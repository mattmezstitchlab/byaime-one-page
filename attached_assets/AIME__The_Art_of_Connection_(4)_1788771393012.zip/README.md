# AIME: The Art of Connection

AIME — LE RÉSEAU DES BONNES RENCONTRES

Prompt de conception UI/UX — Apple-like / Premium / Cards / IA

Conçois une application universelle appelée AIME, fondée sur une idée simple : transformer la mise en relation en une expérience de cartes de profils intelligentes, inspirée à la fois des cartes à jouer, des cartes de collection premium et des interfaces numériques contemporaines.

AIME ne doit surtout pas ressembler à une application de dating classique ni à un annuaire de prestataires. C’est un réseau universel de rencontres entre personnes, professionnels, organismes, lieux, services, ressources et événements, orchestré par une IA entremetteuse.

1. DIRECTION ARTISTIQUE

Créer une esthétique Apple-like contemporaine :

minimalisme extrêmement propre

fond blanc / ivoire très légèrement chaud

noir profond pour la typographie

gris très subtil pour les informations secondaires

grandes respirations

typographie sans-serif moderne de type SF Pro

hiérarchie typographique très précise

coins généreusement arrondis

surfaces translucides et effet verre très subtil

ombres diffuses et presque imperceptibles

profondeur légère

animations fluides

micro-interactions sophistiquées

aucune surcharge visuelle

aucun effet « application de dating »

aucun gradient criard

aucune esthétique gaming kitsch

L’ensemble doit donner l’impression d’un nouveau produit technologique haut de gamme, à mi-chemin entre un objet Apple, une galerie digitale et un jeu de cartes contemporain.

Le design doit être aussi élégant en mobile qu’en desktop.



2. CONCEPT CENTRAL : LA CARTE AIME

Chaque élément du réseau devient une CARTE AIME.

Une carte peut représenter :

une personne

un professionnel

une entreprise

un organisme

un lieu

un service

un événement

une ressource

Créer un système de cartes cohérent, avec une identité visuelle commune mais de légères variations selon la catégorie.

Exemple de carte :

PHOTO / VISUEL

♡
AIME

Matthieu
Saxophoniste

📍 Lille, France

Musique live · Mariage · Événement

★★★★★

La carte doit ressembler à un objet numérique précieux, presque comme une carte de collection.

Ne pas utiliser de bordures épaisses.

Privilégier :
photo + typographie + information minimale + profondeur + matière.



3. LE BOUTON « AIME »

Le bouton principal de la carte n’est pas « Like ».

Il s’appelle :

AIME

Utiliser un symbole cœur élégant.

Interaction :

♡ → cœur plein avec animation très douce.

Lorsque l’utilisateur appuie :

AIME

Une micro-animation confirme l’action.

Mais AIME ne signifie pas uniquement « j’aime cette personne ».

Le système comprend plusieurs intentions :

❤️ J’aime
🤝 Collaborer
💍 Réserver
⭐ Recommander
🧩 Associer
💬 Contacter
☆ Enregistrer

Créer une interface extrêmement simple pour choisir l’intention.



4. L’AGENT IA : L’ENTREMETTEUSE

Créer un agent IA central appelé :

AIME

ou

L’Entremetteuse

Elle ne doit pas apparaître comme un chatbot traditionnel.

Elle agit comme une intelligence invisible qui comprend les intentions et compose les meilleures rencontres.

Interface :

« Que souhaitez-vous créer ? »

Champ conversationnel très minimal.

Exemple :

« Je cherche un mariage élégant de 80 personnes à Lille, avec un lieu de caractère, une photographe artistique et de la musique live. »

AIME analyse automatiquement :

localisation

budget

date

style

nombre de personnes

besoins

préférences

contraintes

compatibilités

Puis présente les cartes correspondantes.



5. L’IDÉE CLÉ : AIME NE RECHERCHE PAS SEULEMENT DES PROFILS

L’application doit proposer des RENCONTRES et des COMPOSITIONS.

Exemple :

VOTRE RENCONTRE

📷 Photographe
×
🎷 Saxophoniste
×
🏰 Domaine
×
🌸 Fleuriste

Afficher :

« Ces quatre cartes semblent particulièrement compatibles. »

Puis une explication générée par l’IA :

« Même zone géographique, univers esthétique cohérent, expériences similaires et compatibilité avec votre budget. »

Créer un bouton :

COMPOSER

qui assemble les cartes dans une composition visuelle élégante.



6. SYSTÈME DE COMBINAISONS

Créer des « COMBOS AIME ».

Exemples :

Photographe + Vidéaste + Musicien
→ COMBO ÉMOTION

Domaine + Fleuriste + Traiteur
→ COMBO RÉCEPTION

DJ + Musicien + Éclairage
→ COMBO PARTY

Créer une présentation très premium, presque comme une collection de cartes physiques posées les unes sur les autres.



7. LE REGISTRE AIME

Créer une section appelée :

REGISTRE

C’est la cartographie universelle des cartes AIME.

Catégories :

PERSONNES
PROFESSIONNELS
ORGANISMES
LIEUX
SERVICES
RESSOURCES
ÉVÉNEMENTS

Créer une navigation extrêmement fluide.

Exemple :

REGISTRE
↓
MARIAGE
↓
FRANCE
↓
HAUTS-DE-FRANCE
↓
LILLE
↓
PHOTOGRAPHES

Mais permettre également à l’IA de naviguer dans ce registre.

Le registre doit sembler vivant.

Les cartes peuvent évoluer :

disponible
indisponible
nouveau
vérifié
populaire
recommandé
en relation avec…



8. PAGE D’ACCUEIL

Créer une homepage très minimaliste.

En haut :

AIME

Navigation :

Découvrir
Rencontres
Registre
Compositions

Au centre :

Tout commence par une rencontre.

Sous-titre :

AIME vous aide à trouver les personnes, les lieux et les services qui ont vraiment quelque chose à créer ensemble.

Puis une grande zone IA :

Que souhaitez-vous créer ?

Placeholder :

« Décrivez votre projet… »

Sous cette zone :

Cartes flottantes AIME légèrement superposées.



9. PAGE DISCOVER

Créer un flux de cartes.

Pas un swipe Tinder classique.

Les cartes doivent être présentées comme une galerie intelligente.

Une grande carte principale au centre.

Autour, quelques cartes secondaires.

L’utilisateur peut :

AIMER
PASSER
OUVRIR
ASSOCIER

Interaction tactile très fluide.

Sur desktop : système de pile de cartes avec profondeur 3D extrêmement légère.

Sur mobile : carte plein écran avec gestes horizontaux.



10. PAGE RENCONTRES

Afficher toutes les rencontres proposées par l’IA.

Exemple :

POUR VOUS

AIME vous présente 6 rencontres

Carte :

🎷 Matt Mez Sax
×
📷 Claire Photography

Compatibilité 94 %

Puis :

« Même zone géographique · style compatible · disponibilité compatible · expérience mariage »

Boutons :

AIMER

VOIR LA RENCONTRE



11. PAGE COMPOSITIONS

Créer une interface très élégante où les cartes sélectionnées sont assemblées.

Exemple :

MON MARIAGE

[ LIEU ]
[ TRAITEUR ]
[ PHOTOGRAPHE ]
[ MUSIQUE ]
[ FLEURISTE ]

Afficher automatiquement les relations.

Une ligne fine peut relier les cartes.

L’IA peut proposer :

OPTIMISER

« J’ai trouvé une meilleure combinaison géographique et budgétaire. »



12. PAGE PROFIL / CARTE PERSONNELLE

Chaque utilisateur possède sa propre carte AIME.

Créer un profil extrêmement premium.

Recto :

PHOTO

AIME

NOM

VILLE

PROFESSION

UNIVERS

VERSO :

Présentation
Compétences
Expériences
Disponibilités
Portfolio
Relations
Avis
Préférences
Statistiques

Créer une animation de retournement 3D très fluide pour passer du recto au verso.



13. SYSTÈME DE TAXONOMIE

Créer une taxonomie extensible.

Une même infrastructure doit pouvoir fonctionner pour :

💍 Mariage
🎂 Anniversaire
🎓 Événement
🎵 Concert
🏢 Entreprise
🎨 Culture
🤝 Association
🌍 Voyage
❤️ Rencontre
👶 Naissance
🕊️ Cérémonie

Le système ne doit jamais être conçu uniquement pour le mariage.

Le mariage est le premier univers d’application, mais AIME doit visuellement et techniquement sembler capable de devenir un registre universel des rencontres humaines et professionnelles.



14. MICRO-INTERACTIONS

Créer une expérience extrêmement fluide :

cartes qui se soulèvent légèrement au toucher

profondeur progressive

cœur qui se transforme lorsqu’on AIME

transitions douces entre les pages

apparition progressive des informations

parallaxe très légère

blur dynamique subtil

spring animations naturelles

retournement 3D des cartes

compositions qui s’assemblent magnétiquement

IA qui révèle progressivement ses recommandations

Tout doit être rapide, silencieux et élégant.



15. DESIGN SYSTEM

Créer un véritable design system AIME :

Typography
Spacing
Cards
Buttons
Icons
Badges
Avatars
AI surfaces
Navigation
Modals
Sheets
Tags
Filters
States
Empty states
Loading states

Prévoir les états :

Normal
Hover
Pressed
Selected
Liked
Matched
Verified
Unavailable
Recommended

Créer des composants réutilisables.



16. PHILOSOPHIE UX

Ne jamais demander à l’utilisateur de remplir de longues listes de formulaires.

AIME doit apprendre progressivement.

L’utilisateur peut simplement dire :

« Je cherche un photographe pour mon mariage à Lille. »

L’IA comprend.

Puis :

« Plutôt quelque chose de très artistique. »

AIME affine.

Puis :

« J’aime celui-ci. »

AIME apprend.

L’interface doit donner l’impression que l’application comprend progressivement la personne.



17. PHRASES DE MARQUE

Utiliser ponctuellement :

AIME

Tout commence par une rencontre.

Trouvez ce qui vous correspond.

Les bonnes personnes. Les bons lieux. Les bonnes idées.

AIME les réunit.

Une intention. Des rencontres. Une composition.



18. RÉSULTAT ATTENDU

Produire une expérience UI/UX complète et cohérente, très haut de gamme, contemporaine, minimaliste et émotionnelle.

AIME doit donner immédiatement l’impression d’être :

un nouveau type de réseau social + moteur de compatibilité + registre universel + intelligence artificielle d’entremise + système de cartes numériques.

L’utilisateur doit avoir envie de toucher les cartes.

Il doit comprendre immédiatement le concept.

Et surtout :

AIME ne doit pas donner l’impression de chercher quelqu’un.

Il doit donner l’impression de découvrir une rencontre qui devait arriver.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://aime-network.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/aae9e2ba-747d-44ad-8e4b-8e88280e6264).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
