# Langues, conformité européenne et paiement par carte

Six chantiers : la traduction des conversations, un sélecteur de langue global, la langue de la radio, les réglages d'accessibilité, un pied de page juridique complet, et le paiement des crédits par carte bancaire. Le mode d'emploi est mis à jour à la fin.

## 1. Messagerie multilingue automatique

- Détection de la langue de chaque message reçu par l'entremetteuse (aucune saisie de l'utilisateur).
- Vous écrivez en français, le message part traduit dans la langue de votre interlocuteur : le fil affiche votre texte d'origine et la version envoyée.
- À la réception, l'inverse : le message étranger est affiché traduit dans votre langue, avec la possibilité de voir l'original.
- Réglage par fil dans le cockpit : « traduction automatique » activée/désactivée, langue détectée affichée à côté de chaque participant.

## 2. Menu de langue dans le header

- Sélecteur (drapeau + code) en haut à droite, à côté des icônes existantes.
- Interface traduite via un dictionnaire : français, anglais, espagnol, allemand, italien (extensible).
- Choix mémorisé, appliqué à toute la navigation, aux titres et aux boutons. Les contenus écrits par les membres restent dans leur langue d'origine.

## 3. Langue de la radio

- Au clic sur le bouton Micro de la radio : choix de la langue de diffusion.
- L'entremetteuse traduit l'annonce, le prompteur et les paroles dans la langue choisie avant de parler.

## 4. Réglages et accessibilité européenne

- Bouton « Paramètres » dans le tableau de bord ouvrant un panneau dédié :
  - Contraste élevé, taille de texte (normal / grand / très grand), réduction des animations, soulignement des liens, police adaptée dyslexie.
  - Langue de l'interface, préférences de traduction.
  - Consentement données et déclaration d'accessibilité (EAA / WCAG 2.1 AA).
- Préférences conservées et appliquées à tout le site.

## 5. Pied de page juridique et labels

- Nouveau footer sur toutes les pages : mentions légales, CGU, CGV, politique de confidentialité (RGPD), politique cookies, déclaration d'accessibilité, médiation à la consommation, contact.
- Pages correspondantes créées avec un contenu type prêt à personnaliser.
- Bandeau cookies avec choix granulaire.
- Rangée de badges de conformité : RGPD, WCAG 2.1 AA / EAA, paiement sécurisé, médiation.

## 6. Paiement des crédits par carte bancaire

- Activation de Stripe (paiements intégrés Lovable, pas de compte à créer, vendeur en France).
- Sur la page Crédits, les packs (5 € / 15 € / 40 €) et le montant libre deviennent payables par carte en un clic.
- Retour de paiement : page de confirmation, crédits ajoutés automatiquement, écriture dans l'historique avec le statut réel.
- Les virements IBAN / Revolut restent disponibles en saisie manuelle ; les retraits ne changent pas.

## 7. Mode d'emploi mis à jour

Nouveaux chapitres détaillés, pas à pas : créer une carte, établir un devis, publier un éphémère (story 6 h), payer et suivre un paiement, plus un chapitre langues & accessibilité.

## Détails techniques

- Traduction messages : nouveau mode `traduire` dans `chat.functions.ts` (détection + traduction), colonnes de traduction sur `messages`, réglage `auto_translate` dans `thread_settings`.
- i18n : contexte React léger + dictionnaires JSON par langue dans `src/lib/i18n/`, préférence en `localStorage` et sur `profiles`, `lang` du document mis à jour.
- Accessibilité : classes utilitaires sur `<html>` pilotées par le contexte de préférences, tokens existants de `styles.css` respectés.
- Radio : paramètre de langue passé à `radio.functions.ts` (annonce + voix).
- Stripe : `enable_stripe_payments`, produits crédits, session de checkout via server function, webhook sous `src/routes/api/public/` qui insère dans `credit_ledger` avec statut `valide`.
- Footer et pages légales : routes statiques avec `head()` propre à chacune.
