# Le Cœur universel : menus contextuels et actions dépliables

Oui, c'est d'accord sur les trois points : le cœur devient l'unique surface d'action de chaque carte, ses actions se déplient sur place, et la Messagerie devient la conversation avec l'Entremetteuse (plus les fils entre membres restant, eux, dans les Aimes reçues).

## 1. Le cœur devient contextuel

Le menu n'est plus la même liste de 7 intentions partout. Il dépend de la nature de la carte (`kind`) et de qui regarde.

| Nature de la carte | Actions proposées |
| --- | --- |
| Professionnel / Service | Réserver, Devis, Payer, Contacter, Associer, Recommander, Enregistrer, J'aime |
| Lieu | Réserver (dates), Devis, Visiter (proposer une visite), Contacter, Associer, Recommander, Enregistrer |
| Personne | Contacter, Collaborer, Inviter à un événement, Recommander, Enregistrer, J'aime |
| Entreprise / Organisme | Contacter, Collaborer, Devis, Partenariat, Recommander, Enregistrer |
| Événement | Participer, Inviter quelqu'un, Proposer un service, Payer ma part, Enregistrer, J'aime |
| Ressource | Réserver, Louer / Emprunter, Devis, Contacter, Associer, Enregistrer |
| Ma propre carte | Modifier, Timeline, Disponibilités, Tarifs, Partager |

Une action déjà en cours (intention déposée, devis reçu, part à payer) s'affiche en tête avec son état, plutôt qu'en simple ligne inerte.

## 2. Chaque action se déplie dans le menu

Un clic n'ouvre plus une autre page et ne ferme plus le menu : la ligne se déplie, l'action se fait sur place, puis une confirmation s'affiche.

- **Contacter** — champ message déjà présent + bouton **Envoyer**. Crée le fil et envoie réellement le premier message.
- **Réserver** — mini-calendrier des disponibilités de la carte, choix d'une date (ou plage), créneau, mot facultatif, bouton **Demander cette date**.
- **Associer** — liste de mes compositions + « Nouvelle composition », sélection, bouton **Ajouter**.
- **Devis** — service et date visée, bouton **Demander un devis** ; s'il existe déjà un devis, montant et bouton **Voir le devis**.
- **Payer** — visible quand une part m'est due : montant, service, bouton **Marquer payé** (suivi de règlement ; l'encaissement carte demanderait Stripe, à dire si vous le voulez).
- **Recommander** — champ « à qui » (membre ou e-mail) + **Envoyer la recommandation**.
- **Inviter / Participer** — choix de l'événement parmi les miens + **Inviter**.
- **J'aime / Enregistrer** — instantanés, sans dépliage.

Le menu reste ouvert pendant toute la séquence, se ferme après confirmation, et s'ouvre vers le haut quand il manque de place (déjà en place).

## 3. Tout remonte dans « Aimes reçues »

`/aimes-recues` devient le centre des échanges entre membres : chaque intention y arrive avec son type, son message, sa date demandée, son statut, et la conversation liée est lisible et répondable **directement dans la ligne** (fil déplié, pas de renvoi vers une autre page). Accepter / refuser / proposer une autre date restent au même endroit, et une réponse acceptée déclenche l'événement ou le devis correspondant.

## 4. La Messagerie devient l'Entremetteuse

`/messages` cesse d'être la liste des fils entre membres et devient **la conversation avec l'Entremetteuse** : historique persistant, style tendre et taquin déjà en place, et capacité à produire des documents.

- Elle génère sur demande : **devis, facture, contrat, convention, dossier de demande (organisme, association, subvention), fiche technique, planning**.
- Chaque document est présenté dans la conversation, modifiable, puis **envoyable par elle-même** à un membre, à un e-mail ou à un groupe (participants d'un événement, cartes d'une composition).
- Elle voit mes cartes, mes événements, mes compositions et mes devis, donc peut agir en contexte (« envoie le devis de samedi au traiteur et aux mariés »).

Les fils entre membres restent accessibles, mais leur maison est désormais Aimes reçues.

## Détails techniques

- `src/lib/aime/intents.ts` : passe d'une liste fixe à une table d'actions par `card_kind` (label, sous-titre, icône, composant de dépliage, condition d'affichage).
- `src/components/aime/AimeButton.tsx` : refonte en menu à panneaux — chaque action rend son propre panneau inline (`ContactPanel`, `ReservePanel`, `AssociatePanel`, `QuotePanel`, `PayPanel`, `RecommendPanel`, `InvitePanel`), avec état de soumission et confirmation.
- Nouvelles écritures depuis le cœur : `messages` + `threads` (Contacter), `aimes` avec `requested_date` (Réserver), `composition_items` (Associer), `quotes` (Devis), `event_payments` (Payer), `event_invitations` (Inviter).
- Base : ajout d'une colonne de date demandée sur `aimes` si absente, et d'une table `ai_conversations` / `ai_messages` + `documents` pour la Messagerie Entremetteuse (avec GRANT et RLS par propriétaire).
- `src/lib/aime/ai.functions.ts` : nouvelle fonction serveur de conversation persistante et de génération de documents (sortie structurée), plus envoi par e-mail.
- `/aimes-recues` : fil de conversation déplié par ligne ; `/messages` réécrit autour de l'Entremetteuse.

## Ordre de réalisation

1. Menus contextuels par nature de carte + dépliage des actions (Contacter, Réserver, Associer).
2. Devis, Payer, Recommander, Inviter dans le cœur.
3. Aimes reçues avec conversation intégrée.
4. Messagerie Entremetteuse et génération/envoi de documents.
