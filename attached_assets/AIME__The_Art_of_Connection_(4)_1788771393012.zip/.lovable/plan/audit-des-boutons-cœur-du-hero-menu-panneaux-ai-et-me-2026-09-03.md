# Audit des boutons : cœur du hero, menu « + », panneaux AI et ME

## Ce que l'audit a trouvé

**1. Le menu « + » envoie souvent au même endroit sans rien ouvrir**
Cinq entrées sur dix pointent vers `/ma-page` (Une carte, Un moment sur ma timeline, Une contribution, Une annonce radio) ou vers une page de navigation (Un devis → `/monde`, Une intention publique → `/reseau`). `/ma-page` est une simple redirection vers votre page personnelle : on arrive sur la même page, sans formulaire ni composer ouvert. D'où l'impression que « ça ne fait rien ».

**2. Deux listes de création qui peuvent diverger**
La barre mobile utilise `createEntries.tsx`, mais le dock desktop redéfinit sa propre liste en dur dans `AimeDock.tsx`. Deux sources pour la même chose.

**3. Le cœur du hero fait doublon**
Sur l'accueil, le cœur du champ propose : dicter, importer, préciser le cadre, déposer en public, embarquer des cartes, reprendre une intention. Or le hero affiche déjà « Voir ma feuille de route », « Créer ma page », « Comment ça marche », plus les suggestions de cartes. Le cœur reste utile (dictée, import, cadre), mais ses entrées « cartes » et « reprendre » recouvrent ce que le hero fait déjà.

**4. Panneaux AI et ME**
Les boutons y sont bien câblés (liens de route ou mutations). Le risque restant est identique au point 1 : quelques liens ouvrent une page sans amener à l'endroit exact attendu.

## Ce que je propose de faire

**Menu « + » — chaque entrée ouvre vraiment quelque chose**
- Source unique : le dock desktop consomme `createEntries.tsx` (suppression de la liste dupliquée).
- Chaque entrée transporte une intention dans l'URL (par ex. `?creer=moment`, `?creer=contribution`, `?creer=radio`, `?creer=carte`) et la page cible ouvre directement le bon panneau/formulaire à l'arrivée : composer de timeline, contribution, annonce radio, édition de la carte.
- « Une intention publique » ouvre le dépôt public sur `/reseau`, « Un devis » ouvre le choix de carte puis la demande de devis, au lieu d'atterrir sur une page de navigation.
- Toute entrée dont l'action cible n'existe pas encore est retirée du menu plutôt que laissée muette.

**Cœur du hero — allégé, pas supprimé**
Sur l'accueil uniquement, le cœur garde Dicter · Importer · Préciser le cadre · Déposer en public, et perd « Embarquer des cartes » et « Reprendre une intention », déjà couverts par le hero. Le cœur reste complet sur les autres pages.

**Panneaux AI et ME**
Passage de chaque bouton en conditions réelles (connecté), et correction des liens qui n'ouvrent pas la vue attendue. Un bouton sans action possible affiche un retour clair plutôt que rien.

## Détails techniques

- `src/components/aime/AimeDock.tsx` : supprimer `CREATE`, importer `CREATE_ENTRIES`.
- `src/components/aime/createEntries.tsx` : ajouter un `search` par entrée (typé) plutôt qu'un simple `to`.
- Routes cibles (`carte.$id.tsx`, `reseau.tsx`, `monde.tsx`) : lecture du paramètre à l'arrivée et ouverture du panneau correspondant.
- `src/lib/aime/heartActions.ts` : retirer `cartes` et `reprendre` de la branche `accueil`.
- Vérification finale au navigateur sur l'accueil, le menu « + », AI et ME.
