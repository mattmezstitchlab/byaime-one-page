# La Carte Mariage : une seule page pour tout organiser

## L'idée, dite simplement

Un futur marié ne doit pas apprendre l'architecture d'AIME. Il crée **une carte Mariage**, et cette carte devient **sa page de mariage** : tout s'y passe, sans jamais en sortir.

Aucune route nouvelle. La page carte existe déjà (`/carte/$id`, avec ses onglets Présentation, Savoir-faire, Expériences, Calendrier, Avis, Devis, Timeline, Radio, Contact). Le mariage n'est pas une page à part : c'est **un habillage de cette page**, déclenché quand la carte est de nature « événement » dans l'univers Mariage. Même URL, même gabarit, contenu adapté.

## Ce que voit un futur marié

### 1. Créer sa carte en trois phrases
Dans « Ma carte », à côté des chemins existants (rapide avec Aime / détaillé), une troisième entrée : **« J'organise mon mariage »**. Trois questions, pas une de plus :

```text
Vos deux prénoms          →  nom de la carte
Une date (même approximative) → semaine et saison rattachées
Une ville                 →  lieu de recherche et proximité
```

La carte est publiée immédiatement, en univers Mariage, nature « événement ». Le reste se remplira tout seul, au fil des onglets.

### 2. La page mariage : les onglets deviennent des étapes
Pour une carte Mariage, la barre d'onglets se réécrit dans l'ordre où on organise un mariage, en réutilisant les blocs déjà construits ailleurs :

| Onglet | Ce qu'on y fait | Brique réutilisée |
| --- | --- | --- |
| Le jour J | date, lieu, compte à rebours, météo du jour | timeline + panneau météo existants |
| Les prestataires | les places à pourvoir (Lieu, Traiteur, Photographe, Musique, Fleuriste, Coiffure…), pleines ou vides | plan des places + composition |
| Le déroulé | heure par heure : cérémonie, cocktail, repas, ouverture de bal | timeline de la carte |
| Les invités | liste, réponses, tables | participants de projet |
| Budget | devis reçus, acomptes, total engagé | devis et paiements existants |
| Musique | playlist et moments radio du jour | MusicBox / Radio |
| Documents | contrats, factures, attestations | Bureau |
| Messages | un fil par prestataire | messagerie existante |

Un seul écran, une seule barre : on change d'onglet, jamais de page.

### 3. Les places à pourvoir font le travail
L'onglet **Prestataires** part d'un plan pré-rempli des rôles d'un mariage. Chaque place vide est un bouton : Aime propose les cartes correspondantes **à proximité de la ville et disponibles à la date**, avec cœur d'intention « Réserver ». Une place se remplit sans quitter l'onglet ; la place devient pleine, le budget et le déroulé se mettent à jour.

### 4. Le fil conducteur
En haut de la page, une bande discrète : *« Mariage de … — 12 juin — Lille — 4 places sur 9 pourvues »*, avec la prochaine chose à faire. C'est le seul endroit qui dit quoi faire ensuite.

## Ce que ça ne fait pas

- Aucune route dupliquée : ni `/mariage`, ni page parallèle. Tout vit sur `/carte/$id`.
- Aucun module inventé : chaque onglet branche une brique qui fonctionne déjà.
- Le modèle universel reste intact : le même mécanisme servira ensuite aux autres mondes (anniversaire, concert, association) avec un simple jeu de rôles différent.

## Détails techniques

- Nouveau fichier `src/lib/aime/presets/mariage.ts` : liste des rôles du plan des places, étapes types du déroulé, jeu d'onglets, libellés.
- `src/components/aime/CardTabs.tsx` : le type `CardTabKey` s'élargit aux clés du préréglage ; la liste d'onglets devient une donnée passée par la page, comme aujourd'hui.
- `src/routes/carte.$id.tsx` : détection `kind === "evenement" && universes.includes("mariage")` → jeu d'onglets et panneaux du préréglage, sinon comportement actuel inchangé.
- Panneaux mariage assemblés à partir de l'existant : `SlotPlan`, `CompositionPicker`, `HeroTimeline`, `MonthCalendar`, `WeatherPanel`, `MusicBox`, blocs devis/paiements et `FolderTemplates` du Bureau.
- Recherche de prestataires : `openSlots.ts` + `proximity.ts` déjà en place, filtrés sur ville, univers mariage et disponibilité à la date.
- « J'organise mon mariage » ajouté comme troisième mode dans `src/routes/ma-carte.tsx`, réutilisant la mutation de création existante.
- Invités et paiements : rattachement de la carte à un projet (`events`) créé silencieusement à la publication, pour réutiliser participants et paiements sans nouvelle table.
- Aucune modification de sécurité ; une seule évolution de base éventuelle : colonne de liaison carte ↔ projet si elle n'existe pas déjà (à vérifier avant écriture).

## Ordre de réalisation

1. Préréglage mariage + onglets dédiés sur la page carte.
2. Plan des places et remplissage par proximité/date.
3. Déroulé du jour J et bande de progression.
4. Invités, budget, musique, documents, messages branchés dans les onglets.
5. Entrée « J'organise mon mariage » dans Ma carte.
