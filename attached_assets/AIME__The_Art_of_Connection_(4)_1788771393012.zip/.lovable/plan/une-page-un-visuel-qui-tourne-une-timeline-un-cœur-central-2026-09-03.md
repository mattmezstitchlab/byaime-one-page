# Une page = un visuel qui tourne, une timeline, un cœur central

## Ce que je comprends de votre demande

La page d'une personne (la vôtre comme celle d'un autre) devient une vitrine pure : un carrousel de visuels correspondant à ses univers/activités, une ligne de temps, et **un seul point d'entrée** — le cœur, posé au centre de la timeline, qui pointe vers elle. Plus de barre de saisie visible en permanence : on clique sur le cœur, un menu central se déplie, et **tout se fait sur place** (dispo, devis, contact, paiement, galerie, avis, message…). En bas de ce menu, l'agent répond : une notification horodatée avec ce qu'il a compris et un bouton de confirmation qui transforme l'échange en repère sur la timeline.

Le panneau latéral droit « Modifier ma page » devient le seul endroit d'édition, et absorbe le panneau ME. Le panneau AI devient l'éditeur d'instructions : ce que l'agent fait pour moi, et ce que les autres ont le droit de faire sur ma page (dont l'activation de modules comme la visio, qui s'affiche alors au centre du hero).

## 1. Nettoyage du hero et de la timeline

- Suppression du texte « Passé · Présent · Futur ».
- Suppression des pastilles de filtre par famille (Rdv, Document, Argent) — ces vues repassent par le menu du cœur.
- Suppression du badge d'état (« Nouveau ») en haut à gauche.
- Suppression de la barre de saisie AIME du hero.
- Conservés : le zoom, « Aujourd'hui », les repères et les bulles.

## 2. Le cœur central

- Un bouton cœur ancré au centre de la timeline, avec une pointe dirigée vers le repère central (curseur du présent).
- Au clic : un panneau central s'ouvre au-dessus de la timeline, sans quitter la page. Il contient :
  - **La grille d'actions** (issue de la liste actuelle des demandes) : Disponibilités · Tarifs et devis · Payer · Photos et vidéos · Avis · Message · Contact · Radio · J'aime cette page. Sur ma propre page s'ajoutent les entrées de gestion.
  - **La zone d'action sur place** : chaque action déplie son propre bloc dans le menu (choix de dates, formulaire de devis, champ de message, écran de paiement, galerie, visio si activée). Aucune navigation.
  - **Un champ libre** en bas, pour écrire au lieu de cliquer.
  - **Le fil de l'agent** : après chaque écriture ou clic, une ligne horodatée « Voici ce que j'ai compris : … » avec **Confirmer** / **Corriger**. La confirmation crée le repère sur la timeline (et le message, devis, demande correspondant), avec animation de recentrage sur le repère créé.
- Le menu se ferme par Échap, clic extérieur, ou après confirmation.

## 3. Le carrousel des univers (vitrine)

Les pictos en haut à droite sont bien les univers/activités cochés à la création. Ils deviennent le pilote d'un carrousel :

- Une slide par univers coché : un média (image ou vidéo) plein cadre, le **titre de l'univers au centre**, un **sous-titre descriptif**, et une mention **« à partir de … »** quand un tarif est renseigné.
- Défilement automatique doux + navigation par les pictos (qui restent en haut à droite) et par glissement.
- Média par défaut fourni selon l'univers, remplaçable depuis le panneau d'édition.

## 4. Panneau droit « Ma page » (ex-ME fusionné)

Un seul panneau latéral, structuré en sections repliables avec un sommaire ascenseur à gauche :

1. **Identité** — nom, phrase, photo, ville.
2. **Univers et activités** — cases à cocher ; **au clic sur un univers coché, sa fiche se déplie juste en dessous** : média (défaut modifiable), titre, sous-titre, tarif « à partir de », description. C'est ce qui alimente le carrousel.
3. **Vitrine** — ordre des slides, galerie, portrait animé.
4. **Disponibilités et tarifs** — plages, grille de prix, conditions.
5. **Mes cartes** — mes autres pages, brouillons, publication.
6. **Échanges** — demandes reçues, messages, devis en cours.
7. **Argent** — factures, versements, coordonnées de paiement.
8. **Bureau** — dossiers, documents, exports.
9. **Projets et contributions**.
10. **Fréquence et radio** — publication, consentement de diffusion, bibliothèque musicale.
11. **Ma place dans Le Monde AIME**.
12. **Compte et réglages** — profil, langue, notifications, confidentialité, crédits, diagnostics, déconnexion.

Tout ce qui vivait dans ME et dans les pages Paramètres / Bureau / Projets / Argent devient accessible ici. Les pages restent en ligne (adresses directes), mais on n'a plus besoin d'y aller.

## 5. Panneau AI (éditeur d'instructions)

1. **Ma voix** — ton, langue, signature, ce que l'agent peut répondre à ma place.
2. **Ce que l'agent fait pour moi** — relances, tri des demandes, rédaction de devis, résumé de la journée.
3. **Ce que les autres peuvent faire sur ma page** — interrupteurs par action du cœur : demander une dispo, un devis, payer, écrire, appeler, voir la galerie, laisser un avis, **visio**. Un module coché apparaît au centre du hero.
4. **Modules affichés dans le hero** — visio, radio, lecteur musical, réservation directe.
5. **Mémoire et consignes libres** — instructions en texte, comme un éditeur de prompt.
6. **Journal et crédits** — ce que l'agent a fait, ce que ça a coûté.

## 6. Menu « + »

Réduit à ce qui crée réellement quelque chose, tout s'ouvrant sur place :

1. Un repère sur ma timeline (rendez-vous, souvenir, disponibilité)
2. Un projet
3. Un document
4. Une intention publique
5. Une invitation

« Une carte » quitte le menu : la création de page passe par le panneau droit.

## 7. Suppressions

- La page **Mode d'emploi** (`/comment-ca-marche`) et tous ses liens (menus, pied de page, plan du site, sitemap).

## 8. Mise à jour du système nerveux

`/plan-du-site` est réécrit pour refléter la nouvelle grammaire : la page universelle au centre, le cœur comme unique entrée d'action, le panneau Ma page comme unique lieu d'édition, le panneau AI comme éditeur de règles, et les anciennes destinations (Bureau, Projets, Argent, Paramètres) montrées comme sections du panneau plutôt que comme pages à visiter. Retrait du nœud Mode d'emploi.

## Détails techniques

- `HeroTimeline.tsx` : retrait du bandeau « Passé · Présent · Futur » et des pastilles `presentFamilies` ; ajout d'un point d'ancrage central pour le cœur (`HeartCenter`) et d'un `onConfirm` qui crée le repère.
- Nouveau `src/components/aime/heart/HeartMenu.tsx` (grille d'actions + blocs dépliants + champ libre) et `HeartFeed.tsx` (fil horodaté avec Confirmer/Corriger). Les blocs réutilisent `QuotePanel`, `MonthCalendar`/`RangePicker`, `MusicBox`, `WeddingPanels`, `StripeEmbeddedCheckout`.
- `src/lib/aime/pageAsk.ts` : `AskEntry` gagne `module` (visio, radio…) et `enabled`, lus depuis les réglages du panneau AI.
- `carte.$id.tsx` : suppression de `AimeField` du hero et de `StatusBadge` ; remplacement du visuel unique par `<UniverseCarousel />` piloté par `activeUniverse` ; les pictos deviennent les puces du carrousel.
- Nouveau `UniverseCarousel.tsx` + extension de `PageSetup.tsx` en `PagePanel.tsx` sectionné (accordéon + sommaire), avec l'édition par univers dépliée sous la case cochée.
- Stockage des fiches d'univers et des réglages d'agent : nouvelles colonnes JSONB sur `cards` (`universe_cards`, `agent_rules`) via migration, avec GRANT et RLS alignés sur les politiques existantes de `cards`.
- `MePanel.tsx` est retiré de `AimeBar.tsx` ; le bouton ME ouvre le panneau Ma page. `AiPanel.tsx` est réécrit selon la structure ci-dessus.
- `createEntries.tsx` : entrée « Un repère » ajoutée, « Une carte » retirée.
- Suppression de `src/routes/comment-ca-marche.tsx` et de ses références (`i18n`, `SiteFooter`, `LogoMenu`, `MobileMenu`, `systemMap.ts`, `sitemap.xml.ts`).
- `systemMap.ts` : nœuds, arêtes et états revus.

## Ce que je propose de livrer en premier

Le hero nettoyé, le carrousel d'univers et le cœur central avec son fil de confirmation — c'est le cœur de l'expérience. Les panneaux Ma page / AI et le système nerveux suivent dans la foulée.
