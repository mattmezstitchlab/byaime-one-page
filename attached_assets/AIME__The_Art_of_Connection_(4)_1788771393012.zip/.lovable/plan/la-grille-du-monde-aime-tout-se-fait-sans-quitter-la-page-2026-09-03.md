# La grille du Monde AIME : tout se fait sans quitter la page

Aujourd'hui la grille sert à regarder : survol → bulle, clic → on part ailleurs (page carte, création de page). L'idée est d'en faire un vrai plan de travail : on reste sur la grille, tout s'ouvre à côté.

## 1. Un panneau latéral au lieu d'un départ

Cliquer une case ouvre un panneau à droite (en bas sur téléphone), la grille reste visible et la case reste allumée.

Dans le panneau, en onglets :
- **La page** : visuel, présentation, savoir-faire, ville, avis.
- **Sa timeline** : ses moments publics, en lecture.
- **Écrire** : un fil de messages, envoi direct depuis le panneau.
- **Demander** : proposer une date, demander un devis — le formulaire s'ouvre là, pas sur une autre page.

Un lien discret « Ouvrir la page complète » reste disponible pour ceux qui le veulent.

## 2. Chercher dans la grille, sans liste

Un champ au-dessus de la grille : en tapant (métier, ville, nom, monde), les cases qui correspondent s'allument et les autres s'éteignent doucement. La grille devient elle-même le résultat de recherche — plus besoin de basculer sur la vue liste.

Filtres rapides à côté : Disponible · Près de moi · En direct (fréquence) · Nouveau.

## 3. Choisir plusieurs cases

Un mode « sélection » : on clique plusieurs cases, une barre apparaît en bas de la grille avec le nombre choisi et trois gestes :
- écrire à tout le monde d'un coup,
- créer un projet avec ces personnes,
- envoyer une intention publique à ce groupe.

## 4. Prendre sa place sur place

Sur une case libre, au lieu de partir vers Ma page : un mini-formulaire dans le panneau (nom, ville, savoir-faire, visuel). Dès validation la case s'allume à son nom, sans changement de page. Les détails se complètent plus tard.

## 5. Naviguer dans la grille

- Clic sur une zone dense → on descend d'un niveau (Ville ← Région ← Pays ← Monde) sans rechargement.
- Le niveau, le lieu, la recherche et la case ouverte vivent dans l'URL : la vue se partage telle quelle.
- Raccourcis clavier : flèches pour se déplacer de case en case, Entrée pour ouvrir, Échap pour fermer.

## Détails techniques

- Nouveau `GridWorkspace` autour de `WorldGrid` : grille à gauche, panneau `CardConsole` étendu à droite, en `grid-cols-[1fr_360px]` au-dessus de `lg`, feuille en bas sur mobile.
- La bulle de survol reste (aperçu rapide) ; le clic n'épingle plus la bulle mais alimente le panneau.
- Recherche/filtres : réutilisation des utilitaires existants de `/reseau` (filtres cartes, proximité, fréquences publiées) ; la grille reçoit un `Set` d'identifiants mis en avant et applique opacité/anneau.
- Sélection multiple : état local `Set<string>`, barre d'action réutilisant les flux message/projet/intention déjà en place.
- Création sur case libre : formulaire court branché sur le flux existant de création de page personnelle, sans navigation.
- État dans l'URL de `/reseau` (`vues=grille`, `niveau`, `lieu`, `q`, `carte`) via search params Zod.
- Aucun changement de schéma ni de règles de sécurité.

## Ordre proposé

1. Panneau latéral (page, timeline, écrire, demander)
2. Recherche + filtres dans la grille
3. Case libre : création sur place
4. Sélection multiple et gestes de groupe
5. Navigation clavier et zoom par zone
