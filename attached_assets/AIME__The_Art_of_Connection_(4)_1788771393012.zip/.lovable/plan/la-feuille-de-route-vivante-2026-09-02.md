# La Feuille de route vivante

Depuis le champ du hero d'accueil, ce que vous écrivez devient un plan d'étapes affiché comme des petites cartes reliées, dans le même langage visuel que le plan du système. Chaque étape dit clairement ce qui est réellement disponible aujourd'hui sur AIME, et quand ça ne l'est pas, propose un contournement concret pour ne jamais bloquer.

## Ce que voit l'utilisateur

1. Il écrit son intention (« Créer un mariage à Lille en juin »).
2. Sous le champ, Aime répond comme aujourd'hui, plus un bouton **« Voir ma feuille de route »**.
3. Un panneau plein écran s'ouvre avec un chemin en trois temps :
   - **Point zéro — l'intention** : reformulée par Aime, avec l'objectif, la ville, la date approximative et le budget si exprimés.
   - **Le chemin** : 5 à 9 étapes ordonnées, chacune une petite carte reliée par une ligne pointillée animée.
   - **L'après** : 2 à 4 cartes « ce qui peut continuer » (revivre, réutiliser l'équipe, archiver la comptabilité, publier sa propre carte…).
4. Chaque carte d'étape porte : un titre court, une phrase, un badge de disponibilité, un bouton d'action qui mène à la vraie page (Registre filtré, Ma carte, Équipe, Bureau, Devis, Messages…).

## La transparence, sans point bloquant

Trois badges seulement, calculés côté site (pas inventés par l'IA) :

- **Disponible** — la fonctionnalité existe et le bouton y mène directement.
- **Partiel** — elle existe mais incomplète ; la carte affiche « Autrement : … » avec le détour praticable.
- **Bientôt** — pas encore là ; la carte propose systématiquement une alternative (un document déposé au Bureau, un message, une note sur la timeline) pour que l'étape reste faisable.

Règle non négociable : aucune étape ne peut rester sans action. Si rien d'interne ne couvre l'étape, l'action par défaut devient « Le noter dans mon projet » (une entrée de timeline) ou « En parler à Aime ».

## Comment le plan est fabriqué

- Un **catalogue de capacités** décrit dans le code chaque brique du site (créer sa carte, composer une équipe, réserver une date, demander un devis, suivre le budget, inviter, payer, exporter la compta, radio, guides…), avec sa route, son état réel et son contournement. C'est la seule source de vérité pour les badges, réutilisée par le plan du système pour rester cohérente.
- Aime (moteur IA existant) reçoit ce catalogue et l'intention, et rend un plan structuré : point zéro, étapes ordonnées, étapes d'après — chaque étape référençant une capacité du catalogue par son identifiant.
- Toute étape citant un identifiant inconnu est écartée ; les badges et les liens viennent du catalogue, jamais du texte généré. Zéro promesse inventée.

## Où on retrouve la feuille de route

- Ouverte depuis le hero d'accueil (bouton sous la réponse d'Aime).
- Rejouable depuis le panneau **AI** du dock, et depuis la page Rencontres avec la même intention.
- Bouton **« Transformer en projet »** : crée le projet et dépose chaque étape comme élément à faire, pour que le plan ne reste pas décoratif.

## Détails techniques

- `src/lib/aime/capabilities.ts` : nouveau catalogue typé (`id`, libellé, route, `status`, `workaround`), aligné sur `systemMap.ts`.
- `src/lib/aime/roadmap.functions.ts` : nouveau `createServerFn` appelant la passerelle IA (même modèle et mêmes garde-fous d'erreur que `ai.functions.ts`) avec un `json_schema` strict : `{ zero: {objective, context}, steps: [{capability_id, title, why, order}], after: [{capability_id, title, why}] }`. Validation Zod + filtrage sur le catalogue au retour.
- `src/components/aime/RoadmapPanel.tsx` : nouveau panneau (overlay) — cartes reliées, pointillés animés en SVG sur desktop, pile verticale sur mobile, respect de `prefers-reduced-motion`, fermeture Échap/extérieur.
- `src/components/aime/IntentionHero.tsx` : ajout du bouton d'ouverture sous la réponse d'Aime, sans toucher au comportement de recherche actuel.
- Réutilisation des styles existants du plan du système (mêmes badges de statut, mêmes cartes).
- Aucune modification de base de données pour la version initiale ; « Transformer en projet » utilise les tables `projets`/timeline déjà en place.
