# La page universelle : une carte, plusieurs univers, un seul écran

## Ce que j'ai compris

Une personne ne crée pas une fiche. Elle crée **sa page universelle** : un même être humain (ou lieu, ou structure) qui existe dans plusieurs univers — mariage, anniversaire, concert, entreprise, billetterie. Aujourd'hui chacun de ses univers est une carte séparée, sur une page séparée : on se perd, et l'idée disparaît.

Donc :

1. **Les pictos d'univers du hero ne sont plus des liens.** Un clic remplace, **au même endroit**, le contenu par la carte que ce même utilisateur a créée dans cet univers : visuel du hero, nom, accroche, présentation, savoir-faire, calendrier. On ne change jamais de page. C'est là que tout s'éclaircit : on comprend qu'on est sur **une personne**, pas sur une annonce.
2. **Sous la timeline, une navigation par onglets.** Présentation · Savoir-faire · Expériences · Calendrier · Avis · Devis & tarifs · Timeline · Contact. Le hero et la timeline restent toujours visibles ; seul le contenu change. Fini les pages `/devis/$cardId` et `/carte/$id/timeline` qui font sortir de la carte.
3. **Les titres de section deviennent de vrais titres**, plus des micro-capitales grises perdues dans la colonne.
4. **Les tags de savoir-faire deviennent cliquables** : au clic, on reste sur place, le tag se met en évidence et on voit ce qu'il relie — la description de ce savoir-faire, les autres univers de cette personne où il apparaît, et les cartes proches qui le partagent.

```text
┌──────────────────────────────────────────────┐
│  HERO (visuel de l'univers actif)   ◍ ◍ ◍ ◍  │ ← pictos = univers
│  Nom · accroche · ville · ♥                  │
│  ▓▓▓ TIMELINE ▓▓▓ (filtrée par l'univers)    │
├──────────────────────────────────────────────┤
│ Présentation │ Savoir-faire │ Devis │ Avis…  │ ← onglets
├──────────────────────────────────────────────┤
│  contenu de l'onglet (change seul)           │
└──────────────────────────────────────────────┘
```

## 1. Le sélecteur d'univers

- Les pictos listent les univers du **même propriétaire** (déjà calculé dans `universeLinks`), plus un picto « Tout ».
- Clic = changement d'état, pas de navigation. Fondu croisé du visuel, du titre, de l'accroche et du contenu.
- La timeline se filtre sur l'univers actif : les repères des autres univers restent visibles mais atténués.
- L'URL suit en `?univers=mariage` (remplacement d'historique, sans rechargement), pour rester partageable.
- Si l'univers correspond à une autre carte du propriétaire, c'est **cette carte** qui alimente l'onglet courant, sans quitter l'écran.

## 2. Les onglets

| Onglet | Contenu | Aujourd'hui |
| --- | --- | --- |
| Présentation | bio, budget, contact, à associer | dispersé en colonnes |
| Savoir-faire | tags cliquables + détail du tag choisi | liste passive |
| Expériences | parcours, références | section |
| Calendrier | `CalendarFlip` (recto mois / verso jour) | colonne de droite |
| Avis | note, avis référencés | section |
| Devis & tarifs | le contenu de `/devis/$cardId` rapatrié | **page séparée** |
| Timeline | l'éditeur de repères de `/carte/$id/timeline` | **page séparée** |

Les deux anciennes routes ne disparaissent pas : elles redirigent vers `/carte/$id?onglet=devis` / `?onglet=timeline` pour ne casser aucun lien existant.

L'onglet actif vit dans l'URL (`?onglet=`), donc partageable et compatible avec le bouton Retour.

## 3. Les tags cliquables

Un tag sélectionné ouvre, juste sous la rangée, un panneau discret :
- ce que recouvre ce savoir-faire pour cette personne (phrase tirée de la bio / des expériences quand elle existe) ;
- **dans quels univers de sa page** ce savoir-faire réapparaît (pastilles cliquables qui basculent l'univers) ;
- les cartes proches qui partagent ce tag, en petites étiquettes ;
- une action directe : Demander un devis sur ce savoir-faire.

Aucun rechargement, aucune page intermédiaire.

## 4. Le verso de carte, cohérent avec la page

La console à tuiles prévue pour le verso reprend exactement les mêmes entrées que les onglets (mêmes libellés, mêmes ordres), pour qu'un utilisateur reconnaisse le même vocabulaire dans la vignette et dans la page. Le second cœur du verso disparaît : le cœur reste unique, sur le recto.

## Détails techniques

- `src/routes/carte.$id.tsx` : ajout de `validateSearch` (`univers?: string`, `onglet?: string`), état dérivé de l'URL via `Route.useSearch()` et `navigate({ search, replace: true })`. `universeLinks` devient une liste de boutons d'état ; la carte affichée devient `activeCard` (la carte du propriétaire correspondant à l'univers actif, sinon la carte de l'URL). Le hero passe en fondu croisé (`AnimatePresence` sur la clé `activeCard.id`).
- Nouveau `src/components/aime/CardTabs.tsx` : barre d'onglets collante sous la timeline, défilable horizontalement sur mobile, accessible au clavier (rôle `tablist`).
- Nouveau `src/components/aime/CardSkills.tsx` : rangée de tags sélectionnables + panneau de liaison.
- Extraction du corps de `src/routes/devis.$cardId.tsx` et de `src/routes/carte.$id.timeline.tsx` vers `src/components/aime/panels/QuotePanel.tsx` et `TimelinePanel.tsx`, utilisés par l'onglet et par les anciennes routes (qui deviennent de simples redirections).
- `HeroTimeline` reçoit `activeUniverse` pour atténuer les repères hors univers.
- Titres de section : passage de `eyebrow` à un vrai `h2` (`text-xl font-semibold tracking-[-0.02em]`) avec le surtitre conservé au-dessus quand il apporte quelque chose.
- Aucune migration, aucune nouvelle table, aucune modification de RLS : tout vient de `cards`, `card_availability`, `reviews`, `quotes` déjà en place.

## Ordre de réalisation

1. Onglets + URL (`?onglet=`) et rapatriement de Devis & tarifs et Timeline dans la page.
2. Pictos d'univers en sélecteur sur place + fondu du hero + timeline filtrée.
3. Titres de section lisibles et remise en page du contenu par onglet.
4. Tags de savoir-faire cliquables et panneau de liaison.
5. Verso de carte aligné sur le même vocabulaire, cœur unique sur le recto.
