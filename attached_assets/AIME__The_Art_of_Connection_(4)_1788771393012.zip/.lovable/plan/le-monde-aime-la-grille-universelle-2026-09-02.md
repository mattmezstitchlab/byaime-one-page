# LE MONDE AIME — la grille universelle

Le Registre devient **Le Monde AIME** : une seule grille, comme une toile de point de croix, où chaque case est une place dans le réseau. Une case prise = une carte universelle. La recherche, les filtres, la liste et la map restent dans `/reseau`, comme prévu.

## Le premier écran

À l'ouverture, la grille se remplit toute seule : les cases scintillent une à une, puis s'allument avec les cartes déjà présentes (visuel rond de la carte dans la case). Les cases libres restent en trame très légère. Un compteur discret : « 226 cartes · 999 774 cases libres ».

La grille tient dans un seul écran, sans défilement : la taille des cases s'adapte au nombre de places du niveau affiché.

## Quatre niveaux de zoom

Un sélecteur simple au-dessus de la grille : **Ville · Région · Pays · Monde**.

- **Ville** (départ : Lille Métropole) — cases larges, on reconnaît chaque visage.
- **Région**, **Pays** — cases plus petites, la densité devient un dessin.
- **Monde** — la trame complète : chaque point est une personne.

Le niveau et le lieu vivent dans l'URL (`/monde?niveau=ville&lieu=lille-metropole`), donc partageables. Cliquer une zone dense descend d'un niveau.

## Une case

- **Case prise** : survol → la même bulle que sur la timeline (visuel, nom, ville, savoir-faire, actions Aimer / Écrire / Ouvrir). Clic → la carte AIME du site.
- **Case libre** : survol → « Cette place est libre ». Clic → « Prendre ma place » : on choisit sa case, on crée sa carte, la case s'allume à son nom.

Pour cette version, prendre une case est **gratuit** (compte requis). On explique le sens : chaque place soutiendra l'association « Le Monde AIME » à hauteur d'un euro, et l'abonnement mensuel viendra plus tard, ajusté au projet de chacun. Aucun paiement dans cette version.

## Ce que devient `/registre`

`/registre` redirige vers `/monde` en conservant les paramètres. La capsule, le burger et le plan du site affichent « Le Monde AIME ». La recherche/filtres/liste/map restent l'affaire de `/reseau`.

## Détails techniques

- Nouvelle route `src/routes/monde.tsx` : search params Zod `niveau` (ville|region|pays|monde) et `lieu`, avec `fallback`.
- Nouveau `src/components/aime/WorldGrid.tsx` : grille CSS calculée depuis la taille du conteneur (aucun défilement), rendu virtualisé au-delà de ~5 000 cases, animation d'apparition en scintillement échelonné, respect de `prefers-reduced-motion`.
- Placement stable : hachage de l'identifiant de carte → index de case dans le niveau, pour qu'une carte garde toujours la même place.
- Bulle d'aperçu : composant partagé extrait de `HeroTimeline` (`MarkerPreview`), réutilisé ici et par les pins de la map.
- Réservation : nouvelle table `world_cells` (niveau, lieu, index, card_id, user_id) avec GRANT explicites, lecture publique et écriture réservée au propriétaire ; une seule case par utilisateur et par niveau.
- `src/routes/registre.tsx` devient une redirection ; mise à jour de `navigation.ts`, `systemMap.ts` et du plan du site.
- Aucun paiement, aucun abonnement dans cette étape.
