# Nettoyage final du header, de la Radio et des anciennes pages

## Objectif

Alléger l’interface autour de trois accès très clairs : le Réseau, le profil public et Mon espace. La timeline reste la surface centrale ; les échanges et documents continuent d’exister dans leur contexte, sans pages autonomes « Messages » ou « Bureau ».

## 1. Header simplifié

- Remplacer les deux liens texte centraux par deux boutons pictogrammes accessibles :
  - **Carte** : icône carte, ouvre `/reseau` ;
  - **Mon profil** : icône personne, ouvre directement la page publique de l’utilisateur.
- Si aucune page publique n’existe encore, **Mon profil** ouvre sa zone de création dans Mon espace.
- Conserver le bouton **Mon espace / Connexion** à droite comme accès au compte ; il ne fait donc plus doublon avec le centre.
- Adapter le menu mobile au même vocabulaire et supprimer toute entrée « Bureau » du menu du logo.

## 2. Radio rattachée au bouton du header

- Conserver l’icône Radio en haut à droite.
- Au clic, afficher la capsule du lecteur juste sous ce bouton, ancrée au header.
- La capsule contient lecture/pause, titre en cours, piste suivante et fermeture.
- Le clic sur l’icône ouvre le lecteur sans lancer automatiquement le son ; la lecture reste une action volontaire dans la capsule.
- Supprimer définitivement la capsule flottante en bas de l’écran, sur ordinateur comme sur téléphone.
- Préserver le moteur audio unique déjà en place : seule sa présentation et son point d’ouverture changent.

## 3. Cartes de timeline toujours visibles

- Sortir l’aperçu au survol du conteneur visuel qui le coupe actuellement.
- Positionner cette carte par rapport au repère, au-dessus de la timeline, avec une altitude supérieure au header.
- Ajouter une détection des bords : la carte reste entièrement visible sous le header, se décale horizontalement si nécessaire et devient défilable si son contenu dépasse la hauteur disponible.
- Conserver le même comportement au clic sur mobile et vérifier les timelines de profil, projet et démo mariage.

## 4. Suppression réelle des pages Messages et Bureau

- Supprimer la route `/messages` au lieu de la rediriger : l’ancienne adresse doit désormais être introuvable.
- Supprimer toute la famille de pages autonomes `/bureau`, y compris dossier, projet, membres et export, afin qu’aucun « Bureau » parallèle ne subsiste.
- Retirer tous les liens internes vers ces anciennes adresses avant suppression.
- Conserver les capacités utiles à leur nouvel emplacement :
  - les conversations dans **Échanges** de Mon espace et dans les repères concernés ;
  - les documents, devis, factures et échéances dans **Documents** et **Argent** du projet ;
  - les documents personnels encore nécessaires dans une section **Documents** de Mon espace, sans vocabulaire « Bureau ».
- Les anciennes URL ne seront pas redirigées, conformément au choix de suppression totale.
- Ne modifier ni les données existantes ni les fonctions de sécurité en base.

## 5. Cohérence avec les audits Manus

Les audits confirment les principes déjà engagés :

- une seule timeline universelle et un seul PLAY ;
- une donnée enregistrée une fois, puis affichée par différentes vues ;
- aucun encaissement par AIME ;
- les messages, documents, échéances et personnes accessibles depuis leur repère ou leur projet ;
- séparation nette entre profil public, projet privé et Mon espace.

Ce lot applique ces conclusions au header, à la Radio et aux anciennes pages. Il ne lance pas une nouvelle refonte des cinq panneaux déjà fusionnés ; leur contenu pourra être affiné ensuite à partir des mêmes règles.

## Vérifications

- Contrôler le header sur ordinateur et téléphone, connecté et déconnecté.
- Vérifier l’ouverture/fermeture de la Radio et l’absence de capsule en bas.
- Tester les cartes de timeline près du haut, du bas et des bords sur profil, projet et démo.
- Vérifier qu’aucun lien du site ne pointe vers `/messages` ou `/bureau...` et que ces adresses affichent bien une page introuvable.
- Vérifier que conversations, documents et suivi financier restent accessibles depuis Mon espace ou les panneaux du projet.
