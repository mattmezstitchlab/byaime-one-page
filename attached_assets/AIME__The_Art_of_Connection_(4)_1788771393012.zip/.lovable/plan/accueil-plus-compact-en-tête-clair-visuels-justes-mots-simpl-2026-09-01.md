# Accueil plus compact, en-tête clair, visuels justes, mots simples

## 1. Hero de l'accueil plus court
Le hero occupe aujourd'hui presque tout l'écran (92vh). Il passe à une hauteur réduite (environ 68vh sur ordinateur, 60vh sur mobile) : la vidéo reste visible, le champ de saisie et la timeline remontent, et la suite de la page apparaît tout de suite.

## 2. Ondes animées dans la carte audio
Dans l'aperçu d'un repère « Audio » de la timeline, les 12 barres sont fixes. Elles deviennent vivantes : chaque barre monte et descend en boucle, avec un décalage entre elles, comme un vrai niveau sonore. Animation désactivée si l'utilisateur préfère réduire les animations.

## 3. Suppression des pictos étoiles
Retrait de toutes les étoiles (notes/mises en avant) sur la page d'une carte et dans Réseau. La note chiffrée reste affichée en texte simple là où elle est utile, sans symbole étoile.

## 4. En-tête
- Logo « AIME » nettement plus grand en haut à gauche.
- Les liens de navigation passent en noir (au lieu de gris), l'onglet actif reste distinct.
- À droite : un bouton « Connexion » (ou « Mon espace » si déjà connecté) menant à la page d'entrée.

## 5. Fin des photos en double sur les cartes
Aujourd'hui une carte sans photo retombe sur une petite liste d'images génériques, donc les mêmes visuels reviennent partout. Nouvelle règle, appliquée à toutes les cartes :
photo de la carte → visuel du métier → visuel de l'univers → variante neutre.
La bibliothèque riche déjà utilisée pour les devis (pâtisserie, cave, hôtel, scène, patrimoine, beauté, mode, déco, transport, institution…) devient la source unique, et à métier égal une variante est choisie de façon stable selon la carte pour éviter deux vignettes identiques côte à côte.

## 6. Audit du wording : compréhensible par un enfant, de 7 à 97 ans
Principes retenus : phrases courtes, mots du quotidien, verbes concrets, zéro jargon métier ou technique.

Exemples de reformulations (accueil, hero, cartes, Bureau, Composer) :

| Aujourd'hui | Proposé |
| --- | --- |
| « Tout ce qui existe peut devenir une carte. Et chaque carte peut rencontrer la bonne. » | « Chacun a sa carte. AIME trouve celles qui vont ensemble. » |
| « Vous exprimez une intention, l'IA compose les rencontres qui tiennent debout. » | « Dites ce que vous voulez faire. On vous présente les bonnes personnes. » |
| « Le bouton AIME — Une intention, pas un like. » | « Le cœur : dites ce que vous voulez faire ensemble. » |
| « Les compositions » | « Les équipes » |
| « Univers vivants » | « Onze mondes à explorer » |
| « Rapprochement automatique / score de complétude » | « AIME range vos papiers et vous dit ce qu'il manque » |
| « Registre » (nav) | conservé, mais sous-titre « Toutes les cartes » |
| « Prestataires », « intermittents du spectacle » | « les pros », « les artistes et techniciens du spectacle » |

L'audit couvre l'accueil, le hero, Composer, Réseau, Ma carte, Mes projets, Le Bureau, et les libellés d'aide. Les noms de rubriques de la navigation ne changent pas (repères connus), seuls les textes explicatifs sont simplifiés.

## Détails techniques
- `IntentionHero.tsx` : `min-h-[92vh]` → `min-h-[60vh] md:min-h-[68vh]`, paddings réduits.
- `HeroTimeline.tsx` : keyframes `audio-wave` dans `src/styles.css` + `animationDelay` par barre.
- `AppShell.tsx` : taille du logo, `text-foreground` sur les liens, bouton Connexion à droite de la grille d'en-tête (colonne déjà réservée par `aria-hidden`).
- `src/lib/aime/visuals.ts` : `visualFor` réécrit pour déléguer à la table métier/univers de `universeVisuals.ts`, avec choix stable par hash d'identifiant ; signature étendue pour recevoir la carte.
- Retrait de `Star` dans `src/routes/carte.$id.tsx` et `src/routes/reseau.tsx`.
- Textes : mise à jour des chaînes dans les routes concernées et dans les dictionnaires `src/lib/i18n` (FR d'abord, autres langues alignées).
- Aucun changement de base de données ni de logique métier.
