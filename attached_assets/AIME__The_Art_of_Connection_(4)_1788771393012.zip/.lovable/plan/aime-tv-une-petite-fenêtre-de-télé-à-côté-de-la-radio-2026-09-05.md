# AIME TV — une petite fenêtre de télé à côté de la radio

Même principe que la Radio AIME, mais en images : une carte de lecture posée en haut à droite, qui enchaîne photos et vidéos courtes selon la chaîne choisie.

## Ce qui est faisable tout de suite

1. **Bouton AIME TV** dans l'en-tête, juste à côté du bouton Radio. Un clic ouvre le menu des chaînes :
   - **Les préparatifs** — tout ce qui précède le jour du projet
   - **Jour J** — ce qui se passe pendant, y compris les dépôts des invités
   - **Memory** — l'après : rétrospective, film du/de la vidéaste quand il est disponible
2. **Carte de lecture flottante** en haut à droite, dans le style de votre capture : titre de la chaîne, position (1/18), image ou vidéo arrondie, légende date + moment, barre de progression, précédent / lecture / suivant, bouton son, bouton fermer, plus un **bouton plein écran** pour agrandir et revenir.
3. **Enchaînement automatique et aléatoire** : photos ~5 s, vidéos jusqu'à leur fin (10 s max côté dépôt), passage au suivant tout seul, boucle quand la chaîne est finie.
4. **Musique par-dessus** : un interrupteur Audio et un curseur de volume. Quand la TV met sa musique, la radio se tait (elles ne peuvent pas parler en même temps), et le son d'une vidéo baisse automatiquement la musique.
5. **Dépôt des invités** : un bouton « Déposer » sur la carte TV — photo ou vidéo de moins de 10 secondes, rangée dans le projet et visible immédiatement dans la chaîne Jour J. Refus clair et lisible si la vidéo dépasse 10 s.
6. **Réparation du dépôt vocal de la radio** : le bouton micro existe mais l'annonce ne repart pas à l'antenne. À corriger dans le même passage, avec un vrai retour à l'écran (enregistrement en cours, durée, écoute avant envoi).

## Le direct (comme un live Instagram)

C'est faisable, mais ce n'est pas la même technique : diffuser une caméra en direct vers plusieurs spectateurs demande un service de visio dédié (type LiveKit ou Daily), avec un abonnement séparé et un coût à la minute. Je propose de le traiter **en deuxième temps**, une fois la TV en place, et de vous présenter le choix du service et son coût avant de l'engager.

En attendant, une version simple est possible sans service externe : « **Direct court** » — la personne se filme depuis la carte TV, et le clip part immédiatement en tête de la chaîne Jour J avec la mention « à l'instant ». Ce n'est pas du direct continu, mais l'effet côté spectateurs est très proche.

## Détails techniques

- Nouveau `TvProvider` calqué sur `RadioProvider` : file d'éléments, index, lecture/pause, saut, boucle, volume musique.
- La file réutilise `buildPlayQueue` (`src/lib/aime/play/buildQueue.ts`) filtrée sur `photo` + `video` uniquement, avec trois portées : avant le jour J, le jour J, après.
- La carte reprend le rendu de `PlayStage` en mode `embedded`, dans un nouveau composant `TvCard` (flottant, redimensionnable plein écran), monté dans `AppShell` à côté de `RadioStage`.
- Un seul son à la fois : passage par `claimAudio`/`bindAudioElement` de `src/lib/aime/audioBus.ts`, avec un nouveau propriétaire `tv` ; la musique de fond garde son propre élément audio ducké.
- Dépôts invités : `media_items` (`addMedia`) + envoi fichier via `uploadMediaFile`, contrôle de durée côté navigateur avant l'envoi.
- Dépôt vocal radio : audit de `AnnonceDialog` → `musicbox_entries` → `publicTracksQuery`, pour comprendre pourquoi l'annonce ne ressort pas dans la programmation, puis correction.
- Aucune donnée ajoutée automatiquement : la TV ne montre que ce qui existe déjà dans le projet.

## Ordre de réalisation

1. Bouton + menu des chaînes + carte TV avec photos/vidéos et plein écran
2. Musique superposée, volume, coordination avec la radio
3. Dépôt invité (photo / vidéo ≤ 10 s) et réparation du dépôt vocal radio
4. Direct court (auto-filmé), puis étude du vrai live si vous le souhaitez
