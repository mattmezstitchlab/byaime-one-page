# Vérification du travail fait avec Manus

J'ai comparé le dossier reçu avec la version en ligne. La plupart des ajouts sont sains, mais trois points bloquent avant de les reprendre tels quels.

## Ce qui est bon à reprendre

- **Un projet peut désormais être « démo », « brouillon » ou « actif »** : la démo mariage n'est plus confondue avec un vrai projet.
- **Corrections manuelles sur la ligne de temps** : renommer, décrire, déplacer un repère sans écraser sa source.
- **Brouillon conservé** dans le navigateur : on retrouve son projet après avoir fermé la page.
- **Analyse automatique** : retards, éléments à confirmer, effets en chaîne d'un même prestataire, incohérences, prochaine action, relances prêtes à envoyer.
- **Passage du brouillon au vrai projet** : création de l'événement puis rattachement des devis, paiements et documents déjà existants — sans recopier ces objets.

## Les trois points bloquants

**1. La base de données n'a jamais reçu les deux nouvelles tables.** Le code écrit dans `project_snapshots` et `project_finance_links`, qui n'existent pas côté serveur. Aujourd'hui, « transformer en vrai projet » échouerait, et créerait même un événement fantôme avant l'erreur. Les deux scripts fournis sont corrects (propriétaire, accès restreint, index) — il suffit de les appliquer, puis de retirer les contournements laissés dans le code.

**2. La barre du bas a perdu les boutons AI et ME.** Il ne reste que le « + ». Cela contredit la décision prise pour le Studio (dock unique AI · + · ME). Je propose de rétablir les trois boutons.

**3. La page démo publique demande maintenant un compte.** Elle enregistre en base et déclenche des messages d'erreur pour un visiteur non connecté. Elle doit rester consultable et modifiable en lecture libre, l'enregistrement n'apparaissant qu'une fois connecté.

## Ce qui reste du Money Orchestrator

Seules les fondations sont posées (engagements rattachés au projet, budget lu depuis ces engagements). L'échéancier détaillé, le feu MONEY READY, le journal financier, le rétroplanning de paiement et le module intermittence restent à faire, comme prévu dans le plan précédent.

## Ce que je ferai si vous validez

1. Appliquer les deux tables manquantes et régénérer les types, puis nettoyer les contournements du code.
2. Reprendre les fichiers ajoutés et modifiés par Manus dans le projet.
3. Rétablir les trois boutons de la barre du bas.
4. Rendre la page démo à nouveau publique : modification libre, enregistrement réservé aux personnes connectées.
5. Vérifier dans le navigateur : démo en visiteur, création d'un projet depuis un récit, page projet avec sa ligne de temps.

## Détails techniques

- Migrations à appliquer : `project_snapshots` (unicité par `event_id`, RLS propriétaire, trigger `touch_updated_at`) et `project_finance_links` (contrainte d'objet non nul, index, RLS propriétaire). `touch_updated_at`, `events`, `quotes`, `event_payments`, `bureau_documents` existent déjà.
- Retirer les `(supabase as any)` de `projectPersistence.ts` après régénération de `src/integrations/supabase/types.ts`.
- `persistValidatedProject` : encapsuler la création événement + snapshot pour éviter l'événement orphelin.
- Déplacer l'`import type { PaymentCommitment }` en tête de `src/lib/aime/world/types.ts`.
- Aucun changement sur les routes `/bureau`, aucun `SECURITY DEFINER` touché.
