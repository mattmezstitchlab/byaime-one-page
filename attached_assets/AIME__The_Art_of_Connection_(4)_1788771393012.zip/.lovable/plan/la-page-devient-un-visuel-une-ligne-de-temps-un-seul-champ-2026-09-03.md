# La page devient : un visuel, une ligne de temps, un seul champ

Sur la page d'une personne (la vôtre ou celle d'un autre), tout se demande à l'agent AIME depuis un unique champ posé dans le hero, avec le cœur à gauche du champ. Plus rien ne s'empile sous la ligne de temps : les réponses de l'agent s'ouvrent en bulle sur la timeline, au bon moment.

## Ce qui change à l'écran

1. **Le champ AIME entre dans le hero.** Il remplace la barre actuelle posée sous le visuel. Même apparence que partout ailleurs sur le site : un champ libre, un bouton d'envoi, et le cœur rond au début du champ.

2. **Le cœur devient le menu de la page.** Il reprend, une par une, les entrées de l'ancienne navigation horizontale :
   - Disponibilités et réservation
   - Tarifs et devis
   - Payer
   - Photos, vidéos, galerie
   - Avis
   - Savoir-faire et expériences
   - Contacter / écrire
   - Radio
   - Sur sa propre page : Projets, Bureau, Modifier ma page

   Choisir une entrée écrit l'intention dans le champ ; on peut la préciser librement avant d'envoyer (« disponible le 12 juin ? », « devis pour un mariage en juillet »).

3. **La barre d'onglets horizontale disparaît**, ainsi que tout le contenu qui suivait. La page se termine sur la ligne de temps.

4. **Les réponses s'ouvrent en bulle sur la timeline.** L'agent recentre la ligne de temps sur la période concernée et ancre sa réponse à la bonne date : le calendrier de disponibilité sur le mois demandé, le devis à la date visée, un avis à sa date, un message envoyé à aujourd'hui. On ferme la bulle, la page reste nette.

5. **Demander, c'est faire.** Envoyer un message, demander un devis, proposer une date ou déposer un document depuis ce champ exécute l'action, l'inscrit sur la ligne de temps et affiche le résultat en bulle — sans ouvrir Bureau ni Projets.

6. **Le hero garde un seul visuel** pour cette étape ; le carrousel de médias viendra ensuite.

## Détails techniques

- `src/routes/carte.$id.tsx` : suppression de `CardTabs`, du bloc de contenu par onglet et du paramètre `onglet` (conservé en lecture pour rediriger les anciens liens vers l'intention équivalente). Le hero accueille `AimeField` ; le bouton propriétaire « Modifier ma page » et sa feuille latérale restent, déclenchés depuis le cœur.
- Nouveau `src/lib/aime/pageAsk.ts` : liste des intentions de page (clé, libellé, icône, visibilité propriétaire/visiteur), phrase pré-remplie par intention, et résolution `intention -> panneau` réutilisant les composants existants (`CalendarFlip`, `QuotePanel`, `CardSkills`, avis, contact, `RadioPanel`, `TimelinePanel`, galerie).
- `src/lib/aime/agentParse.ts` : ajout d'une détection d'intention par mots-clés (disponible, tarif, devis, payer, photo, vidéo, avis, contacter, message) en plus de la date déjà comprise, renvoyée dans `AgentIntent`.
- `src/components/aime/AimeField.tsx` : réintroduction d'un cœur optionnel (props `actions`, `onPick`) — menu simple, sans l'ancienne machinerie d'intentions structurées supprimée précédemment.
- `src/components/aime/HeroTimeline.tsx` : support d'une bulle « réponse » éphémère ancrée à un instant donné, rendue via le `renderExtra` existant élargi, plus recentrage sur la période demandée.
- `src/components/aime/TimelineAgentBar.tsx` : la logique de soumission et de validation d'un repère est déplacée dans le hero ; le composant est simplifié ou absorbé.
- Actions réelles inchangées côté données : `card_timeline_entries` pour les repères, `ensureThread`/`sendMessage` pour les messages, `createDraftQuote` pour les devis, `useAimes` pour les intentions. Aucun changement de schéma, de politique RLS ni de paiement.
- Les routes `/bureau`, `/projets`, `/messages` restent en place et accessibles ; elles cessent seulement d'être nécessaires depuis une page.
