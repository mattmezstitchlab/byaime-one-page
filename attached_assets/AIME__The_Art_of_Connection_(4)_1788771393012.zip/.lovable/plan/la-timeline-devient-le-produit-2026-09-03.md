# La timeline devient le produit

Oui : c'est le vrai différenciant, et le code est déjà à 70 % du chemin. Voici ce qui existe réellement, ce qui manque, et ce qui est faisable pour que tout se joue sur la ligne de temps — la vôtre et celle des autres.

## Ce qui existe déjà (vérifié dans le code)

- `HeroTimeline.tsx` gère le zoom (semaine → décennie), le glisser, les bandes de période, la bulle au survol **et épinglée au clic** (fermeture par Échap / clic extérieur), plus des actions rondes dans la bulle via `actionsFor`.
- Les repères ont déjà un type de média : `video`, `audio`, `doc`, `historique`, `rencontre`, avec vignette ronde et média joué dans l'aperçu.
- `timelineActions.ts` associe déjà des actions à chaque nature de repère (réserver, devis, facture, ouvrir, écrire, partager, confirmer, libérer, supprimer).
- `carte.$id.tsx` alimente la timeline avec : disponibilités groupées en bandes, repères `card_timeline_entries`, avis, date de création. Le propriétaire peut cliquer une date vide pour créer un repère.
- Les onglets `CardTabs` (présentation, calendrier, devis, timeline, bureau, projets, préréglage mariage…) portent aujourd'hui tout le contenu, en dessous de la timeline.

## Ce qui manque pour que « tout se passe sur la timeline »

1. **Aucun filtre.** Impossible de n'afficher que les documents, les rendez-vous, les tâches ou l'argent.
2. **Les documents, devis, factures et paiements ne sont pas sur la timeline** de la carte, alors que les types de repères existent déjà. Ils vivent uniquement dans le Bureau.
3. **Aucun repère de message.** Rien ne relie `messages` / `threads` à la ligne de temps.
4. **Pas de tâches.** Il n'y a pas de notion de tâche à échéance rattachée à une carte.
5. **La bulle montre, elle ne remplit pas.** On ne peut pas éditer le titre, la date, joindre un fichier ou répondre depuis la bulle : il faut redescendre dans un onglet.
6. **Pas de regroupement.** Beaucoup de repères proches donnent des points empilés ; pas de « dossier » qui les rassemble.
7. **Un prestataire repéré n'atterrit nulle part sur ma timeline** : ajouter quelqu'un à un projet ne crée pas de repère daté chez moi.

## Réponse à la question de fond

Presque tout peut se jouer sur la timeline, à une condition : la bulle doit devenir une **mini-carte active** (lire / remplir / répondre), comme le menu du cœur qui agit sans changer de page. Deux choses resteront hors timeline parce qu'elles n'ont pas de date : l'identité de la page (photo, présentation, savoir-faire) et les réglages. Tout le reste — disponibilités, rendez-vous, événements, documents, devis, factures, paiements, avis, messages, tâches — est daté, donc représentable.

## Ce que je propose de construire

### 1. Une barre de filtres au-dessus de la règle

Pastilles cumulables : Tout · Rendez-vous · Tâches · Documents · Argent · Messages · Souvenirs · Disponibilités. Le filtre change seulement l'affichage, pas les données. Sur mobile, la barre défile horizontalement.

### 2. Toutes les sources sur une seule ligne

La timeline de la carte agrège en plus de l'existant :
- `bureau_documents` (date du document) → repère Document
- devis et factures (`quotes`, `quote_items`) → repères Devis / Facture avec le montant lisible
- `event_payments` → repère Paiement
- `events` liés à la carte → repère Événement
- `messages` du fil rattaché à la carte, groupés par jour → repère Message
- tâches (nouveau `kind` sur `card_timeline_entries`, avec échéance et état fait/à faire)

### 3. La bulle devient une mini-carte qui se remplit

Selon la nature du repère, la bulle affiche un rendu propre (lecteur vidéo, onde audio, aperçu de document, fil de discussion, montant) **et** un mode édition en place pour le propriétaire : titre, date, note, case « fait », pièce jointe. On enregistre sans quitter la timeline, comme dans le menu du cœur.

### 4. La carte Message

Nouveau type de repère et nouvelle mini-carte : les derniers messages du fil lié à cette carte, avec un champ de réponse directement dans la bulle. Écrire à quelqu'un depuis sa timeline devient le geste normal, sans passer par `/messages`.

### 5. Les dossiers sur la timeline

Quand plusieurs repères tombent dans la même fenêtre (ou partagent le même projet), ils se groupent en une pastille « dossier » portant un compte. Au clic, la bulle liste les repères du dossier ; on peut zoomer pour les séparer. Un projet/événement devient donc un dossier daté sur la ligne.

### 6. Un prestataire ajouté apparaît sur ma ligne

Depuis la page d'un prestataire, « Ajouter à un projet » crée un repère daté sur **ma** timeline (à la date du projet), avec la vignette de la personne et les actions écrire / devis / réserver.

### 7. Même rendu que l'accueil, partout

La timeline de `/carte/$id` reprend exactement le comportement de l'accueil (aperçu riche, vignettes rondes, actions), et le même composant sert sur la page projet et le Bureau.

## Découpage en livraisons

1. **Lire** — filtres, agrégation documents/argent/événements, dossiers de regroupement.
2. **Agir** — bulle éditable en place, tâches avec échéance, prestataire ajouté à un projet.
3. **Parler** — carte Message avec réponse dans la bulle.

## Détails techniques

`HeroTimeline.tsx` : ajout d'une prop `filters` (liste de familles actives) et d'un regroupement par grappe quand deux repères sont à moins de ~18 px, rendu en pastille de compte. Extraction du contenu de la bulle dans `TimelineBubble.tsx` avec un rendu par `media`/`kind` et un mode édition (mutations React Query existantes sur `card_timeline_entries`). Nouvelles sources agrégées dans un hook `useCardTimeline(cardId)` réutilisable, lisant `bureau_documents`, `quotes`, `event_payments`, `events`, `messages` via `src/lib/bureau/queries.ts` et `src/lib/aime/queries.ts`. Tâches : nouveau `kind` `tache` plus colonnes `due_at`/`done_at` sur `card_timeline_entries` (migration avec GRANT et politiques RLS calquées sur l'existant). Carte Message : réutilisation de `ensureThread`/`sendMessage` de `src/lib/aime/messaging.ts`. `timelineActions.ts` étendu pour les clés `tache`, `message`, `dossier`. Aucune suppression de table ni changement des findings de sécurité.
