# Tout sur la ligne de temps : un seul lecteur, des fenêtres au lieu de listes

## La réponse à la question

Oui : sur la page démo mariage, toutes les listes (Avant, Le jour J, Après,
prestataires, devis, messages, souvenirs) sont écrites depuis le même modèle de
projet, via la même fonction qui fabrique la ligne de temps. Rien n'est saisi
deux fois : ce sont des fenêtres sur la même ligne.

En revanche il y a bien **deux lecteurs** aujourd'hui, ce qui contredit la règle
« un seul moteur PLAY » :

- le bouton de lecture posé sur le film d'ouverture, branché sur la ligne de temps ;
- un second lecteur propre au bloc « Le jour J » (« Lire la journée », « Moment
  suivant », son compteur 5/12 et son minuteur), qui vit de son côté.

## Ce qu'on fait

1. **Un seul bouton de lecture**, celui posé en bas du film. Le second lecteur du
   bloc « Le jour J » disparaît en tant que lecteur : ses commandes sont retirées.
2. **Le bloc « Le jour J » devient une fenêtre** : la même ligne de temps, cadrée
   sur la journée, avec la pastille du moment en cours qui suit la lecture du
   haut de page. Quand on lit, la page suit ; quand on clique un moment, la
   lecture s'y pose.
3. **Les listes restent, mais allégées** : chaque section garde sa liste
   (c'est ce qui rend le projet lisible), mais elle affiche le moment en cours en
   surbrillance et n'a plus ni bouton lecture ni minuteur à elle.
4. **Même règle sur les autres pages** : page carte, page projet et accueil
   n'affichent qu'un seul bouton de lecture, celui de la ligne de temps.

## Ce qu'on ne fait pas

- On ne supprime pas les sections : une ligne de temps seule est illisible pour
  un projet de plusieurs centaines d'objets. Les sections sont des fenêtres, pas
  des doublons.
- On ne touche pas au Bureau ni aux fonctions protégées de la base.

## Détails techniques

- `src/routes/demo.mariage.tsx` : retirer l'état local `playing` / `stepIndex` et
  son minuteur ; lire le moment courant depuis le contexte `PlayProvider`
  (`usePlay().currentId`) au lieu d'un compteur maison.
- Remonter le `PlayShell` du hero pour qu'il enveloppe toute la page (le
  fournisseur au niveau de la page, le bouton restant posé sur le film), afin que
  les sections puissent lire et écrire la lecture en cours.
- Les pastilles horaires du bloc « jour J » appellent `start`/`seek` du moteur
  au lieu de `goTo` local.
- Vérifier qu'aucune autre page ne fabrique un lecteur parallèle
  (`carte.$id.tsx`, `projets.$id.index.tsx`, accueil).

## Reste à faire par ailleurs (extrait de la feuille de route)

- Brancher le rétroplanning sur la barre d'intention et l'import de documents.
- Vues filtrées Intermittence et Mariage (calques, pas de ligne séparée).
- Suite Money Orchestrator : échéancier, feu « prêt à payer », journal financier.
- Décider du sort de la page « réseau » (question posée juste avant).
