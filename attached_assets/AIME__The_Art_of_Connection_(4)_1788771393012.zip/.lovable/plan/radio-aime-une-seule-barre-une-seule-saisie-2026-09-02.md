# Radio AIME — une seule barre, une seule saisie

## Ce qui cloche aujourd'hui (audit du bloc radio)

Le bandeau du bas empile six commandes qui ne jouent pas le même rôle :

- **Doublons d'action** : « Micro » existe deux fois (bouton rond coeur → « Parler en direct », et pastille « Micro »). « Prompteur » existe aussi deux fois (menu coeur + pastille).
- **Outils décoratifs** : « Paroles » découpe simplement la note de l'entrée en lignes et surligne une ligne au prorata du temps — ce n'est pas un vrai fichier de paroles. « Partition » dessine une portée de notes générée à partir des lettres du titre : joli, mais faux, et cela suggère une fonctionnalité musicale qui n'existe pas.
- **Pas d'entrée d'écriture** : la radio se règle par pastilles et sliders alors que partout ailleurs (accueil, Carte réseau, Ma carte) on parle à Aime dans un champ avec le bouton coeur.
- **Réglages dispersés** : la distance d'écoute (slider géo), la langue d'antenne et la traduction sont enfouies dans le panneau micro, sans lien clair avec ce qu'on entend.
- **Ambiguïté de fond** : rien ne dit si la radio est « ce qui passe autour de moi » ou « ma console de diffusion ». Les deux rôles sont mélangés.

## Ce qu'on fait

### 1. Nettoyage
- Suppression de « Paroles » et « Partition » (panneaux et code associé : instruments, portée générée).
- Suppression de la pastille « Micro » et de la pastille « Prompteur » de la barre : le micro et le prompteur vivent désormais dans le menu du bouton coeur.
- Le bouton coeur devient l'unique entrée d'actions : J'aime ce passage · **Micro (ouvrir/fermer l'antenne)** · Prompteur · Programmation · Autour de moi (distance) · Langue d'antenne · Voir la carte diffusée.

### 2. Un champ de saisie, comme sur Carte réseau
Sous le titre en cours, une seule ligne : **champ de texte + bouton coeur rond + envoyer**.
On y écrit en langage normal, Aime interprète et agit :

- « passe quelque chose de doux ce soir » → filtre la grille et lance l'écoute
- « programme un message pour Julie samedi 20h » → crée l'entrée MusicBox correspondante
- « radio autour de moi à 10 km » → règle géo + distance
- « je veux parler en direct » → ouvre le micro
- « lis ce texte en anglais » → prompteur + traduction

Les intentions non comprises reçoivent une réponse d'Aime avec deux propositions cliquables, jamais un échec sec.

### 3. Rôle clarifié
La barre affiche deux états lisibles :
- **J'écoute** : ce qui passe, ce qui suit, autour de moi.
- **Je prends l'antenne** : micro ouvert, niveau, prompteur, langue.
Un seul basculement entre les deux, plus de pastilles concurrentes.

## Détails techniques

- `src/components/aime/RadioBar.tsx` : retrait du type `Tool` `paroles`/`partition`, des constantes `INSTRUMENTS`, `staffNotes`, du calcul `lyrics`/`activeLine` et des deux panneaux. Le prompteur et la programmation restent, ouverts depuis le menu coeur.
- Nouveau `RadioComposer` intégré à `RadioBar` : champ + `IntentionHeart` (réutilisé, `size="sm"`, `side="top"`) pour import/voix/cadre, avec un menu radio-spécifique (micro, distance, langue, programmation).
- Nouveau server fn `src/lib/aime/radioIntent.functions.ts` : Gemini via l'AI Gateway, sortie JSON typée `{ action, params, reply }` avec actions `play | filter | schedule | geo | mic | prompter | translate | none`, validée par Zod côté serveur.
- Exécution côté client dans `RadioBar` : `schedule` insère dans `musicbox_entries` (mêmes champs que `MusicBox.tsx`), `geo` appelle `requestGeo`/`setRadiusKm` du `RadioProvider`, `mic` bascule `live`, `translate` réutilise `translateText`.
- `RadioProvider` : exposition de `setCoords`/filtre d'ambiance pour permettre le réglage par la saisie ; aucune modification de schéma de base.
- Réglage distance et langue déplacés dans le menu coeur ; le pied de barre ne garde qu'une phrase d'état (« Autour de vous · 25 km »).
