# Le verso des 12 mondes devient un réglage vivant

Aujourd'hui, chaque entrée du verso d'une carte des 12 mondes (accueil) est un lien vers `/registre`, qui redirige vers `/monde`. Ce n'est plus le bon geste : cliquer sur « Mariage » ou « DJ » devrait ouvrir une exploration, pas déplacer la personne ailleurs.

Nouveau principe : **le clic reste sur place**. Il enrichit le verso au lieu de quitter l'accueil.

## Ce que devient le verso

1. **Le clic ne redirige plus.** Il sélectionne l'entrée (surbrillance) et déplie, sous la liste, une zone vivante.
2. **Vignettes rondes.** 3 à 6 visages/lieux réellement liés à l'entrée (photo de carte, ronde, petit nom). Cliquer une vignette ouvre la vraie carte en superposition, toujours sans quitter l'accueil.
3. **Une micro-question à la fois**, tirée d'un jeu propre à chaque monde :
   - cases à cocher (« Plutôt intime · Plutôt grande fête · Je ne sais pas encore »),
   - curseur (« Ambiance : discrète ←→ éclatante »),
   - molette de saison, de distance, de budget approximatif,
   - et toujours une porte de sortie : « Surprends-moi ».
4. **Aucune réponse obligatoire.** Rien n'est bloquant, rien n'est un formulaire. On peut cliquer dix entrées sans répondre à une seule question.
5. **Un seul bouton de sortie**, en bas : « Voir ce que ça donne » → résultats filtrés (univers + sous-univers + réglages) sur le Réseau.

## La mémoire d'exploration

Chaque clic, chaque réponse, chaque « surprends-moi » est enregistré comme un **signal** : monde, entrée, type de geste, valeur, moment. Anonyme tant que la personne n'est pas connectée (identifiant local), rattaché à son compte à la connexion.

Ces signaux servent à :
- réordonner les entrées et les vignettes à la visite suivante,
- pré-remplir l'intention quand la personne écrit dans le champ du hero,
- nourrir le récit d'Aime (« tu regardes souvent les lieux en extérieur »).

Une ligne claire, visible dans le panneau ME : ce que le site retient, et un bouton pour tout effacer.

## La philosophie, tenue jusqu'au bout

« Il n'y a pas de hasard, que de beaux rendez-vous. » Concrètement, cela veut dire :
- aucun critère n'est obligatoire, aucune combinaison ne renvoie « 0 résultat » ;
- si le réglage est trop étroit, on élargit et on le dit : « Personne exactement là, mais voici trois rencontres à côté » ;
- une part d'inattendu assumée dans chaque série de vignettes ;
- des questions ouvertes plutôt que des filtres fermés — on propose même l'inconnu.

## Détails techniques

- Nouvelle table `exploration_signals` (user_id nullable, anon_id, univers, sous-univers, type `clic|choix|curseur|surprise`, valeur jsonb, date) avec GRANT + RLS : insertion libre, lecture réservée à son propre identifiant.
- Nouveau `src/lib/aime/taxonomy.ts` : pour chacun des 12 mondes, le jeu de questions (type, libellés, valeurs) — données pures, pas de migration.
- `UniverseVideoGrid.tsx` : les `<Link>` du verso deviennent des boutons d'état ; ajout de la zone vignettes + question + bouton final.
- Nouveau `ExplorationPanel.tsx` (vignettes rondes, question, « Surprends-moi »), alimenté par une requête cartes filtrée sur univers/sous-univers.
- Réutilisation de `CardOverlay` pour ouvrir la vraie carte depuis une vignette.
- Le lien final pointe vers `/reseau` avec les réglages en paramètres de recherche (fin de la redirection `/registre` pour ce parcours).
- Panneau ME : section « Ce que j'ai exploré » + effacement.

## Avant une vraie mise en ligne — l'essentiel qui reste

1. **Parcours connecté testé de bout en bout** (inscription → carte → devis → Bureau) : encore ouvert dans la feuille de route.
2. **Pages légales et cookies** cohérentes avec la mémoire d'exploration (à mentionner explicitement).
3. **Crédits et paiements** : vérifier le mode réel vs test, et le message affiché.
4. **E-mails** : confirmation d'inscription, code de revendication, notification de devis — tester les envois réels.
5. **Données de démonstration clairement étiquetées** pour qu'un visiteur ne prenne pas une carte démo pour un vrai prestataire.
6. **Performance mobile de l'accueil** (films du bisou + 12 vidéos) : vérifier le poids sur un vrai téléphone.
7. **Modération** : un bouton « signaler » sur les cartes et les contributions.

## Le paragraphe de bienvenue de la page Bêta

À placer tout en haut de `/beta`, avant les étapes, dans un encadré :

> **Bienvenue — lisez ceci avant tout.**
> AIME est une bêta. Autrement dit : un site vivant, en train d'être construit sous vos yeux. Des choses vont marcher, d'autres non, certaines vont changer d'un jour à l'autre, et quelques-unes vont disparaître le temps d'être refaites. C'est normal, c'est même le but.
> Ici, rien n'est définitif : les cartes, les projets, les documents et les fréquences de la bêta peuvent être remis à zéro sans préavis. Ne déposez rien d'irremplaçable, ne comptez pas sur AIME pour un événement réel tant que nous n'avons pas annoncé l'ouverture officielle.
> Nous ne promettons aucun délai, aucune assistance immédiate, aucune correction garantie. Une seule personne construit tout cela, et elle avance. Ce que nous promettons, en revanche : chaque retour est lu.
> Alors si quelque chose vous agace, ne le gardez pas — écrivez-le ici, dans le formulaire en bas de page. C'est la seule bonne façon de se plaindre, et c'est la plus utile.
> Enfin, si vous avez une question, commencez par relire ce paragraphe : il répond déjà à la plupart d'entre elles. Merci d'être là si tôt — vous voyez le réseau avant tout le monde.

Le formulaire de retour est mis en avant juste après, et une ligne rappelle : « Une question ? Relisez le paragraphe de Bienvenue. »
