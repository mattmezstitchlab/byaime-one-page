# Des commandes plus discrètes, sans perdre les fonctions

## Ce que j’ai compris

La barre placée sous la ligne de temps de la page publique fonctionne parce qu’elle réunit les commandes liées au contenu dans une seule zone : le visuel respire, les actions restent accessibles, et la lecture devient plus évidente sur téléphone.

Ce principe ne doit pas être copié partout mécaniquement. Il convient surtout aux écrans où plusieurs boutons flottent, se répètent ou prennent la place du contenu.

## 1. Corriger le clic des cercles chiffrés sur la carte

Le comportement actuel est différent selon l’appareil :

- à la souris, le clic lance bien le zoom ;
- sur écran tactile, le toucher ouvre d’abord la liste d’aperçu puis neutralise le clic de zoom qui suit.

La correction sera sans ambiguïté :

- **clic ou toucher sur un cercle chiffré = zoom immédiat en profondeur vers les repères contenus** ;
- **survol à la souris uniquement = petit aperçu**, sans bloquer le zoom ;
- les petites fiches cliquables restent disponibles pour les repères individuels ;
- si plusieurs personnes ont exactement le même emplacement, le zoom s’approche suffisamment pour les révéler sans ouvrir automatiquement une liste.

## 2. Simplifier en priorité la carte du réseau

C’est l’autre écran où le principe de barre compacte apportera le plus : la recherche, la localisation, le cœur, les filtres, les critères actifs et le panneau « À l’écran » occupent actuellement plusieurs niveaux au-dessus de la carte.

Sur téléphone :

- conserver la recherche comme élément principal ;
- réunir **Autour de moi**, **Intention** et **Filtres** dans une petite barre d’icônes cohérente ;
- afficher le nombre de filtres en pastille plutôt qu’en texte long ;
- garder « À l’écran » replié par défaut sous forme de petite commande basse, puis ouvrir la liste seulement à la demande ;
- laisser les critères actifs sur une ligne horizontale compacte et défilable, au lieu de faire grandir le bloc sur plusieurs lignes.

La carte reste ainsi la surface principale, et non l’arrière-plan de plusieurs panneaux.

## 3. Harmoniser les panneaux Échanges et Documents

Leur structure est déjà proche du bon modèle. Les améliorations utiles sont ciblées :

- intégrer **Discussions / Documents** dans une barre compacte fixe en haut du panneau ;
- dans une conversation, garder sur la même ligne la flèche retour, le nom, la visio et l’aide AIME ;
- lorsque l’aide AIME est ouverte, remplacer l’empilement de boutons par un sélecteur compact pour **Me souffler / Écrire / Résumer**, puis placer le ton et la veille dans un menu secondaire ;
- dans Documents, réunir l’ajout et la navigation du dossier dans l’en-tête compact de la visionneuse.

Le champ d’écriture reste fixé en bas et ne change pas de fonctionnement.

## 4. Alléger « Mon espace » sans le transformer en tableau de boutons

Deux endroits sont concernés :

- dans « À faire », conserver une action principale visible et ranger la confirmation dans une petite barre locale **Confirmer / Annuler** ;
- sur « Ma page publique », remplacer les deux boutons texte **Modifier / Voir** par deux icônes côte à côte avec libellés accessibles.

Les réglages, les crédits et la déconnexion restent des lignes de menu : les convertir en barre compacte les rendrait moins compréhensibles.

## 5. Simplifier les actions répétées dans les projets

Deux barres sont réellement concernées, sans changer la structure des pages projet :

- dans les invitations, remplacer les cinq commandes visibles par un état compact et un menu d’actions pour copier ou supprimer ;
- lors d’une sélection de personnes, tenir **nombre choisi · destination · ajouter/annuler** sur une seule barre stable au lieu de laisser les boutons passer sur plusieurs lignes.

La ligne de temps projet, le moteur PLAY et le contenu du projet restent inchangés.

## 6. Corriger deux entrées publiques trop chargées

Sur les pages d’invitation et de demande de profil :

- garder une action principale clairement visible ;
- ranger les choix secondaires derrière une commande discrète ou dans une rangée horizontale ;
- empêcher les séries de boutons de former trois ou quatre lignes avant le contenu principal.

## 7. Ne pas appliquer ce système là où il n’apporte rien

Après lecture des écrans actuels :

- **Le fil** : les deux choix et les commandes de publication tiennent déjà correctement ; pas de refonte globale.
- **Grille Médias** : les actions sont liées à chaque vignette et déjà rangées dans un menu ; pas de nouvelle barre permanente.
- **Édition de la page** : les boutons servent des champs différents ; les regrouper éloignerait l’action de son contenu.
- **Démo mariage et ligne de temps des projets** : inchangées dans ce chantier.
- Routes `/bureau` et fonctions `SECURITY DEFINER` : strictement inchangées.

## Vérifications

- Essai tactile du cercle chiffré : aucun aperçu ne doit s’ouvrir avant le zoom.
- Essai souris : le survol peut montrer l’aperçu, le clic zoome toujours.
- Vérification sur téléphone étroit : carte visible, aucune commande coupée ou superposée.
- Vérification clavier et lecteur d’écran : chaque icône conserve un nom explicite.
- Contrôle des panneaux Échanges, Documents et Mon espace ouverts depuis l’en-tête.
- Contrôle des invitations, de la sélection multiple et des deux entrées publiques sur téléphone.
