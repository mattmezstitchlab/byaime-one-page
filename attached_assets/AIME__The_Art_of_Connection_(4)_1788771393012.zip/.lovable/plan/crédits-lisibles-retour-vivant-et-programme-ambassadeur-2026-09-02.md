# Crédits lisibles, retour vivant et programme Ambassadeur

## Ce qui est vrai aujourd'hui (vérifié)

- Le compteur de crédits existe (enveloppe mensuelle de 120 + versements) et s'affiche dans le panneau AI et sur `/credits`.
- **Aucune fonction du site ne débite réellement de crédits** : le journal `ai_usage` est seulement lu, jamais écrit. Le compteur reste donc figé quoi que fasse l'utilisateur.
- Une seule fonction est déjà conditionnée : la génération de la photo/vidéo de profil, réservée aux membres ayant pris leur case dans Le Monde AIME (1 €).
- Le bouton « Un retour » ouvre un formulaire simple qui écrit dans la table des retours bêta ; il n'y a ni conversation, ni aide entre membres.

## Ce que je conseille (pour éviter les mauvaises surprises)

Ne pas facturer maintenant. Deux étiquettes grises, honnêtes, et un débit réel **journalisé mais non bloquant** pendant la bêta :

- `up` — fonction qui consomme de l'IA, gratuite pendant la bêta, comptée dans le journal.
- `pro` — fonction déjà conditionnée à une contrepartie réelle (case du Monde AIME, paiement).
- Rien du tout sur les fonctions gratuites : pas d'étiquette décorative.

Règle d'or : une étiquette ne s'affiche que là où le mécanisme existe vraiment. Si une fonction échoue, le message renvoie vers le retour bêta plutôt que vers un message d'erreur sec.

## Inventaire des fonctions à étiqueter

| Fonction | Étiquette | Coût prévu |
|---|---|---|
| Composer / rencontres (correspondances IA) | up | 4 |
| Feuille de route depuis le champ d'accueil | up | 3 |
| Analyse d'un document au Bureau | up | 3 |
| Traduction automatique des messages | up | 1 |
| Réponses déléguées à Aime dans une discussion | up | 2 |
| Lecture de fréquence / annonces Radio | up | 2 |
| Enrichissement d'une carte (qualification) | up | 3 |
| Rapport IA de « Ma carte » | up | 2 |
| Météo / effets causaux d'un projet | up | 2 |
| Cockpit intermittent | up | 2 |
| Génération d'image de profil | pro | case Monde AIME |
| Animation vidéo du portrait | pro | case Monde AIME |

## Le retour devient une conversation

Le bouton « Un retour » ouvre un fil avec Aime au lieu d'un formulaire :

1. L'utilisateur décrit le blocage ; Aime répond, propose une solution connue si elle existe (contournement, page concernée).
2. Si rien ne débloque, le fil est enregistré comme retour bêta, avec la page, l'heure et le résumé de la conversation.
3. Aime propose alors une mise en relation humaine.

## Assistance humaine entre membres

Sous la conversation apparaissent des vignettes rondes de membres **en ligne, à proximité, ayant coché l'accord d'aide**, en priorité ceux qui ont déjà rencontré le même obstacle. Un clic ouvre une discussion d'entraide.

L'accord se donne à la création de la carte : « Accepter et découvrir le programme Ambassadeur ».

## Page Programme Ambassadeur

Une page de missions bénévoles (technique, éditorial, commercial, accueil, terrain). Pour chaque mission : ce qu'il y a à faire, le temps estimé, ce que ça apporte. L'utilisateur déclare son intention ; Aime enregistre chaque intention et chaque mission accomplie et fait évoluer une **valeur de compétence propre au site** (accueil, diagnostic, réseau, musique, administration…), visible sur la carte du membre. Pas de rémunération : c'est explicite en tête de page.

Oui, tout cela est faisable avec l'architecture actuelle.

## Cockpit admin — voir la bêta en direct

Une page `/cockpit`, visible seulement pour vous (rôle `admin`), qui montre en direct :

- les premières visites et premières utilisations (un signal est écrit à l'arrivée, à la création de carte, à chaque fonction `up`/`pro`) ;
- les erreurs et blocages réels remontés par le site (erreur d'exécution, appel IA en échec, action refusée), avec la page, l'heure, le parcours suivi et le compte concerné ;
- les retours bêta et les conversations d'aide en cours.

À côté de chaque erreur, un bouton **« Corriger l'erreur »**, visible de vous seul. Ce qu'il fait honnêtement : il marque l'erreur *en cours de correction*, rassemble le contexte technique complet (message, trace, page, actions précédentes) dans un rapport prêt à me transmettre, et prévient l'utilisateur. Il ne peut pas écrire le code tout seul — c'est vous qui me passez le rapport en un clic, et je corrige. Quand vous marquez l'erreur résolue, l'utilisateur le voit.

Côté utilisateur : dès qu'une erreur le concernant passe en « en cours de correction », une petite pastille animée apparaît au centre du header — « On répare ça » — puis « C'est réparé » quelques secondes avant de disparaître. Aucun autre visiteur ne la voit.

Sur le système nerveux, les erreurs réelles se posent sur les nœuds concernés : un point rouge et le nombre d'incidents des 7 derniers jours, et pour vous seul le même bouton « Corriger ». Pour les autres visiteurs, rien ne change.

## Détails techniques

- `src/lib/aime/credits.ts` : ajouter le catalogue `FEATURE_COSTS` (clé, libellé, étiquette, coût) et `logUsage()` qui écrit dans `ai_usage` après un appel IA réussi. Non bloquant en bêta : jamais de refus, seulement un journal et une alerte douce à zéro.
- Nouveau composant `CreditTag` (`up`/`pro`, gris, discret) posé à côté des déclencheurs listés ci-dessus.
- Appeler `logUsage()` dans les `*.functions.ts` concernés côté client, après succès.
- `FeedbackSheet.tsx` : mode conversation (fil local + serveur fn Aime), écriture du retour en fin de fil, puis vignettes d'entraide.
- Migration : `ambassadors` (accord d'aide, présence, compétences), `ambassador_missions` (catalogue), `mission_intents` (intentions et validations) ; GRANT + RLS propriétaire, lecture publique limitée aux ambassadeurs en ligne ayant consenti.
- Nouvelle route `/ambassadeur` ; case d'accord ajoutée dans `ma-carte.tsx`.
- Mettre à jour `/beta`, `/comment-ca-marche` (chapitre crédits) et le système nerveux.
- Cockpit : migration `site_events` (visite, première utilisation, fonction, erreur, blocage ; `user_id` nullable, `anon_id`, `route`, `node` du système nerveux, `payload` jsonb, `status`, `fix_note`). Insertion autorisée à tous (append-only), lecture/mise à jour réservées à `has_role(auth.uid(),'admin')` ; l'utilisateur peut lire uniquement les lignes qui le concernent (pour la pastille). GRANT + RLS dans la même migration.
- Capture : brancher l'écriture d'erreur sur le gestionnaire existant (`src/lib/error-capture.ts`, frontières d'erreur des routes) et sur les échecs des `*.functions.ts`.
- Nouvelle route `/cockpit` (liste temps réel via Realtime, filtres, bouton « Corriger » → statut + rapport copiable) ; badge header alimenté par un abonnement Realtime filtré sur l'utilisateur.
- `plan-du-site.tsx` / `systemMap.ts` : agrégat d'incidents par nœud, actions admin uniquement.
