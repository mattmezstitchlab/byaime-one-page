# Étape 1 : empiler les sections sous le héros de la page utilisateur

Premier pas vers la page unique. **Le héros actuel — carrousel, timeline et son cœur — ne bouge pas.** On ajoute uniquement des sections en dessous.

## Ce qu'on voit

Sur la page d'une personne (`/carte/...`), en descendant :

```text
1. HÉRO           carrousel + timeline + cœur actuel      (inchangé)
2. LE MONDE AIME  la grille des personnes, telle qu'elle est sur /reseau
3. LES UNIVERS    la bande de cartes univers, telle qu'elle est sur l'accueil
4. LE POINT ZÉRO  la vidéo du héros d'accueil, un seul bouton cœur au centre
5. LE BUREAU      documents, dossiers, tri — remis au propre
```

La grille garde tout son comportement actuel : recherche, niveaux ville/région/pays/monde, zoom, filtres, et le panneau qui s'ouvre au clic sur une case. La bande univers garde ses vidéos et ses sous-univers.

Chaque section reçoit un titre discret et un ancrage, pour pouvoir y renvoyer plus tard depuis le sommaire de la page unique.

## 4. Le point zéro

Une nouvelle section, distincte du héros du haut : la vidéo plein cadre de l'accueil, sans texte ni champ par-dessus, avec **un second cœur, au centre de la vidéo**. Au clic, un menu d'import s'ouvre :

- un document (PDF, Word, tableur)
- une copie d'écran ou une photo
- un visuel
- une vidéo
- ou simplement du texte collé

Ce qu'on dépose est lu, reconnu, trié et classé — la fonction du Bureau, remontée ici. Le résultat s'annonce en clair (« j'ai compris une facture de 340 € du 12 mars ») et attend une validation avant d'aller se poser : au Bureau juste en dessous, sur la timeline, ou dans un dossier.

## 5. Le Bureau, remis au propre

Sous la vidéo, le Bureau devient une section lisible plutôt qu'une page dense :

- une ligne d'état en haut : ce qui est à vérifier, les totaux, le dernier export
- les dossiers en cartes, chacun avec son montant et son nombre de pièces
- les documents en liste simple, filtrable (à vérifier, factures, devis, justificatifs, recettes, dépenses)
- ce qui manque (montant, date, type, dossier) rassemblé dans un seul bloc « à compléter »

Même contenu et mêmes données qu'aujourd'hui, présentation resserrée et cohérente avec le reste de la page.

## Ce qui ne change pas

Le reste de la page utilisateur (bulle de réponse, contenu du cœur, panneaux) reste à sa place. Les pages `/reseau`, l'accueil et `/bureau` continuent de fonctionner : on réutilise les mêmes blocs, on ne les démonte pas encore.

## Détails techniques

Dans `src/routes/carte.$id.tsx`, après le bloc héros/timeline, monter dans l'ordre, chacun dans une `<section id="...">` :

1. `<WorldGridSection />` — autonome, aucune prop.
2. `<UniverseVideoGrid />` — autonome, aucune prop.
3. `ZeroPoint` (nouveau, `src/components/aime/heart/ZeroPoint.tsx`) : la vidéo `@/assets/aime-wedding.mp4.asset.json` en boucle muette (même source que `IntentionHero`), `HeartMenu` centré en absolu, actions d'import branchées sur un `<input type="file">` multi-format + collage, puis le flux d'analyse existant du Bureau (`src/lib/bureau/*` — ingestion, reconnaissance de type, extraction). Chaque résultat devient une `AgentNote` confirmable dans `HeartMenu`.
4. `BureauSection` (nouveau, `src/components/aime/bureau/BureauSection.tsx`) : le corps de `src/routes/bureau.index.tsx` extrait en composant réutilisable (mêmes requêtes `foldersQuery`/`documentsQuery`/`linksQuery`/`bureauContextQuery`, mêmes calculs `accountingSummary`/`folderTotals`/`suggestLinks`), mise en page refaite. La route `/bureau` rend ensuite ce composant, pour éviter deux implémentations.

Aucun changement de schéma ni de règles d'accès. `reseau.tsx` et `index.tsx` sont inchangés.

## Suite (non incluse ici)

Sélection de cases → cercles / projets, section Projet qui glisse, la map en section, redirections des anciennes pages.
