# Accueil — hero nettoyé et mur des 11 univers

## Ce que j'ai compris

1. **Hero** : plus de dégradé/voile blanc en bas de la vidéo. Le texte « Le réseau des bonnes rencontres », le grand titre et le champ de saisie descendent (le hero vidéo reste pur, en fond).
2. **Bloc sous le hero** : texte centré (eyebrow, titre, sous-titre), et un seul bouton « Créer ma carte » à la place de « Découvrir les cartes » / « Parcourir le registre ».
3. **Section « Univers vivants »** : grand titre centré, puis une grille de **11 cartes vidéo**, une par univers (Mariage, Concert, Entreprise, Anniversaire, Événement, Culture, Association, Voyage, Rencontre, Naissance, Cérémonie). Chaque carte : vidéo en boucle muette, titre de l'univers en surimpression, bouton flèche qui ouvre `/registre?universe=<slug>` filtré.
   - La vidéo existante de l'entremetteuse est conservée et porte le titre « Événement ».
   - Les 10 autres univers reçoivent une vidéo générée en IA (8 s, boucle, sans son).
4. **Suppression** des cartes prestataires de l'accueil (doublon du registre) et de l'ancienne liste de pastilles d'univers.

## Rendu

```text
[ vidéo manège plein cadre + champ de saisie (aucun dégradé) ]

        Le réseau des bonnes rencontres
        Tout ce qui existe peut devenir une carte…
              [ Créer ma carte ]

               Univers vivants
   [vidéo Mariage →] [vidéo Concert →] [vidéo Entreprise →]
   [vidéo Anniversaire →] [vidéo Événement →] …  (11 au total)
```

## Détails techniques

- `src/components/aime/IntentionHero.tsx` : suppression du `bg-gradient-to-b … to-background`, hero limité à la vidéo + champ compact ; le bloc éditorial passe dans `index.tsx` sous le hero.
- `src/routes/index.tsx` : bloc central `text-center`, CTA unique vers `/ma-carte`, suppression de la section « featured cards » et des anciennes pastilles d'univers.
- Nouveau composant `UniverseVideoGrid` : grille responsive (1 / 2 / 3 colonnes), `rounded-4xl`, ratio 4:5, `<video autoplay muted loop playsinline preload="metadata">`, overlay dégradé bas + titre + bouton flèche `Link to="/registre" search={{ universe: slug }}`.
- Génération de 10 vidéos (`videogen--generate_video`, 1080p, 5 s, 4:3 ou 3:4) enregistrées dans `src/assets/univers-<slug>.mp4`, dans l'esprit ivoire/chaleureux du site ; mapping slug → asset dans un petit module `src/lib/aime/universeMedia.ts`. `evenement` réutilise `aime-face.mp4`.
- Performance : `preload="metadata"`, lecture déclenchée quand la carte entre dans le viewport (IntersectionObserver) pour éviter 11 vidéos simultanées.
- Aucun changement de logique métier ni de base de données.
