# Mon espace, accueil allégé, nouveau discours

## 1. Le bouton « Mon espace » ouvre vraiment votre page

Aujourd'hui l'en-tête envoie vers `/carte/$id` seulement si une carte existe ; sinon il retombe sur `/ma-carte`, l'écran de création. Résultat : on retombe sans cesse sur « créer ».

Changement :
- Connecté avec une page → ouvre directement `/carte/$id`.
- Connecté sans page → crée la page en un geste (nom du compte comme titre, brouillon non publié) puis atterrit sur `/carte/$id`, en mode édition. Plus d'écran intermédiaire.
- Non connecté → `/auth` comme aujourd'hui.
- Même logique pour l'entrée « Ma page » de la barre latérale et de la barre mobile.

`/ma-carte` reste accessible (footer, liens existants) comme éditeur détaillé, mais n'est plus la destination par défaut.

## 2. Accueil : retirer la section « Comment ça marche »

Suppression du bloc titre + carrousel de chapitres + bouton « Voir plus » sur la page d'accueil. La page `/comment-ca-marche` reste en ligne, atteignable depuis le pied de page, à remettre à jour plus tard.

## 3. Les 12 mondes restent

Aucun changement : la grille vidéo des univers reste sur l'accueil, elle sert à parcourir en profondeur et à tomber sur des personnes par domaine.

## 4. Nouveau texte sous le hero (bloc timeline)

Remplacement de « Une carte qui se souvient et qui se projette / Réalisations passées, moments à venir, disponibilités… » par un discours qui explique la page et sa ligne de temps comme le vrai différenciant :

- Titre : « Votre page, et une seule ligne de temps »
- Sous-titre : votre page réunit ce que vous faites, ce que vous avez fait et ce que vous préparez — passé, présent, futur sur une même ligne. Pas un profil figé d'un côté et un fil d'actualité de l'autre : un écosystème où le professionnel et le personnel se répondent, où chaque moment reste accessible et continue de vivre.
- Une ligne d'appui sous la timeline : survolez un moment pour voir la carte, cliquez pour ouvrir la page derrière.

Ton : pas de nom de concurrent dans le texte affiché ; l'idée « LinkedIn + Facebook en écosystème » est traduite en langage AIME.

## Détails techniques

- `src/components/aime/AppShell.tsx` : bouton « Mon espace » et entrée « Ma page » passent par un handler unique de résolution de page (hook `useMyPageLink` / création à la volée via l'insert `cards` déjà utilisé par `/ma-carte`).
- `src/lib/aime/navigation.ts` + `MobileBottomBar` : « Ma page » utilise la même résolution.
- `src/routes/index.tsx` : suppression de la section chapitres (et de l'import `ChapterCarousel` devenu inutile) ; réécriture des textes du bloc timeline.
- Aucune migration, aucune règle de sécurité modifiée.
