# Finition AIME — audit et plan d'exécution

Aucun nouveau moteur, aucune nouvelle table sauf mention explicite. Tout s'appuie sur ce qui existe déjà.

## Ce que l'audit montre

- **Ligne de temps** : l'édition existe mais est partielle. Le panneau d'un moment (`TimelineBubbleExtra`) ne permet aujourd'hui que titre, date/heure et note, plus quelques ajouts (pièce jointe, personnes). Les autres informations réellement stockées — fin, durée, statut, échéance, priorité, public/privé, univers, lieu, budget, médias, relations, phase — existent en base mais ne sont pas modifiables.
- **Biographie** : le texte saisi dans « Modifier ma page » est bien enregistré, et la page publique l'affiche déjà… mais seulement dans un onglet « Présentation », en repli sur l'accroche, sans mise en forme. Ce n'est donc pas un problème de stockage, mais de présentation.
- **Médias — liens web** : un lien est reconnu comme « lien » mais reste une case grise avec une icône. Aucun titre, aucun domaine, aucune image. La table des médias possède déjà un titre et une vignette : rien à créer.
- **Médias — PDF** : aucun traitement. Un PDF tombe dans « lien ». Une visionneuse de documents existe déjà ailleurs (l'espace Documents) et sera réutilisée.
- **Accueil** : le champ libre et le système de questions coexistent sans se parler visuellement. Le moteur de compréhension du récit, les questions et les réponses existent déjà et seront simplement reliés.
- **Sources** : le catalogue existe et fonctionne réellement pour « document » et « lien ». Les six autres (Agenda, Gmail, Drive, Instagram, LinkedIn, Facebook) ne font que « collez le lien » : c'est honnête mais pas une vraie connexion. Aucune ne peut être branchée sans une inscription développeur externe.
- **« Modifier ma page »** : les champs de la partie basse s'enregistrent correctement. La partie haute (mise en page, visuel) doit être passée au crible : c'est là que se trouvent les contrôles suspects.
- **Calendrier** : la Radio est un des cinq boutons du dos du calendrier. Le retournement affiche toujours la même console.
- **LAB** : les facettes Temps, Critique et Relations sont en place. Il n'y a pas encore de lecture d'ensemble.

## Plan, groupe par groupe

**A — Ligne de temps entièrement modifiable**
Ouvrir à l'édition tout ce qui est réellement stocké sur un moment : titre, description, début, fin/durée, échéance, statut, priorité, phase (avant/pendant/après), univers, visibilité, personnes, lieu, budget, médias, relations. Un seul formulaire, écrivant dans la vraie source. Glisser-déposer, ordre, contraintes et affichage mobile inchangés.
Fichiers : `src/components/aime/TimelineBubbleExtra.tsx`, `src/lib/aime/timelineActions.ts`, `src/components/aime/HeroTimeline.tsx` (lecture seule des nouveaux champs).

**B — Biographie publique**
Donner à la présentation une vraie place éditoriale en haut de la page publique, masquée si vide, sans doublon avec l'onglet actuel.
Fichiers : `src/routes/carte.$id.tsx`, `src/components/aime/CardIdentity.tsx`.

**C — Liens web et PDF dans les médias**
Reconnaître un lien : afficher le domaine, le titre quand il est disponible, et une image de prévisualisation quand le site en fournit une. Là où le site l'interdit techniquement, afficher une carte propre au lieu d'une capture inventée. Ajouter le choix du cadrage de la vignette obtenue. Reconnaître les PDF : vignette, nom, ouverture et aperçu dans la visionneuse existante.
Fichiers : `src/lib/aime/mediaKind.ts`, `src/lib/aime/media.ts`, `src/components/aime/media/MediaTile.tsx`, `MediaViewer.tsx`, `AddMediaDialog.tsx`, réutilisation de `src/components/aime/messages/DocViewer.tsx`, plus une petite fonction serveur de lecture d'aperçu réutilisant le service de lecture web déjà configuré.

**D — Champ d'accueil et sources**
Fondre le champ libre dans le parcours de questions : ce que la personne raconte remplit les réponses déjà connues, sans écraser ce qu'elle a répondu, et les questions restantes restent visibles. Le bouton Source devient un simple « + » au début du champ. Rapport écrit et précis sur chaque connecteur : ce qui manque exactement pour le rendre réel. Les connecteurs non branchés seront marqués clairement plutôt que laissés ambigus.
Fichiers : `src/components/aime/home/HeroBar.tsx`, `src/lib/aime/world/journey.ts`, `questions.ts`, `parseStory.ts`, `storyIntent.ts`, `src/components/aime/sources/SourceMenu.tsx`, `src/lib/aime/sources/catalog.ts`.

**E — Audit de « Modifier ma page »**
Passer chaque bouton, menu et choix en revue : action réelle, bonne donnée, état visible, persistance après rechargement. Ce qui n'est pas implémenté est retiré.
Fichiers : `src/components/aime/page/EditPageSheet.tsx`, `src/components/aime/PageSetup.tsx`.

**F — Calendrier**
Retirer la Radio du dos du calendrier (le système Radio reste intact ailleurs). Le retournement devient un choix de représentation : jour, moments, événements, personnes — uniquement les vues réellement alimentées.
Fichiers : `src/components/aime/DayConsole.tsx`, `src/components/aime/CalendarFlip.tsx`.

**G — Bibliothèque de médias par Univers / Domaine**
Une bibliothèque d'images cohérentes, classée par univers et domaine, en réutilisant les visuels internes déjà présents dans le projet et la taxonomie existante des 12 univers / 73 domaines. Aperçu, sélection, ajout à la page, remplacement, suppression — via le système média actuel.
Fichiers : `src/lib/aime/visuals.ts`, `universeMedia.ts`, `domains.ts`, nouvelle vue de sélection dans `src/components/aime/media/`, branchée dans « Modifier ma page ».

**H — LAB, étape 5 : « Est-ce que ça tient la route ? »**
Une lecture d'ensemble dérivée des facettes déjà là — solide, manquant, fragile, contradictoire — avec le pourquoi et ce qui améliorerait la confiance. Pas de note magique, pas de nouvel agent, pas d'écriture automatique dans le modèle du projet.
Fichiers : `src/lib/aime/lab/agents/` (lecture d'ensemble), `src/components/aime/lab/LabAnalysis.tsx`.

## Manière de travailler

Un groupe à la fois, dans l'ordre A → H. Après chaque groupe : tests ciblés, tests globaux, vérification du code, vérification qu'aucune fonctionnalité existante n'est cassée, puis rapport avant de passer au suivant.

## Deux points à trancher

- Les six connecteurs externes ne peuvent pas être réellement branchés sans inscriptions développeur externes (Google, Meta, LinkedIn). Je documenterai précisément ce qui manque pour chacun, sans fabriquer de faux succès.
- La capture d'un site web arbitraire n'est pas possible depuis le navigateur. J'utiliserai l'aperçu que le site publie lui-même, et une carte soignée quand il n'en publie pas.
