# Rencontres — se rencontrer parce que des chemins se croisent

Une nouvelle page `/rencontres` qui ne compare pas deux photos, mais montre **où deux histoires se croisent** : hier, aujourd'hui, demain. Chaque proposition est expliquée, jamais chiffrée en pourcentage.

## A — Ce qui existe déjà (audit)

Beaucoup de la matière est en place et sera réutilisée telle quelle :

- **Identité** : les pages publiques portent déjà nom, ville, métier, univers, compétences, expériences, photos, position sur la carte, disponibilité.
- **Temps** : les moments publics d'une page, les disponibilités par jour, les projets avec leurs dates et leurs villes, les participants d'un projet.
- **Mondes** : les 12 mondes et leurs sous-mondes, avec la correspondance monde → métiers.
- **Lieux** : la carte du réseau, la position des pages, les rayons (ville, 40 km, 100 km, région, partout) et le calcul de distance.
- **Relations** : participation à un même projet, appartenance à une même équipe, suivis.
- **Échanges** : la messagerie une-à-une et la porte unique « Échanges » ; les notifications ; le blocage et le signalement, déjà opérationnels.
- **Le fil, la radio, la recherche** : existants et rattachables.

Il n'y a **aucune page Rencontres** aujourd'hui. `/reseau` est la carte du réseau (exploration et filtres), `/recherche` une recherche de texte. Aucune des deux ne fait de mise en relation.

## B — Ce qui manque

1. **Un accord à deux.** Les rencontres suggérées existantes sont une liste proposée à une seule personne ; il n'y a pas d'objet « A a fait signe, B a accepté ».
2. **Une intention de rencontre déclarée** (amitié, collaboration, projet, artistes, professionnels, amoureux…) et le fait d'être visible ou non.
3. **La position d'une personne** (et non d'une page) partageable dans ce cadre précis, révocable.
4. **Les convergences calculées et gardées**, avec leurs raisons en clair.

## C — Comment ça marche pour la personne

### 1. S'ouvrir aux rencontres
Un écran d'entrée court : intentions cochées, rayon, qui peut me contacter (tout le monde / personnes convergentes / personnes que je valide). Par défaut : visible pour les intentions **professionnelles** (collaboration, projet, métier) ; amitié et rencontre amoureuse restent éteintes tant qu'elles ne sont pas cochées. Position précise facultative, la ville suffit.

### 2. Trois modes sur la même page
- **Autour de moi** — les personnes dont le chemin peut croiser le mien, par ville puis par rayon.
- **Convergences** — l'entrée par l'intersection : même projet, même monde, même activité, même période, même lieu à venir.
- **Exploration** — la recherche volontaire : je cherche [personnes] dans [monde] qui font [activité] autour de [ma zone] pour [collaborer].

### 3. La carte des convergences
Au centre, moi. Autour, des points placés selon **le temps** : passé à gauche, présent au centre, futur à droite ; l'éloignement du centre dit la distance géographique. Un trait relie chaque point à moi, avec ses raisons. Repli automatique en liste de cartes sur téléphone, ou si moins de 4 personnes — la visualisation ne s'impose jamais.

### 4. Une carte de rencontre
Visuel, prénom, ville, activité, puis « Ce qui pourrait vous rapprocher » : deux ou trois raisons en clair. Jamais de pourcentage.

### 5. Découvrir avant de contacter
Cliquer ouvre le **récit des convergences**, pas la messagerie :

```text
4 POINTS DE CONVERGENCE
2019      un même festival
AUJOURD'HUI  une activité proche
DANS 14 J    la même région
PROJET       une intention compatible
```

Puis seulement les gestes : *Garder pour plus tard · Suivre son parcours · Dire bonjour · Proposer une rencontre · Inviter dans un projet*.

### 6. Dire bonjour, puis proposer
« Bonjour » est un signal léger (emoji, message facultatif). L'autre l'accepte ou l'ignore ; la conversation ne s'ouvre qu'après acceptation. « Proposer une rencontre » ajoute un pourquoi (café, événement, projet, collaboration, faire connaissance), un lieu et un moment — et devient une petite rencontre partagée à deux, avec sa conversation.

### 7. Après
Quand une rencontre est passée, AIME **demande** si on veut l'ajouter à sa ligne de temps. Jamais tout seul.

## D — Les convergences, et ce qu'on ne dira jamais

Calculées uniquement sur du public ou de l'explicitement partagé : monde et sous-monde communs, métier proche, compétences croisées, même projet ou même équipe, moments publics au même endroit ou à la même période, disponibilités qui se recouvrent, ville ou rayon, intentions compatibles.

Formulé en clair (« vous avez un festival en commun en 2019 », « vous serez tous les deux dans la région dans deux semaines »), jamais en trace précise (« mardi soir à cette adresse »). Les personnes bloquées, non visibles, ou hors des intentions cochées n'apparaissent pas.

## E — Découpage

**Lot 1 — Le socle** : réglages de visibilité et d'intentions, calcul des convergences, mode Autour de moi et mode Convergences, carte de rencontre, page de découverte, Dire bonjour → acceptation → conversation, blocage/signalement présents partout.

**Lot 2 — La carte des convergences** : la visualisation temporelle centrée sur moi, avec repli en liste.

**Lot 3 — Le contexte** : rencontres par événement (« 12 personnes présentes »), rencontres par besoin de projet (« recherche photographe »), proposer une rencontre avec lieu et moment, moment ajouté à la ligne de temps sur validation.

**Lot 4 — La voix** : une phrase hebdomadaire dans la radio, discrète, jamais une notification déguisée. Mode Exploration affiné.

## Détails techniques

- Nouvelles tables : `meet_prefs` (visibilité, intentions[], rayon, qui peut contacter, opt-in position), `meet_signals` (from_user, to_user, kind `bonjour|proposition|garde|suivi`, message, statut `envoyé|accepté|refusé|ignoré`, reasons[] figées), `meet_proposals` (signal_id, motif, lieu, moment, statut) — chacune avec `GRANT` explicites puis RLS restreinte aux deux parties, plus une politique de lecture publique limitée aux `meet_prefs` marquées visibles.
- Convergences calculées côté serveur dans un `createServerFn` (`src/lib/aime/meet/convergences.functions.ts`) qui lit uniquement des données publiques et renvoie `{ card, reasons[{axis: passé|présent|futur, label, weight}] }`. Pas d'appel IA au premier chargement ; l'IA (`chat.functions.ts`) sert seulement à formuler le premier message.
- Réutilisation : `cardCoords`/`RANGES`/`inRange`, `universeTree`/`tradeWorlds`, `card_availability`, `card_timeline_entries` (`is_public` uniquement), `event_participants`, `compositions`, `ensureThread`/`openMessages`, `pushNotification`, `safety.ts`.
- Extraction de `distanceKm` de `musicbox.ts` vers `geo.ts` (import mis à jour, aucun changement de comportement).
- Nouvelles vues : `src/routes/rencontres.tsx` (+ `rencontres.$id.tsx` pour la découverte), composants `ConvergenceMap`, `MeetCard`, `ConvergenceStory`, `SayHello`, `MeetProposal`, `MeetPrefs`.
- La position personnelle passe par la table de géo de profil existante, avec une politique de lecture supplémentaire strictement conditionnée à l'opt-in Rencontres ; sans opt-in, tout fonctionne à la ville.
- `head()` propre sur `/rencontres`, aucune donnée privée en SSR. `roadmap.md` complété des 4 lots.
