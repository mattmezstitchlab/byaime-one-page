# Tout faire depuis la ligne de temps

Aujourd'hui la bulle d'un moment sait montrer (média, montant, contexte), et
quelques gestes existent déjà dedans : cocher une tâche, répondre à un message,
et les actions rondes (réserver, devis, ouvrir, écrire, partager…). Tout le
reste oblige encore à descendre dans une page ou un onglet.

Voici ce qui peut basculer dans la bulle, par ordre d'utilité.

## 1. Créer et modifier un moment sur place

- Cliquer une date vide ouvre une petite fiche : titre, heure, note, nature.
- Dans la bulle : renommer, changer la date/heure, écrire une note, supprimer.
- Glisser un point pour le déplacer dans le temps (avec annulation possible).
- Dupliquer un moment (utile pour les rendez-vous répétés).

## 2. L'argent, sans quitter la ligne

- Depuis un devis : accepter, refuser, relancer, transformer en facture.
- Depuis une facture : marquer payée, programmer l'échéance, voir le reste dû.
- Créer une échéance de paiement directement sur une date.
- Toujours avec la mention : AIME prépare et suit, mais n'encaisse pas.

## 3. Les gens

- Ajouter un prestataire à un moment (recherche courte dans la bulle).
- Voir qui est rattaché, retirer quelqu'un, lui écrire, demander un devis.
- Marquer une place « à pourvoir » comme pourvue.

## 4. Les fichiers et souvenirs

- Déposer une photo, une vidéo, un document sur un moment (glisser-déposer sur
  le point ou bouton dans la bulle).
- Lire le média dans la bulle, le partager, le définir comme image du moment.

## 5. Les échanges

- Répondre existe déjà : y ajouter l'envoi d'un message à propos d'un moment
  précis (le message porte la date et le titre du moment).
- Proposer une date : la personne accepte ou propose une autre, dans la bulle.

## 6. Les décisions rapides

- Confirmer / mettre en option / libérer une disponibilité.
- Valider une suggestion de l'assistant (« il manque un photographe » →
  « chercher » ou « ignorer ») sans ouvrir de panneau.
- Rappel : « me le rappeler la veille ».

## 7. Le groupe de points (dossier)

- La bulle d'un dossier liste ses moments avec les mêmes gestes en ligne,
  et permet de déplacer tout le groupe d'un coup.

## Ce qui reste hors de la ligne de temps

L'identité de la page (photo, présentation, savoir-faire) et les réglages du
compte : ils n'ont pas de date, donc pas de place sur la ligne.

## Découpage proposé

1. **Éditer** — créer/renommer/dater/supprimer un moment, glisser pour déplacer,
   pièce jointe.
2. **Décider** — devis/facture/échéance, confirmer/libérer, valider une
   suggestion.
3. **Réunir** — personnes rattachées, proposition de date, dossier éditable.

## Détails techniques

Extraire le corps de la bulle de `HeroTimeline.tsx` (≈ lignes 882-1120) dans un
`TimelineBubble.tsx` avec un mode lecture et un mode édition, en gardant
`actionsFor` et `renderExtra`. Étendre `TimelineBubbleExtra.tsx` par nature de
repère (`devis`, `facture`, `paiement`, `document`, `disponible`, `dossier`)
avec les mutations React Query existantes (`quotes`, `event_payments`,
`bureau_documents`, `card_timeline_entries`). Glisser-déposer temporel : gestion
pointeur dans `HeroTimeline` convertissant x → temps, écriture via une mutation
`updateMarkerTime` par source. Pièces jointes : stockage existant du Bureau.
Ajouter les clés `accept`, `decline`, `remind`, `attach`, `assign` dans
`timelineActions.ts`. Pas de nouvelle page ; `/bureau` et les fonctions
`SECURITY DEFINER` restent intouchées. Migration éventuelle : colonnes de
rappel sur `card_timeline_entries` (avec GRANT + RLS calqués sur l'existant).
