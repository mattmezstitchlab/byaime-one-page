# Mon espace devient un panneau — et la page publique s'édite sur place

## L'idée, telle que je la comprends

Aujourd'hui « Mon espace » est une longue page où tout est empilé : mondes, chiffres, Aimes, éditeur de page, documents, compte. On lit beaucoup, on agit peu.

Demain, « Mon espace » n'est plus une page mais **un panneau qui s'ouvre à droite, depuis n'importe où**. Il ne contient que les grandes entrées, chacune avec :

- un **point de couleur** quand quelque chose demande une action (orange = à faire, bleu = nouveau, vert = prêt à envoyer) ;
- un ou deux **boutons d'action immédiats** qui exécutent le travail sans ouvrir d'écran intermédiaire.

Le point clé, c'est l'**enchaînement automatique**. Un point orange sur « Mariage Claire & Julien » ne dit pas « il manque un devis » puis vous laisse chercher : le bouton dit « Créer et envoyer le devis ». Un clic, et AIME fait la suite tout seul — crée le devis à partir de ce que le projet sait déjà (personne, prestation, montant, date), le range dans le dossier du projet, rédige le message, l'envoie dans la bonne conversation, pose le repère sur la ligne de temps, et affiche seulement le résultat : « Devis envoyé à Julien. » Rien à comprendre, rien à parcourir.

Chaque point de couleur est donc un **chemin déjà tracé**, pas une alerte.

## Les chemins d'un clic (première série)

| Ce qui déclenche | Le bouton | Ce que fait AIME, seul |
| --- | --- | --- |
| Prestation acceptée sans devis | Créer et envoyer le devis | devis → dossier projet → message → repère timeline |
| Devis accepté sans facture | Facturer | facture depuis le devis → dossier → message → échéance posée |
| Facture échue non payée | Relancer | message de relance dans la bonne conversation |
| Document incomplet | Compléter | montant/date déduits, fiche remplie, à confirmer d'un clic |
| Aime reçue non lue | Répondre | conversation ouverte avec un premier message proposé |
| Page publique incomplète | Compléter ma page | panneau d'édition ouvert sur le champ manquant |

Chaque action montre d'abord une phrase de confirmation en une ligne (« Envoyer le devis de 1 200 € à Julien ? ») puis s'exécute. Rien n'est envoyé sans ce oui.

## Ce que devient la page /mon-espace

La page disparaît en tant que long empilement. Son adresse reste et ouvre simplement le panneau (pour les liens déjà partagés). Le panneau contient, dans l'ordre :

1. **Mes mondes** — une ligne par projet, point de couleur, actions rapides.
2. **À faire** — la liste des chemins d'un clic, tous projets confondus.
3. **Aimes** — les nouvelles, avec « Répondre ».
4. **Ma page publique** — avancement + « Modifier ».
5. **Crédits**, **Réglages**, **Déconnexion** — trois lignes en pied.

Ce qui est **supprimé de Mon espace** : le bloc Documents (il vit déjà dans le panneau Documents de l'en-tête), l'éditeur de page complet (il part sur la page publique), les quatre tuiles-compteurs qui ne faisaient que faire défiler la page.

## La page publique : un bouton « Modifier »

En haut à droite du hero de ma propre page, un simple bouton **Modifier**. Il ouvre le panneau latéral droit d'édition, avec les réglages de la deuxième capture, revus :

- nom, titre de page, photo ;
- « Ce que vous faites » (mondes + savoir-faire) ;
- ville ;
- et, en plus, ce qui enrichit le dessous du hero et manque aujourd'hui : **présentation**, **galerie photos/vidéos**, **expériences**, **tarifs**, **disponibilités**, **coordonnées visibles ou non**, **liens** (site, réseaux).

Chaque champ s'enregistre en direct, la page derrière se met à jour en même temps. Plus d'édition dans Mon espace.

## Détails techniques

- Nouveau `src/components/aime/space/SpaceSheet.tsx` (même mécanique que `MessagesSheet` / `SettingsSheet` : `src/components/aime/spaceSheet.ts` avec `openSpace()`), monté dans `AppShell`. Le bouton « Mon espace » de l'en-tête ouvre le panneau au lieu de naviguer.
- Nouveau `src/lib/aime/space/actions.ts` : dérive les chemins depuis les données existantes (`events`, `quotes`, `bureau_documents`, `aimes`, `threads`, `cards`) et expose `runAction(action)` qui enchaîne `createDraftQuote` / `ensureQuoteFolder` / `ensureProjectFolder` / `postMessage` / `linkDocumentToMessage` / repère timeline. Aucune table nouvelle.
- `src/routes/mon-espace.tsx` réduit à une coquille qui appelle `openSpace()` et renvoie vers l'accueil.
- `PageSetup.tsx` déplacé dans un panneau `src/components/aime/page/EditPageSheet.tsx`, enrichi des champs manquants ; bouton « Modifier » ajouté dans le hero de `carte.$id.tsx` quand `isMine`.
- Routes `/bureau` et fonctions `SECURITY DEFINER` non touchées. Pas de migration.
