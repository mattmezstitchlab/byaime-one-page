# Ma Carte : une seule barre, et une entrée en douceur

## 1. Pourquoi il y a deux barres aujourd'hui

La page calcule deux fois l'avancement, avec deux règles différentes :

1. La barre collante en haut — « Carte complétée à 14 % » — repose sur 7 critères : photo, nom, accroche, quelques mots, ville, mots-clés, disponibilités. Elle liste ce qui manque.
2. Le bloc en dessous — « Votre carte est prête à 18 % » — repose sur 11 critères : les mêmes plus les univers, les sous-univers, un minimum de 3 mots-clés, les compétences, et le fait que la carte existe déjà. Il affiche l'état d'enregistrement et « Compléter plus tard ».

Les pourcentages diffèrent parce que les dénominateurs ne sont pas les mêmes. Vu de l'utilisateur, c'est une contradiction.

**Correction :** une seule mesure, affichée une seule fois, dans la barre collante du haut, qui reprend tout : pourcentage, ce qui manque, état d'enregistrement, « Compléter plus tard ». Le second bloc disparaît sans perte d'information.

## 2. Une page moins chargée : deux chemins d'entrée

Aujourd'hui la page ouvre d'un coup l'intégralité du formulaire (univers, sous-univers, présentation, ville, calendrier, organisateur, catégorie, tags, aperçu, connexions, historique). Pour quelqu'un qui n'a pas encore de carte, c'est un mur.

À la place, quand la personne n'a **pas encore** de carte, la page propose un choix clair, avec une phrase honnête : *« Le reste vous sera demandé petit à petit, à mesure que vous l'utilisez. »*

- **Création rapide avec Aime** — la personne écrit une phrase dans le champ au cœur du hero, Aime propose nom, accroche, mots, univers, sous-univers et mots-clés. Elle relit, corrige si besoin, et publie. Trois écrans : je raconte → Aime propose → je publie.
- **Création détaillée** — le formulaire complet, tel qu'il existe aujourd'hui, pour ceux qui préfèrent tout maîtriser. Un lien « Je préfère tout remplir moi-même » y mène à tout moment.

### Le pas-à-pas de la création rapide

```text
Étape 1  Racontez-vous          champ Aime + exemples
Étape 2  Ce qu'Aime a reconnu   nom, accroche, mots, univers, sous-univers, mots-clés (modifiables)
Étape 3  Votre visage           photo + ville
         → Publier ma carte
```

Chaque étape tient sur un écran, avec la barre d'avancement en haut et un bouton « Passer » : rien n'est bloquant, une carte peut être publiée incomplète.

### Après la publication : le petit à petit

Quand la carte existe, la page redevient l'éditeur complet, mais organisée en sections repliées (Identité, Univers, Présentation & ville, Disponibilités, Catégorie & mots-clés, Aperçu & connexions). Seule la section correspondant au **premier élément manquant** est ouverte, avec une invitation courte : *« Il reste vos disponibilités — c'est ce qui permet aux autres de vous proposer une date. »* Un élément manquant à la fois, jamais la liste entière.

## 3. Détails techniques

- `src/routes/ma-carte.tsx` : fusion des deux `useMemo` (`completion` l. 751 et `progress` l. 656) en un seul `{ percent, missing }` ; suppression du bloc l. 853-874, son contenu utile remontant dans l'en-tête collant.
- Nouvel état local `mode` (`quick` | `detail`) et `step` (1-3), initialisé sur `quick` quand `myCard` est nul, sur `detail` sinon ; persisté dans `localStorage` pour ne pas repartir de zéro à un rechargement.
- Le pas-à-pas réutilise l'existant : `AimeField`, la mutation `askAime`, `PixelCardLoader`, le bloc « Ce qu'Aime a reconnu » et l'aperçu de carte — aucun nouveau service ni appel IA supplémentaire.
- Éditeur complet passé en sections repliables (composant `Collapsible` déjà présent dans le design system), ouverture pilotée par le premier champ manquant.
- Aucun changement de base de données, aucune modification de sécurité.
