# Le système nerveux : canevas infini, ce qui manque, et la logique Si · Alors · Parce que

## Le problème actuel, vérifié

`src/routes/plan-du-site.tsx` rend un SVG figé en `viewBox="0 0 1480 870"` avec `min-w-[1240px]` dans un conteneur `overflow-x-auto` : sur un écran de 1275 px, six colonnes de nœuds de 208 px de large dépassent forcément à droite. On ne peut ni reculer, ni s'approcher. C'est un plan imprimé, pas un organisme.

De plus, `src/lib/aime/systemMap.ts` ne décrit **que ce qui existe** : 30 nœuds, tous « actif » ou « en cours », aucun nœud « à venir » réellement présent malgré le statut prévu. La page ne montre donc jamais ce qui manque — exactement l'inverse de ce que tu veux.

## 1. Canevas infini (zoom et déplacement)

Le plan devient une surface qu'on explore :

- molette et pincement de trackpad pour zoomer, autour du curseur (le point sous la souris ne bouge pas) ;
- glisser pour déplacer, à la souris comme au doigt ;
- boutons `−` / `+` / **Tout voir** (recadrage automatique sur l'ensemble du graphe) ;
- au chargement : recadrage automatique, donc plus rien ne dépasse, quelle que soit la taille d'écran ;
- au zoom éloigné on ne lit que les titres de systèmes ; en s'approchant apparaissent les nœuds, puis les libellés de flux — le détail se révèle en s'approchant, comme sur une carte ;
- `prefers-reduced-motion` respecté, et la vue mobile empilée conservée telle quelle.

## 2. Faire apparaître ce qui n'existe pas encore

Trois états visuels, pas deux :

```text
plein, cerclé net   ── existe et fonctionne
plein, cerclé ambre ── existe, incomplet
contour pointillé   ── n'existe pas encore  ← nouveau
```

Idem pour les liens : un flux déjà câblé est une ligne animée, un flux **à créer** est une ligne fantôme, plus pâle, sans animation. Un interrupteur en haut : **Tout · Ce qui existe · Ce qui manque**. En mode « Ce qui manque », le site actuel s'efface au second plan et il ne reste que le futur — la carte du chantier.

Les nœuds manquants seront écrits à partir de ce que le code montre déjà comme absent (page Radio autonome, bibliothèque musicale, contributions, page Fréquence publique, cockpit intermittent partiel, mémoire et sources, causalité, météo/plan B…), chacun rattaché à un système existant.

## 3. La grammaire Si · Alors · Parce que

Chaque flux porte aujourd'hui une phrase plate. Il devient une **règle lisible** :

```text
SI       une timeline est qualifiée
ALORS    une fréquence devient écoutable
PARCE QUE ce qui a bougé mérite d'être raconté
```

Au clic sur un nœud, le panneau du bas donne : ce que la page fait, ce qui y mène, ce qu'elle déclenche — et pour chaque relation les trois lignes ci-dessus. Un flux à créer affiche la même règle au futur, avec en plus **« Ce qui bloque »** et **« Comment on contourne »** : demander de l'aide, se rassembler, passer par une autre porte. C'est la promesse du site rendue visible sur son propre plan.

## 4. Les portes et les contournements

Nouveau type d'élément : la **barrière** (argent, temps, compétence, droit, accès, isolement). Une barrière se place sur un flux et porte toujours au moins un contournement : *faire soi-même*, *se faire aider*, *se rassembler*, *une autre route*. Elles ne sont pas décoratives : elles disent, écran par écran, ce qui empêche encore quelqu'un d'atteindre son objectif dans AIME, et par où passer en attendant.

## 5. « Les secrets » — ce que je peux enfin te montrer

Un dernier calque, réservé à toi (visible une fois connecté en propriétaire), appelé **Les coulisses** : les zones où le site promet plus qu'il ne tient encore, les doublons de destination, les pages sans métadonnées, les tables créées mais non exploitées par l'interface, les statuts affichés « fonctionne » qui méritent « partiel ». Rien d'inventé : chaque entrée sera vérifiée dans le code avant d'être écrite, et celles que je ne peux pas prouver seront marquées comme à vérifier plutôt qu'affirmées.

## Livraison

1. Canevas zoomable et déplaçable, recadrage automatique — plus aucun dépassement.
2. Nœuds et flux manquants ajoutés, avec le filtre Tout / Existe / Manque.
3. Chaque relation réécrite en Si · Alors · Parce que.
4. Barrières et contournements.
5. Calque « Les coulisses ».

## Détails techniques

`src/lib/aime/systemMap.ts` : `SystemNode` gagne `exists: boolean`, `SystemEdge` gagne `{ si, alors, parceQue, exists }`, nouveau type `Barrier { edgeId, kind, detour[] }`, nouveau tableau `MISSING_NODES` fusionné dans `SYSTEM_NODES`, positions recalculées (grille plus large, le canevas gérant le cadrage). `src/routes/plan-du-site.tsx` : état `{ zoom, offset }` appliqué via un `<g transform>` unique sur le SVG ; molette gérée par un listener natif non passif (`{ passive: false }`) posé en `useEffect` avec `preventDefault`, facteur `Math.exp(-dy * 0.0015)` normalisé sur `deltaMode`, ancrage au curseur en coordonnées `viewBox`, clamp 0.35–2.5 ; pan par Pointer Events avec `touch-action: none` ; « Tout voir » calcule la boîte englobante des nœuds. Révélation progressive par seuils de zoom (opacité conditionnelle, pas de démontage). Aucune dépendance ajoutée, aucune migration de base de données ; le calque coulisses lit `useAuth` et n'affiche rien pour un visiteur.
