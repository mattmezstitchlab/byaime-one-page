# Briefing pour Manus — analyse externe d'AIME

Objectif : préparer un message complet et cadré à envoyer à Manus, pour qu'il produise un rapport en trois volets (parcours, positionnement, technique) sans partir sur une reconstruction du produit.

## Ce que je prépare

Un document unique `docs/brief-manus.md`, prêt à copier-coller, contenant :

1. **Le contexte du produit** — ce qu'est AIME en une page : une intention racontée en langage libre devient un monde/projet, dont la ligne de temps universelle est la représentation unique. Les principes non négociables : une seule ligne de temps, une information jamais dupliquée, AIME orchestre mais ne détient pas l'argent.
2. **Ce qu'il doit regarder** — le site public (byaime.fr), le parcours d'accueil, la page de démonstration mariage, l'espace personnel, le réseau.
3. **Un résumé écrit de l'architecture** — les espaces (Accueil, Mon espace, Projet/Monde, Réseau, Bureau), la chaîne source → transformation → affichage, le moteur PLAY, le module financier, et l'état du nettoyage en cours.
4. **Les trois volets de rapport demandés**, avec pour chacun des questions précises :
   - clarté du parcours (un visiteur comprend-il en 30 secondes ? où décroche-t-il ?) ;
   - positionnement et marché (concurrents de l'organisation d'événements et du mariage, angle différenciant, message public, mots-clés) ;
   - qualité technique et référencement (cohérence, pages restantes sans usage, performance, métadonnées).
5. **Les règles du cadrage** — ne pas proposer de refonte totale, ne pas toucher au périmètre gelé, classer chaque recommandation par impact et effort, distinguer les faits observés des hypothèses, citer ses sources web.
6. **Le format de réponse attendu** — synthèse en dix lignes, puis les trois volets, puis une liste priorisée d'actions.

## Détails techniques

- Fichier créé : `docs/brief-manus.md` (documentation seule, aucun impact sur l'application).
- Le résumé d'architecture reprendra les éléments réels du projet (routes existantes, `src/lib/aime/world/`, `src/lib/aime/play/`, `ProjectStage`, `HeroTimeline`) sans exposer de clés ni d'identifiants techniques sensibles.
- Aucune modification de code applicatif, aucune suppression de page.
