# Finaliser AIME sur téléphone, puis ajouter ce qui manque

## Ce que j'ai vérifié maintenant

Passage automatisé de dix pages sur un écran de téléphone (390 px) : accueil, fil, carte du réseau, crédits, bienvenue, connexion, mariage, démo mariage, guides, mon espace.

- Aucune page ne déborde sur le côté, aucune erreur dans le navigateur : la base est saine.
- Sur chaque page, entre 11 et 22 boutons ou liens sont plus petits que la cible confortable au doigt (44 px). C'est le principal défaut restant.
- Sur la démo mariage, deux petits boutons de la ligne de temps sortent légèrement du cadre.

## Lot 1 — Finition téléphone (à faire en premier)

1. Passer tous les petits boutons et liens à une zone tactile confortable, sans changer leur apparence (zone invisible autour du texte).
2. Corriger le léger débordement de la ligne de temps sur la démo mariage.
3. Vérifier la page publique d'une personne au doigt : ligne de temps, médias, commentaires, réactions.
4. Ajouter partout des états visibles : chargement, erreur avec bouton « Réessayer », et message quand il n'y a rien.
5. Rendre l'application installable sur l'écran d'accueil du téléphone (icône, nom, écran de lancement).

## Lot 2 — Ce qui manque vraiment pour un réseau social

Par ordre d'importance, d'après la feuille de route et l'état actuel :

1. **Recherche globale** : une seule barre pour trouver une personne, un lieu, un métier, un projet, un moment. Aujourd'hui il n'y a pas d'entrée unique.
2. **Abonnés / abonnements visibles** : voir qui suit qui, depuis chaque page publique.
3. **Réponses et modification** : répondre à un commentaire, corriger un moment ou un commentaire publié.
4. **Chargement au défilement** dans le fil (aujourd'hui il faut appuyer sur « Voir plus »).
5. **Temps réel** : nouveaux messages, réactions et commentaires qui apparaissent sans recharger.
6. **Réactions et commentaires sous chaque média et chaque moment**, pas seulement sous la page et les moments du fil.
7. **Essai réel à plusieurs comptes** depuis un vrai téléphone, y compris la connexion Google depuis l'adresse publique.

## Lot 3 — Innovations propres à AIME

Des choses qu'un réseau classique n'a pas et que la structure d'AIME rend possibles :

- **Le fil en ligne de temps** : voir les moments des personnes suivies replacés dans l'avant / pendant / après, et pas seulement du plus récent au plus ancien.
- **Écouter le fil** : le bouton Play existant appliqué au fil, qui raconte à voix haute les moments du jour avec la musique des pages.
- **Moments qui expirent** (24 h) pour publier sans engager, en réutilisant les moments courts déjà en place.
- **Demander un coup de main** : un bouton sur une page ou un projet qui diffuse un besoin aux personnes proches, par métier et par ville.
- **Rencontres suggérées** : proposer deux personnes complémentaires du même territoire, avec une entrée directe en conversation.
- **Page collective** : un collectif, un lieu ou un groupe animé à plusieurs mains.
- **Événements publics** avec participation et invitations, reliés aux projets existants.
- **Encaissement réel** pour terminer la chaîne devis → facture → paiement.

## Ordre proposé

Lot 1 d'abord (fiabilité avant le partage public), puis recherche globale + abonnés/abonnements + défilement infini, puis une innovation choisie parmi le lot 3.

## Détails techniques

- Cibles tactiles : ajouter `min-h-11 min-w-11` ou un pseudo-élément d'extension sur les boutons compacts de `SocialSafetyMenu`, `ReactionBar`, `CommentsSection`, `PostCard`, `HeroTimeline`, `TimeCapsule`, `reseau.tsx`, `credits.tsx`, `guides.*`, `organiser-un-mariage.tsx`.
- Débordement démo : boutons `shrink-0 rounded-full px-3 py-1 text-[12px]` de la barre de ligne de temps dans `demo.mariage.tsx` / `HeroTimeline.tsx` — conteneur en `overflow-x-auto` + `min-w-0`.
- Installable : `manifest.webmanifest` + balises dans `src/routes/__root.tsx` (pas de service worker au premier lot).
- Recherche globale : requête unique sur `cards`, `posts`, `projects` via un `createServerFn`, avec route `/recherche`.
- Abonnés/abonnements : lectures sur `follows` déjà en place, deux listes dans `carte.$id.tsx`.
- Défilement infini : `useInfiniteQuery` sur `feed.ts` (`PAGE_SIZE` déjà exporté).
- Temps réel : canaux Supabase Realtime sur `posts`, `comments`, `reactions`, `notifications` avec filtres par ligne.
- Conventions maintenues : pas de route `/bureau`, aucune modification des fonctions `SECURITY DEFINER`.
