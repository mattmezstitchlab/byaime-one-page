# Grand nettoyage d'AIME — audit et plan

Aucun fichier n'a été modifié. Voici l'état réel constaté, puis ce que je propose.

## A. Toutes les pages, avec leur statut

| Page | Rôle réel aujourd'hui | Statut | Action |
| --- | --- | --- | --- |
| `/` accueil | Récit → monde → timeline | CORE | garder |
| `/reseau` | Carte vivante + mode grille | CORE | garder la carte, retirer la grille |
| `/mon-espace` | Seuil du compte | CORE | garder, devient la seule porte du compte |
| `/ma-page` | Page publique personnelle | CORE | garder |
| `/carte/$id` | Page d'une entité | CORE | garder, timeline unifiée |
| `/projets/$id` | Le monde | CORE | garder (adresse conservée) |
| `/messages`, `/credits` | Fonctions du compte | CONTEXTUEL | accessibles seulement depuis Mon espace |
| `/demo/mariage` | Démonstration publique | CONTEXTUEL | garder |
| `/guides/*`, `/legal/*`, `/invitation`, `/auth`, `/demande-profil` | SEO, droit, entrée | CORE | garder |
| `/bureau/*` | Périmètre gelé | CORE | ne pas toucher |
| `/projets` (liste) | Doublon de « Mes mondes » | DOUBLON | rediriger vers `/mon-espace` |
| `/projets/nouveau` | Ancienne création par formulaire | DOUBLON | rediriger vers l'accueil |
| `/aimes-recues` | Ancienne porte | OBSOLÈTE | supprimer, la fonction vit dans Mon espace |
| `/plan-du-site` | Explique la navigation | OBSOLÈTE | supprimer |
| `/comment-ca-marche` | Ancienne page explicative | OBSOLÈTE | supprimer, le contenu utile passe en aide contextuelle |
| `/projets/$id/participants`, `/paiements`, `/facture`, `/musicbox` | Sous-pages verticales | À REPOSITIONNER | deviennent des panneaux du monde, adresses redirigées vers le monde |
| `/carte/$id/timeline`, `/devis/$cardId` | Déjà de simples redirections internes | OBSOLÈTE | supprimer |
| `/beta`, `/chemin`, `/cockpit`, `/communs`, `/entraide`, `/objectif`, `/saisons`, `/rencontres`, `/ambassadeur`, `/frequence/$id`, `/ma-carte`, `/tableau-de-bord`, `/parametres`, `/profil`, `/intermittent` | Redirections internes d'anciennes versions | OBSOLÈTE | supprimer (aucun lien interne, aucun intérêt public) |
| `/registre`, `/monde`, `/evenements`, `/evenement/*` | Anciennes adresses publiques déjà indexables | LEGACY | garder en redirection permanente seulement |

## B. Anciennes pages → remplacement

- Aimes reçues → Mon espace (section Aimes)
- Mes projets → Mon espace (Mes mondes)
- Comment ça marche → l'accueil lui-même + aide contextuelle dans le menu AIME
- Plan du site → navigation réduite à trois portes
- Sous-pages du projet → panneaux du monde
- Registre / Monde / Événements → Réseau et Mondes

## C. Navigation finale

```text
En-tête : AIME (menu) · Réseau · Mon espace
Menu AIME : aide & retours · démo mariage · langue · (Bureau si droits)
Mon espace : Ma page · Mes mondes · Aimes · Messages · Crédits · Paramètres
Un monde : Timeline · Calques · Relations · Personnes · Ressources · Documents · Finance · Musique · Messages
```

Trois portes principales au lieu de la dizaine actuelle.

## D. Une seule mécanique de temps

Aujourd'hui la page d'une carte lit ses propres sources (documents, devis, paiements, événements, messages, musique) avec une logique distincte de celle du monde. Je propose de convertir ces sources en un même modèle de monde, puis de les afficher avec le même moteur que l'accueil et le monde : mêmes temps (avant / aujourd'hui / après), mêmes statuts, mêmes relations, mêmes pictogrammes. Selon la nature de la carte (personne, lieu, ressource, projet), le récit change mais la grammaire reste identique.

## E. « Ce qui est lié »

Un clic sur ce bouton fait entrer la ligne de temps dans un mode relation : les éléments liés pulsent doucement et se relient par un trait, les autres s'atténuent, un second clic revient à l'état normal. L'animation est lente, s'arrête d'elle-même et est désactivée si la personne préfère moins d'animation.

## F. Pictogrammes

Passe complète : plus aucune étoile générique. Chaque élément prend l'icône de sa nature (personne, lieu, date, photo, musique, document, argent) et le cœur est réservé au dialogue avec AIME.

## G. Vocabulaire

« Mes mondes » remplace « Mes projets », « AIME » remplace « IA », le cœur remplace l'étoile. Les adresses techniques `/projets/...` restent inchangées pour ne casser aucun lien existant.

## H. Risques

- Un lien oublié vers une page supprimée casserait la navigation : je vérifie chaque lien avant suppression.
- Les sous-pages du projet contiennent de vraies fonctions : elles sont déplacées avant d'être fermées, jamais supprimées d'abord.
- Le passage de la timeline des cartes au moteur commun peut faire disparaître des éléments : comparaison avant/après sur une carte réelle.
- Bureau et sécurité de la base : non touchés.

## I. Ordre de réalisation

- **P0** — Retirer la grille du Réseau, retirer « Mes projets » du menu, supprimer Aimes reçues, Plan du site, Comment ça marche, nettoyer tous les liens et le plan de référencement.
- **P1** — Timeline unique sur les pages de carte ; nouvelle interaction « Ce qui est lié » avec pulsation ; remplacement des étoiles.
- **P1 bis** — Panneaux du monde pour participants, paiements, facture, musique, puis redirection des anciennes sous-pages.
- **P2** — Suppression des redirections internes sans usage, nettoyage des composants devenus orphelins, harmonisation du vocabulaire.

## Détails techniques

- Routes supprimées : fichiers retirés de `src/routes/`, `routeTree.gen.ts` se régénère seul.
- Redirections conservées uniquement pour `/registre`, `/monde`, `/evenements`, `/evenement/$`, `/projets`, `/projets/nouveau`.
- `src/lib/aime/cardTimeline.ts` devient un adaptateur produisant un `WorldProject` consommé par `deriveTimeline`, au lieu de fabriquer directement des marqueurs.
- Mode relation : état local dans `HeroTimeline` (`relationFocusId`), classes de pulsation gardées derrière `usePrefersReducedMotion()` déjà présent dans `MarkerReveal.tsx`.
- Nettoyage attendu côté composants : `GridPanel`, `GridCreate`, `WorldGrid`, `WorldGridSection`, `FilmComposer`, `ChapterCarousel` — chacun vérifié pour imports et usages dynamiques avant retrait.
- `src/routes/sitemap[.]xml.ts` : retirer `/comment-ca-marche`.
