# Un seul panneau, une seule ligne de temps

## Ce qui cloche aujourd'hui

Sur une page projet, la tuile « Documents » ouvre un tiroir à droite qui lui est propre : ses dossiers, ses montants, sa mise en page. Le panneau qu'on vient de construire (Discussions + Documents, avec les pastilles, l'aperçu sur place et l'envoi à une conversation) est juste à côté, et montre exactement les mêmes documents autrement. Deux portes, une seule information.

Et sur une page publique, la ligne de temps n'a pas la capsule « Aujourd'hui · Avant · Après » qui existe sur un projet : on ne peut pas voir d'un geste ce qui est déjà passé chez quelqu'un et ce qui l'attend.

## Ce qu'on fait

### 1. La page projet ouvre le même panneau

- La tuile « Documents » du projet n'ouvre plus son propre tiroir : elle ouvre le panneau latéral commun, onglet Documents, positionné sur le dossier du projet (déplié, les autres dossiers restent visibles au-dessus).
- Le dossier du projet est créé s'il n'existe pas, exactement comme aujourd'hui.
- Une tuile « Échanges » rejoint la rangée : elle ouvre le même panneau, onglet Discussions, sur la conversation du projet.
- Les tuiles « Personnes », « Argent », « Le jour J », « Veille » ne bougent pas : elles ne font double emploi avec rien.
- Les chiffres du projet (prévu, facturé, payé, reste) ne disparaissent pas : ils restent sur la page du projet, sous la rangée de tuiles, là où on les lit sans ouvrir de tiroir.
- La démo mariage garde son tiroir de lecture : elle n'a ni compte ni vrais documents.

### 2. Un dossier déplié montre ses documents en vignettes

Aujourd'hui, déplier un dossier donne une liste de noms : il faut cliquer, puis revenir. À la place, comme pour les documents non classés :

- Chaque document déplié s'affiche en vignette : l'aperçu de la page ou de la photo, son nom, sa date, son montant s'il en a un, et la pastille orange quand il manque quelque chose.
- La fiche du document s'ouvre sous la vignette d'un geste : type, sens, tiers, numéro, date, montant — modifiables sur place, sans quitter l'arbre.
- Les actions dépendent du type : un devis propose « Accepter » et « Envoyer », une facture « Marquer payée » et « Envoyer », une photo « Poser sur la ligne de temps », un document non identifié « Compléter ». Toutes ont « Envoyer à une conversation », « Ouvrir en grand » et « Télécharger ».
- Les vignettes s'affichent en grille de deux sur ordinateur, une seule colonne sur téléphone.

### 3. La capsule de temps sur les pages publiques


Sous la ligne de temps d'une page personne ou lieu, la même capsule que sur un projet :

```text
( Aujourd'hui | Tout 12 | Avant 7 | Aujourd'hui 1 | À venir 4 )
```

- **Avant** : ce qui s'est déjà passé — projets faits, souvenirs, avis.
- **Aujourd'hui** : ce qui se joue en ce moment.
- **À venir** : disponibilités, dates posées, ce qui l'attend.
- Chaque bouton recadre la ligne sur sa fenêtre et affiche le nombre de moments qu'elle contient ; « Aujourd'hui » à gauche ramène au présent, comme sur un projet.
- Le point de bascule d'une page personne, c'est le jour même (il n'y a pas de « jour J »), donc trois fenêtres au lieu de quatre.
- Le bouton de lecture et les calques restent où ils sont, sur la même rangée.

## Détails techniques

- Extraction de la capsule de `ProjectStage.tsx` (lignes 308-341) vers `src/components/aime/TimeCapsule.tsx` : props `pivot`, `phase`, `onPhase`, `counts`, `onRecenter`, `mode: "projet" | "personne"` (4 ou 3 fenêtres). `ProjectStage` et `carte.$id.tsx` l'utilisent tous les deux ; le calcul des bornes (`openPhase`, `phaseCounts`) devient une fonction partagée `phaseWindows(markers, pivot, mode)`.
- `carte.$id.tsx` : nouvel état `phase`, filtre combiné avec `layerFilter` existant pour la prop `visible` de `HeroTimeline`, et `setFocus` sur la fenêtre choisie.
- `FolderTree.tsx` : le contenu d'un dossier ouvert rend une grille de `DocCard` (nouveau composant tiré de `DocViewer`/`DocumentRow` : aperçu signé via `documentUrl`, `DocumentRow defaultOpen={false}` pour la fiche, rangée d'actions selon `doc.kind`). `DocViewer` réutilise `DocCard` en grand format pour éviter deux rendus concurrents.

- `messagesSheet.ts` : `MessagesRequest` gagne `folderId?: string | null` et `eventId?: string | null` ; `openDocuments({ eventId })`. `MessagesSheet` transmet à `DocumentsTab`, qui appelle `ensureProjectFolder`, déplie ce dossier et le fait défiler à l'écran.
- `ProjectPanels.tsx` : `PROJECT_PANEL_KEYS` perd `documents` et gagne `echanges` ; `PanelBar` déclenche `openDocuments`/`openMessages` pour ces deux clés au lieu de `setPanel`. `BureauPanel`/`DossiersPanel` restent en place pour la route `/bureau`, inchangée.
- La conversation d'un projet se retrouve par `threads.event_id` (déjà en base) ; si aucune n'existe, le bouton propose de l'ouvrir.
- Aucune migration. Routes `/bureau` et fonctions `SECURITY DEFINER` non touchées.
