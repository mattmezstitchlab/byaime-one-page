# Page publique : le cœur, le Play, et le menu du cœur

## Ce qui change à l'écran

1. **Le cœur passe en rouge AIME**, sans contour blanc ni petite pointe blanche : un disque rouge plein, l'icône en blanc. Il reste au même endroit, au centre, juste au-dessus de la ligne de temps.
2. **Le bouton Play remonte** : aujourd'hui il est collé en bas à gauche, à moitié mangé par la règle du temps et les calques. Il se place au-dessus de la ligne de temps, sur la même rangée visuelle que le cœur, donc toujours visible et cliquable.
3. **Le titre en double disparaît** : le nom de la page est écrit deux fois, une fois au milieu de l'image et une fois en gros en bas. On garde celui du bas (avec la ville, le prix, la note) et on retire celui du milieu quand il ne fait que répéter le nom.

## Audit du menu du cœur

Aujourd'hui le menu ouvre 12 tuiles identiques, toutes présentées de la même façon, même quand elles ne mènent nulle part (0 avis, pas de radio, pas de tarif).

**On garde, en trois familles au lieu d'une grille plate :**
- *Découvrir* : Photos et vidéos, Savoir-faire, Expériences, Avis, Sa ligne de temps
- *Travailler ensemble* : Disponibilités, Tarifs et devis, Payer
- *Rester en lien* : Écrire un message, Coordonnées, J'aime cette page

**On fait le ménage :**
- Une tuile vide est grisée avec la raison (« aucun avis pour l'instant ») au lieu d'ouvrir une page blanche.
- « Radio » n'apparaît que si la personne a une station.
- « Payer » n'apparaît que s'il existe un devis ou une prestation à régler.
- Côté propriétaire, « Mes projets », « Mon Bureau », « Modifier ma page » sont regroupés dans une bande « Ma page » séparée, pour ne pas se mélanger aux actions de visite.

**On ajoute (utilité réelle, appuyée sur ce qui existe déjà) :**
- **L'ajouter à un projet** : rattacher cette personne à l'un de mes projets en un clic, sans passer par un formulaire.
- **Recommander à quelqu'un** : envoyer cette page à un contact, avec un mot ; la recommandation se trace dans la ligne de temps.
- **Envoyer un document** : déposer un devis, un plan, une photo — le fichier part dans la conversation et se range tout seul dans le dossier de l'échange (le panneau Messages/Documents créé précédemment).
- **Rappel de contexte** : en tête du menu, une ligne « Vous lui avez écrit le 3 sept. · devis en attente », pour reprendre là où on s'est arrêté plutôt que repartir de zéro.

## Détails techniques

- `HeartMenu.tsx` : nouveau rendu du déclencheur — `bg-aime text-white`, `border-transparent`, suppression du losange-pointe blanc ; le `tone` par défaut devient rouge.
- `PlayShell.tsx` : le conteneur du `PlayButton` passe de `bottom-24 left-4` à un ancrage au-dessus de la règle (aligné avec la rangée du cœur, `z` au-dessus des calques).
- `UniverseCarousel.tsx` : ne rend le bloc titre centré que si `current.label` diffère de `card.name` (et si une sous-légende ou un prix existe).
- `pageAsk.ts` : ajout d'un champ `group: "decouvrir" | "ensemble" | "lien" | "ma-page"`, ajout des entrées `associer`, `recommander`, `document` ; `HeartMenu` rend les tuiles par groupe et accepte un état `disabled` + raison.
- `carte.$id.tsx` : calcule la disponibilité de chaque action (compteurs déjà en mémoire : avis, devis, radio, timeline) et la ligne de contexte à partir du fil existant.
- Pas de changement de base de données. Routes `/bureau` et fonctions `SECURITY DEFINER` non touchées.
