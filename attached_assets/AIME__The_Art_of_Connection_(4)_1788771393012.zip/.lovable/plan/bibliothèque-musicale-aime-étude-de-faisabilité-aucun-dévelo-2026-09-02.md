# Bibliothèque musicale AIME — étude de faisabilité (aucun développement)

## Réponse courte

Oui, c'est une extension naturelle de HERA → MusicBox → Timeline → AIME RADIO, à condition de ne **jamais** créer un second système. Une entrée MusicBox reste l'unité de programmation ; la bibliothèque ajoute seulement une couche « œuvre » à laquelle une entrée peut se rattacher, plus un journal de diffusion.

AIME ne peut pas héberger de musique protégée ni délivrer des licences. AIME peut en revanche devenir excellent sur ce que personne ne fait proprement : **la traçabilité fine œuvre → licence → programmation → diffusion**.

## 1. Ce qui est déjà possible aujourd'hui

Vérifié dans le code actuel :
- `musicbox_entries` porte déjà `kind: "musique"`, `title`, `day`, `start_time`, `duration_min`, `source_type` (link/upload), `source_url`, `audio_path`, `card_id`, `event_id`, `owner_id`, `visibility`, `city/lat/lon`.
- L'onglet Radio calcule déjà « à l'antenne », « juste après » et la bande du jour à partir de ces horaires (`isLive`, `entryStart/entryEnd`).
- L'identité de fréquence (`card_radios`) et son équipe (`radio_members`) existent depuis aujourd'hui.

Donc : programmation, horaires, contexte (carte / monde / événement), auteur de l'ajout — tout cela est déjà capté. Il manque l'identité de l'œuvre et la preuve de diffusion.

## 2. Faisable immédiatement, sans droit ni partenaire

- Préécoute 30 s : ne pas héberger d'extrait ; utiliser les **players officiels** (Spotify/Deezer/Apple ont des embeds de preview autorisés) ou l'aperçu YouTube déjà géré par `embedInfo`.
- Distinguer visuellement les états d'un morceau : `decouverte` (30 s), `disponible` (droits déclarés), `programme`, `diffuse`.
- Journaliser chaque passage à l'antenne (calculé, pas déclaratif) : quelle entrée, quelle fréquence, quel monde, début/fin réels.
- Export d'un **relevé de diffusion** CSV/PDF par période, exactement comme l'export Pennylane du Bureau.

## 3. Données supplémentaires à stocker (couche « œuvre »)

- `works` : titre, artiste principal, ISRC, ISWC si connu, label/éditeur, année, durée, source d'identification, statut de vérification.
- `work_rights` : ayants droit connus (rôle : auteur, compositeur, éditeur, interprète), part si déclarée.
- `work_licenses` : titulaire (utilisateur ou fréquence), périmètre (radio / événement / monde), type (libre, CC, achat, licence déclarée, autorisation directe de l'artiste), preuve/justificatif, dates de validité.
- `airplay_logs` : entrée, œuvre, fréquence, carte/événement, début, fin, durée effective, contexte, nombre d'écoutes.
- `musicbox_entries.work_id` : le seul champ à ajouter côté existant — pas de duplication.

## 4. Identification fiable des morceaux

Possible, par paliers :
- **Déclaratif assisté** : l'utilisateur colle un lien, l'IA extrait titre/artiste (déjà le rôle de Gemini dans le Bureau).
- **Bases ouvertes** : MusicBrainz (ISRC/ISWC, gratuit) et Discogs pour la métadonnée éditoriale.
- **Empreinte audio** : AcoustID/Chromaprint (ouvert) pour les uploads, ACRCloud pour du niveau professionnel.
- ISRC = enregistrement, ISWC = œuvre. Les deux sont nécessaires pour parler aux OGC ; l'ISWC est rarement public, il vient des sociétés d'auteurs.

Fiabilité honnête : identifier l'enregistrement est atteignable ; identifier **tous** les ayants droit ne l'est pas sans accès aux répertoires des sociétés.

## 5. « 30 s → disponible » sans héberger illégalement

Règle simple, non négociable :
- La découverte passe **toujours** par le player du service source (embed officiel). AIME ne stocke ni ne découpe l'audio.
- L'upload dans `audio_path` reste réservé aux créations propres, voix, messages, ou morceaux dont l'utilisateur détient/déclare les droits, avec case d'attestation.
- « Disponible » ne veut pas dire « fichier obtenu » : cela veut dire **statut de droits renseigné et justifié**. La lecture continue de passer par le service source ou par un fichier légitimement détenu.

## 6. Partenaires envisageables

- Catalogues libres de droits : Free Music Archive, Jamendo Licensing, Epidemic Sound, Artlist, Audiius — API et licence commerciale immédiates.
- Radios en ligne : Radio King, Live365, RadioJar (ils gèrent déjà la relation SACEM/SoundExchange).
- Métadonnée : MusicBrainz, Discogs, Songstats, ACRCloud.
- Distribution/artistes indépendants : Bandcamp, Believe, Distrokid — pour un accord direct artiste ↔ AIME, souvent la voie la plus rapide.
- OGC : SACEM/SDRM en France, SACEM + producteurs (SCPP/SPPF) pour les droits voisins.

## 7. Preuve de diffusion

Techniquement oui, et c'est le point fort d'AIME. La programmation étant horodatée, un relevé est calculable : œuvre, ISRC, durée, fréquence, contexte, date. Format visé : le relevé type des OGC (playlist déclarative). Le mot « preuve » doit rester prudent : c'est un **relevé fiable et horodaté**, pas une certification légale, tant qu'aucun tiers ne le contresigne.

## 8. Rémunération / partage de revenus

Plausible seulement en aval d'accords. Modèle progressif :
1. Reversement des licences catalogue (marge AIME sur un achat de licence).
2. Abonnement fréquence, dont une part alimente un pot redistribué au prorata des diffusions tracées.
3. Récompense contributeur : plutôt en crédits AIME (déjà en place) qu'en argent — cela évite d'être un intermédiaire financier soumis à agrément.

Le partage en euros vers des ayants droit fait d'AIME un payeur de droits : cela exige contrat, comptabilité dédiée, et probablement statut de service de médias en ligne.

## 9. Ce qui exige obligatoirement des accords

- Toute diffusion publique d'un phonogramme protégé (droit d'auteur SACEM + droits voisins SCPP/SPPF).
- Tout hébergement/streaming de fichiers protégés.
- Toute redistribution d'argent aux ayants droit.
- Tout usage d'une API commerciale (Spotify preview, Epidemic, ACRCloud) au-delà de ses conditions.

Rien de tout cela n'est bloquant pour la phase 1 si AIME reste un **outil de programmation et de relevé**, jamais un diffuseur.

## 10. MVP réaliste proposé

1. Champ œuvre sur une entrée musique : titre, artiste, ISRC optionnel, lien source, statut de droits (libre / licence détenue / à obtenir / création propre).
2. Table `works` + `musicbox_entries.work_id`, avec dédoublonnage par ISRC ou titre+artiste.
3. Préécoute par embed officiel, jamais de fichier protégé.
4. Journal de diffusion automatique à partir des créneaux déjà programmés.
5. Écran « Bibliothèque » sur la fréquence : les œuvres, leur état, leur nombre de diffusions.
6. Export relevé de diffusion (CSV) par période, réutilisant le moteur d'export du Bureau.
7. Catalogue libre de droits branché en premier (Jamendo/FMA) : la boucle complète « découvre → droits → programme → diffusé → tracé » devient réelle et 100 % légale dès le MVP.

Ce MVP ne crée pas un deuxième système : une œuvre est un attribut d'une entrée MusicBox, la diffusion est un journal de la Radio, l'export réutilise le Bureau.

## Détails techniques

- Nouvelles tables : `works`, `work_rights`, `work_licenses`, `airplay_logs` ; une seule colonne ajoutée à l'existant (`musicbox_entries.work_id`).
- RLS : `works` en lecture publique (métadonnée non sensible), `work_licenses` et `airplay_logs` réservés au propriétaire de la fréquence ; grants explicites.
- Le journal de diffusion s'écrit côté serveur (`createServerFn`) au passage du créneau, pas depuis le navigateur, pour rester fiable.
- Identification des œuvres via un appel serveur MusicBrainz, sans clé, avec cache dans `works`.

## Ce que je recommande de ne pas faire

- Ne pas stocker d'extraits de 30 s dans le stockage AIME.
- Ne pas afficher « libre de droits » sans source vérifiable.
- Ne pas promettre une rémunération aux contributeurs avant d'avoir un accord signé — un système de crédits est la bonne étape intermédiaire.
