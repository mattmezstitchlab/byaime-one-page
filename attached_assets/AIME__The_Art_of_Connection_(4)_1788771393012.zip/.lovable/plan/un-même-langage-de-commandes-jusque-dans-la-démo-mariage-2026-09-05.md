# Un même langage de commandes, jusque dans la démo Mariage

## Objectif

La démo Mariage doit présenter la même interface claire que les projets réels, tout en restant entièrement en lecture seule. Les commandes importantes restent visibles ; les actions secondaires sont regroupées sans supprimer de fonction.

## 1. Mettre à jour les panneaux de la démo Mariage

La démo utilise déjà les mêmes catégories que les projets — **Personnes, Argent, Documents, Jour J, Veille** — et les ouvre déjà à droite. En revanche, leur barre d’entrée est encore composée de grandes tuiles empilées sur téléphone.

Nous allons :

- remplacer ces grandes tuiles par une barre compacte commune aux projets et à la démo ;
- conserver les cinq entrées avec icône, libellé court et état actif clair ;
- permettre le défilement horizontal sur petit écran plutôt que plusieurs rangées ;
- ouvrir chaque contenu dans le même panneau latéral plein écran sur téléphone et à largeur contenue sur ordinateur ;
- afficher clairement que la démo est consultative, sans boutons d’écriture, d’envoi ou de paiement ;
- garder le bouton **Activer** comme seule action permettant de transformer la démonstration en vrai projet.

## 2. Unifier la structure des panneaux projet et démo

Créer une seule présentation réutilisable pour éviter que les deux expériences divergent à nouveau :

- même en-tête compact avec retour/fermeture, titre et éventuelle action contextuelle ;
- même position, même hauteur de commande et même comportement mobile ;
- contenu réel dans les projets, projection en lecture seule dans la démo ;
- navigation reflétée dans l’adresse pour conserver le retour navigateur et le partage d’un panneau ouvert.

Aucune donnée de démonstration ne sera enregistrée avant l’activation.

## 3. Alléger encore les boutons de l’en-tête mobile

L’en-tête affiche encore côte à côte **Échanges, Documents, Mon espace et Fil** sur téléphone. Nous allons :

- conserver **Échanges** comme accès direct principal ;
- regrouper **Documents** et **Mon espace** derrière une seule commande personnelle compacte avec une pastille cumulée ;
- conserver **Fil** comme navigation directe ;
- rendre les trois destinations immédiatement accessibles dans un petit menu, sans texte coupé ni déplacement du logo ;
- ne rien changer à la disposition ordinateur.

## 4. Finir l’allègement de la carte Réseau

La carte est déjà plus claire, mais trois commandes flottantes restent au-dessus du contenu. Nous allons :

- intégrer **Autour de moi** à la zone de recherche ;
- garder seulement **Intention** et **Filtres** comme actions flottantes ;
- rendre la barre de sélection stable sur téléphone avec la destination sur une ligne et les actions compactes sur une seconde ligne si nécessaire ;
- conserver le clic/toucher direct des cercles chiffrés vers le zoom.

## 5. Simplifier les formulaires financiers sur téléphone

Les zones de retrait et de contribution peuvent encore former des rangées irrégulières quand les champs passent à la ligne. Nous allons :

- empiler les champs proprement sur téléphone ;
- donner toute la largeur au bouton principal en bas du groupe ;
- conserver la disposition horizontale actuelle sur ordinateur ;
- ne modifier aucune règle de calcul ni aucun mouvement d’argent.

## 6. Règles communes pour les prochains boutons

Appliquer le même principe aux zones concernées :

- une action principale visible ;
- les actions secondaires dans un menu ou une courte barre ;
- les rangées mêlant texte et icônes construites pour que le texte puisse se réduire sans pousser les boutons hors écran ;
- icônes toujours nommées pour le clavier et les lecteurs d’écran ;
- hauteur tactile minimale conservée.

## Vérifications

- Démo Mariage à 360–430 px : une seule barre compacte, aucun empilement de cinq tuiles.
- Chaque panneau de la démo s’ouvre, se ferme et reste en lecture seule.
- Projet réel : même barre, sans régression sur les contenus ni les actions autorisées.
- En-tête mobile : logo et commandes tiennent sur une ligne, pastilles lisibles.
- Carte : recherche et commandes ne masquent pas les repères ; sélection lisible avec un nom long.
- Formulaires financiers : aucun champ ni bouton coupé sur téléphone.
- Navigation clavier, noms accessibles et fermeture des panneaux contrôlés.

## Hors périmètre

- aucune modification des routes `/bureau` ;
- aucune modification des fonctions `SECURITY DEFINER` ;
- aucune modification du moteur PLAY ni de la ligne de temps ;
- aucune écriture de données depuis la démo avant son activation ;
- aucune modification des règles financières.
