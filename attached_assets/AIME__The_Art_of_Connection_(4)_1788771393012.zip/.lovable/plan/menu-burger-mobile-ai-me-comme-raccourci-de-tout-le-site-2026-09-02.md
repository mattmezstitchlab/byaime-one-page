# Menu burger mobile + AI · + · ME comme raccourci de tout le site

Aujourd'hui sur mobile la capsule verticale disparaît : elle est remplacée par une barre basse de 8 pictos sans libellés, qui n'ouvre ni Radio, ni langues, ni les pages secondaires (crédits, paramètres, guides, bêta, comment ça marche). Le dock AI · + · ME, lui, est bien présent partout, mais ses trois panneaux ne couvrent qu'une partie du site.

## 1. Menu burger dans le header (mobile et tablette)

Un bouton burger à gauche du logo, uniquement sous `md`. Il ouvre une feuille plein écran qui reprend **toute** la navigation, structurée en sections lisibles avec libellés (plus seulement des icônes) :

```text
DÉCOUVRIR      Accueil · Annuaire · Carte réseau · Guides locaux
FAIRE          Créer ma carte · Créer une équipe · Mes projets · Le Bureau
ÉCHANGER       Messages · Aimes reçues · Radio AIME
MOI            Tableau de bord · Mon espace · Crédits · Paramètres
COMPRENDRE     Comment ça marche · Visite en 40 s · Programme bêta
                                        Langue : FR EN ES DE IT
```

La page courante est marquée, les compteurs (Aimes non lues) sont visibles, et « Visite en 40 s » lance la présentation depuis n'importe quelle page.

La barre basse mobile actuelle disparaît : elle faisait doublon avec le burger et poussait le dock trop haut. Sur mobile on garde donc, dans tous les cas : **burger en haut à gauche, AI · + · ME en bas au centre** — exactement la même logique que sur ordinateur (capsule à gauche, dock en bas).

## 2. Audit — ce qui manque dans AI, + et ME

Règle de partage, à respecter pour éviter tout doublon :
**AI = ce qui vient d'elle · + = ce que je crée · ME = ce qui m'appartient.**

### AI (panneau gauche) — présent : champ d'intention, crédits, mémoire, discussions, journal

Manque :
- **Ce qu'elle propose maintenant** : 3 suggestions vivantes issues de vos données (une date libre à remplir, un devis sans réponse, un document manquant au Bureau) — c'est ce qui transforme le panneau en tableau de bord.
- **À corriger** : le compteur « À faire » du Bureau (pièces illisibles, montants incertains) avec accès direct.
- **Traduire / parler** : langue de discussion et prompteur radio, aujourd'hui cachés dans la messagerie et la radio.
- **Comprendre** : « Comment ça marche » et « Visite en 40 s ».

### + (créer) — présent : carte, projet, équipe, éphémère, document, devis/facture

Manque :
- **Une intention publique** (dire ce qu'on cherche sans créer de carte).
- **Un moment sur ma timeline** (repère, souvenir, disponibilité).
- **Une invitation** (inviter un prestataire ou un proche).
- **Un retour bêta**, aujourd'hui uniquement dans le bouton flottant.

À corriger : « Un devis / une facture » pointe sur `/bureau` comme « Un document » — deux entrées, une seule destination. Le devis doit mener à la création de devis.

### ME (panneau droit) — présent : compteurs, coordonnées de versement

Manque :
- **Mes cartes** (liste avec accès direct, création d'une carte supplémentaire).
- **Mes Aimes reçues** et **mes messages**, avec compteurs de non-lus.
- **Mes devis et factures**, mes paiements en attente.
- **Mes dossiers du Bureau** et l'export comptable.
- **Mon profil public**, **Paramètres** (langue, accessibilité), **Crédits**, **Déconnexion** — aucune de ces entrées n'est atteignable depuis ME.

Résultat visé : depuis ces trois boutons, chaque page du site est atteignable en un geste, sans jamais se répéter d'un panneau à l'autre.

## 3. Livraison

1. Burger mobile + retrait de la barre basse.
2. Enrichissement des trois panneaux selon l'audit ci-dessus.
3. Vérification mobile (430 px) : rien ne se chevauche, dock lisible, burger accessible.

## Détails techniques

Nouveau `src/components/aime/MobileMenu.tsx` (Sheet `side="left"`, sections issues d'une constante partagée `src/lib/aime/navigation.ts` réutilisée par la capsule desktop et le burger pour garantir une seule source de vérité). `AppShell.tsx` : ajout du burger dans le header sous `md`, suppression du `<nav>` bas mobile, ajustement du padding `main` et de la position du dock. `AimeDock.tsx` : liste `CREATE` complétée et destination du devis corrigée. `AiPanel.tsx` : bloc suggestions calculé à partir des requêtes existantes (`card_availability`, `quotes`, `bureau_documents`), bloc « À corriger », liens Comprendre. `MePanel.tsx` : sections Mes cartes / Échanges / Argent / Bureau / Compte, avec liens et compteurs via les requêtes déjà en place. Aucune modification de base de données.
