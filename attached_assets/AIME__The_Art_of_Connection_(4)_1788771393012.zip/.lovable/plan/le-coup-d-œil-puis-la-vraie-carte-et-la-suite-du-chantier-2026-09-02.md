# Le coup d'œil, puis la vraie carte — et la suite du chantier

Oui, l'idée est juste : la bulle du Monde AIME doit rester un **coup d'œil** (rapide, vivant, média qui défile), et un **switch** doit faire apparaître la **vraie carte universelle recto/verso**, exactement celle du reste du site. Deux niveaux de lecture, sans jamais quitter la grille.

## 1. La bulle « coup d'œil » (Monde AIME et pins de la map)

Un seul composant partagé, utilisé par la grille `/monde`, les pins de la map et la timeline.

- Bandeau média en boucle : visuel, vidéo, extrait sonore, projets — défilement lent automatique, points de progression, pause au survol, flèches discrètes.
- Sous le média : univers · ville, nom, accroche.
- Rangée d'actions : Ouvrir · Devis · Dispos · Écrire.
- Un **switch** en haut à droite de la bulle : « Voir la carte ». La bulle se retourne (même animation 3D que le calendrier) et affiche la vraie Carte AIME recto/verso, cœur au recto, console AI · + · ME au verso. Re-clic pour revenir au coup d'œil.
- Sur mobile la bulle est une feuille en bas d'écran, même contenu.

## 2. Le verso des cartes — la console carrée

- Format carré, même grammaire que `DayConsole`/`CalendarFlip`.
- Niveau 0 : tuiles. Niveau 1 : panneau plein dans le carré, retour en un geste.
- **AI** = correspondances expliquées · **+** = actions (devis, réserver, inviter, document) · **ME** = fonctions perso (mes dispos, mes projets, mes documents).
- Cœur uniquement au recto.

## 3. Réseau — la fusion (déjà convenue)

- Bouton **Filtres** en panneau, pour nettoyer la barre sous la recherche.
- Vues cumulables pilotées par l'URL : `?vues=map,liste,mosaique`.
- Mosaïque en bande horizontale en haut de la page.
- Au survol d'un pin : la même bulle « coup d'œil » qu'au point 1, avec le même switch vers la vraie carte.
- Liste latérale = la liste officielle, partagée par toutes les vues.

## 4. Page carte universelle `/carte/$id`

- Finaliser `?univers=` : changer de carte, de hero et filtrer la timeline sans quitter la page.
- Finaliser les onglets `?onglet=` : Présentation, Savoir-faire, Expériences, Calendrier, Avis, Devis et tarifs, Timeline, Contact.
- Retirer les anciennes routes devis/timeline redondantes.

## 5. Finitions

- Devis générés depuis la timeline reliés au Bureau.
- Crawl des parcours connectés (grille, réseau, carte, bureau).

## Ordre de réalisation

1. Bulle partagée + switch vers la vraie carte (grille, pins, timeline)
2. Verso console AI · + · ME
3. Fusion `/reseau` (filtres, vues cumulables, mosaïque en bande)
4. Page carte universelle
5. Devis → Bureau, crawl connecté

## Détails techniques

- Nouveau `src/components/aime/CardPreview.tsx` : bulle partagée (média en carrousel, actions, état `flipped`), consommée par `WorldGrid.tsx`, `CardsMap.tsx` et `HeroTimeline.tsx` — la logique de bulle actuellement dupliquée y est extraite.
- Le verso réutilise `AimeCard.tsx` en mode compact ; nouveau `src/components/aime/panels/CardConsole.tsx` pour les tuiles AI · + · ME, dans l'esprit de `DayConsole.tsx`.
- Médias du carrousel dérivés des données existantes (visuel de carte, médias timeline, projets liés) — pas de nouveau champ pour l'instant.
- `/reseau` : état des vues dans les search params Zod (`vues`, `q`, filtres), panneau Filtres en `Sheet`.
- Respect de `prefers-reduced-motion` : pas de défilement auto ni de flip animé.
- Aucun changement de base de données ni de RLS.
