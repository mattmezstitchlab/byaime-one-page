# Audit AIME — ce qui existe, ce qui traîne, ce qui manque

## 1. Ce qu'on peut faire aujourd'hui dans AIME

**Se présenter**
- Une page publique par personne, lieu ou métier (281 pages déjà en base) : photo, présentation, savoir-faire, expériences, disponibilités, tarifs, visibilité.
- Modification en direct sur sa propre page (bouton « Modifier »).
- Grille de médias : photos, vidéos, YouTube, sons, liens, avec visionneuse plein écran.
- Demander sa page, revendiquer une page existante, inviter quelqu'un.

**Se trouver**
- Carte du réseau en plein écran, avec vignette au survol d'un point.
- Les 12 Mondes comme vue de découverte, guides métier/ville pour l'arrivée depuis Google.

**Se parler**
- Messagerie type Messenger : liste de conversations, non-lus, recherche, fil, visio.
- Onglet Documents dans le même panneau : arbre de dossiers (un dossier par projet, un par conversation), vignettes, actions par type de document.
- Notifications navigateur + pastilles et son.

**Faire ensemble**
- Projets avec une seule ligne de temps universelle (avant / pendant / après), calques, pastilles d'état, boussoles « que dois-je faire / que manque-t-il », rétroplanning.
- Devis, factures, acomptes, échéanciers, statut « prêt à payer », journal financier.
- Participants, rôles, invitations, page publique d'événement.
- Démo publique d'un mariage complet.

**Vivre le récit**
- Un seul bouton Play : lit la ligne de temps, voix qui raconte, playlist écoutable, radio d'ambiance au hasard sur les morceaux publics.

**Le compte**
- Mon espace en panneau avec la liste « à faire » et ses actions en un geste, réglages + accessibilité, langues, crédits IA, copilote Aime.

## 2. Incohérences à corriger

1. **Le « plan du système » sur l'accueil** affiche des compteurs techniques (pages vivantes, modules jamais importés) et se contredit entre l'affichage serveur et l'affichage navigateur (11 vs 6) : bloc de diagnostic interne exposé aux visiteurs. À retirer de l'accueil.
2. **Deux réglages coexistent** : le panneau Réglages actuel et un ancien écran de réglages qu'il utilise encore, avec des liens qui renvoient vers l'ancienne page « Mon espace ». À fusionner sur une seule source.
3. **« Mon espace » existe en double** : le panneau (nouveau) et la page (ancienne). Une trentaine de liens internes pointent encore vers la page. Cible : la page ne fait plus qu'ouvrir le panneau, tous les liens passent par le panneau.
4. **Bureau résiduel** : trois écrans « bureau » (fenêtre, dossier d'événement, liens de dossier) ne sont plus jamais ouverts depuis la refonte Documents.
5. **Un lien d'invitation aux documents** fabrique une adresse `/mon-espace?invitation=…#documents` que plus rien ne lit.
6. **Restes de l'ancienne radio** : un sélecteur de fréquence et un journal de diffusion subsistent alors que le concept a été supprimé.

## 3. Pages et fichiers à supprimer

**Pages**
- 4 redirections projet (musicbox, paiements, participants, facture) et la redirection événement : à garder seulement si ces adresses ont pu être partagées, sinon à supprimer.
- Page « Mon espace » : à réduire à une simple ouverture du panneau.

**Fichiers jamais utilisés** (vérifiés : aucun import)
- Écrans : panneau d'exploration, boussole de temps, bande de fréquence, fenêtre bureau, dossier d'événement, liens de dossier.
- Outils : administration, texte, traduction, semaines, œuvres, exports bureau (x2), membres bureau.
- Une trentaine de composants d'interface de la bibliothèque de base jamais employés (accordéon, tableau, curseur, etc.) — sans risque, mais alourdissent le projet.

## 4. Ce qui n'est pas branché (existe en base, invisible dans l'app)

| Sujet | État |
|---|---|
| Stories et vues de stories | tables présentes, aucun écran |
| Bisous / empreintes | 3 enregistrements, aucun écran |
| Rencontres, passages, parrainages | vides, aucun écran |
| Avis et recommandations | table vide, aucun écran |
| Ambassadeurs et missions | 10 missions en base, aucun écran |
| Communs (biens partagés) | table vide, aucun écran |
| Objectifs, demandes d'aide | tables vides, aucun écran |
| Cellules du monde | 1 ligne, aucun écran |
| Rôles projet, playlists de temps | vides, aucun écran |
| Œuvres, droits, licences | vides, code présent mais jamais importé |
| Capacités de page | table vide |
| Comptes de versement, liens financiers | vides : l'argent est modélisé mais aucun encaissement réel |
| Signaux d'exploration (151) | collectés, jamais restitués à l'utilisateur |
| Trace du site (3 500 événements) | collectée, jamais restituée |

## 5. Ce qui manque pour remplacer Facebook

Par ordre d'importance :

1. **Un fil d'actualité** : aujourd'hui aucun flux ne rassemble ce que font les gens qu'on suit. C'est le manque numéro un.
2. **Le lien social explicite** : suivre / être suivi / ami, avec une liste de relations. Les « Aimes » existent mais ne créent pas d'abonnement.
3. **Réagir et commenter** : ni réaction, ni commentaire, ni partage sur une page, un média ou un moment de ligne de temps.
4. **Publier un moment court** (statut, photo du jour, story) sans créer un projet.
5. **Notifications persistantes** : rien n'est stocké, tout disparaît au rechargement ; pas de centre de notifications.
6. **Recherche globale** de personnes, lieux, projets, médias.
7. **Groupes / pages collectives** : un collectif ne peut pas encore avoir sa page animée à plusieurs.
8. **Événements ouverts au public** avec participation et invitations sociales.
9. **Encaissement réel** : la chaîne devis → facture → paiement s'arrête avant le paiement effectif.
10. **Confidentialité par publication** : choisir qui voit quoi, au-delà de public / privé.
11. **Application installable et notifications même app fermée**.
12. **Modération et signalement**, indispensables dès que le fil existe.

## 6. Ordre de travail proposé

- **Étape A — Nettoyage** : retirer le plan du système de l'accueil, fusionner les réglages, réduire « Mon espace » au panneau, supprimer les fichiers morts et les restes de radio.
- **Étape B — Socle social** : relations (suivre), réactions, commentaires, notifications persistantes.
- **Étape C — Fil d'actualité** alimenté par les pages, les médias, les moments publics et les stories.
- **Étape D — Recherche globale, groupes, événements publics.**
- **Étape E — Paiement réel, confidentialité fine, modération.**

## Détails techniques

- Fichiers orphelins confirmés par recherche d'imports : `ExplorationPanel.tsx`, `TimelineCompass.tsx`, `panels/FrequencyBand.tsx`, `bureau/BureauWindow.tsx`, `bureau/FolderEvent.tsx`, `bureau/FolderLinks.tsx`, `lib/aime/{admin,text,translate.functions,weeks,works}.ts`, `lib/bureau/{export,exports,members}.ts`, ~30 `components/ui/*`.
- Doublon réglages : `components/aime/SettingsSheet.tsx` importe `components/dashboard/SettingsSection.tsx`, qui pointe vers `/mon-espace` et `/credits`.
- Redirections : `projets.$id.{musicbox,paiements,participants,facture}.tsx`, `evenement.$.tsx`.
- Hydratation `SystemMap.tsx` : le graphe importé diffère entre rendu serveur et navigateur (compteurs et arêtes), d'où l'erreur d'hydratation sur l'accueil.
- Socle social à créer : tables `follows`, `reactions`, `comments`, `notifications`, `posts` (+ GRANT et RLS), plus une requête de fil paginée.
- Conventions respectées : pas de route `/bureau`, aucune modification des fonctions `SECURITY DEFINER`.
