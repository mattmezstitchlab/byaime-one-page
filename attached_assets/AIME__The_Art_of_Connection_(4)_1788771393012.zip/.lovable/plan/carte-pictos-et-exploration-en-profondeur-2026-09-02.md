# Carte, pictos et exploration en profondeur

## 1. La vignette qui s'échappe sur la carte

Au survol d'une vignette ronde, le code applique un agrandissement directement sur le bouton du repère. Or c'est ce même élément que la carte utilise pour placer le point : l'agrandissement écrase la position, la vignette saute en haut à gauche, puis la carte la remet en place au rafraîchissement suivant. D'où l'aller-retour.

Correction : l'agrandissement s'applique à l'image à l'intérieur du bouton, jamais au bouton lui-même. Le repère reste immobile, seule la photo grossit légèrement.

## 2. Le petit bloc d'aperçu sur la carte

Sur la carte, le bloc s'affiche sans son fond sombre : le texte et les boutons flottent sur le plan, illisibles (capture). Sur le Monde AIME le même bloc est correct parce qu'il est posé dans une bulle noire.

Correction : la carte réutilise exactement la bulle du Monde AIME — fond noir translucide, bord fin, ombre, coins arrondis — et le même comportement :

- position recadrée pour ne jamais déborder à gauche, à droite ni sous l'en-tête,
- bascule sous le point quand il n'y a pas la place au-dessus,
- sur téléphone, le bloc se pose en bas de l'écran plutôt qu'au-dessus du doigt.

## 3. Menu AIME : « les six chapitres »

Le mode d'emploi en compte treize. Le menu du logo affiche « Treize chapitres illustrés » partout, et la mention obsolète disparaît.

## 4. L'étoile scintillante remplacée par une boussole

L'étoile est remplacée par une boussole partout où elle sert d'icône d'intelligence ou de suggestion : barre d'outils, panneau AI au verso des cartes, menu du logo, dock, panneaux Radio/Fréquence, écrans Ma carte, Bureau, Crédits, Tableau de bord, Ambassadeur, Registre vide, Intermittent, Demande de profil, Invitation, Réseau, Roadmap, Composer, Diagramme du mode d'emploi, Stories. Le cœur reste le cœur : rien d'autre ne change.

## 5. Le verso des 12 mondes : explorer en profondeur

### Ce qui disparaît
- « Surprends-moi » (rotation aléatoire sans effet compris).
- « Voir ce que ça donne » (sortie prématurée hors de l'exploration).

### La taxonomie à trois niveaux
Chaque entrée d'un monde ouvre désormais son propre sous-menu de domaines, à cocher, sans quitter la carte :

```text
Événement
 └─ Mariage
     ├─ Lieu de réception      ├─ Traiteur
     ├─ Photographe            ├─ Vidéaste
     ├─ Musique / DJ           ├─ Cérémonie laïque
     ├─ Fleurs & décor         ├─ Robe & costume
     ├─ Coiffure & maquillage  └─ Transport
 └─ Anniversaire
     ├─ Animation              ├─ Gâteau & pâtisserie …
```

Les domaines sont écrits pour les douze mondes et leurs entrées, dans le vocabulaire propre à chacun (le mariage parle de cérémonie et de traiteur, la musique de scène et de sonorisation, le patrimoine de restauration et d'archives). Chaque case cochée est mémorisée comme signal d'exploration, comme aujourd'hui, et resserre immédiatement les visages proposés.

### « Ajouter à la composition »
Le bouton « Tout l'univers » devient « Ajouter à la composition ». Au clic :

1. la liste des projets de la personne s'ouvre (avec « Nouveau projet » si besoin),
2. les domaines cochés deviennent des **places à pourvoir** dans la composition (une place « Traiteur », une place « Photographe »…),
3. les cartes affichées que l'on choisit viennent **se poser sur ces places**, en remplissant la place correspondante quand elle existe.

L'exploration cesse d'être une visite : elle remplit le projet.

Sans être connecté, le choix est conservé le temps de la visite et proposé à la connexion.

## Détails techniques

- `CardsMap.tsx` : l'agrandissement passe sur l'`img` interne du repère ; le bouton conserve la transformation de placement de la carte.
- `reseau.tsx` : le conteneur du coup d'œil reprend l'habillage et le calcul de position de `WorldGrid.tsx` (bulle noire, recadrage horizontal/vertical, bascule dessus/dessous, plein largeur sur mobile) — extraction d'un composant `GlanceBubble` partagé par `WorldGrid` et `reseau` pour éviter le double code.
- `LogoMenu.tsx` : note « Treize chapitres ».
- Remplacement de `Sparkles` par `Compass` dans les fichiers listés au point 4 (`lib/aime/icons.ts` inclus, pour les intentions).
- `universeTree.ts` : `SubUniverse` reçoit `domains?: { slug; label; keywords?: string[] }[]`, renseignés pour les 12 mondes ; helpers `domainsFor(universe, sub)` et `cardMatchesDomain(card, domain)` (mots-clés sur catégorie, étiquettes et savoir-faire).
- `ExplorationPanel.tsx` : suppression du bouton surprise et du lien `/reseau` ; ajout de la grille de domaines cochables (état local + `recordSignal({ kind: "choix" })`), filtrage des visages par domaines cochés puis élargissement progressif.
- `UniverseVideoGrid.tsx` : le pied de carte devient un bouton d'ajout ouvrant un sélecteur de composition (`compositionsQuery`, création via `compositions`), insertion des places dans `composition_items` avec `slot_label` = libellé du domaine et pose d'une carte sur une place existante. Aucune migration : `composition_items` a déjà `slot_label`, `position` et `card_id`.
- Une place vide sans carte n'étant pas représentable en base (`card_id` obligatoire), les places à pourvoir sont conservées dans le `brief` structuré de la composition tant qu'aucune carte n'y est posée, puis converties en ligne réelle dès qu'une carte est choisie.
