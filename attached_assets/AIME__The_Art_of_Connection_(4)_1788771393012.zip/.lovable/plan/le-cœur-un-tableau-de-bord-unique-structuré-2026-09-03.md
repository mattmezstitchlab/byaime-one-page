# Le cœur : un tableau de bord unique, structuré

## 1. Correction — menu cœur caché dans la carte du Monde

Vérifié : la fenêtre « voir la carte » (`CardOverlay`) s'affiche en couche 70, alors que le menu du bouton cœur, rendu dans un portail Radix, reste en couche 60. Il s'ouvre donc réellement, mais derrière le voile de la carte.

Correction : remonter le menu du cœur au-dessus des fenêtres modales (couche supérieure à celle de l'overlay), pour toutes ses utilisations — carte du Monde, Réseau, page carte. Aucun changement de comportement, uniquement l'ordre d'empilement.

## 2. Ce qui est dispersé aujourd'hui (constat)

Pages qui parlent des mêmes objets : `/tableau-de-bord`, `/parametres`, `/ma-carte`, `/projets`, `/rencontres` (compositions), `/bureau`, `/messages`, `/aimes-recues`, `/credits`, `/saisons`, `/profil`, plus les panneaux AI et ME du dock. Chacune a son hero, sa navigation, ses compteurs. Le même projet se pilote depuis trois endroits.

## 3. Principe : le cœur devient la console

Le tableau de bord devient une interface d'application (style Vercel), pas une page de contenu :

```text
┌──────────────────────────────────────────────────────────┐
│  AI + ME     Vue · Semaine · Recherche AIME      profil  │  ← barre haute
├───────────────┬──────────────────────────────────────────┤
│ MOI           │                                          │
│  Ma carte     │            Zone de travail               │
│  Mes cartes   │        (le contenu de la section)        │
│ FAIRE         │                                          │
│  Projets  ▸   │                                          │
│  Compositions │                                          │
│  Semaines     │                                          │
│ ÉCHANGER      │                                          │
│  Messages     │                                          │
│  Aimes        │                                          │
│ ARGENT        │                                          │
│  Bureau   ▸   │                                          │
│  Crédits      │                                          │
│ RÉGLAGES  ▸   │                                          │
├───────────────┴──────────────────────────────────────────┤
│  mini-carte Réseau   │   timeline globale (52 semaines)  │  ← barre basse
└──────────────────────────────────────────────────────────┘
```

- **Colonne de gauche** : toute l'arborescence du site, avec menus et sous-menus dépliables, compteurs (aimes non lues, documents à vérifier, paiements en attente). Elle remplace la capsule verticale, qui est masquée uniquement sur cette page sur ordinateur. Sur mobile, elle s'ouvre en feuille depuis un bouton, comme un burger.
- **Barre haute** : le champ AIME (même cœur, mêmes intentions), le sélecteur de semaine/portée (ma ville, 40 km, 100 km, ma région), l'accès au compte.
- **Zone de travail** : la section choisie s'affiche ici, sans quitter la page.
- **Barre basse** : mini-carte du Réseau (points à proximité, cliquables) et timeline globale des 52 semaines avec les places à pourvoir.

## 4. Fusion des pages — ce qui rentre, ce qui reste

**Absorbé dans le tableau de bord** (les routes existantes restent valides et affichent la même section, pas de doublon de code) :
- Paramètres → section Réglages
- Panneaux AI et ME du dock → sections « Ce qu'Aime propose » et « Ce qui est à moi » ; le dock ouvre désormais la section correspondante
- Crédits, Aimes reçues, Mes projets (liste), Compositions, Semaines, Bureau (aperçu) → sections
- Ma carte (aperçu et complétude) → section, l'édition complète reste sur sa page

**Restent des pages à part entière**, parce qu'elles sont publiques, immersives ou partageables : accueil, Le Monde AIME, Réseau, carte publique `/carte/$id`, page projet `/projets/$id`, Bureau détaillé (dossiers, export, membres), messages en conversation, Identity, guides, pages légales.

Aucune route n'est supprimée dans cette étape : elles pointent vers la bonne section du tableau de bord, ce qui évite les liens morts et permet de mesurer l'usage avant tout retrait.

## 5. Livraison en trois temps

1. Correction du menu cœur (immédiat).
2. Coquille du tableau de bord : barre haute, colonne gauche avec arborescence complète, zone de travail, masquage de la capsule sur cette page, version mobile.
3. Sections branchées sur les données déjà en place, puis mini-carte et timeline globale en bas.

## Détails techniques

- `AimeButton` : `PopoverContent` passe en `z-[90]` (au-dessus de `CardOverlay` en `z-[70]` et de `StoryViewer` en `z-[80]`).
- Nouveau `src/components/dashboard/` : `DashboardShell.tsx` (grille barre haute / colonne / zone), `DashboardNav.tsx` (sections issues d'une constante partagée avec `navigation.ts`), `DashboardMiniMap.tsx`, `DashboardTimeline.tsx`.
- `tableau-de-bord.tsx` : section pilotée par un paramètre de recherche `section` (validé par Zod), état conservé au rechargement et partageable.
- `AppShell` : prop pour masquer la capsule et le dock sur `/tableau-de-bord` en `md+`.
- Sections réutilisant les blocs existants (`AiPanel`, `MePanel`, contenu de `parametres.tsx`, `projets.index.tsx`, `saisons.tsx`, `bureau.index.tsx`) extraits en composants, sans duplication de requêtes.
- Mini-carte : réutilisation du composant carte du Réseau en mode réduit et non interactif ; timeline : `weeks.ts` + `openSlots.ts`.
- Aucune migration, aucune modification de `geo.ts`, aucun finding de sécurité traité.
