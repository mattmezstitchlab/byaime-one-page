# Quatre destinations, rien de plus

Oui, je comprends la direction — et je pense qu'elle est juste. Aujourd'hui le site a 57 fichiers de routes ; l'utilisateur n'a pas besoin d'en connaître plus de quatre.

## La structure cible

```text
1. Accueil          la promesse + le champ AIME
2. Le Monde AIME    l'actuelle page Réseau, renommée, avec 3 modes :
                    Carte · Grille (l'actuel /monde) · Liste
3. Ma page          /carte/$id — le profil, déjà à onglets
                    onglets : Présentation · Savoir-faire · Expériences
                              Calendrier · Avis · Radio · Contact
                              + Bureau (nouveau, si c'est ma carte)
                              + Mes projets / événements (nouveau, si c'est ma carte)
4. AI et ME         les deux panneaux, accessibles de partout via le dock
```

Tout le reste passe en pied de page ou disparaît des menus.

## Ce qui change concrètement

**Le Monde AIME devient le cœur.** La page Réseau est renommée « Le Monde AIME ».
Elle garde la carte géographique et gagne un sélecteur de mode en haut : Carte,
Grille (la grille universelle de `/monde`, déplacée telle quelle), Liste.
`/monde` redirige vers `/reseau?vue=grille`. Le champ du hero d'accueil continue
d'y mener — c'est bien la page la plus différenciante, une fois qu'elle absorbe
la grille.

**Le tableau de bord disparaît.** C'est un doublon d'AI + ME. `/tableau-de-bord`
redirige vers `/ma-carte`. Ce que la console apportait d'unique (crédits,
proposition du jour, semaine en cours) est réparti : les crédits et les réglages
dans ME, la proposition du jour dans AI.

**Le Bureau devient un onglet de ma page.** `/bureau` reste accessible en direct
(les liens existants ne cassent pas) mais n'apparaît plus dans la capsule ni le
menu : on l'ouvre depuis l'onglet « Bureau » de sa propre carte, et depuis ME.

**Mes projets deviennent un onglet.** Un onglet « Projets » sur ma carte liste
mes événements et ouvre le détail existant. `/projets` sort des menus.

**Le temps se joue sur la timeline.** La capsule Passé/Présent/Futur quitte le
haut de page (elle chevauche les titres, cf. la capture) et se pose sur la
barre de timeline elle-même, à gauche des marqueurs. Le bouton + du dock adopte
la couleur du temps choisi, comme aujourd'hui. Une seule place, un seul geste.

**La capsule de gauche passe à quatre portes :** Accueil · Le Monde AIME ·
Ma page · Radio. AI, ME et + restent dans le dock du bas.

## Ce qui part au pied de page

Saisons, Messages, Crédits, Réglages, Guides, Comment ça marche, Ambassadeur,
Bêta, Registre, Identity, Plan du site. Les routes restent vivantes, elles ne
prennent simplement plus de place dans la navigation.

## Détails techniques

- `reseau.tsx` : ajout d'un paramètre `vue: "carte" | "grille" | "liste"` aux
  search params existants ; la grille est extraite de `monde.tsx` en composant.
- Redirections 301 : `/monde` → `/reseau?vue=grille`, `/tableau-de-bord` →
  `/ma-carte`.
- `carte.$id.tsx` : deux clés de plus dans `TAB_KEYS` (`bureau`, `projets`),
  affichées uniquement quand la carte appartient à l'utilisateur connecté ;
  réutilisation de `BureauWindow` et des requêtes projets existantes.
- `TenseSwitch` déplacé dans `HeroTimeline` / `DashboardTimeline` ; retrait du
  rendu en tête de page.
- `PRIMARY_NAV` réduit à quatre entrées, `FOOTER_NAV` étoffé.
- Aucun changement de base de données, de RLS ni de sécurité.

## Ce que je ne fais pas

Aucune suppression de fichier de route : tout reste atteignable par URL. On
range, on ne détruit pas.
