# Cohérence globale des heroes — une seule grammaire de page

## Ce que j'ai compris

Chaque page du site doit s'ouvrir exactement comme le Registre :

1. Un visuel hero de **hauteur unique et fixe** (`h-[420px] md:h-[560px]`, déjà dans `PageHero`).
2. Le **titre de la page dans ce hero** (plus de titre posé dans le contenu, plus de sous-titre orphelin).
3. Quand la page a une entrée d'action ou de recherche, **la barre Aime (champ + bouton cœur + envoi) vit dans le hero**, sous le titre.
4. Le contenu commence en dessous, sur fond ivoire. Aucune vidéo d'ambiance derrière le contenu.

Cas cités : le Bureau doit afficher « Bureau financier & administratif / Dépose. Je lis, je classe, je te dis ce qui manque. » dans le hero et perdre la vidéo de nuages en fond ; Ma carte doit remonter son titre et poser le champ + cœur dans le hero.

## Liste des pages à rectifier

### A. Hero présent mais titre/sous-titre à remonter, ou fond parasite
- **Bureau** (`bureau.index`, `bureau.dossier/$id`, `bureau.projet/$id`, `bureau.membres`, `bureau.export`, via `BureauWindow`) : titre du hero → « Bureau financier & administratif », baseline « Dépose. Je lis, je classe, je te dis ce qui manque. » ; suppression de la vidéo ciel et du voile bleu derrière la fenêtre ; la fenêtre du Bureau reste, posée sur l'ivoire.
- **Ma carte** : titre remonté, ajout de la barre Aime dans le hero (décrire sa carte / importer / dicter), le bloc Aime actuellement sous le hero disparaît au profit de celui du hero.
- **Rencontres**, **Tableau de bord**, **Messages**, **Projets**, **Aimes reçues**, **Crédits**, **Paramètres**, **Guides**, **Comment ça marche** : vérification du duo eyebrow/titre, suppression des titres redondants répétés en tête de contenu.
- **Rencontres**, **Tableau de bord**, **Messages**, **Projets**, **Aimes reçues**, **Crédits**, **Paramètres**, **Guides**, **Comment ça marche** : vérification du duo eyebrow/titre, suppression des titres redondants répétés en tête de contenu.
- **Page carte** (`carte/$id`) : utilise déjà `HERO_HEIGHT` mais un rendu maison — aligner sur `PageHero`.

### A-bis. Pages volontairement SANS hero (exceptions assumées)
- **Annuaire / Carte réseau** (`reseau`) : la carte reste **plein écran comme aujourd'hui**, sans visuel hero. Recherche et filtres restent en surimpression sur la carte. Les pages immersives échappent à la règle du hero.
- `auth`, `legal/$doc`, `admin.enrichissement`, routes API.

### B. Pages sans hero du tout (à créer)
- `evenements` — Événements
- `mon-evenement`, `evenement/$` — L'événement
- `projets.nouveau` — Nouveau projet (avec barre Aime : décrire le projet)
- `projets/$id` et ses onglets (facture, paiements, participants, musicbox) — hero du projet
- `profil` — Mon profil
- `demande-profil` — Demander un profil (avec barre Aime)
- `invitation` — Invitation
- `devis/$cardId` — Devis
- `guides/$metier/$ville` — guide ville/métier
- `intermittent` — cockpit intermittent (utilise `HERO_HEIGHT` sans `PageHero`)
- `carte/$id/timeline` — Timeline de la carte
- `credits`, `parametres` déjà OK

## Bouton Retour global

Aujourd'hui rien ne permet de revenir à l'écran précédent : on doit refaire tout le parcours. Ajout d'un bouton **Retour** en **haut à gauche de chaque page**, carte réseau plein écran comprise.

- Pastille ronde discrète avec flèche gauche, lisible sur visuel comme sur fond ivoire.
- Revient à l'écran précédent de l'historique du routeur ; sans historique (lien partagé, arrivée directe) il ramène à l'accueil.
- Masqué sur l'accueil.
- Rendu une seule fois dans `AppShell` : jamais dupliqué page par page, et il ne recouvre ni le logo ni la capsule verticale.

### C. Pages avec champ Aime dans le hero (barre unique)

## « Comprendre AIME en 40 secondes » — nouvelle démo produit

Les quatre clips de la mariée qui explique (`intro-a/b/c/d`) sont remplacés par une **démonstration réelle du site**, en quatre chapitres d'environ 10 secondes :

1. **Créer ma carte, de A à Z** — champ Aime dans le hero, choix univers/sous-univers, ville, photo, carte publiée.
2. **Créer une équipe** — composition, invitations, participants qui rejoignent.
3. **La timeline vivante** — survol d'un repère, aperçu, actions contextuelles (réserver, devis, facture).
4. **Le Bureau** — dépôt d'une facture, lecture par Aime, classement, score et rapprochement devis → facture → paiement.

Production : captures d'écran réelles du site prises par script (Playwright) sur des données de démonstration, enchaînées en vidéo (ffmpeg) avec zoom léger, curseur animé et fondus, puis sous-titre de chapitre en français. Avantage sur une vidéo générée : ce que l'on montre est exactement ce que l'utilisateur verra, et la démo se régénère quand l'interface évolue.

`SiteIntro` garde sa mécanique actuelle (enchaînement, points de progression, bouton « Passer l'introduction ») ; seuls les fichiers de clips et les libellés de chapitres changent. Les anciens assets `intro-*.mp4` restent utilisés là où ils servent de souvenir (timeline de démonstration) ou sont retirés s'ils ne servent plus.

### C. Pages avec champ Aime dans le hero (barre unique)
Accueil (déjà), Registre (déjà), Ma carte, Nouveau projet, Créer une équipe / participants, Demande de profil, Bureau (dépôt + question à Aime), Messages (nouvelle conversation).

## Détails techniques

- `PageHero` reste la seule source de hauteur (`HERO_HEIGHT`) : aucune variante en `vh` ni en ratio natif.
- Ajout d'une prop `subtitle` à `PageHero` pour la baseline sous le titre (cas Bureau), rendue en `text-background/85`.
- `AimeField` réutilisé tel quel avec `tone="dark"` dans les heroes ; chaque page ne change que le comportement au `onSubmit`.
- `BureauWindow` : suppression de `bureau-sky.mp4` et du calque `bg-sky-950/20` ; conteneur en `bg-background`.
- Les pages sans visuel dédié réutilisent les assets existants (`visual-*.jpg`, vidéos d'univers) plutôt que d'en générer de nouveaux.
- Aucun changement de base de données, aucune nouvelle route.

## Ordre d'exécution

1. `PageHero` (prop `subtitle`) + Bureau (hero, suppression vidéo) + Ma carte (titre + champ).
2. Bouton Retour global dans `AppShell`, testé sur `reseau` plein écran.
3. Pages sans hero (liste B), une passe par famille : événements, projets, profil/invitations, guides/intermittent.
4. Nouvelle démo « AIME en 40 secondes » : captures des quatre parcours puis montage.
5. Passe de cohérence : suppression des titres dupliqués et vérification visuelle des heroes page par page.
