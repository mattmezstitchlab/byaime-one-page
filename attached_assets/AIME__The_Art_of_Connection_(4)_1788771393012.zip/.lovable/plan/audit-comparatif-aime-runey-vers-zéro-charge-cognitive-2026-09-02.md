# Audit comparatif AIME ↔ Runey — vers zéro charge cognitive

Analyse faite sur runey.app (rendu réel) et sur notre accueil (rendu réel, desktop 1280px).

## Ce que Runey fait et que nous ne faisons pas

| Runey | AIME aujourd'hui |
|---|---|
| Titre + sous-titre + 3 CTA visibles en 1 seconde | Grand vide ivoire, aucun titre au-dessus de la ligne de flottaison, un seul champ flottant en bas |
| Une démo produit visible immédiatement (vidéo dans un cadre, contrôlée par l'utilisateur) | Film d'intro plein écran noir qui s'impose avant le site |
| Un chemin unique : « Start for free » | 5 entrées de menu + capsule latérale (cœur, radio, messages, dossier, profil, langue) + champ Aime, tous au même niveau d'importance |
| Un parcours raconté étape par étape (Client → Brief → Devis → Contrat → Projet → Facture) | Fonctions puissantes mais jamais mises en récit sur l'accueil |
| Preuve sociale (témoignages, « featured on »), prix, FAQ | Aucune preuve, aucun prix, aucune FAQ sur l'accueil |
| Menu réduit : Features / FAQ / Pricing / Updates | Menu en majuscules, jargon interne (Composer, Registre, Intermittents) |

## Détails relevés que nous n'avions pas listés

1. **L'intro film bloque la première impression.** À l'ouverture : écran noir plein page, seul « Passer l'introduction » est cliquable. C'est le pire endroit pour mettre une vidéo. Runey met la même énergie dans une démo *à l'intérieur* de la page, jouable au clic.
2. **Le hero d'accueil est vide.** La vidéo de fond ne s'affiche pas toujours (fallback absent) : il reste une grande zone ivoire sans texte, puis le champ de saisie tout en bas. Le titre « Chacun a sa carte » n'arrive qu'après la timeline.
3. **La bande timeline (2026/2027/2028) apparaît en gris** avant chargement et coupe la page en deux sans qu'on comprenne à quoi elle sert.
4. **11 vidéos d'univers chargées d'un coup** sur l'accueil : poids énorme, cartes blanches tant que ça n'a pas chargé, aucun visuel de repli.
5. **Le bandeau cookies s'ouvre par-dessus le contenu** en même temps que l'intro et la capsule : trois sollicitations simultanées.
6. **La capsule latérale a 6 icônes sans libellé.** Un visiteur ne peut pas deviner cœur / radio / messages / dossier / profil.
7. **Vocabulaire interne** : Composer, Registre, Réseau, Intermittents. Runey nomme les choses par leur usage (Invoices, Projects, Clients).
8. **Pas de piste de sortie** : aucun « Comment ça marche » visible, aucune FAQ, aucun tarif alors que crédits et factures existent déjà dans le produit.
9. **Pas d'image de partage** : notre accueil n'a pas d'og:image comme Runey (og-image 1920×1008).
10. **Aucun état vide guidé** sur les écrans clés — le visiteur non connecté arrive sur des listes sans première action évidente.

## Ce qu'il faut reprendre (et ce qu'il ne faut pas)

À reprendre : la hiérarchie d'un seul message + un seul CTA, la démo produit en ligne, le récit du parcours, la preuve sociale, la clarté du menu.
À ne pas reprendre : leur look SaaS générique. Notre identité ivoire, cartes, cœur, Aime reste la différence — on garde l'émotion, on enlève le brouillard.

## Plan en 3 passes

### Passe 1 — Enlever la charge (accueil)
- Intro film : ne plus la lancer automatiquement. La déplacer dans la page sous forme de lecteur « Voir AIME en 40 secondes », ou la limiter à la toute première visite avec fondu court et sortie au moindre clic.
- Hero : titre « Le réseau des bonnes rencontres » + une phrase + le champ Aime + un seul bouton « Créer ma carte », le tout centré et visible sans scroll. Image de repli derrière la vidéo pour ne jamais avoir de vide.
- Cookies : n'apparaître qu'après la fin de l'intro, jamais superposé.
- Timeline : la descendre sous le hero, avec un titre explicite, et un fond ivoire au lieu du gris.

### Passe 2 — Rendre lisible
- Univers : poster/image de repli sur chaque carte, chargement paresseux, lecture vidéo seulement au survol.
- Capsule : libellés au survol + libellés visibles sur mobile.
- Menu : renommer en langage d'usage (Carte réseau, Créer une équipe, Annuaire, Mes projets), garder Intermittents dans le pied de page.
- Ajouter sur l'accueil : bloc « Comment ça marche » en 5 étapes (Carte → Cœur → Aime compose → Rencontre → Événement), 3 témoignages, tarifs/crédits, FAQ courte.

### Passe 3 — Finitions
- og:image dédiée + titres/descriptions uniques par route.
- États vides guidés sur Registre, Réseau, Bureau, Mes projets.
- Passage mobile complet sur accueil, réseau, ma carte, bureau.
- Contrôle de poids : mesure du chargement de l'accueil avant/après.

## Détails techniques

Fichiers concernés : `src/routes/index.tsx`, `src/components/aime/SiteIntro.tsx`, `IntentionHero.tsx`, `HeroTimeline.tsx`, `UniverseVideoGrid.tsx`, `AppShell.tsx`, `CookieBanner.tsx`, `SiteFooter.tsx`. Les vidéos d'univers passent en `preload="none"` + `poster`, chargées via IntersectionObserver. L'intro devient un composant appelé à la demande plutôt qu'un overlay monté à la racine.
