# Le Monde AIME : une page d'entraide, et une seule barre en bas

## 1. La barre du bas ne se décroche plus

Aujourd'hui la page d'un projet remplace la barre commune (Chercher · Le fil · Réseau · Documents · Échanges · Ma page) par une autre barre (Personnes · Argent · Documents · Le jour J · Veille · Échanges). D'où l'impression d'une barre « décrochée », doublée par la petite pastille flottante du Studio qui vient se poser dessus.

Correction :

- Une seule barre, toujours au même endroit et toujours collée en bas.
- Sur une page de projet, elle garde ses boutons communs et ajoute, sur la même ligne, un bouton **Projet** qui déplie vers le haut les portes du projet : Personnes, Argent, Documents, Le jour J, Veille.
- La pastille du Studio remonte au-dessus de la barre, elle ne la recouvre plus.
- La page réserve la bonne hauteur en bas pour que le dernier bloc ne passe jamais sous la barre.

## 2. « Publier dans le registre » disparaît

Le bouton est remplacé par **« Demander de l'aide au Monde AIME »**, visible pour la personne qui porte le projet.

## 3. La page de l'association : `/le-monde-aime`

Une page publique, dans le style du site : ce qu'est l'association, puis les projets qui ont besoin d'aide, avec un filtre par ville, par monde et par type de besoin.

Chaque projet publié s'y présente en une carte : le titre, la date, le lieu, **pourquoi** il a besoin d'aide, ce qui est demandé, ce qui est déjà réuni, et l'échéance. Ouvrir la carte mène à la page du projet.

### Ce qu'on peut demander (les quatre à la fois)

- **Un coup de main** : des bras, une compétence, une présence un jour donné.
- **Un prêt** : matériel, lieu, transport — daté, avec retour prévu.
- **Une promesse de don** : un montant annoncé, réglé plus tard, hors du site.
- **Un don d'argent** : réglé en ligne, encaissé par l'association, avec reçu.
- **Une mise en relation** : le besoin est exposé, on répond par les échanges du site.

Chaque besoin est une ligne avec une quantité et une échéance ; on voit d'un coup d'œil « 3 sur 8 » et il ne reste plus que ce qui manque.

### La demande, côté projet

Un formulaire court, en une fenêtre : le motif (pourquoi cette aide change quelque chose), les besoins ligne par ligne, l'échéance, et une case à cocher qui engage la personne sur l'exactitude de ce qu'elle déclare. Rien n'est publié tant que la demande n'est pas complète.

### La validation

Deux temps :

1. **Contrôle de complétude** — motif, besoins, échéance, et une vérification de cohérence (échéance passée, montant absent, projet vide) : tant que ça manque, la demande reste en brouillon.
2. **Validation de la marraine de l'association** — la demande arrive dans un espace dédié où elle est acceptée, renvoyée avec une remarque, ou refusée. Une demande de don d'argent passe systématiquement par cette validation ; le nom de la marraine et la date de validation apparaissent sur la carte publiée, ce qui donne son sérieux à la page.

Un projet refusé peut être corrigé et renvoyé.

### Ce qui se passe ensuite

- Chaque geste (un coup de main proposé, un prêt accepté, une promesse, un don) devient **un moment sur la ligne de temps du projet** — jamais une donnée à part.
- La personne qui aide reçoit une notification et retrouve ses engagements dans « Mon espace ».
- Le porteur du projet remercie en un clic ; le remerciement peut devenir une publication au fil.
- Quand tout est réuni, la carte passe en « besoin couvert » et sort de la liste d'appel, sans disparaître de l'historique.

### Confidentialité

Aucun montant privé n'est exposé : seul ce que le porteur choisit de rendre public apparaît. Les coordonnées passent par les échanges du site.

## Détails techniques

- `AppShell.tsx` / `GlobalDock.tsx` / `ProjectPanels.tsx` : suppression de la seconde barre fixe, `PanelBar` devient un menu « Projet » dans `GlobalDock` (via `dockPresence` qui transporte les portes du projet au lieu de masquer la barre commune) ; `Studio` remonte au-dessus (`bottom` + hauteur du dock).
- Nouvelle route `src/routes/le-monde-aime.tsx` avec `head()` propre (titre, description, og/twitter), plus `src/lib/aime/commons/*` pour les requêtes.
- Base : réutilisation de `help_requests` (déjà présente) enrichie des colonnes manquantes — projet lié, motif, échéance, statut de validation, validateur, date de validation — et d'une table de lignes de besoin (type, libellé, quantité demandée/réunie, montant). GRANT + RLS : lecture publique des seules demandes validées, écriture réservée au porteur, validation réservée au rôle de modération.
- Dons d'argent : passage par le module de paiement déjà branché ; l'encaissement va à l'association, la ligne de temps ne fait que tracer.
- Chaque engagement écrit une entrée dans la ligne de temps existante et une notification, sans nouveau modèle parallèle.
- Vérification navigateur ordinateur + téléphone, puis contrôle des types.
