# Ordre des plans + Cartes de mémoire (DMC, Jésus)

## Ce que montre la capture

Oui, je comprends. Sur `/reseau` en mode Carte + Mosaïque, trois blocs se battent :

- le menu du bouton `+` s'affiche **sous** le panneau blanc de la mosaïque ("Aucune carte ne correspond à ces filtres") ;
- la barre de vues (Carte · Liste · Mosaïque · Filtres · Éphémères) est recouverte par ce même panneau ;
- le dock AI · + · ME et la RadioBar se croisent en bas.

Cause vérifiée : deux échelles d'altitude cohabitent. Les composants d'interface partagés (menus, tiroirs, boîtes de dialogue) sont à `z-50`, tandis que les pages ont inventé des valeurs libres — `z-[400]`, `z-[410]`, `z-[420]`, `z-[460]`, `z-[600]`, `z-[650]`, `z-[700]`, `z-[1000]`. Un menu ouvert depuis le dock passe donc derrière un panneau de page. Ce n'est pas un bug local : c'est l'absence d'échelle commune.

## Étape 1 — Une seule échelle d'altitude pour tout le site

Créer une échelle nommée, unique, et l'appliquer partout :

```text
contenu            0      la page
chrome flottant    20     capsule latérale, boutons flottants
panneaux de page   30     liste Réseau, mosaïque, plateau, compteurs
barre radio        40
dock AI · + · ME   50
menus & bulles     60     menus du cœur, coup d'œil, aperçus Monde
tiroirs & modales  70     filtres, composeur, devis
plein écran        80     StoryViewer, intro du site
```

Chaque page perd ses valeurs improvisées. Les composants partagés (menu, tiroir, dialogue) montent de `z-50` à l'étage « menus & modales » pour rester au-dessus du dock et des panneaux.

## Étape 2 — Corriger la composition de `/reseau`

- La mosaïque en mode Carte ne démarre plus au ras de la barre de vues : elle laisse la barre respirer et devient un panneau déroulant sous les contrôles.
- Le message « Aucune carte » ne s'affiche plus comme grand bloc blanc plein cadre : il vit dans le panneau, à sa taille.
- Le menu du `+` et le coup d'œil passent au-dessus de tout panneau de page.

## Étape 3 — Vérification sur tout le site

Passer chaque page où plusieurs couches coexistent : accueil, Monde, Réseau, carte universelle, projets, Bureau, Radio, calendrier. Contrôle en desktop et en mobile, dock ouvert et menu ouvert, pour confirmer qu'aucun panneau ne masque un menu.

---

# Audit — La carte DMC, et la carte de Jésus

## Pourquoi ces deux cartes ne sont pas des exceptions

AIME repose sur une carte universelle : un nom, une identité, une timeline passé · présent · futur, une fréquence. Rien dans ce modèle n'exige que le titulaire soit vivant, ni humain. Une maison, une œuvre, une invention, une figure historique peuvent porter une carte, à une condition : **la carte doit dire d'où vient chaque information**. Le site distingue déjà Déclaré · Documenté · Estimé. C'est exactement l'outil dont ces deux cartes ont besoin.

Je propose donc un type de carte **Mémoire** : carte non revendicable, pas de contact, pas de devis, timeline uniquement documentée, chaque moment portant sa source.

## Carte 1 — DMC (Dollfus-Mieg et Compagnie)

Sources de vérité identifiées et hiérarchisées :

1. **Primaires** — Archives municipales de Mulhouse (fonds DMC, petit musée DMC), Musée de l'Impression sur Étoffes de Mulhouse (planches, livres d'échantillons), nuanciers officiels DMC publiés par la marque, publications historiques de la maison dont l'*Encyclopédie des ouvrages de dames* de Thérèse de Dillmont, éditée par DMC.
2. **Institutionnelles** — dossier patrimoine de la Ville de Mulhouse sur l'aventure DMC, inventaire du site industriel de Dornach.
3. **Secondaires** — encyclopédies et presse régionale, utilisables pour le récit, jamais pour un chiffre.

Faits solides pour la timeline (à horodater avec source visible) : fondation à Mulhouse en 1746 par Jean-Henri Dollfus ; naissance de Dollfus-Mieg et Cie autour de 1800 avec Daniel Dollfus et Anne-Marie Mieg ; deux métiers, l'impression sur étoffes et le fil à broder ; cotation à Paris en 1922 ; fusion avec Thiriez et Cartier-Bresson en 1961 ; friche et reconversion du site de Mulhouse aujourd'hui.

Ce que la carte apporte de spécifique : **le nuancier**. Chaque référence de fil devient une couleur nommée, et la grille du Monde AIME est déjà une grille de point de croix. La carte DMC peut donc offrir une palette officielle réutilisable par les cases du Monde — sous réserve d'un point juridique traité plus bas.

Point de vigilance : les numéros et noms de coloris, les nuanciers imprimés et la marque appartiennent à l'entreprise. La carte peut citer, décrire, renvoyer vers le nuancier officiel ; elle ne peut pas republier un nuancier complet comme s'il était libre, ni se présenter comme une source officielle. Statut par défaut : **Documenté, non affilié**.

## Carte 2 — Jésus

Ici, le sujet n'est pas la vérité religieuse mais la méthode. AIME n'a pas à trancher une question de foi ; il doit montrer d'où vient chaque élément.

Structure proposée :

- **Déclaré** — ce que les textes affirment, cités comme textes : évangiles, épîtres, textes apocryphes, avec référence précise.
- **Documenté** — ce que les sources extérieures mentionnent : Flavius Josèphe, Tacite, Pline le Jeune, ainsi que le consensus historien sur l'existence d'un prédicateur juif de Galilée exécuté sous Ponce Pilate.
- **Interprété** — traditions, doctrines, lectures divergentes, chacune attribuée à qui la porte.

Règles de tenue : aucune date présentée comme certaine quand elle est débattue, aucun score, aucune note, aucune hiérarchie entre confessions, et une fréquence narrative plutôt qu'un chiffre — comme pour toute carte de personne. Les contributions restent des entrées de timeline sourcées, soumises à modération.

Ce que cette carte prouve : si AIME sait tenir une carte de Jésus sans dogmatisme et sans confusion des registres, il sait tenir n'importe quelle carte d'héritage — un métier, une abbaye, un village, une famille.

## Ce que j'implémenterais dans un second temps

Rien de tout cela n'est construit dans cette passe : d'abord l'ordre des plans, ensuite le type Mémoire, la citation de source obligatoire sur chaque moment, et enfin les deux cartes de démonstration.

## Détails techniques

- Nouvelle échelle d'altitude centralisée (constantes + classes), suppression des valeurs libres dans les pages et alignement des composants partagés.
- Aucune migration de base, aucune dépendance ajoutée dans cette passe.
- Vérification par capture de chaque page avec dock ouvert et menu ouvert.
