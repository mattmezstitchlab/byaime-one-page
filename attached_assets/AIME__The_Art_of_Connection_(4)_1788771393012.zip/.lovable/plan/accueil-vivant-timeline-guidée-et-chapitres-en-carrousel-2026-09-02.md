# Accueil vivant, timeline guidée et chapitres en carrousel

## 1. Bug de superposition sur les pages universelles

La bande d'onglets de la carte (`CardTabs`) est collante au même niveau que la capsule de navigation de gauche, et comme elle vient après dans la page, elle passe par-dessus.

- Faire redescendre la bande d'onglets sous le niveau « chrome » de l'échelle d'altitude (`src/lib/aime/layers.ts`), la capsule et le bouton retour restent toujours visibles.
- Vérifier au passage les autres bandes collantes du site (Monde, Réseau, Registre, Bureau, Projets) pour qu'aucune ne dépasse la capsule.

## 2. Timeline : défilement doux et gestes montrés

Sur l'accueil (et partout où la timeline est en mode démonstration) :

- Défilement lent et continu vers la gauche, qui s'arrête dès que la personne touche, survole ou fait défiler, et repart après quelques secondes d'inactivité.
- Une flèche animée se déplace d'un repère à l'autre et ouvre le petit bloc au survol, comme si quelqu'un montrait la ligne. Elle disparaît dès la première interaction réelle.
- Un indice de geste discret : deux flèches qui s'écartent (pincer pour élargir) puis une main qui glisse (déplacer la ligne), affichés deux ou trois fois puis oubliés.
- Tout est désactivé si la personne a demandé des animations réduites.

## 3. Section « Comment ça marche » de l'accueil

- Suppression des cartes 01 à 05 et du fil rouge courbe (`HowItWorksDiagram` retiré de l'accueil et de la page Comment ça marche).
- À la place : un carrousel horizontal des vrais chapitres de la page Comment ça marche — capture d'écran, numéro et titre du chapitre, sous-titre court et un petit bouton qui mène directement au chapitre.
- Flèches précédent/suivant, glissement au doigt, points de progression, et le bouton « Voir plus » conservé sous le carrousel.

## 4. Vidéo de 40 secondes

- Retrait du bouton et du lecteur « Voir la visite en 40 secondes » sur la page Comment ça marche (et de toute autre entrée vers cette visite), ainsi que des mentions « 40 secondes » dans les textes et métadonnées.
- Les chapitres de la visite restent : ils alimentent le carrousel et la page.

## 5. Les douze mondes qui défilent

- La grille des univers de l'accueil devient une bande qui défile lentement vers la gauche, en boucle continue.
- Pause au survol et au focus clavier, glissement manuel possible, lecture de la vidéo d'un univers au survol comme aujourd'hui, animations réduites respectées.

## 6. FAQ et page Programme Bêta

- FAQ de l'accueil réécrite et complétée : gratuité et crédits, Le Monde AIME et prendre sa place, la Fréquence et la Radio, le Bureau et l'export comptable, les trois temps, le bisou d'entrée et l'empreinte, la confidentialité des coordonnées, les langues.
- Page `/beta` mise à jour : parcours conseillé aligné sur le site réel (carte, Monde, timeline, Bureau, fréquence), mention du rituel d'entrée, et retrait des étapes devenues obsolètes.

## Détails techniques

- `src/components/aime/CardTabs.tsx` : niveau collant abaissé sous `Z.chrome` ; audit `rg` des `sticky` + `z-` restants.
- `src/components/aime/HeroTimeline.tsx` : dérive `autoScroll` renforcée, curseur fantôme piloté par `requestAnimationFrame` qui réutilise l'état de repère épinglé/survolé existant, calque d'indices de gestes ; garde `prefers-reduced-motion`.
- Nouveau `src/components/aime/ChapterCarousel.tsx` alimenté par `TOUR` + les chapitres additionnels ; ces derniers sont extraits de `src/routes/comment-ca-marche.tsx` vers `src/lib/aime/tour.ts` pour une source unique.
- Nouveau défilement en boucle dans `src/components/aime/UniverseVideoGrid.tsx` (duplication de la liste + translation CSS/rAF).
- `src/routes/index.tsx` : diagramme remplacé par le carrousel, FAQ réécrite.
- `src/routes/comment-ca-marche.tsx` : `SiteIntro` et diagramme retirés, textes et `head()` mis à jour.
- `src/routes/beta.tsx` : étapes et textes actualisés.
- `src/components/aime/SiteIntro.tsx` reste dans le dépôt mais n'est plus référencé, ou est supprimé si plus aucun appelant.
