# Taxonomie propre à chaque entrée + nettoyage de l'en-tête

## Ce que l'audit montre (vérifié dans le code)

- Le rond arc-en-ciel en haut à droite est le lien « ID » vers `/identity`, posé dans l'en-tête global.
- Le verso des mondes affiche bien un sous-menu par entrée, mais la liste des cases à cocher vient de `domainsFor(monde, entrée)` : seules **5 entrées sur 73** ont une liste propre (`evenement/mariage`, `anniversaire`, `bapteme`, `ceremonie`, `naissance`). Toutes les autres retombent sur la liste **du monde entier**.
  C'est exactement ce que montrent vos captures : « Immobilier vente » et « Location de matériel » proposent la même liste Patrimoine (Estimation, Visite & état des lieux, Juridique & notaire…). Vous avez raison, ce n'est pas acceptable.
- Même défaut sur la question posée en bas du panneau : `questionFor` tire une question dans le jeu **du monde**, choisie par un hachage du nom de l'entrée. Elle est donc stable mais pas pertinente pour l'entrée.
- Le panneau lui-même (cases, visages, retenue, « Ajouter à la composition ») fonctionne et n'a pas besoin d'être refait.

## Ce que je fais

### 1. En-tête
Retirer le rond arc-en-ciel « ID » de l'en-tête. `/identity` reste accessible par le menu AIME et le plan du site (j'ajoute l'entrée au menu si elle n'y est pas).

### 2. Une taxonomie propre à chacune des 73 entrées
Écrire, entrée par entrée, 8 à 14 domaines dans le vocabulaire réel du métier, avec leurs mots-clés de rapprochement aux cartes. Aucune entrée ne retombe plus sur la liste générique du monde.

Exemples du travail attendu :

```text
patrimoine/immo-vente     Estimation · Diagnostics · Notaire · Courtier & prêt ·
                          Home staging · Photo & visite 3D · Agence & mandat ·
                          Travaux avant vente · Fiscalité · Déménagement
patrimoine/materiel       Sono & lumière · Mobilier & tables · Vaisselle ·
                          Tentes & chapiteau · Froid & cuisine · Scène & praticables ·
                          Groupe électrogène · Livraison & montage · Caution & assurance
musique/festival          Programmation · Billetterie · Sécurité & SSIAP · Scène & structure ·
                          Son · Lumière · Loges & catering · Bénévoles · SACEM & droits ·
                          Camping & accueil public
table/cave                Vin · Champagne · Bière & brasserie · Spiritueux · Sommelier ·
                          Accord mets-vins · Dégustation · Verrerie · Livraison & reprise
```

Le même soin est appliqué aux 12 mondes : Événement, Musique, Culture, Entreprise, Lieux, Table, Image, Style, Patrimoine, Voyage, Lien, Solidarité.

### 3. La question posée devient elle aussi propre à l'entrée
Un jeu de questions rattaché à `monde/entrée` (budget, délai, formule, nombre de personnes selon le sujet), avec repli sur le monde uniquement si l'entrée n'en définit pas — ce qui, après ce travail, ne concernera plus personne.

### 4. Vérification de bout en bout
Passage sur les 12 versos, entrée par entrée, pour confirmer : liste différente à chaque entrée, cases mémorisées par entrée, compteur juste, « Ajouter à la composition » qui reprend bien l'ensemble des cases cochées de la carte. Correction de tout écart constaté au passage.

## Détails techniques

- `src/components/aime/AppShell.tsx` : suppression du lien ID en conic-gradient.
- `src/lib/aime/domains.ts` : `DOMAINS_BY_SUB` complété pour les 73 clés `monde/entrée` issues de `universeTree.ts`. `DOMAINS_BY_UNIVERSE` conservé comme filet de sécurité.
- `src/lib/aime/taxonomy.ts` : ajout de `QUESTIONS_BY_SUB` et priorité sur `QUESTIONS_BY_UNIVERSE` dans `questionFor`.
- Aucun changement de base de données, aucun changement de sécurité.
- Vérification : typecheck, puis parcours réel des versos dans le navigateur.
