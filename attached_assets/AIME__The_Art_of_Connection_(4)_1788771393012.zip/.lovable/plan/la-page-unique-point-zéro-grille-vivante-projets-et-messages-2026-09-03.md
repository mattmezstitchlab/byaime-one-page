# La page unique : point zéro, grille vivante, projets et messages

Tout se joue désormais sur la page carte. Six chantiers, dans l'ordre.

## 1. Le point zéro : cœur rouge, menu caché, timeline des documents

- Le bouton cœur du point zéro prend le rouge des autres cœurs du site (même pastille pleine, même ombre), au lieu du bouton clair actuel.
- Le menu d'import ne s'ouvre plus au-dessus de la vidéo en gros panneau : il reste replié, discret, et ne se déploie qu'au clic — la vidéo reste lisible.
- Le Bureau complet disparaît de cette section. À la place, la même timeline que sur le héros, mais ne portant que les documents (factures, devis, justificatifs, contrats), posée sur le fond vidéo.
- Un curseur au centre de cette timeline, avec un picto dossier ouvert : le cœur lit ce qu'on dépose et écrit un récapitulatif structuré (nature, parties, date, montant, dossier proposé) juste au-dessus du curseur ; on clique le dossier pour confirmer — il se ferme, le document est rangé, la timeline se met à jour.

## 2. La grille : la page en miniature à droite

- Au clic sur une case, le panneau de droite montre d'abord le héros de la page cliquée en miniature (carrousel univers, nom, ville, savoir-faire) — une vraie mini-page, pas une fiche texte.
- Onglet « Sa timeline » : sa timeline est superposée à la nôtre, à l'échelle exacte, en deux couches. On voit d'un coup d'œil ce qui est possible (créneaux libres des deux côtés) et ce qui ne l'est pas.
- Cliquer un créneau de la superposition prépare un message ou une demande pré-remplie avec la date, dans les onglets « Écrire » / « Demander ».

## 3. Sélection multiple

- « Déposer une intention » est retiré.
- Restent « Créer un projet » et un nouveau « Ajouter à un projet » (choix parmi les projets existants).
- Les deux mènent directement à la section Projets plus bas dans la page, sans changer de page.

## 4. La section Projets, sous la bande des univers

- Le mécanisme visuel de la map (cercles regroupés avec les chiffres, zoom, éclatement) mais sans fond de carte : juste les cercles sur un plan libre.
- Chaque personne est une pastille qu'on glisse d'un cercle à l'autre : tables, équipes, groupes d'invités, pôles. Les cercles se renomment, se créent, se suppriment.
- Le nombre affiché sur chaque cercle suit le glisser-déposer en direct, et l'état est enregistré sur le projet.

## 5. Les messages en bloc à droite

- Les fonctions de la page Messages (liste des fils, fil ouvert, envoi, pièces jointes) reprises en un bloc latéral de la page, à droite de la section Projets.
- Le même bloc sert la grille : écrire depuis une case ouvre le fil ici.

## 6. Audit : quelles pages supprimer

Une fois le reste en place, passage sur toutes les routes du site pour livrer une liste en trois colonnes :
- à supprimer (contenu entièrement absorbé par la page unique),
- à garder en redirection (ancien lien, ancienne URL partagée, référencement),
- à garder telles quelles (pages publiques, légales, guides, authentification).

Aucune page n'est supprimée sans cette liste validée.

## Détails techniques

- `HeartMenu` : variante `tone="aime"` pour le bouton rouge, et ouverture repliée par défaut (`compact`) — le panneau d'actions se monte au clic.
- `ZeroPoint` : `BureauSection` remplacé par `HeroTimeline` alimentée par `documentsQuery` (repères `kind: "document" | "devis" | "facture"`), plus un curseur central `DocFolderCursor` branché sur `ingestFile` : la sortie de `analyzeDocument` devient un récapitulatif structuré confirmable.
- `GridPanel` : onglet « page » = mini-héros (`UniverseCarousel` en petit format) ; onglet timeline = deux `HeroTimeline` superposées en absolu partageant la même fenêtre temporelle, la nôtre en dessous, la sienne en surimpression translucide.
- `WorldGridSection` : barre de sélection — retrait du lien intention, ajout d'un sélecteur « Ajouter à un projet » (`projectsQuery`), les deux poussent vers `#projets` via `scrollIntoView`.
- Nouveau `ProjectCircles` : SVG plein écran, regroupement par cercle, zoom molette avec ancrage curseur (facteur exponentiel, listener non passif), glisser-déposer par Pointer Events. Persistance des groupes sur `project_roles` (champ groupe) ou une colonne JSON du projet — à confirmer au moment de l'écriture.
- Nouveau `MessagesPanel` : extraction du corps de `src/routes/messages.tsx` en composant réutilisable, la route devenant une simple enveloppe.
- Pas de changement de schéma prévu hors éventuel champ de groupe pour les cercles de projet.
