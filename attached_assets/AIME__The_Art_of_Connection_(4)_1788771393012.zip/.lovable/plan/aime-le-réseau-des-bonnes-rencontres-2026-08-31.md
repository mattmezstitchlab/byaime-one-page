# AIME — Le réseau des bonnes rencontres

Application universelle de mise en relation par cartes, avec comptes, base de données et IA entremetteuse. Univers de démarrage : Mariage + Événement d'entreprise / concert.

## Direction artistique

- Fond ivoire très légèrement chaud, noir profond typographique, gris subtils.
- Typographie sans-serif type SF Pro (Inter Tight / system-ui en fallback), hiérarchie stricte.
- Coins très arrondis, verre translucide léger, ombres diffuses quasi imperceptibles.
- Animations spring, micro-interactions silencieuses, aucune surcharge, aucun gradient criard.
- Design system complet : typographie, espacements, cartes, boutons, badges, avatars, surfaces IA, navigation, modales, sheets, tags, filtres, états (normal, hover, pressed, selected, liked, matched, verified, unavailable, recommended), états vides et de chargement.

## La carte AIME

Composant central décliné par catégorie (personne, professionnel, entreprise, organisme, lieu, service, ressource, événement) : visuel, nom, métier, ville, tags d'univers, note, badge de statut, bouton AIME.

- Retournement 3D recto/verso fluide.
- Bouton AIME : cœur ♡ → ♥ avec animation douce, puis choix d'intention (J'aime, Collaborer, Réserver, Recommander, Associer, Contacter, Enregistrer) via une feuille très épurée.
- Statuts vivants : disponible, indisponible, nouveau, vérifié, populaire, recommandé, en relation avec…

## Pages

1. **Accueil** — logo AIME, navigation (Découvrir, Rencontres, Registre, Compositions), accroche « Tout commence par une rencontre. », grande zone IA « Que souhaitez-vous créer ? », cartes flottantes légèrement superposées.
2. **Découvrir** — galerie intelligente : grande carte centrale, cartes secondaires autour ; pile 3D légère en desktop, plein écran avec gestes horizontaux en mobile. Actions : AIMER, PASSER, OUVRIR, ASSOCIER.
3. **Rencontres** — rencontres proposées par l'IA : paires/trios de cartes, score de compatibilité, raisons (zone, style, disponibilité, expérience), boutons AIMER / VOIR LA RENCONTRE.
4. **Registre** — navigation hiérarchique univers → pays → région → ville → catégorie, plus filtres et recherche. Catégories : Personnes, Professionnels, Organismes, Lieux, Services, Ressources, Événements.
5. **Compositions** — plan de composition (« Mon mariage ») avec emplacements Lieu / Traiteur / Photographe / Musique / Fleuriste, lignes fines de relation, assemblage magnétique, bouton OPTIMISER piloté par l'IA. Combos AIME (Émotion, Réception, Party) présentés comme des cartes empilées.
6. **Profil / Ma carte** — carte personnelle premium, recto (photo, nom, ville, profession, univers) et verso (présentation, compétences, expériences, disponibilités, portfolio, relations, avis, préférences, statistiques). Édition progressive, jamais de long formulaire.
7. **Connexion / Inscription** — écran sobre, email + mot de passe, création automatique de la carte personnelle.

## Backend (Lovable Cloud)

Activation de Lovable Cloud pour : comptes, base de données, stockage des visuels, fonctions serveur IA.

Tables principales : `profiles`, `cards` (avec catégorie, univers, localisation, statuts, médias), `card_media`, `taxonomy` (univers / catégories / lieux extensibles), `aimes` (carte → carte ou utilisateur → carte, avec intention), `encounters` (rencontres générées par l'IA + score + explication), `compositions` et `composition_items`, `reviews`. RLS sur chaque table : lecture publique des cartes publiées, écriture réservée au propriétaire ; rôles dans une table `user_roles` séparée avec fonction `has_role`.

Données de démonstration insérées en migration : ~30 cartes sur l'univers Mariage (Lille / Hauts-de-France) et ~15 sur l'univers Événement d'entreprise & concert.

## IA entremetteuse

Fonctions serveur appelant Lovable AI :

- **Analyse d'intention** : transforme « Je cherche un mariage élégant de 80 personnes à Lille… » en critères structurés (localisation, budget, date, style, nombre, besoins, contraintes).
- **Composition de rencontres** : sélectionne les cartes compatibles, produit un score et une explication en langage naturel.
- **Optimisation** : propose une meilleure combinaison géographique et budgétaire pour une composition.
- **Apprentissage progressif** : les AIME et refus de l'utilisateur affinent les propositions suivantes.

L'IA n'apparaît jamais comme un chatbot classique : champ conversationnel minimal, révélation progressive des recommandations, erreurs de service affichées clairement.

## Détails techniques

- TanStack Start, routes dédiées par page, métadonnées SEO propres par route.
- Tokens de design dans `src/styles.css` (@theme, oklch), composants réutilisables dans `src/components/aime/`.
- Animations avec Motion for React (spring, retournement 3D, parallaxe légère, blur dynamique).
- Gestes mobiles pour la pile de cartes de Découvrir.
- Taxonomie stockée en base et extensible : mariage, anniversaire, événement, concert, entreprise, culture, association, voyage, rencontre, naissance, cérémonie.

## Ordre de réalisation

1. Design system + composant Carte AIME (recto/verso, bouton AIME, intentions).
2. Activation Cloud, schéma, RLS, données de démonstration, authentification.
3. Accueil + Découvrir.
4. Fonctions IA + Rencontres.
5. Registre.
6. Compositions + combos + OPTIMISER.
7. Profil / carte personnelle, polissage des micro-interactions.
