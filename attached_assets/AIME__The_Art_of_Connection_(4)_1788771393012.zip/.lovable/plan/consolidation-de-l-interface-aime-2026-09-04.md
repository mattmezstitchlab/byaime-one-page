# Consolidation de l'interface AIME

Objectif : moins de portes, moins de boutons, moins de pictogrammes. Aucune nouvelle fonctionnalité.

## 1. Un seul header global

- Suppression de la capsule verticale flottante à gauche (desktop) et du second menu burger mobile.
- Nouveau header : `AIME ▾` à gauche (le logo mène à l'accueil, la flèche ouvre le menu système), `Réseau` et `Mes projets` au centre, `Radio`, `♥ Aimes` (avec le nombre de non-lus) et `Mon espace` / `Connexion` à droite.
- Le Bureau disparaît de la navigation ; il reste dans le menu AIME pour les personnes qui y ont droit.
- À 390 px : `AIME ▾ … ♥ ○`, Réseau et Mes projets passent dans le menu AIME.

## 2. Fin du bouton « Modifier » global

Retiré du header. La modification devient contextuelle : sa page depuis `/ma-page`, un projet depuis ses propres outils.

## 3. Menu du logo AIME

Six entrées au plus : Comment ça marche · Démo : un mariage · Aide & retours · Plan du site · Langue · Bureau (si droits). Rien d'autre.

## 4. Un seul système de retours

- Suppression du bouton flottant « Un retour ? ».
- La feuille de retours s'ouvre uniquement depuis AIME → Aide & retours, avec un choix simple à l'entrée : « Signaler un problème » ou « Partager une idée ».

## 5. Pied de page réduit

Seulement les mentions réglementaires (mentions légales, confidentialité, CGU/CGV, cookies, accessibilité, médiation, contact) et le copyright. Plus de seconde navigation.

## 6. Capsule temporelle du projet

- Le bouton « Aujourd'hui » quitte la ligne de temps et rejoint la capsule : `[ ▶ ] [ Aujourd'hui | Tout | Avant | Pendant | Après ]`.
- « Aujourd'hui » recentre sur maintenant et revient au zoom par défaut, sans changer la phase active.
- Le repère « Aujourd'hui » dessiné sur la règle reste en place.
- Sur téléphone la capsule défile horizontalement, les calques restent accessibles par un bouton discret « Calques ».

## 7. Play simplifié

Menu réduit à : « Lire le temps affiché », « Le jour J », « Récit », puis « Arrêter ». Disparaissent : Photos, Vidéos, Audio, Musique, Souvenirs (ce sont des calques), Tout / Cette journée / Cette semaine (c'est la capsule) et « Créer un film… ». Play lit ce qui est visible.

## 8. Grammaire des pictogrammes

- `♥` = AIME, `▶` = lecture du temps, le reste = nature réelle de l'objet.
- Suppression des étoiles décoratives et des actions « Demander à AIME » dans les bulles de la timeline (le cœur reste la seule porte IA).
- Chaque étoile porteuse de sens est remplacée par l'icône de sa fonction (lieu, personne, date, photo, musique, repas, document, paiement, idée), prises dans la bibliothèque d'icônes du projet, sans emoji.
- Relecture complète des icônes de la timeline pour vérifier qu'aucune n'est décorative ni redondante.

## 9. Ce qui ne bouge pas

Le moteur `WorldProject` → `ProjectStage` → timeline → calques → panneaux reste la source de vérité. Les routes anciennes gardent leurs redirections mais n'apparaissent nulle part dans la navigation. Mon espace reste une grille simple. `/bureau` et les fonctions de sécurité de la base ne sont pas touchés. `FilmComposer` n'est plus exposé mais son fichier est conservé.

## Détails techniques

- `src/lib/aime/navigation.ts` réécrit : `HEADER_NAV`, `SYSTEM_MENU`, `BUREAU_ITEM`, `FOOTER_LEGAL` remplacent `PRIMARY_NAV`, `CONSOLE_NAV_ITEMS`, `NAV_SECTIONS`, `FOOTER_NAV`.
- `LogoMenu.tsx` : logo + popover système (langue intégrée, Bureau conditionné par `useIsAdmin`). `MobileMenu.tsx` supprimé après vérification des imports.
- `AppShell.tsx` : header unique, capsule retirée, bouton « Modifier » retiré.
- `feedbackSheet.ts` (nouveau canal d'événement, même modèle que `radioSheet.ts`) ; `FeedbackSheet.tsx` perd son bouton flottant et gagne le choix problème / idée.
- `HeroTimeline.tsx` : bouton « Aujourd'hui » retiré, nouvelle prop `recenter` (jeton) pour recentrer et remettre `pxPerDay` à 1.2 ; `KIND_ICON.intention` ne sera plus `Sparkles`.
- `ProjectStage.tsx` : capsule Aujourd'hui + phases, action « Demander à AIME » retirée, `visibleMarkers` transmis à Play.
- `PlayButton.tsx` : trois lectures + Arrêter.

## Vérifications

Typecheck, puis parcours Playwright à 1280 px et 390 px : navigation (logo, menu, Réseau, Mes projets, Mon espace, Radio, Aimes), projet (timeline, capsule, recentrage, Play, calques, cœur, clic sur un point), retours (aucun bouton flottant), et parcours de création `/` → brouillon → `/projets/:id` sans passage par `/demo/mariage`.

## Audit final

Compte rendu chiffré : portes principales, systèmes de navigation, de timeline, d'IA visible, de feedback, boutons flottants, composants devenus orphelins, routes anciennes encore exposées.
