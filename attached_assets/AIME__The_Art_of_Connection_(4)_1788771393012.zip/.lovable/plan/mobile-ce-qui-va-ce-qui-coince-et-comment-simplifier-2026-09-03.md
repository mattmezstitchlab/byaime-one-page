# Mobile : ce qui va, ce qui coince, et comment simplifier

## État constaté (mesuré à 390 px de large)

Test automatisé sur Accueil, Le Monde AIME, Réseau, Ma carte, Tableau de bord, Bureau, Rencontres, Saisons, Messages, Projets :

- Aucune page ne déborde horizontalement : la largeur de défilement est exactement celle de l'écran sur les 10 pages. Pas de scroll latéral parasite.
- Les seuls éléments qui dépassent sont à l'intérieur de carrousels prévus pour glisser (chapitres d'accueil, timeline 52 semaines).
- Le menu burger mobile existe et remplace bien la capsule verticale (masquée sous 768 px).

Donc : le site est correctement responsive au sens technique. Ce qui gêne sur téléphone, c'est l'encombrement du bas d'écran et la densité, pas la mise en page.

## Les 4 vrais problèmes mobiles

1. **Trois barres flottantes empilées en bas.** Le dock AI · + · ME (bas 24 px), la barre Radio (bas 64 px) et le bouton Retour bêta (bas 104 px) occupent simultanément le tiers inférieur de l'écran et se recouvrent partiellement quand la radio est allumée.
2. **Aucune gestion de la zone sûre iOS.** Rien n'utilise les marges système : sur iPhone, le dock passe sous la barre d'accueil et devient difficile à toucher.
3. **Cibles tactiles trop petites** sur la timeline 52 semaines du tableau de bord (14 px de large par semaine) et sur certains chips de filtres.
4. **Menu burger trop long** : il déroule toutes les sections du site alors que la simplification retenue ne garde que sept portes.

## Ce que je propose (mobile = version simplifiée, pas version réduite)

### A. Un seul étage flottant en bas
- Sur mobile, fusionner en une **barre unique** : à gauche l'accès Radio (mini-état lecture), au centre le bouton « + » de création, à droite le cœur Tableau de bord avec la pastille de non-lus.
- La barre Radio complète ne s'ouvre qu'au tap sur l'icône radio, en feuille glissante, au lieu de rester affichée.
- Le bouton « Retour bêta » quitte le flottant sur mobile et rejoint le menu burger et le pied de page.
- Les panneaux AI et ME s'ouvrent en feuille plein écran plutôt qu'en popover.

### B. Zone sûre et confort tactile
- Ajouter les marges système (`env(safe-area-inset-bottom)`) à la barre unique et aux feuilles.
- Passer toutes les cibles interactives à 44 px minimum de hauteur ; sur la timeline 52 semaines, mode mobile en 13 semaines par saison avec défilement par saison plutôt que 52 colonnes de 14 px.

### C. Menu burger aligné sur les sept portes
- En haut : Accueil, Le Monde AIME, Réseau, Ma carte, Tableau de bord, Bureau, Radio.
- Le reste (guides, bêta, identité, ambassadeur, plan du site, mentions) passe dans un bloc « Aller plus loin » replié.

### D. Hero et densité
- Hero mobile plus court (hauteur réduite, titre en 28 px) pour que le champ AIME soit visible sans défiler.
- Sur le tableau de bord console, la navigation latérale reste en feuille ; ajouter une barre d'onglets glissante en haut pour changer de section en un geste.

## Détails techniques

- Nouveau composant `MobileBottomBar` rendu par `AppShell` sous `md`, remplaçant `AimeDock` + `RadioBar` + bouton `FeedbackSheet` sur cette taille ; le comportement desktop reste identique.
- `RadioBar` gagne une variante « feuille » (Sheet) pour mobile, même état et même provider audio.
- Utilitaire CSS `pb-safe` dans `src/styles.css` pour les marges système.
- `MobileMenu` consomme `PRIMARY_NAV` + `CONSOLE_NAV_ITEMS` en premier niveau, `NAV_SECTIONS` replié.
- `DashboardTimeline` : rendu par saison sous `md`, colonnes 44 px.
- `PageHero` : hauteur et typographie mobiles réduites, sans changement desktop.
- Aucune modification de base de données, de RLS ni de sécurité. Aucune route ajoutée ou supprimée.

## Vérification

Reprise du test automatique 390 px sur les 10 pages (zéro débordement), plus contrôle visuel du bas d'écran radio allumée / éteinte.
