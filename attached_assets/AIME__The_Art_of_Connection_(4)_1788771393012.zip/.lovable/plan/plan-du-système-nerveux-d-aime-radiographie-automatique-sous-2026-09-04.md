# Plan du système nerveux d'AIME — radiographie automatique sous le Hero

Avant toute chose, voici l'analyse réelle demandée (livrable 17). Tout ce qui suit vient de mesures faites dans le code du projet, pas d'une interprétation.

## A. Ce qui existe réellement (nœuds détectés)

34 fichiers de pages. En retirant les pages techniques (MCP, sitemap, aperçu d'e-mails, consentement OAuth, `.well-known`, webhook de paiement) :

- **Pages vivantes** : Accueil `/`, Réseau `/reseau`, Mon espace `/mon-espace`, Personne `/carte/$id`, Monde/Projet `/projets/$id`, Démo mariage `/demo/mariage`, Connexion `/auth`, Crédits `/credits`, Guides (`/guides`, `/guides/$metier/$ville`), Invitation, Demande de profil, Légal `/legal/$doc`, et le Bureau (dossier, projet, membres, export).
- **Redirections** (14 fichiers ne contenant qu'une redirection) : `/messages`, `/projets`, `/projets/nouveau`, `/projets/$id/facture`, `/projets/$id/paiements`, `/projets/$id/participants`, `/projets/$id/musicbox`, `/evenements`, `/evenement/*`, `/registre`, `/monde`, `/ma-page`, `/bureau` (redirection interne), consentement OAuth.

## B. Connexions réelles relevées

Liens de navigation effectivement écrits dans le code, par destination :
`/carte/$id` 19 · `/mon-espace` 10 · `/projets/$id` 7 · `/bureau` 7 · `/` 6 · `/reseau` 5 · `/auth` 5 · `/monde` 3 · `/ma-page` 3 · `/legal/$doc` 3 · guides 3 · dossier bureau 3 · démo 2 · crédits 2 · export 2.

## C. Dépendances importantes (nombre de fichiers qui les utilisent)

`lib/utils` 103 · `hooks/useAuth` 36 · `lib/aime/queries` 29 · **`components/aime/HeroTimeline` 24** · `lib/aime/types` 20 · `AppShell` 14 · `lib/bureau/queries` 10 · `lib/aime/visuals` 9.

**La Timeline est bien centrale techniquement** : 24 modules en dépendent (calques, filtres, relations, audit, rétroplanning, Play, automatisations, accueil, personne, projet). C'est le deuxième vrai carrefour du site après l'authentification.

**HeartAgent, en revanche, n'est pas central** : seulement 3 endroits le touchent (`carte/$id`, `ProjectStage`, `AiPanel`). L'ambition « HeartAgent = intelligence et action » n'est pas encore vraie dans l'architecture.

## D/E. Legacy et redirections

Les 13 redirections listées en A sont l'ancienne architecture (Projets, Messages, Registre, Événements, Monde, Ma page). Elles seront affichées comme telles, en périphérie, jamais au cœur.

## F. Déséquilibres constatés

- **Liens morts fonctionnels** : 3 liens pointent vers `/monde` et 3 vers `/ma-page`, qui ne sont plus que des redirections. Ils fonctionnent mais font faire un détour.
- **Modules jamais importés** (~20 hors interface de base) : `ExplorationPanel`, `panels/CardConsole`, `ai.functions`, `cardCapabilities`, `console`, `domains`, `intermittent.functions`, `openSlots`, `radioIntent.functions`, `weeks`, `world/wedding`, `bureau/export`, `hooks/useMyPage`, l'ancien système de traduction `lib/i18n`. À confirmer un par un (certains sont peut-être appelés par chemin relatif) avant de conclure.
- **Systèmes parallèles** : Play et Radio coexistent autour de la musique ; `lib/aime/play/film` et `play/narrate` ne sont plus appelés.

## G→J. Méthode de génération automatique

Aucun trait ne sera dessiné à la main. Un petit module d'analyse lit, **à chaque construction du site**, les fichiers de `src/` et en déduit : les routes (nom de fichier), les redirections (présence d'une redirection et sa cible), les liens de navigation (`to="…"`), les imports entre fichiers, et le nombre d'utilisateurs de chaque module. Le graphe obtenu est figé dans le site au moment de la construction : coût nul pour le visiteur, et remise à jour automatique dès que l'architecture change. Trois degrés d'honnêteté sur les relations : **certaine** (import ou redirection écrits noir sur blanc), **détectée** (lien de navigation), **probable** (source de données partagée) — chaque relation affiche comment elle a été trouvée.

## La section sur l'Accueil

Placée juste sous le Hero, sobre, beaucoup d'air, titre « Plan du système nerveux » et une phrase : *voici comment AIME est réellement relié aujourd'hui*.

```text
        ┌── Utilisateur ─── Système ──┐   (deux lectures)

              Réseau ── Personne ── Timeline ── Monde
                 │          │          │         │
             Mon espace ── Cœur ──── Bureau ── Documents
                 ·          ·
             (legacy en périphérie, en pointillés)

   26 pages vivantes · 13 redirections · 24 modules sur la Timeline
```

- **Vue utilisateur** : uniquement les pages et les chemins réellement empruntables.
- **Vue système** : ajoute les modules partagés, les dépendances et l'ancien monde.
- Un nœud sélectionné se met au centre, ses relations s'allument, le reste s'estompe ; un panneau donne ses chiffres réels (routes, composants partagés, sources, nombre de connexions) et un bouton **Ouvrir** quand la page est réellement destinée au visiteur.
- Pastilles : cœur, dépendance forte, doublon, orphelin, legacy — attribuées par le calcul, pas à la main.
- Indicateurs chiffrés dessous, seulement ceux qui se calculent : pages vivantes, redirections, pages isolées, modules non utilisés, liens vers une redirection, dépendances les plus lourdes. **Aucun score global inventé.**
- Mobile : pas de carte réduite, mais la même matière en liste repliable par famille, avec les mêmes pastilles et le même panneau de détail.
- Animations discrètes, respect de la réduction de mouvement.

Rien du site n'est déplacé, fusionné ni supprimé dans ce chantier.

## Détails techniques

Plugin Vite `aime-graph` exposant un module virtuel `virtual:aime-graph` : lecture de `src/routes/**` et `src/{components,lib,hooks}/**` au démarrage et au build, extraction par expressions régulières (routes, `throw redirect({ to })`, `to="…"`, imports `@/` et relatifs), calcul du degré entrant/sortant, classification des nœuds par seuils explicites documentés dans le code. Sortie typée `SystemGraph { nodes, edges, metrics }`, consommée par un nouveau `src/components/aime/home/SystemMap.tsx` (SVG, disposition en anneaux par famille, surbrillance par état React) monté dans `HomeJourney.tsx` sous le Hero. Aucune dépendance ajoutée, aucune migration de base de données, aucune route touchée.
