# Uniformisation des heroes, bande des 12 mondes, dock AI · + · ME global

## 1. Heroes à hauteur unique (règle non négociable)

- `PageHero` reçoit une hauteur **fixe en pixels**, identique partout : conteneur `h-[560px]` (mobile `h-[420px]`), média en `absolute inset-0 h-full w-full object-cover`, titre superposé en bas centré.
- Suppression de toutes les hauteurs locales en `vh` : `IntentionHero` (accueil), `carte/$id`, `intermittent`, `QuoteHero`.
- L'accueil garde le même cadre ; seule différence autorisée : le champ Aime superposé.
- La page carte garde sa timeline noire directement sous le visuel, sans agrandir le média.

## 2. Accueil — 12 mondes en bande horizontale

- Le titre « Onze mondes à explorer » devient « Douze mondes à explorer ».
- `UniverseVideoGrid` devient une **bande horizontale** : défilement automatique lent (marquee en boucle), stoppé au survol/toucher, et défilement manuel (drag + molette + flèches clavier), scrollbar masquée.
- Gain de hauteur : une seule rangée de cartes vidéo au lieu d'une grille de 4 rangées.
- Chaque carte garde son titre d'univers et sa flèche vers le registre filtré.

## 3. Dock AI · + · ME sur tout le site

Aujourd'hui il n'existe que sur `/tableau-de-bord`. Il est extrait dans un composant global `AimeDock`, monté dans `AppShell`, donc visible **en bas au centre de chaque page**, avec `AiPanel` (gauche) et `MePanel` (droite).

Répartition définitive, sans doublon — chaque entrée n'existe qu'à un seul endroit :

**« + » — créer (verbes d'action uniquement)**
- Une carte, un projet, une équipe/composition, un éphémère
- Déposer un document au Bureau, un devis, une facture
- Prendre l'antenne (radio)

**Panneau gauche « AI » — tout ce qui vient d'Aime**
- Conversation Aime (champ + cœur, identique au hero) : source d'entrée unique
- Ce qu'elle propose maintenant : combinaisons, cartes à associer, dates croisées
- Mémoire d'Aime (ajouter / oublier)
- Crédits AI restants, consommation, historique
- Journal des actions faites par Aime (devis généré, relance, rapprochement)

**Panneau droit « ME » — tout ce qui m'appartient**
- Identité : ma carte, mes disponibilités
- Mes projets, mes événements, mes aimes reçues
- Mes documents / Bureau, budget et trésorerie en un coup d'œil
- Compte : coordonnées de versement, langue, notifications, paramètres, déconnexion

**Anti-doublon**
- La capsule verticale gauche reste la navigation entre *pages* ; ME liste des *états et raccourcis contextuels*, pas des pages déjà dans la capsule (les entrées dupliquées Mon espace / Tableau de bord sont retirées du header).
- Les crédits vivent uniquement dans AI (retirés de ME) ; les paramètres uniquement dans ME.
- Les actions de création disparaissent des panneaux : elles sont exclusivement dans « + ».

## Détails techniques

- Nouveaux fichiers : `src/components/aime/AimeDock.tsx` (dock + panneaux déplacés depuis `tableau-de-bord.tsx`), `src/components/aime/UniverseStrip.tsx` (bande, réutilise `UniverseTile`).
- `AiPanel` / `MePanel` sortent de `src/routes/tableau-de-bord.tsx` vers `src/components/aime/panels/`, la route les réutilise.
- Dock masqué quand un lecteur/overlay plein écran est actif (intro, StoryViewer) ; décalé au-dessus de la RadioBar sur mobile.
- Aucune modification de base de données.
