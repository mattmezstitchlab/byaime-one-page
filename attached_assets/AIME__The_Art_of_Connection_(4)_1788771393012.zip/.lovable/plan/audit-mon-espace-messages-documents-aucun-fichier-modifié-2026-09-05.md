# Audit — Mon espace, Messages, Documents (aucun fichier modifié)

Vérifié dans le code et dans les données réelles avant d'écrire ce rapport.

## 1 — État actuel de Mon espace

Une seule page, sept blocs empilés (354 lignes) :

| Bloc | Rôle | Source | Valeur réelle |
| --- | --- | --- | --- |
| Titre + intro | Accueil personnel | — | Faible |
| Mes mondes | Mes projets (8 max) | `events` (dont je suis propriétaire) | Forte |
| Ce qui m'attend | 4 pastilles : Aimes, Échanges, Crédits, Réglages | recalculé depuis les blocs du dessous | Moyenne : 3 pastilles sur 4 ne font que faire défiler la même page |
| Échanges | Messagerie complète | `threads` + `messages` | Forte, mais surdimensionnée ici |
| Aimes reçues | 12 dernières marques d'intérêt | `aimes` | Forte |
| Ma page publique | Aperçu + édition complète | `cards` + `PageSetup` | Forte |
| Documents | Dépôt, dossiers, « à vérifier » | `bureau_documents`, `bureau_folders` | Moyenne |
| Réglages | Ville, rayon radio, accessibilité, son, langue, export, mot de passe, déconnexion | `profiles`, `profile_geo`, préférences locales | Moyenne, mais mal placée |

Doublon confirmé : la langue existe déjà dans le menu AIME **et** dans les Réglages ; les pastilles « Aimes / Échanges / Réglages » ne sont que des ancres vers la même page.

## 2 — État actuel des messages

- Tables : `threads` (avec `card_id`, `aime_id`, `subject`, `title`, `kind`, `created_by`, `visio_url`), `messages` (`body`, `read_at`, `kind`, `attachment_url`, `attachment_name`, traduction), `thread_members` (`card_id`, `role_label`, `ai_delegate`), `thread_settings` (mode IA, ton, traduction).
- Interface : un seul composant, `ThreadsSection` (943 lignes), monté uniquement dans Mon espace. Les autres écrans (page personne, aperçu de carte, panneau IA) renvoient vers `/mon-espace#echanges`.
- Ce qui existe vraiment : conversations à deux et de groupe, pièces jointes (bucket `pieces-jointes`), non-lus, traduction automatique, copilote IA, lien de visio, annuaire pour démarrer une conversation.
- Ce qui n'existe pas : temps réel (rafraîchissement toutes les 5–8 s), recherche dans les conversations, notifications hors de la page.
- Données : 1 conversation, 4 messages, 1 membre. Rien n'est en production — la refonte est donc peu risquée.

## 3 — État actuel des documents

- `bureau_documents` : fichier dans le bucket `bureau`, plus des métadonnées riches (type, montants HT/TVA/TTC, échéance, paiement, confiance d'extraction, champs incertains).
- `bureau_folders` : un dossier peut pointer vers un projet (`event_id`) ou une personne (`card_id`) — 9 dossiers existent, dont 1 rattaché à un projet.
- `bureau_links` : relations entre documents (devis → facture).
- Visibilité : strictement privée au propriétaire ; `bureau_members` prévoit le partage mais n'est pas branché à l'interface.
- Affichage : `BureauPanel`, dans Mon espace (tout le compte) et dans un projet (filtré).
- **Aucun lien entre un document et une conversation aujourd'hui** : une pièce jointe de message est une simple URL dans `messages`, elle n'entre jamais dans la bibliothèque documentaire.

## 4 — Relations existantes

```text
PERSONNE ──< threads.card_id / aime_id >── CONVERSATION ──< messages
PERSONNE ──< bureau_folders.card_id >── DOSSIER ──< DOCUMENT
PROJET  ──< bureau_folders.event_id >── DOSSIER ──< DOCUMENT
PROJET  ── (aucun lien) ── CONVERSATION      ← manquant
CONVERSATION ── (aucun lien) ── DOCUMENT     ← manquant (pièce jointe orpheline)
MONDE   ── aucun lien avec conversations ni documents
```

## 5 — Les trois scénarios

**A — Minimal.** On range Mon espace, les Messages y restent.
Avantages : aucun risque. Inconvénients : la messagerie reste introuvable depuis le reste du site, la page reste longue. Impact données : nul.

**B — Messages globaux.** Un bouton Messages dans l'en-tête, à côté de Radio, ouvrant un panneau (liste, recherche, non-lus, nouvelle conversation). Mon espace redevient « ma vue personnelle ».
Avantages : accessible partout, page allégée, cohérent avec ce qui a déjà été fait pour la Radio. Inconvénients : il faut sortir `ThreadsSection` d'une page et la faire tenir dans un panneau. Impact données : **aucun** — mêmes tables. Risque : faible (1 conversation en base).

**C — Conversations contextuelles.** En plus de B : une conversation peut être rattachée à un projet ou un événement, et un document partagé dans une conversation reste retrouvable depuis le projet.
Ce que l'existant supporte déjà : rattachement à une personne (`card_id`), groupes (`thread_members`), pièces jointes.
Ce qui manquerait : une colonne `event_id` sur `threads`, et un lien pièce jointe → document (donc migration + règles de sécurité). Coût réel : moyen. Risque : introduire un second chemin de documents mal cadré.

## 6 — Recommandation

- **Les Messages doivent quitter Mon espace : oui.**
- **Devenir une fonction globale : oui**, un bouton dans l'en-tête à côté de Radio, même mécanique de capsule.
- **Documents dans les conversations : oui, mais plus tard** — d'abord relier la pièce jointe à la bibliothèque documentaire (un seul objet, plusieurs chemins), sans créer de second stockage.
- **Contexte d'une conversation : personne et groupe tout de suite** (déjà supportés), **projet dans un second temps** (une colonne à ajouter), **événement seulement si le besoin apparaît**.

Retenu : **scénario B maintenant, C par étapes ensuite.**

## 7 — Réglages dans le menu AIME (votre demande)

Aujourd'hui la langue est à deux endroits. Proposition : le menu AIME devient le seul endroit des réglages **du système** (langue, accessibilité : contraste, taille du texte, animations, liens soulignés, police lisible, plus le test du son). Restent dans Mon espace les réglages **du compte** : ville et rayon d'écoute, mot de passe, export de mes données, cookies, déconnexion.

## Ce que Mon espace deviendrait

Ma vue personnelle : mes mondes, ce qui m'attend (Aimes, échéances), mes Aimes reçues, ma page publique, mes documents, mon compte. Plus de messagerie, plus de réglages système.

## Prochaine étape proposée (à valider)

1. Bouton Messages dans l'en-tête + capsule de conversation réutilisant `ThreadsSection`, avec recherche et non-lus.
2. Retrait du bloc Échanges et de la pastille correspondante dans Mon espace ; les liens `#echanges` ouvrent la capsule.
3. Déplacement de l'accessibilité vers le menu AIME, suppression du doublon de langue.
4. Plus tard : lien conversation ↔ projet et pièce jointe ↔ document.

Aucun fichier n'a été modifié pendant cet audit.
