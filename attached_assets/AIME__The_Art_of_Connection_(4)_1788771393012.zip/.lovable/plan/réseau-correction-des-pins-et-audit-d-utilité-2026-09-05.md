# Réseau — correction des pins et audit d’utilité

## Constat vérifié

- Les vignettes photo individuelles déclenchent déjà un aperçu au survol et au clic.
- Les petits points noirs isolés possèdent également ce comportement.
- Les ronds noirs numérotés visibles sur la capture sont des **groupes de profils**. Ils ne gèrent actuellement que le clic pour zoomer : aucun aperçu n’est demandé au survol. C’est pourquoi la petite carte attendue n’apparaît pas dans la vue actuelle.
- La page charge déjà les profils, les intentions, les rencontres, les projets et la messagerie globale. Ces données peuvent être mieux reliées sans créer un second système.

## Correction immédiate

1. **Donner un vrai aperçu aux ronds numérotés**
   - Au survol, lire les profils contenus dans le groupe et afficher une bulle compacte avec quelques profils représentatifs.
   - Chaque ligne de la bulle sera cliquable pour ouvrir la page du profil correspondant.
   - Conserver le clic direct sur le rond pour zoomer et révéler les profils.
   - Ajouter un lien « Voir les N profils » qui zoome sur le groupe.

2. **Uniformiser toutes les interactions de carte**
   - Même langage visuel et même délai de fermeture pour vignette photo, point isolé et groupe.
   - Maintenir la bulle ouverte pendant le passage du pointeur du rond vers son contenu.
   - Sur mobile, remplacer le survol par un premier toucher qui ouvre l’aperçu ; les actions restent accessibles au toucher.
   - Garantir que la bulle reste dans l’écran et au-dessus de la carte, des contrôles et du panneau « À l’écran ».

3. **Fiabiliser le rendu**
   - Corriger l’écart d’affichage initial du compteur « À l’écran » constaté entre le chargement serveur et le navigateur.
   - Vérifier les groupes, les points isolés et les vignettes photo à plusieurs niveaux de zoom, sur ordinateur et mobile.
   - Vérifier dans le navigateur que chaque aperçu apparaît, reste atteignable et conduit au bon profil.

## Audit des innovations possibles

### Priorité 1 — Transformer la carte en moteur de mise en relation

**A. Résultats utiles autour d’un besoin** — valeur très forte, effort modéré  
Quand une personne publie « Je cherche… », afficher directement sur la carte les profils compatibles selon le lieu, le métier et l’univers déjà renseignés. La source reste le flux d’intentions existant ; la carte ne duplique rien.

**B. Composer une équipe pour un projet** — valeur très forte, effort faible  
Renforcer la sélection multiple déjà présente : sélection depuis les bulles et la carte, résumé clair de l’équipe, puis ajout au projet choisi. Le parcours existant « ajouter à un monde » devient compréhensible et directement opérationnel.

**C. Expliquer les liens du réseau** — valeur forte, effort faible  
Lorsqu’un profil est sélectionné, mettre en évidence ses connexions et indiquer pourquoi elles existent : rencontre commune ou projet partagé. Les traits déjà calculés deviennent une information utile plutôt qu’un simple décor.

### Priorité 2 — Accélérer la prise de contact

**D. Actions contextuelles dans chaque aperçu** — valeur forte, effort faible à modéré  
Réunir « Voir la page », « Écrire », « Demander un devis », « Voir les disponibilités » et « Ajouter au projet » dans la même bulle. Ces fonctions existent déjà ailleurs dans AIME ; il s’agit de les rendre accessibles au bon moment.

**E. Vue “mes AIME” et profils déjà rencontrés** — valeur moyenne à forte, effort faible  
Ajouter des filtres de carte fondés sur les signaux déjà enregistrés : profils aimés, déjà rencontrés, déjà présents dans un projet. Cela aide à retrouver plutôt qu’à seulement découvrir.

### Priorité 3 — Assistance intelligente, ensuite

**F. Suggestion AIME contextualisée** — valeur potentielle forte, effort élevé  
Depuis une sélection ou un besoin, ouvrir Studio AI avec le contexte courant pour suggérer une équipe ou signaler ce qui manque. Cette étape vient après les parcours déterministes ci-dessus afin que l’IA s’appuie sur une base claire et vérifiable.

## Recommandation produit

Pour cette intervention, implémenter la **correction complète des groupes au survol/toucher**, puis ajouter seulement les deux améliorations les plus directement liées à ce geste :

- des profils réellement cliquables dans l’aperçu du groupe ;
- les actions contextuelles existantes dans l’aperçu individuel.

Les autres innovations restent un ordre de développement recommandé, pas des fonctions ajoutées sans validation. La page reste une carte unique reliée aux données existantes, sans nouvelle route ni duplication.

## Contraintes respectées

- Interface et libellés en français.
- Aucun changement dans `/bureau`.
- Aucun changement des fonctions `SECURITY DEFINER`.
- Aucun nouveau stockage pour cette correction.
