# Phase 5 — L'accueil devient la première expérience AIME

Le storyboard est validé. Voici le plan d'exécution, confirmé après inspection du code existant.

## Ce qui existe déjà et sera réutilisé tel quel

- `readStory` (repérage immédiat d'une phrase : date, ville, lieu, invités, heure, prestataires cités)
- `readStoryAI` (lecture par AIME, côté serveur) et son cache `rememberReading` / `cachedReading`
- `projectFromReading` / `projectFromStory` → `buildWedding` : le seul constructeur de monde
- `deriveTimeline(project)` : la seule projection vers la ligne de temps
- `HeroTimeline` (points, survol, clic, bulle, `renderExtra`)
- `projectDraft` (`saveProjectDraft`, `loadProjectDraft`) et `persistValidatedProject`
- `AimeField` (champ d'intention unique)

Aucun second moteur ne sera créé. `journey.ts` est une couche **pure** : réponses → récit → lecture → `projectFromReading`.

## Ce qui sera construit

1. `src/lib/aime/world/journey.ts` — orchestration pure : les 6 étapes, la composition du récit, la fusion de la lecture locale et de la lecture IA, les mots d'ambiance entendus, les moments proposés (retirables), la synthèse finale, les manques.
2. `src/components/aime/home/MarkerReveal.tsx` — apparition progressive des points (reprend la mécanique de `TimelineGenesis`), désactivée si `prefers-reduced-motion`.
3. `src/components/aime/home/JourneyStep.tsx` — une question, le champ libre, les réponses rapides, « je ne sais pas encore », ignorer, précédent, et l'accès permanent au récit d'un coup.
4. `src/components/aime/home/HomeJourney.tsx` — le hero : film en fond, conversation au centre, ligne de temps ancrée en bas du début à la fin, micro-fiches au clic sur un point, synthèse et bouton « Entrer dans mon projet ».

## Le flux, à chaque réponse

```text
réponse
  ↓ (immédiat)
WorldProject brouillon  →  deriveTimeline  →  HeroTimeline
  ↓ (asynchrone, sans écran de chargement)
lecture AIME  →  même WorldProject enrichi  →  même timeline
```

Une information inconnue reste une donnée valide : la date ou le lieu « à définir » alimentent `missing` et les états `a_confirmer` / `manquant` déjà existants.

## Le passage au projet

`Entrer dans mon projet` → brouillon rangé → si connecté : création réelle puis `/projets/:id` ; sinon `/auth` (avec retour), reprise du brouillon, puis `/projets/:id`. Plus aucun passage par `/demo/mariage`, qui reste une démonstration indépendante et intacte.

## Nettoyage de l'accueil

Retrait de la section vitrine (`showcaseTimeline`, `TimelineDigest` sur l'accueil), du bloc « Aime réfléchit… », des cartes suggérées du hero et du lien `/demo/mariage?recit=`. `IntentionHero` et `TimelineGenesis`, utilisés uniquement par l'accueil, sont remplacés par le parcours ; `TimelineDigest` et `showcaseTimeline` ne sont retirés que de l'accueil.

## Détails techniques

- `journey.ts` : `JOURNEY_STEPS`, `JourneyAnswers` (dont la clé `libre` pour le récit d'un coup), `storyFromAnswers`, `readingFromAnswers`, `mergeReading`, `toneTags`, `proposedMoments`, `projectFromJourney`, `journeySummary`.
- `projectDraft.ts` : ajout d'un lecteur `loadAnyProjectDraft()` sur le même stockage, pour reprendre le brouillon après connexion.
- `auth.tsx` : paramètre de recherche `suite` pour revenir à l'accueil et finaliser le projet après connexion.
- Responsive : conversation prioritaire, timeline toujours visible, test explicite à 390 px.
- Accessibilité : navigation clavier, focus visible, `aria-label` sur les points, alternative au survol (clic), animations réduites si demandé.
- Tests Playwright : parcours complet, parcours avec inconnues, récit libre, clic sur un point, retour arrière, 390 px, connecté / non connecté.
- `roadmap.md` sera mis à jour avec cette phase dès le passage en construction.

## Livrable

À la fin : la liste des fichiers créés, modifiés, supprimés, les routes touchées, les tests exécutés et les anomalies restantes.
