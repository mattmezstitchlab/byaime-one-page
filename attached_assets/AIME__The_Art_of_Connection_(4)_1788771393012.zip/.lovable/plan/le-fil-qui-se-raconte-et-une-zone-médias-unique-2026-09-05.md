# Le fil qui se raconte, et une zone Médias unique

## 1. Les réactions du fil

- Plus de contour noir : les pastilles deviennent des ronds discrets, sans
  bordure marquée, gris très clair, et se teintent seulement quand c'est vous
  qui avez réagi.
- Les émoticônes système (❤️ 👏 😄 😮 🙏) laissent la place à des pictos
  modernes dessinés au trait, dans le même style que le reste du site :
  cœur, applaudissement, sourire, étonnement, merci.
- Le compte reste à droite du picto, en chiffres.

## 2. La radio raconte le fil

C'est la nouveauté principale. Le bouton radio propose désormais deux écoutes :

- **Musique** — l'écoute au hasard actuelle, inchangée.
- **Le fil** — l'animatrice lit le fil d'actualité, publication après
  publication, dans un ordre mélangé.

Comment se déroule une publication lue :

1. L'animatrice annonce l'auteur et la date à voix haute (« Camille, il y a deux
   heures »), puis lit le texte de la publication.
2. Si la publication contient une vidéo YouTube, un son ou une vidéo, la voix
   s'interrompt, le média se lance (30 secondes par défaut, ou jusqu'au bout si
   c'est court), puis la voix reprend et enchaîne.
3. Si c'est une photo, elle est affichée pendant que la voix décrit la légende.
4. Un lien d'article : la voix cite le nom du site et le titre.

Pendant la lecture, la barre radio se transforme en petite scène : la
publication en cours s'affiche (auteur, photo ou vidéo, texte qui défile), avec
une onde animée qui suit la voix, et les commandes Passer / Pause / Couper.
Un clic sur la carte ouvre la publication dans le fil.

## 3. La Mémoire Web, enfin visible

Elle existe mais elle est enfouie dans un panneau. On la remonte :

- Sur votre page, un bloc « Retrouver mon histoire » sous la ligne de temps,
  avec une phrase d'explication et un bouton « Chercher mes traces ».
- Un rappel discret quand la ligne de temps est presque vide.
- Visible pour vous seule (propriétaire de la page), jamais pour les visiteurs.

## 4. Une seule porte pour ajouter

Aujourd'hui il y a deux entrées : le bouton « Ajouter » (Musique / Souvenir)
posé au milieu de la page, et « Ajouter un média » dans la zone Médias. On les
réunit.

- Le bouton du milieu disparaît.
- La fenêtre « Ajouter » propose : Photo · Vidéo · YouTube · Audio · Lien ·
  **Musique** · **Souvenir**.
- Musique et Souvenir gardent exactement leur formulaire actuel (date, titre,
  message, fichier, recherche d'un morceau) — il s'affiche dans la même
  fenêtre, une fois le type choisi.
- Ce qui est daté part sur la ligne de temps, ce qui ne l'est pas reste dans
  les médias : rien n'est enregistré deux fois.

## 5. La zone Médias : plusieurs regards, plus de choix

Trois façons de regarder la même zone, choisies par un petit sélecteur en haut
à droite (le choix est retenu) :

- **Mur** — l'affichage actuel, grandes vignettes.
- **Mosaïque** — beaucoup de petites vignettes, tout tient à l'écran.
- **Ligne de temps** — les médias rangés par année, du plus ancien au plus
  récent, comme un album du passé.

Le menu « … » d'un média s'étoffe : Modifier le titre, Mettre en couverture,
Poser sur la ligne de temps (avec sa date), Publier dans le fil, Copier le
lien, Déplacer avant / après, Supprimer.

## 6. Le bouton Calques s'efface

Sur la ligne de temps, « Calques » devient un simple bouton rond avec le picto
de réglages, posé à droite de la règle. Le mot disparaît, la pastille de
comptage reste quand des calques sont désactivés, et le panneau qui s'ouvre ne
change pas.

## Détails techniques

- `src/lib/aime/social.ts` : `EMOJI_SIGNS` devient une table de composants
  lucide (`Heart`, `PartyPopper`, `Smile`, `Sparkle`, `HandHeart`) ; la valeur
  stockée en base (`reactions.emoji`) ne change pas, seul le rendu change.
  `ReactionBar.tsx` : `border-border` → `border-transparent bg-secondary/60`,
  état actif `bg-primary/10 text-primary`.
- Radio : `RadioProvider.tsx` gagne un `mode: "musique" | "fil"`. Le mode fil
  construit une file à partir de `feed.ts` (publications publiques récentes,
  mélangées), génère la voix par `speakNarration` (déjà en place,
  `openai/gpt-4o-mini-tts`), et alterne voix / média via l'`audioBus` existant
  pour garder un seul son à la fois. Les vidéos YouTube utilisent l'IFrame API
  dans la barre radio ; sinon `<audio>`/`<video>`.
  Nouveau composant `RadioStage.tsx` pour la scène, branché dans `RadioBar`.
  La narration est mise en cache par identifiant de publication (les crédits
  IA se paient à chaque appel).
- `WebMemory` : extrait de `TimelinePanel` et rendu aussi dans
  `carte.$id.tsx` sous la ligne de temps, derrière `isOwner`.
- `AddMediaDialog.tsx` : ajout des types `musique` et `souvenir`, qui montent
  le formulaire de `AddToTimeline` en mode intégré ; retrait du rendu
  `AddToTimeline` autonome dans `carte.$id.tsx`. Aucune duplication de logique
  d'écriture : `musicbox_entries` et `card_timeline_entries` restent les seules
  destinations.
- `MediaGrid.tsx` : état `view` (`mur` | `mosaique` | `chrono`) persisté en
  `localStorage`, tri par `taken_at`/`created_at` pour le mode chrono ;
  `MediaTile.tsx` : entrées supplémentaires du menu `…`.
- `TimelineLayers.tsx` : `size="icon"` arrondi, libellé en `sr-only`, badge de
  comptage ; les appelants (`carte.$id.tsx`, `ProjectStage.tsx`, démo) passent
  au nouveau placement à droite de la règle.
- Rien ne touche `/bureau` ni les fonctions `SECURITY DEFINER`.
