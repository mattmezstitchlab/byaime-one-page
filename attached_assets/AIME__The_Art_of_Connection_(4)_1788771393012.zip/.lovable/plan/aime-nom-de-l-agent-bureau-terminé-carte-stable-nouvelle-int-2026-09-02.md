# Aime : nom de l'agent, Bureau terminé, carte stable, nouvelle intro, audit complet

## 1. L'agent s'appelle « Aime »

Partout où l'interface dit « l'entremetteuse », « l'IA entremetteuse », « AI — l'entremetteuse », on écrit simplement « Aime ». Concerné : accueil, Composer/Rencontres, Messages, Tableau de bord, Crédits, Comment ça marche, Profil, Réseau, et les textes système de l'IA (elle se présente comme Aime). Les cinq langues sont mises à jour de la même façon.

## 2. Bureau : finir la colonne de gauche

- **Fichiers cliquables** : dans l'arborescence, chaque document devient un lien qui ouvre le document (aperçu + champs extraits), au lieu du texte inerte actuel.
- **« Non classés » en double** : la coquille du Bureau monte l'arbre deux fois (version mobile + version bureau). Selon la largeur, les deux peuvent s'afficher. On garde un seul arbre rendu à la fois, ce qui supprime le doublon.
- **Cohérence** : compteurs, glisser-déposer et menus (créer / renommer / supprimer) revérifiés après ce nettoyage.

## 3. Carte réseau : le survol qui « balaye » les vignettes

Les pastilles rondes sont des éléments HTML recréés à chaque rafraîchissement de la carte ; pendant ce court instant on voit les points noirs de la couche de fond. Correction : réutiliser les pastilles existantes (mise à jour par identifiant au lieu de tout détruire), ne pas reconstruire les pastilles sur simple survol, et masquer les points noirs partout où une vignette est affichée. Le survol garde son léger agrandissement, sans clignotement.

## 4. Nouvelle introduction du site

Les six clips actuels (l'enfant, la robe, le ballon) sont remplacés par une présentation : une femme en robe de mariée, devant un ordinateur, présente le site — plan d'ouverture, écran d'accueil et champ de saisie, les cartes, la composition d'équipe, le Bureau, l'invitation finale. Même mécanique qu'aujourd'hui : enchaînement automatique, bouton « Passer l'introduction », lecture muette. Les anciens fichiers sont retirés du projet ; la frise « showcase » qui réutilise un de ces clips reçoit le nouveau plan correspondant.

## 5. Audit complet avant partage

Passage sur toutes les pages publiques et connectées (accueil, registre, réseau, rencontres, ma carte, carte/$id, projets, bureau et ses écrans, messages, crédits, intermittent, comment ça marche, légal, auth, profil) avec :

- zéro erreur console et zéro écart d'hydratation ;
- tous les liens et routes qui répondent, aucun bouton mort ;
- métadonnées de partage (titre, description, aperçu) uniques et justes sur chaque page ;
- affichage mobile vérifié sur les écrans denses (Bureau, projet, réseau) ;
- scan de sécurité de la base relu, anomalies signalées avant publication.

Le rapport final liste ce qui a été corrigé et ce qui reste éventuellement à décider.

## Détails techniques

- Renommage : remplacement texte dans `src/routes/*`, `src/components/aime/*`, `src/lib/i18n/*`, et les invites système de `src/lib/aime/ai.functions.ts` / `chat.functions.ts`.
- Bureau : `FolderTree.tsx` (documents en `Link` vers la fiche document), `BureauWindow.tsx` (un seul rendu de l'arbre).
- Carte : `CardsMap.tsx` — `renderMarkers()` devient incrémental (map id → Marker), le survol ne passe plus par `syncData()`, et la couche `unclustered-point` est filtrée pour les cartes déjà représentées par une vignette.
- Intro : nouveaux `src/assets/intro-*.mp4.asset.json` générés, `SiteIntro.tsx` et `src/lib/aime/showcaseTimeline.ts` mis à jour, anciens pointeurs supprimés.
- Audit : parcours Playwright de toutes les routes, `tsgo --noEmit`, linter base de données.
