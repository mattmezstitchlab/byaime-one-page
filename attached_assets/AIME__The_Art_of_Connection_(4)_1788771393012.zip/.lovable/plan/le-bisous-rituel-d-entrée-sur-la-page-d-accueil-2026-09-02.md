# Le Bisous — rituel d'entrée sur la page d'accueil

Oui, c'est possible, entièrement, avec les vidéos déjà générées (`identity-film.mp4`, `identity-film-2.mp4`) et sans nouvelle génération vidéo.

## Le déroulé

1. **Première visite seulement.** Un marqueur local retient que le rituel a déjà eu lieu ; les visites suivantes affichent l'accueil normal (avec un petit bouton « Revoir le bisous »).
2. **3 · 2 · 1** en gros chiffres au centre du hero dès que la page est prête.
3. **Film I** (la mariée qui s'approche et embrasse l'objectif) joue plein cadre dans le hero. Pas de champ de saisie, pas de bouton, pas de dock pendant ce temps.
4. **Film II** enchaîne. **Arrêt sur image 5 secondes** au moment où **la deuxième femme** approche sa bouche au plus près de l'objectif, avec le message « Fais-moi un bisous en fermant les yeux » et un compte à rebours discret. La personne peut embrasser l'écran (mobile : un appui sur l'écran vaut le bisou ; ordinateur : un clic, la barre d'espace, ou simplement laisser passer les 5 secondes — dans tous les cas le geste est considéré comme fait).
5. La vidéo reprend, la femme s'éloigne, la mariée sourit et disparaît, puis **l'ange branche les câbles**.
6. **La carte blanche apparaît** : une carte universelle vierge, ivoire, portant l'empreinte de rouge à lèvres, l'horodatage (date, heure, fuseau) et un **code de bisou** unique et lisible (ex. `BISOU-7F3K-24Q9`).
7. Après 5 secondes la carte s'efface en fondu et le hero d'aujourd'hui revient : la **vidéo du manège reste figée sur sa première image**, champ de saisie et bouton apparaissent.
8. **Le cœur met le manège en marche.** Tant que la personne n'a pas touché le bouton cœur, le manège ne tourne pas ; une invitation discrète le désigne (« Appuyez sur le cœur »). Au clic, le manège s'anime en boucle et le menu du cœur s'ouvre — la personne découvre son utilité par le geste.
9. **L'empreinte est conservée.** Sur « Créer ma carte », si la personne n'a pas de photo, l'empreinte du bisou devient sa photo par défaut, et sa carte reste rattachée au code de connexion.


## Ce que voit la personne

```text
[ 3 · 2 · 1 ]
[ film I : la mariée s'approche et embrasse l'objectif ]
[ film II : la deuxième femme s'approche… ]
[ ARRÊT — « Fais-moi un bisous en fermant les yeux »  (5 s) ]
[ suite : elle s'éloigne · l'ange branche les câbles ]

        ┌──────────────────┐
        │   carte blanche  │
        │      💋          │
        │  2 sept. 2026    │
        │  BISOU-7F3K-24Q9 │
        └──────────────────┘

[ manège figé + champ de saisie + bouton ]
        ♥  ← au clic : le manège tourne, le menu du cœur s'ouvre

```

## Points à trancher (je prends ces partis par défaut)

- **Son** : les navigateurs bloquent le son sans geste préalable — le film démarre muet, avec un petit bouton « son ».
- **Passer** : un discret « Passer » reste accessible en permanence (accessibilité, et l'internaute pressé).
- **Mouvement réduit** : si le système demande moins d'animation, on saute directement à la carte blanche.
- **Le moment exact de l'arrêt sur image** : réglé par un timecode que j'ajuste en regardant le film, et facilement modifiable ensuite.

## Détails techniques

- Nouveau composant `src/components/aime/KissRitual.tsx` monté par `IntentionHero` : machine à états `countdown → film1 → film2 → freeze → film2-suite → card → done`, les deux `<video>` préchargées, `timeupdate` + `pause()` pour l'arrêt sur image au timecode de la deuxième femme, `AnimatePresence` pour les fondus. Le hero masque champ et boutons tant que l'état n'est pas `done`.
- Manège au repos : la vidéo de fond `hero-carousel.mp4` perd `autoPlay`/`loop` et démarre en pause sur sa première image (`preload="metadata"`, `currentTime = 0`) ; `IntentionHeart` reçoit un `onFirstOpen` qui appelle `play()` et retire l'invitation « Appuyez sur le cœur ». Une fois lancé, le manège tourne en boucle pour le reste de la visite.
- Empreinte : une empreinte de lèvres dessinée en SVG (teinte de la charte), pas une image lourde ; légère variation aléatoire d'angle et d'opacité pour que chaque bisou soit unique.
- Code : `BISOU-XXXX-XXXX` généré côté client à partir de `crypto.randomUUID()`, stocké avec l'horodatage dans `localStorage` (`aime.kiss`) pour la reprise et l'affichage.
- Historique des bisous : nouvelle table `kiss_prints` (code, horodatage, empreinte SVG sérialisée, `user_id` nullable), écriture via une server function publique avec RLS/GRANT — insertion permise à `anon`, lecture réservée au propriétaire une fois la personne inscrite. Aucune donnée personnelle, aucune caméra, aucun capteur : le « bisou » est un geste symbolique.
- Rattachement : à la création de carte (`ma-carte.tsx`), si aucune photo n'est choisie, l'empreinte du `localStorage` est rendue en PNG (canvas) et déposée dans le bucket `cartes` comme visuel par défaut, et le code du bisou est rattaché à la carte.
- Performance : les deux films ne sont préchargés que sur la première visite (`preload="auto"` uniquement à ce moment), avec image d'attente le temps du décompte.

## Ordre de livraison

1. Le rituel visuel complet dans le hero (décompte, films, arrêt sur image sur la deuxième femme, carte blanche) avec code et horodatage en local.
2. Le manège figé relancé par le bouton cœur, avec l'invitation à l'essayer.
3. La table `kiss_prints` et l'historique des connexions.
4. L'empreinte comme photo par défaut à la création de carte.
