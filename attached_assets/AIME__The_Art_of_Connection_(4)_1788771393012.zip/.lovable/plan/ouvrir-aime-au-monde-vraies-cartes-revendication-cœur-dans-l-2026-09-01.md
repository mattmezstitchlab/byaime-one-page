# Ouvrir AIME au monde : vraies cartes, revendication, cœur dans le Réseau

## 1. Retouches d'interface demandées

- Accueil : suppression de la citation « Un + dirait "ajouter un fichier"… » au-dessus du champ.
- Réseau (`/reseau`) : le bouton cœur passe **au bout du champ de recherche** (à droite, dans la barre ronde), à la place du bouton flottant en bas. Le menu s'ouvre vers le bas depuis la barre. Le champ garde la loupe à gauche et la croix d'effacement.

## 2. Le problème constaté

Les 40 cartes actuelles sont toutes sans propriétaire, dans un seul pays et 10 villes. Quand on contacte une carte, le site répond qu'elle n'a pas de propriétaire, et rien ne dit à la personne concernée comment la récupérer. Il manque deux choses : de la matière (vraies fiches, partout, dans les 12 univers) et un chemin de revendication.

## 3. Enrichissement par sources publiques (Firecrawl)

Un moteur d'enrichissement, piloté depuis un écran d'administration :

- On choisit un univers, un sous-univers et une ville (n'importe où dans le monde).
- Le moteur cherche sur le web des acteurs réels de ce métier dans cette ville et récupère uniquement des informations **publiques** : nom, accroche, ville/pays, site officiel, téléphone public, adresse, quelques savoir-faire.
- Chaque fiche trouvée est proposée en attente de validation ; on publie en un clic celles qui sont bonnes.
- Les cartes créées portent la mention **« Fiche publique — non revendiquée »** et la source (le site d'origine, cliquable).
- Doublons évités par site officiel + nom + ville.

Cela permet de couvrir progressivement les grandes métropoles du monde, univers par univers, sans jamais inventer de données.

## 4. Revendication d'une carte

Sur toute carte sans propriétaire, un bouton **« C'est ma carte »** :

1. La personne se connecte, puis saisit une adresse e-mail **du domaine du site officiel** affiché sur la fiche (ex. `contact@sondomaine.com` pour `sondomaine.com`).
2. Un code à 6 chiffres est envoyé à cette adresse.
3. Code correct : la carte lui est attribuée, elle devient modifiable depuis « Mes cartes », le badge « non revendiquée » disparaît et la messagerie fonctionne normalement.
4. Fiche sans site officiel, ou domaine différent : bascule automatique vers une demande manuelle, visible dans l'écran d'administration pour approbation.

Sur la page carte, tant qu'elle n'est pas revendiquée, le bouton « Discuter » est remplacé par « C'est ma carte » + « Signaler une erreur », au lieu du message actuel.

## 5. Détails techniques

- Connecteur **Firecrawl** à lier au projet (carte de connexion en chat) ; appels `search` + `scrape` (format `json`) depuis des server functions, jamais depuis le navigateur.
- Nouvelles tables : `card_sources` (fiches brutes issues du web, statut à valider/publiée/rejetée, url source, payload) et `card_claims` (carte, utilisateur, e-mail, code haché, expiration, statut) — avec RLS et GRANT ; codes de vérification jamais lisibles côté client.
- Nouvelles server functions dans `src/lib/aime/enrich.functions.ts` (recherche, import, publication, réservées aux comptes `admin` via `has_role`) et `src/lib/aime/claim.functions.ts` (demande de code, vérification, attribution du `owner_id`).
- Envoi du code par e-mail via l'infrastructure e-mail du projet ; expiration 15 minutes, 5 tentatives max.
- Colonne `cards.source` déjà présente : réutilisée pour tracer l'origine ; ajout de `source_url` et `claim_status`.
- `src/routes/admin.enrichissement.tsx` : nouvel écran (univers → sous-univers → ville → résultats → publier).
- `src/routes/reseau.tsx` : `IntentionHeart`/`AimeButton` déplacé dans la barre de recherche, suppression du FAB.
- `src/components/aime/IntentionHero.tsx` : suppression du bloc de citation (l. 138-146).
- Les libellés d'univers et sous-univers restent la source de vérité pour les requêtes de recherche (`universeTree.ts`), traduits selon la ville/pays visée.

## 6. Ordre de livraison

1. Retouches interface (cœur dans le Réseau, citation supprimée).
2. Revendication de carte de bout en bout.
3. Moteur d'enrichissement Firecrawl + écran d'administration, puis premières vagues de villes dans le monde.
