# Première minute sans faute : « Bienvenue, votre page en 1 minute »

## Ce que montrent les données

Le compte créé par votre amie a bien fonctionné côté enregistrement : sa page « Marie Bibi » existe, avec sa photo, sa phrase, sa ville (Lille), son métier et deux univers (entreprise, concert). Donc ses clics ont bien été enregistrés — mais **rien ne se voyait à l'écran**.

Cause confirmée : sur l'écran de bienvenue, la page est chargée une seule fois et gardée en mémoire figée. Chaque clic (univers, cases du menu métier / domaines, ville) enregistre en base, mais l'écran continue d'afficher l'ancienne version : aucun bouton ne devient noir, aucune case ne se coche, la barre de progression ne bouge pas. L'impression est « ça ne marche pas », donc on reclique, et parfois on annule ce qu'on venait de faire.

Pour l'arrivée sur la page « Matt Mez Sax » après « Continuer » : je n'ai pas encore de preuve dans le code d'un renvoi vers votre page (le bouton envoie normalement vers la page de la personne connectée). Deux pistes crédibles : le bouton a été utilisé avant que sa page ne soit prête, ou la session ouverte sur le téléphone n'était pas la sienne. La première chose à faire est donc de reproduire l'inscription de bout en bout sur le site publié pour trancher — et, quoi qu'il arrive, de rendre cette étape infaillible.

## Ce que je propose

### 1. L'écran de bienvenue réagit à chaque clic
- La page suivie en direct : dès qu'un univers est choisi, il devient noir ; la case se coche ; la ville s'affiche ; la barre « votre page est remplie à X % » avance.
- Bloquer le double-clic pendant l'enregistrement, et afficher un petit « enregistré » discret.
- En cas d'échec d'enregistrement, un message clair au lieu du silence.

### 2. « Continuer » ne peut plus se tromper de page
- Le bouton reste inactif tant que la page de la personne n'est pas créée et confirmée.
- Il envoie explicitement vers **sa** page, avec un écran de fin « Voilà votre page » (son nom, sa photo) et deux boutons : « Voir ma page » et « Aller à mon espace ».
- Garde-fou : si la page affichée n'appartient pas à la personne connectée, on la renvoie vers sa propre page.

### 3. Un début plus guidé
- Titre et sous-titre qui disent quoi faire, étape par étape, avec « Passer » sur chaque étape.
- Si la confirmation d'e-mail est demandée, le message actuel est conservé.

### 4. Vérification réelle avant de faire tester
- Une inscription complète depuis un téléphone, en navigation privée, sur l'adresse publique : compte créé, page créée, univers et métier cochés visibles, photo, ville, puis « Continuer » qui aboutit bien sur la page de la personne.
- Même essai avec la connexion Google.
- Un second essai avec un deuxième compte pour vérifier qu'on ne croise jamais deux pages.

## Détails techniques

- `src/routes/bienvenue.tsx` : remplacer l'état local `card` par `myCardQuery(userId)` (React Query) après `ensureMyCard`, pour que `PageSetup` reçoive une carte à jour ; `Continuer` désactivé tant que `card?.id` est absent ; navigation vers `/carte/$id` avec l'id issu de la requête, jamais d'un état figé.
- `src/components/aime/PageSetup.tsx` : invalidations déjà présentes conservées ; ajouter un état `pending` (désactivation des boutons pendant `save.isPending`) et remonter les erreurs.
- `src/routes/carte.$id.tsx` : aucune modification de fond ; éventuel garde-fou d'affichage seulement si l'essai réel montre un décalage.
- Aucune migration de base, aucun changement de `SECURITY DEFINER`, pas de touche aux routes `/bureau`.
