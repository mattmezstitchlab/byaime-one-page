# Bulle timeline cliquable, vraie vidéo de découverte, page bêta collaborative

Trois sujets : garder la bulle ouverte pour cliquer ses boutons, remplacer enfin les clips d'intro, et ouvrir le site à des testeurs qui peuvent commenter.

## 1. La bulle de la timeline reste ouverte

Constat dans le code : la bulle s'affiche au survol et se referme dès que la souris quitte la zone de la timeline (`onMouseLeave` sur le conteneur), et elle est posée au-dessus de la bande avec un espace vide entre le point et la bulle. Résultat : on ne peut pas atteindre les boutons Réserver / Devis / Écrire.

Ce qui change :

- **Deux états au lieu d'un.** Survol = aperçu léger, qui disparaît en partant. Clic sur le point = bulle **épinglée** : elle reste, même si la souris part ailleurs.
- Une bulle épinglée se ferme seulement par : clic ailleurs sur la page, touche Échap, ou son bouton de fermeture. Exactement la logique du menu du bouton cœur.
- Suppression de l'espace mort entre le point et la bulle (pont de survol) pour que la souris puisse monter sans perdre l'aperçu.
- Sur mobile : appui = bulle épinglée d'office en feuille basse.
- Le point épinglé reste visuellement marqué (anneau AIME) pour savoir de quoi parle la bulle.

## 2. Les actions ne quittent plus la page

Aujourd'hui « Devis » envoie sur `/devis/...` — c'est justement ce que le site doit éviter.

Les actions s'exécutent **dans une feuille qui s'ouvre par-dessus la page**, sans navigation :

| Action | Ce qui se passe sur place |
|---|---|
| Réserver | choix du créneau + message, confirmation dans la feuille |
| Devis | formulaire court (prestation, montant, date) → devis créé, nouveau repère posé sur la timeline |
| Facture | reprend le devis lié et le transforme, nouveau repère |
| Écrire | fil de message ouvert dans la feuille |
| Ouvrir / Partager | aperçu du document ou lien copié |

Aucune de ces actions ne recharge la page ; la timeline se met à jour immédiatement. Un lien discret « Ouvrir en grand » reste possible pour ceux qui veulent la page complète.

## 3. « Comprendre AIME en 40 secondes » — la vraie démo

Rien n'a changé parce que les quatre clips actuels sont toujours les vidéos de la mariée. On les remplace par une démonstration réelle du site en quatre chapitres d'environ 10 secondes :

1. Créer sa carte, de la saisie à la carte publiée
2. Créer une équipe / composer avec Aime
3. La timeline vivante et ses actions
4. Le Bureau : dépôt d'une facture, classement, budget

Production : captures d'écran animées du site réel, enchaînées avec léger zoom, curseur visible, fondus et un sous-titre par chapitre. Le bouton « Passer » et la barre de progression restent.

## 4. Page bêta publique et remontée de bugs

Nouvelle page **`/beta`** accessible sans compte, dans la grammaire habituelle (hero fixe, titre dans le hero) :

- Ce qu'est AIME en cinq lignes, à qui ça s'adresse, ce qui marche déjà, ce qui est en construction.
- Un parcours suggéré pour tester (créer une carte → dire une intention → suivre la timeline → déposer un document).
- **Un formulaire de retour** : type (bug, idée, incompréhension, coup de cœur), page concernée (pré-remplie), message, prénom et e-mail facultatifs, capture d'écran facultative.
- **Le mur des retours** : les remarques publiées apparaissent en dessous, avec leur statut (Reçu · En cours · Corrigé) et un bouton « moi aussi » pour appuyer une remarque. Les retours sont modérés : visibles seulement après validation, pour éviter le spam.
- Un bouton discret « Un retour ? » présent sur tout le site, qui ouvre le même formulaire en feuille, avec la page courante déjà remplie.

Côté vous : un écran d'administration simple pour lire, trier et changer le statut des retours.

## Détails techniques

`HeroTimeline.tsx` : séparation `hovered` / `pinned`, suppression du `onMouseLeave` global au profit d'un délai de grâce, fermeture par clic extérieur + Échap, pont de survol entre le repère et la bulle. `timelineActions.ts` gagne un mode « feuille » : les handlers de `carte.$id.tsx` n'appellent plus `navigate` mais ouvrent un nouveau composant `TimelineActionSheet.tsx` (réservation, devis, facture, message) branché sur les fonctions serveur existantes du Bureau et de la messagerie, avec invalidation React Query pour rafraîchir les repères.

Nouvelle table `beta_feedback` (type, message, page, contact facultatif, statut, compteur d'appuis, capture) avec GRANT explicites, RLS : insertion autorisée à tous, lecture publique limitée aux retours publiés, gestion réservée aux administrateurs via `has_role`. Route `/beta` + composant `FeedbackSheet.tsx` monté dans `AppShell`. Stockage des captures dans un bucket dédié avec contrôle de taille.

Nouveaux assets d'intro générés par captures Playwright puis montage ffmpeg, remplaçant `intro-a…d` dans `SiteIntro.tsx` (attention : `intro-b` est aussi utilisé comme média de démonstration dans `showcaseTimeline.ts`).
