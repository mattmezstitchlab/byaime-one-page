# Devis immersifs + audit des timelines

## 1. Fonds visuels immersifs sur les pages Devis

Aujourd'hui `/devis/$cardId` s'ouvre sur une page blanche avec un simple titre. Objectif : un grand fond visuel plein écran lié à l'univers/métier de la carte (Meert → pâtisserie, château → salle de réception, musicien → scène, etc.).

Principe retenu : **le visuel suit le métier de la carte, pas seulement l'univers**, car c'est le métier qui parle (traiteur, pâtisserie, fleuriste, photographe, lieu, DJ…).

- Hero immersif en haut de la page devis : image plein largeur (débord gauche/droite), hauteur ~52vh, dégradé ivoire vers le bas pour fondre dans le contenu, nom de la carte + ville + fourchette de prix posés dessus.
- Table de correspondance `categorie / univers → visuel`, avec repli sur le visuel d'univers puis sur un visuel neutre. Priorité : photo de couverture de la carte si elle existe → visuel métier → visuel univers.
- Réutilisation des visuels existants (`visual-food`, `visual-venue`, `visual-music`, `visual-flower`, `visual-photo`, `visual-event`, `visual-light`, `visual-people`…) et **génération des visuels manquants** pour les métiers non couverts : pâtisserie/chocolaterie, vin & spiritueux, beauté/coiffure, mode & robe, décoration, transport, patrimoine, bien-être, enfance, sport, artisanat.
- Même traitement appliqué au bloc « Devis et tarifs » affiché dans les combinaisons et sur la page carte, en version bandeau réduit, pour la cohérence.
- Lisibilité et accessibilité : voile sombre calibré, textes en tokens sémantiques, `alt` descriptif, pas de texte critique posé sur une zone chargée.

## 2. Audit timelines — ce qui existe

La timeline actuelle (règle graduée zoomable, marqueurs souvenir / événement / disponible / option / complet / intention / jalon) est déjà singulière. Elle reste pourtant **descriptive** : elle affiche ce qui a été saisi. Les pistes ci-dessous la rendent **vivante, croisée et prédictive** — c'est là que se trouve l'innovation.

### A. Le contenu qui manque (à forte valeur, simple)
1. **Saisons tarifaires** — bandes colorées de fond selon la grille de devis (haute/basse saison, dates majorées). On lit le prix dans le temps, pas dans un tableau.
2. **Dates chaudes** — intensité de la demande par date (nombre d'intentions reçues sur ce créneau). Un lieu voit ses week-ends brûlants.
3. **Jalons de préparation auto** — pour un événement daté, l'agent pose J-180 essayage, J-90 acompte, J-30 plan de table, J-7 confirmation. Générés, éditables.
4. **Fil de vie de la carte** — création, revendication, premiers avis, premières prestations : l'histoire de la carte devient un contenu public.
5. **Traces publiques** — dates de festivals, expos, saisons officielles importées depuis la source publique de la carte.

### B. Les innovations qu'on ne voit nulle part
6. **Timelines superposées (calque duo)** — poser la timeline d'une autre carte par-dessus la sienne : les créneaux communs s'illuminent. La disponibilité devient une rencontre visuelle, pas une liste.
7. **Timeline d'équipe / de projet** — un projet empile les timelines de tous ses prestataires : un seul écran montre où l'équipe tient et où elle casse (conflit, trou, dépendance).
8. **Zone de futur probable** — au-delà d'aujourd'hui, l'agent trame des périodes « probablement libre / probablement prise » à partir des habitudes de la carte. Un futur lu, pas vide.
9. **Timeline négociable** — glisser une intention sur la règle propose une date à l'autre personne ; elle accepte ou contre-propose en déplaçant le marqueur. La négociation se fait sur la ligne, sans message.
10. **Chapitres racontés** — l'agent regroupe les marqueurs en chapitres titrés (« l'été des mariages », « la saison des refus ») lisibles comme un récit ; ton tendre et taquin de l'entremetteuse.
11. **Timeline sonore** — parcourir la règle joue l'ambiance de chaque période (extrait du musicien, radio du moment). Le temps s'écoute.
12. **Éphémères sur la ligne** — les stories 6h apparaissent comme des points qui s'effacent en direct : la timeline respire.
13. **Empreinte carbone / distance** — pour les prestataires itinérants, la ligne montre les déplacements et suggère les regroupements géographiques.
14. **Timeline miroir invité** — un invité voit sa propre ligne (ses intentions, ses événements, ses paiements) : la timeline devient le journal de bord personnel, pas seulement une vitrine de prestataire.

### C. Ordre recommandé
Passe 1 : 1, 2, 3 (contenu immédiat, sans nouvelle table lourde).
Passe 2 : 6, 7, 12 (le croisement — le vrai différenciateur).
Passe 3 : 8, 9, 10, 11 (l'agent et le récit).

## 3. Détails techniques

- Nouveau module `src/lib/aime/universeVisuals.ts` : mapping catégorie/univers → asset importé, avec repli en cascade.
- Nouveau composant `QuoteHero` (hero immersif réutilisable) monté dans `devis.$cardId.tsx` et en variante compacte dans les combinaisons.
- Images générées en `.jpg` dans `src/assets`, importées en ES6, `loading="lazy"` hors du hero courant.
- Aucune modification de schéma pour la partie visuelle ; l'audit timeline reste une proposition, rien n'est implémenté tant que vous n'avez pas choisi les pistes.

## 4. Timeline vitrine dans le hero de l'accueil

Une timeline de démonstration s'installe en bas du hero d'accueil, par-dessus la vidéo, comme signature du produit dès la première seconde.

- Reprise de `HeroTimeline` enrichie avec des **marqueurs typés et illustrés** : vidéo, audio, document, historique, rencontre.
- Les marqueurs « rencontre » s'affichent en **vignette photo ronde** (visage), les autres en pastille avec picto, taille légèrement supérieure aux points actuels.
- Au survol / au clic, un aperçu léger s'ouvre au-dessus de la ligne : lecture d'un extrait vidéo muet en boucle, forme d'onde audio jouable, première page du document, texte du souvenir, ou la carte de la personne rencontrée.
- Contenu de démonstration scénarisé (un mariage : rencontre, essayage filmé, contrat signé, maquette musicale, jour J) posé du passé au futur, pour montrer d'un coup d'œil ce qu'une carte peut raconter.
- Auto-déroulé lent à l'arrivée (le curseur glisse doucement de gauche à droite) puis reprise de la main par l'utilisateur au premier geste ; respect de `prefers-reduced-motion`.
- Techniquement : extension du type `TimelineMarker` avec `media` (`video | audio | doc | souvenir | rencontre`), `thumbUrl` et `mediaUrl`, plus un composant `TimelinePreview`. Les données de démo vivent dans `src/lib/aime/demoTimeline.ts` — aucune écriture en base.
- La même timeline enrichie sert ensuite aux vraies cartes : ce n'est pas une maquette jetable.

## 5. Question ouverte

Après cette première livraison, dites-moi quelles pistes de l'audit lancer en premier — je propose 1, 2 et 6.
