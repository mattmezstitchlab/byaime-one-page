# Radio simple, récit à voix haute et en-tête unifié

La radio arrête d'être un média à part avec ses fréquences et ses équipes. Il ne reste que deux choses : une voix qui raconte votre ligne de temps, et une playlist de vrais morceaux qu'on peut écouter.

## 1. La radio devient simple

- Suppression complète du concept de fréquence : plus de nom de station, d'accroche, de couleur, de jingle, d'équipe ni de grille de programmation. Les écrans correspondants disparaissent et les données de fréquence sont effacées.
- Ce qui reste de la radio : **ma playlist** (des morceaux) et **le récit** (la voix qui lit la ligne de temps).
- Le bouton Radio de l'en-tête lance une **écoute au hasard** des morceaux que la communauté a rendus publics dans sa playlist. Le morceau en cours s'affiche dans la petite barre existante (titre, artiste, passer au suivant), avec un lien vers la page de la personne qui l'a ajouté.

## 2. Une playlist qu'on peut vraiment écouter

- Ajout d'un morceau en tapant simplement un nom d'artiste ou de chanson : la recherche propose des résultats avec pochette, titre, artiste et durée, et il suffit de cliquer pour l'ajouter.
- Le morceau ajouté est écoutable (extrait officiel autorisé), avec sa pochette, et un lien vers la version complète chez le service d'origine. Aucun fichier n'est copié ni stocké.
- Chaque morceau garde sa place sur la ligne de temps (le calque Musique existant) et peut être privé, réservé aux invités, ou public. Seuls les morceaux publics alimentent l'écoute au hasard.

## 3. Le récit lu à voix haute

- Dans le lecteur ▶ de la ligne de temps, le récit est désormais **dit par une voix**, automatiquement, moment après moment, pendant que la ligne défile.
- Le texte lu reste construit uniquement à partir de ce que porte réellement la ligne de temps : rien n'est inventé.
- Sur une page publique, le bouton ▶ ne propose plus de scénarios de gestion de projet : **Écouter le récit** et **Écouter la playlist**, rien d'autre.

## 4. Ce qui s'affiche sous la ligne de temps

- Sur une page publique vue par un visiteur : plus de blocs « Que dois-je faire ? », « Que manque-t-il ? », « Vigilance », ni de formulaire d'ajout. Ces informations sont privées.
- Pour le propriétaire de la page, ces mêmes éléments ne sont plus répétés sous la ligne de temps : ils rejoignent la liste « À faire » de Mon espace, qui devient le seul endroit où l'on voit ce qui demande une action, avec son compteur.
- Sous la ligne de temps, il ne reste que ce qui parle au visiteur : la présentation, les savoir-faire, la galerie, les tarifs.

## 5. L'en-tête

- « Mon espace » devient un picto rond comme les autres, avec son compteur de nouveautés.
- Le picto Messagerie reçoit le même traitement que le picto Documents : un compteur qui s'allume en direct dès qu'un message arrive, sans recharger la page.
- En plus, si le visiteur l'accepte, une vraie alerte du navigateur s'affiche à l'arrivée d'un message ou d'un document, avec un lien qui ouvre directement la conversation. L'autorisation se demande une seule fois, depuis les Réglages.

## Détails techniques

Base : migration de suppression des tables de fréquence `card_radios`, `radio_members`, `radio_announcements`, `radio_stations`, et des colonnes/FK qui y renvoient (`musicbox_entries`, `airplay_logs`) ; les entrées musicales elles-mêmes sont conservées. Ajout sur `musicbox_entries` des champs fournisseur (`provider`, `track_id`, `artist`, `artwork_url`, `preview_url`, `external_url`) et d'une policy `TO anon` en lecture limitée aux entrées `visibility = 'public'` et `kind = 'musique'`, avec les GRANT correspondants, pour l'écoute au hasard.

Code : suppression de `src/components/aime/panels/FrequencyPicker.tsx`, `RadioIdentity.tsx`, `src/lib/aime/frequency.ts`, `frequency.functions.ts`, `src/lib/aime/radio.ts` et des usages dans `RadioPanel.tsx`, `CardTabs.tsx`, `MusicBox.tsx`, `DayConsole.tsx`. `RadioProvider.tsx` est réduit à : file aléatoire de morceaux publics + lecture via `audioBus`, sans segments d'antenne, géolocalisation ni rayon. Recherche de morceaux via `MUSIC_PROVIDERS` (`src/lib/aime/play/providers.ts`) réutilisé dans `MusicLibrary.tsx` et `AddToTimeline.tsx`.

Récit vocal : nouveau `src/lib/aime/play/speak.functions.ts` (`createServerFn`) appelant la synthèse vocale de Lovable AI (`/v1/audio/speech`, SSE, PCM) avec les statuts d'erreur gérés (429/5xx avec attente, 402/403 terminaux affichés) ; `PlayProvider` enchaîne texte → audio et n'avance qu'à la fin de la voix ; `PlayStage` affiche le texte lu et un bouton couper le son. Réutilisation de `bindAudioElement` pour qu'un seul son joue à la fois. `PlayButton` reçoit un mode `public` (deux entrées seulement) utilisé par `carte.$id.tsx`.

En-tête et notifications : `AppShell.tsx` — bouton Mon espace transformé en `Button size="icon"` avec pastille ; abonnement Realtime sur `messages` et `bureau_documents` pour rafraîchir les compteurs en direct ; nouveau `src/lib/aime/notify.ts` (permission `Notification`, garde iframe → invitation à ouvrir l'app dans un onglet, envoi de l'alerte) branché sur ces abonnements, réglage d'activation ajouté dans `SettingsSheet.tsx`. Sous la ligne de temps, `TimelineCompass` et `AddToTimeline` quittent `carte.$id.tsx` ; les mêmes éléments sont fusionnés dans la liste « À faire » de `SpaceSheet.tsx` via `auditTimeline`. Aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié.
