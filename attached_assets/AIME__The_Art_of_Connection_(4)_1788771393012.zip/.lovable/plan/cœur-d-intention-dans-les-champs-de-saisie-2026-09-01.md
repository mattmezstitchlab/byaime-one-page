# Cœur d'intention dans les champs de saisie

## 1. Composer (`/rencontres`)

- Suppression des 3 phrases de suggestion sous le champ.
- Le champ de saisie gagne un **bouton cœur** à gauche du bouton « Composer les rencontres », avec un menu d'actions liées à la saisie en cours.

## 2. Accueil (hero)

- Même bouton cœur, posé dans la barre ronde, entre le champ et « Continuer ».
- Un seul et même composant partagé entre les deux pages, pour que le geste soit identique partout.

## 3. Ce que contient le menu cœur (audit)

Le cœur d'AIME est déjà un « menu d'intention » sur les cartes. Ici il devient le **menu d'alimentation de l'intention** : tout ce qui permet de nourrir la demande avant que l'IA compose.

Retenu :

1. **Importer un document** (PDF, devis, cahier des charges, e-mail, image d'inspiration) — l'IA en extrait date, lieu, budget, nombre d'invités et pré-remplit le champ. C'est le vrai gain : la plupart des gens ont déjà leur brief écrit ailleurs.
2. **Dicter à la voix** — micro, transcription dans le champ. Un brief parlé est plus long et plus riche qu'un brief tapé, donc de meilleures compositions.
3. **Embarquer des cartes** — ouvrir la recherche de cartes et les épingler à l'intention (déjà supporté par `pinned`, mais aujourd'hui invisible depuis Composer).
4. **Reprendre une intention passée** — mes intentions et rencontres déjà enregistrées, réutilisables en un clic.
5. **Déposer l'intention en public** — la publier sur le Réseau pour que d'autres y répondent, plutôt que d'attendre seulement l'IA.
6. **Préciser le cadre** — date/période, ville, budget, nombre de personnes, en petits champs repliés. Ces trois données changent radicalement la qualité du résultat et sont pénibles à formuler en prose.

Écarté volontairement : refaire ici les filtres univers (déjà dans le registre), et tout bouton qui dupliquerait « Composer ». Le cœur ne lance rien, il **remplit** ; le bouton principal reste le seul déclencheur.

Pourquoi le cœur plutôt qu'un « + » : sur AIME le cœur est déjà la signature du geste d'intention. Un « + » dirait « ajouter un fichier » ; le cœur dit « dis-moi ce que tu veux vivre, par tous les moyens ». <<< fais en une citation au dessus du champs dans le hero, 

## Détails techniques

- Nouveau `src/components/aime/IntentionHeart.tsx` : bouton rond (même gabarit que `AimeButton`) + `Popover` d'actions, props `value`, `onChange`, `pinned`, `onPinnedChange`.
- Import de document : lecture du fichier puis extraction via une server fn (réutilise le modèle Lovable AI déjà branché dans `ai.functions.ts`) qui renvoie un brief structuré injecté dans le champ.
- Dictée : Web Speech API côté navigateur, repli silencieux si non supporté.
- « Reprendre » lit `encountersQuery` / `intentions`; « Déposer » écrit dans la table `intentions` existante.
- `src/routes/rencontres.tsx` : suppression de `SUGGESTIONS` (l. 63-67) et du bloc l. 225-236 ; insertion du cœur dans la barre d'action.
- `src/components/aime/IntentionHero.tsx` : insertion du cœur dans la barre ronde, avant « Continuer ».