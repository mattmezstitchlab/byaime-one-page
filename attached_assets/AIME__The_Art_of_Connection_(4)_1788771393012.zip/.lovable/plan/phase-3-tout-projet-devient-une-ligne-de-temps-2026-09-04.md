# Phase 3 — Tout projet devient une ligne de temps

## Le problème constaté

Deux pages de projet coexistent aujourd'hui dans `src/routes/projets.$id.index.tsx` :

- Si un « monde » a été généré depuis un récit (mémoire locale ou instantané enregistré), la page affiche la scène complète : film, chips, sélecteur Tout / Avant / Pendant / Après, ligne de temps en bas du hero.
- Sinon — cas de « Mariage Claire & Julien », créé directement dans la base — la page retombe sur l'ancienne mise en page verticale : hero image, boutons, liste de participants, Causalité, Ciel et plan B, Dossiers du Bureau.

C'est la contradiction visible sur vos deux captures. Un projet réel n'a pas encore de ligne de temps parce que rien ne transforme les données de la base en modèle de monde.

## Ce qu'on fait

Un seul chemin : **tout projet, quelle que soit son origine, est un monde, et la ligne de temps en est la projection.**

1. **Nouvelle traduction base → monde** : un module qui lit l'événement (date, lieu, ville, invités, description), ses participants, ses devis, ses paiements, ses documents et sa programmation musicale, et en compose un `WorldProject` — mêmes objets que ceux issus du récit (intentions, prestataires, documents, paiements, moments, musique). Rien n'est inventé : ce qui manque reste marqué « à confirmer » ou absent.
2. **Une seule page projet** : l'ancienne mise en page verticale disparaît. La page affiche toujours la scène (film, titre, chips, phases, ligne de temps), suivie du bandeau discret date / lieu / invités, des volets latéraux (participants, paiements, facture, programmation) et du bloc de synchronisation financière.
3. **Ce qui reste, replacé** : Causalité, Ciel et plan B et Dossiers du Bureau ne sont plus des sections empilées ; ils deviennent des volets latéraux supplémentaires, ouverts depuis la même barre que les autres, sur le même modèle d'URL (`?panneau=…`). Rien n'est supprimé.
4. **Publication et retour au registre** : les boutons « Publier dans le registre » et « Mes projets » sont conservés, replacés dans la barre unique.
5. **Priorité de la source** : monde enregistré (instantané) > brouillon local > monde reconstitué depuis la base. Dès qu'une modification est faite sur un projet reconstitué, elle est enregistrée comme instantané, donc plus rien ne régresse.

## Détails techniques

- Nouveau `src/lib/aime/world/projectFromEvent.ts` : `projectFromEvent(event, { participants, quotes, payments, documents, tracks })` → `WorldProject`, pivot sur `starts_at`, confiance `confirme` pour ce qui vient de la base, `a_confirmer` pour ce qui est déduit.
- `src/routes/projets.$id.index.tsx` : suppression du double rendu ; `canonicalProject = remoteSnapshot ?? localProject ?? projectFromEvent(...)`, un seul composant de page.
- `src/components/aime/project/ProjectPanels.tsx` : ajout des clés `causalite`, `meteo`, `dossiers` au schéma `panneau` (et donc au `validateSearch` de la route).
- Réutilisation des requêtes existantes (`eventQuery`, `paymentsQuery`, `quotes`, `musicbox_entries`) — aucune nouvelle table, aucune migration.
- Périmètre gelé respecté : aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié.
- Vérification : `bunx tsgo --noEmit -p tsconfig.json` puis contrôle navigateur sur `/projets/165db7a7-…` (scène visible, phases comptées, volets ouvrables).
