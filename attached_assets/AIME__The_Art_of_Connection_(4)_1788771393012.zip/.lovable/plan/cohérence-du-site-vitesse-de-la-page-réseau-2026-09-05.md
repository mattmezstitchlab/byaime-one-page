# Cohérence du site + vitesse de la page Réseau

## Ce que vaut le retour de Manus

J'ai vérifié chaque point dans le code réel. Verdict :

**Justes, à corriger (7)**
1. Les douze mondes apparaissent deux fois : la bande est volontairement dupliquée pour défiler en boucle, mais rien ne le dit — visuellement et pour la lecture d'écran, on voit 24 mondes.
2. « À l'écran · 0 » alors que la carte affiche 227 pages : la liste ne se met à jour qu'au premier déplacement de la carte. Elle est comptée avant l'arrivée des données, puis jamais recomptée.
3. « 227 carte s » : le « s » du pluriel est séparé du mot dans le rendu.
4. Mentions légales sans identité juridique : pas de raison sociale, adresse, immatriculation ni représentant nommé, alors que le service vend des crédits.
5. « AIME » / « Aime » / « aime.app » / « byaime.fr » se mélangent, y compris dans les documents légaux (« crédits d'Aime »).
6. La page de connexion s'intitule « Rejoindre AIME » puis affiche « Content de vous revoir ».
7. « Écoute AIME · silencieuse » : formulation contradictoire quand rien ne joue.

**Justes mais à arbitrer avec vous (4)**
8. Paiements : « AIME n'encaisse pas » côté public vs « paiements traités par un prestataire » côté conditions — la distinction achat de crédits / paiement entre membres doit être écrite noir sur blanc.
9. Confidentialité : le fournisseur d'IA et le pays de traitement ne sont pas nommés, alors que les mentions annoncent un stockage en Europe.
10. Géolocalisation et éphémères annoncés comme soumis au consentement, sans réglage visible dans le bandeau.
11. Déclaration d'accessibilité qui renvoie à une page Paramètres introuvable publiquement (les réglages vivent dans Mon espace).

**Point hors sujet (1)**
12. Le badge « Edit with Lovable » n'est pas du contenu du site : il se retire dans les réglages de publication. Je peux le faire si vous le souhaitez.

## Vitesse de la page Réseau : ce qui freine réellement

Constats dans le code, du plus lourd au plus léger :

- La page ne prépare rien à l'avance : les pages, catégories, mondes, rencontres, projets et compositions ne sont demandés qu'une fois la page affichée dans le navigateur.
- La requête des pages demande **toutes les colonnes** des 281 pages (37 colonnes, dont de longs textes), alors que la carte n'a besoin que d'une dizaine de champs.
- La carte pose une **vignette photo par point** (élément HTML + image pleine taille) et les recalcule à chaque immobilisation de la carte.
- Le fond de carte vient d'un service externe, puis toutes ses couleurs sont réécrites une par une au chargement.
- La bande des douze mondes est doublée : jusqu'à 24 vignettes vidéo animées en continu au-dessus, sur l'accueil.

## Ce que je propose de faire

### Étape 1 — Vitesse Réseau (priorité)
- Charger les données de la carte dès la demande de page, avant l'affichage, et ne demander que les champs utiles.
- Recompter « À l'écran » dès que les données arrivent, plus seulement au déplacement.
- Afficher les vignettes photo uniquement pour les points visibles, en images allégées, et cesser de tout recalculer à chaque immobilisation.
- Afficher un fond de carte et un cadre immédiats pendant le chargement, pour supprimer l'écran vide.

### Étape 2 — Corrections d'incohérence sans arbitrage
- Bande des mondes : la copie de défilement devient invisible aux lecteurs d'écran, et le libellé annonce douze mondes.
- « 227 cartes sur la carte » écrit correctement.
- Page de connexion : un seul récit selon le mode (se connecter / créer sa page), titre inclus.
- Radio : « Rien ne joue pour l'instant » au lieu de « silencieuse ».
- Un seul nom partout : AIME, avec byaime.fr comme adresse et aime.app réservé aux e-mails.

### Étape 3 — Textes légaux (avec vos informations)
- Mentions légales : raison sociale, forme, adresse, immatriculation, représentant, hébergeur.
- Argent : une phrase claire — les crédits sont vendus par AIME et encaissés par un prestataire de paiement ; les sommes entre membres ne transitent jamais par AIME.
- Confidentialité : nommer le fournisseur d'IA et le lieu de traitement.
- Accessibilité : renvoyer vers les réglages de Mon espace.
- Consentement : géolocalisation et éphémères réellement réglables depuis le bandeau.

## Détail technique

`src/routes/reseau.tsx` : ajouter un `loader` avec `ensureQueryData` sur les requêtes carte, corriger le pluriel ligne 800, forcer un recalcul de `viewportIds` à l'arrivée des données. `src/lib/aime/queries.ts` : remplacer `select("*")` par une liste de colonnes pour `cardsQuery` (variante « carte »). `src/components/aime/CardsMap.tsx` : `emitViewport` appelé aussi depuis `syncData`, marqueurs limités à l'emprise visible, `renderMarkers` débranché de `idle` au profit de `moveend`, images de marqueur en miniature. `src/components/aime/UniverseVideoGrid.tsx` : `aria-hidden` sur le second jeu de tuiles, vidéo armée uniquement au survol/visibilité. `src/routes/auth.tsx` : `head()` et titres pilotés par `mode`. `src/components/aime/RadioBar.tsx` : libellé de repos. `src/routes/legal.$doc.tsx` : identité juridique, terminologie AIME, fournisseur d'IA, renvoi accessibilité. Aucune modification de `/bureau` ni des fonctions `SECURITY DEFINER`.

## Ce dont j'ai besoin de vous
Raison sociale, forme juridique, adresse, numéro d'immatriculation, représentant légal, et le nom du prestataire de paiement. Sans ces éléments je ferai l'étape 1 et 2, et je laisserai l'étape 3 en attente plutôt que d'inventer.
