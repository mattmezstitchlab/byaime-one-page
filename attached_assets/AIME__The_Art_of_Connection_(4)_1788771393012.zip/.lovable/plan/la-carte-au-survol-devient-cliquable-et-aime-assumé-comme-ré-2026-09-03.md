# La carte au survol devient cliquable — et AIME assumé comme réseau social

## 1. Survol d'un pin sur la carte : la vignette reste

Aujourd'hui, la bulle d'aperçu (« coup d'œil ») s'affiche au survol d'un pin, mais disparaît dès que la souris quitte le pin : impossible d'atteindre les boutons. Sur la vue Grille, la même vignette est utilisable.

Correction :
- Petit délai de grâce (~180 ms) à la sortie du pin, annulé si la souris entre dans la bulle : on peut donc glisser du pin vers la vignette sans qu'elle se ferme.
- La bulle reste ouverte tant que la souris est dessus, et se ferme sur : sortie réelle, clic ailleurs, touche Échap, ou déplacement/zoom de la carte.
- Clic sur un pin : la vignette est épinglée (mode « verrouillé »), elle ne se ferme plus au survol — mêmes actions que sur la Grille, dont « Voir la page ».
- Sur mobile, comportement inchangé (bulle en bas d'écran, fermeture par la croix).

Résultat : la carte et la grille se comportent exactement pareil.

## 2. Bouton « + » : suppression du passé/présent/futur

Dans le dock, le « + » porte aujourd'hui une enseigne de temps (♠ ♦ ♣), un appui long qui ouvre un sélecteur de temps, un lien « Changer », et un tri des créations par temps.

À retirer : la pastille d'enseigne, l'appui long, le sélecteur, le lien « Changer » et le regroupement « Autres temps ». Le « + » devient un simple bouton de création avec une seule liste. La notion de temps reste là où elle a du sens : les timelines des pages (passé / présent / futur).

## 3. La direction : AIME est un réseau social de pages

Votre lecture est juste, et c'est déjà presque ce que fait le site. La formulation claire :

- Chacun crée **sa page** (aujourd'hui « sa carte »). C'est l'objet central, comme un profil.
- La page porte **des onglets** qui dépendent de l'activité : un traiteur n'a pas les mêmes onglets qu'un futur marié.
- Créer un projet ou un événement ne crée pas une autre page : cela **ajoute un onglet** à la page, avec sa timeline.
- **Le Monde AIME** (carte / liste / grille) est l'espace public où l'on découvre les pages des autres.
- **AI** et **ME** restent les deux panneaux globaux : AI = ce qui vient vers moi, ME = ce qui m'appartient.

Ce qui manque pour que ce soit lisible, et que je propose de faire ensuite (pas dans ce lot) :
1. À la création, une question simple : « qu'est-ce que vous organisez / proposez ? ». La réponse choisit un jeu d'onglets par défaut (Mariage, Prestataire, Lieu, Artiste, Association…).
2. Un réglage « Onglets » sur sa propre page : cocher/décocher, réordonner. Rien d'imposé.
3. Chaque projet créé apparaît comme onglet de la page, et non comme une page séparée.

## Périmètre technique de ce lot

- `src/components/aime/CardPreview.tsx` : `GlanceBubble` gagne un état épinglé et la gestion Échap/clic extérieur.
- `src/routes/reseau.tsx` : délai de grâce sur `onHoverCard`, épinglage au clic sur un pin, fermeture au `moveend`.
- `src/components/aime/CardsMap.tsx` : le clic sur un pin remonte « épingler » plutôt qu'ouvrir directement l'overlay.
- `src/components/aime/AimeDock.tsx` : suppression du sélecteur de temps et de l'appui long.
- Aucune modification de base de données, de RLS ni de routes.
