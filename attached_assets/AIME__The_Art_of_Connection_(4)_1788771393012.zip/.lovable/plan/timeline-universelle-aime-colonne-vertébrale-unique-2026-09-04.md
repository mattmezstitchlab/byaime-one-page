# Timeline universelle AIME — colonne vertébrale unique

L'objectif est clair : une seule ligne de temps, enrichie par calques, objets et relations. Bonne nouvelle, la base existe déjà et n'a pas besoin d'être reconstruite.

## Ce qui existe déjà (vérifié dans le code)

- `HeroTimeline.tsx` : règle graduée, zoom semaine→décennie, bandes de période, bulle d'aperçu épinglable, actions rondes, vignettes et médias. Le type `TimelineMarker` porte déjà `kind`, `media`, `thumbUrl`, `startTime`/`endTime`, `done`, `threadId`, `children` (dossier) et `pending` (proposition à valider).
- 14 natures de repères déjà typées : souvenir, événement, disponible, option, complet, intention, jalon, tâche, message, dossier, document, devis, facture, paiement.
- `timelineFilters.ts` : 7 familles de calques déjà définies.
- `cardTimeline.ts` : agrégation déjà en place de `bureau_documents`, `quotes`, `event_payments`, `events`, `messages` sur une seule ligne.
- `TimelineAgentBar.tsx` : on écrit une phrase, elle est interprétée (`agentParse.ts`), un repère « proposition » apparaît et n'est enregistré qu'après validation.
- `timeline_effects` : table de conséquences reliée aux repères et aux documents.
- `card_timeline_entries` porte déjà `due_at`, `done_at`, `ends_at`, `link_event_id`, `secrecy`, `universe_slug`.

Il n'existe aucune timeline « mariage », « intermittent » ou « finance » séparée : la règle d'architecture demandée est déjà respectée. Ce qui manque, ce sont les **relations**, les **statuts de validation**, le **rétroplanning**, et les deux boussoles « Que dois-je faire ? » / « Que manque-t-il ? ».

## Le plan, en quatre livraisons

### 1. Le socle : objets, relations, statuts

- Un modèle unique `TimelineItem` étendant l'actuel `TimelineMarker` : ajout de `status` (préparé / à valider / exécuté / bloqué / en attente / annulé / échoué), `priority`, `projectId`, `personIds`, `relatedIds`, `source`, `metadata` libre.
- Une table de liens `timeline_relations` (élément → élément, avec la nature du lien : devis→contrat→facture→paiement, prestation→heures→bulletin→déclaration, événement→photos).
- Les statuts et pastilles de validation apparaissent directement sur la règle : un point orange « à valider », un point vert « exécuté ».
- Les objets déjà agrégés (documents, devis, factures, paiements, événements, messages) reçoivent leurs relations automatiquement quand elles sont déductibles (même projet, même carte, même montant).

### 2. Les calques et la superposition

- Barre de calques enrichie au-dessus de la règle : Tout · Intentions · Événements · Personnes · Documents · Photos · Vidéos · Messages · Tâches · Prestataires · Finance · Administratif · Validations. Désactiver un calque masque, ne supprime jamais.
- Superposition : quand plusieurs objets tombent sur le même moment, une pastille « dossier » avec compteur ; au clic, la bulle liste les angles de ce même instant (cérémonie, prestataire, contrat, paiement, photos…).
- Panneau contextuel : la bulle devient une fiche qui affiche l'objet **et sa chaîne de relations**, navigable sans quitter la ligne de temps.

### 3. L'intelligence : rétroplanning, manques, anomalies

- **Rétroplanning générique** : à partir d'une date cible et d'un type de projet, génération d'une structure J-540 → J+30 en repères « proposés » (jamais enregistrés sans validation). Les modèles d'étapes sont des données, pas du code en dur : mariage, événement, production, mission, création d'entreprise, travaux, voyage.
- **« Que dois-je faire ? »** : lecture de toute la ligne de temps, compteur blocages / validations / actions préparées / terminés, et la prochaine action recommandée avec ses boutons Voir et Valider.
- **« Que manque-t-il ? »** : documents, signatures, paiements, justificatifs, informations et échéances à risque absents pour boucler un projet.
- **Anomalies** : comparaison des objets reliés (devis 1 200 € / contrat 1 200 € / facture 1 350 €) → écart signalé, paiement placé en « à valider », jamais exécuté seul.
- **Recherche universelle** : un mot traverse tous les objets et remonte la grappe reliée.

### 4. Entrées et sorties

- **Intention → timeline** : une phrase (« Je me marie le 12 septembre 2027 avec 120 invités », « Je dois atteindre 507 heures cette année ») déclenche le rétroplanning correspondant, en propositions à valider. Prolongement direct de la barre d'agent existante.
- **Documents intelligents** : à l'import, extraction des personnes, dates, montants, lieux, références, puis « 6 informations détectées — ajouter à la ligne de temps ? ». Rattachement seulement après accord.
- **Vues spécialisées comme simples filtres** : le calque Intermittence affiche le compteur 507 h (heures validées, préparées, justificatifs manquants) ; le calque Mariage affiche le Jour J. Aucune nouvelle timeline.
- **Export** : AIME vérifie, l'humain valide, AIME exporte — vers client, prestataire, comptable, organisme.

## Ce qui reste hors de la ligne de temps

L'identité de la page (photo, présentation, savoir-faire) et les réglages : ils n'ont pas de date. Tout le reste est daté, donc représentable.

## Détails techniques

Extension de `TimelineMarker` en `TimelineItem` dans `HeroTimeline.tsx` (champs optionnels, aucune rupture des appels existants dans `carte.$id.tsx`, `index.tsx`, `demo.mariage.tsx`, `DashboardTimeline.tsx`). Nouvelle migration : `timeline_relations` (from_kind/from_id, to_kind/to_id, relation, card_id) et colonnes `status`/`priority`/`metadata` sur `card_timeline_entries`, avec GRANT et politiques RLS calquées sur l'existant ; réutilisation de `timeline_effects` pour les conséquences. Le graphe de relations est lu par un hook `useTimelineGraph(cardId)` au-dessus de `useCardTimelineSources`. Rétroplanning dans `src/lib/aime/retroplanning.ts` (modèles déclaratifs par type de projet + moteur générique de décalage). Analyse « que faire / que manque-t-il / anomalies » dans `src/lib/aime/timelineAudit.ts`, pur calcul côté client sur les objets déjà chargés. Extraction documentaire via une server function existante côté Lovable AI (`ai.functions.ts`), résultats retournés en propositions. `timelineFilters.ts` étendu aux nouvelles familles. Aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié.
