# Phase 4 — La démo alignée sur le projet, puis grand nettoyage des pages

Vous avez raison : aujourd'hui la démo mariage et la page d'un vrai projet ne se comportent pas pareil. Ce sont donc deux produits différents alors que ce devrait être la même chose, en lecture seule.

## 1. La démo devient exactement la page projet

Même scène, mêmes temps (Tout / Avant / Pendant / Après), mêmes volets (participants, paiements, facture, musique, causalité, ciel, dossiers), même bouton Lecture. Seules différences, assumées et visibles :

- rien ne s'enregistre : tout ce qu'on modifie reste le temps de la visite ;
- un bandeau discret « Page de démonstration » et le bouton « Activer ce mariage » restent en bas du panneau du cœur ;
- les volets s'ouvrent avec les données fictives, pas avec la base.

Concrètement : la démo gagne la même barre de volets que le projet, et le projet garde son comportement actuel. On regarde deux fois la même page.

## 2. Le nettoyage, par vagues

Le site compte aujourd'hui 40 pages réelles et 17 adresses qui ne font que rediriger. On enlève d'abord ce qui ne sert plus, sans rien casser : les adresses restent valides et renvoient vers la bonne page.

**Vague A — pages doublons à retirer (deviennent des redirections)**
- `/cockpit` → Mon espace (déjà remplacé par Mon espace)
- `/parametres` → Mon espace, onglet réglages
- `/profil` → Mon espace
- `/saisons` → Réseau
- `/entraide` → Mon espace
- `/frequence/$id` → la page de la carte concernée

**Vague B — pages à décider ensemble (rien n'est touché sans votre accord)**
- `/beta`, `/ambassadeur`, `/intermittent`, `/demande-profil`, `/invitation`, `/admin/enrichissement` : pages de campagne ou d'administration. Utiles ? Sinon on les sort des menus et du plan du site.
- `/aimes-recues` : son contenu existe déjà dans Mon espace.

**Vague C — les redirections anciennes**
Les 17 adresses de redirection sont conservées (SEO, liens partagés), mais retirées du plan du site et de tous les menus, pour qu'elles n'apparaissent plus nulle part.

**Hors périmètre** : `/bureau*` (gelé), les pages légales, les guides, `/plan-du-site`, `/auth`, `/credits`, `/comment-ca-marche`.

## 3. Le résultat visé

Cinq destinations dans la navigation : Accueil, Mon espace, Mes projets, Réseau, Bureau. Plus une démo publique qui est, à l'identique, ce que l'on obtient avec son propre mariage.

## Détails techniques

`demo.mariage.tsx` reprend le même agencement que `projets.$id.index.tsx` : `validateSearch` avec `panneau`, rendu de `ProjectPanelDock` sous `ProjectStage`, et un `ProjectPanel` alimenté par `demoWedding()` au lieu des requêtes Supabase (aucune requête ajoutée). Les volets qui exigent des données serveur (paiements Stripe, dossiers Bureau) affichent leur état fictif en lecture seule. `onProjectChange` continue d'alimenter l'état local `enriched`, sans persistance.

Nettoyage : remplacement du corps de `cockpit.tsx`, `parametres.tsx`, `profil.tsx`, `saisons.tsx`, `entraide.tsx`, `frequence.$id.tsx` par un `beforeLoad` + `redirect` (statusCode 301), suppression de leurs entrées dans `navigation.ts`, `plan-du-site.tsx`, `sitemap[.]xml.ts` et les menus. Aucune table, RLS ni route `/bureau` touchée. Typecheck après chaque vague.

## Ordre

1. Alignement de la démo sur la page projet.
2. Vague A (doublons) + nettoyage des menus et du plan du site.
3. Décision sur la vague B, puis exécution.
