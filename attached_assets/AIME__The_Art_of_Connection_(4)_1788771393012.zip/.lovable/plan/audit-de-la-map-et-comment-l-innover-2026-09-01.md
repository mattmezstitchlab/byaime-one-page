# Audit de la Map — et comment l'innover

## Ce que fait la carte aujourd'hui (constaté dans le code)

- Fond de carte : tuiles images OpenStreetMap standard, via Leaflet. Rendu générique, aux antipodes de la direction ivoire/noir du site.
- Positions : aucune adresse réelle en base. Les coordonnées viennent d'un dictionnaire de ~100 villes écrit à la main (`src/lib/aime/geo.ts`), plus un léger décalage aléatoire. Une carte dont la ville n'est pas dans la liste **n'apparaît pas du tout** sur la map.
- Marqueurs : une vignette ronde par carte, toutes dessinées en même temps, sans regroupement. Au-dessus de quelques centaines de cartes, la carte devient illisible et lente.
- Éphémères : vignette rectangulaire reliée en pointillé à son auteur — c'est la meilleure idée de la map actuelle.
- Recherche : filtre par nom/ville/tag, une seule ville à la fois, sans lien avec ce que l'on voit à l'écran (déplacer la carte ne change pas les résultats).
- Le cadrage n'est calculé qu'une fois ; ensuite la carte ne se réajuste plus aux filtres.

## Le verdict

Le modèle « épingles sur une carte routière » est le degré zéro de l'annuaire géographique. Il répond à « où est cette personne ? » alors qu'AIME pose une autre question : « avec qui puis-je faire quelque chose ? ». La géographie n'est pas la matière première d'AIME — la **relation** l'est.

Il y a donc mieux, et cela se joue sur deux plans : la qualité du rendu, et le modèle d'interaction.

## Proposition — la Carte Vivante

### 1. Un fond de carte à nous
Passer d'un fond image OSM à un fond vectoriel stylé maison : ivoire, routes en traits fins, texte discret, zéro bruit commercial. La carte devient un objet du design system et non une capture Google. Les vignettes de profil deviennent enfin le seul élément coloré de l'écran.

### 2. Regroupement vivant et lecture par niveau de zoom
- Loin : des **halos de villes** dont la taille dit la densité du réseau (« Lille · 42 »).
- Moyen : des grappes de vignettes qui s'écartent en éventail au survol.
- Près : la vignette pleine, avec accroche et statut.
Fin des empilements et de la lenteur, quel que soit le nombre de cartes.

### 3. Les liens visibles — la constellation
La force d'AIME, c'est ce qui relie les cartes. Tracer en traits fins les relations réelles : rencontres passées, projets communs, prestataires d'un même événement. En ouvrant une carte, son réseau s'illumine et le reste s'estompe. C'est la vue que personne d'autre n'a.

### 4. La carte suit la recherche, et la recherche suit la carte
Panneau latéral synchronisé : ce que l'on voit à l'écran est la liste, la liste est ce que l'on voit. Survoler une ligne éclaire la vignette et inversement. Filtres cumulables (univers, métier, disponibilité, budget) au lieu d'une seule ville.

### 5. La couche temps
Un curseur de temps en bas : les éphémères des dernières 24 h, les événements à venir, les disponibilités du mois. La map cesse d'être un annuaire figé pour devenir un fil d'actualité géographique.

### 6. Le mode Composition
Depuis la map, glisser des vignettes dans un « plateau » latéral pour composer une équipe (lieu + traiteur + photographe…). La carte affiche alors les distances entre eux et un temps de trajet total. La géographie sert enfin à décider, pas seulement à situer.

### 7. Adresses réelles
Ajouter latitude/longitude sur les cartes, remplies au moment de la création ou de l'enrichissement. Le dictionnaire de villes reste seulement en dernier recours. Toute carte devient plaçable, partout dans le monde.

## Détails techniques

- Remplacement de Leaflet par MapLibre GL JS (rendu vectoriel WebGL, style JSON maison aux tokens du design system, chargé côté client uniquement comme aujourd'hui).
- Marqueurs et grappes rendus en couches natives (`symbol`/`circle` + clustering GeoJSON) plutôt qu'en éléments HTML, pour la fluidité ; seule la vignette sélectionnée reste un élément React superposé.
- Colonnes `lat`/`lon` sur `cards`, remplies par géocodage à l'enrichissement, repli sur `coordsFor`.
- Liens de constellation dérivés de `encounters`, `composition_items` et des dossiers d'événements, dessinés en couche `line`.
- Filtrage lié à l'emprise visible (`moveend`) et partagé avec le panneau liste.
- Le bouton cœur flottant, les éphémères et l'encart noir sont conservés tels quels.

## Ordre de réalisation proposé

1. Fond vectoriel stylé + regroupement par zoom (le saut visuel le plus fort, sans changement de données).
2. Panneau liste synchronisé et filtres cumulables.
3. Coordonnées réelles et géocodage.
4. Constellation des liens.
5. Curseur de temps et mode Composition.
