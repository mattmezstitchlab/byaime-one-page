# Audit : où on en est, ce qu'on nettoie, et la page unique pilotée par l'agent

## 1. Le bug constaté sur mobile (cause vérifiée)

Sur l'accueil, la ligne de temps tourne toute seule (`autoScroll`). Quand elle passe sur un repère, la bulle d'aperçu s'affiche — et sur mobile cette bulle est **collée en bas de l'écran** (position fixe). Comme la démo ne s'arrête jamais, une carte reste affichée en permanence par-dessus la page, même quand on a fait défiler bien plus bas. Sur ordinateur la bulle est ancrée au repère, donc elle disparaît de la vue : le problème ne se voit pas.

Correctifs :
- Sur mobile, la bulle en feuille basse ne s'ouvre plus que sur **appui volontaire** ; le survol automatique de la démo n'ouvre plus rien.
- La bulle se ferme automatiquement dès que la section de la ligne de temps sort de l'écran.
- Sur mobile, la démo d'accueil devient un aperçu simple (moins de mouvement, pas de bulle flottante).

## 2. État des lieux : 55 pages pour 4 vraies destinations

La décision prise reste la bonne : Accueil, Le Monde AIME (`/reseau`), Ma page (`/carte/$id`), et les panneaux AI/ME. Or il subsiste beaucoup de pages héritées qui font doublon avec des onglets de la page.

À faire disparaître de la navigation (URL conservée en simple redirection, aucune donnée supprimée) :

| Page héritée | Devient |
|---|---|
| `/tableau-de-bord`, `/cockpit`, `/parametres` | onglets/panneaux de ma page |
| `/projets`, `/projets/$id/*`, `/evenements`, `/evenement/$` | onglet Projets de ma page (repères sur la ligne de temps) |
| `/bureau*` | onglet Bureau de ma page |
| `/messages`, `/aimes-recues` | repères Message sur la ligne de temps |
| `/rencontres`, `/monde`, `/registre`, `/saisons` | vues de `/reseau` |
| `/ma-carte` | déjà redirigé vers `/ma-page` |
| `/chemin`, `/objectif`, `/entraide`, `/communs`, `/frequence/$id` | retirés des menus, gardés en URL |

Restent des pages à part entière : Accueil, `/reseau`, `/carte/$id`, `/ma-page`, `/auth`, `/credits`, `/comment-ca-marche`, les pages légales, les guides SEO, `/plan-du-site`.

## 3. Ce qui passe dans la ligne de temps (et ce qui n'y passe pas)

Déjà en place : disponibilités, repères de carte, avis, documents, devis, factures, paiements, événements, messages, tâches, dossiers de regroupement, filtres par famille.

Ce qu'il reste à y faire passer :
- **Créneaux horaires** : un repère peut porter une heure de début et de fin et s'affiche comme une petite barre horaire (indispensable pour un jour J de mariage : 14 h cérémonie, 16 h photos, 19 h dîner).
- **Demandes reçues** (les « aimes ») : un repère daté avec accepter / refuser dans la bulle.
- **Participants et prestataires d'un projet** : vignettes rondes posées à la date du projet.
- **Projet = dossier** : un projet devient un dossier daté qui contient tous ses repères.

Ce qui ne peut pas y passer, parce que non daté : l'identité de la page (photo, phrase, savoir-faire) et les réglages. Ils restent en haut de la page.

## 4. Le champ de l'agent, sous le héros de ma page

Un seul champ de saisie, placé juste sous le héros de la page, remplace les champs éparpillés. Ce qu'on y écrit s'adresse à l'agent Aime, et **la ligne de temps répond** :

- « photographe dispo en juin » → la ligne se déplace sur juin et met au centre ce qui correspond ; le reste s'estompe.
- « note le rendez-vous traiteur mardi 15 h » → l'agent pose un repère **en attente** à la bonne date avec le créneau, la carte s'ouvre sur la ligne, on valide ou on modifie sur place.
- « écris à Julie pour confirmer » → l'agent affiche le message rédigé dans la bulle de la carte concernée, avec Envoyer / Modifier.
- « organise le 12 juillet » → l'agent crée le dossier du jour J et propose les créneaux horaires, à valider un par un.

Règle absolue : **l'agent prépare, l'utilisateur valide.** Rien n'est écrit sans un geste de validation, et tout ce qu'il prépare apparaît à l'endroit concerné (sur la date, sur la carte), jamais dans une fenêtre séparée.

## 5. Livraisons

1. **Correctif + nettoyage** — bulle mobile, menus réduits aux quatre destinations, redirections des pages héritées.
2. **Le temps précis** — créneaux horaires sur les repères, demandes reçues et participants sur la ligne, projet-dossier.
3. **L'agent au centre** — champ unique sous le héros, recentrage animé de la ligne, propositions en attente de validation (repère, message, événement, jour J).

## Détails techniques

`HeroTimeline.tsx` : la bulle mobile n'est plus déclenchée par `hovered` mais uniquement par `pinned` ; fermeture via `IntersectionObserver` sur le conteneur ; `autoScroll` n'émet plus de survol fantôme sous `md`. Ajout de `startTime`/`endTime` optionnels sur `TimelineMarker`, rendus en segment horaire avec libellé d'heures, plus une méthode impérative `focusRange(from, to)` pour l'animation de recentrage. Nouveau `src/lib/aime/agentIntent.ts` : analyse de la saisie via l'AI Gateway (`generateText` + `Output.object`, schéma court sans bornes, garde `NoObjectGeneratedError`) renvoyant `{ action, dateRange, time, cardRef, draft }`, exécuté dans un `createServerFn`. Les propositions vivent en état local `pendingMarkers` fusionné aux repères réels avec un style « en attente » ; la validation réutilise les mutations existantes (`card_timeline_entries`, `sendMessage`, `events`) — aucune écriture avant validation. Nettoyage : suppression des entrées de menu dans `LogoMenu.tsx`, `MobileMenu.tsx`, `AppShell.tsx` et du footer, remplacement du corps des routes héritées par un `redirect` de loader ; aucune table supprimée, aucun changement de RLS, `geo.ts` intact, les quatre findings de sécurité inchangés.
