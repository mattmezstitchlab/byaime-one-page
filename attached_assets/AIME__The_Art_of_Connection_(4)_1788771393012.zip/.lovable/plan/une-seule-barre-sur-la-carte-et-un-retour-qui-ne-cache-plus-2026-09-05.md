# Une seule barre sur la carte, et un retour qui ne cache plus rien

Aujourd'hui sur la carte du réseau, trois éléments flottent séparément : le champ de recherche, puis en dessous le cœur et les filtres, et par-dessus tout un bouton « Retour » posé en haut à gauche qui recouvre le titre de la page ou les premiers boutons.

## Ce qui change

**1. Une barre unique sur la carte**

Le champ de recherche, le bouton « autour de moi », le cœur (déposer une intention) et les filtres se réunissent dans une seule capsule arrondie, en haut de la carte :

```text
[ 🔍 Un nom, une ville, un savoir-faire…   ◎ │ ♥ │ ⚙ 2 ]
```

- séparateur discret entre la saisie et les deux actions, pour qu'on comprenne que ce sont des commandes et pas du texte
- la pastille du nombre de filtres actifs reste visible sur le bouton filtres
- sur grand écran, le mot « Filtres » réapparaît à côté de l'icône
- les suggestions et les étiquettes (ville, catégorie) continuent de s'afficher juste en dessous, sans changement
- toutes les cibles restent à 44 px minimum au doigt

**2. Le bouton Retour ne flotte plus par-dessus la page**

Il rejoint la barre du haut du site, à gauche du logo AIME, sous forme de flèche ronde. Il ne recouvre donc plus jamais un titre, un bouton ou une information. Sur la carte, cela libère aussi tout le coin supérieur gauche.

Il garde exactement le même comportement : revenir à l'écran précédent, ou à l'accueil s'il n'y a pas d'historique, et il reste invisible sur l'accueil.

## Détails techniques

- `src/routes/reseau.tsx` : fusion du bloc de commandes (`mt-2 flex items-center justify-end`) dans la capsule de recherche existante ; les états `fluxOpen`, `filtersOpen`, `activeFilterCount` et les handlers restent inchangés.
- `src/components/aime/BackButton.tsx` : suppression de la variante fixe `fixed left-4 top-[80px]` ; le composant ne rend plus que la version compacte en flèche ronde (44 px), avec `aria-label` conservé.
- `src/components/aime/AppShell.tsx` : `<BackButton />` déplacé hors du flux flottant, inséré dans la grille d'en-tête avant le logo, conditionné comme aujourd'hui par `chrome === "full" && showBackButton`. En-tête en `grid-cols-[auto_minmax(0,1fr)_auto]` avec `min-w-0` pour éviter tout écrasement sur petit écran.
- Vérification : `/reseau`, `/recherche`, `/carte/:id`, `/demo/mariage` en 320 px et en 1280 px.
