# Vos autres projets Lovable : que vaut-il vraiment la peine de reprendre ?

Verdict honnête d'abord : sur 13 projets, **deux seulement** apportent quelque chose que AIME n'a pas déjà. Le reste est soit hors sujet, soit déjà refait en mieux ici.

## Ce que j'ai regardé

- **[MSA Innovation](/projects/2c19c03f-eec0-4bd6-a866-a871e2c86b51)** + ses 2 remix — OCR de PDF de formation, graphe familial, courrier de réclamation. Domaine administratif, aucun rapport avec le réseau de rencontres. **À ne pas reprendre.**
- **[Easy Docs Generator](/projects/e2af91b5-4f24-43d8-8782-e175861e4c6f)** — devis / factures / contrats, 89 fichiers, 4 routes. AIME a déjà `/devis/$cardId`, la facture imprimable et le suivi des paiements Stripe. Seule idée neuve : le **contrat**. **Rien à copier, une idée à retenir.**
- **[Page Architect](/projects/cd2032b3-c689-4d3c-8b05-2b966de44c05)**, **[Project Ascend](/projects/71706e19-234b-414a-aebe-c6790185ac1a)**, **[Finish It Up!](/projects/9c131245-9662-4dcd-b49a-b05ac3f46198)**, **[AIME Studio](/projects/ad653c5e-27c1-4210-bc28-c6ce4542083b)**, **[Landing Page Linker](/projects/fff86a74-d743-4b17-ba5c-aa57bf60ab3b)**, **[Apple Vision Design](/projects/5661010d-9ac0-4fc1-afe0-ac89d6b4a8bf)**, **[My Favorite Books](/projects/b8d7bb1f-7004-4daa-a8a6-4cf4e4bbcdb7)** — outils méta (constructeurs de sites, correcteurs de projets) ou tests. **Rien à reprendre.**
- **[Eventflix Studio](/projects/4c200172-afbd-4b0b-9e9d-1d2aeda14d12)** — 418 fichiers, le plus abouti après AIME. Vraie valeur.
- **[The Day Weaver](/projects/5fb5b0cb-d1e2-4fc7-a3e0-cf5028a1636a)** — expérience de mariage cinématique. Valeur ciblée.

## Les 4 choses qui valent vraiment le coup

### 1. Les pages SEO par métier × ville (Eventflix)
Routes `guides/$domain/$city`, `titre/$slug`, `domaines/$slug` et un `sitemap.xml` généré. C'est le seul vrai moteur d'acquisition gratuite, et AIME n'a rien de tel : aujourd'hui tout est derrière des pages dynamiques non indexables. Traduit pour AIME : des pages « Photographe de mariage à Lille » alimentées par le registre existant, avec maillage vers les cartes.

### 2. Le mode Jour J (Eventflix)
`day-of/live-screen` + `jour-j` : un écran temps réel du déroulé, minute par minute, partagé aux prestataires. AIME a la timeline d'une carte mais pas d'écran live de la journée. C'est le complément naturel de la timeline et des projets.

### 3. La page publique d'événement, cinématique (The Day Weaver)
`w/$slug` : page publique par événement avec scènes, RSVP, livre d'or, playlist, audio d'ambiance. AIME a les invitations et les participants mais pas de vitrine publique. À rapprocher de la Radio AIME (playlist, TTS déjà présents des deux côtés).

### 4. Deux briques secondaires
- **Conseiller budget** (Eventflix `budget-advisor`) : répartition budgétaire par poste, à brancher sur les devis AIME.
- **Contrat signé** (Easy Docs + Eventflix `contract.ts`) : le maillon manquant entre devis accepté et paiement.

## Ce qu'il ne faut PAS reprendre

Recopier du code d'Eventflix serait une erreur : conventions différentes (`src/components/pages/`, `app-state`, son propre i18n, son propre système de crédits et de paiements). AIME a déjà tout cet équivalent, en plus cohérent. **On reprend des concepts et des schémas de données, pas des fichiers.** Les visuels d'Eventflix et Day Weaver sont des pointeurs d'assets projet ; ils devront être régénérés ou re-téléversés, pas copiés.

## Ma recommandation, franchement

Honnêtement : **une seule chose vaut le détour à court terme, les pages SEO métier × ville.** C'est le seul manque qui coûte des utilisateurs tous les jours. Le Jour J et la page publique d'événement sont de belles idées mais AIME a déjà de quoi les construire seul, sans détour par un autre projet. Le reste : à archiver.

## Ordre proposé si vous validez

1. Pages SEO métier × ville + sitemap, alimentées par le registre AIME.
2. Écran Jour J temps réel branché sur la timeline et les participants d'un projet.
3. Page publique d'événement (RSVP, livre d'or, playlist reliée à la Radio).
4. Conseiller budget + contrat signé avant paiement.

Dites-moi si vous voulez que j'ouvre le chantier 1, ou que je détaille l'un des autres avant.
