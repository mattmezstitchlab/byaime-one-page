# Alléger le visuel des pages publiques

## Constat vérifié

Sur la fiche publique `/carte/:id`, les commandes sont actuellement empilées sur le visuel :

- le bouton « Retour » est fixé en haut à gauche par l’enveloppe générale ;
- le cœur est ancré au centre, au-dessus de la ligne de temps ;
- les calques et la capsule temporelle sont placés entre le texte et la ligne de temps ;
- le bouton Play est ajouté en position flottante par l’enveloppe de lecture ;
- la section Médias existe déjà après le bloc visuel, mais elle n’apparaît que lorsqu’il y a des médias ou pour le propriétaire.

Cette accumulation masque le contenu et prend trop de hauteur, surtout sur téléphone.

## Nouvelle organisation de la fiche publique

1. **Libérer entièrement le visuel**
   - Retirer du visuel le cœur, la capsule temporelle, Play et le bouton Retour avec son texte.
   - Conserver sur l’image uniquement l’identité de la page et la ligne de temps.
   - Sortir également « Calques » de l’image afin que toutes les commandes vivent au même endroit.

2. **Créer une barre compacte sous la ligne de temps**
   - À gauche : une simple flèche de retour, sans le mot « Retour ».
   - Au centre : un petit sélecteur aligné `Tout · Avant · Aujourd’hui · À venir`.
   - À droite : deux boutons ronds de même taille, cœur puis Play.
   - Placer « Calques » comme commande secondaire discrète dans cette même zone, sans recouvrir le média.
   - Sur les très petits écrans, conserver les boutons fixes sur les côtés et permettre au sélecteur central de tenir sans débordement.

3. **Préserver les interactions existantes**
   - Les périodes continuent à recadrer la même ligne de temps ; « Aujourd’hui » remplace l’actuel doublon entre recentrage et phase en cours.
   - Le cœur ouvre exactement le même panneau et conserve toutes ses actions.
   - Play utilise le même moteur, le même menu et la même mise en évidence des repères.
   - La flèche conserve le retour navigateur avec repli vers l’accueil.

4. **Rendre la suite de page évidente**
   - Faire commencer la section Médias immédiatement après la nouvelle barre, avec un espacement réduit sur téléphone.
   - Afficher la grille publique dès qu’un média visible existe ; ne pas inventer de contenu si la page est vide.
   - Garder ensuite les informations « Ce que je fais », « Mes mondes » et le reste de la fiche.

## Périmètre

- Appliquer ce montage uniquement aux pages publiques `/carte/:id`.
- Ne pas modifier la présentation des pages projet ni de la démo mariage.
- Ne pas toucher aux routes `/bureau`, aux règles de sécurité ni aux données.

## Vérification

- Contrôler la fiche à 430 px puis à une largeur téléphone plus étroite : aucun chevauchement ni défilement horizontal.
- Vérifier les quatre filtres temporels, le retour, l’ouverture du cœur, le menu Play et les calques.
- Vérifier qu’une page avec médias montre bien ses vignettes immédiatement sous les commandes, et qu’une page vide reste propre.
- Vérifier aussi l’affichage sur ordinateur pour conserver une hiérarchie cohérente.
