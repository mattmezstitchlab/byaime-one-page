# Mes projets : fusionner « Mon événement » et « Événements »

## Le constat

Aujourd'hui deux pages font le même métier avec deux entrées de menu :

- `/mon-evenement` : un formulaire de création (titre, date, ville, invités, budget, ambiance) + composition IA des participants, hérité de l'époque « mariage ».
- `/evenements` : le calendrier partagé + la liste des événements existants + les réponses des participants.

C'est le même objet (un projet daté avec des participants), coupé en deux : on crée d'un côté, on consulte de l'autre. Et le mot « événement » est doublement chargé, puisque « Événement » est aussi l'un des 12 univers.

## Ce qu'on en fait

Une seule entrée de menu : **Mes projets**.

```text
Mes projets (/projets)
├── liste des projets + calendrier partagé   (ex-/evenements)
└── Nouveau projet                            (ex-/mon-evenement)
        └── /projets/$id  = la page du projet
```

Un projet = un mariage, un concert, un déménagement, un anniversaire, une expo — n'importe lequel des 12 univers. Le formulaire actuel reste, mais devient générique : le titre par défaut n'est plus « Mariage de Camille & Antoine », l'univers choisi adapte le vocabulaire (invités/participants/spectateurs) et le brief envoyé à l'IA.

### Répartition claire des rôles

| Objet | Rôle |
| --- | --- |
| **Carte** (`/carte/$id`) | Une identité durable : personne, lieu, service, ressource. Sa timeline, son calendrier, son cœur. |
| **Projet** (`/projets/$id`) | Une intention datée qui assemble des cartes : participants, budget, paiements, timeline du jour J. |
| **Registre** | Toutes les cartes. |
| **Composer** | Le moteur IA qui propose des cartes ; son résultat s'enregistre en projet. |

La carte n'est pas l'éditeur du projet : c'est l'inverse. Le projet est l'éditeur, et il embarque des cartes. Un projet peut néanmoins publier sa propre carte (kind `evenement`) pour être visible dans le Registre et sur la Map — un bouton « Publier dans le registre » sur la page projet.

## Détail technique

- Nouvelles routes : `src/routes/projets.index.tsx` (liste + calendrier, contenu de `evenements.tsx`), `src/routes/projets.nouveau.tsx` (contenu de `mon-evenement.tsx`), `src/routes/projets.$id.tsx` (page projet : participants, paiements, musicbox, timeline — aujourd'hui éclatée en `evenement.$id.*`).
- Les routes `evenement.$id.participants|paiements|musicbox` deviennent `projets.$id.*` ; anciennes routes conservées en redirections permanentes pour ne pas casser les URLs.
- Aucun changement de schéma : la table reste `events` / `event_participants`. Seuls les libellés changent côté UI.
- `AppShell` : `NAV` passe de six à cinq entrées — Réseau, Composer, Registre, Découvrir, **Mes projets**.
- Chaque route reçoit son propre `head()` (titre/description/og distincts).
- Le titre par défaut du formulaire devient vide avec un placeholder contextuel selon l'univers.

## Hors périmètre

Découvrir, Réseau, Registre, la carte et le cœur ne bougent pas.
