# Bande des univers, pages publiques allégées et nettoyage

## 1. La bande des univers change de place

- Elle disparaît des pages publiques (`/carte/...`) : une page de personne ne montre plus la galerie de tous les univers.
- Elle apparaît sur l'accueil, juste sous le hero, précédée d'un court texte éditorial qui explique le concept : chaque univers est un monde de rencontres, tout ce qui existe peut devenir une carte, et une seule ligne de temps relie le tout.
- Elle apparaît aussi dans la page d'un projet (mariage), sous la ligne de temps, comme moyen d'aller chercher des personnes à rattacher au projet.

## 2. Page publique d'une personne

- Suppression du bouton « Modifier ma page » : la modification se fait déjà depuis Mon espace.
- Contenu sous le hero remis à plat et resserré sur ce qui parle d'une personne :
  - ce qu'elle propose et où (univers de la personne uniquement, pas la galerie générale) ;
  - sa ligne de temps publique ;
  - les outils réservés au propriétaire (ajout de repère, boussole, rétroplanning) regroupés dans un seul bloc discret, visible seulement pour lui ;
  - la liste « Mes mondes » retirée de la page publique : elle vit dans Mon espace.

## 3. Header

Ordre à droite : **Mon espace**, puis le bouton profil, puis le bouton carte. Les deux pictogrammes quittent le centre du header et rejoignent le groupe de droite, avec la Radio et le compteur inchangés.

## 4. Doublons relevés (à nettoyer)

- La bande des univers présente à la fois sur l'accueil et sur chaque page publique.
- Deux façons d'atteindre la modification de sa page : bouton sur la page publique + Mon espace.
- Deux listes de mondes : page publique et Mon espace.
- Sur la page projet : le résumé des trois phases répète des repères déjà lus sur la ligne de temps ; à réduire à un simple compte ou à supprimer au profit des panneaux.
- Bouton « Publier dans le registre » posé à côté de la barre de panneaux alors que la publication est une action de page ; à rapatrier dans le panneau concerné.

## 5. Pages encore à supprimer

Ces adresses ne sont plus référencées nulle part dans l'application et ne servent que de renvoi :

- `/registre` → Réseau
- `/monde` → Réseau
- `/ma-page` → Mon espace
- `/evenements` → Mon espace
- `/projets` (liste) → Mon espace

Comme le site est publié, je propose de les garder encore un temps en simple renvoi (elles peuvent exister dans des liens externes ou dans Google) et de ne supprimer que celles que vous confirmez. Dites-moi si vous préférez la suppression sèche comme pour Messages et Bureau.

## Détails techniques

- `UniverseVideoGrid` retiré de `src/routes/carte.$id.tsx` (section `#univers`), monté dans `src/routes/index.tsx` sous `HomeJourney` avec un bloc éditorial, et dans `src/routes/projets.$id.index.tsx` sous `ProjectStage`.
- `carte.$id.tsx` : suppression du lien « Modifier ma page » et de la section « Mes mondes » ; regroupement des outils propriétaire.
- `AppShell.tsx` : la `nav` centrale devient un groupe placé après le lien Mon espace dans la colonne de droite ; `grid-cols-[auto_1fr_auto]` conservé, colonne centrale vide ou supprimée.
- Aucun changement de données, de règles de sécurité ni de logique métier.
