# AIME MusicBox + Radio AIME — et nettoyage du header

La timeline du hero reste spatiotemporelle. C'est le **calendrier** de chaque page qui devient une MusicBox : une grille de dates programmable, connectée à une radio vivante.

## 1. Header (correction immédiate)

- Suppression de « Accueil » — le logo AIME devient le bouton d'accueil.
- Suppression du doublon « Mon espace » : une seule entrée, en picto.
- Fin des deux barres de navigation : une seule ligne. Rencontres, Registre, Découvrir, Événements restent en texte ; Mon espace, Messages et Aimes reçues deviennent trois pictos à droite.
- Le picto Aimes reçues est un cœur avec pastille de notification (nombre d'aimes non lues, mise à jour en direct).
- Nouveau picto Radio à droite : bouton on/off de la Radio AIME, avec point pulsé quand elle diffuse.
- En mobile, la barre du bas reprend les mêmes pictos.

## 2. La MusicBox (calendrier programmable)

Le calendrier mensuel existant (page carte, mon espace, événements) gagne une seconde vie. Un clic sur une date ouvre un panneau de programmation où l'on ajoute une **entrée** :

- **Type** : morceau de musique, message vocal, annonce, récit / conte / lecture, biographie, tâche, rendez-vous.
- **Contenu** : un lien externe (YouTube, Spotify, SoundCloud) **ou** un fichier audio déposé (messages vocaux, récits, créations perso).
- **Créneau horaire** : heure de début et durée — c'est ce qui rend la journée programmable.
- **Dédicace** : « pour quelqu'un » (un membre, une carte) avec un mot, ou rien.
- **Visibilité** : privé, invités uniquement, public.

La date affiche un point coloré par type d'entrée, et le nombre d'entrées. Les jours programmés se distinguent des jours de disponibilité (qui restent).

### Playlist collaborative (mariage / événement)

Sur une page d'événement, la MusicBox bascule en mode collaboratif : les invités proposent des morceaux et des messages sur les dates du mariage, l'organisateur valide, réordonne, et la journée se lit comme un conducteur (cérémonie, repas, soirée) mêlant musique, dédicaces, tâches et rendez-vous.

## 3. Radio AIME

Un bouton Radio en haut à droite. Une fois enclenché :

- La radio lit **en direct** ce qui est programmé maintenant dans les MusicBox autour de vous.
- Tout le monde voit sa grille évoluer en live : point pulsé sur l'entrée en cours, compte à rebours avant la suivante, badge « à l'antenne ».
- **Portée géographique** : géolocalisation du navigateur (avec accord explicite) + curseur de distance — quartier, ville, région. Une suggestion propose d'ouvrir la radio au voisinage ; on peut refuser ou élargir.
- Repli propre si la géolocalisation est refusée : station de la ville du profil.

### L'animatrice

Entre deux morceaux, l'entremetteuse présente : elle annonce le titre, dit pour qui c'est, glisse un mot tendre ou taquin. Le texte est écrit par l'IA, puis **transformé en voix une seule fois et conservée** — la même annonce est rejouée à tout le monde sans regénérer, donc le coût reste maîtrisé. Le texte est aussi affiché à l'écran.

L'écoute hors écran est possible : la radio continue en arrière-plan (contrôles média du système, titre + animatrice), avec accord explicite. Une mariée peut donc laisser AIME parler de son mariage pendant qu'elle fait autre chose.

## 4. Ce que ça implique côté données

Nouvelles tables : entrées de MusicBox (date, créneau, type, lien ou fichier, dédicataire, visibilité, statut de validation), propositions d'invités, stations radio (zone, rayon, ville), annonces d'animatrice mises en cache, et préférences de géolocalisation par membre. Règles d'accès : chaque membre gère ses entrées, l'organisateur valide celles de son événement, seules les entrées publiques alimentent la radio de zone.

## Détails techniques

- Extension de `MonthCalendar.tsx` avec un mode « musicbox » (points par type, densité) plutôt qu'un composant concurrent ; nouveau panneau `MusicBoxDay`.
- Audio déposé dans un bucket dédié, lecture par URL signée ; liens externes rendus via lecteur embarqué (pas de réhébergement, pas de problème de droits).
- Horloge radio calculée serveur (`createServerFn`) pour que tout le monde voie la même chose, plus Realtime sur les entrées pour les changements en direct.
- Annonces animatrice : texte généré par l'IA Lovable, synthèse vocale mise en cache dans le stockage, une génération par annonce.
- Sélection par proximité : coordonnées lat/lon sur profil et station, filtre par rayon.
- Lecture en arrière-plan via l'API Media Session ; pas d'app native.

## Livraison

Tout d'un coup, dans cet ordre : header → tables → MusicBox → playlist collaborative → radio + géolocalisation → animatrice.
