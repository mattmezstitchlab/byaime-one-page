# Architecture AIME — accord de principe et mise en œuvre

## 1. Le mécanisme, confirmé

Oui, tout ce que tu décris tient dans un seul modèle cohérent :

**Une carte = une page = une timeline = un calendrier.** Peu importe que la carte soit une personne, un lieu, un prestataire, un projet ou un événement : même gabarit visuel, même page, mêmes briques.

Une carte peut naître de deux façons :
- **Bouton « Créer ma carte »** dans le hero de l'accueil (voie directe, formulaire progressif existant).
- **L'entremetteuse**, qui raisonne sur ce que tu écris. Quand elle détecte qu'un projet mérite d'exister comme carte (« je veux organiser un festival de jazz à Lille en juin »), elle le dit : elle explique le potentiel, ce que la carte permettrait, qui pourrait être mis en relation, ce qu'on peut partager avec d'autres membres — puis propose un bouton « Créer cette carte » pré-rempli (nom, univers, ville, accroche, tags). L'utilisateur reste maître : il peut refuser et continuer à chercher.

Toutes les cartes remontent dans **Registre**, et en **suggestions** en bas des pages de cartes (même univers / même ville / tags communs).

## 2. Le cœur est universel — pas de bouton « Ajouter à mon événement »

Point de subtilité que tu soulèves : le cœur AIME **est** le mécanisme universel. Réserver un prestataire, s'associer, contacter, enregistrer : ce sont des **intentions** du cœur, pas des boutons séparés. On supprime donc « Ajouter à mon événement » comme bouton distinct ; à la place, l'intention « Réserver » (ou « Associer ») propose, une fois posée, de la rattacher à un de mes événements. Une seule grammaire, partout.

## 3. La page d'une carte, remise à plat

Ordre définitif :

1. **Hero** (visuel ou vidéo) + identité + cœur AIME.
2. **Timeline** passé / présent / futur (bande sous le hero, déjà en place) — enrichie : voir §4.
3. **Calendrier du sujet** — un seul calendrier, plus de doublon MusicBox.
4. Présentation, savoir-faire, expériences, avis.
5. **Tags cliquables** → `/registre?tag=...` pour voir toutes les cartes portant ce tag.
6. Cartes suggérées.

### Le calendrier : un seul, avec un menu au clic

Le calendrier actuel et la MusicBox fusionnent. Un clic sur une date ouvre une feuille de choix contextuelle :

- Programmer un moment radio (musique, message, récit, dédicace)
- Poser une disponibilité / une option / marquer complet *(propriétaire)*
- Créer un repère de timeline
- Proposer un rendez-vous / une date à l'autre
- Voir ce qui existe déjà ce jour-là

La MusicBox disparaît comme bloc séparé : c'est une des entrées de ce menu. La Radio AIME continue de lire ces moments programmés.

## 4. La timeline devient sociale

Sur la règle graduée, en plus des repères actuels :

- **Vignettes rondes de profil** (photo des personnes rattachées à ce moment — parfait pour un mariage : les mariés, le photographe, le traiteur…).
- Au clic sur une vignette : encart avec la personne, son rôle sur ce moment, et des **boutons d'action** contextuels (voir sa carte, lui écrire, confirmer, proposer une date).
- Les repères peuvent porter, en plus du texte : **messages**, **documents**, **tâches / missions** avec un statut (à faire, en cours, fait) et un responsable.

## 5. « Rencontres » devient **Carte du réseau** (`/reseau`)

Refonte complète :

- **Plus de hero.** La carte géographique occupe tout l'écran, en plein écran, sous le header (elle ne passera plus au-dessus : correction du z-index).
- En haut, flottante sur la map : une **barre de recherche intelligente** qui affiche les mêmes petites étiquettes que sur les pages (noms, tags, villes). Au clic sur une étiquette, la map vole jusqu'à la vignette ronde correspondante.
- **Vignettes rondes de profil** comme marqueurs. Clic → petit encart flottant : intentions du cœur, et possibilité de **retourner l'encart** pour lire les infos de la personne.
- Dans cet encart : boutons **« Proposer »** et **« Publier une intention »**.
- L'ancien empilement (hero + double champ de saisie + flux d'intentions redondant) est supprimé.

## 6. Détails techniques

- Base : nouvelle table `timeline_people` (repère ↔ carte, rôle) et extension de `card_timeline_entries` avec `documents` (jsonb), `task_status`, `assignee_card_id`. Grants + RLS comme les tables existantes.
- `MusicBox.tsx` : le calendrier interne est retiré ; le composant devient `DayActionsSheet` alimenté par le calendrier unique de la page carte.
- `HeroTimeline.tsx` : ajout d'une piste de vignettes rondes et d'un panneau de détail (messages / documents / tâches).
- `AimeButton.tsx` : après une intention « Réserver », proposer le rattachement à un événement ; suppression du bouton « Ajouter à mon événement » de `carte.$id.tsx`.
- Tags : `Link` vers `/registre` avec un nouveau paramètre de recherche `tag`.
- Nouvelle route `src/routes/reseau.tsx` (map plein écran) ; `rencontres.tsx` redirige vers elle. `CardsMap.tsx` reçoit un mode `fullscreen`, des marqueurs ronds cliquables et un encart retournable. `AppShell` : « Rencontres » → « Réseau ».
- `ai.functions.ts` : le prompt de l'entremetteuse gagne une capacité « proposer la création d'une carte » avec une sortie structurée (raison, potentiel, mises en relation possibles, brouillon de carte).

## 7. Ordre de réalisation

1. Réseau (map plein écran, recherche à étiquettes, encart retournable) + correction du header.
2. Page carte : calendrier unique + menu au clic, fin du doublon MusicBox, tags cliquables, cœur universel.
3. Timeline sociale (vignettes, messages, documents, tâches).
4. Entremetteuse créatrice de cartes.
