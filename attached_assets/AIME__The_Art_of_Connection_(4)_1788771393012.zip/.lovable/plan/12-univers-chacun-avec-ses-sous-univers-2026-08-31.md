# 12 univers, chacun avec ses sous-univers

## La 12e manquante

Le site parle de moments et de personnes, jamais de **biens**. C'est le manque le plus universel : logement, lieu, matériel, tenues, véhicules, objets. D'où un univers **Patrimoine & Biens**, qui alimente tous les autres (un mariage a besoin d'un lieu, d'une robe, d'un van).

## Les 12 univers et leurs sous-univers

1. **Événement** — Mariage, Anniversaire, Baptême, Cérémonie, Naissance, Fête privée, EVJF / EVG
2. **Musique & Scène** — Concert, DJ, Festival, Groupe live, Karaoké, Studio d'enregistrement
3. **Culture & Art** — Exposition, Théâtre, Musée, Artisanat d'art, Cinéma, Littérature
4. **Entreprise & Pro** — Séminaire, Team building, Lancement produit, Coworking, Formation, Salon
5. **Lieux & Réception** — Salle, Château, Domaine, Rooftop, Jardin, Chapiteau
6. **Table & Saveurs** — Traiteur, Chef à domicile, Food truck, Pâtisserie, Bar & mixologie, Cave
7. **Image & Souvenirs** — Photographe, Vidéaste, Drone, Photobooth, Retouche, Album
8. **Beauté & Style** — Coiffure, Maquillage, Robe & costume, Location de tenues, Bijoux, Soins
9. **Patrimoine & Biens** — Immobilier vente, Immobilier location, Location de matériel, Véhicules, Mobilier & déco, Objets rares
10. **Voyage & Séjour** — Hébergement, Séjour de groupe, Guide local, Transport, Navette, Expérience
11. **Lien & Rencontre** — Rencontre, Amitié, Réseau pro, Mentorat, Communauté, Entraide
12. **Association & Solidarité** — Bénévolat, Collecte, Cause, Sport & loisirs, Cause animale, Quartier

## Interaction sur l'accueil

Chaque carte vidéo de « Univers vivants » devient une carte à deux faces :

```text
[ vidéo + titre + flèche ]   --clic-->   [ fond noir
                                           Événement
                                           Mariage · Anniversaire
                                           Baptême · Cérémonie
                                           Naissance · Fête privée
                                           Tout l'univers →  ✕ ]
```

- Clic sur la carte : la vidéo passe sous un voile noir et le menu des sous-univers apparaît (fondu + léger décalage).
- Clic sur un sous-univers : ouvre `/registre` filtré sur ce sous-univers.
- « Tout l'univers » : ouvre `/registre` filtré sur l'univers parent (tous ses sous-univers).
- Clic ailleurs / croix : la carte revient à la vidéo.

## Détails techniques

- Nouveau `src/lib/aime/universeTree.ts` : les 12 univers (slug, label, liste de sous-univers `{ slug, label }`) + mapping parent → slugs d'univers existants en base, pour ne casser aucune donnée de carte.
- `UniverseVideoGrid.tsx` : état ouvert/fermé par carte, overlay noir `absolute inset-0` avec la liste des sous-univers, vidéo mise en pause quand le menu est ouvert, accessible au clavier (bouton + `aria-expanded`).
- `registre.tsx` : `validateSearch` accepte `sub` en plus de `universe`. Filtrage : `universe` = parent → on garde les cartes appartenant à un de ses slugs enfants ; `sub` → filtre sur le slug d'univers en base quand il existe, sinon recherche par mot-clé sur catégorie/titre/savoir-faire. Le panneau « Filtres » liste les 12 parents, et les sous-univers du parent sélectionné.
- Vidéos : les 11 vidéos actuelles sont réaffectées aux nouveaux parents (Événement garde l'entremetteuse) ; une 12e vidéo est générée pour **Patrimoine & Biens**.
- Aucune migration de base de données, aucune logique métier modifiée.
