# Nettoyage du hero, étiquettes embarquables, et « Mes projets » unifié

## 1. Hero d'accueil

- Le **bouton cœur passe à gauche**, tout au début du champ, avant la zone de saisie (aujourd'hui il est coincé entre le texte et « Continuer », ce qui écrase la saisie).
- **Suppression du doublon d'étiquettes** : la rangée de vignettes de cartes qui apparaît automatiquement dès qu'on tape disparaît. Embarquer une carte se fait désormais uniquement depuis le menu du cœur (« Embarquer des cartes »).
- Les cartes déjà embarquées restent affichées en pastilles sous le champ, avec leur croix pour les retirer.

## 2. Créer ma carte — « Connexions possibles »

Dans la colonne d'aperçu, sous la carte, la liste de texte brut « Connexions possibles » est remplacée par les **mêmes petites étiquettes embarquables, en blanc** : vignette ronde + nom + métier · ville, sur fond clair, cliquables vers la page de la carte. Même vocabulaire visuel que dans le hero, mais posé au bon endroit.

## 3. Rencontres gardées et formulaire de projet

- Dans Composer, chaque rencontre gardée devient cliquable : dépliage (cartes de la composition, intention d'origine), bouton **« En faire un projet »** qui ouvre le formulaire pré-rempli, et suppression.
- Le formulaire de création de projet (aujourd'hui sur `/projets/nouveau`, sans lien depuis « Mes projets ») remonte **dans « Mes projets »**, en bloc dépliable en tête de page, au-dessus du calendrier et de la liste. `/projets/nouveau` redirige vers `/projets` avec le bloc ouvert.

## Détails techniques

- `IntentionHero.tsx` : `IntentionHeart` déplacé avant l'`<input>` (padding du conteneur ajusté `pl-2 pr-2`) ; suppression du bloc `suggestions` (état, `scoreCard`, `tokens`, et le conteneur `min-h-[92px]`) — la logique de recherche reste dans `IntentionHeart`.
- Nouveau composant partagé `src/components/aime/CardChip.tsx` (vignette + nom + sous-titre, variantes `light` / `dark`), utilisé par les pastilles du hero et par « Connexions possibles ».
- `src/routes/ma-carte.tsx` (~l. 1060-1082) : la `<ul>` de connexions rend des `CardChip` blancs enveloppés dans un `Link to="/carte/$id"`.
- Extraction du formulaire de `src/routes/projets.nouveau.tsx` vers `src/components/aime/ProjectForm.tsx` (props `initialTitle`, `initialStyle`, `initialCards`, `onCreated`) ; `projets.index.tsx` l'affiche dans un bloc dépliable ouvert si `?nouveau=1` ; `projets.nouveau.tsx` devient une redirection.
- `src/routes/rencontres.tsx` : section « Vos rencontres gardées » en cartes interactives (dépliage, `AimeCard`, lien vers `/projets?nouveau=1&from=<id>`, suppression via `encounters`).
- Aucun changement de base de données.
