# Le panneau latéral devient le centre de tout : Discussions + Documents vivants

Oui, l'idée est claire : l'arbre de dossiers n'est pas une simple liste de fichiers, c'est une timeline verticale repliable — on y voit ce qui bouge, ce qui manque, et on agit sur place (ouvrir, corriger, envoyer à la bonne personne, rejoindre le projet). Et les pages publiques cessent d'éjecter le visiteur vers le Réseau.

## 1. Pages publiques : on reste sur la page

Aujourd'hui, dans « Ce que je fais » un mot-clé et dans « Mes mondes » un monde renvoient vers la page Réseau : le visiteur quitte la page.

À la place, un clic ouvre **sous le bouton, sur place** :
- un mot-clé : ce que la personne fait avec ce savoir-faire (ses prestations et tarifs correspondants, ses moments de ligne de temps liés), plus quelques personnes proches du même savoir-faire, en petites vignettes cliquables ;
- un monde : ce que la personne y fait (ses projets de ce monde) et un aperçu du monde lui-même.

Un lien discret « Voir tout dans le Réseau » reste disponible pour qui veut vraiment partir. Le bouton actif se marque, un second clic referme.

## 2. Un bouton « Doc » à côté du bouton messagerie

Dans l'en-tête, à côté de la bulle de messages, un bouton document ouvre **le même panneau**, directement sur l'onglet Documents. Une pastille de couleur y apparaît quand quelque chose demande attention.

## 3. L'arbre de dossiers devient une timeline verticale agissante

```text
▾ 📁 Mariage Julie & Marc      ● 2
     [ Ouvrir le projet ]
   ▾ 📁 Conversation — Traiteur  ●
       📄 Devis-traiteur.pdf   ● montant manquant
       📄 Contrat.pdf
   📄 Photo-lieu.jpg
▸ 📁 Non classés                ● 1
```

- **Clic sur un document = il s'ouvre sur place**, dans le panneau : aperçu (image ou PDF) et, juste en dessous, la fiche d'édition complète déjà présente dans l'espace Documents (type, sens, tiers, dates, montants, dossier, libellé). Plus d'onglet navigateur qui s'ouvre — un bouton « Ouvrir en grand » reste là pour ceux qui le veulent.
- **Points de couleur qui pulsent** : un dossier ou un fichier signale ce qui demande attention — orange « montant manquant / date manquante / type à préciser », bleu « nouveau depuis votre dernière visite ». Le point remonte sur le dossier parent avec le compte. Au survol, la phrase guidée : « Il manque le montant de ce devis ». Une fois vu ou corrigé, le point s'éteint.
- **Dossier de projet** : quand un dossier correspond à un de vos mondes, une ligne d'action « Ouvrir le projet » mène à sa page, et un rappel court dit où en est le projet.
- **Dossier de conversation** : « Ouvrir la discussion » bascule sur l'onglet Discussions, au bon fil.
- **Envoyer ce document** : depuis n'importe quel fichier, on choisit une conversation (ou une personne) et le document part dans le fil **et** reste rangé au même endroit. C'est le miroir : ce qui est dans l'arbre part dans la discussion, ce qui arrive dans la discussion se range dans l'arbre.
- On garde ce qui existe : créer, renommer, supprimer un dossier, glisser-déposer un document, déposer un nouveau fichier.

## 4. Vers la disparition de « Mon espace »

Ce panneau reprend petit à petit le rôle de la page Mon espace. Cette étape y transfère toute la partie Documents. La page Mon espace n'est pas supprimée maintenant : elle le sera quand les dernières sections (activité, page publique, compte) auront trouvé leur place.

## Détails techniques

- `CardIdentity.tsx` : les `Link to="/reseau"` deviennent des sections dépliantes locales (état `openTag` / `openWorld`), alimentées par `serviceRatesQuery`, `cardEventsQuery`, `cardTimeline` et une requête cartes filtrée par savoir-faire/monde (`worldsForTrade`). Lien secondaire vers `/reseau` conservé.
- `AppShell.tsx` : second bouton d'en-tête appelant `openDocuments()` (déjà exporté par `messagesSheet.ts`), avec pastille dérivée du décompte d'alertes.
- `FolderTree.tsx` : nouveau prop `onOpenDoc` ; `DocumentRow` s'ouvre en visionneuse dans `DocumentsTab` (aperçu via `documentUrl` signé + formulaire existant), au lieu de `window.open`.
- Alertes : dérivées côté client de `bureau_documents.uncertain_fields`, `amount_ttc`/`issued_on`/`doc_type` nuls, et de `created_at` comparé à un horodatage « dernière visite » en `localStorage` (`aime.docs.seen`). Aucune migration, aucune table nouvelle.
- Actions dossier : `bureau_folders.event_id` → `Link to="/projets/$id"` ; `bureau_folders.thread_id` → `openMessages(threadId)`.
- Envoi : réutilise `ensureThreadFolder`, `ingestFile`, `linkDocumentToMessage` (`src/lib/bureau/threadFolders.ts`) et le sélecteur de destinataire de `NewThreadDialog`.
- Inchangés : les routes `/bureau` et les fonctions `SECURITY DEFINER`.
