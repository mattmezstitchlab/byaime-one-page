# Calendrier de la page carte : la console carrée qui remplace le panneau latéral

Aujourd'hui, cliquer une date ouvre une grande feuille sur la droite qui recouvre la page. On la supprime : le calendrier lui-même devient l'objet vivant, dans un bloc carré unique.

## Le principe

Le bloc calendrier garde exactement sa taille et son format carré. Au clic sur une date, il **se retourne sur place** (rotation 3D douce, comme le recto/verso de la carte AIME) et révèle au dos la console du jour, au millimètre au même endroit. Une flèche blanche en haut à gauche ramène au calendrier. Rien ne recouvre la page, rien ne se déplace.

## Le dos : la console du jour

- En tête : la date en toutes lettres, et la pastille de disponibilité du jour.
- Les actions deviennent **quatre tuiles carrées** dans une grille 2×2, chacune avec son icône et son mot :
  - Radio — programmer un moment (morceau, message, récit, dédicace)
  - Repère — poser un jalon de timeline (propriétaire)
  - Réserver — déclarer l'intention sur cette carte (visiteur)
  - Dispo — disponible / option / complet (propriétaire)
- Cliquer une tuile ne change pas d'écran : la tuile **s'agrandit dans le carré** et affiche son mini-formulaire (programmation radio, titre du repère, message de réservation), avec retour aux tuiles.

## Les innovations sur la grille elle-même

1. **Pinceau de disponibilité** : le propriétaire choisit un état puis glisse le doigt ou la souris sur plusieurs jours d'affilée pour les peindre d'un coup. Fin des clics un par un.
2. **Aperçu au survol** : passer sur un jour rempli affiche en bas du bloc, sans clic, ce qui s'y trouve (heure, titre, type).
3. **Jour vivant** : le jour à l'antenne garde son halo pulsé, et le jour du jour est cerclé finement.
4. **Ruban du mois** : sous la grille, une ligne fine de points résume le mois d'un regard — vert/ambre/rose pour la disponibilité, points colorés pour les programmations.

## Détails techniques

- Nouveau composant `src/components/aime/DayConsole.tsx` : le dos carré (en-tête, grille 2×2 de tuiles, modes `radio` / `repere` / `reserver` / `dispo`), reprenant les mutations existantes de `DaySheet` (`card_availability` upsert, `card_timeline_entries` insert, `onIntent`) et la `MusicBox` en mode `bare hideCalendar`.
- Nouveau composant `src/components/aime/CalendarFlip.tsx` : conteneur `aspect-square` avec `perspective` + `rotate-y-180`, recto `MonthCalendar`, verso `DayConsole`.
- `src/components/aime/MonthCalendar.tsx` : ajout d'un `onPaint` optionnel (pointerdown/pointerenter) pour le pinceau, d'un `onHoverDay` pour l'aperçu, et du cerclage du jour courant.
- `src/routes/carte.$id.tsx` : remplace `<MonthCalendar>` + `<DaySheet>` par `<CalendarFlip>` dans la colonne latérale.
- `src/components/aime/DaySheet.tsx` supprimé s'il n'est plus utilisé ailleurs (vérification par recherche avant suppression).
- Aucune modification de schéma ni de RLS : mêmes tables, mêmes requêtes.
- Correctif au passage : l'erreur d'hydratation du squelette de chargement sur `/carte/$id`.
