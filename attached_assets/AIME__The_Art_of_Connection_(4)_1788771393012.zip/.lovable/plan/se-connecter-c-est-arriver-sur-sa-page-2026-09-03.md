# Se connecter, c'est arriver sur sa page

Oui, j'ai bien compris : aujourd'hui la connexion mène à un écran intermédiaire (« Mon espace ») avec un héros qui affiche l'adresse e-mail et des vestiges d'anciennes cartes et intentions. Puis, pour se décrire, il faut encore passer par un formulaire séparé. Cela fait deux fois le même travail. Le but : après Google ou e-mail, on arrive **sur sa page**, et c'est là, sous ses yeux, qu'on la remplit.

## Ce qui existe aujourd'hui (vérifié)

- `/auth` renvoie vers `/profil` après connexion et après inscription.
- `/profil` affiche un héros avec le nom ou, à défaut, l'adresse e-mail, puis la vignette de la page, les intentions passées et les rencontres gardées.
- `/ma-page` est encore un très gros formulaire de création séparé (plus de 2 000 lignes), en doublon avec la page elle-même.
- `/carte/$id` sait déjà qui est le propriétaire et affiche des panneaux d'édition en place (timeline, devis, radio, mémoire, mariage).

## Ce que je propose

### 1. La connexion mène directement à sa page

Après connexion Google ou e-mail, la page personnelle est ouverte immédiatement. Si elle n'existe pas encore, elle est créée en silence (brouillon, non publiée) et on arrive dessus. Plus aucun écran intermédiaire.

### 2. On remplit sa page sur sa page

Pour le propriétaire, la page affiche en haut un bandeau de mise en route, discret et repliable, avec les mêmes quatre temps qu'aujourd'hui — mais **en place**, chaque champ modifiant la page en direct :

1. Qui / quoi — nom, une phrase, photo
2. Ce que vous faites — activité et sous-univers (détermine les onglets et boutons de la vignette)
3. Où — ville, rayon, premières disponibilités
4. Un premier repère sur la ligne de temps

Chaque étape est passable ; le bandeau disparaît quand la page est suffisamment complète et reste rappelable par un bouton « Compléter ma page ». Le champ de l'agent sous le héros reste disponible pour tout le reste.

### 3. Fin du doublon

`/ma-page` cesse d'être un formulaire concurrent : l'adresse est conservée mais redirige vers sa page (comme `/ma-carte` déjà aujourd'hui). `/profil` fait de même. Ce qui n'appartient pas à la page — déconnexion et réglages de compte — rejoint Paramètres, déjà accessible depuis le menu AIME.

### 4. Les traces anciennes

Les intentions et cartes d'avant ne disparaissent pas : elles restent visibles depuis « Mes Aimes » et la ligne de temps de la page, mais ne s'affichent plus comme un tableau de bord séparé.

## Détails techniques

`auth.tsx` remplace ses deux `navigate({ to: "/profil" })` par l'ouverture via `useMyPage()` (création silencieuse puis `/carte/$id`). `profil.tsx` et `ma-page.tsx` deviennent des routes de redirection ; le contenu utile du formulaire (identité, activité, ville/rayon, disponibilités) est extrait en un composant `PageSetup` monté dans `carte.$id.tsx` sous condition `isOwner`, réutilisant `MultiSelectMenu`, `CityInput`, `universeTree` et les requêtes de disponibilité déjà en place. La déconnexion est ajoutée à `/parametres` avant la suppression de `profil.tsx`. Aucune table, migration ni règle d'accès n'est touchée.
