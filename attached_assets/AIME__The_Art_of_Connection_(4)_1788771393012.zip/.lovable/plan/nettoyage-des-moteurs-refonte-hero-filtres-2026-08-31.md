# Nettoyage des moteurs + refonte hero & filtres

## Audit : combien de « moteurs » l'entremetteuse a-t-elle vraiment ?

Un seul. La fonction serveur `composeEncounters` est le seul moteur IA du site. Elle est appelée depuis deux endroits, avec exactement les mêmes paramètres (texte libre, univers, ville) :

- `/rencontres` — champ libre + sélecteur univers + ville
- `/mon-evenement` — formulaire structuré (titre, date, ville, invités, budget, style) qui compose une phrase et appelle la même fonction

Et deux autres champs de saisie ressemblent à des moteurs sans en être :

- Accueil (`IntentionHero`) — pas d'IA : filtrage local du catalogue, puis redirection vers `/rencontres` qui lance le vrai moteur
- `/rencontres` → `IntentionFlux` (« Je cherche / Je propose ») — pas d'IA du tout : c'est un mur de petites annonces enregistrées en base, avec ses propres boutons d'univers, d'où l'impression de doublon total sur la page

Conclusion : trois zones de saisie sur une même page pour un seul moteur. À nettoyer.

## Ce que je propose

### 1. Rencontres — une seule saisie
- On garde le bloc de composition (le vrai moteur) en haut.
- Le flux « Je cherche / Je propose » perd son propre formulaire et ses boutons d'univers : il devient une simple liste de ce que les autres cherchent/offrent, en bas de page, avec un seul bouton « Poser une intention » qui ouvre un petit panneau. Plus de doublon d'univers ni de ville.
- Hero en plein écran immersif : l'image déborde à gauche, à droite et remonte sous le header, header rendu transparent puis blanc au scroll.

### 2. Mon événement / Événements — hero immersif
- Même traitement plein écran pour le visuel de `/evenements` (chef d'orchestre) et ajout d'un hero cohérent sur `/mon-evenement`.
- Le formulaire structuré de `/mon-evenement` reste : c'est le même moteur mais un usage différent (créer un événement partagé, pas explorer). Je l'assume et le nomme clairement pour lever la confusion.

### 3. Registre — filtres dans un panneau
- Un seul bouton « Filtres » avec pastille du nombre de filtres actifs.
- Ouvre un panneau latéral (Sheet) contenant univers, villes et familles.
- Reste visible en haut : la recherche texte + les filtres actifs sous forme de puces supprimables.

### 4. Accueil — hero épuré et embarquement des cartes
- Suppression du voile blanc sur la vidéo (on garde juste un léger dégradé bas pour la lisibilité) et suppression du mot « L'entremetteuse ».
- Champ de saisie nettement plus petit (une ligne, largeur réduite, centré) + bouton « Continuer ».
- Les petites cartes qui apparaissent pendant la frappe deviennent **embarquables** : un clic les ajoute sous le champ en pastilles (avec photo, nom, croix pour retirer). Elles ne renvoient plus vers la fiche.
- « Continuer » envoie vers `/rencontres` avec le texte **et** les cartes embarquées ; le moteur les traite comme cartes imposées dans la composition, et la page les affiche en haut en « Vos cartes embarquées ».

Mon avis : oui, l'embarquement est la bonne idée — c'est ce qui différencie AIME d'un moteur de recherche. On compose un panier d'envies avant de demander à l'entremetteuse de les faire tenir ensemble.

## Détails techniques

- `composeEncounters` : ajout d'un paramètre optionnel `pinnedCardIds`, injecté dans le prompt comme cartes à inclure prioritairement.
- `/rencontres` : `validateSearch` accepte `cards` (liste d'ids séparés par des virgules) en plus de `intention`.
- `IntentionFlux` : formulaire replié dans un panneau, suppression des chips univers dupliquées.
- `/registre` : filtres déplacés dans `@/components/ui/sheet`, état inchangé (search params `universe`, `city` + state `group`).
- Heroes : conteneur pleine largeur `w-screen` hors du wrapper `max-w-6xl`, header `AppShell` avec fond transparent sur les routes à hero et bascule en blanc au scroll.
