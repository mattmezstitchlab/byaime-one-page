# Les Éphémères sur la carte + menu AIME

## 1. Découvrir disparaît, les éphémères vivent sur la carte

- `/decouvrir` est supprimé de la navigation et redirige (301) vers `/reseau`.
- Sur la carte du Réseau, chaque éphémère actif (moins de 6 h) apparaît comme une **petite vignette rectangulaire** posée près de sa ville, reliée par un **trait pointillé** à la vignette ronde de la carte/personne qui l'a publié. Si l'auteur n'a pas de carte, la vignette flotte seule sur sa ville.
- La vignette montre l'aperçu (image, ou 1re frame de la vidéo), un point rouge pulsé « en direct » et le temps restant.
- Un compteur discret en haut de la carte : « X éphémères en ce moment ».

## 2. Lecteur plein écran type TikTok

- Clic sur une vignette → ouverture **plein écran** (overlay au-dessus de la carte et du header).
- Défilement vertical (glisser haut/bas + molette + flèches clavier) sur **tous les éphémères qui nous sont reliés** : d'abord celui cliqué, puis les autres du réseau proche (même ville, cartes aimées, cartes de nos projets), puis le reste.
- On garde les règles existantes : 10 s max, avance auto, marqué « vu » une seule fois, disparition après 6 h.
- Bouton fermer, barre de progression, légende + ville + temps restant, bouton « Voir la carte », et le bouton Cœur (intentions) directement dans le lecteur.
- Bouton « Publier un éphémère » : le composer actuel, déplacé dans une feuille depuis le menu Cœur de la carte.

## 3. Le Cœur du header devient le Tableau de bord « AI + ME »

Le bouton Cœur du header n'ouvre plus seulement les Aimes reçues : il ouvre **le tableau de bord**, la page personnelle qui regroupe tout.

En haut, un titre lettré **AI · ME** dont les deux moitiés sont cliquables :

- **AI** → panneau latéral gauche : l'entremetteuse. Crédits restants et consommation, formule/recharge, sa **mémoire** (ce qu'elle a retenu de vous, modifiable/effaçable) et l'**historique des conversations** avec accès direct au fil.
- **ME** → panneau latéral droit : vous. Compte et identité, préférences, notifications, confidentialité, et **paiements** (IBAN / Revolut pour être payé, moyens de paiement pour payer), factures et reçus.

Le corps du tableau de bord :

- **À faire** — tâches classées par priorité générées par l'entremetteuse : Aimes sans réponse, devis à valider, paiements en retard, dates à confirmer, carte incomplète.
- **Statistiques** — vues de vos cartes, Aimes reçues/envoyées, taux de réponse, revenus du mois, éphémères vus.
- **Mes cartes** (avec « Créer une carte »), **Mes projets**, **Mes documents** (devis, factures, contrats générés), **Messages**, **Mes intentions**, **Mes compositions**.

En bas de l'écran, un **bouton « + » rouge flottant** (même langage que le Cœur du Réseau) avec le menu propre au tableau de bord : Créer une carte · Nouveau projet · Nouveau devis · Publier une intention · Publier un éphémère · Demander un document à l'entremetteuse.

`/aimes-recues` devient un onglet de ce tableau de bord (l'ancienne URL redirige).

## 3 bis. La Radio : picto qui pulse + animatrice d'accueil

- Le picto Radio du header **pulse en continu** (halo doux, pas d'aggressivité) tant que la radio n'est pas lancée, pour inviter au clic.
- Au premier clic, la radio ouvre par une **présentation vocale du site par l'animatrice AIME** (voix générée par l'entremetteuse) : quelques phrases qui expliquent AIME, puis enchaîne sur la programmation.
- Barre radio avec l'onde animée, le nom de ce qui passe, pause/suivant.

## 3 ter. Le hero d'accueil : « Créer ma carte » + recherche par l'agent IA

- Le bouton **« Créer ma carte »** remonte **dans le hero**, juste sous le champ de saisie : c'est la première chose qu'on voit en arrivant (il disparaît de la section en dessous).
- Dès qu'on écrit dans le champ, l'entremetteuse **répond en une phrase vivante** sous le champ, et si vous n'avez pas encore de carte elle vous le dit à sa manière : « Pour que je vous présente à quelqu'un, il me faut d'abord votre carte. » avec le bouton « Créer ma carte » mis en avant.
- Si vous avez déjà une carte, elle enchaîne directement sur ce qu'elle a trouvé.
- **Oui, la recherche passe par l'agent IA** : la frappe déclenche d'abord le filtrage local instantané (les petites cartes qui apparaissent, aucun délai), puis, après une courte pause de frappe, l'agent affine — il comprend l'intention, reclasse les cartes, ajoute celles qu'un simple mot-clé aurait ratées et écrit sa phrase. Les cartes se réorganisent en douceur quand sa réponse arrive.
- Les cartes restent embarquables ; « Continuer » envoie le tout vers Composer.


## 4. Ce qu'il reste pour terminer l'application

Par ordre d'urgence :

1. **Aimes envoyées + états** : on voit les Aimes reçues mais pas les nôtres, ni leur suivi (en attente / acceptée / refusée).
2. **Notifications** : rien n'avertit d'une nouvelle intention, d'un message ou d'un paiement. Un centre de notifications + badges dans le menu AIME.
3. **Messagerie entremetteuse** : la page existe mais elle doit devenir la vraie conversation qui génère devis, contrats et documents et les envoie.
4. **Onboarding** : à la première connexion, l'entremetteuse propose de créer sa carte plutôt que de laisser l'utilisateur devant un réseau vide.
5. **Paiements réels** : aujourd'hui les paiements sont déclaratifs. Il faudra brancher un vrai encaissement.
6. **Modération / signalement** sur les éphémères et les cartes publiques.
7. **Recherche globale** : une seule barre qui cherche cartes, univers, villes, projets, où qu'on soit.
8. **Mobile & performances** : lecteur plein écran, carte et menus testés au doigt ; images et vidéos allégées.
9. **SEO & partage** : titres/aperçus propres sur chaque page carte et projet.

## Détails techniques

- Nouvelle couche Leaflet dans `CardsMap.tsx` : marqueurs `divIcon` rectangulaires pour les éphémères + `L.polyline` en `dashArray` reliant l'éphémère à la carte de son auteur ; props `stories`, `onOpenStory`.
- `src/lib/aime/stories.ts` : requête enrichie renvoyant `owner card_id`, ville, et tri de « proximité » (ville, cartes aimées, projets) pour l'ordre de lecture.
- Nouveau `src/components/aime/StoryViewer.tsx` (overlay `fixed z-[60]`, Motion drag vertical) réutilisant la logique actuelle de `decouvrir.tsx` (markSeen, auto-advance).
- `src/routes/decouvrir.tsx` devient une redirection permanente vers `/reseau`; retrait de l'entrée dans `NAV` de `AppShell.tsx`.
- Nouvelle route `/tableau-de-bord` (onglets : À faire, Cartes, Projets, Aimes, Documents) ; `/aimes-recues` redirige vers son onglet. Le Cœur du header y renvoie, badge conservé.
- Panneaux AI et ME : `Sheet` shadcn (side left / right). Crédits et mémoire IA : nouvelles tables `ai_usage` et `ai_memory` (RLS par `auth.uid()`, GRANT authenticated + service_role) ; coordonnées de paiement dans une table `payout_accounts` (privée, lecture/écriture propriétaire uniquement). Aucun encaissement réel à ce stade.
- Statistiques calculées côté client à partir des requêtes existantes (`aimes`, `events`, `event_payments`, `story_views`) ; pas de nouvelle table.
- Radio : halo `animate-ping` sur le picto tant que `on === false` ; jingle d'accueil via la fonction serveur radio existante (texte de présentation → synthèse vocale, mis en cache dans `radio_announcements`), joué en premier élément de la file.
- Hero : nouvelle fonction serveur `assistIntention` (Lovable AI, modèle rapide) appelée en debounce ~600 ms depuis `IntentionHero`, renvoyant `{ reply, cardIds[] }` ; état de secours = tri local actuel si l'IA échoue ou n'est pas encore revenue. Présence d'une carte détectée via `myCardQuery`.


