# Audit AIME — carte, nettoyage, et l'Accueil comme vitrine

## 1. Carte du Réseau — cause trouvée (et différente de ce qu'on pensait)

Test réel sur `https://byaime.fr/reseau` : la carte crée bien sa zone de dessin, les données publiques arrivent (60 fiches), le fond de carte répond. Une seule requête échoue :

```text
404  https://byaime.fr/assets/maplibre-gl-worker.mjs
```

Ce n'est **pas** un problème de domaine croisé : le fichier est demandé sur la bonne adresse, il n'existe tout simplement pas dans le site publié. Sans lui, la carte ne peut rien dessiner et reste ivoire.

Origine : dans la configuration de construction, la bibliothèque de carte est explicitement mise de côté (`optimizeDeps.exclude: ["maplibre-gl"]`, `vite.config.ts:25`). Ce réglage rend le fichier de travail invisible pour la construction, qui ne le publie donc pas. Le correctif ajouté précédemment dans `CardsMap.tsx:229-242` corrigeait une adresse — il ne pouvait pas créer un fichier manquant, d'où la persistance.

Ce n'est ni un problème de connexion, ni de permissions : la page n'exige aucun compte et les fiches publiées sont lisibles par tous.

**Correction retenue** (la plus simple, sans architecture parallèle) : déclarer le fichier de travail comme un vrai module de l'application (import dédié fourni par la bibliothèque) et l'indiquer à la carte avant sa création, puis retirer la mise à l'écart devenue inutile. Le bloc de rattrapage d'adresse est conservé mais journalisé au lieu d'être avalé en silence. Vérification obligatoire : ouverture de la page sur les trois adresses avec contrôle qu'aucune requête n'échoue.

Fichiers : `vite.config.ts`, `src/components/aime/CardsMap.tsx`.

## 2. Page Projets — fortement simplifiée

Elle contient aujourd'hui : une vidéo d'en-tête, un bouton de création, un calendrier mensuel, et pour chaque projet une carte avec quatre boutons (Participants, Paiements, Facture, Programmation), une barre de paiements et la liste des invités avec leurs réponses.

Tout cela existe déjà à l'intérieur du projet lui-même (la ligne de temps et ses panneaux). La page devient donc une simple **liste d'entrée** : nom, date, lieu, avancement, et on entre. Suppression du calendrier, des quatre boutons de raccourci et du bloc de réponses d'invités. La création reste sur l'Accueil.

## 3. Page Messages — la ligne de temps devient vivante

Décision retenue avec vous : les échanges se lisent et se répondent **dans la ligne de temps**. Quand un message arrive, l'icône du moment concerné clignote sur la ligne.

- La ligne de temps reçoit un état « non lu » sur les moments porteurs d'un échange, avec une pastille qui pulse, et la réponse se fait dans la bulle (déjà en place).
- La page Messages est conservée mais réduite à son seul rôle : retrouver toutes les conversations. Sa vidéo d'en-tête est retirée (elle part vers l'Accueil, voir §5).
- Un seul système d'envoi : celui de la bulle et celui de la page passent par la même fonction.

## 4. Radio — écoute légère, narration au Play

La Radio n'est plus une destination : il n'existe déjà aucune page Radio, seulement une barre présente partout et un panneau dans les projets. Le texte d'« animatrice » (`airplay.functions.ts:32`) est supprimé.

Conformément à votre choix : **le Play prend la narration**, et il reste une **écoute musicale discrète** en fond pendant la navigation (la barre existante, allégée : lecture, pause, titre).

## 5. Play — la lecture du monde dans le temps

Le moteur existe déjà et va au-delà d'un lecteur : il compose une suite de moments (photo, vidéo, son, musique, texte, narration) et fait avancer la ligne de temps avec elle. Ce qui manque pour tenir la promesse « AIME raconte votre monde » :

- une voix : la phrase de narration est aujourd'hui écrite mais jamais dite — ajout d'une lecture vocale, désactivable ;
- l'enchaînement de sens : passer d'un moment à la personne concernée, puis à la décision, puis au moment suivant, au lieu d'une simple suite chronologique ;
- la musique en fond de la narration plutôt qu'à la place.

Ces trois points sont chiffrés en P2 : ils viennent après le nettoyage.

## 6. Bande de cartes d'univers — elle déménage sur l'Accueil

Elle n'est aujourd'hui montée que sur une page personne, où elle n'explique rien. Elle porte pourtant exactement le message manquant : AIME n'est pas une application de mariage, c'est un système qui sait représenter des univers différents. Elle rejoint l'Accueil, avec le retournement recto/verso : recto ce que l'on voit, verso ce qu'AIME comprend.

## 7. Vidéos

- Film d'un projet (mariage) : c'est la **démonstration** — elle reste dans le projet et sert d'illustration à la section temps de l'Accueil.
- Visage AIME (page Messages) : c'est l'**émotion / le manifeste** — retirée de Messages, elle devient l'en-tête de l'Accueil.
- Vidéo d'en-tête de la liste des projets : devenue décorative, supprimée avec la simplification du §2.

## 8. Nouvel Accueil — premier lot seulement

Conformément à votre choix, ce lot s'arrête à trois temps :

1. **Hero** — le film du visage, le mot AIME, une phrase simple, et le champ « Racontez votre intention ».
2. **L'intention** — le récit se transforme sous les yeux : la ligne de temps se dessine (mécanique déjà en place).
3. **Les univers** — la bande de cartes retournables, pour montrer que le même principe vaut pour un mariage, une association, un événement, une mission.

Les sections Temps, Play, Cœur et manifeste sont écrites au plan mais construites plus tard. L'Accueil reste une expérience, jamais un tableau de bord.

## 9. Pages héritées repérées

| Page | Fonction réelle | Ailleurs ? | Décision |
|---|---|---|---|
| `/projets` | liste + raccourcis | oui, dans le projet | SIMPLIFIER |
| `/messages` | toutes les conversations | partiellement (timeline) | RÉDUIRE |
| `/ma-page` | ouvre un panneau | oui, Mon Espace | SUPPRIMER (redirection) |
| `/projets/nouveau` | création | oui, Accueil | déjà redirigé, CONSERVER |
| `/registre` | ancien mode grille disparu | — | CORRIGER la cible vers `/reseau` |
| `/monde`, `/evenements`, `/evenement/*` | redirections | — | CONSERVER (liens existants) |
| Radio (barre + panneau) | ambiance sonore | — | ALLÉGER |

## 10. Doublons restants

Envoi de message (bulle / page Messages) · narration (Radio / Play) · vidéo d'en-tête sur trois pages · liste de projets (Mon Espace / page Projets, sous-ensemble accepté).

## 11. Architecture visée

Accueil (comprendre) · Réseau (découvrir) · Mon Espace (soi) · Personne et Monde (contextes) · Ligne de temps (l'interface) · Play (la narration) · Messages (l'annuaire des conversations) · Bureau (gelé).

## 12. Plan d'action

**P0** — 1. Réparer la carte (fichier de travail manquant) et vérifier sur les trois adresses. 2. Simplifier la page Projets. 3. Retirer le texte d'animatrice et alléger la barre radio.

**P1** — 4. Pastille clignotante des messages non lus sur la ligne de temps, réponse dans la bulle, page Messages réduite. 5. Nouvel Accueil : hero filmé, intention, bande d'univers retournable. 6. `/ma-page` en redirection, cible de `/registre` corrigée.

**P2** — 7. Play narratif : voix, enchaînement de sens, musique en fond. 8. Sections Accueil suivantes (temps, Play, Cœur, manifeste).

## Détails techniques

- `vite.config.ts` : retrait de `optimizeDeps.exclude: ["maplibre-gl"]` ; worker importé via le point d'entrée dédié du paquet et passé par `maplibregl.setWorkerUrl` / `workerClass` avant l'instanciation dans `CardsMap.tsx:226`.
- `projets.index.tsx` : suppression de `MonthCalendar`, des quatre `Link search={{ panneau }}`, du bloc participants/invites et du hero vidéo.
- Messages non lus : lecture de `messages.read_at`/`threads.last_message_at` agrégée par `thread_id` → drapeau `unread` sur les marqueurs `message` de `cardTimeline.ts` / `derive.ts` ; animation de pastille dans `HeroTimeline.tsx`, réponse déjà gérée par `TimelineBubbleExtra.tsx`.
- `airplay.functions.ts:32` : prompt d'animatrice supprimé ; `RadioBar.tsx` réduit à lecture/pause/titre.
- Accueil : `UniverseCarousel` déplacé de `carte.$id.tsx` vers `index.tsx`, ajout du retournement recto/verso à partir de `universeSheets.ts` ; hero `aime-face.mp4.asset.json`.
- Périmètre gelé : `/bureau*`, fonctions `SECURITY DEFINER`, pages légales. Typecheck + contrôle navigateur (1280 px et 390 px) après chaque lot.
