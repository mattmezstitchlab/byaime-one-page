# Registre : recherche dans le hero, 3 modes de vue, et jamais d'écran vide

## 1. La recherche remonte dans le hero

Le champ « Rechercher une carte, une ville, un savoir-faire… », le bouton Filtres et le sélecteur de mode passent sous le titre, à l'intérieur du visuel (comme le hero d'accueil). La zone sous le hero commence directement par les résultats.

## 2. Trois modes de vue, un seul jeu de filtres

Un segment de 3 icônes dans le hero, à droite du champ : **Mosaïque · Liste · Carte**. Même recherche, mêmes filtres, mêmes résultats — seule la représentation change. Le mode est mémorisé dans l'URL (`?view=mosaique|liste|map`), donc partageable.

- **Mosaïque** (actuel) : grille de cartes AIME, pour la découverte visuelle.
- **Liste** (nouveau) : lignes rectangulaires compactes — vignette ronde à gauche, nom + accroche + ville + famille, cœur d'intention à droite. Densité élevée : on voit ~4× plus de résultats d'un coup, idéal quand on compare ou qu'on cherche un nom précis.
- **Carte** (reprise de /reseau) : la carte MapLibre existante avec clustering et liste latérale synchronisée, alimentée par les cartes filtrées du registre.

Le mode Carte réutilise `CardsMap` tel quel : c'est le même composant que /reseau, pas une copie. /reseau reste en place comme expérience plein écran « vivante » (stories, flux, compositions) ; le registre en propose la version « recherche ». Si vous préférez, on peut plus tard rediriger /reseau vers `/registre?view=map` — à décider une fois les deux côte à côte.

## 3. Jamais d'écran vide

Plus jamais « 0 carte ». Le compteur devient une phrase claire (« 24 cartes · Entreprise & Pro · Lancement produit ») avec les filtres actifs en pastilles retirables. Et quand rien ne correspond, la grille reste pleine :

- **Cartes d'action**, au même format que les cartes du registre : « Créer ma carte ici » (univers + ville pré-remplis), « Demander un profil », « Inviter un prestataire », « Décrire mon besoin à Aime ».
- **Élargir la recherche** : boutons qui relâchent un filtre à la fois (« sans la ville », « tout l'univers », « toutes familles »), avec le nombre de cartes débloquées calculé en direct.
- **Proches de votre recherche** : de vraies cartes voisines (même univers sans le sous-univers, puis même ville, puis les plus récentes).

En mode Liste et en mode Carte, le même bloc s'affiche (sous la carte pour le mode Map).

## Détails techniques

- `src/routes/registre.tsx` : champ + Filtres + segment de vue déplacés dans `children` de `PageHero`, en verre sombre sur le visuel ; nouveau search param `view` validé par Zod avec `fallback`.
- Nouveau `src/components/aime/RegistryList.tsx` : rendu en lignes (vignette ronde `cardVisual`, cœur `AimeButton`).
- Nouveau `src/components/aime/RegistryEmpty.tsx` : actions, élargissements et cartes voisines, calculés depuis la liste déjà chargée (aucune requête en plus).
- Mode Carte : `CardsMap` monté avec `filtered`, hauteur fixe sous le hero, clic marqueur → ouverture de la ligne correspondante.
- Filtrage extrait en fonction pure, réutilisée pour les compteurs « sans ce filtre ».
- Aucune modification de base de données, aucune nouvelle route.
