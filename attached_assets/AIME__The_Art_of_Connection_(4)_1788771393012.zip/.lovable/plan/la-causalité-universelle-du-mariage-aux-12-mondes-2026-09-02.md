# La causalité universelle : du mariage aux 12 mondes

Le mariage est le meilleur banc d'essai : beaucoup d'acteurs, une date irréversible, un budget qui glisse, des secrets à préserver. Ce qui marche là marche partout. Mais on ne recopie pas le vocabulaire du mariage dans les autres univers — on garde le moteur, on change le jargon.

## Le moteur, en quatre notions seulement

1. **Point zéro** — le paramètre irréversible (une date, un lieu, un budget, une capacité).
2. **Lien causal** — « si X bouge, alors Y bouge », avec une force et un délai.
3. **Onde** — impacts directs, indirects, différés, calculés et *proposés*, jamais appliqués en silence.
4. **Zone secrète** — un créneau réservé dont la durée est visible de tous et le contenu de personne, sauf de ses porteurs.

Ces quatre notions s'écrivent une seule fois. Chaque univers ne fournit que son dictionnaire : ses rôles, ses variables sensibles, ses points de rupture.

## Ce que le site a déjà

- `timeline_effects` qualifie déjà des effets avec Déclaré / Documenté / Estimé — c'est la matière première des ondes.
- Le Bureau (`bureau_folders`, score, rapprochement devis → facture → paiement) est déjà le miroir des dossiers.
- Les enseignes ♠ Passé ♦ Présent ♣ Futur donnent déjà le mode « prévenir au lieu de guérir » : le Futur, c'est la lecture des ondes avant qu'elles ne frappent.
- Ce qui manque, vérifié dans le code : aucun graphe de dépendances, `role_label` en texte libre sur les participants, aucun mécanisme de secret, aucun modèle de dossiers par métier.

## La déclinaison par univers

Pour chaque monde : le point zéro, la variable qui fait tout basculer, le point de rupture typique, et le secret à protéger.

| Univers | Point zéro | Variable critique | Rupture typique | Zone secrète |
|---|---|---|---|---|
| Événement | Date + capacité | Nombre de convives | +10 convives → traiteur, salle, plan de table, budget | Surprises, discours |
| Musique & Scène | Heure de balance | Durée du set | Balance décalée → ouverture des portes, couvre-feu | Invité surprise, morceau caché |
| Culture & Art | Date de vernissage | Nombre d'œuvres et surface | Œuvre en retard → accrochage, assurance, catalogue | Pièce dévoilée le soir même |
| Entreprise & Pro | Date + nombre d'inscrits | Inscrits confirmés | Salle sous-dimensionnée → traiteur, badges, régie | Annonce interne embargo |
| Lieux & Réception | Capacité homologuée | Créneau de montage | Montage raccourci → décor, sécurité, horaires | Autre client le même week-end |
| Table & Saveurs | Nombre de couverts | Régimes et allergènes | Régimes tardifs → commandes, coût, service | Menu du gâteau surprise |
| Image & Souvenirs | Heure de la lumière | Ordre des séquences | Cérémonie en retard → photos de groupe perdues | Cadeau filmé à l'avance |
| Beauté & Style | Heure de départ | Nombre de mises en beauté | +2 personnes → réveil avancé de 90 min | — |
| Patrimoine & Biens | Date de disponibilité | État des lieux | Livraison décalée → montage, caution, assurance | Prix négocié |
| Voyage & Séjour | Date de réservation | Nombre de chambres | Groupe réduit → tarif perdu, navettes vides | Voyage offert |
| Lien & Rencontre | Première proposition | Disponibilité réelle | Créneau annulé → toute la chaîne d'intentions | Message non encore envoyé |
| Association & Solidarité | Date de collecte | Bénévoles confirmés | Bénévoles manquants → périmètre, sécurité, autorisation | Montant d'un don anonyme |

Chaque ligne devient une entrée de dictionnaire, pas un développement séparé.

## Plan en 3 passes

### Passe 1 — Le socle causal et le secret
- Rôles structurés sur les participants (rôle, sous-type, visibilité), le `role_label` existant est conservé et migré.
- Créneaux à contenu masqué : durée visible par tous, contenu réservé à ses porteurs, garanti côté base et non côté écran.
- Panneau « Ce que vous voyez · Ce qui vous impacte · Ce qui vous est caché », alimenté par le rôle réel.

### Passe 2 — Le graphe et l'onde
- Dictionnaire causal par univers (le tableau ci-dessus), déclaratif, éditable sans toucher au moteur.
- Au moindre changement de point zéro : impacts directs, indirects et différés proposés, avec leur source, à accepter ou refuser.
- Rendu en onde sur la timeline et dans le Bureau : ce qui est touché s'illumine en cascade, les chiffres se recalculent en direct.
- Les impacts acceptés deviennent des `timeline_effects` — aucun second système.

### Passe 3 — Le Bureau généré et l'anticipation
- Modèles de dossiers par rôle et par métier, créés quand quelqu'un rejoint un projet ; règle d'or : une carte de la mosaïque = un dossier racine.
- Repères de timeline pré-remplis par univers (J-12 mois pour un mariage, J-3 semaines pour une expo, J-2 jours pour une collecte).
- Météo sur la date et le lieu, plan B proposé pour tout ce qui est en extérieur.
- Mode ♣ Futur : la liste des ondes qui vont frapper si rien ne bouge.

## Réserves

- « Brevetable » et « aucun concurrent » sont les conclusions des rapports, pas des faits du site : à ne pas afficher comme acquis.
- Les chiffres du rapport (51 % de dépassement, 12–18 prestataires) restent sourcés s'ils apparaissent à l'écran.
- Le moteur propose, l'humain valide. Jamais l'inverse.

## Détails techniques

Nouvelles tables : `project_roles` (rôle, sous-type, visibilité), `causal_links` (univers, variable source, cible, règle, force, délai), `causal_impacts` (déclencheur, impacts calculés, statut proposé/accepté). Le secret est une colonne de confidentialité sur les entrées de timeline, avec des politiques distinctes pour l'enveloppe (durée) et le contenu. Le calcul vit dans une server function `causal.functions.ts`. La météo est appelée côté serveur et mise en cache par date et lieu. Le dictionnaire par univers est un fichier front (`src/lib/aime/causal.ts`) sur le modèle de `universeTree.ts`, sans migration.
