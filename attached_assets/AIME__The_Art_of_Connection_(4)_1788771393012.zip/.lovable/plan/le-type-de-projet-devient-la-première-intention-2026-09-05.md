# Le type de projet devient la première intention

## Ce que l'audit a trouvé

Le mariage n'est pas un « reste » d'affichage : c'est le seul modèle branché.

- La barre d'accueil demande Date → Ville → Budget → Personnes → Type de projet. Le type est donc demandé **en dernier**, et il ne sert qu'à écrire une phrase.
- Quel que soit le type choisi, la construction du projet passe toujours par le même constructeur « mariage » : rôles (traiteur, fleuriste, officiant…), déroulé de la journée (cérémonie, cocktail, ouverture de bal) et rétroplanning (faire-part, plan de table) sont écrits en dur, et l'univers du projet est forcé à « Mariage ».
- Des modèles d'étapes par univers existent déjà (mariage, événement/concert, entreprise, voyage, intermittence, projet générique) mais ne sont utilisés que sur la page d'une carte, jamais à la création d'un projet.
- Les 12 univers réels sont ceux de l'arbre AIME : Événement, Musique & Scène, Culture & Art, Entreprise & Pro, Lieux & Réception, Table & Saveurs, Image & Souvenirs, Beauté & Style, Patrimoine, Voyage & Séjour, Lien & Rencontre, Association & Solidarité — chacun avec ses sous-types (mariage, anniversaire, concert, festival, exposition, séminaire, etc.).
- L'animation de création n'est reliée à rien : elle défile toute seule et disparaît dès que l'enregistrement répond (souvent moins d'une seconde).
- Sur la page projet, le bouton Play et les boutons Avant / Pendant / Après ouvrent une fenêtre noire plein écran par-dessus toute l'interface.

## Ce que je vais construire

### 1. Le type d'abord
La barre d'accueil commence par « Que souhaitez-vous créer ? », avec les types réellement disponibles (univers puis sous-type : Mariage, Anniversaire, Concert, Festival, Exposition, Séminaire, Voyage, Projet artistique, Association…). Les quatre questions suivantes ne sont posées qu'ensuite.

### 2. Quatre questions qui changent selon le type
Chaque type a ses propres questions, formulations, exemples et suggestions. Par exemple : un mariage parle de date, lieu, invités, ambiance ; un concert parle de date, salle, public attendu, plateau artistique ; un festival de période, site, capacité, programmation ; un projet artistique d'intention, période, collaborateurs, résultat attendu. Les types sans modèle propre héritent d'un jeu de questions générique (période, lieu, personnes, intention).

### 3. Un modèle de projet par type, plus jamais le mariage par défaut
Le constructeur « mariage » devient un modèle parmi d'autres. Chaque type apporte : ses rôles à pourvoir, ses phases, son déroulé du jour, son rétroplanning, ses manques à signaler. Le projet garde son vrai univers et son vrai titre. Un type sans modèle dédié reçoit un modèle générique honnête (conception → préparation → jour de l'événement → bilan), jamais des étapes de mariage.

### 4. Une timeline qui respecte l'ordre des choses
Les étapes sont posées à partir de la date cible et du temps réellement disponible, avec leurs dépendances : on ne répète pas avant d'avoir un programme, on n'installe pas après l'ouverture, on prépare une invitation avant de l'envoyer. Si la date est proche, le rétroplanning se resserre au lieu de placer des étapes dans le passé.

### 5. La création devient une séquence visible (~10 s)
Le clic sur « Ouvrir mon projet » lance immédiatement le vrai travail (lecture de l'intention, construction des étapes, rétroplanning, enregistrement, préparation de l'espace). L'écran raconte ces étapes une par une, cochées au fur et à mesure, avec des mots propres au type choisi (« Organisation de la production » pour un concert, « Préparation du jour J » pour un mariage). Si tout est prêt avant la fin, la séquence se termine proprement au lieu de disparaître d'un coup, puis enchaîne en fondu sur la page du projet.

### 6. Le héros du projet remplace la fenêtre noire
Play et les boutons de temps n'ouvrent plus de fenêtre noire. Tout s'affiche dans le héros lui-même : le titre, le compte à rebours, l'étape suivante, les moments mis en avant. Play fait défiler la timeline dans le héros (progression, moments qui s'allument, narration et musique conservées) ; Passé / Présent / Futur transforment le contenu du héros au lieu de superposer une couche. La lecture plein écran reste disponible uniquement pour les photos et vidéos ouvertes volontairement.

## Détails techniques

- `HeroBar.tsx` : nouvel ordre, premier champ `type` alimenté par `UNIVERSE_TREE` (univers + sous-univers), champs suivants issus d'un descripteur par type.
- Nouveau module `src/lib/aime/world/blueprints/` : un « blueprint » par famille (mariage, concert/festival, spectacle-culture, entreprise, voyage, association, artistique, générique) exposant `questions`, `roles`, `flow`, `retro`, `loadingSteps`. `world/wedding.ts` devient le blueprint mariage.
- `parseStory.projectFromReading` et `journey.projectFromJourney` reçoivent le type et appellent `buildProject(blueprint, input)` au lieu de `buildWedding` ; `universe`/`kind` viennent du type choisi.
- Le rétroplanning fusionne la logique existante de `retroplanning.ts` (`RETRO_TEMPLATES`) avec les blueprints, avec ordonnancement par dépendances et compression si la date est proche.
- `AimeLoader` piloté par une machine d'étapes réelles (promesses de `persistValidatedProject` + préparation), durée plancher ~10 s, libellés fournis par le blueprint ; sortie en fondu avant `navigate`.
- `ProjectStage.tsx` : `PlayStage` plein écran n'est plus monté pour la lecture de timeline ; un mode « lecture dans le héros » consomme la même file (`buildPlayQueue`, narration, voix) et rend l'état dans la composition du héros. `TimeCapsule` alimente le contenu du héros (passé/présent/futur) au lieu d'un panneau superposé.
- Périmètre respecté : aucune modification de `/bureau`, aucune modification des fonctions `SECURITY DEFINER`, aucune migration de base nécessaire.

## Vérifications

Parcours complet testé sur mariage, concert, festival, séminaire et projet artistique : questions adaptées, étapes de timeline propres au type, aucune étape de mariage sur les autres types, séquence de création visible, et héros du projet sans fenêtre noire sur Play, Passé, Présent et Futur.
