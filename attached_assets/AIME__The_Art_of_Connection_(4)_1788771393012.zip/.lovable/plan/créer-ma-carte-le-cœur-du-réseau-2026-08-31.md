# Créer ma carte — le cœur du réseau

## Ce que je comprends

La page « Créer ma carte » a été pensée à l'époque « Mariage ». Aujourd'hui l'app repose sur 12 univers et leurs sous-univers, et c'est ici que se décide **tout le maillage** : ce qu'on saisit sur cette page détermine où la carte apparaît (registre, réseau/map, suggestions, compositions IA), avec qui elle sera reliée, et ce que l'entremetteuse peut en faire. Une carte mal qualifiée = une carte invisible et sans connexions.

État actuel constaté dans le code :

- Les boutons « Univers » listent la table à plat, sans la hiérarchie des 12 univers, et il n'existe **aucune sélection de sous-univers**.
- L'univers par défaut est encore `mariage`.
- Les **tags ne sont jamais renseignés** (jamais envoyés à l'enregistrement, forcés à vide dans l'aperçu) alors que les tags sont cliquables partout ailleurs (registre, réseau) — c'est le principal lien mort du réseau.
- La région est **figée à « Hauts-de-France »** en dur.
- La catégorie est un simple menu déroulant global, sans lien avec l'univers choisi : on peut créer un « photographe » dans « Patrimoine ».
- Un utilisateur ne gère **qu'une seule carte**, alors que le concept veut une carte par sujet/projet/lieu/bien.

## Ce que je propose de construire

### 1. Un parcours de qualification, pas un formulaire
Le formulaire devient un parcours en étapes courtes :
1. **Univers** (les 12, en grille avec pictos et vidéos) → 2. **Sous-univers** (multi-sélection, issue de l'arbre) → 3. **Nature de la carte** (personne, lieu, service, ressource, événement…) → 4. **Identité** (nom, accroche, photo/vidéo) → 5. **Savoir-faire & tags** → 6. **Ville & rayon** → 7. **Disponibilités**.
L'aperçu de la carte reste visible en permanence à droite.

### 2. Catégories filtrées par univers
La liste des catégories se restreint aux catégories cohérentes avec l'univers et le sous-univers choisis, avec un repli « autre » libre. Fin des combinaisons absurdes.

### 3. Tags — la matière première des connexions
- Suggestions de tags générées à partir de l'univers, du sous-univers et de la catégorie.
- Ajout libre, tags visibles dans l'aperçu, **réellement enregistrés** en base.
- Chaque tag reste cliquable ailleurs et ramène au registre filtré.

### 4. L'entremetteuse dans la création
Un bloc « Décrivez ce que vous voulez vivre / proposer » en haut de page : l'IA lit le texte et pré-remplit univers, sous-univers, nature, accroche, savoir-faire et tags, en expliquant en une phrase pourquoi cette carte a du potentiel et à qui elle pourra être reliée. L'utilisateur garde la main sur chaque champ.

### 5. Aperçu des connexions avant publication
Sous l'aperçu : « Ce que votre carte va rencontrer » — les cartes proches (même sous-univers, tags communs, même ville) et le nombre d'intentions ouvertes qui correspondent. C'est la preuve immédiate de l'utilité de la carte.

### 6. Plusieurs cartes par membre
Passage de « ma carte » à « mes cartes » : liste des cartes du membre, bouton « Nouvelle carte », sélecteur en haut de page. Les blocs existants (Aimes reçues, disponibilités, organisateur, timeline) suivent la carte sélectionnée.

### 7. Ville libre et région déduite
Saisie de ville avec suggestions ; la région est déduite de la ville au lieu d'être écrite en dur, pour que la map et les filtres géographiques restent justes hors Hauts-de-France.

## Détails techniques

- Source de vérité : `src/lib/aime/universeTree.ts` (12 parents, sous-univers avec `db` ou `keywords`).
- Stockage sans migration lourde : `universes` reçoit les slugs parents + slugs de sous-univers existants en base ; les sous-univers sans équivalent base sont écrits dans `tags` sous forme normalisée, ce qui les rend filtrables partout immédiatement.
- Ajout de `tags` au payload d'enregistrement et à l'objet d'aperçu de `src/routes/ma-carte.tsx`.
- Filtrage catégories/univers via une table de correspondance dans `src/lib/aime/universeTree.ts`.
- Pré-remplissage IA via une nouvelle fonction serveur dans `src/lib/aime/ai.functions.ts` (même moteur Gemini, sortie JSON typée).
- Sélection multi-cartes : nouvelle requête « cartes du membre » dans `src/lib/aime/queries.ts`, `myCardQuery` conservée comme repli.
- Aucune donnée existante perdue : les cartes actuelles restent valides, les champs manquants se remplissent à la prochaine édition.

## Ordre de livraison

1. Arbre univers + sous-univers + tags réellement enregistrés + catégories filtrées.
2. Parcours en étapes, ville/région, aperçu des connexions.
3. Pré-remplissage par l'entremetteuse et gestion multi-cartes.
