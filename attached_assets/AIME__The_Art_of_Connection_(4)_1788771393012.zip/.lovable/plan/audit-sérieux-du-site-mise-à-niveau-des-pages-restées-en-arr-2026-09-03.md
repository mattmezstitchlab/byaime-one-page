# Audit sérieux du site + mise à niveau des pages restées en arrière

Constats vérifiés dans le code actuel, puis ce que je propose de faire. Rien n'est appliqué avant votre accord.

## Ce que j'ai vérifié

- `PageHero` a maintenant `align` et `overlap` : seules Bureau, Rencontres et Tableau de bord les utilisent. Messages, Ma Carte, Projets gardent l'ancien réglage.
- `/monde` n'a **aucun** hero : c'est la seule grande page du site avec un simple titre centré. Elle est restée à l'état d'avant l'harmonisation.
- `/projets` a un hero sans champ AIME, sans sous-titre, et un H2 qui redit le titre juste en dessous.
- `/messages` a un hero vidéo mais aucun champ d'intention, alors que tout le site en a un.
- `/ma-carte` a déjà `AimeField` dans le hero (elle est à jour côté grammaire) mais 1577 lignes en un seul écran linéaire.
- `/identity` est une page isolée : pas d'`AppShell`, pas de lien avec le bisou (`kiss_prints` existe déjà), pas d'invitation, pas de crédits.
- `invites` (code, label, uses, created_by) et `credit_ledger` existent déjà : la fidélité par partage peut se brancher dessus sans nouvelle mécanique de paiement.
- Le Bureau : la fenêtre flotte sur un fond uni ; le visuel du hero s'arrête net au bord de la fenêtre.

## 1. Bureau — le fond d'écran (demande explicite)

- Le visuel du hero devient le fond **de toute la page**, fixé derrière la fenêtre, avec un léger flou et un voile pour garder la lisibilité.
- En haut à droite de la barre de fenêtre : un bouton « Fond d'écran » qui ouvre une planche de vignettes (les visuels déjà présents dans `src/assets` : institution, lumière, scène, patrimoine, ville, plus un ciel vidéo) façon réglage de bureau.
- Le choix est mémorisé par utilisateur en local, s'applique aussi aux sous-pages du Bureau (dossier, projet, export, membres) puisqu'elles partagent `BureauWindow`.
- Bonus cohérent avec le reste : la fenêtre gagne un fil d'Ariane et un compteur « ce qui bloque » directement dans sa barre de titre.

## 2. Monde — la page la plus en retard

- Ajout du hero standard (`align="raised"`) avec un champ AIME : « Où voulez-vous prendre votre place ? » → sélection du niveau et du lieu par la phrase.
- Les réglages niveau/lieu remontent dans le hero ; la grille reste plein écran en dessous.
- Ajout du repère de proximité déjà utilisé sur Saisons : compter les cases libres autour de vous, et un lien direct vers les places à pourvoir de la semaine.

## 3. Projets — cohérence et utilité

- Sous-titre dans le hero, champ AIME intégré (« Un concert à Lille le 12, il me manque un lieu ») créant directement un projet pré-rempli.
- Suppression du H2 qui répète le hero.
- Chaque projet affiche désormais ce que le reste du site sait déjà : places manquantes (SlotPlan), semaine de la saison, état du Bureau (devis/factures liés), et un lien « compléter à proximité ».

## 4. Messages — la page à repenser

- Champ AIME dans le hero : écrire une intention crée le bon fil (personne, groupe, équipe projet) au lieu de passer par le bouton « + ».
- Fils regroupés par projet / carte plutôt qu'une liste plate, avec pastilles de non-lus.
- Dans le fil : une barre d'actions contextuelles reliée au reste du site — proposer une date (Saisons), envoyer un devis (Bureau), ajouter à une composition, inviter sur un projet.
- Le copilote garde ses modes, mais ses mentions de crédits s'affichent comme ailleurs (CreditTag).

## 5. Ma Carte — découper le fleuve

- Le contenu reste identique, mais réparti en étapes claires (Identité, Univers, Savoir-faire, Disponibilités, Média, Publication) avec une barre de progression et un enregistrement par étape.
- Aperçu de la carte collant en haut à droite sur desktop, pour voir l'effet en direct.
- Rappel de ce qui manque avant publication, formulé comme le Bureau (« il manque une ville et une photo »).

## 6. Identity — le bisou qui invite (nouvelle mécanique)

- La page passe dans `AppShell` et devient la page du geste : on y génère son empreinte de bisou (déjà codée dans `kiss.ts`, stockée dans `kiss_prints`).
- Chaque bisou produit un lien d'invitation personnel (table `invites` existante, un code par personne) : « Envoyez votre bisou ».
- Fidélité : quand un invité crée son compte et publie sa carte, le parrain reçoit des crédits, écrits dans `credit_ledger` avec un type `parrainage` (aucun paiement, purement offert). Un palier tous les 3 filleuls donne un bonus.
- Un petit tableau « Mes bisous envoyés / acceptés / crédits gagnés » sous le film.
- Anti-abus : validation côté serveur (le crédit n'est versé qu'après publication de la carte du filleul), pas d'auto-parrainage.

## Ordre proposé

1. Bureau (fond + sélecteur de fond) — demande directe.
2. Monde et Projets — mise à niveau de grammaire, rapide.
3. Identity + parrainage.
4. Messages.
5. Ma Carte (le plus gros découpage).

Dites-moi si je fais tout dans cet ordre, ou si vous voulez commencer par un bloc en particulier.

## Détails techniques

- `BureauWindow` : nouveau composant `BureauWallpaper` (fond `fixed inset-0`, `-z-0`), choix stocké dans `localStorage` sous `aime.bureau.wallpaper`, liste de visuels typée dans `src/lib/bureau/wallpapers.ts`.
- `PageHero` réutilisé partout (`align="raised"`), aucun nouveau composant de hero.
- Parrainage : réutilise `invites` (`created_by`, `code`, `uses`) et `credit_ledger` (`kind='parrainage'`, `amount_cents=0`). Attribution par server function protégée, jamais côté navigateur.
- Aucune modification des 7 avertissements `SECURITY DEFINER` ni d'aucun autre finding de sécurité.
- Vérification : `bunx tsgo --noEmit` puis contrôle visuel desktop/mobile des pages touchées.
