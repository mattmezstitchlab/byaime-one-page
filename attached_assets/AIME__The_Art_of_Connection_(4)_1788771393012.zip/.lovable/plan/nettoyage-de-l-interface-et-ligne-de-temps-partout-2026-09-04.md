# Nettoyage de l'interface et ligne de temps partout

## 1. La barre du bas (AI · + · ME)

Les trois boutons font doublon avec « Modifier » en haut. On garde une seule
porte d'entrée :

- Le bouton du bas devient un unique bouton « + » (créer), centré.
- « Modifier » en haut ouvre le Studio sur l'onglet ME (déjà le cas).
- Un accès « AI » reste disponible depuis le Studio lui-même (onglets AI · + · ME
  conservés à l'intérieur), donc rien n'est perdu.

## 2. L'accueil

- Retirer la carte du réseau en bas de page (elle ne sert plus et ne s'affiche
  pas en ligne). La carte reste sur `/reseau`.
- Remettre en haut de l'accueil le champ de récit (composant `IntentionHero`
  déjà existant) : on écrit son projet en une phrase, on arrive sur la ligne de
  temps générée (`/demo/mariage?recit=…`).
- Ordre de la page : film d'ouverture → champ récit → « Votre page, et une seule
  ligne de temps » (démo de la ligne) → voix et questions.

## 3. La page carte (capture jointe)

- Les pastilles Événements / Documents / Finance au-dessus de la règle sont
  illisibles sur le média : leur donner une version « sur fond sombre »
  (fond noir translucide, texte blanc, contour discret) quand elles sont posées
  sur le visuel.
- Le bouton Play passe sous la barre latérale gauche : le décaler
  (`md:left-24`) pour qu'il ne chevauche plus la capsule, et le poser au-dessus
  d'elle en altitude.
- Son menu déroulant passe sous l'en-tête : le remonter au niveau « menu »
  de l'échelle d'altitude du site (au-dessus de l'en-tête collant) et limiter
  sa hauteur avec défilement pour qu'il tienne à l'écran.

## 4. Une seule ligne de temps, partout

Vérifier que les quatre pages qui affichent une ligne de temps
(accueil, carte, projet, démo mariage) utilisent bien le même trio
`HeroTimeline` + calques + moteur PLAY, avec les mêmes réglages d'altitude et
de lisibilité. Corriger les écarts trouvés, sans dupliquer de composant.

## Détails techniques

- `AimeBar.tsx` : supprimer les deux boutons ronds AI et ME, garder le « + » ;
  l'écouteur `aime:dock` reste pour les ouvertures programmatiques.
- `index.tsx` : retirer `CardsMap` + `cardsQuery`, insérer `IntentionHero`.
- `TimelineLayers.tsx` : ajouter une prop `tone?: "clair" | "media"` ; la page
  carte passe `tone="media"`.
- `PlayShell.tsx` : conteneur du bouton en `md:left-24`, altitude `Z.panel`.
- `PlayButton.tsx` : menu rendu dans un portail avec `Z.menu` (au-dessus de
  l'en-tête `z-[45]`), `max-h` + `overflow-y-auto`.
- Ne pas toucher aux routes `/bureau` ni aux fonctions `SECURITY DEFINER`.

## 5. La page démo mariage

- Placer la ligne de temps en bas du film d'ouverture, comme sur la page carte
  (même montage : hero plein cadre, règle posée sur le bas du visuel).
- Les cartes qui apparaissent au survol d'un moment passent derrière les blocs
  situés au-dessus : les remonter au niveau « menu » de l'échelle d'altitude et
  retirer le recadrage qui les coupe, pour qu'elles s'affichent toujours par
  dessus le reste.
- Corriger au passage l'écart de date au premier affichage (12 déc. / 13 déc.)
  dû à un calcul d'heure locale au chargement.
