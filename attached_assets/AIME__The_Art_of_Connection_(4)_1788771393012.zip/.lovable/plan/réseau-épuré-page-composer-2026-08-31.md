# Réseau épuré + page Composer

## 1. Page Réseau (`/reseau`)

- Les marqueurs restent des vignettes rondes de profil. Au clic, l'encart qui s'ouvre devient **une vraie carte AIME en noir** (fond sombre, texte clair), même gabarit visuel que les cartes du site.
- L'encart ne montre plus que : la carte + les **propositions de cette personne qui correspondent à la recherche en cours** (tags/ville/mots-clés saisis) + le **bouton cœur**.
- Suppressions dans l'encart : bouton « Proposer », bouton « Intention », bouton « Retourner » (plus de recto/verso).
- Le menu du cœur s'ouvre **au-dessus** du bouton (`side="top"`), plus jamais masqué par le bas de l'écran ni par la map.
- Nouveau : **bouton cœur flottant** en bas de l'écran de la map — rond rouge, cœur blanc. Au clic, un menu remonte avec :
  - Proposer une rencontre
  - Déposer une intention (je cherche / je propose)
  - Autour de moi (recentrer sur ma position)
  - Créer une carte

## 2. Page « Composer » (ancienne page Rencontre)

- Le menu garde **Réseau** (la map) et gagne une **nouvelle entrée « Composer »** à côté, qui pointe vers la page de composition (route `/rencontres` inchangée). Réseau et Composer coexistent.
- **Suppression de la map** sur cette page (doublon avec Réseau).
- **Suppression du bloc FLUX** en bas de page (les intentions publiques vivent désormais sur la map, via le bouton cœur flottant).
- Il reste : la saisie, la composition IA, les résultats et les présentations croisées.

## Détails techniques

- `src/routes/reseau.tsx` : encart réécrit en carte sombre, retrait de `flipped`/`RotateCw` et des deux liens d'action ; filtrage des propositions de la carte selon le terme de recherche ; ajout du FAB cœur avec menu (Popover/Sheet) en `z-[500]`.
- `src/components/aime/AimeButton.tsx` : prop `side` pour ouvrir le popover vers le haut.
- `src/routes/rencontres.tsx` : retrait de l'import et de la section `CardsMap` (l. 231-281) et du bloc `IntentionFlux` (l. 440).
- `src/components/aime/AppShell.tsx` : ajout de l'entrée « Composer » (`/rencontres`) après « Réseau », dans la nav desktop et la barre mobile.
