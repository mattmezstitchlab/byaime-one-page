# Faire d’AIME un réseau social sûr, vivant et compréhensible

## Résultat de l’audit

AIME possède déjà le parcours social essentiel : inscription, création automatique d’une page, carte du réseau, abonnements, fil « Mes suivis / Découvrir », publications, réactions, commentaires, notifications et messagerie.

Le socle fonctionne pour un premier usage, mais il reste trois chantiers avant une ouverture publique sereine :

1. **Sécuriser les interactions** : les notifications peuvent actuellement être créées trop librement, et les réactions/commentaires liés à un contenu privé ne reprennent pas sa confidentialité.
2. **Protéger les personnes** : aucun blocage ni signalement de page, publication, commentaire ou message n’est disponible ; le rôle de modérateur existe mais n’est pas encore relié à un espace de traitement.
3. **Rendre le réseau vivant** : le fil ne charge que les 20 premières publications, les abonnés ne sont pas avertis d’un nouveau moment, les listes d’abonnés restent invisibles et les données sociales réelles sont encore vides.

État vérifié dans la base : 281 pages publiées, mais seulement une page rattachée à un compte, un profil, et actuellement aucun abonnement, publication, commentaire, réaction ou notification. Un test pilote avec plusieurs comptes sera donc indispensable.

## Priorité 0 — Sécurité avant ouverture

- Remplacer la création libre de notifications par des notifications produites côté serveur à partir d’une action sociale vérifiée.
- N’accepter que des destinations internes autorisées dans les notifications ; supprimer la possibilité d’injecter un titre, un texte ou un lien arbitraire vers un autre membre.
- Faire hériter aux commentaires et réactions de la visibilité de leur page, média ou publication parente, afin qu’une interaction privée ne soit jamais lisible publiquement.
- Ajouter des contraintes de cohérence : auteur authentifié, cible existante, type autorisé, page réellement liée à la publication ou au commentaire.
- Ajouter des limites de longueur, de fréquence et de volume sur publications, commentaires, réactions, abonnements et notifications.
- Conserver hors périmètre les fonctions `SECURITY DEFINER` existantes ; les nouvelles règles s’appuieront sur les contrôles déjà disponibles sans les modifier.

## Priorité 1 — Confiance et modération

- Ajouter **Signaler** sur une page, une publication, un commentaire et une conversation, avec motif, commentaire facultatif et suivi de statut.
- Ajouter **Bloquer / débloquer** une personne : ses contenus disparaissent du fil, les interactions sont refusées dans les deux sens et aucune nouvelle conversation directe ne peut être créée.
- Créer une file de traitement réservée aux rôles modérateur/admin : contenu signalé, contexte, auteur, historique, décision et trace de l’action.
- Prévoir les décisions minimales : classer sans suite, masquer, supprimer, avertir, suspendre temporairement.
- Ajouter les actions de sécurité dans des menus discrets, sans alourdir les cartes ni les pages publiques.

## Priorité 1 — Activation du réseau

- Lorsqu’une page publie un nouveau moment, prévenir ses abonnés et relier la notification directement à la publication.
- Ajouter un chargement progressif du fil au-delà des 20 premiers éléments, avec conservation de la position et bouton de reprise en cas d’erreur.
- Ajouter une vraie amorce pour un nouveau membre : suggestions pertinentes par ville, activité et univers, avec suivi direct depuis la carte et les aperçus.
- Rendre visibles « Abonnés » et « Abonnements » depuis une page, avec listes paginées et respect des blocages.
- Transformer les actions sociales d’un visiteur non connecté en invitation contextualisée à s’inscrire, puis le ramener exactement à la page et à l’action commencée.
- Clarifier la différence entre **publier un Moment** et **commenter une page**, aujourd’hui présentés très près l’un de l’autre.

## Priorité 2 — Qualité d’usage et montée en charge

- Ajouter l’édition des publications et commentaires, déjà permise en base mais absente de l’interface.
- Activer les réponses à un commentaire à partir du lien parent déjà prévu, avec une profondeur simple et lisible.
- Remplacer les listes intégrales de réactions/commentaires par des compteurs et des chargements paginés afin d’éviter une requête par bloc du fil.
- Remplacer progressivement les rafraîchissements périodiques de la messagerie par des mises à jour instantanées filtrées par conversation ; faire de même pour notifications, commentaires et réactions.
- Ajouter partout les états « chargement », « problème de connexion », « réessayer » et les mises à jour immédiates avec retour arrière en cas d’échec.
- Sur téléphone, porter les commandes sociales principales à une zone tactile de 44 px : onglets du fil, Photo/Publier, réactions, suppression, cases de sélection et actions de carte.
- Donner une hauteur maîtrisée aux médias du fil et un repérage plus clair des sections longues de la page publique.

## Parcours pilote à valider

Tester avec au moins trois comptes réels : un créateur, un abonné et un modérateur.

```text
Inscription → page créée → profil complété → découverte sur la carte
            → suivre → publication → notification → réaction/commentaire
            → réponse/message → signaler ou bloquer → traitement modérateur
```

- Vérifier ordinateur et téléphone à chaque étape, y compris connexion lente et coupure réseau.
- Vérifier qu’un contenu privé et toutes ses interactions restent invisibles à un tiers et à un visiteur déconnecté.
- Vérifier que bloquer coupe le fil, les commentaires, les réactions, les abonnements et les nouvelles conversations.
- Vérifier que les compteurs, non-lus et destinations de notifications restent cohérents après ajout, retrait et suppression.
- Vérifier la navigation au clavier, les lecteurs d’écran, les libellés et les cibles tactiles.

## Ordre de réalisation conseillé

1. **Lot Sécurité** : notifications sûres, confidentialité héritée, cohérence des cibles, limites anti-abus.
2. **Lot Confiance** : signalement, blocage et file de modération.
3. **Lot Activation** : notifications de publication, suggestions, abonnés/abonnements, reprise après inscription.
4. **Lot Fluidité** : pagination, compteurs, réponses, édition, états réseau et mises à jour instantanées.
5. **Lot Pilote** : données de test réalistes, tests multi-comptes et validation mobile complète.

## Détails techniques

- Étendre le schéma avec des tables séparées pour blocages et signalements, avec droits explicites et règles d’accès par rôle.
- Déplacer la génération de notifications sociales dans des fonctions serveur authentifiées ; le navigateur ne choisira plus librement le destinataire ni le lien.
- Ne pas modifier les routes `/bureau`, la démo Mariage, les lignes de temps projet ni les fonctions `SECURITY DEFINER`.
- Conserver la page publique, la carte et le fil existants : les compléter plutôt que créer un second système social.