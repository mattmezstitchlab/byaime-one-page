# BUREAU AIME — préparation administrative et comptable

## Audit : ce qui existe déjà

Vérifié dans le projet aujourd'hui :

- **Devis** : table `quotes` + `quote_items`, page `/devis/$cardId` avec hero immersif. Statut, total, date cible, lien vers un projet.
- **Paiements de projet** : table `event_payments` (montant dû, payé, statut, payeur), page `/projets/$id/paiements`.
- **Facture** : page imprimable `/projets/$id/facture` (rendu, pas de document stocké).
- **Encaissement carte bancaire** : Stripe (crédits IA) + webhook `api/public/payments/webhook`, table `credit_ledger`, coordonnées de versement `payout_accounts`.
- **Pièces jointes** : bucket `pieces-jointes` utilisé uniquement dans la messagerie.
- **IA** : plusieurs fonctions serveur (composition, extraction de brief, qualification de carte) — mais **aucune lecture de document** (PDF/photo) aujourd'hui.

Ce qui **n'existe pas** malgré le prompt : pas de « Bureau », pas de Document Intelligence, pas de World Model, pas d'entités/relations, pas de scoring, pas de dossiers. Ces briques sont donc à créer, pas à réutiliser.

Conclusion : le Bureau se construit **au-dessus** de devis / paiements / factures existants, en ajoutant une couche documents + dossiers + vérification.

## Ce qu'on construit

### Capsule
Ajout d'un bouton **Dossier** (icône dossier) dans la capsule noire de gauche, entre le cœur et la radio, menant à `/bureau`.

### Modèle de données (nouveau)
- `folders` — dossier vivant : titre, type, client/carte liée, événement lié, montant attendu, état (`pret` / `a_verifier` / `incomplet`), score, dates.
- `documents` — fichier déposé : chemin storage, type détecté (devis, facture, avoir, acompte, reçu, justificatif, contrat, relevé, administratif), émetteur, tiers, dates, HT / TVA / TTC, numéro, mode de paiement, `confidence`, champs incertains, `folder_id`, statut de vérification, JSON brut de l'extraction.
- `document_links` — relations typées entre documents (devis→facture, facture→paiement, dépense→justificatif…), avec origine `auto` ou `manuel`.
- `folder_checks` — items de checklist calculés (libellé, ok/manquant/à vérifier, action proposée).
- Bucket privé `bureau` pour les fichiers, RLS + GRANT par propriétaire sur toutes les tables.

### Extraction (Document Intelligence, réelle)
Fonction serveur `analyzeDocument` : le fichier est envoyé au modèle multimodal (PDF et image en base64) avec un schéma strict → type, qui, quoi, quand, combien, pourquoi, où, plus un niveau de confiance par champ. Aucun champ inventé : si le modèle n'est pas sûr, le champ ressort `null` et s'affiche 🟠 À vérifier.

Puis `reconcileFolder` : rapprochement automatique par montant, nom du tiers, numéro et date, sur les documents **et** sur les `quotes` / `event_payments` déjà en base. Chaque lien proposé reste confirmable ou refusable par l'utilisateur.

Le score du dossier est calculé côté serveur à partir des checks (document identifié, client, montant, date, TVA, devis relié, paiement, justificatif).

### Écrans

`/bureau` — tableau de bord : compteurs (à préparer, à vérifier, prêts, pièces manquantes), totaux recettes / dépenses / à encaisser / à payer calculés sur les documents + `event_payments`, et activité récente.

`/bureau` onglets :
- **Dossiers** — cartes avec nom, type, montant, date, pastille d'état, barre de progression, éléments manquants.
- **Documents** — liste filtrable (tous, devis, factures, avoirs, dépenses, justificatifs, contrats, paiements, administratif) + recherche en langage naturel réutilisant le moteur d'intention existant.
- **À faire** — chaque anomalie est une ligne cliquable avec son action directe (ajouter le justificatif, relier au devis, corriger le montant).

`/bureau/dossier/$id` — le dossier vivant : chaîne verticale Client → Devis → Acompte → Facture → Paiement → Justificatif rendue en composant réutilisable, checklist de préparation, documents du dossier, note de l'assistant AIME (« j'ai trouvé une facture correspondant à ce devis, je les rapproche ? »).

**+ AJOUTER** : dépôt universel (glisser-déposer ou photo), sans choix de catégorie. Analyse, puis fiche de confirmation des champs détectés et rattachement à un dossier existant ou nouveau.

### Exports honnêtes
`/bureau/export` — écran de contrôle : nombre de documents, opérations, clients, fournisseurs, anomalies bloquantes, puis :
- **Préparer pour Pennylane** → génère un pack structuré (CSV factures/avoirs/tiers + JSON relations + fichiers). Aucune API Pennylane n'existe dans le projet : l'état affiché est « Intégration à connecter », jamais « synchronisé ». L'export est isolé derrière un module `exporters/` pour brancher plus tard une API officielle.
- **Préparer pour mon comptable** → archive : documents originaux, synthèse, liste des opérations, anomalies, pièces manquantes, rapprochements.

### Design
Identité AIME conservée : ivoire, noir, grands espaces, cartes lisibles, couleur uniquement pour les états (vert / ambre / rouge), micro-animations discrètes. Aucun aspect tableur.

## Détails techniques

- Routes : `src/routes/bureau.index.tsx`, `bureau.dossier.$id.tsx`, `bureau.export.tsx`.
- Composants : `FolderCard`, `DocumentRow`, `DocChain`, `ReadyScore`, `AddDocumentSheet`, `TodoList`, `BureauAssistant` sous `src/components/bureau/`.
- Serveur : `src/lib/bureau/documents.functions.ts` (analyse, rapprochement, scoring), `src/lib/bureau/export.functions.ts`.
- Requêtes : `src/lib/bureau/queries.ts` sur le modèle de `src/lib/aime/queries.ts`.
- Une migration crée les tables, le bucket privé, les GRANT et les policies RLS `owner_id = auth.uid()`.
- Aucune modification des flux devis / paiements / facture existants : le Bureau les lit.

## Livraison en 3 passes

1. Tables + bucket + capsule + `/bureau` (dashboard, dossiers, documents) + dépôt et analyse réelle.
2. Rapprochement automatique, score, checklist, vue À faire, page dossier avec la chaîne.
3. Exports Pennylane / comptable + assistant AIME contextuel + chapitre dans « Comment ça marche ».
