# Le Jeu des 52 semaines + la page Rencontres qui se souvient

Deux chantiers liés : la page Rencontres retrouve ses traces et sa barre d'intention, et une nouvelle page devient la structure du temps — 52 cartes, une par semaine, quatre saisons.

## A. Rencontres (Composition)

### A1. La même barre partout
Le bloc textarea + bouton disparaît au profit de la barre `AimeField` (cœur à gauche, champ libre, flèche), ton clair, comme sur l'accueil et « Créer ma carte ». Univers, ville et cartes embarquées restent juste dessous, en ligne discrète. Placeholders qui défilent : « Une équipe pour un mariage à Lille en septembre… », « Trouver qui manque à mon projet… ».

### A2. Ce que vous avez déjà commencé
Une bande sous la barre, avant tout résultat, réunissant trois familles dans le même style :

- **Compositions** (`compositions` + `composition_items`) : titre, univers, cartes retenues en vignettes rondes, et les « Places à pourvoir » lues dans le brief. Actions : *Reprendre*, *Compléter les places*, *En faire un projet*.
- **Rencontres gardées** : le bloc existant, remonté et harmonisé.
- **Explorations** : ce qui a été coché sur les versos des mondes (`exploration_signals`), résumé en mots-clés cliquables qui remplissent la barre, avec un bouton pour tout effacer.

### A3. Composer par les places
- **Plan des places** : une rangée de pastilles, une par rôle. Pleine = carte retenue, vide = place à pourvoir. Cliquer une place vide demande à Aime trois cartes pour ce rôle seulement.
- **Réglages vivants** : budget, distance, formalité — trois curseurs qui relancent la lecture sur la même intention.

## B. La nouvelle page : Les 52 semaines

Adresse `/saisons`. Un jeu de 52 cartes-semaines, groupées en quatre saisons, qui devient le squelette du temps d'AIME.

### Ce qu'on voit
- Quatre bandes (Hiver · Printemps · Été · Automne), 13 cartes chacune : **S1 → S52**, avec les dates de début/fin de semaine et le mois.
- La semaine en cours est cerclée ; les semaines passées sont estompées.
- Chaque carte-semaine porte des pastilles : ce qui existe déjà dans cette semaine — un projet, une disponibilité posée, un devis daté, une programmation radio.
- Cliquer une semaine ouvre son verso : la liste réelle de la semaine, et **les places à pourvoir autour de vous**.

### Les places à pourvoir, par proximité
Pour une semaine donnée, on croise ce qui existe déjà :
- les **compositions** dont le brief liste encore des places non pourvues,
- les **projets** (`events`) programmés cette semaine-là, avec leur ville,
- votre position (ville de profil, ou `lat`/`lon` si le partage est accepté).

La carte-semaine affiche alors : « 3 places à pourvoir à moins de 40 km — Régie technique · Traiteur · Photographe », avec la distance et le jour. Un bouton propose de se positionner sur une place, ce qui crée une intention et prévient l'auteur du projet.

### Ce que ça change
On ne cherche plus dans un moteur : on regarde son année, on voit les trous des autres près de chez soi, on comble. C'est l'agenda qui se remplit tout seul par voisinage de temps et d'espace.

## Ce qui est vraiment possible aujourd'hui, et ce qui ne l'est pas

**Possible tout de suite, sans nouvelle table :**
- Les 52 semaines et les 4 saisons : calcul pur (semaines ISO), aucune donnée requise.
- Pastilles de semaine à partir de `events.starts_at`, `card_availability.day`, `quotes.target_date`, `musicbox_entries.day`.
- Places à pourvoir issues des `compositions` (les « Places à pourvoir : » du brief) et de `event_participants` manquants par rapport aux rôles attendus.
- Distance : `cards.lat/lon` et `profiles.lat/lon` existent déjà ; à défaut, comparaison par ville puis par région.
- Se positionner sur une place : réutilise `intentions` (déjà en place), pas de nouveau schéma.

**Limite honnête, à corriger dans le même chantier :**
- Une composition n'a pas de date : impossible de la ranger dans une semaine tant qu'on ne lui en donne pas une. J'ajoute une colonne `target_week` (date du lundi) sur `compositions`, renseignée lors de la création ou depuis la page. Sans elle, les compositions n'apparaissent que dans une colonne « sans date ».
- Les projets d'autres utilisateurs ne sont visibles que si leurs `events` sont lisibles par autrui. Aujourd'hui la lecture est restreinte au propriétaire et aux participants. Deux options : n'afficher que vos propres places (immédiat, zéro risque), ou publier volontairement une place sur le registre public. Je propose de commencer par vos places + celles des projets où vous êtes participant, et d'ajouter un vrai « appel public » ensuite.
- La géolocalisation reste facultative et révocable ; sans elle, tout fonctionne à la ville.

## Découpage

1. **Rencontres** — barre `AimeField`, bande des traces, plan des places.
2. **Les 52 semaines** — page `/saisons`, quatre saisons, verso de semaine, pastilles réelles.
3. **La proximité** — distances, places à pourvoir autour de soi, se positionner sur une place.

## Détails techniques

- `src/routes/rencontres.tsx` : `AimeField` à la place du textarea, nouvelle section traces, plan des places.
- Nouveaux : `src/components/aime/CompositionTraces.tsx`, `src/components/aime/SlotPlan.tsx`, `src/routes/saisons.tsx`, `src/components/aime/WeekCard.tsx`, `src/lib/aime/weeks.ts` (semaines ISO, saisons, bornes) et `src/lib/aime/openSlots.ts` (agrégation des places + distance haversine).
- Migration : `alter table public.compositions add column target_week date;` (nullable, aucun impact sur l'existant).
- `composeEncounters` reçoit deux entrées optionnelles : `slotOnly` et `tuning`.
- Vérification : `tsgo --noEmit`, puis passage navigateur sur `/rencontres` et `/saisons` en session connectée.
- `roadmap.md` : ajout des trois lots ci-dessus.
