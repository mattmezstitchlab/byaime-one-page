# Une seule grammaire pour tout le site

Oui, la logique est claire : aujourd'hui chaque page a été dessinée séparément (hero sur certaines, rien sur d'autres ; « Mon espace » deux fois ; navigation en haut ET à gauche). Le but de cette repasse : **une même page-type partout**, pour que l'utilisateur n'ait plus jamais à réapprendre l'interface.

## 1. Une seule navigation

- La capsule verticale de gauche devient **la** navigation du site : Accueil, Carte réseau, Créer une équipe, Annuaire, Mes projets, Le Bureau, Radio, Messages, Mon espace, Langue. Chaque icône a son libellé au survol, et la section active est marquée.
- Le header du haut est allégé : logo AIME à gauche, et à droite un seul bouton (Mon espace / Connexion). Plus de menu horizontal en doublon.
- Sur mobile : la barre du bas reprend les mêmes entrées, plus un bouton « Plus » qui ouvre le reste (Bureau, Radio, Langue).

## 2. Un hero identique sur chaque page

Un composant unique `PageHero`, utilisé partout, avec :

- **la même hauteur partout** (`60vh`, `68vh` en desktop), pleine largeur, sous le header ;
- image ou vidéo de fond + voile sombre discret ;
- surtitre (nom de section) et **titre de la page centré** en blanc, en bas du visuel ;
- optionnellement, une **barre de saisie Aime** (champ + bouton cœur avec menu d'actions + bouton d'envoi), exactement comme sur l'accueil.

Pages concernées et visuel associé :

| Page | Titre | Champ Aime dans le hero |
| --- | --- | --- |
| Accueil | Chacun a sa carte… | oui (existant) |
| Carte réseau | La carte du réseau | oui (recherche actuelle remontée) |
| Créer une équipe | Dites ce que vous cherchez | oui |
| Annuaire | Tout ce que le réseau contient | oui (recherche + filtres) |
| Mes projets | Vos projets, du premier mot au jour J | oui (créer un projet en une phrase) |
| Ma carte | Créer ma carte | oui (existant) |
| Le Bureau | Dépose. Je lis, je classe. | oui (déposer / demander) |
| Messages | Messages, groupes et Aime | non |
| Tableau de bord, Aimes reçues, Crédits, Paramètres, Comment ça marche, Guides, Intermittent, Événements | titre de la page | non |
| Carte d'un membre | nom de la carte | non (garde son hero photo + timeline) |

L'accueil garde sa hauteur plus généreuse ; toutes les autres pages partagent strictement la même.

## 3. Un même bloc « parler à Aime »

Le champ + cœur devient un composant réutilisable (`AimeField`) : même apparence, même menu d'actions (dicter, importer, coller un lien…), seul le comportement à l'envoi change selon la page. Les variantes actuelles (accueil, rencontres, radio, ma carte) sont remplacées par ce composant.

## 4. Ce que ça règle

- Plus de doublon « Mon espace ».
- Plus de pages qui commencent par un titre nu et d'autres par une vidéo.
- Un rythme identique : hero → intention → contenu.
- Chaque page a son propre titre/description pour le partage et la recherche.

## Détails techniques

- Nouveaux composants : `src/components/aime/PageHero.tsx` (visuel, hauteur, titre, slot) et `src/components/aime/AimeField.tsx` (extraction de la barre du hero d'accueil avec `IntentionHeart`).
- `src/components/aime/AppShell.tsx` : header réduit, capsule enrichie (entrées + libellés + état actif), barre mobile revue.
- Routes modifiées pour adopter `PageHero` : `index`, `reseau`, `rencontres`, `registre`, `projets.index`, `ma-carte`, `bureau.*`, `messages`, `tableau-de-bord`, `aimes-recues`, `credits`, `parametres`, `comment-ca-marche`, `evenements`, `guides.*`, `intermittent`.
- Visuels : réutilisation des assets existants (`hero-*`, `bureau-sky`, `visual-*`) ; 3 à 4 visuels manquants générés dans la même direction ivoire/lumière chaude.
- Aucun changement de base de données ni de logique métier : mise en page, navigation et composants uniquement.
