# Une page démo : le mariage de Camille & Sofiane

## L'idée

Une seule page publique, accessible sans compte, à l'adresse `/demo/mariage`. On y parcourt un mariage complet, déjà passé : les préparatifs, le jour J, puis l'après. Tout ce qu'AIME sait faire se voit sur une même page, avec de vraies briques du site (timeline, devis, prestataires, radio, messages) mais des contenus fictifs écrits d'avance — donc rien à créer, rien à connecter, et la démo est identique pour tout le monde.

## Ce qu'on voit en descendant la page

### 1. En-tête
Film plein cadre du mariage, les deux prénoms, la date (passée), la ville, et une ligne d'état : « 12 places pourvues · 9 devis · 148 invités · mariage célébré ».

### 2. Avant : les préparatifs
- **Les places à pourvoir** — les douze rôles d'un mariage (lieu, traiteur, photographe, DJ, fleuriste…), tous remplis par une carte prestataire fictive, avec la date de signature.
- **Les devis** — la liste réelle en apparence : montant, acompte, solde, état (signé, payé), et le total engagé qui s'additionne.
- **Les échanges** — quelques fils de discussion avec les prestataires, tels qu'ils se sont déroulés avant le jour J.

### 3. Le jour J : la timeline qui se joue
Le cœur de la démo. Un bouton **Lecture** lance le déroulé de la journée dans l'en-tête : la timeline avance heure par heure, et à chaque moment l'en-tête montre ce qui se passe — préparatifs, cérémonie, cocktail, repas, ouverture de bal, soirée — avec le prestataire concerné et, pour la soirée, le morceau en cours. On peut mettre en pause, avancer d'un moment à l'autre, ou cliquer un repère pour s'y poser.

### 4. La radio du mariage
Sous la timeline, la playlist complète de la soirée : chaque titre avec son horaire, sa dédicace et son moment (ouverture de bal, dîner, fin de nuit). Le titre en cours est mis en avant pendant la lecture de la journée, et l'un suit l'autre automatiquement.

### 5. Après : les souvenirs
- Photos et vidéos du jour, posées sur la timeline aux heures où elles ont été prises.
- Le message de remerciement des mariés, puis quelques réponses d'invités et de prestataires.
- Le bilan : budget final, documents rangés, avis laissés.

### 6. Une invitation discrète
En bas : « Cette page a été créée par deux futurs mariés en trois phrases. » avec un lien vers la création de sa propre page.

## Ce que ça ne fait pas

- Aucune écriture en base : la démo est en lecture seule, personne ne peut la modifier.
- Aucune donnée réelle d'utilisateur n'y apparaît.
- Aucune page existante n'est modifiée : c'est une adresse nouvelle, à côté.

## Détails techniques

- Nouvelle route publique `src/routes/demo.mariage.tsx`, avec ses propres métadonnées de partage (titre, description, image).
- Nouveau fichier de contenu `src/lib/aime/demo/mariage.ts` : prestataires, devis, repères de timeline (`TimelineMarker[]`), étapes du jour J, playlist, fils de messages, souvenirs. Tout est typé avec les types existants, et les dates sont calculées en relatif (le mariage tombe toujours il y a ~3 mois) pour que la démo ne périme jamais.
- L'en-tête réutilise `HeroTimeline` avec ses `markers`, ses bandes et son mode aperçu ; la lecture pilote la position via un état local et un minuteur, sans toucher au composant au-delà d'un `focusTime` optionnel s'il en manque un.
- Les blocs prestataires / devis / souvenirs sont des composants de présentation propres à la démo, écrits dans le style visuel des blocs existants (`SlotPlan`, blocs devis de `carte.$id`), sans requête base.
- La radio de la démo est un panneau autonome (`DemoRadio`) : liste de titres, mise en avant du titre courant, extraits joués seulement si une source publique est fournie ; sinon le panneau reste visuel et synchronisé, sans son.
- Ajout de la démo au plan du site et au pied de page, plus une entrée dans le sitemap pour l'indexation.

## Ordre de réalisation

1. Le contenu fictif complet (prestataires, devis, timeline, playlist, messages, souvenirs).
2. La page et son en-tête filmé, avec la timeline et le bouton de lecture.
3. Les blocs Avant (places, devis, échanges).
4. La radio synchronisée avec la lecture du jour J.
5. Les blocs Après (souvenirs, remerciements, bilan) et les liens vers la démo.
