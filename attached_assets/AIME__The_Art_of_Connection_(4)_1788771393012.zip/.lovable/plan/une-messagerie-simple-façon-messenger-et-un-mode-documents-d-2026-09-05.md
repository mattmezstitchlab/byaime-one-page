# Une messagerie simple, façon Messenger — et un mode Documents dans le même panneau

## Ce qui ne va pas aujourd'hui

Le panneau Échanges ouvre tout en même temps : un texte d'explication, un champ « écrire à AIME », deux boutons, la liste des fils, la conversation et le cockpit IA côte à côte. Sur un écran normal, ça déborde et on ne sait pas où regarder. Les documents, eux, vivent complètement ailleurs, et une pièce jointe envoyée dans une conversation n'apparaît jamais dans la bibliothèque de documents.

## Le principe

Un seul panneau latéral, deux onglets en haut : **Discussions** et **Documents**. Rien d'autre à l'ouverture.

```text
┌──────────────────────────────┐
│  Discussions | Documents   ✕ │
│  🔍 Rechercher               │
├──────────────────────────────┤
│  ● Mariage      il y a 2 h   │
│    Le lien de visio…         │
│  ○ Julie        hier         │
│    D'accord pour jeudi       │
└──────────────────────────────┘
```

### Onglet Discussions

- Liste seule à l'ouverture : photo, nom, dernier message, heure, pastille bleue si non lu.
- Une barre de recherche en haut, un bouton « + » discret pour démarrer une conversation.
- On clique : la conversation **remplace** la liste, avec une flèche retour, le nom, et les actions (participants, visio, options IA) rangées dans un petit menu « … ». Plus de colonne cockpit collée à côté.
- Le texte d'introduction et le champ « écrire à AIME » disparaissent ; l'aide d'AIME reste accessible depuis le menu de la conversation.
- Une conversation peut être rattachée à un projet : le nom du projet s'affiche en petit sous le titre.

### Onglet Documents

Le même panneau, mais l'arborescence de dossiers :

- Arbre de dossiers repliables (déjà en place dans le Bureau), avec les projets qui apparaissent comme des dossiers à part entière — ouvrir un projet, c'est ouvrir son dossier.
- Un dossier par conversation également : tout ce qui a été échangé dans un fil s'y retrouve.
- Bouton « Envoyer un document » : on choisit un fichier et une conversation, il part dans le fil **et** se range dans le dossier.
- Toute pièce jointe reçue dans une conversation entre automatiquement dans la bibliothèque : un seul document, plusieurs chemins pour le retrouver.
- Chaque document reste cliquable pour l'ouvrir, le déplacer par glisser-déposer, le renommer.

Le Bureau (la grande fenêtre de gestion) ne change pas : il lit exactement les mêmes dossiers et les mêmes documents.

## Étapes

1. Refonte du panneau : deux onglets, liste puis conversation en plein panneau, recherche, non-lus.
2. Nettoyage de la conversation : actions regroupées dans un menu, cockpit IA en tiroir.
3. Onglet Documents : arbre partagé avec le Bureau, dossier par projet et par conversation.
4. Passerelle pièce jointe → document, dans les deux sens.

## Détails techniques

- `MessagesSheet.tsx` devient une coquille à onglets (`discussions` / `documents`) ; `openMessages(threadId?)` gagne un paramètre d'onglet.
- `ThreadsSection.tsx` (943 lignes) est scindé : `ThreadList` (liste + recherche + non-lus) et `ThreadView` (fil + composeur + menu d'actions), le cockpit IA existant passe en tiroir secondaire.
- Réutilisation directe de `FolderTree.tsx` et `src/lib/bureau/queries.ts` — `bureau_folders.parent_id`, `event_id` et `card_id` existent déjà, aucun second stockage.
- Migration nécessaire : `threads.event_id` (rattachement projet) et `bureau_folders.thread_id` + `bureau_documents.message_id` (lien pièce jointe ↔ document), avec GRANT et RLS alignés sur l'existant.
- Les pièces jointes migrent du bucket `pieces-jointes` vers `bureau` à l'envoi, pour n'avoir qu'un seul emplacement de fichiers.
- Hors périmètre, inchangés : les routes `/bureau` et les fonctions `SECURITY DEFINER`.
