# Studio AIME : un seul écran d'édition, et une carte du monde vivante

## Ce que je confirme

1. **Accueil libre.** `/` reste public : le film, la ligne de temps et la carte du réseau sont visibles sans compte. Rien à changer côté accès.
2. **Page personnelle protégée.** Dès qu'on va sur sa page (`/ma-page`, l'édition de sa carte), la connexion est demandée, puis le remplissage des informations (nom, rôle/activité, univers, ville). Aujourd'hui l'ouverture passe déjà par un accès identifié ; on rendra le passage explicite : connexion → remplissage guidé → page.
3. **Grille du Monde AIME relationnelle.** Oui, c'est faisable et c'est la bonne direction : au lieu d'une grille « toutes les cartes », la grille se lit depuis votre page. Quatre familles :
   - **Associés** — déjà reliés (projets, aimes échangées, messages)
   - **Complémentaires** — métier différent mais même univers / même ville
   - **Alignés** — même métier, même univers (pairs)
   - **En recherche** — cartes qui ont déclaré un besoin correspondant à ce que vous proposez

   Le classement se recalcule à partir de ce que vous remplissez (univers cochés, activité, ville, disponibilités). Tant que la page est vide, la grille reste générique — c'est le meilleur argument pour finir sa page.

## Le Studio AI + ME

Un bouton **Modifier** en haut à droite, à côté de « Mon espace ». Il fait descendre du haut un panneau plein écran : le **Studio**.

```text
┌──────────────────────────────────────────┐
│  STUDIO            AI · ME · +      [X]  │
├──────────────────────────────────────────┤
│  Onglet actif : ME                       │
│                                          │
│  Ma page   Mon activité   Mes univers    │
│  Disponibilités   Tarifs   Réglages      │
│  Compte · langue · radio · données       │
└──────────────────────────────────────────┘
```

- Les trois boutons du bas (AI, +, ME) deviennent les trois onglets du Studio ; la barre du bas reste comme raccourci d'ouverture.
- **ME** : édition de la page (ce que fait aujourd'hui l'ouverture de « ma page ») + activité, univers, dispos, tarifs + tous les réglages (compte, lieu, langue, accessibilité, radio, données, déconnexion).
- **AI** : comprendre AIME, la mémoire, la traduction, la radio, les suggestions.
- **+** : créer (projet, événement, document, intention).
- Une sauvegarde unique : ce qu'on modifie met à jour la carte, et donc la grille du Monde, en direct.

## Pages qui restent au final

**Publiques**
- `/` accueil
- `/reseau` le Monde AIME (grille + carte)
- `/carte/$id` une page (la vôtre ou celle d'un autre)
- `/auth` connexion
- `/comment-ca-marche`, `/guides/*`, `/evenement/*`, `/legal/$doc`, `/plan-du-site`, `/sitemap.xml` (référencement)

**Connecté**
- `/ma-page` (redirige vers votre carte, Studio ouvert au premier passage)
- `/projets`, `/projets/$id/*` (fiche, participants, paiements, facture, musicbox)
- `/messages`
- `/bureau/*` (inchangé)
- `/devis/$cardId`, `/invitation`, `/frequence/$id`
- `/admin/enrichissement`

**Absorbées par le Studio, puis supprimées** (avec redirection vers `/ma-page`)
`/parametres`, `/profil`, `/ma-carte`, `/cockpit`, `/tableau-de-bord`, `/credits`, `/registre`, `/objectif`, `/chemin`, `/communs`, `/entraide`, `/rencontres`, `/saisons`, `/monde`, `/evenements`, `/beta`, `/ambassadeur`, `/intermittent`, `/aimes-recues`, `/demande-profil`.

On passe de ~50 pages à ~20.

## Ordre de réalisation

1. Studio AI + ME (bouton Modifier, panneau descendant, onglets, absorption des réglages et de l'édition de page).
2. Connexion + remplissage obligatoire à l'entrée de la page personnelle.
3. Grille relationnelle du Monde AIME (les quatre familles, calcul depuis la carte).
4. Nettoyage des pages et redirections.

## Détails techniques

- Studio : nouveau `src/components/aime/studio/Studio.tsx`, ouverture par un événement global (comme `aime:dock`), onglets alimentés par `AiPanel`, `MePanel`, `CREATE_ENTRIES` ; `SettingsSection` et `PageSetup` déplacés dedans.
- Grille : nouveau sélecteur dans `src/lib/aime/` qui classe les cartes en associés / complémentaires / alignés / en recherche à partir de `cards` (métier, univers, ville), `aimes`, `event_participants` et `help_requests` ; consommé par `WorldGridSection`.
- Suppressions : chaque route retirée est remplacée par une redirection permanente vers `/ma-page` ou `/reseau`, et les liens de `navigation.ts` (FOOTER_NAV) sont mis à jour.
- Pas de changement de base de données à cette étape.
