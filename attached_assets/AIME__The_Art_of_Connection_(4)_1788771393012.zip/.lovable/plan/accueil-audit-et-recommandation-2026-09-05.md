# Accueil — audit et recommandation

## Ce que montre l'accueil aujourd'hui

1. Un hero plein écran : film de mariage en fond, une conversation en 6 questions, et la ligne de temps qui se dessine en bas au fur et à mesure des réponses.
2. Sous le hero, la bande des univers (12 vidéos) avec un court texte.
3. C'est tout : ni preuve, ni explication des autres usages (réseau, argent, messages, Play, mon espace), ni parcours pour quelqu'un qui n'a pas envie de répondre tout de suite.

Constats :

- **La promesse est forte mais coûteuse.** Le premier écran demande un effort (raconter son projet) avant d'avoir montré à quoi sert AIME. Un visiteur froid, surtout sur téléphone, n'a pas de raison de commencer.
- **Il n'y a aucune sortie douce.** Pas de « voir sans rien écrire », sauf un petit lien démonstration tout en bas du dernier écran.
- **Le reste de l'application est invisible.** Le réseau, les paiements orchestrés, les messages, Play, la page publique : rien n'est raconté.
- **Le titre de la page ne parle que de mariage** alors que la bande juste en dessous annonce douze univers : message contradictoire.
- **Rien à lire pour les moteurs de recherche** : la page est quasiment vide de texte, tout est dans une interaction.

## Ma recommandation

Ni l'un ni l'autre en exclusivité : **garder le parcours interactif comme premier acte, et lui ajouter une vraie landing page immersive en dessous**. Le parcours est ce qui rend AIME unique — il ne faut pas le remplacer par une page marketing de plus. Mais il ne peut pas rester seul : il lui faut un « avant » (une phrase claire + une porte de sortie) et un « après » (les sections qui montrent l'application).

## Ce que je construirais

**Acte 0 — le hero respire.** Au-dessus de la première question : une phrase qui dit ce qu'est AIME en une ligne, et deux portes : « Raconter mon projet » (le parcours actuel) et « Regarder d'abord » (fait défiler vers la démonstration animée). Titre et description de la page réécrits pour couvrir tous les univers, pas seulement le mariage.

**Acte 1 — le parcours** : inchangé.

**Actes suivants — les grandes sections immersives**, plein écran, une idée par section, animées à l'arrivée dans l'écran :

1. **Une seule ligne de temps** — démonstration jouée toute seule, sans rien saisir : les moments se posent, la ligne se remplit.
2. **Douze univers** — la bande vidéo existante, remontée ici avec son texte.
3. **Le réseau** — la carte et les pages des personnes et des lieux, avec un aperçu réel.
4. **L'argent, orchestré** — devis, échéances, autorisations : AIME prépare et suit, n'encaisse pas.
5. **Play** — la lecture du projet dans le temps, avec le son.
6. **Ensemble** — messages, documents, invités, page publique.
7. **Le manifeste + l'appel** — une dernière phrase, et le champ d'intention qui revient.

Chaque section : un titre court, deux lignes, un visuel réel de l'application (vidéo ou capture animée), et jamais de tableau de bord.

## Points d'attention

- **Téléphone d'abord** : sections empilées, hauteur libre plutôt que plein écran forcé, animations désactivées si l'appareil le demande.
- **Poids** : les vidéos ne se chargent qu'à l'approche de leur section, une seule joue à la fois.
- **Référencement** : le texte des sections est du vrai texte lisible, un seul titre principal, description réécrite.

## Détails techniques

- `src/routes/index.tsx` : nouvelles métadonnées (titre/description multi-univers), assemblage des sections.
- Nouveau `src/components/aime/home/HomeStory.tsx` + un composant `StorySection` réutilisable (titre, texte, média, `IntersectionObserver` pour l'animation et la lecture vidéo, respect de `prefers-reduced-motion`).
- `HomeJourney.tsx` : ajout de l'accroche et des deux boutons au-dessus de l'étape 0, ancre de défilement ; le reste du parcours n'est pas touché.
- `UniverseStrip.tsx` réutilisé tel quel comme section 2.
- Médias : réemploi des vidéos existantes (`aime-wedding`, `aime-face`, `identity-film`, `univers-*`) ; captures animées ajoutées seulement si un visuel manque.
- Aucun changement de logique métier, de base de données ni des routes `/bureau`.
