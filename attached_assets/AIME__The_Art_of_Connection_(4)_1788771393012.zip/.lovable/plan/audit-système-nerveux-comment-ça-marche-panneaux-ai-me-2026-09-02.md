# Audit : système nerveux, « Comment ça marche », panneaux AI · + · ME

Tout ce qui suit a été vérifié dans le code avant d'être écrit.

## 1. Le système nerveux (`/plan-du-site`) — ce qui ne dit plus la vérité

La carte du système date d'avant la Fréquence, la Radio et Le Monde AIME.

Erreurs confirmées :
- **Radio AIME pointe vers `/`** (aucune page Radio n'existe : la Radio vit dans l'onglet Radio d'un Monde). Nœud trompeur.
- **Devis & factures pointe vers `/bureau`**, exactement comme le nœud Bureau : deux nœuds, une seule destination. La vraie destination est l'onglet Devis d'une carte.
- **La page universelle `/carte/$id` n'est pas un nœud** alors qu'elle est devenue le centre du site (Visuel · Timeline · Onglets · Radio).
- **La Fréquence n'apparaît nulle part** : ni le nœud, ni le flux Timeline → effets → Fréquence → Radio → animatrice, qui est pourtant la colonne vertébrale actuelle.
- **La bibliothèque musicale et le journal de diffusion** (œuvres, licences, airplay) n'existent pas sur la carte.
- Pages réelles absentes : Intermittent, Invitation, Demande de profil, Export comptable, Membres du Bureau.
- Tous les nœuds sont marqués « Fonctionne » sauf deux : l'état ne reflète pas l'avancement réel.

Correctifs proposés :
- Une sixième colonne **« Écouter »** : Page universelle · Fréquence · Radio · Bibliothèque musicale.
- Destinations réelles pour Radio et Devis (onglets de `/carte/$id`).
- Nouveaux flux : timeline → fréquence, fréquence → radio, radio → bibliothèque, contribution → timeline, monde → fréquences actives.
- Pastilles d'état révisées page par page.

## 2. « Comment ça marche » — trois chapitres manquent

La page rejoue les 6 chapitres de la visite : carte, équipe, annuaire, timeline, Bureau, projet. Depuis, trois briques majeures ont été livrées et ne sont expliquées nulle part :

- **Le Monde AIME** — la grille universelle, prendre sa place, le coup d'œil puis la vraie carte.
- **La Fréquence et la Radio** — « ce qui a bougé, en ce moment, ce qui se prépare », l'animatrice qui explique *pourquoi* ça évolue, le consentement de diffusion.
- **Contribuer** — donner du temps, une compétence, un objet : la contribution devient un repère de timeline et fait évoluer la fréquence.

Ajouts prévus :
- 3 chapitres supplémentaires (07, 08, 09) dans la même grammaire visuelle que les six actuels.
- Un encart « Bon à savoir » sur la musique : préécoute, droits, traçabilité — sans jamais promettre « libre de droits ».
- Sommaire ancré mis à jour ; métadonnées de la page réécrites (elles annoncent encore « six chapitres »).

La visite de 40 s reste à six chapitres : on ne l'alourdit pas. Les trois nouveaux sont propres à la page longue.

## 3. Panneau AI — ce qui manque

Présent : suggestions, pièces à vérifier, champ d'intention, crédits, mémoire, discussions, journal, Comprendre.

Manque :
- **Ce qui a bougé dans mes Mondes** : les derniers effets de fréquence de mes cartes, avec le repère source. C'est la nouveauté la plus forte du site et elle est invisible ici.
- **Écouter une fréquence** : accès direct au sélecteur des fréquences publiées.
- **Le plan généré** : la roadmap produite depuis le champ hero n'est jamais rappelée.
- Les suggestions ignorent trois signaux déjà disponibles : demandes Aime sans réponse, projet sans dossier au Bureau, carte sans repère de timeline récent.

## 4. Panneau + (créer) — ce qui manque

Manque : **une contribution** (don, temps, compétence) et **une annonce radio / un moment d'antenne**, alors que les deux existent en base.
À corriger : « Un devis » pointe sur `/registre` (redirection) au lieu de la création réelle ; « Une intention publique » et « Un éphémère » pointent tous deux sur `/reseau`.

## 5. Panneau ME — ce qui manque

Présent : compte, où j'en suis, mes cartes, échanges, argent, Bureau, versements, déconnexion.

Manque :
- **Ma fréquence** : est-elle publiée ? diffusion consentie ou non, avec l'interrupteur ici.
- **Ma place dans Le Monde AIME** : ma case, ou l'invitation à la prendre.
- **Ma bibliothèque musicale** et mes diffusions journalisées.
- **Mes contributions** — ce que j'ai donné, ce que j'ai reçu.

## 6. Livraison

1. Mise à jour de la carte du système (nœuds, destinations, flux, états réels).
2. Trois chapitres et un encart musique dans « Comment ça marche », métadonnées corrigées.
3. Enrichissement des trois panneaux selon les manques ci-dessus, sans jamais dupliquer une entrée d'un panneau à l'autre (AI = ce qui vient d'elle · + = ce que je crée · ME = ce qui m'appartient).

## Détails techniques

`src/lib/aime/systemMap.ts` : ajout d'une colonne (grille passant à 6 colonnes, recalcul de `COL`), nœuds `carte-universelle`, `frequence`, `radio` (vers `/carte/$id?onglet=radio` via un Monde d'exemple ou état « à venir » si aucun), `bibliotheque`, `intermittent`, `invitation`, `export`, `membres` ; nouvelles arêtes ; statuts revus. `src/routes/plan-du-site.tsx` : adaptation du `viewBox` et de la disposition mobile, aucun changement de comportement d'animation. `src/lib/aime/tour.ts` reste à 6 chapitres ; les 3 nouveaux vivent dans une constante locale `CHAPTERS_PLUS` de `src/routes/comment-ca-marche.tsx`, rendue avec le même bloc JSX (visuels existants réutilisés : `guide/registre.jpg`, `visual-music.jpg`, `visual-people.jpg`). `AiPanel.tsx` : bloc « Ce qui a bougé » via `effectsQuery` sur `myCards`, entrée vers `FrequencyPicker`, suggestions étendues à partir de `receivedAimesQuery`, `eventsQuery` et `documentsQuery` déjà chargées. `AimeDock.tsx` : deux entrées de création ajoutées, destination du devis corrigée. `MePanel.tsx` : sections Fréquence (lecture de `card_radios` : publiée + `broadcast_consent`), Ma place (`world_cells`), Bibliothèque (`works` / `airplay_logs`), Contributions (repères de timeline `kind = contribution`). Aucune modification de base de données, aucune nouvelle dépendance.
