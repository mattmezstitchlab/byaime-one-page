# AIME — Money Orchestrator (couche finance de la ligne de temps)

AIME orchestre, l'utilisateur autorise, un prestataire de paiement exécuterait, la ligne de temps trace. Cette étape construit le modèle financier complet et sa représentation dans le projet Mariage de démonstration — sans jamais déplacer d'argent réel.

## Principe

Un devis n'est pas un document : c'est un engagement financier relié au temps. Le montant est saisi une seule fois et se lit partout — budget, échéances, prestataire, document, ligne de temps, PLAY.

```text
WeddingProject → PaymentCommitment → PaymentSchedule → Payment → Bénéficiaire
                                            ↓
                                    Timeline universelle
```

## Ce qui est construit

**1. Engagements financiers**
Chaque prestataire ayant un montant devient un engagement : total, acompte, solde, date de service, document source, statut, niveau de confiance. Le budget actuel devient une lecture de ces engagements, plus une liste séparée.

**2. Échéanciers**
Chaque engagement porte une programmation datée (par exemple traiteur : 2 000 € au 01/10/2026, 2 000 € au 01/04/2027, 2 000 € au 01/08/2027, 2 400 € au 05/09/2027). Les échéances sont calculées à partir de la date du mariage et des conditions détectées, et clairement marquées « proposé par AIME » tant qu'elles ne sont pas validées.

**3. Statut MONEY READY**
Pour chaque échéance, un feu à trois états : 🟢 prêt, 🟠 action requise, 🔴 bloqué — calculé depuis bénéficiaire identifié, bénéficiaire vérifié, document présent, montant confirmé, échéance confirmée, autorisation valide. Chaque état affiche ce qui manque exactement.

**4. Double validation**
Rien ne devient exécutable par déduction. Parcours : détecté → proposé → vérifié → validé par le couple → autorisation de paiement → programmé. Les deux dernières marches restent verrouillées en démo (badge « Disponible avec votre abonnement »).

**5. Journal financier immuable**
Un registre d'événements horodatés — créé, validé, programmé, exécuté, confirmé, échoué, annulé, remboursé, bénéficiaire vérifié. Rien n'est jamais supprimé ; une correction ajoute un événement. Consultable par engagement et en vue globale.

**6. Rétroplanning de paiement**
Pour chaque échéance importante : J-30 préparation, J-15 vérification, J-7 rappel, J-2 dernière vérification, jour de l'échéance. Ces jalons apparaissent comme des repères sur la ligne de temps.

**7. Calque Finance**
Le calque finance existant s'enrichit : engagements, échéances, jalons de préparation, paiements effectués, alertes. Filtrable et lisible par année/mois, puis avant / jour J / après.

**8. Alertes intelligentes**
Solde arrivant à échéance, moyen de paiement non validé, bénéficiaire non vérifié, facture au-dessus du budget prévu, paiement programmé avant la date contractuelle, prestation sans engagement associé. Elles rejoignent la boussole « Que manque-t-il ? ».

**9. Document → argent**
À l'import d'un devis ou d'une facture, AIME propose un engagement pré-rempli (prestataire, prestation, total, TVA, acompte, solde, échéances) que l'utilisateur valide ou corrige avant intégration. Jamais d'ajout silencieux.

**10. Spectacle / Intermittence**
Un artiste ou technicien n'est pas un fournisseur. Une relation d'emploi porte : employeur, salarié, emploi, objet, dates de répétition et de représentation, lieu, heures, cachets, frais, régime applicable, statut déclaratif, documents. Un moteur de cohérence pose les six questions (qui, quoi, quand, où, quel statut, quel régime) et signale les incohérences — par exemple « cette prestation semble relever d'une relation salariée du spectacle vivant, vérifiez le régime avant paiement ». AIME prépare le dossier et les éléments de rémunération, puis oriente vers le GUSO ; il ne déclare pas, ne calcule pas de cotisations comme s'il s'agissait d'un fait établi, et n'affirme jamais qu'une situation est légale.

**11. Tableau de bord finance**
Budget total, déjà payé, programmé, à prévoir, en attente, bloqué, après mariage — avec la répartition par prestataire et par période.

**12. PLAY financier**
La lecture du projet énonce les échéances au fil du temps : « Dans 14 jours, le deuxième paiement du traiteur est prévu. » La narration est construite depuis les données, jamais inventée.

**13. Abstraction prestataire de paiement**
Une interface unique (vérification du bénéficiaire, autorisation, exécution, remboursement, réconciliation par webhook) avec une implémentation de démonstration. Stripe Connect ou une autre solution s'y branchera ensuite sans toucher au reste. « Connecter mon compte bancaire » reste neutre : aucune banque imposée.

## Ce qui n'est pas fait ici

Aucun mouvement d'argent réel, aucun onboarding KYC, aucun webhook de production, aucune intégration GUSO automatisée. Les actions opérationnelles (autoriser, payer, exporter, déclarer, synchroniser la banque) restent verrouillées derrière l'abonnement, comme le reste de la démo.

## Détails techniques

- Nouveau `src/lib/aime/world/finance.ts` : `PaymentCommitment`, `PaymentSchedule`, `PaymentInstallment`, `PaymentEvent`, `MoneyReadyState`, `readinessOf`, `scheduleFrom`, `ledgerOf`, `financeSummary`. Les montants restent en centimes.
- Nouveau `src/lib/aime/world/employment.ts` : `EmploymentRelationship`, `EmploymentRegime`, `complianceCheck` retournant des constats et des manques, jamais un verdict de légalité.
- Nouveau `src/lib/aime/payments/provider.ts` : interface `PaymentOrchestratorProvider` + `demoProvider`. Aucun couplage direct à un PSP.
- `world/types.ts` : `WorldProject` gagne `commitments` et `employments` ; `WorldPayment` devient une projection de l'échéancier plutôt qu'une liste indépendante.
- `world/derive.ts` : `deriveTimeline` émet les repères d'échéance, les jalons J-30/J-15/J-7/J-2 et les alertes ; `financeOf` lit les engagements.
- `demo/mariage.ts` : les prestataires existants portent leurs engagements et échéanciers ; un intermittent (musicien du bal) illustre le module spectacle. Aucune donnée dupliquée.
- `routes/demo.mariage.tsx` : section Finance repensée (tableau de bord, engagements dépliables avec échéancier, feu MONEY READY, journal), alertes dans la boussole, calque finance enrichi, narration PLAY financière.
- `timelineFilters.ts` : familles `finance` et `alerte`/`autorisation` complétées pour les nouveaux repères.
- Aucune migration de base, aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié.
