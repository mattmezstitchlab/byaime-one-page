# Dernière passe de réglages avant les tests

## 1. Réseau : pouvoir effacer l'exploration venue du verso d'une carte Univers

Aujourd'hui la pastille « Exploration : Lien & Rencontre · Salons & rencontres »
s'affiche mais ne se retire pas : impossible de repartir sur toute la carte.

- La pastille reçoit une croix. Un clic efface le monde, le métier et l'entrée,
  et la carte redevient complète.
- Même geste que la pastille de ville, déjà présente dans la barre de recherche.

## 2. Réseau : la liste de droite

- La case à cocher « choisir » n'apparaît que si l'on est connecté **et** que
  l'on a déjà un monde. Elle sera toujours visible dès qu'on est connecté ;
  sans monde, un clic propose d'en créer un.
- Le menu ouvert depuis le cœur d'une ligne montre encore l'ancien découpage
  (« Présent », « Autres temps »). Il reprendra la présentation courte et
  ordonnée : les actions possibles d'abord, le reste replié.

## 3. Une barre du bas sur ordinateur aussi

Les portes Personnes · Argent · Documents · Le jour J · Veille · Échanges
deviennent une vraie barre posée en bas de l'écran, identique sur téléphone et
sur ordinateur.

- Une seule ligne, jamais de défilement horizontal : sur petit écran l'icône
  seule, le mot apparaît dès qu'il y a la place ; au-delà de cinq portes, un
  bouton « Plus ».
- Le header s'allège d'autant : les accès Documents et Échanges qui y font
  doublon disparaissent, puisqu'ils vivent dans cette barre.

## 4. La démo dans le téléphone (accueil)

- Barre de défilement en noir à l'intérieur du téléphone (la règle déjà écrite
  pour le reste du site).
- Le panneau qui s'ouvre (Documents, Argent…) doit pouvoir se refermer : bouton
  Fermer bien visible en haut du panneau, y compris en mode intégré.
- Le panneau Documents montre une simple liste ; il affichera la même
  bibliothèque que le reste du site (arborescence + visionneuse), pour ne pas
  avoir deux façons de voir un document. En démo, en lecture seule.

## 5. Recevoir les retours des testeurs

Les retours partent bien dans la base, mais personne ne peut les lire : il
n'existe aucun écran. Et rien n'a encore été envoyé (0 retour enregistré).

- Un onglet « Retours » dans la page de modération, réservé aux administrateurs :
  liste datée, page concernée, personne, état (nouveau / traité).
- Un compteur discret dans le menu AIME quand il y a du nouveau.
- Un test de bout en bout : envoi depuis « Aide & retours » → apparition dans la
  liste.

## Détails techniques

- `reseau.tsx` : bouton d'effacement sur la pastille d'exploration
  (`navigate({ to: "/reseau", search: {} })`) ; case de sélection décorrélée de
  `myWorlds.length`.
- `AimeButton.tsx` / `tense.tsx` : simplifier l'entête du menu (retirer le
  bandeau « Présent » / « Autres temps » au profit d'un simple ordre).
- `ProjectPanels.tsx` : `PanelBar` en barre fixe (`fixed inset-x-0 bottom-0`,
  altitude `Z.dock`), libellés masqués sous `sm`, débordement en menu « Plus » ;
  `AppShell` retire les boutons Documents/Échanges du header et ajoute le
  décalage de bas de page.
- `WorldPanels.tsx` : panneau Documents branché sur `FolderTree` + `DocViewer`
  en lecture seule.
- `sheet.tsx` : garantir le bouton de fermeture visible dans le contexte
  `embed` ; `scrollbar-dark` appliqué dans la démo.
- `moderation.tsx` : onglet lecture `beta_feedback` (politique admin déjà en
  place, aucune migration nécessaire).
- Ne pas toucher aux routes `/bureau` ni aux fonctions `SECURITY DEFINER`.
