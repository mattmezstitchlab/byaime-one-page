# Prêt pour une première inscription, sur téléphone

Objectif : qu'une personne à côté de vous crée son compte sur son téléphone et arrive à quelque chose de clair, sans aide.

## Ce que j'ai vérifié dans le site actuel

- L'inscription existe (e-mail + mot de passe, ou Google) et renvoie vers « Mon espace ».
- La barre du haut affiche, une fois connecté, jusqu'à huit petits boutons côte à côte (radio, messages, documents, mon espace, le fil, mon profil, la carte…) sur une seule ligne : sur un écran de téléphone c'est trop serré.
- À la création du compte, **aucune page publique n'est créée automatiquement**. Le panneau « Modifier ma page » affiche alors seulement « Votre page n'existe pas encore » et renvoie vers l'accueil : la nouvelle personne se retrouve sans rien à faire de concret.
- Les boutons Messages, Documents, Le fil et Mon profil n'existent pas tant qu'on n'est pas connecté, donc l'accueil visiteur reste simple — c'est bien.

## Ce que je propose de faire

### 1. Une première minute qui a du sens
- À la création du compte, créer tout de suite la page personnelle avec le nom saisi, puis ouvrir un accueil de bienvenue en 3 étapes très courtes : votre nom et votre photo, votre ville, ce que vous faites / cherchez.
- Chaque étape est passable, tout s'enregistre au fur et à mesure, et on termine sur sa propre page publique avec « Voilà votre page ».
- Si la confirmation d'e-mail est demandée, afficher un message clair (« regardez votre boîte mail ») plutôt qu'un écran vide.

### 2. La barre du haut, pensée téléphone
- Sur mobile : garder au maximum trois repères visibles (mon espace avec sa pastille, messages, le fil) et regrouper le reste dans le menu du logo.
- Les pastilles rouges restent visibles sur les icônes conservées ; sur celles rangées dans le menu, la pastille remonte sur le logo.
- Boutons agrandis à au moins 44 px pour être touchables au doigt.

### 3. Passage au peigne fin de chaque écran sur un téléphone
Accueil, inscription, ma page publique, le fil, la carte du réseau, la démo mariage, et les panneaux latéraux (Mon espace, Messages/Documents, Réglages, Modifier ma page).
Points contrôlés : rien qui déborde sur le côté, textes lisibles, panneaux en plein écran et défilants, clavier qui ne masque pas le champ d'écriture, boutons atteignables au pouce, zone sûre en bas des iPhone.

### 4. Vérifications avant qu'elle s'inscrive
- Une vraie inscription de bout en bout depuis un téléphone, en navigation privée : compte créé, page créée, publication d'un premier moment, envoi d'un message, réaction et commentaire.
- Vérifier que la connexion Google fonctionne bien depuis l'adresse publique du site.
- Vérifier qu'une page toute neuve, vue par quelqu'un d'autre, s'affiche correctement (pas de blocs vides ni d'erreurs).

## Détails techniques

- Création de la carte à l'inscription : déclencheur base de données sur nouvel utilisateur (`cards` à partir de `display_name`), plus repli côté client si la carte manque.
- Nouvel écran `/bienvenue` (ou panneau) réutilisant `PageSetup`, ouvert après `signUp` / retour OAuth ; `auth.tsx` redirige vers lui au lieu de `/mon-espace#ma-page`.
- `AppShell.tsx` : en-tête responsive (icônes secondaires masquées sous `md`, déplacées dans `LogoMenu`), agrégation des pastilles, tailles tactiles.
- Audit visuel Playwright à 390 px sur les routes clés + relevé de `scrollWidth > clientWidth` (l'outil navigateur est indisponible dans cet environnement pour l'instant ; à défaut, contrôle par revue des styles et test manuel guidé).
- Aucune modification des `SECURITY DEFINER` existants, pas de route `/bureau`.
