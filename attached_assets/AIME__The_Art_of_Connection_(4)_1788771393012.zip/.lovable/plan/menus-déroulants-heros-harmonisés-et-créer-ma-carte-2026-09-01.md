# Menus déroulants, heros harmonisés et « Créer ma carte »

## 1. Filtres du registre — villes en saisie

Dans le panneau latéral droit des filtres :
- La longue liste de villes devient un champ de saisie avec suggestions (les villes réellement présentes dans les cartes, avec leur nombre), filtrées au fur et à mesure de la frappe.
- La ville sélectionnée s'affiche comme une puce unique, avec une croix pour l'enlever.
- Les blocs « Univers », « Sous-univers » et « Familles » deviennent des sections repliables (fermées par défaut, ouvertes si un filtre y est actif), pour un panneau court et lisible.

## 2. Page « Ma carte » — univers en menus

- La grille de 12 boutons d'univers devient un menu déroulant multi-sélection (liste compacte avec cases cochées + icône), les univers choisis s'affichant en puces sous le menu.
- Les sous-univers suivent le même principe : un menu déroulant par univers sélectionné, au lieu de dizaines de pastilles.
- La ville passe en champ de saisie avec suggestions (mêmes villes que le réseau), la région restant déduite automatiquement.

## 3. Page « Mes projets » — hero réduit

Le hero vidéo passe de `92vh` à la même hauteur que l'accueil (`min-h-[60vh]`, `md:min-h-[68vh]`), texte et dégradé conservés.

## 4. Page « Ma carte » — hero et réorganisation

- Nouveau hero pleine largeur, même hauteur que l'accueil, avec un visuel généré (ambiance ivoire/lumière chaude, mains composant une carte, esprit Apple) et le titre « Créer ma carte » en blanc, centré en bas du hero.
- Sous le hero : le bloc de l'entremetteuse (saisie libre + bouton « Qualifier ma carte ») élargi et mis en avant, avec le bouton cœur (mêmes actions que sur l'accueil : import, dictée, etc.) et, juste à côté, les menus univers / sous-univers. Ce bloc devient le point d'entrée de la page.
- Le formulaire détaillé (photo, accroche, présentation, ville, savoir-faire, tags, calendrier) reste dessous, inchangé.
- Le bloc « Organisateur » (adresse, téléphone, site web) ne s'affiche que si la catégorie choisie est de type organisateur/lieu/structure ; sinon il est masqué et les champs conservent leur valeur existante.

## Détails techniques

- `src/routes/registre.tsx` : composant local `CitySearch` (input + liste filtrée) et sections repliables dans le `SheetContent`. Aucun changement de logique de filtrage.
- Menus déroulants : `DropdownMenu` shadcn avec items `checkbox`, réutilisé sur `/registre` et `/ma-carte`.
- `src/routes/ma-carte.tsx` : hero en `-mt-16 w-screen` comme `projets.index.tsx` ; remontée du bloc entremetteuse + `IntentionHeart` ; visibilité du bloc Organisateur pilotée par une liste de catégories « organisateur » ajoutée dans `src/lib/aime/universeTree.ts`.
- Nouveau visuel généré dans `src/assets/` (JPG), importé directement.
- `src/routes/projets.index.tsx` : hauteur du hero uniquement.
- Aucune modification de base de données ni de logique d'enregistrement.
