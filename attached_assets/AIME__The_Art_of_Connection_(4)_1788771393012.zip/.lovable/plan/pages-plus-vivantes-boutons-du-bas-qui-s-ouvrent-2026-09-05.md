# Pages plus vivantes, boutons du bas qui s'ouvrent

Suite du peaufinage. Rien de nouveau côté données : on réutilise ce qui existe déjà.

## 1. « Mes mondes » devient des cartes vidéo

À la place des petites pastilles, la section affiche les mêmes cartes vidéo que sur l'accueil (une vidéo par monde, qui se lance quand elle entre à l'écran). Au verso de chaque carte : ce qui s'affiche aujourd'hui — les personnes de ce monde, leur ville, et le lien « Voir sur la carte du réseau ». On garde deux ou trois cartes en ligne sur ordinateur, une sur téléphone.

## 2. « Ce que je fais » devient le passage vers les autres pages de la personne

Le métier reste écrit en une ligne, mais dessous on liste **les autres pages de la même personne** : son association, sa société, son lieu, son projet — chacune avec sa photo, son nom et ce qu'elle est. Un clic ouvre cette page. Les savoir-faire cliquables restent.

Si la personne n'a qu'une page, la section reste comme aujourd'hui.

## 3. Les boutons du bas s'ouvrent tous, comme « Ma page »

Chaque bouton de la barre du bas déplie un petit menu vers le haut, avec un aperçu vivant :

- **Documents** : les derniers documents déposés (nom, dossier, date), puis « Ouvrir les documents ».
- **Échanges** : les dernières conversations avec le début du dernier message et le point non lu, puis « Tout voir ».
- **Le fil** : les dernières notifications, puis « Aller au fil ».
- **Chercher** : les recherches récentes et quelques suggestions, puis le champ complet.
- **Mon espace** : la dernière notification et l'accès au panneau.
- **Radio** : choisir la station — Musique, Le fil raconté, ou Un projet raconté (avec la liste de mes projets).

Un clic simple sur le bouton fait ce qu'il faisait avant ; c'est le petit chevron/appui prolongé qui déplie. Sur téléphone, les menus restent lisibles et ne dépassent pas l'écran.

## 4. Suite du héros d'accueil

On termine ce qui restait :
- Le héros ne garde que **THE ART OF CONNECTION** et une barre blanche au design du Réseau, avec un seul bouton à la fois : Date → Ville/lieu → Budget → Nombre de personnes → Type de projet → Ouvrir mon projet. Chaque réponse reste en pastille à gauche, retour en arrière possible.
- Au clic sur « Ouvrir mon projet » : l'animation AI+ME (le « + » qui tourne, le « ME » qui blanchit jusqu'à 100 %), les étapes qui s'écrivent une par une, et à chaque information posée un picto qui file de la barre jusqu'à la ligne de temps.
- Puis le héros de projet contextuel (AVANT / PENDANT avec météo / APRÈS / Ce qui est relié, Play Jour J joué dans le héros) et le texte d'explication de la Veille.

## Détails techniques

- `CardIdentity.tsx` : « Mes mondes » réutilise le rendu de `UniverseVideoGrid` (extrait en tuile réutilisable avec `universeVideo`/`universePoster`), verso alimenté par le composant `Neighbours` existant ; « Ce que je fais » ajoute `myCardsQuery`-équivalent filtré sur `owner_id` de la carte affichée (autres cartes du même propriétaire, exclut la carte courante).
- `GlobalDock.tsx` : chaque bouton passe en `DropdownMenu` comme « Ma page », alimenté par les requêtes existantes (`bureau/queries` documents, `messaging` threads, `notifications`, `eventsQuery`) ; les actions actuelles (`onDocuments`, `onMessages`) restent sur l'entrée « Tout voir ».
- `RadioBar.tsx` : le bouton radio ouvre le même type de menu (modes + liste de projets via `eventsQuery`), la capsule reste dans l'en-tête.
- `HomeJourney.tsx` : barre séquentielle + écran de chargement AI+ME ; `ProjectStage.tsx` / `HeroTimeline.tsx` / `WeatherPanel.tsx` pour le héros de projet ; `ProjectPanels.tsx` pour la Veille.
- Vérification navigateur ordinateur + téléphone, puis contrôle des types.
