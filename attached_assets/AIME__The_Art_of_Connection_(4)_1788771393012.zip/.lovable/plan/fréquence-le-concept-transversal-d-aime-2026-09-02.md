# FRÉQUENCE — le concept transversal d'AIME

Mon retour d'abord, franchement : oui, « Fréquence » peut devenir le concept transversal, à une condition. Il ne faut **rien inventer de nouveau côté données**. Une Fréquence n'est pas un objet à créer, c'est une **lecture** de ce qui existe déjà : un Monde (carte, projet, lieu, bien, association, œuvre) + sa Timeline. Si on essaie d'en faire une table de « scores », on crée un deuxième système et on perd tout.

Le principe le plus simple, celui que je retiens :

```text
MONDE → TIMELINE → ÉVÉNEMENTS QUALIFIÉS → FRÉQUENCE (lecture) → RADIO → ANIMATRICE (récit)
```

La Fréquence n'est **jamais un score**. C'est : ce qui a bougé, quand, avec quelles preuves, et ce que ça change.

## Ce qui existe déjà et qu'on réutilise

- La page universelle `/carte/$id` avec ses modes (visuel, timeline, onglets, radio).
- La Timeline (`card_timeline_entries`) : la matière première des évolutions.
- La programmation MusicBox et le direct radio (à l'antenne, suivant, compte à rebours).
- L'animatrice IA : texte + voix, déjà générés et conservés.
- L'identité de fréquence par carte et son équipe.
- Le Bureau : factures, devis, documents analysés — c'est lui qui fournit les **preuves** (travaux, diagnostics, montants).

Donc la brique manquante n'est pas la donnée. C'est **la qualification d'un événement** et **le récit**.

## Le point critique : cote ≠ vérité

Je suis d'accord avec votre réserve, et je vais plus loin : AIME ne doit **jamais** afficher un chiffre unique présenté comme « la valeur ». Trois indicateurs distincts, toujours séparés visuellement :

- **Déclaré** — ce que le propriétaire affirme. Aucune preuve. Toujours étiqueté comme tel.
- **Documenté** — ce qui est adossé à une pièce dans le Bureau (facture, diagnostic, contrat). C'est le seul chiffre solide.
- **Estimé** — uniquement si une source externe existe (barème public, indice). Sinon : pas d'estimation du tout. Mieux vaut ne rien afficher qu'inventer une cotation.

Et un **niveau de confiance** attaché à chaque évolution, dérivé mécaniquement : preuve jointe > déclaration datée > déclaration simple.

Pour l'immobilier concrètement : AIME dit « 18 400 € de travaux documentés cette année, DPE passé de E à C » — pas « le bien vaut 247 000 € ». La valorisation reste une déduction de l'utilisateur, ou d'un professionnel. C'est la seule position tenable juridiquement.

## Le point le plus important : les personnes

Pour un Monde de type personne, **aucun indicateur chiffré. Jamais.** Pas de valeur, pas de score, pas de progression en pourcentage. La Fréquence d'une personne est uniquement **narrative** : ce qui a été ajouté, qui accompagne, quelle étape s'ouvre.

Trois garde-fous non négociables :

1. Le type de Monde détermine ce qui est autorisé. Personne = récit seul. Bien/projet/association = récit + indicateurs.
2. Consentement explicite et révocable pour toute diffusion à l'antenne d'une fréquence de personne. Par défaut : privée.
3. Retrait immédiat : couper la diffusion doit être un seul geste, sans supprimer les données.

C'est ce qui fait la différence entre mettre en lumière et exposer.

## Ce que je propose de construire, par étapes

### Étape 1 — Qualifier les évolutions (fondation)
Chaque entrée de Timeline peut porter un **effet** : ce qui a changé, dans quel sens, avec quelle preuve et quelle confiance. Rien d'obligatoire, rien d'automatique : les entrées existantes restent valides telles quelles.

### Étape 2 — La lecture « Fréquence » sur la page universelle
Un bandeau dans l'onglet Radio : *ce qui a bougé récemment*, *ce qui est en cours*, *ce qui arrive*. Les indicateurs (si le type de Monde les autorise) affichés séparés par nature, chacun avec sa mention Déclaré / Documenté / Estimé et son niveau de confiance.

### Étape 3 — L'animatrice explique
Un texte généré à partir **uniquement** des évolutions qualifiées, avec interdiction stricte d'extrapoler un chiffre non présent dans les données. Chaque phrase du récit reste rattachable à l'entrée qui l'a produite — c'est ça, la traçabilité du raisonnement. La voix existante lit ce texte.

### Étape 4 — Donner et recevoir
Les contributions (don, temps, compétence, objet, mise en relation) deviennent des entrées de Timeline comme les autres, et produisent donc des évolutions. La boucle contribution → action → évolution → récit se referme sans nouveau système.

### Étape 5 — Écouter une Fréquence
Un sélecteur « Quelle Fréquence veux-tu écouter ? » qui liste les Mondes dont la fréquence est publiée, tous types confondus. Les fréquences liées (personnes, lieux, associations d'un même projet) sont proposées à la suite — les liens existent déjà par les rattachements de cartes et de projets.

### Étape 6 — Les fréquences vivantes dans Le Monde AIME
Une fréquence active se signale dans la grille universelle, avec le même aperçu que les cartes.

## Détails techniques

- Une seule table nouvelle sur toute l'étape 1 : les effets d'évolution, rattachés à une entrée de Timeline (nature, sens, valeur optionnelle, unité, source `declare|documente|estime`, référence de pièce Bureau, confiance). GRANT explicites + RLS calquées sur `card_timeline_entries`.
- Aucune table de « score » et aucune valeur agrégée persistée : la Fréquence se **calcule à la lecture** à partir des entrées. Ça évite toute dérive vers une notation.
- Le type de Monde (`cards.kind`) pilote les indicateurs autorisés, via une table de règles côté code — personne et `evenement` sans indicateur financier.
- Récit : fonction serveur Gemini existante, prompt strictement borné aux effets fournis, aucune valeur inventée ; réponse mise en cache et rejouée par la voix déjà en place.
- Contributions : réutilisation du bouton cœur et du modèle d'entrée de Timeline, pas de nouvel écran.
- Consentement de diffusion : un champ sur l'identité de fréquence existante (`card_radios`), pas de nouvelle mécanique de permissions.

## Ordre de mise en œuvre

1. Effets d'évolution sur la Timeline + saisie depuis le bouton cœur.
2. Bandeau Fréquence dans l'onglet Radio, avec indicateurs séparés par nature et confiance.
3. Récit de l'animatrice, borné aux données, avec sources affichables.
4. Contributions et boucle donner/recevoir.
5. Sélecteur « Quelle Fréquence veux-tu écouter ? » et fréquences liées.
6. Fréquences vivantes dans Le Monde AIME.
