# Grand audit avant mise en ligne + page « Système nerveux » d'AIME

## 1. Ce que je vérifie avant d'affirmer quoi que ce soit

L'audit ne sera pas une liste d'impressions : chaque page (39 routes) sera ouverte réellement dans un navigateur, en 430 px et en 1280 px, connecté et déconnecté. Pour chacune je note : la page s'affiche, le hero est à la bonne hauteur, le champ/cœur fonctionne, les boutons font ce qu'ils annoncent, aucune erreur console, aucun lien mort.

Le résultat sera livré sous forme d'un tableau clair : **Fonctionne / Partiel / Ne fonctionne pas encore**, page par page, avec une phrase d'explication à chaque fois.

## 2. Doublons déjà confirmés (vérifiés dans le code)

- **Navigation en double source** : `src/lib/aime/navigation.ts` définit `PRIMARY_NAV`, mais la capsule de gauche utilise encore sa propre liste `NAV` dans `AppShell.tsx`. Deux listes à maintenir. → la capsule doit lire `PRIMARY_NAV`.
- **Lien périmé dans ME** : « À venir » pointe sur `/evenements`, qui n'est plus qu'une redirection 301 vers `/projets`. Même chose pour `/mon-evenement`. → pointer directement sur la destination réelle.
- **Création de devis écrite deux fois** : la même insertion existe dans `carte.$id.tsx` et dans `AimeButton.tsx`. → une seule fonction partagée.
- **Métadonnées manquantes** : certaines routes n'ont pas de `head()` (dont les redirections et une page secondaire) — à compléter avant partage public.

D'autres doublons seront ajoutés à la liste au fil de l'audit (heros locaux vs `PageHero`, requêtes dupliquées, libellés divergents entre capsule, burger et panneaux).

## 3. La page « Plan du système » — `/plan-du-site`

Une page publique qui montre AIME comme un organisme : les pages sont des nœuds, les relations sont des lignes en pointillés animées, la lumière circule du point de départ vers la destination.

Structure en cinq systèmes, comme le burger :

```text
DÉCOUVRIR ── Accueil ─ Annuaire ─ Carte réseau ─ Guides
FAIRE ────── Ma carte ─ Équipe ─ Projets ─ Bureau
ÉCHANGER ─── Messages ─ Aimes ─ Radio
MOI ──────── Tableau de bord ─ Crédits ─ Paramètres
COMPRENDRE ─ Comment ça marche ─ Visite 40 s ─ Bêta
```

Comportement :
- chaque nœud est cliquable et mène à la page réelle ;
- au survol d'un nœud, seules ses relations restent allumées, le reste s'estompe : on voit d'un coup « ce qui parle à quoi » (une carte alimente la timeline, la timeline produit un devis, le devis devient une facture au Bureau, la facture nourrit le budget du projet) ;
- les lignes pointillées s'animent en continu, dans le sens du flux ;
- une pastille d'état par nœud : **actif** / **en cours** / **à venir**, ce qui te donne l'avancement réel du site en un écran ;
- version mobile : mêmes systèmes empilés verticalement, lignes verticales animées ;
- respecte `prefers-reduced-motion` (animations coupées).

## 4. Le menu sous le logo AIME

Cliquer sur « AIME » dans le header ouvre un petit menu (le clic long / la flèche ; le logo reste un retour à l'accueil sur mobile via le burger). Entrées proposées :

- **Plan du système** — la nouvelle page
- **Comment ça marche** — les 6 chapitres
- **Visite en 40 secondes** — lance la présentation depuis n'importe où
- **Programme bêta & retours** — la page où les testeurs commentent et où tu vois les remarques remontées
- **Guides locaux**
- **Mentions légales & confidentialité**

C'est le bon endroit pour ces pages : ce sont des pages « à propos du site », pas des pages d'action — elles n'ont donc leur place ni dans **+** (créer), ni dans **ME** (ce qui m'appartient), ni dans la capsule (parcours quotidien).

## 5. Livraison

1. Audit complet des 39 routes, rendu en trois listes : fonctionne / partiel / ne fonctionne pas.
2. Liste des doublons et sources de vérité à unifier, avec les corrections évidentes appliquées (navigation, liens périmés, devis).
3. Page `/plan-du-site` avec les relations animées.
4. Menu sous le logo AIME.

## Détails techniques

Audit via Playwright : parcours scripté des routes, capture des erreurs console, des réponses HTTP et des liens `href` morts, en deux tailles d'écran. Nouvelle route `src/routes/plan-du-site.tsx` avec `head()` propre ; le graphe est décrit dans une constante partagée dérivée de `src/lib/aime/navigation.ts` (nœuds + arêtes typées), rendu en SVG avec `stroke-dasharray` animé et surbrillance au survol via état React ; aucun ajout de dépendance, aucune modification de base de données. Nouveau `LogoMenu.tsx` (Popover) dans `AppShell.tsx`. Corrections de doublons : capsule branchée sur `PRIMARY_NAV`, liens `/evenements` remplacés, insertion de devis extraite dans `src/lib/aime/quotes.ts`.
