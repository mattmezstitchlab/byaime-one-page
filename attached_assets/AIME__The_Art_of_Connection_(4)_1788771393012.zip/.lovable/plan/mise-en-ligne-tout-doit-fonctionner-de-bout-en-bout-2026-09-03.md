# Mise en ligne : tout doit fonctionner de bout en bout

Audit réel effectué à l'instant (types, linter, 32 pages en HTTP, rendu navigateur public **et connecté**, base de données, scan de sécurité). Voici ce qui est sain, ce qui est cassé, et ce que je corrige.

## Ce qui est déjà sain

- Types : aucune erreur.
- 32 pages testées : toutes répondent (200 ou redirection voulue). Aucune erreur JavaScript, aucune erreur réseau, aucun débordement horizontal sur les 12 pages rendues en navigateur.
- Parcours connecté : Accueil, Ma page, Réseau, Paramètres, Messages, Bureau, Projets, Saisons, Crédits, Aimes reçues, Cockpit s'affichent sans erreur.
- Sécurité : aucun finding ouvert. Toutes les tables ont RLS activée et des règles.

## Anomalies bloquantes (vérifiées, pas supposées)

### 1. Chaque visite crée une nouvelle page en double — le plus grave

Votre compte possède aujourd'hui **3 pages** au lieu d'une. Deux ont été créées pendant mon test, à 34 secondes d'intervalle, simplement en ouvrant « Ma page » deux fois. L'ouverture lance la création avant que la recherche de la page existante ait répondu ; elle croit donc qu'il n'y en a pas.

Correction : attendre que la recherche soit terminée avant toute création, revérifier juste avant l'insertion, sérialiser l'appel, et fusionner les doublons déjà créés en gardant la plus ancienne page.

### 2. La table des profils est inaccessible à l'application

`profiles` n'a **aucun droit d'accès accordé** : chaque lecture ou écriture de profil échoue en « permission refusée », malgré des règles correctes. Cela touche les réglages, le chat, l'affichage des noms et la diffusion radio. La table est d'ailleurs vide (0 ligne) alors qu'un compte existe.

Correction : accorder les droits nécessaires et garantir la création du profil à la première connexion.

### 3. Adresse du site erronée pour Google et les partages

Le plan de site et le fichier robots annoncent `lemondeaime.lovable.app`, qui n'est pas l'adresse du site. Toutes les URLs soumises aux moteurs sont donc fausses.

Correction : basculer sur `https://byaime.fr` (avec `aime-network.lovable.app` en secours) partout : plan de site, robots, liens canoniques, images de partage.

### 4. 11 pages sans titre ni description propres

Elles héritent du texte générique : `carte/$id/timeline`, `devis/$cardId`, `evenement/$`, `projets/nouveau`, `rencontres`, `monde`, `registre`, `evenements`, `tableau-de-bord`, `ma-carte`, la page de consentement. Les pages publiques partagées (page d'une personne, devis, événement) doivent avoir leur propre titre, description et image.

### 5. La version de production n'a jamais été construite ni testée

Le site tourne en développement. Certaines incompatibilités du moteur de production n'apparaissent qu'à la construction. Non négociable avant mise en ligne : construire, servir la version de production, et rejouer le parcours complet dessus.

## Anomalies non bloquantes traitées dans la foulée

- 4 218 remontées du linter, dont 4 191 de simple mise en forme : correction automatique en un passage.
- 24 types `any` et 5 dépendances de hooks incomplètes (dont `CardsMap`, `HeroTimeline`) : corrigés à la main.
- Avertissements « inputValidator est déprécié » sur 25 fonctions serveur : renommage en `validator`.

## Plan d'exécution

1. **Unicité de la page** : correction de l'ouverture, fusion des doublons existants, vérification par double ouverture successive.
2. **Droits sur les profils** + création automatique du profil à la connexion.
3. **Parcours connecté complet, écriture comprise** : créer sa page, la compléter, publier, poser un repère de timeline, envoyer un Aime, écrire un message, créer un projet, déposer un document au Bureau, demander un devis, se déconnecter. Chaque échec est corrigé avant de passer au suivant.
4. **Adresse du site, plan de site, robots, métadonnées** des 11 pages manquantes.
5. **Nettoyage linter et avertissements serveur.**
6. **Construction de production + rejeu du parcours** sur la version construite, y compris en mobile 390 px.
7. **Rapport final** : liste des points vérifiés et de ce qui reste hors périmètre.

## Détails techniques

`useMyPage.open()` doit attendre `isFetched` de `myCardQuery`, refaire un `select` `owner_id` trié par `created_at` juste avant l'`insert`, et être protégé par un verrou de module (pas seulement `useState`) car deux routes le montent. Fusion des doublons par migration : conserver la carte la plus ancienne par `owner_id`, réaffecter les lignes liées (`card_timeline_entries`, `aimes`, `events`, `compositions`, `quotes`) puis supprimer les brouillons vides. `GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated; GRANT SELECT ON public.profiles TO anon; GRANT ALL TO service_role` en cohérence avec les trois règles existantes ; profil créé côté client à la première connexion (aucun trigger sur le schéma `auth`). `SITE_URL` dans `src/lib/aime/seo.ts` et `public/robots.txt` passent sur `https://byaime.fr`. Aucune règle RLS existante, aucun finding de sécurité, aucun avertissement `SECURITY DEFINER` et `geo.ts` ne sont touchés.
