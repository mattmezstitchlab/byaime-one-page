# Le cœur devient la seule porte d'entrée

Aujourd'hui il y a deux façons d'ajouter quelque chose : le bouton rouge « + » en bas de l'écran, qui demande de choisir soi-même entre « une carte », « un projet », « une intention publique », « un document », « une invitation » — et le cœur posé sur la ligne de temps, qui parle déjà avec l'agent. On supprime la première et on généralise la seconde.

## 1. Le « + » disparaît

- Le bouton rouge flottant en bas est retiré de toutes les pages.
- Le panneau qu'il ouvrait (« une carte », « un projet », « une intention publique », « un document », « une invitation ») est retiré de l'expérience : ces cinq entrées de création manuelle n'existent plus.
- Le Studio (accessible par « Modifier » et par la redirection quand une page est incomplète) garde ses réglages et l'édition de la page personnelle, mais perd son onglet « + ».
- Les formulaires eux-mêmes (projet, intention, dépôt de document, invitation) restent en place là où ils vivent déjà — page de projet, page d'invitation, Bureau — ils cessent seulement d'être proposés comme un menu de création.

## 2. Le cœur : « je donne quelque chose à AIME »

Le cœur déjà présent au centre de la ligne de temps devient le seul bouton d'ajout, clairement identifié « AIME ». Il ouvre l'agent du projet — pas une fenêtre de discussion neutre : l'agent connaît déjà le projet, la ligne de temps, les personnes, les prestataires, les documents, l'argent, les échéances et les liens entre eux (c'est déjà le cas pour les questions).

Une seule zone : « Que souhaitez-vous ajouter ou demander à AIME ? » avec, à côté du champ, trois gestes — joindre un fichier, prendre une photo, coller du texte. Aucune question du type « voulez-vous créer un document ? ».

## 3. Ce qui se passe quand on dépose un document

On réutilise strictement le moteur du Bureau, qui sait déjà lire un PDF ou une photo, en extraire le type, l'émetteur, les montants, la TVA, les dates et l'échéance, puis proposer un classement. Aucun deuxième moteur de lecture n'est créé.

Après lecture, le cœur affiche une confirmation lisible :

```text
J'ai reconnu ce document
Devis — Coiffure & maquillage
Prestataire : Salon Ondine
Montant : 600 €   Acompte : 300 €   Date : 29 janvier
À ajouter dans : Documents · Prestataires · Finance · Ligne de temps
[ Ajouter au projet ]   [ Modifier ]
```

Rien n'est enregistré avant ce clic. Les champs incertains sont signalés et modifiables.

## 4. Une seule information, qui se propage

À la validation, on écrit **un seul** ensemble relié dans le modèle du projet : le document, le prestataire reconnu, l'engagement financier et ses échéances, et les repères correspondants sur la ligne de temps — tous liés entre eux. Les vues Documents, Finance, Prestataires et Avant ne stockent rien : elles lisent ce même modèle. L'agent peut ensuite répondre à « Combien dois-je encore au traiteur ? ».

## 5. Le contexte compte

Si l'on ouvre le cœur alors qu'on regarde « Photographe — 12 septembre », ou une période comme avril 2027, l'agent en tient compte et propose le rattachement (« ce document semble concerner le photographe »). Une proposition, jamais une décision automatique.

## 6. Répondre et montrer

Quand une réponse cite un élément précis, l'agent propose « Voir dans la ligne de temps » : le panneau se referme, la ligne se positionne sur l'élément et le met en évidence.

## Détails techniques

- Suppression : `src/components/aime/AimeBar.tsx`, `src/components/aime/CreateOverlay.tsx`, `src/components/aime/createEntries.tsx`, l'onglet `creer` de `src/components/aime/studio/Studio.tsx`, et leur montage dans `src/components/aime/AppShell.tsx`. `openStudio("me")` reste utilisé par `useMyPage.ts` et par « Modifier ».
- Nouveau composant partagé `src/components/aime/heart/HeartAgent.tsx` : le panneau du cœur (question + dépôt + proposition + validation), monté sur la page projet et sur `/demo/mariage`, avec le contexte courant (repère survolé/épinglé, fenêtre de temps).
- Lecture documentaire : réutilisation de `ingestFile` / `analyzeDocument` (`src/lib/bureau/ingest.ts`, `src/lib/bureau/documents.functions.ts`) — aucune nouvelle fonction d'extraction. `analyzeDocument` exige une session : sur la démo publique, la lecture est proposée aux personnes connectées, sinon un message clair invite à se connecter (la démo reste consultable).
- Injection : nouvelle fonction `src/lib/aime/world/ingestToProject.ts` qui transforme une `DocumentExtraction` en objets du `WorldProject` (document + prestataire + `PaymentCommitment` + repères), puis écrit via `projectPersistence.ts` / `card_timeline_entries` déjà en place. `derive.ts` continue de projeter la ligne de temps ; aucune donnée dupliquée dans les vues.
- Agent : `src/lib/aime/timelineAsk.functions.ts` conserve son rôle (réponse + calques + cadrage + cibles) et alimente « Voir dans la ligne de temps ».
- Hors périmètre : `/bureau` et les fonctions `SECURITY DEFINER` ne sont pas touchés.

## Vérifications

Le « + » n'existe plus nulle part ; les cinq anciennes entrées ne sont plus accessibles ; le cœur est le seul bouton d'ajout ; il accepte un texte, un fichier et une photo ; un devis photographié produit une proposition juste ; la validation fait apparaître l'information sur la ligne de temps et dans Documents, Finance et Prestataires ; l'agent répond ensuite à une question sur ce document et sait le retrouver sur la ligne de temps.
