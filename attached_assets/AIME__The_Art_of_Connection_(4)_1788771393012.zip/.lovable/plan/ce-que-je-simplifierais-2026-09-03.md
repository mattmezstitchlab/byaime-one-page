# Ce que je simplifierais

L'application tient aujourd'hui sur 57 fichiers de routes, trois systèmes de navigation superposés (menu logo, dock AI/+/ME, barre mobile + radio) et plusieurs pages qui racontent la même chose. Voici les quatre simplifications qui feraient le plus de bien, de la plus utile à la moins urgente.

## 1. Réduire le nombre de pages

Certaines pages ne sont atteignables que par le plan du site : `/registre` et `/evenements` n'ont aucun lien entrant, `/chemin`, `/intermittent` et `/tableau-de-bord` n'en ont qu'un seul. D'autres sont de simples redirections empilées : `/monde`, `/profil`, `/ma-carte`, `/rencontres` renvoient toutes vers `/reseau` ou vers la page personnelle.

Proposition :
- Garder les redirections courtes (elles protègent les anciens liens), mais les sortir du plan du site et du sitemap pour qu'elles cessent d'apparaître comme des destinations.
- Fusionner `/objectif`, `/chemin`, `/entraide` et `/communs` en une seule page « Entraide » à deux onglets, plutôt que quatre pages de ~200 lignes qui partagent la même grammaire.
- Fusionner `/tableau-de-bord` et `/cockpit` : même intention (voir l'état), l'un est déjà une coquille de 12 lignes.

Résultat visé : passer d'environ 40 destinations réelles à une vingtaine, toutes atteignables en deux clics.

## 2. Une seule barre du bas

Sur téléphone il y a la barre AI · + · ME · Radio · Cœur ; sur ordinateur le dock AI · + · ME plus la barre radio. Deux composants à maintenir pour la même grammaire.

Proposition : un composant unique, la même liste d'actions, la mise en page seule change selon la largeur. La radio devient une entrée du panneau AI plutôt qu'un bouton permanent.

## 3. Alléger le menu « + »

Dix entrées de création, dont plusieurs mènent au même endroit avec un paramètre différent. Je descendrais à cinq : une carte, un projet, une intention publique, un document, une invitation. Les autres (moment de timeline, contribution, annonce radio) appartiennent naturellement à la page où elles se créent — on les y trouve déjà.

## 4. Découper les trois plus gros fichiers

`HeroTimeline` (944 lignes), `AimeButton` (727), `RadioBar` (704) et `IntentionHeart` (682) concentrent la plupart des régressions. Je les découperais par responsabilité, sans changer une ligne de comportement visible.

## Détails techniques

- Fusions de pages : conserver les anciens chemins avec un `redirect()` dans le loader, mettre à jour `plan-du-site.tsx` et `sitemap[.]xml.ts`, retirer les entrées mortes.
- Barre unique : fusionner `AimeDock.tsx` et `MobileBottomBar.tsx` en un `AimeBar.tsx` consommant `CREATE_ENTRIES`, avec variantes Tailwind `md:`.
- Menu « + » : réduire `CREATE_ENTRIES`; les paramètres `?creer=` déjà câblés restent valides pour les liens existants.
- Découpage : extraction de sous-composants dans un dossier voisin, aucune modification de logique métier ni de requêtes.

## Ordre proposé

1. Barre unique du bas et menu « + » allégé (visible immédiatement, faible risque).
2. Fusion des pages et nettoyage du plan du site.
3. Découpage des gros composants.

Dites-moi lesquels de ces quatre points vous voulez, et dans quel ordre — je peux aussi n'en faire qu'un.
