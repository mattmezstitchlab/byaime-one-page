# Mémoire & Héritage — l'arbre des origines

Objectif : relier ce qui existe déjà (page personne, ligne de temps, mémoire web, documents, médias) au lieu d'ajouter une page « généalogie » séparée. Une personne, ses origines, ses traces, et ce qu'elle choisit de transmettre.

## A — Ce qui existe déjà (audité)

- **Page personne** : une seule page par carte, avec des onglets (présentation, savoir-faire, expériences, calendrier, ligne de temps, radio, contact, projets…).
- **Certitude** : les références d'une personne portent déjà trois niveaux — déclaré, documenté, interprété — affichés dans le panneau Mémoire.
- **Mémoire web** : le parcours complet existe déjà — chercher, trouver, expliquer (période, lieu, personnes, confiance), valider à la main, puis créer un moment dans la ligne de temps. Rien n'est ajouté automatiquement.
- **Ligne de temps** : les moments acceptent un titre, une date, un lieu, une visibilité publique ou privée, et gardent la trace de leur source.
- **Liens** : il existe un système de liens générique entre objets (utilisé aujourd'hui pour devis → facture → paiement), réutilisable comme squelette.
- **Médias et documents** : photos/vidéos rattachées à une personne, documents importés côté bureau.

## B — Ce qui manque vraiment (minimum)

1. Naissance et décès : aucune date ni lieu de naissance nulle part aujourd'hui.
2. Un lien de parenté typé (parent, enfant, fratrie, conjoint) entre deux personnes, avec son niveau de certitude et sa source.
3. Cinq niveaux de certitude au lieu de trois : confirmé, documenté, hypothèse, à clarifier, inféré.
4. Un rendu en arbre (rien d'arborescent n'existe, seulement des frises).

Tout le reste est réutilisé : pas de duplication des personnes, des médias, des documents ni des moments.

## C — Principe de non-duplication

Une personne de l'arbre est **une carte** (celle qui existe déjà, ou une carte minimale « personne » non publiée pour un aïeul). Un souvenir familial est **un moment de la ligne de temps**. Une preuve est **une référence ou un document existant**. L'arbre n'est qu'une lecture verticale de ces mêmes données.

## D — MVP proposé

1. **Onglet « Origines »** sur la page personne (pas dans le hero, pas de nouvelle page isolée).
2. **Fiche naissance** : date, ville, pays — saisis par la personne. Chaque champ porte son niveau de certitude.
3. **Arbre structurel** : deux parents et quatre grands-parents toujours affichés, même sans identité. Trois états visuels immédiatement lisibles :
   - plein = personne connue (mène à sa page) ;
   - demi = hypothèse (« voir pourquoi ») ;
   - vide = place attendue, identité inconnue (« rechercher des traces »).
4. **Pourquoi AIME sait / suppose** : chaque lien ouvre un encart listant les éléments (source identifiable, période cohérente, lieu cohérent, identité non confirmée). Jamais de note unique en pourcentage.
5. **Pistes** : le moteur de mémoire web déjà en place est branché sur un emplacement vide ; il propose des pistes avec source et correspondances, à examiner puis accepter ou écarter. Aucune relation n'est enregistrée sans validation humaine.
6. **Ce qui reste à découvrir** : une liste courte des trous identifiés (branche non documentée, période peu renseignée, lieu sans archive, personne mentionnée non reliée).
7. **Vie privée** : chaque lien a sa visibilité (privé par défaut). Une personne vivante n'est jamais rendue publique sans son accord ; une branche peut rester privée ; une hypothèse peut être refusée ou supprimée.

## E — Ensuite (pas dans ce lot)

- **Héritage** : un onglet où l'on désigne ce qui se transmet (une photo, une lettre, une voix, une œuvre, un lieu) et à qui, en réutilisant les moments et médias existants.
- **Croisement avec la ligne de temps** : voir les naissances des générations sur le même axe temporel que sa propre histoire.
- **Croisement avec Rencontres** : « nos histoires se croisent » gagne un axe familial et géographique ancien.
- **Fusion de doublons** quand deux cartes désignent la même personne.

## F — Détails techniques

- Nouvelle table `family_links` : `from_card_id`, `to_card_id`, `relation` (parent | enfant | fratrie | conjoint), `certainty` (confirme | documente | hypothese | a_clarifier | infere), `visibility` (private | shared | public), `note`, `source_ref_id`, `evidence` (jsonb : liste des éléments expliqués), `created_by`. Contraintes CHECK sur `relation` et `certainty`, `from <> to`, unicité (from, to, relation). GRANT explicites puis RLS : lecture par le propriétaire de l'une des deux cartes ou si `visibility = 'public'` ; écriture réservée au propriétaire de la carte d'origine. Pas de SECURITY DEFINER nouveau.
- Nouvelle table `card_identity` (1-1 avec `cards`) : `card_id`, `born_on`, `born_precision` (jour | mois | annee), `birth_city`, `birth_country`, `died_on`, `death_city`, `certainty` par champ (jsonb), `visibility`. Pas de colonnes ajoutées à `cards` pour éviter d'élargir sa lecture publique.
- Niveaux de certitude unifiés dans `src/lib/aime/memory/certainty.ts` ; les trois niveaux existants des références y sont mappés sans migration destructive.
- Pistes généalogiques : réutilisation du flux mémoire web existant, avec un `kind` dédié (`genealogie`) et le contexte du lien visé dans `metadata` ; l'acceptation crée le lien de parenté (et une carte personne minimale si nécessaire) plutôt qu'un moment.
- Nouveaux composants sous `src/components/aime/origins/` : `OriginsPanel`, `OriginsTree` (rendu SVG générationnel), `LinkEvidence`, `OpenQuestions`, `IdentityForm`. Onglet ajouté à `CardTabs`, aucune modification du hero.
- Aucune route `/bureau` touchée ; conventions de style existantes (`AimeCard`, hairline, tracking majuscule) conservées.
