# La ligne de temps qui se lit d'un coup d'œil

Une seule page mariage, une seule ligne de temps, des pictogrammes qui disent immédiatement de quoi il s'agit, et un agent qui sait où regarder. Aucune nouvelle page n'est créée.

## 1. Supprimer les ronds avec des chiffres

Aujourd'hui, quand plusieurs repères se retrouvent au même endroit, la ligne de temps affiche un rond blanc avec « 3 », « 8 », « 11 ». On ne sait pas ce que c'est.

À la place : un petit groupe de pictogrammes empilés (jusqu'à trois, les natures les plus présentes), avec un léger « +2 » discret seulement s'il en reste. Le chiffre ne remplace plus l'information, il la complète.

Les chiffres restent partout où ils comptent vraiment : 148 invités, 600 photos, 3 éléments à confirmer.

## 2. Un pictogramme par nature, et un état visible

Chaque repère porte déjà une icône. On complète la bibliothèque pour que chaque nature du mariage ait la sienne : lieu, prestataire, photographe, vidéaste, contrat, devis, facture, paiement, échéance, tâche, rendez-vous, musique, photo, vidéo, message, transport, hébergement, repas, cérémonie, invités, alerte, suggestion.

Sur chaque pictogramme, une pastille d'état très sobre : confirmé, à faire, en attente, bloqué, suggestion, terminé. Une seule couleur d'accent, rien de criard. Trois réponses immédiates : quoi, quand, dans quel état.

## 3. Le survol et le clic racontent tout

Au survol : nature, titre, date, état.
Au clic : une carte détaillée qui montre tout ce qui est relié à cet élément — le prestataire, son contrat, son paiement, sa présence dans la journée, ses photos — avec les actions Voir, Demander à AIME, Lire (Play).

## 4. L'agent comprend la ligne de temps

Le champ au cœur de la page devient un vrai agent. On lui écrit n'importe quelle question :
« Qu'est-ce que j'ai oublié ? », « Combien me reste-t-il à payer ? », « Où en est le photographe ? », « Montre-moi les paiements des trois prochains mois. »

Il lit le projet réel (personnes, prestataires, documents, montants, échéances, moments, médias) et répond avec des chiffres justes. Puis il agit sur l'écran : il positionne la ligne de temps sur la bonne période, active les bons calques, met en évidence l'élément dont il parle, avec un bouton « Voir dans la ligne de temps ». Il tient compte de l'endroit où l'on se trouve déjà dans le temps.

Les suggestions d'AIME (ce qui manque : musique, fleuriste, transport, hébergement, plan B météo) apparaissent comme des repères « suggestion » sur la ligne, pas comme une liste à part.

## 5. Ce qui ne change pas

La page d'accueil reste un seul champ « Décrivez votre mariage » puis « Créer ma timeline ». Le Studio reste tel quel. Avant / Pendant / Après restent des fenêtres sur la même ligne de temps. Les métiers restent des univers du même moteur, pas des pages séparées. Rien n'est saisi deux fois.

## Détails techniques

- `src/components/aime/HeroTimeline.tsx` : remplacer le rendu `kind === "dossier"` (pastille chiffrée) par une grappe de pictogrammes issus de `KIND_ICON` des enfants ; étendre `KIND_ICON` et ajouter un `ROLE_ICON` (photographe, traiteur, transport, hébergement…) résolu depuis `metadata`/`providerId` ; harmoniser `STATUS_RING` en une pastille d'état unique.
- `src/lib/aime/world/derive.ts` : porter le rôle du prestataire et l'état dans `metadata` du repère pour que l'icône soit choisie sans nouvelle source de données.
- Carte détaillée : un composant `TimelineDetail` alimenté par `relatedIds` + le `WorldProject`, ouvert au clic dans `HeroTimeline` (pas de nouvelle route).
- Agent : nouveau `src/lib/aime/timelineAsk.functions.ts` (`createServerFn`, Responses API, `openai/gpt-5.6-sol`) recevant un résumé compact du projet et la fenêtre temporelle courante, renvoyant `{ reponse, calques, focus, cibles[] }`. `demo.mariage.tsx` applique `calques`/`focus` et met en avant les `cibles`. Pas de duplication : le résumé est dérivé de `deriveTimeline`/`financeOf`.
- Périmètre : `/bureau` et les fonctions protégées de la base ne sont pas touchés.
