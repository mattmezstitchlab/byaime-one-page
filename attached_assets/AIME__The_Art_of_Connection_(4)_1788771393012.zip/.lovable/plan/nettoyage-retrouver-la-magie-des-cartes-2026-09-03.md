# Nettoyage : retrouver la magie des cartes

Trois retraits, aucune nouvelle mécanique. L'objectif : on regarde une carte, on ouvre sa page. Rien à cocher, rien à composer, rien à comprendre.

## 1. Le verso des cartes utilisateur redevient une présentation

Aujourd'hui le verso ouvre une console à tuiles AI · Actions · ME, avec sous-écrans et liens vers Projets, Bureau, Messages. C'est un tableau de bord posé sur une carte.

Nouveau verso, en une seule vue :
- le nom et la catégorie ;
- une présentation courte ;
- quelques lignes simples : ville, savoir-faire, note et avis, budget indicatif, disponibilité ;
- un seul bouton : « Voir la page ».

Plus de tuiles, plus de panneaux AI/ME depuis la carte. Les panneaux restent accessibles là où ils vivent déjà (dock, tableau de bord).

## 2. Le verso des cartes mondes redevient une découverte

Aujourd'hui : cliquer une entrée déplie une liste de cases à cocher, une question, des visages à retenir, un compteur, puis « Ajouter à la composition ».

Nouveau verso :
- la liste des entrées du monde, comme avant, animée ;
- cliquer une entrée montre directement quelques visages correspondants (vignettes rondes) ;
- cliquer un visage ouvre la carte en superposition, sans quitter l'accueil ;
- un lien discret « Tout voir » qui mène au Réseau filtré sur ce monde et cette entrée.

Disparaissent : les cases de domaines, la question, la retenue, le compteur, le bouton « Ajouter à la composition ».

## 3. Le principe des bisous disparaît

Retirés partout : la page `/bisous`, l'empreinte dans le panneau ME, l'empreinte proposée comme photo dans Ma carte, le bisou et l'invitation par bisou sur Identity, les entrées correspondantes dans Monde, le plan du site et le système nerveux. Identity reste comme page de film et d'invitation simple, sans geste de bisou.

## 4. Le principe de composer disparaît de l'interface

Plus de « composition » proposée nulle part : ni sur les versos, ni dans les menus, ni dans la barre de création. Les pages qui n'existaient que pour ça (Rencontres/compositions) sortent de la navigation et redirigent vers le Réseau. Rien n'est supprimé en base : les données restent, elles ne sont simplement plus exposées.

## Détails techniques

- `src/components/aime/panels/CardConsole.tsx` remplacé par un résumé + un `Link` vers `/carte/$id` ; `AimeCard.tsx` adapté.
- `src/components/aime/UniverseVideoGrid.tsx` : suppression de `openSubs`/`domains`/`retained`/`picking` ; une seule entrée ouverte, vignettes + « Tout voir ».
- `ExplorationPanel.tsx` réduit aux vignettes ; `CompositionPicker.tsx`, `domains.ts` et `taxonomy.ts` retirés de la chaîne d'import (fichiers supprimés s'ils ne servent plus ailleurs).
- Suppression de `src/routes/bisous.tsx` et `src/lib/aime/kiss.ts` ; nettoyage dans `ma-carte.tsx`, `MePanel.tsx`, `identity.tsx`, `monde.tsx`, `plan-du-site`, `systemMap.ts`, `comment-ca-marche.tsx`, `beta.tsx`, `index.tsx`.
- Navigation : retrait des entrées composition/rencontres dans `src/lib/aime/navigation.ts`, `createEntries.tsx`, `AimeDock.tsx`, `MobileMenu.tsx` ; `/rencontres` redirige vers `/reseau`.
- Aucune migration, aucun changement de sécurité. Vérification : typecheck puis parcours réel de l'accueil, d'un verso de monde et d'un verso de carte.
