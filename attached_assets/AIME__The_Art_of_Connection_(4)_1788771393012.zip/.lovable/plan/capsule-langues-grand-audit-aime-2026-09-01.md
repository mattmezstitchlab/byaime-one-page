# Capsule langues + grand audit AIME

## 1. Le menu des langues devient une capsule dépliante

Aujourd'hui le bouton `FR` de la capsule noire ouvre un panneau blanc carré, détaché, qui flotte à côté (voir capture). Il casse la continuité de la capsule.

À la place :
- Au clic sur `FR`, la capsule noire **s'allonge vers le bas** : les langues apparaissent dans le même cylindre noir, même largeur, même arrondi, sans carte blanche.
- Chaque langue = une pastille ronde de 40 px avec son code (`FR`, `EN`, `ES`, `DE`, `IT`), la langue active en pastille blanche sur fond noir, les autres en blanc translucide.
- Ouverture/fermeture animées (hauteur + opacité), fermeture au second clic, à la sélection, à l'`Échap` ou au clic à l'extérieur.
- Le drapeau et le libellé complet restent en info-bulle pour rester lisibles.
- Dans le footer noir, le menu langue garde son comportement actuel (liste), inchangé.

Technique : nouveau mode `variant="capsule"` dans `src/components/aime/LanguageMenu.tsx` (état local + `motion/react` au lieu du `Popover`), utilisé par `src/components/aime/AppShell.tsx`.

---

## 2. Audit réel de l'application

### Ce qui marche parfaitement (à ne pas toucher)

- **La Carte** (`/carte/$id`, `AimeCard`) : recto/verso, hero immersif, timeline, cœur d'intention. C'est l'objet identitaire du site, unique sur le marché.
- **Le cœur AIME** à intentions multiples : une seule grammaire d'action partout (aimer, contacter, réserver, associer). Cohérent et compris tout de suite.
- **Le Bureau** (`/bureau`) : arborescence, lecture automatique des factures, rapprochement devis → facture → paiement, export comptable. Réellement différenciant.
- **Le registre + guides SEO** (`/registre`, `/guides/$metier/$ville`, `sitemap.xml`) : la porte d'entrée gratuite du trafic.
- **Les univers vidéo de l'accueil** : la meilleure première impression du site.
- **Messages** (cockpit, copilote, traduction) : très complet.

### Ce qui est inutile, redondant ou coûteux

| Sujet | Constat | Décision proposée |
|---|---|---|
| Redirections en cascade | `/mon-evenement` → `/projets/nouveau` → `/projets?nouveau=1` : deux sauts | Rediriger directement vers `/projets?nouveau=1` |
| Anciennes routes | `/evenements`, `/evenement/$`, `/mon-evenement` ne sont plus que des redirections | Les garder 6 mois pour le SEO, puis supprimer |
| Nav principale | 5 entrées dont « Intermittents », très spécialisée | Passer « Intermittents » dans un sous-menu de « Composer » |
| Doublon d'entrée IA | Un champ de saisie sur l'accueil et un sur `/rencontres` | Garder les deux mais l'accueil ne fait qu'amorcer et renvoie vers Composer |
| Radio | Fonctionnalités très riches (prompteur, partition, karaoké) pour un usage encore nul | Réduire à Écouter + Programme, garder le reste en mode « studio » réservé aux cartes actives |
| Pages énormes | `ma-carte` (1177 lignes), `messages` (938), `tableau-de-bord` (674) | Découper en sous-composants : lisibilité et vitesse |
| Crédits IA | Une page complète alors que peu de monde paie encore | La replier dans le tableau de bord tant que le volume est faible |
| Deux vocabulaires | « Composer », « Rencontres », « Réseau » désignent des choses proches | Un mot par page : Réseau (carte), Composer (l'IA), Registre (annuaire) |
| Mobile | La capsule gauche + la barre du bas se superposent sur petit écran | Sur mobile, capsule masquée, tout dans la barre du bas |

### Ce qui manque et bloque l'usage réel

1. **La réclamation de carte à grande échelle** : des milliers de fiches existent sans propriétaire. Sans campagne d'e-mails de revendication, l'annuaire reste un décor.
2. **La preuve sociale** : très peu d'avis affichés. Une carte sans avis ne convertit pas.
3. **Le premier message** : rien ne pousse un visiteur à envoyer sa première intention (pas de relance, pas de garantie de réponse).
4. **Le mobile** : le site est pensé desktop, alors que les mariés cherchent au téléphone, le soir.

---

## 3. Innovations proposées, et pourquoi elles peuvent marcher

### a. La Timeline vivante d'un prestataire, publique
Chaque carte montre son passé (souvenirs, événements réalisés) et son futur (dates libres). **Pourquoi ça marche** : aujourd'hui la question n°1 est « êtes-vous libre le 12 juin ? ». Répondre avant même la question supprime 80 % des échanges morts.

### b. La réservation de date en un geste, avec option gratuite 48 h
**Pourquoi** : le secteur fonctionne encore au devis papier et au téléphone. Poser une option sans engagement rassure les deux côtés.

### c. Le Bureau comme raison de revenir
Facture lue automatiquement, dossier qui se complète, export comptable. **Pourquoi** : les prestataires ne reviennent pas pour être « visibles », ils reviennent pour être payés et pour leur comptabilité.

### d. L'entremetteuse qui compose une équipe entière
Un texte → une équipe cohérente (lieu, traiteur, musique) déjà disponible aux mêmes dates. **Pourquoi** : personne ne vend l'événement comme un tout, seulement des prestataires isolés.

### e. Les éphémères (photos/vidéos 6 h)
**Pourquoi** : un prestataire n'a pas le temps d'écrire une fiche, mais il filme déjà ses prestations. Le contenu frais coûte zéro effort.

### f. La messagerie traduite en direct
**Pourquoi** : débloque le mariage international et les tournées.

---

## 4. Pourquoi la France d'abord

- **Les intermittents du spectacle** : 507 heures, cachets, GUSO. C'est une spécificité 100 % française, aucune plateforme mondiale ne la traitera jamais. C'est un fossé défensif.
- **La facturation électronique obligatoire** (réforme en cours pour les entreprises françaises) : le Bureau devient une nécessité, pas un confort.
- **Le marché du mariage français** est dense, régional, et encore organisé par bouche-à-oreille et annuaires payants : un annuaire gratuit et vivant a une place immédiate.
- **La langue et la culture du devis** : les acteurs français attendent un devis écrit, structuré, signé — exactement ce que produit AIME.

## 5. Pourquoi le monde ensuite

- Le socle est **neutre** : carte, disponibilité, intention, devis, paiement. Seule la couche administrative est nationale.
- L'ordre proposé : **Belgique / Suisse / Luxembourg** (même langue, même droit proche) → **Espagne / Italie** (marché mariage très fort, saisonnalité complémentaire) → **Royaume-Uni / États-Unis** (budgets plus élevés, mais concurrence installée).
- Le multilingue et la traduction des messages sont déjà en place : l'ouverture ne coûte que la traduction des mentions légales et l'adaptation du module administratif.

---

## Détails techniques

- `src/components/aime/LanguageMenu.tsx` : ajout d'une variante `capsule` (état local, `AnimatePresence`, fermeture au clic extérieur via `useEffect` + `pointerdown`), la variante `popover` actuelle reste par défaut pour le footer.
- `src/components/aime/AppShell.tsx` : la capsule passe en `flex-col` avec `overflow-hidden` et hauteur animée ; `LanguageMenu variant="capsule"` en bas.
- `src/routes/mon-evenement.tsx` : redirection directe vers `/projets` avec `search: { nouveau: "1" }`.
- L'audit ci-dessus n'entraîne, à cette étape, que la capsule et la redirection. Les autres points sont des décisions à valider, à découper en chantiers séparés.
