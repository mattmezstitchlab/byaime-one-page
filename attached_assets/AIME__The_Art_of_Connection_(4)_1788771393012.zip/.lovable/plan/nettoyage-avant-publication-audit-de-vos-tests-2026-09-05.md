# Nettoyage avant publication — audit de vos tests

Voici ce que vos essais ont laissé dans l'application, et ce que je propose d'effacer ou de garder.

## Ce que j'ai trouvé

**Vos documents (Bureau) — 4 fiches, 5 fichiers stockés**
- « urssaf mr lecointre.pdf » — document personnel réel
- « FACTURE-MMSAX-ROTARYCLUB.pdf » — facture réelle
- « facture-nord-sound-system-2026-0412.png » — essai
- « IMG_8059.PNG » — essai, non reconnu
- 1 fichier « facture.pdf » resté dans le stockage sans fiche associée (déchet)

**Dossiers du Bureau — 23, dont beaucoup de doublons**
Les mêmes dossiers types (« Mes factures », « Mes devis émis », « Contrats et fiches technique », « Justificatifs de frais », « Attestations »…) ont été recréés trois fois lors des tests des 4 et 5 septembre, plus « Mariage Claire & Julien », « Votre mariage », « Devis — Nord Sound System ».

**Essais divers**
- 5 intentions de test (« mariage lille », « faire mon mariage », « mariage lille 30 personne »…)
- 2 événements de test (« Mariage Claire & Julien », « Votre mariage ») + 1 devis
- 1 story « Ongles Test » + sa vidéo
- 1 entrée musique « la vie en rose »
- 1 conversation « mariage » avec 4 messages
- Fichiers d'essai dans le stockage des cartes : 2 vidéos générées, une capture d'écran, un « bisou »

**Journal de visites : 3 768 lignes**
Presque uniquement vos propres passages pendant le développement. Les statistiques seront faussées au lancement.

**Annuaire de cartes : 281**
280 sans propriétaire (annuaire public constitué) + votre carte « Matt Mez Sax ». Une carte de démonstration (photographe, avec 6 moments de ligne de temps publiés) fait partie du lot.

## Ce que je propose de faire

1. **Effacer les essais** : dossiers en double du Bureau, les 2 documents d'essai (Nord Sound System, IMG_8059), le fichier orphelin du stockage, les 5 intentions, les 2 événements + le devis, la story, l'entrée musique, la conversation d'essai et ses messages, et les fichiers d'essai du stockage des cartes.
2. **Garder** : votre carte « Matt Mez Sax », vos deux vrais documents (URSSAF, facture Rotary), les voix de la radio (dossier « annonces »), et l'annuaire public de cartes.
3. **Remettre le compteur de visites à zéro** pour partir sur des statistiques propres au lancement.
4. **Recréer un jeu de dossiers Bureau propre** (un seul exemplaire de chaque dossier type).
5. **Vérifier après coup** que l'accueil, le fil, le réseau, « Mon espace » et le Bureau s'affichent correctement avec ces données allégées, sur téléphone.

## Points à confirmer

- La carte de démonstration « photographe » et ses 6 moments publiés : je les garde comme vitrine, ou je les efface aussi ?
- Vos deux vrais documents : je les garde (ils sont privés et visibles de vous seul).

## Détails techniques

- Suppressions par migration SQL avec identifiants explicites (aucune suppression en masse par table), plus effacement des objets correspondants dans les seaux `bureau`, `cartes`, `stories`.
- `site_events` : `TRUNCATE`/`DELETE` complet.
- Pas de modification des routes `/bureau` ni des fonctions `SECURITY DEFINER`.
- Aucun changement de schéma, de RLS ou de GRANT.
