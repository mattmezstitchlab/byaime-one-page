# Un seul mariage numérique : le modèle, la ligne de temps, les vues

La page Mariage existante (`/demo/mariage`, AVANT / PENDANT / APRÈS) est conservée telle quelle dans sa mise en scène. Ce qui change : elle cesse d'avoir ses propres listes de données et devient une **fenêtre** sur un modèle unique, dont la ligne de temps universelle est la colonne vertébrale.

## Principe

```text
RÉCIT / SOURCES  →  WORLD MODEL (WeddingProject)  →  TIMELINE (dérivée)  →  VUES
                                                                            Avant
                                                                            Pendant (Jour J)
                                                                            Après
                                                                            Documents
                                                                            Finance
                                                                            Personnes / Prestataires
                                                                            Médias / Musique / Play
```

Une date, un lieu, un prestataire, un montant : une seule valeur source. Les vues la lisent, ne la recopient jamais.

## Ce qui est construit

### 1. Le modèle projet (source unique)
Un module `src/lib/aime/world/` :
- `WorldProject` générique (identité, date pivot, lieu, personnes, prestataires, événements, documents, finances, médias, musique, tâches, intentions, suggestions) — pensé pour d'autres projets que le mariage.
- `WeddingProject` = spécialisation (couple, invités, déroulé du jour J).
- Chaque champ porte un **statut de confiance** : `confirme`, `deduit`, `suggere`, `a_confirmer`, `manquant`, avec la source qui l'a produit.
- Des **relations** typées entre objets (prestataire → contrat → montant → acompte → échéance → jour J → photos → film), branchées sur le module de relations déjà existant.

### 2. La ligne de temps est dérivée, jamais saisie deux fois
`deriveTimeline(project)` produit les repères de la timeline universelle à partir du modèle : tâches du rétroplanning (J‑540 → J+30), rendez‑vous, devis, contrats, paiements, documents, moments du jour J, musique, photos, vidéos, messages, remerciements. Les calques existants (Tout, Temps, Personnes, Lieux, Prestataires, Documents, Finance, Photos, Vidéos, Musique, Messages, Tâches, Intentions) filtrent cette même liste.

### 3. Les trois vues de la page Mariage deviennent des sélections
- **AVANT** = repères antérieurs au jour J (tâches, rendez‑vous, devis, contrats, paiements, échéances, décisions, invitations).
- **PENDANT** = repères du jour J, heure par heure, avec personnes, lieux, prestataires, musique, médias.
- **APRÈS** = repères postérieurs (photos, vidéos, film, remerciements, soldes, albums, souvenirs).

Aucune liste codée en dur ne subsiste dans la page : `DEMO_STEPS`, `DEMO_VENDORS`, `DEMO_DEPOSITS`, `DEMO_PLAYLIST`, `DEMO_THREADS`, `DEMO_THANKS` deviennent des projections du modèle. La mise en page, le hero filmé, la radio et les sections restent identiques.

### 4. Propagation
Une valeur modifiée dans une vue modifie le modèle, et toutes les vues suivent (heure de cérémonie 15h → 15h30 se répercute sur le jour J, les prestataires concernés, les échéances et les repères liés). Une seule fonction d'écriture, jamais cinq champs à corriger.

### 5. Le récit du futur marié
Le champ du hero d'accueil reste en place. Une phrase du type « Nous nous marions le 12 septembre 2027 au Château X à Lille avec 120 invités, cérémonie à 15h, photographe et lieu déjà réservés » suit le pipeline :
1. **Comprendre** — extraction date, ville, lieu, nombre d'invités, heures, prestataires cités et leur statut (extension du lecteur de phrases existant, complétée par l'IA du projet).
2. **Structurer** — construction du `WeddingProject`.
3. **Relier** — création des relations entre prestataires, documents, montants, moments.
4. **Compléter** — déduction du déroulé manquant (préparation, habillage, accueil, cérémonie, sortie, photos, cocktail, dîner, discours, ouverture de bal, soirée) et du rétroplanning, tout marqué **Suggestion AIME** ou **À confirmer**, jamais présenté comme un fait.
5. **Représenter** — arrivée directe sur la page Mariage alimentée, avec sa ligne de temps.

Les prestataires réels par ville ne sont affichés que lorsqu'ils proviennent d'une recherche effective ; sinon le statut reste « À rechercher ». Aucun prestataire inventé.

### 6. Mode démo
La structure et l'exploration sont réelles et interactives : zoom, calques, filtres, fiches, relations, suggestions, lecture, narration. Les actions opérationnelles (modifier, importer, envoyer, contacter, synchroniser, payer, exporter, automatiser) affichent un cadenas et un appel à l'action « Activez votre mariage avec AIME ».

### 7. PLAY
Le moteur PLAY déjà construit est branché sur la timeline dérivée du modèle : ▶ Tout, Avant, Jour J, Photos, Vidéos, Musique, Narration AIME. La narration est composée à partir des données du modèle (ce qui est réservé, ce qui reste à prévoir) et n'invente rien.

## Détails techniques

- Nouveau dossier `src/lib/aime/world/` : `types.ts` (modèle générique + statuts de confiance), `wedding.ts` (spécialisation et déduction du déroulé), `derive.ts` (`deriveTimeline`, sélecteurs `before/during/after`, prestataires, finance, documents, médias), `parseStory.ts` (récit → modèle).
- `src/lib/aime/demo/mariage.ts` devient un **seul** `WeddingProject` de démonstration ; les exports actuels sont remplacés par des sélecteurs afin de supprimer toute duplication.
- `src/routes/demo.mariage.tsx` : mêmes sections, données lues via les sélecteurs, calques et boussoles branchés, `PlayShell` réutilisé.
- Le récit du hero passe le modèle sérialisé à la page démo (paramètre d'URL compact ou stockage de session), sans écriture en base : la démo reste publique et anonyme.
- Réutilisation stricte de l'existant : `HeroTimeline`, `TimelineLayers`, `TimelineCompass`, `timelineFilters`, `timelineRelations`, `retroplanning`, `play/*`. Aucune nouvelle table, aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié.
