# Tout miser sur la ligne de temps

## 1. L'accueil : un seul geste, un seul message

- Le champ devient explicite : « Racontez votre mariage : la date, le lieu,
  l'ambiance, le nombre d'invités… ». Les phrases qui défilent parlent toutes
  du récit d'un mariage, plus de « Louer une salle » / « Gérer mon budget ».
- On retire le bouton « Voir ma feuille de route » (ancien parcours) et le
  doublon « Voir mon mariage ». Il ne reste que « Continuer », qui lance la
  génération.
- Le petit commentaire d'Aime reste, mais court : une phrase, sans lien vers
  une autre page.

## 2. La génération se voit sur la ligne de temps

C'est le moment différenciant. Après « Continuer », on reste sur place :

- La ligne de temps apparaît en bas du film d'ouverture, vide.
- Les points s'y posent un par un, dans l'ordre du temps, avec le libellé qui
  s'écrit (« Le lieu », « Le traiteur », « Le jour J »…), pendant qu'une phrase
  d'état défile au-dessus (« Je place la cérémonie… »).
- Quand tout est posé, la page glisse vers le projet mariage : la même ligne,
  au même endroit, déjà remplie. Aucune coupure, aucun écran de chargement.

## 3. La page mariage : horizontale, pas verticale

Aujourd'hui neuf blocs empilés obligent à scroller sans fin. À la place :

- La ligne de temps reste posée en bas du film, toujours visible.
- En dessous, **un seul espace** qui montre ce que la lecture désigne :
  le moment en cours et ce qui s'y rattache (prestataire, devis, message,
  photo). On change de moment, le contenu change.
- Les listes longues (prestataires, devis, souvenirs) passent en **ascenseur
  horizontal** : une rangée de cartes qui défile latéralement, au lieu d'une
  colonne interminable.
- Pas de barre de navigation par section : la ligne de temps est la
  navigation.

Ce qu'on supprime de la page : les blocs séparés « Avant », « Le jour J »,
« Après », « Échanges », « Radio », « Budget » en tant que sections empilées.
Leur contenu ne disparaît pas — il devient les rangées horizontales du moment
sélectionné.

## Détails techniques

- `IntentionHero.tsx` : retirer `RoadmapPanel`, le bouton feuille de route et
  le bouton mariage ; un seul `go()`. Nouveaux `rotatingPlaceholders`.
- Nouveau `TimelineGenesis.tsx` : reçoit les marqueurs finaux, les révèle par
  intervalles (≈120 ms) dans `HeroTimeline` via une prop `revealCount`.
- `HeroTimeline.tsx` : prop `revealCount?: number` qui limite les marqueurs
  affichés, avec transition d'apparition.
- `demo.mariage.tsx` : remplacer les `<Section>` empilées par un
  `MomentPanel` piloté par `usePlay().currentId`, et un composant
  `Rail` (scroll horizontal, `snap-x`) pour les listes.
- On ne touche ni aux routes `/bureau`, ni aux fonctions protégées de la base.
