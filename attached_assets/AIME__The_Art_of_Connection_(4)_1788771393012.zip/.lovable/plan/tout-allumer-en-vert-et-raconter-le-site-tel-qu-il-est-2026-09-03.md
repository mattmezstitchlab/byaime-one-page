# Tout allumer en vert, et raconter le site tel qu'il est

## Ce que je comprends

1. **Bureau** : le voile blanc/flou devant le fond d'écran doit disparaître (le visuel doit se voir), et la bande blanche sous la fenêtre doit être couverte par le fond.
2. **Plan du système** : créer réellement ce qui est marqué « à venir » et terminer ce qui est « en cours », jusqu'à ce que chaque nœud soit « Fonctionne ».
3. **Comment ça marche + accueil** : chapitres remis à jour, et au-dessus du carrousel une fenêtre façon Bureau qui joue le chapitre étape par étape, avec la vraie copie d'écran de chaque étape, l'état correspondant et une barre de lecture.
4. **Verso des cartes des univers** : aujourd'hui on ne peut cocher qu'un seul sous-univers à la fois — le panneau se déplace au lieu de garder les cases cochées ailleurs. Il faut pouvoir parcourir tous les sous-univers d'une carte et cocher des sous-domaines dans chacun, le total se cumulant dans « Ajouter à la composition ».

## 1. Bureau (rapide)

- Suppression du calque `bg-background/70 backdrop-blur-xl` : le fond d'écran reste net, seul un léger dégradé sombre en haut garde le texte lisible.
- Le fond devient `fixed inset-0` derrière toute la page, y compris sous le pied de page : plus de marge blanche en bas.
- La fenêtre garde son verre dépoli à elle (c'est elle qui est floutée, pas le mur).

## 2. Faire passer le système nerveux au vert

Le plan liste 12 nœuds inexistants et 5 nœuds incomplets. Je les construis pour de vrai, mais à la bonne échelle : chaque page fait une chose, avec les données déjà présentes en base — aucune promesse de façade.

**À créer (nouvelles pages) :**

| Nœud | Page | Ce qu'elle fait |
| --- | --- | --- |
| Objectif | `/objectif` | Nommer ce qu'on veut atteindre, échéance, et le garder en tête de tableau de bord |
| Obstacles | dans `/objectif` | Les six barrières nommées, chacune avec ses contournements |
| Chemin | `/chemin` | Où j'en suis, l'étape suivante, ce qui bloque, qui peut m'aider |
| Entraide | `/entraide` | Demander de l'aide / proposer de l'aide, rattaché à un projet |
| Communs | `/communs` | Ce qui se prête : matériel, lieu, savoir-faire, heures |
| Contribution | dans `/entraide` | Le temps donné devient un repère de timeline |
| Veille | dans `/chemin` | Ce qui va coincer si rien ne bouge (dates, montants, places vides) |
| Fréquence publique | `/frequence/$id` | Écouter une fréquence sans passer par la carte |
| Historique des bisous | `/bisous` | Le mur public des empreintes |
| Rémunération | `/credits` (section) | Le journal de diffusion devient un décompte à reverser |
| Contributions-monnaie | `/credits` (section) | Heures données converties en crédits |
| Coulisses | `/plan-du-site` (calque proprio) | Ce qui reste à tenir, daté |

Trois tables nouvelles seulement : `objectives`, `help_requests`, `commons_items` (RLS + GRANT, comme partout).

**À terminer (« en cours ») :** mémoire (sources affichées sur chaque affirmation), fréquence (déclaré / documenté / estimé visibles), radio (page autonome atteignable), bibliothèque musicale (journal exportable), intermittent (cachets + heures complets).

Puis `systemMap.ts` passe chaque nœud à `actif` — **mais seulement après vérification écran par écran**, jamais par simple changement d'étiquette.

## 3. Comment ça marche + les chapitres de l'accueil

- Nouveau composant `ChapterWindow` : la même fenêtre que le Bureau (trois pastilles, barre de titre), placée **au-dessus du carrousel** sur l'accueil et en tête de chaque chapitre sur `/comment-ca-marche`.
- Chaque chapitre devient une suite d'**étapes numérotées** ; chaque étape porte sa propre copie d'écran du site, sa phrase, et sa pastille d'état (Fonctionne / En cours).
- Une **barre de lecture** sous la fenêtre : lecture automatique des étapes, pause, avance/recul, points cliquables. Respect de `prefers-reduced-motion`.
- Les captures sont refaites à partir du site réel (navigateur automatisé, une image par étape) pour qu'elles correspondent enfin à ce qu'on voit.
- Le carrousel des chapitres reste dessous et pilote la fenêtre : cliquer une vignette charge ce chapitre dans la fenêtre.

## 4. Verso des cartes : cocher partout, pas seulement au premier clic

- Les cases cochées sont mémorisées **par sous-univers** (elles le sont déjà dans `domains`), mais l'ouverture d'un autre sous-univers doit conserver l'affichage et le total.
- Chaque bouton de la liste devient un accordéon : on l'ouvre, on coche ses sous-domaines, on le referme, on passe au suivant — plusieurs ouverts possibles, les coches restent visibles sous chaque titre.
- Un compteur par sous-univers dans la liste, et le total cumulé sur « Ajouter à la composition » (déjà en place, il additionnera maintenant tous les sous-univers).
- Pour chaque univers des 12 mondes, les sous-domaines de troisième niveau manquants sont complétés dans `src/lib/aime/universes.ts` afin qu'aucun bouton n'ouvre une liste vide.

## Ordre de livraison

1. Bureau (fond net, plus de marge blanche).
2. Verso des cartes (accordéons multi-sélection).
3. Les pages manquantes + finitions des pages en cours, système nerveux repassé au vert.
4. Fenêtre de chapitre, captures d'écran réelles par étape, barre de lecture, accueil + Comment ça marche.

## Détails techniques

`BureauWindow.tsx` : suppression du calque flouté, fond en `fixed`. Nouvelles routes `objectif.tsx`, `chemin.tsx`, `entraide.tsx`, `communs.tsx`, `bisous.tsx`, `frequence.$id.tsx` avec `head()` propre et requêtes React Query ; une migration crée `objectives`, `help_requests`, `commons_items` avec `GRANT` puis RLS par `auth.uid()`. `systemMap.ts` : statuts et `exists` mis à jour, nouveaux `to:` réels, calque coulisses alimenté par ce qui reste. Nouveau `src/components/aime/ChapterWindow.tsx` (coquille fenêtre + lecteur d'étapes) ; `src/lib/aime/tour.ts` et `tourPlus.ts` gagnent `steps: { n, title, line, shot, status }[]`, les captures étant produites par un passage Playwright sur le site local et rangées dans `public/guide/`. `UniverseVideoGrid.tsx` : liste transformée en accordéons (`openSubs: string[]`), `ExplorationPanel` rendu sous chaque sous-univers ouvert, état `domains` inchangé. Aucune modification des sept avertissements de sécurité existants.
