# Moins de vues, moins de boutons, tout sur place

Trois simplifications qui vont dans le même sens : on enlève ce qui fait doublon, et on crée là où on est.

## 1. Le Réseau garde deux vues : Carte et Grille

La liste ne sert plus à grand-chose depuis que la grille cherche, filtre et ouvre un panneau. On la retire :

- Le sélecteur du Réseau n'affiche plus que **Carte** et **Grille**.
- Les anciens liens `?vues=liste` continuent de marcher : ils basculent simplement sur la grille.
- Le panneau latéral de la carte (les résultats à droite) reste : c'est lui qui remplaçait déjà la liste.

## 2. Sur ma page : un bouton « Modifier ma page »

Aujourd'hui, quand on est chez soi, l'éditeur s'affiche tout seul en haut tant que la page n'est pas complète. À la place :

- Un bouton **Modifier ma page** visible seulement pour le propriétaire, en haut de sa page.
- Il ouvre l'éditeur existant (visuel, nom, activité, ville, savoir-faire, univers) dans un panneau, sans quitter la page ; chaque champ s'enregistre en direct comme aujourd'hui.
- Un discret rappel de complétion (« votre page est remplie à X % ») reste sur le bouton, pour donner envie de continuer.

## 3. Plus de bouton cœur, et le « + » crée sur place

- Le cœur disparaît de la barre du bas et des champs de saisie : il ajoutait un menu d'options par-dessus l'écriture, ce qui doublait le « + ». Le champ AIME reste, on écrit et on envoie, simplement.
- Le « + » n'emmène plus ailleurs : chaque entrée ouvre un panneau par-dessus la page en cours.
  - Un projet → le formulaire de projet dans un panneau.
  - Une intention publique → le dépôt d'intention dans un panneau.
  - Un document → l'ajout de document dans un panneau.
  - Une invitation → l'invitation dans un panneau.
  - Ma page → reste une ouverture de page (c'est une destination, pas une création).
- Après validation, on reste où on était, avec une confirmation et un lien « voir ».

## Détails techniques

- `reseau.tsx` : `VIEW_KEYS` sans `liste`, normalisation `liste → grille`, retrait du rendu liste et du bouton correspondant.
- `carte.$id.tsx` : `PageSetup` n'est plus monté en permanence ; il passe dans un `Sheet`/`Dialog` déclenché par un bouton `isOwner`. Le calcul de complétion existant alimente le libellé.
- Barre du bas `AimeBar.tsx` : suppression du bouton cœur (mobile) ; `AimeField.tsx` ne rend plus `IntentionHeart`. `IntentionHeart.tsx` est supprimé une fois ses derniers usages retirés (`index`, `projets`, `messages`, `saisons`, `AiPanel`), en conservant le type `IntentionFrame` là où il sert.
- Nouveau `CreateOverlay` monté une fois dans `AppShell`, piloté par un petit état global (événement `aime:creer`), qui affiche `ProjectForm`, le dépôt d'intention, `AddDocument` ou l'invitation selon l'entrée choisie. `CREATE_ENTRIES` gagne une clé `panel` au lieu d'un `to` pour ces quatre entrées.
- Les routes `/projets?nouveau=1`, `/reseau?creer=intention`, `/bureau?creer=document`, `/invitation` restent valides comme adresses directes.
- Aucun changement de base de données ni de règles de sécurité.

## Ordre proposé

1. Réseau sans mode liste
2. Bouton « Modifier ma page »
3. Retrait du cœur
4. Créations en panneau depuis le « + »
