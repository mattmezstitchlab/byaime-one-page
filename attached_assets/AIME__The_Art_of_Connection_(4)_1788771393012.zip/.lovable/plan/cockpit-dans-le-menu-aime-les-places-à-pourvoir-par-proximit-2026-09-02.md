# Cockpit dans le menu AIME + les places à pourvoir par proximité

Deux choses : rendre le Cockpit accessible (et visible pour vous seul), puis terminer le volet « proximité » des places à pourvoir sur `/saisons` et `/rencontres`.

## A. Accès au Cockpit

- Une entrée **Cockpit** apparaît dans le menu AIME (le petit chevron à côté du logo), en bas, séparée par un trait, avec la note « Réservé à l'administration ».
- Elle n'est affichée que si votre compte porte le rôle `admin` en base — vérification serveur via `user_roles`, jamais un test côté navigateur. Les autres visiteurs ne voient rien du tout.
- Même entrée conditionnelle dans le menu burger mobile, section « Moi ».

Point important, vérifié : **votre compte n'a aucun rôle `admin` aujourd'hui** (la table `user_roles` ne renvoie rien pour vous). Le lien resterait donc invisible. Le chantier inclut donc l'attribution du rôle `admin` à votre compte (`matthieu.lecointre@gmail.com`) par migration, pour que l'entrée apparaisse et que `/cockpit` s'ouvre.

## B. Les places à pourvoir, par proximité

Aujourd'hui la distance existe dans le calcul mais rien ne l'alimente : aucune coordonnée n'est fournie, donc toutes les places s'affichent sans notion de distance. On complète la chaîne.

### B1. Savoir où vous êtes
Par ordre de préférence, sans jamais forcer :
1. votre **ville de profil** (déjà là),
2. la **ville de votre carte** avec ses `lat`/`lon` (les cartes portent déjà ces colonnes),
3. votre **cellule de monde** (`world_cells` : ville/région déjà posée),
4. rien du tout : tout continue de fonctionner, mais sans distances.

Aucune géolocalisation navigateur n'est demandée : on reste sur ce que vous avez déjà renseigné.

### B2. Donner une position aux places
Les villes des projets et des compositions sont converties en coordonnées via le géocodage déjà utilisé ailleurs dans le site, avec un cache local : une ville n'est résolue qu'une fois. À défaut de coordonnées, on retombe sur une comparaison **même ville** puis **même région**.

### B3. Le réglage de proximité
Une barre de portée, présente en haut de `/saisons` et dans le plan des places de `/rencontres` :

**Ma ville · 40 km · 100 km · Ma région · Partout**

Le choix est mémorisé (il reprend `profiles.radio_radius_km` comme valeur de départ, la même notion de rayon que la radio). Il filtre les places affichées et réordonne chaque semaine par distance croissante.

### B4. Ce que la carte-semaine dit
Chaque carte-semaine affiche une pastille du type « 3 places à moins de 40 km », et le verso liste chaque place avec son rôle, son projet, sa ville, le jour et la distance (« Busnes · 38 km · vendredi 5 »). Les places sans distance connue sont regroupées en fin de liste sous « Distance inconnue » plutôt que masquées.

### B5. Se positionner
Le bouton « Je peux tenir cette place » reste tel quel : il pré-remplit l'intention et ouvre `/rencontres` sur ce rôle précis.

### Limite maintenue
Seuls vos projets et ceux où vous êtes participant nourrissent les places : rien des autres membres n'est exposé tant que l'« appel public » volontaire n'existe pas. La proximité s'applique donc d'abord à votre propre année — l'ouverture aux appels d'autrui reste le lot suivant.

## Détails techniques

- `src/lib/aime/admin.ts` : réutilisé tel quel par `LogoMenu.tsx` et `MobileMenu.tsx` pour l'entrée conditionnelle.
- Migration : insertion du rôle `admin` dans `public.user_roles` pour l'utilisateur ciblé par e-mail.
- Nouveau `src/lib/aime/geo.ts` : résolution ville → `{lat, lon}` avec cache `localStorage`, repli ville/région, et `radiusFilter`.
- `src/lib/aime/openSlots.ts` : `home` alimenté (profil → carte → `world_cells`), `cityPoint` branché sur `geo.ts`, tri distance puis date, regroupement « distance inconnue ».
- Nouveau `src/components/aime/RangePicker.tsx` : la barre de portée, utilisée par `saisons.tsx` et `SlotPlan.tsx`.
- `WeekCard.tsx` : pastille de distance et ligne détaillée par place.
- Vérification : `bunx tsgo --noEmit`, puis passage navigateur sur `/saisons`, `/rencontres` et `/cockpit` en session connectée.
- Aucun finding de sécurité supplémentaire n'est touché.
