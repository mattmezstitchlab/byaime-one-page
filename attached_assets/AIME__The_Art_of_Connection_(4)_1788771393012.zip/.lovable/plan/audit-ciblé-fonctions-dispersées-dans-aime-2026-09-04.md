# Audit ciblé — fonctions dispersées dans AIME

Aucun fichier de code n'a été modifié. Tout ce qui suit est vérifié dans le code actuel (chemins et lignes à l'appui).

## 1. Ce qui existe encore

**Page personne (`src/routes/carte.$id.tsx`)**
- Deux entrées « Modifier » : l'entrée `modifier` du menu Cœur (`src/lib/aime/pageAsk.ts:150`, traitée ligne 319) et un bouton texte « Modifier ma page » sous la timeline (ligne 1311). Les deux ouvrent le même panneau latéral droit (ligne 1321), qui ne contient qu'un composant : `PageSetup`.
- `PageSetup` (`src/components/aime/PageSetup.tsx`) = identité, photo, activité, ville, publier.
- Section « Projets » (ligne 1387) : `ProjectCircles` (cercles de participants, glisser-déposer) + `MessagesPanel`.
- Section « Échanges » = ce même `MessagesPanel`, une messagerie complète (fils, envoi, pièces jointes) dans la page.
- Section « Point zéro » (ligne 1398) : `ZeroPoint` — vidéo de fond, import fichier/photo/texte, OCR via `ingestFile` (`src/lib/bureau/ingest.ts`) → stockage `bureau`, table `bureau_documents`, mini-timeline de documents.

**Studio / Mon Espace**
- `Studio.tsx` (plein écran, onglets AI / ME) contient : `PageSetup`, `SettingsSection`, `MePanel`, bloc compte + déconnexion.
- `mon-espace.tsx` : Mes mondes, Ce qui m'attend (4 tuiles), Aimes reçues, Ma page publique (+ « Modifier ma page » → Studio ME), Mon bureau, Réglages (`SettingsSection` + bloc compte).
- Route `/ma-page` : ne fait qu'ouvrir le Studio.

**Réseau (`src/routes/reseau.tsx`)**
- Carte plein écran `CardsMap` (MapLibre + fond CARTO, sans clé).
- Panneau flottant droit « À l'écran · N » : liste des cartes visibles, avec au dépliage ville, note, propositions, lien vers la page, bouton Aime.
- Filtres : Univers, Domaine, Ville, Fraîcheur (**ce dernier n'est jamais appliqué**, lignes 185-205).
- Bouton Cœur : simple popover à 3 actions — Déposer une intention, Autour de moi, Créer ma page. Aucun lien avec `HeartAgent`.

**HeartAgent** (`src/components/aime/heart/HeartAgent.tsx`) : fichier/photo → lecture IA → proposition éditable → « Ajouter au projet » (World Model). Il n'est pas monté sur la page personne.

## 2. Doublons détectés

| Doublon | Où |
|---|---|
| `PageSetup` instancié deux fois, dans deux enveloppes différentes | panneau latéral de `carte.$id.tsx` **et** Studio onglet ME |
| Trois chemins vers la même édition de page | menu Cœur, bouton page personne, bouton Mon Espace / `/ma-page` |
| `SettingsSection` monté deux fois | `mon-espace.tsx:314` **et** `Studio.tsx:115` |
| Bloc compte (email + déconnexion) dupliqué | `mon-espace.tsx:315` **et** `Studio.tsx:125` |
| Lecture de document + OCR en double logique | `ZeroPoint`/`ingestFile` (→ `bureau_documents`) **et** `HeartAgent`/`analyzeDocument` (→ World Model) |
| Messagerie en double | `MessagesPanel` dans la page personne **et** page `/messages` |
| Deux « cœurs » sans rapport | popover Réseau (3 actions) **et** `HeartAgent`/`HeartMenu` |

## 3. À déplacer vers la Timeline
Échanges contextualisés (un fil lié à un moment devient un repère, la réponse se fait dans la bulle — déjà supporté) ; documents importés (repère « document » au lieu d'une mini-timeline séparée dans Point zéro) ; participation aux projets (repères de la timeline personnelle plutôt qu'une grille de projets autonome).

## 4. À déplacer vers HeartAgent
Tout l'import et la lecture de documents du Point zéro (fichier, photo, OCR, extraction, proposition, validation) ; l'action « Déposer une intention » du Cœur Réseau ; « Reprendre une intention ».

## 5. À centraliser dans Mon Espace
Édition de la page publique (`PageSetup`), réglages AI / ME, langue, accessibilité, préférences, confidentialité, compte et déconnexion — **une seule fois**. Manquent aujourd'hui, à créer : apparence/thème, notifications, sécurité (mot de passe, sessions), connexions, visibilité du profil.

## 6. À conserver dans Réseau
La carte, la recherche, les filtres Univers / Domaine / Ville, la sélection d'une personne, « Autour de moi », et l'action sur la sélection.

## 7. À transformer en outil de sélection
La grille de personnes ne doit pas disparaître : elle devient un **mode sélection multiple du Réseau** (cases, barre d'action flottante : ajouter à un projet, créer un cercle, écrire au groupe, demander plusieurs devis), réutilisable en panneau contextuel depuis un projet et depuis la bulle d'un moment. `ProjectCircles` de la page personne devient le consommateur de cette sélection, plus une grille indépendante.

## 8. À supprimer
Panneau « Modifier » de la page personne ; second montage de `SettingsSection` ; bloc compte dupliqué ; filtre « Fraîcheur » non branché ; composant jamais importé `src/components/aime/AgentLoader.tsx` ; redirection `monde.tsx` → `/reseau?vues=grille` (le mode grille n'existe plus) ; section Point zéro comme section autonome.

## 9. Carte Réseau non affichée en partage — cause trouvée

Vérifié sur `https://aime-network.lovable.app/reseau` : la requête `https://byaime.fr/assets/maplibre-gl-worker.mjs` échoue en `net::ERR_FAILED`. Le fichier de travail de MapLibre est demandé **sur le domaine personnalisé** alors que la page est servie depuis un autre domaine (lien partagé, aperçu, `*.lovable.app`) : le navigateur bloque cette requête inter-domaines et la carte ne peut pas dessiner ses tuiles. Les données ne sont pas en cause : les cartes publiées sont lisibles sans compte (`GRANT SELECT ... TO anon`, politique `cards_public_read`) et la liste « À l'écran · 60 » se remplit bien.

Fichiers concernés : `src/components/aime/CardsMap.tsx:226-227` (import dynamique de `maplibre-gl`), configuration de base d'URL des ressources dans `vite.config.ts` / réglages de publication.

Correction recommandée : servir les ressources en chemin relatif à l'origine courante (base `/` au lieu d'une URL absolue vers `byaime.fr`), ou déclarer explicitement l'URL du worker MapLibre sur l'origine courante avant l'initialisation. À vérifier ensuite sur les trois domaines.

## 10. Nouvelle architecture — page Personne
HERO : identité, présence, HeartAgent (avec import de document). TIMELINE personnelle : moments, projets, tâches, décisions, échanges, documents, échéances, relations, alertes. Puis, très léger : mes mondes (liste cliquable), mes cercles. Plus de panneau d'édition, plus de messagerie, plus de Point zéro.

## 11. Nouvelle architecture — Mon Espace
A. Ma page (identité, présentation, photo, éléments publics, AI / ME) · B. Préférences (langue, accessibilité, affichage, notifications) · C. Compte (sécurité, confidentialité, connexions, crédits) · D. Mes mondes (accès seulement ; la configuration d'un monde reste dans le monde). Quatre volets repliés par défaut, ouverts un à la fois, pour éviter le mur de réglages.

## 12. Nouvelle architecture — Réseau
Carte plein écran → recherche → filtres (Univers, Domaine, Ville) → sélection (simple ou multiple) → action. Le panneau droit devient un panneau contextuel : masqué par défaut, ouvert sur sélection ou en mode liste, et il porte le mode sélection multiple. Le Cœur du Réseau disparaît au profit du HeartAgent.

## 13. Une fonction = un lieu

| Fonction | Aujourd'hui | Doublon | Lieu cible | Action |
|---|---|---|---|---|
| Modifier ma page | page personne + Studio + `/ma-page` | oui (×3) | Mon Espace | FUSIONNER |
| Réglages généraux | Mon Espace + Studio | oui | Mon Espace | FUSIONNER |
| Compte / déconnexion | Mon Espace + Studio | oui | Mon Espace | FUSIONNER |
| Onglets AI / ME | Studio | non | Mon Espace | DÉPLACER |
| Échanges (page personne) | `MessagesPanel` | oui (`/messages`) | Timeline + Messages | DÉPLACER |
| Projets (page personne) | `ProjectCircles` | partiel | Timeline + liste légère | RÉDUIRE |
| Point zéro (import, OCR) | `ZeroPoint` | oui (`HeartAgent`) | HeartAgent | FUSIONNER |
| Cercles de participants | `ProjectCircles` | non | Projet + sélection Réseau | TRANSFORMER |
| Grille de personnes | supprimée du Réseau | non | Réseau, mode sélection | TRANSFORMER |
| Cœur Réseau (3 actions) | `reseau.tsx:399` | oui | HeartAgent | FUSIONNER |
| Filtre Fraîcheur | Réseau | inactif | — | SUPPRIMER |
| Liste « À l'écran » | colonne droite fixe | non | panneau contextuel | TRANSFORMER |
| Bureau | Mon Espace `#bureau` | non | inchangé (gelé) | CONSERVER |

## 14. Fantômes / legacy
`AgentLoader.tsx` jamais importé (SUPPRIMER) · `monde.tsx` → `/reseau?vues=grille`, mode disparu (CORRIGER la cible) · `registre.tsx`, `evenements.tsx`, `evenement.$.tsx`, `bureau.index.tsx` : redirections à garder pour les liens existants (CONSERVER) · `/ma-page` comme route-fantôme ouvrant le Studio (TRANSFORMER en redirection vers Mon Espace) · filtre `catFilter` sans commande visible dans le panneau (SUPPRIMER ou exposer) · paramètre `vues=grille` encore lu par le Réseau.

## 15. Plan de nettoyage priorisé

**P0** — 1. Carte invisible en partage (worker MapLibre inter-domaines). 2. Suppression du panneau « Modifier » de la page personne + des trois entrées concurrentes, au profit de Mon Espace. 3. Fusion des réglages et du bloc compte en un seul endroit.

**P1** — 4. Point zéro absorbé par le HeartAgent (import + lecture + proposition → Timeline). 5. Échanges de la page personne convertis en repères de timeline, `/messages` reste l'espace global. 6. Section Projets réduite à une liste légère de mondes. 7. Réseau : panneau droit contextuel, Cœur remplacé par HeartAgent, filtre Fraîcheur retiré.

**P2** — 8. Mode sélection multiple du Réseau (cercles, équipes, ajout groupé à un projet). 9. Mon Espace complété : apparence, notifications, sécurité, connexions, confidentialité. 10. Nettoyage des fantômes (`AgentLoader`, cible de `monde.tsx`, `/ma-page`, `catFilter`).

Périmètre gelé : `/bureau*`, fonctions `SECURITY DEFINER`, pages légales.
