# Carte épurée + page dédiée par carte

## 1. Nettoyage visuel de la carte

Sur le recto de la carte AIME :
- Suppression du badge de statut en haut à gauche (RECOMMANDÉ / POPULAIRE / …).
- Suppression du rond « vérifié » (✓).
- Suppression du bouton rond en verre qui sert à retourner la carte : il reste seulement une flèche blanche fine (↻) posée sur la photo, sans fond ni contour.
- Idem au verso : la flèche de retour devient une simple flèche discrète.

Le reste du recto (catégorie, nom, accroche, ville, prix, note, bouton cœur) ne bouge pas.

## 2. Bouton « Voir la carte » au verso

Au verso, sous les infos, un bouton texte discret « Voir la page » ouvre une nouvelle page dédiée à la carte.

## 3. Nouvelle page `/carte/$id`

Structure :
- **Grand hero** plein écran (photo de la carte, dégradé sombre en bas).
- **Sur le hero** : catégorie, nom, accroche, ville, note et prix — et le **bouton cœur AIME** (mêmes intentions qu'aujourd'hui, taille lg).
- **Corps de page** : sections détaillées (voir audit ci-dessous).
- Métadonnées SEO propres à chaque carte (titre, description, og:image quand la photo est une URL absolue).

## Audit — ce que peut contenir la page d'une carte

Avec les données déjà présentes en base, sans nouvelle table :

| Section | Source | Statut |
|---|---|---|
| Hero + identité (nom, accroche, catégorie, ville/région) | `cards` | dispo |
| Statut & vérifié (déplacés ici depuis la vignette) | `cards.status`, `verified` | dispo |
| Présentation / bio longue | `cards.bio` | dispo |
| Savoir-faire (puces) | `cards.skills` | dispo |
| Expériences / références | `cards.experiences` | dispo |
| Univers concernés (pictos) | `cards.universes` | dispo |
| Tags | `cards.tags` | dispo |
| Budget & niveau de prix | `budget_min/max`, `price_level` | dispo |
| Calendrier de disponibilité du mois | `card_availability` + `MonthCalendar` | dispo |
| Créneaux texte (« Samedi 9 mai — disponible ») | `availability_slots` | dispo |
| Avis & note détaillée | table `reviews` | dispo, pas encore affichée |
| Contact : site, téléphone, adresse | `website`, `phone`, `address` | dispo (affiché seulement après une intention « contacter », pour protéger les prestataires) |
| Barre d'actions AIME (aimer, réserver, contacter, associer, enregistrer) | `aimes` | dispo |
| Cartes proches / à associer (même univers ou ville) | `cards` | dispo, calcul côté client |
| Source de la fiche (« annuaire mariages.net ») | `cards.source` | dispo |
| Bouton « Ajouter à mon événement » | `events` / `event_participants` | dispo |

Pistes pour plus tard (nécessiteraient du travail en base) : galerie multi-photos, tarifs détaillés par formule, écriture d'un avis depuis la page, messagerie directe.


## 4. Timeline passé / présent / futur sous le hero

Bande horizontale collée au bas du hero, pleine largeur, sur fond verre translucide.

**Lecture**
- Règle graduée façon mètre de menuisier : traits fins pour les mois, traits longs + libellé pour les années.
- Le présent est au centre par défaut, marqué par un curseur vertical fin (ligne + pastille) et l'étiquette « Aujourd'hui ».
- À gauche : le passé (souvenirs, événements réalisés, mise en ligne de la carte, avis reçus).
- À droite : le futur (dates réservées, options posées, événements planifiés, disponibilités).
- Chaque repère est un point coloré posé sur la règle (vert disponible, ambre option, rouge complet, noir événement, gris souvenir), avec l'icône d'univers quand la carte est active sur plusieurs univers — une ligne de pictos d'univers est affichée au-dessus de la règle.

**Interaction**
- Glisser horizontalement (souris, trackpad, doigt) pour se déplacer dans le temps.
- Pincer / molette / double-tap pour zoomer la graduation : décennie → année → mois → semaine. Plus on zoome, plus les repères se détaillent (titre, lieu, statut).
- Tap sur un repère : ouvre une fiche compacte au-dessus de la règle avec le détail du moment et 1 à 2 actions contextuelles.
- Bouton « Aujourd'hui » pour recentrer.

**Actions contextuelles proposées** (à ajuster ensemble ensuite)
- Sur une date future libre : « Poser une option », « Réserver cette date », « Proposer une rencontre ».
- Sur une date occupée : « Voir l'événement », « Demander une autre date ».
- Sur le présent : « Déclarer une intention » (les intentions AIME existantes : aimer, contacter, associer…).
- Sur un moment passé : « Voir le souvenir », « Laisser un avis ».

**Édition** (uniquement par le propriétaire de la carte)
- Tap long / bouton « + » sur une graduation : créer un repère (type, titre, date, description, univers, visibilité publique ou privée).
- Édition et suppression depuis la fiche du repère.

**Données**
- Nouvelle table `card_timeline_entries` : `card_id`, `kind` (souvenir, evenement, disponibilite, intention, jalon), `title`, `description`, `starts_at`, `ends_at`, `universe_slug`, `is_public`, `link_event_id`. RLS : lecture publique des entrées publiques, écriture réservée au propriétaire de la carte, plus les GRANT associés.
- La timeline agrège ces entrées avec les données existantes : `card_availability`, `events` / `event_participants`, `aimes` reçues, `reviews`.

**Technique**
- Nouveau composant `src/components/aime/HeroTimeline.tsx` : rendu de la règle en SVG, mapping temps → pixels via une échelle linéaire, zoom exponentiel ancré sur le point touché (listener `wheel` natif non passif, `touch-action: none` et Pointer Events pour le pinch à deux doigts), état zoom/offset dans une ref pour éviter les closures périmées.
- Helpers de graduation (choix du pas selon le niveau de zoom) ajoutés à `src/lib/aime/calendar.ts`.
- Réutilisable ailleurs : la page carte d'abord, puis potentiellement `/mon-evenement` et `/evenements`.

## Détails techniques


- `src/components/aime/AimeCard.tsx` : retrait de `StatusBadge`, boutons de flip réduits à une flèche `text-white/80` sans fond, ajout d'un `Link` vers `/carte/$id` au verso.
- Nouveau `src/routes/carte.$id.tsx` avec `createFileRoute("/carte/$id")`, loader qui amorce le cache TanStack Query, `useSuspenseQuery` côté composant, `notFound()` si la carte n'existe pas ou n'est pas publiée.
- Nouvelle query `cardQuery(id)` et `cardReviewsQuery(id)` dans `src/lib/aime/queries.ts`.
- Réutilisation de `AimeButton`, `MonthCalendar`, `useAimes`.
- `StatusBadge` conservé et réutilisé dans le hero de la page carte.
