# Les cœurs du site : ce qu'ils sont vraiment, et ce qu'il faut corriger

## Ce que j'ai trouvé (vérifié dans le code)

Il n'y a pas un cœur, il y en a **quatre familles**, et votre intuition est juste sur deux points : le cœur des champs de saisie est **identique partout**, et plusieurs actions **ne sont pas branchées**.

### 1. Le cœur posé sur une carte (`AimeButton`)
C'est le bon élève : son menu **change vraiment selon la nature de la carte** (personne, lieu, professionnel, événement, ressource, entreprise, ma propre carte) et selon le temps courant du site. Ses panneaux écrivent réellement en base : Réserver (aimes + message), Associer (composition), Devis, Payer, Inviter, Contacter.
Présent sur : page carte, réseau, rencontres, profil, ma carte, guides, vignettes de cartes.

### 2. Le cœur des champs de saisie (`IntentionHeart`, dans `AimeField`)
**Menu strictement identique sur toutes les pages**, six entrées figées : Importer un document, Dicter à la voix, Embarquer des cartes, Reprendre une intention, Déposer en public, Préciser le cadre.
Il ne reçoit **aucun contexte de page** (ni carte, ni projet, ni monde, ni ville). Sur les huit pages qui l'affichent, il propose exactement la même chose — y compris « Embarquer des cartes » sur des pages où les cartes embarquées ne servent à rien ensuite.
Sur ses six entrées, **une seule écrit en base** (Déposer en public → intentions). « Préciser le cadre » ne fait que rallonger le texte, sans jamais enregistrer la date, la ville ou le budget ailleurs.

### 3. Les champs eux-mêmes : ce que devient le texte écrit
- Rencontres : enregistré (crée une rencontre). Ma carte : traité par l'IA de qualification. Correct.
- Accueil, Monde, Tableau de bord, panneau AI : le texte part seulement en paramètre d'URL, rien n'est mémorisé.
- **Projets** : la phrase entière devient le titre du projet — grossier.
- **Messages** : le texte saisi n'est **jamais lu** ; le cœur et le champ ouvrent une fenêtre vide. C'est un vrai trou.

### 4. Le cœur de la Radio (fait main, à part)
Menu « À l'antenne » indépendant des deux autres. **« J'aime ce passage » n'enregistre rien** : il affiche un message qui promet qu'Aime s'en souviendra, ce qui est faux aujourd'hui.

### 5. Reste
Le Bureau n'a aucun cœur. `RegistryList` (une liste avec cœur) est du code mort, jamais affiché.

## Ce que je propose de corriger

### A. Un cœur de saisie qui s'adapte à sa page
`IntentionHeart` reçoit un **contexte** (page, monde, ville, carte ou projet en cours). Le menu se recompose :
- Partout : Dicter, Importer un document, Préciser le cadre, Déposer en public.
- Accueil / Rencontres / Monde : + Embarquer des cartes, Reprendre une intention.
- Page carte : + Proposer une date à cette carte, Demander un devis (reprend les panneaux d'`AimeButton`, pas de doublon).
- Projets : + Rattacher à un de mes projets.
- Messages : + Écrire à quelqu'un précisément (choix du destinataire).
- Radio : le cœur radio reprend la même grammaire visuelle, avec ses entrées propres.

### B. « Préciser le cadre » cesse d'être décoratif
Date, ville, budget et nombre de personnes sont conservés comme critères structurés, et transmis à l'action de la page (recherche, rencontre, projet), au lieu d'être seulement recopiés dans le texte.

### C. Boucher les trous constatés
- **Messages** : le texte du champ ouvre la fenêtre de nouvelle conversation **pré-remplie** avec ce message.
- **Projets** : la phrase sert de brief, et un titre court en est extrait, au lieu de devenir le titre en entier.
- **Accueil / Monde / Tableau de bord** : l'intention écrite est conservée comme intention de l'utilisateur (table existante `intentions`) pour qu'elle réapparaisse dans « Reprendre une intention », au lieu de disparaître à la navigation.
- **Radio, « J'aime ce passage »** : soit enregistré réellement (aime posée sur la carte diffusée), soit le message est reformulé pour ne plus promettre une mémoire qui n'existe pas. Je propose l'enregistrement réel quand un passage est rattaché à une carte, et un message honnête sinon.

### D. Nettoyage
Suppression du composant mort `RegistryList`.

## Détails techniques

- `IntentionHeart` gagne une prop `context` (`{ page, universeSlug?, city?, cardId?, eventId? }`) et une fonction `actionsForContext()` dans un nouveau fichier `src/lib/aime/heartActions.ts`, sur le modèle existant de `cardActions.ts`.
- `AimeField` transmet ce contexte ; chaque page passe le sien (une ligne par page).
- Le « cadre » devient un objet remonté par `onFrameChange` en plus du texte ; les pages qui savent l'exploiter l'utilisent, les autres l'ignorent sans régression.
- Écriture des intentions : réutilisation de la table `intentions` déjà en place — aucune migration, aucun changement de règles d'accès ou de sécurité.
- Radio : réutilisation de `useAimes().toggle` avec `current.card_id`.

## Ordre de réalisation

1. Contexte du cœur de saisie + menus adaptés par page.
2. Cadre structuré réellement transmis.
3. Messages, Projets, Accueil/Monde/Tableau de bord : intentions conservées et pré-remplissages.
4. Cœur radio honnête + suppression du code mort.
