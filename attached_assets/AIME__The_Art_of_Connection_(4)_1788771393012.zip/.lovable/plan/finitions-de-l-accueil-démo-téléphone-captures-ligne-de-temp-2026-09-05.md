# Finitions de l'accueil : démo téléphone, captures, ligne de temps vide

## 0. La démonstration dans un téléphone a disparu

Vérification faite : la section « La démonstration » avec l'écran de téléphone
n'est plus dans le code de l'accueil (aucune trace du cadre ni de la vue
intégrée de `/demo/mariage`). Elle n'a pas survécu aux derniers changements.

À refaire : sous « Une seule ligne de temps », une section ancrée `id="demo"`
avec un vrai cadre de téléphone (largeur 320-390 px, ratio ~9/19.5, bordure et
ombre en jetons du thème) qui affiche la page `/demo/mariage` telle quelle,
chargée seulement quand la section arrive à l'écran. Le lien « Regarder
d'abord » du hero descend vers cette section. La page de démonstration
elle-même n'est pas modifiée.



## 1. Les captures de l'accueil ne montrent plus l'application actuelle

Trois images de l'accueil datent d'avant les derniers changements :

- « Messages, documents, invités » : montre l'ancien panneau Documents, sans le panneau latéral droit ni l'arbre des dossiers.
- « L'argent » : même panneau ancien.
- « Le réseau » : mal cadrée, une bande noire apparaît en bas.

Refaire les trois captures sur l'application telle qu'elle est aujourd'hui :
ouvrir le panneau latéral droit avec l'arbre des dossiers pour la capture
Documents, la vue Argent pour la deuxième, et la carte du réseau cadrée sur la
carte seule (aucune bande noire, aucun bord d'écran visible). Les nouvelles
images remplacent les anciennes au même emplacement, sans toucher aux textes.

## 2. La ligne de temps vide du hero

Aujourd'hui, quand le récit n'a encore rien posé, le hero affiche un cartouche
transparent « Votre ligne de temps est encore vide ».

À la place : la vraie ligne de temps, vide, avec ses graduations et son repère
du jour, prête à recevoir les moments du récit. La mention devient une simple
légende discrète posée par-dessus (« Votre ligne de temps, prête à recevoir »),
sans gêner le clic.

Elle doit être collée au bas du hero, sans espace ni décalage : on supprime la
marge basse et les marges latérales de ce bloc pour qu'elle touche le bord,
exactement comme la ligne de temps remplie.

## 3. Barre de défilement noire dans la ligne de temps

Dans la fiche sombre qui s'ouvre au-dessus de la ligne de temps (la liste des
repères d'un groupe), la barre de défilement est blanche et se voit trop. Elle
passe en version sombre, discrète, sur cette fiche et sur sa liste.

## 4. Nettoyage du hero

Les deux petites phrases « Envie de voir un projet déjà vécu ? Voir la
démonstration » du hero disparaissent : « Regarder d'abord » suffit pour
descendre vers l'histoire, et la démonstration reste accessible plus bas.

## Détails techniques

- `src/components/aime/home/HomeJourney.tsx` : remplacer le bloc `h-14`
  (lignes ~455-470) par `<HeroTimeline markers={[]} preview className="w-full" />`
  plus une légende en superposition `pointer-events-none` ; retirer `pb-3` et le
  `px-5 max-w-5xl` de l'état vide ; supprimer les deux blocs `Link to="/demo/mariage"`
  (lignes ~295-303 et ~419-427) et l'import `Link` s'il devient inutile.
- `src/components/aime/HeroTimeline.tsx` : ajouter l'utilitaire existant
  `scrollbar-dark` (défini dans `src/styles.css`) aux conteneurs défilants
  lignes ~1002 et ~1135.
- `src/components/aime/home/HomeStory.tsx` : section `id="demo"` avec cadre
  téléphone + `<iframe src="/demo/mariage" loading="lazy" title="…">` monté via
  `useInView` ; en-tête et bandeau cookies masqués dans l'aperçu ; ancre du lien
  « Regarder d'abord » sur `#demo`.
- Captures : script Playwright sous `/tmp/browser/shots/`, viewport 1280x1800,
  captures d'élément (jamais `full_page`), export en `src/assets/home-ensemble.jpg`,
  `home-argent.jpg`, `home-reseau.jpg`.
- Vérification : `bunx tsgo --noEmit -p tsconfig.json` puis contrôle visuel de
  l'accueil en 390 px et en 1280 px.
