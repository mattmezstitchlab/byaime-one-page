# Créer sa page : un seul geste, une seule page, une seule ligne de temps

Oui, on est d'accord sur le principe : on ne « crée pas une carte », on **crée sa page**. La carte n'est plus qu'une vignette — la façon dont votre page apparaît dans les recherches, sur la carte du réseau et sur les timelines des autres. Voici ce qui bloque aujourd'hui et ce que je propose.

## Ce qui casse aujourd'hui (vérifié)

- Le message `insert or update on table "cards" violates foreign key constraint "cards_category_slug_fkey"` vient de la création automatique de la page : elle enregistre la catégorie `personne`, qui **n'existe pas** dans la table des catégories (les 23 catégories existantes sont métier : photographe, traiteur, musicien, lieu-reception…). La colonne catégorie est obligatoire et contrôlée, donc l'enregistrement est refusé.
- Conséquence directe : « Mon espace » échoue et vous renvoie sur l'ancien écran **« Créer ma carte »** — celui que vous voyez sur la capture. Ce n'est pas un choix de parcours, c'est le repli en cas d'erreur.
- Le vocabulaire est resté à « carte » partout sur cet écran (titre, sous-titre, métadonnées de la page).

## Ce que je propose

### 1. Débloquer la création

Ajouter deux catégories génériques (« Personne » et « Projet ») pour que toute page puisse exister avant même d'être qualifiée. Créer sa page redevient un geste qui ne peut pas échouer.

### 2. Un seul écran d'entrée : l'onboarding de page

`/ma-carte` devient `/ma-page` (l'ancienne adresse redirige) et se transforme en accueil guidé en 4 temps, tout dans un même écran, chaque étape passable :

1. **Qui / quoi** — nom, une phrase, photo. La page existe dès cette étape.
2. **Ce que vous faites** — activité et sous-univers ; c'est ce qui détermine les onglets et les boutons d'action de votre vignette.
3. **Où et quand** — ville, rayon, premières disponibilités.
4. **Votre première ligne de temps** — au moins un repère : une date à venir, une réalisation passée, une intention. C'est le lien direct avec le nouveau principe de timeline.

À la fin : on arrive sur **sa page** (`/carte/$id`), pas sur un formulaire. Le reste se complète plus tard, depuis la page elle-même.

### 3. La vignette : la carte devient une représentation, pas un objet à créer

Partout où votre page apparaît (recherche, carte du réseau, grille, survol d'un repère de timeline), c'est la même petite carte : photo, nom, une phrase, et **2 à 3 boutons d'action choisis selon votre activité** — Réserver, Demander un devis, Écrire, Voir la page. Exactement la même grammaire que les bulles de la timeline.

### 4. Le vocabulaire

« Créer ma carte » → **« Créer ma page »**, « Modifier ma carte » → « Compléter ma page », partout : héros, boutons, menus, textes de partage. La carte reste nommée comme telle uniquement quand on parle de la vignette.

## Découpage

1. Correction de la création (catégories génériques) + vocabulaire.
2. Onboarding en 4 temps avec sortie directe sur la page.
3. Vignette d'action unifiée dans les trois vues du réseau et dans les bulles de timeline.

## Détails techniques

Migration : insertion de deux lignes dans `categories` (`personne`, `projet`) — aucune table modifiée, aucune règle d'accès touchée. `useMyPage.ts` utilise `personne` et ne retombe plus sur `/ma-carte` en cas d'échec. `ma-carte.tsx` est renommé en `ma-page.tsx` (route de redirection conservée) et son contenu réorganisé en étapes autour de l'état de complétion déjà calculé ; l'étape 4 écrit dans `card_timeline_entries`. La vignette d'action réutilise `timelineActions.ts` pour produire les mêmes boutons dans `CardsMap`, la grille de `/reseau` et les bulles de `HeroTimeline`.
