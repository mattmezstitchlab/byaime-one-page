# Bureau, Rencontres et le Tableau de bord « AI + ME »

## 1. Bureau : textes remontés, fenêtre superposée au hero

- Dans le hero du Bureau, remonter le bloc titre/baseline : le texte cesse d'être collé au bas du visuel et se place plus haut, pour laisser respirer le tiers inférieur.
- La fenêtre du Bureau (barre à trois pastilles + arborescence) remonte pour chevaucher le hero sur environ un tiers de sa hauteur, avec son ombre portée qui la fait flotter au-dessus du visuel.
- L'en-tête interne (« Administration / Bureau financier & administratif ») reste lisible : le contenu du hero est décalé au-dessus de la zone de recouvrement, pas caché derrière la fenêtre.
- Mobile : recouvrement plus faible (le hero est plus court), la fenêtre reste entièrement utilisable.

## 2. Rencontres : texte remonté, champ de saisie dans le hero

- Le hero de Rencontres remonte lui aussi son titre, et accueille directement sous le titre la phrase d'accroche courte puis le champ de saisie AIME (cœur + intention + bouton Composer), en version claire sur fond sombre.
- Le champ disparaît de la colonne sous le hero : une seule saisie, celle du hero, avec les mêmes placeholders tournants, les cartes épinglées et les filtres (univers, ville) juste en dessous, dans le corps de page.
- Pendant que Aime compose, l'animation de recherche prend la place des résultats sous le hero ; le champ reste visible et verrouillé.
- Le reste de la page (traces de composition, résultats, calendrier) ne bouge pas.

Pour permettre ces deux points proprement, le composant de hero partagé reçoit deux réglages optionnels : la position verticale du bloc de texte, et une zone de recouvrement réservée en bas quand un élément flottant vient se poser dessus. Les autres pages gardent exactement leur rendu actuel.

## 3. Audit du Tableau de bord

État actuel : hero + une phrase d'explication, une liste « à faire en priorité », quatre compteurs (cartes, projets, aimes, conversations), les prochains rendez-vous, un encart documents. Rien n'a suivi l'évolution du site : ni crédits, ni mémoire d'Aime, ni compositions, ni semaines/saisons, ni Bureau, ni Radio, ni proximité. Des données sont même déjà chargées (crédits, mémoire, versements) mais jamais affichées.

## 4. Innovation : AI + ME = le Tableau de bord

Le principe du bouton devient la structure de la page : deux colonnes lisibles côte à côte sur grand écran, empilées sur mobile, avec au sommet une ligne « AI + ME = aujourd'hui » qui résume la journée en une phrase.

**Colonne AI — ce qu'Aime a fait et propose**
- La proposition du jour : une composition à compléter, une place à pourvoir près de chez vous, une relance à envoyer — chaque ligne avec un bouton d'action direct.
- Places à pourvoir à proximité, reprises du moteur de proximité déjà en place, avec la portée choisie (ma ville, 40 km, 100 km, ma région).
- La semaine en cours issue du Jeu des 52 semaines : carte S-xx, saison, ce qui est posé, ce qui manque.
- Mémoire d'Aime : ce qu'il retient de vous, modifiable et effaçable ligne par ligne.
- Crédits IA : consommés ce mois, restants, lien vers les crédits.

**Colonne ME — ce qui est à moi**
- Ma carte (aperçu recto), mes cartes secondaires, complétude du profil.
- Mes projets à venir et mes compositions en cours.
- Aimes reçues à traiter et conversations en attente de réponse.
- Bureau : documents à vérifier, montant en attente de paiement, dernier export comptable.
- Coordonnées de versement, avec un rappel si elles manquent.

**Le liant**
- Une barre de saisie AIME dans le hero du tableau de bord (même cœur, mêmes placeholders) : on écrit une intention, elle part vers la bonne page selon le sens (composer, poser une semaine, demander un document).
- Chaque bloc n'apparaît que s'il a du contenu ; à vide, une seule invitation claire plutôt que des cadres vides.
- Un état déconnecté propre, comme aujourd'hui.

## Détails techniques

- `PageHero` : ajout de deux props optionnelles (`align` pour la hauteur du bloc texte, `overlap` pour l'espace réservé au bloc flottant). Valeurs par défaut identiques à l'existant.
- `BureauWindow` : marge négative sur le conteneur de la fenêtre (≈ un tiers de `HERO_HEIGHT`), `relative z-10`, padding compensé en dessous.
- `rencontres.tsx` : `AimeField` (tone sombre) passé en `children` du `PageHero` ; suppression du bloc de saisie dupliqué sous le hero.
- `tableau-de-bord.tsx` : réécriture de la mise en page en deux colonnes AI / ME, réutilisation de `openSlots`, `weeks`, `compositionsQuery`, `aiMemoryQuery`, `aiUsageQuery`, `creditLedgerQuery`, `payoutQuery`, et des requêtes Bureau (`documentsQuery`, `exportsQuery`). Aucun changement de schéma, aucune nouvelle requête serveur.
- Vérification : `bunx tsgo --noEmit`, puis contrôle visuel de `/bureau`, `/rencontres` et `/tableau-de-bord` en desktop et mobile.
- Aucun finding de sécurité supplémentaire n'est traité.
