# Réseau, équipes et radio qui raconte un projet

Trois chantiers, dans cet ordre.

## 1. Réseau : lire la quintessence d'une sélection

Dans le bloc « À l'écran », au-dessus de la liste, un encart apparaît dès qu'une
personne est cochée :

- **Ce que vous réunissez** : les métiers, univers et villes déjà couverts par
  les personnes cochées, en petites pastilles.
- **Formules possibles** : deux ou trois lectures courtes (« Concert en salle :
  scène + son + lieu », « Mariage complet : ... »), déduites des métiers réunis
  et, si un projet existe déjà, de ses besoins.
- **Ce qui manque** : les rôles absents pour tenir la formule visée. Chaque rôle
  manquant est cliquable et **filtre la liste en dessous** : on ne voit plus que
  les personnes qui comblent ce manque.
- Un bouton **« En faire une équipe »**.

Rien n'est ajouté à un projet sans clic. La croix remet la liste complète.

## 2. Une page équipe, avec notification à chacun

« En faire une équipe » ouvre une petite fenêtre : nom de l'équipe, objectif en
une phrase (pré-rempli à partir de la formule), projet rattaché si l'on veut.
Elle crée une page dédiée `/equipe/<id>` qui présente :

- l'objectif et **pourquoi c'est réalisable** (les rôles réunis, ce qu'apporte
  chacun, ce qui reste à trouver) ;
- une fiche par personne (photo, métier, ville, lien vers sa page) ;
- l'avancement : qui a pris connaissance, qui manque.

Chaque personne réunie reçoit une notification « Vous faites partie de <équipe> »
qui ouvre cette page. L'équipe s'appuie sur les regroupements déjà existants
(compositions) plutôt que sur une nouvelle notion parallèle.

## 3. Radio : l'animatrice commente un projet

Dans la capsule radio, un troisième mode : **« Un projet »**, avec le choix du
projet enregistré. L'animatrice raconte alors, à voix haute :

- où en est le projet et **ce qui manque** (rôles, devis, documents, paiements) ;
- les échanges récents qui répondent à une question en attente ;
- la **météo du jour** et, si le projet a une date et un lieu, la **météo prévue
  ce jour-là** ;
- un **plan B** parlé quand la météo l'exige (repli, horaire décalé) ;
- une lecture d'ensemble : la température du projet, un ou deux conseils.

Elle enchaîne ensuite sur la musique ou les médias du projet, comme aujourd'hui
pour le fil.

**Bouton cœur sur la capsule** : enregistrer un vocal ou passer une annonce, en
choisissant la fréquence de diffusion (une fois, chaque jour, chaque semaine,
jusqu'à la date du projet). L'annonce se glisse ensuite entre deux morceaux.

## 4. La barre du bas, partout

Aujourd'hui la barre Personnes · Argent · Documents · Le jour J n'existe que sur
les pages de projet. Elle sera posée sur toutes les pages, sur téléphone comme
sur ordinateur, avec les portes adaptées à la page en cours ; l'en-tête perd les
boutons qui feraient doublon (dossiers, échanges, notifications).

## Détails techniques

- `src/routes/reseau.tsx` : encart de synthèse alimenté par un nouveau
  `src/lib/aime/team/quintessence.ts` (rôles couverts / manquants / formules,
  calcul local à partir de `cards`, `categories`, `events`), filtre de liste
  piloté par le rôle manquant choisi.
- Équipe : réutilisation de `compositions` + `composition_items` (aucune table
  nouvelle), objectif stocké dans `compositions`, nouvelle route
  `src/routes/equipe.$id.tsx` avec `head()` propre, insertion dans
  `notifications` pour chaque membre. Vérifier/compléter les politiques RLS de
  `compositions` pour la lecture par les membres (migration avec `GRANT`).
- Radio : `RadioMode` passe à `musique | fil | projet` dans `RadioProvider.tsx` ;
  nouveau `src/lib/aime/play/projectNarration.ts` qui compose le texte à partir
  de la timeline, des devis/paiements, des messages et de `weather.functions.ts`
  (prévision + plan B) ; lecture via `speakNarration` existant.
- Annonces : `musicbox_entries` (kind « annonce ») pour le vocal et la fréquence
  de diffusion ; enregistrement micro via `MediaRecorder` puis dépôt dans le
  stockage existant.
- Barre du bas : `PanelBar` sortie de `ProjectPanels.tsx` vers un composant
  partagé monté dans `AppShell.tsx`, avec jeu de portes selon la route.
- Aucune modification des routes `/bureau` ni des fonctions `SECURITY DEFINER`.
