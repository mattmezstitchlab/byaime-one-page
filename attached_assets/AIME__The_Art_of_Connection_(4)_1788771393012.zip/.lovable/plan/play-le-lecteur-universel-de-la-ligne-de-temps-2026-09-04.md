# PLAY — le lecteur universel de la ligne de temps

Un seul moteur de lecture, branché sur la timeline existante. Aucun lecteur photo, vidéo, musique ou cinéma séparé : PLAY lit les objets déjà présents, filtrés par calques, période, personne ou événement.

## Ce qui existe déjà (vérifié dans le code)

- `HeroTimeline.tsx` : `TimelineMarker` porte `media`, `mediaUrl`, `thumbUrl`, `startTime`/`endTime`, `status`, `personIds`, `projectId`, `metadata`, plus la prop `visible` pour les calques.
- `timelineFilters.ts` : 13 familles de calques (photo, vidéo, message, personne, finance…), `familiesOf`, `makeLayerFilter`.
- `TimelineLayers.tsx` : barre de calques activables.
- `cardTimeline.ts` : agrégation documents, devis, paiements, événements, messages sur une seule ligne.
- `musicbox_entries` : table déjà datée (jour, heure, durée, type morceau/message/annonce/récit, visibilité), lue par `MusicBox.tsx` et la radio.
- `demo.mariage.tsx` : une lecture heure par heure existe, mais codée en dur pour cette page seulement.

Il n'y a aujourd'hui aucun moteur de lecture réutilisable : c'est ce que ce plan ajoute.

## Livraison 1 — le moteur et le bouton

- **Modèle `PlayableItem`** (id, type, timestamp, duration, mediaUrl, thumbnail, title, source, narration, transition, priority, metadata) construit à partir de n'importe quel repère de la timeline.
- **Constructeur de file** : timeline → filtre (calques, période, personne, événement, sélection courante) → tri chronologique → enrichissement (durées par défaut : photo 3 s, texte 4 s, vidéo/audio = durée réelle) → file de lecture.
- **Bouton ▶ unique** posé sur la règle, avec menu contextuel : *Lire tout · Cette journée · Cette semaine · Cet événement · Photos · Vidéos · Audio · Musique · Narration · Sélection actuelle*.
- **Lecture visuelle** : pendant la lecture, la timeline avance seule, l'élément courant est mis en évidence et la vue se recentre — la règle devient une bande-film.
- **Scène de lecture** : surcouche plein écran (photo, vidéo, lecteur audio, texte) avec précédent / pause / suivant, barre de progression de la file, et titre + heure de l'élément.

## Livraison 2 — musique dans le temps

- Les entrées `musicbox_entries` deviennent des repères de la ligne de temps (calque Musique), placées à leur heure réelle.
- **＋ Ajouter → Musique** : rechercher un titre, importer un fichier audio (MP3, WAV, M4A, AAC), choisir le moment et l'événement associé. Le morceau apparaît immédiatement sur la ligne.
- **Modèle fournisseur** `MusicProvider` (provider, trackId, title, artist, artwork, previewUrl, externalUrl, duration, rights) : preview légale et limitée, jamais de fichier complet stocké. Aucun couplage à un service unique.
- **Mode DJ** : morceau actuel, morceau suivant, événement suivant, heure — vue minimale au-dessus de la même timeline.

## Livraison 3 — souvenirs, film et récit

- **Import de souvenirs** (photos, vidéos, audios, messages) rattachés à une personne, un événement, un lieu. Métadonnées d'origine conservées ; média sans date exploitable → repère « Date inconnue » et question « où placer ce souvenir ? ». Jamais de date inventée.
- **🎬 Film du jour / ✨ Créer un film** : durée (1/3/5/10 min), style (chronologique, Jour J, invités, soirée, rétrospective), audio (musique, narration, les deux, son d'origine), médias (photos, vidéos, les deux). Le résultat est une file de lecture éditorialisée jouée par le même moteur — les fichiers originaux ne sont jamais modifiés.
- **▶ Raconter** : couche de narration entre les éléments, écrite à partir des seules informations réellement présentes dans la timeline, jamais inventée.
- **Playlists** enregistrées et dynamiques : une sélection sauvegardée (nom, filtres, période, personnes, événements, types, ordre) se recharge, et une playlist dynamique intègre automatiquement les nouveaux médias correspondants.

## Ce qui n'est pas fait ici

L'export vidéo d'un fichier de montage et le partage public avec droits d'accès sont préparés dans l'architecture (originaux → timeline → playlist → montage → export) mais livrés plus tard.

## Détails techniques

Nouveau `src/lib/aime/play/` : `types.ts` (`PlayableItem`, `PlayScope`, `PlayMode`, `Transition`), `buildQueue.ts` (pipeline filtre → tri → enrichissement, réutilisant `familiesOf` et `makeLayerFilter`), `narrate.ts` (texte dérivé des repères, option Lovable AI côté serveur), `film.ts` (scénarios de montage déclaratifs par style). Contexte React `PlayProvider.tsx` (file, index, état, vitesse) consommé par `PlayButton.tsx` (menu contextuel), `PlayStage.tsx` (scène plein écran) et `DjMode.tsx`. `HeroTimeline.tsx` reçoit une prop optionnelle `playingId` pour la mise en évidence et le recentrage ; aucune rupture des appels existants. Musique : nouvelles familles `musique` / `narration` dans `timelineFilters.ts`, source `musicbox_entries` ajoutée à `cardTimeline.ts` ; import audio et médias de souvenirs via un bucket de stockage dédié (politiques calquées sur l'existant). Souvenirs : réutilisation de `card_timeline_entries` avec `metadata` (auteur, appareil, lieu, date d'origine, groupe de moment) plutôt qu'une nouvelle table ; playlists enregistrées dans une petite table `timeline_playlists` (filtres en JSON, GRANT et RLS via `public.is_card_owner`). Aucune route `/bureau` touchée, aucun `SECURITY DEFINER` modifié, aucune timeline secondaire créée.
