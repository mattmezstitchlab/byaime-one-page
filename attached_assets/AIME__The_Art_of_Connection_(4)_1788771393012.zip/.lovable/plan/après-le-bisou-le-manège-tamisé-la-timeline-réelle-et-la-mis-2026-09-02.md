# Après le bisou : le manège tamisé, la timeline réelle, et la mise à jour des panneaux

Tout ce qui suit a été vérifié dans le code avant d'être écrit.

## 1. La sortie du rituel — le manège à l'arrêt, pas l'ange

Aujourd'hui, quand le rituel se termine, le fond du hero est la vidéo `hero-carousel.mp4` affichée
avec un poster qui n'a rien à voir (`hero-evenements.jpg`) : c'est ce visuel étranger qu'on voit.

Correctif :
- Le fond redevient **le manège lui-même, à l'arrêt** : première image de la vidéo (vidéo chargée,
  positionnée sur son premier instant, en pause) — donc plus aucun visuel d'ange ni d'événement.
- À l'arrêt, il est **tamisé** : image assombrie et légèrement désaturée, avec une lueur douce qui
  respire lentement sur les ampoules (clignotement discret, respect de `prefers-reduced-motion`).
- Au clic sur le cœur : la pénombre se lève d'un coup — pleine lumière, pleine couleur — et le
  manège se met à tourner. C'est la récompense du geste.
- Un mot sous le champ le dit déjà (« Appuyez sur le cœur — il met le manège en marche ») ; il reste.

## 2. La timeline d'accueil — le vrai mécanisme, en démo

La timeline de l'accueil est aujourd'hui une liste figée de 8 repères inventés
(`showcaseTimeline.ts`) : rien dessous, aucune bulle d'action réelle, aucun lien avec ce que le site
sait faire. Elle montre le décor, pas la machine.

Ce que j'ajoute, sous la ligne de temps, alimenté par les mêmes données de démonstration mais avec
le mécanisme réel :

- **Bande de synthèse** : ce qui est gravé / ce qui s'échange / ce qui se prépare, avec le compte de
  repères par temps et la période affichée.
- **Bande d'argent** : engagé, facturé, encaissé sur la période — les montants manquent aujourd'hui
  dans les repères de démonstration, je les ajoute (devis, acompte, facture).
- **Effets de fréquence** : sous chaque repère sélectionné, la ligne « ce que ça a fait bouger »
  (une disponibilité qui se ferme, un budget qui monte, une équipe qui se complète), exactement la
  grammaire des `timeline_effects` réels, ici en démo lisible.
- **La bulle devient active** : les actions contextuelles existantes (ouvrir, demander un devis,
  voir les dispos) sont branchées, avec la mention honnête « démonstration » quand l'action mène à
  une page plutôt qu'à une écriture.
- Repères manquants ajoutés à la démo pour que le cycle soit complet : une **contribution**, un
  **document rangé au Bureau**, un **moment d'antenne radio**, un **paiement encaissé**.

## 3. « Comment ça marche » sur l'accueil — un schéma animé

Les 5 cartes de texte deviennent un **schéma illustré animé** : les cinq organes (Carte · Cœur ·
Aime · Rencontre · Événement) reliés par un trait qui se trace au défilement, chaque organe
s'allumant à son tour, avec sa phrase courte. Au survol d'un organe, le trait qui en part se
souligne. Version mobile : les organes s'empilent, le trait devient vertical.
En dessous, un bouton **« Voir plus »** qui mène à `/comment-ca-marche`.

## 4. La page « Comment ça marche » — ce que j'y ajoute

Elle compte aujourd'hui 9 chapitres (6 de la visite + Monde, Fréquence, Contribuer) et un encart
musique. Ce qui manque, et que j'ajoute :

- **Le rituel du bisou** : pourquoi on commence par un geste, ce qu'est l'empreinte, où elle vit,
  comment elle sert de photo par défaut, comment l'effacer.
- **Les trois temps** : ♠ Passé constater · ♦ Présent agir · ♣ Futur prévenir — la clé de lecture de
  tout le site, expliquée une fois pour toutes, avec le cœur hors du temps.
- **La causalité** : point zéro, lien causal, onde, zone secrète — dit en langage courant
  (« ce qui bouge ici fait bouger là, et on vous dit pourquoi »).
- **Le Bureau et l'export comptable**, aujourd'hui seulement effleuré.
- Le même schéma animé que l'accueil, en tête de page, en version développée.
- Métadonnées corrigées : le sous-titre annonce « Neuf chapitres » et ne sera plus juste.

## 5. Le système nerveux — ce qu'il manque encore

`systemMap.ts` compte 36 nœuds dont 8 marqués « n'existe pas encore ». Manquent complètement, alors
qu'ils existent dans le code ou sont des trous réels :

À ajouter comme nœuds existants : **le rituel du bisou** (empreintes, historique de connexion), la
**page Identity** (le film), les **capacités de carte**, la **météo et plan B**, les **rôles de
projet et la zone secrète**, les **cartes mémoire** (DMC, Jésus).
À ajouter comme nœuds manquants : **historique public des bisous**, **page Fréquence publique**,
**rémunération des ayants droit**, **contributions comme monnaie**, **journal des coulisses**.
Nouveaux flux en Si · Alors · Parce que : bisou → carte, capacité → possibilité, rôle → secret,
météo → plan B, contribution → fréquence.

## 6. Audit des panneaux AI et ME — et le mode Passé · Présent · Futur

Réponse franche à la question : **non**. Le temps (`tense.tsx`) n'est branché que sur le dock et le
bouton « + » (`AimeDock.tsx`, `AimeButton.tsx`, `CausalPanel.tsx`, `__root.tsx`). Les panneaux AI et
ME l'ignorent totalement : ils affichent la même chose quel que soit le temps choisi.

Panneau AI (aujourd'hui : suggestions, ce qui a bougé, dites-lui, crédits, mémoire, discussions,
journal, comprendre). Ce qui manque :
- il ne se plie pas au temps : en ♠ Passé il devrait raconter et constater, en ♦ Présent proposer
  des actions, en ♣ Futur prévenir les risques ;
- pas de rappel de la dernière feuille de route générée ;
- aucune alerte issue de la météo ou des risques causaux.

Panneau ME (compte, où j'en suis, mes cartes, ma fréquence, ma place, mes contributions, échanges,
argent, Bureau, versements). Ce qui manque :
- pas de filtre temporel non plus : ce que j'ai vécu / ce que je fais / ce qui m'attend ;
- **mon empreinte de bisou** n'apparaît nulle part alors qu'elle est mon premier objet sur le site ;
- mes rôles de projet et ce que je suis seul à savoir (zone secrète) ne sont pas rappelés.

Correctif proposé : les deux panneaux lisent le temps courant et **réordonnent** leurs sections
selon lui, sans en cacher aucune, avec un bandeau qui dit clairement dans quel temps on lit. Le
cœur, lui, reste hors du temps.

## Livraison

1. Manège tamisé au repos, allumage au cœur.
2. Timeline d'accueil : synthèse, argent, effets, bulle active, repères manquants.
3. Schéma animé « Comment ça marche » + bouton « Voir plus ».
4. Page « Comment ça marche » : 4 chapitres ajoutés, métadonnées corrigées.
5. Système nerveux : nœuds et flux manquants.
6. Panneaux AI et ME accordés aux trois temps, plus les entrées manquantes.

## Détails techniques

`IntentionHero.tsx` : retrait du poster étranger, vidéo en `preload="auto"` figée à `currentTime`
0.04 après `loadeddata`, filtre CSS `brightness/saturate` animé et surcouche de lueur en
`motion/react`, transition vers l'état allumé dans `startCarousel`. `showcaseTimeline.ts` : ajout de
`amount`, `effects[]` et de 4 repères (contribution, document, antenne, paiement).
Nouveau `src/components/aime/TimelineDigest.tsx` sous `HeroTimeline` (synthèse temps + argent +
effets), branché sur le repère sélectionné via l'état déjà exposé par `HeroTimeline`.
Nouveau `src/components/aime/HowItWorksDiagram.tsx` (SVG animé, `whileInView`, `prefers-reduced-motion`)
remplaçant la grille `STEPS` de `src/routes/index.tsx`, réutilisé en tête de `comment-ca-marche.tsx`.
`comment-ca-marche.tsx` : 4 entrées dans `CHAPTERS_PLUS`, sous-titre et métadonnées mis à jour.
`systemMap.ts` : nouveaux `SystemNode` (exists true/false) et `SystemEdge` avec si/alors/parceQue,
positions dans les colonnes existantes — le canevas gère déjà le cadrage.
`AiPanel.tsx` / `MePanel.tsx` : lecture de `useTense()`, ordre des sections dérivé du temps, bandeau
d'en-tête, section empreinte lue depuis `src/lib/aime/kiss.ts`. Aucune migration de base de données,
aucune dépendance ajoutée.
