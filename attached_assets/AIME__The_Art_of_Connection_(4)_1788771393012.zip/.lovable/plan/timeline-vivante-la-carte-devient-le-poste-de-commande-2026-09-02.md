# Timeline vivante : la carte devient le poste de commande

Deux choses ici : un nettoyage visuel rapide du hero d'accueil, puis le grand sujet — appliquer partout le mécanisme d'aperçu de la timeline d'accueil, et y greffer les actions (devis, facture, document, budget) pour ne presque plus changer de page.

## Ce qui cloche aujourd'hui (constaté dans le code et sur les captures)

- Sur `/carte/$id`, la timeline affiche les libellés sous chaque point dès que le zoom dépasse le niveau « mois ». Avec une disponibilité par jour, les libellés se chevauchent et forment une bouillie de texte (visible sur la capture Tony Masclet).
- La timeline de la carte est rendue sans le mode aperçu : pas de bulle au survol. Le détail s'ouvre dans un bloc sous le hero, souvent masqué par la barre de navigation collante — on clique et il ne se passe rien de visible.
- Le même contenu est déjà lisible dans le calendrier (points verts/orange/rouges). La timeline duplique l'information sans rien ajouter.
- L'accueil, lui, fait exactement ce qu'il faut : vignette ronde, survol, bulle riche avec image/vidéo/onde audio, titre, détail, date. Ce mécanisme n'est utilisé nulle part ailleurs.
- Les documents, devis, factures, paiements et budget d'un projet ne vivent pas sur la timeline : il faut aller dans le Bureau.

## Ce que je propose

### 1. Hero d'accueil — nettoyage

Retirer le contour du champ de saisie et les contours des boutons : champ en verre foncé sans trait, bouton « Voir le film » sans bordure. Le seul élément plein reste « Continuer » et « Créer ma carte ».

### 2. La timeline devient lisible

- Supprimer définitivement les libellés texte sous les points, à tous les niveaux de zoom. Un point = une pastille de couleur, rien d'autre.
- Regrouper les disponibilités : au lieu d'un point par jour, une barre continue colorée par période (libre / option / complet). On lit une saison d'un coup d'œil au lieu de compter des points.
- Activer l'aperçu au survol sur toutes les timelines, avec la même bulle que l'accueil. Le bloc de détail sous le hero disparaît, remplacé par la bulle ancrée au repère.
- Sur mobile : appui = la bulle s'ouvre en feuille basse, elle n'est jamais coupée par le haut de page.

### 3. La bulle devient active (le vrai saut)

La bulle d'aperçu ne fait plus que montrer : elle agit. Selon la nature du repère, elle propose 2 à 3 actions rondes, directement exécutables sans quitter la page :

| Repère | Actions dans la bulle |
|---|---|
| Date libre | Réserver · Demander un devis · Proposer un créneau |
| Date en option | Confirmer · Relancer · Libérer |
| Devis | Voir le PDF · Accepter · Transformer en facture |
| Facture | Voir · Marquer payée · Relancer |
| Document | Ouvrir · Ranger dans un dossier · Joindre au projet |
| Événement | Ouvrir le projet · Inviter · Voir le budget |
| Souvenir / média | Lire · Partager · Épingler |

Générer un devis ou une facture depuis la bulle réutilise la logique existante du Bureau ; le résultat apparaît immédiatement comme un nouveau repère sur la même timeline. C'est là qu'on dépasse Runey : eux alignent des étapes dans un tunnel, nous les posons sur le temps réel de la carte.

### 4. La timeline porte aussi l'argent et les documents

Trois familles de repères s'ajoutent aux souvenirs et disponibilités : **documents** (picto feuille), **argent** (devis, facture, paiement, avec le montant lisible dans la bulle), **jalons de projet**. Une bande fine sous la timeline résume le budget engagé / facturé / encaissé sur la période affichée.

### 5. Cohérence sur tout le site

Le même composant sert sur : l'accueil, chaque carte, la page timeline d'une carte, l'écran de projet et le dossier du Bureau. Une seule grammaire visuelle, un seul comportement.

## Découpage en trois livraisons

1. **Lisibilité** — hero sans contours, suppression des libellés, disponibilités en barres, aperçu au survol activé partout, feuille basse mobile.
2. **Bulle active** — actions contextuelles dans la bulle, création de devis/facture depuis la timeline, retour immédiat du nouveau repère.
3. **Argent et documents** — repères financiers et documentaires, bande de synthèse budget, réutilisation du composant sur projet et Bureau.

## Détails techniques

`HeroTimeline.tsx` : retrait de `showMarkerLabels`, ajout de segments d'intervalle (nouveau type `TimelineBand`) rendus avant les repères, `preview` activé par défaut, bulle repositionnée en `fixed` sur mobile. Nouveau `TimelineBubble.tsx` portant les actions, alimenté par une table d'actions par `kind`/`media` sur le modèle de `src/lib/aime/cardActions.ts`. `carte.$id.tsx` : suppression du bloc `selected` sous le hero, agrégation des disponibilités en bandes, ajout des repères issus de `bureau_documents` et des devis/factures via `src/lib/bureau/queries.ts`. Les actions de génération passent par les fonctions serveur existantes du Bureau, sans nouvelle table.
