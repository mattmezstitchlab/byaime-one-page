# Simplifier AIME : 7 portes au lieu de 50 pages

Constat vérifié : `src/routes/` contient 59 fichiers, dont une trentaine de pages publiques qui parlent des mêmes objets (carte, projet, composition, semaine, argent). Le tableau de bord console existe déjà et sait afficher la plupart de ces contenus en sections. Le problème n'est donc plus de construire, mais de **fermer des portes**.

## Le principe : une seule question par porte

Sept entrées, pas plus. Tout le reste devient une section, un onglet ou une redirection.

```text
1. Accueil          — « qu'est-ce que vous organisez ? »   (champ AIME)
2. Le Monde AIME    — découvrir les cartes et les univers
3. Réseau           — la carte géographique
4. Ma carte         — qui je suis / ce que je propose
5. Ma page projet   — /carte/$id : tout un projet sur un écran
6. Tableau de bord  — la console : tout piloter (sections déjà en place)
7. Le Bureau        — dossiers, devis, factures, export
```

Le menu (capsule, burger, pied de page) n'affiche plus que ces sept-là. Aujourd'hui la capsule et le burger n'exposent pas la même liste : ils seront alignés sur cette liste unique.

## Ce qui disparaît de la navigation

Ces pages restent accessibles par lien direct (aucune URL cassée, aucun lien mort), mais quittent les menus car leur contenu est déjà dans la console :

- `/parametres`, `/profil`, `/credits`, `/aimes-recues`, `/messages`, `/projets`, `/rencontres`, `/saisons` → sections du tableau de bord
- `/evenements`, `/mon-evenement`, `/registre` → doublons historiques : redirection permanente vers `/projets`, `/projets`, `/monde`
- `/objectif`, `/chemin`, `/entraide`, `/communs`, `/bisous`, `/frequence/$id` → regroupées derrière `/monde` (onglets), pas d'entrée de menu propre
- `/beta`, `/comment-ca-marche`, `/plan-du-site`, `/guides`, `/identity`, `/ambassadeur`, `/intermittent` → une seule page « Comprendre AIME » avec chapitres, reliée depuis le pied de page
- `/cockpit`, `/admin/enrichissement` → réservées admin, jamais dans la navigation publique

## Ce qui reste tel quel

Les pages qui servent de destination partageable : `/carte/$id`, `/projets/$id/*`, `/bureau/*`, `/devis/$cardId`, `/auth`, `/invitation`, `/legal/$doc`, les routes API et le sitemap.

## Simplifier aussi l'intérieur des pages

- **Un seul champ de saisie par page** (le champ AIME avec le cœur), toujours au même endroit : dans le hero. Les textarea et recherches secondaires disparaissent.
- **Un seul indicateur de progression** par écran (le composant `ProgressBar` partagé).
- **Une seule grammaire de hero** : titre, une phrase, le champ. Pas de double rangée de filtres ; les filtres passent derrière un bouton « Affiner ».
- **Le dock AI/ME** ne duplique plus des panneaux : il ouvre la section correspondante du tableau de bord.

## Premier écran d'un nouvel arrivant

Accueil : la vidéo, une phrase, le champ AIME, et trois boutons seulement — « Créer ma carte », « Voir le monde », « Voir autour de moi ». Le reste du site se découvre depuis là.

## Détails techniques

- `src/lib/aime/navigation.ts` : `PRIMARY_NAV` et `NAV_SECTIONS` réduits à la liste des 7 ; les autres liens passent dans un tableau `FOOTER_NAV` utilisé par `SiteFooter` uniquement.
- Redirections : dans `evenements.tsx`, `mon-evenement.tsx`, `registre.tsx`, remplacer le composant par `beforeLoad: () => { throw redirect({ to: ... }) }` ; conserver le fichier pour ne pas casser les URLs indexées.
- Pages absorbées : la route conserve son `head()` et rend une redirection vers `/tableau-de-bord?section=...` (la console lit déjà le paramètre `section`).
- `/monde` : les contenus `objectif`, `chemin`, `entraide`, `communs`, `bisous` deviennent des onglets pilotés par un search param, les fichiers de route redirigeant vers l'onglet correspondant.
- Fusion `/beta` + `/comment-ca-marche` + `/plan-du-site` en `/comment-ca-marche` avec chapitres ; les deux autres redirigent.
- Aucune migration base de données, aucun changement de logique métier, aucun finding de sécurité traité.

## Livraison

1. Menus réduits aux 7 portes (capsule, burger, pied de page).
2. Redirections des doublons et des pages absorbées.
3. Onglets de `/monde` et fusion des pages « comprendre ».
4. Nettoyage intérieur : un champ, une progression, un hero par page.
