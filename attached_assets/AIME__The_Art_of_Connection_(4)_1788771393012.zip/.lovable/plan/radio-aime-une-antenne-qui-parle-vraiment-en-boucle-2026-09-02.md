# Radio AIME — une antenne qui parle vraiment, en boucle

## Pourquoi vous n'entendez rien aujourd'hui

La radio ne joue que des entrées MusicBox publiques et validées du jour. Vérification faite sur les données réelles : cette liste est vide. Sans entrée en cours, l'animatrice n'a rien à présenter, donc elle ne parle jamais — le bouton Play s'allume sur un programme vide.

La solution n'est pas de corriger un bug isolé, mais de donner à la radio un **flux d'antenne permanent** : même sans aucune contribution, il y a toujours quelque chose à dire.

## Ce qu'on met en place

### 1. Une antenne continue, faite de segments

Au clic sur Play, un fil d'antenne s'enchaîne sans interruption. Chaque segment fait ~30 à 90 secondes :

- **Présentation d'un passage** — l'animatrice présente le morceau ou le message déposé, puis on écoute l'extrait (30 s).
- **Le récit AIME** — elle raconte le concept : les cartes, les mondes, la rencontre, la timeline, le Bureau. Un chapitre différent à chaque passage.
- **L'astuce / le tutoriel** — toutes les 10 minutes, un mode d'emploi court et concret (« comment créer sa carte », « à quoi sert le cœur », « comment lire sa timeline »).
- **La bienvenue** — toutes les 10 minutes également, l'animatrice accueille les personnes récemment arrivées : prénom ou nom d'affichage, ville, et l'intention qu'elles ont posée sur le site.

Quand la grille MusicBox est vide, les segments récit / astuce / bienvenue tournent seuls : l'antenne ne tombe jamais en silence.

### 2. Le bouton « Programme » sur la barre du bas

Un bouton ouvre la grille lisible :
- ce qui passe et ce qui suit,
- la liste des chapitres du mode d'emploi (avec ce qui a déjà été diffusé),
- les sujets de discussion à venir,
- les ambiances musicales disponibles,
- les bienvenues programmées.

### 3. La bienvenue des nouveaux membres

Toutes les 10 minutes, l'antenne pioche les personnes arrivées depuis le dernier passage et les présente : « Bienvenue à Claire, à Lille, qui arrive avec l'envie d'organiser un mariage en juin. »

Règle de respect appliquée : **seules les personnes visibles publiquement** (carte publiée ou intention publiée) passent à l'antenne. Les comptes privés ne sont jamais nommés.

### 4. Ce qu'on ne peut pas faire, dit franchement

Les extraits de 30 secondes ne peuvent pas provenir de Spotify, YouTube ou Deezer : leurs plateformes interdisent d'extraire l'audio. Concrètement :
- les fichiers déposés dans MusicBox sont lus normalement (extrait de 30 s),
- les liens plateformes gardent leur lecteur embarqué, et l'animatrice les **présente** au lieu de les diffuser.

C'est crédible en boucle, et légal.

## Détails techniques

- Nouveau `src/lib/aime/airplay.ts` : planificateur d'antenne. Il compose une file de segments typés (`passage | recit | astuce | bienvenue`) à partir de `program` (RadioProvider), d'un catalogue de chapitres récit/astuces, et des nouveaux membres. Cadence : astuce et bienvenue insérées tous les 10 min d'antenne écoulée.
- Nouveau server fn `src/lib/aime/airplay.functions.ts` : `speakSegment({ kind, cacheKey, brief })`. Même mécanique que `radio.functions.ts` (Gemini via l'AI Gateway pour le texte, `openai/gpt-4o-mini-tts` voix `shimmer`, stockage dans le bucket `musicbox`, cache dans `radio_announcements` par `cache_key`). Aucune table nouvelle : les clés de cache deviennent `recit:<slug>`, `astuce:<slug>`, `bienvenue:<userId>:<jour>`, l'existant `<entryId>` reste inchangé.
  Les segments récit/astuce sont générés une seule fois puis rejoués depuis le cache : coût IA négligeable en boucle.
- Nouvelle lecture publique des arrivants : requête sur `profiles` (créés récemment) jointe aux `intentions` publiées et aux `cards` publiées, pour ne retenir que les profils publiquement visibles. Lecture côté serveur avec le client publiable, projection limitée à `display_name`, `city`, texte d'intention.
- `RadioProvider.tsx` : le pilotage passe du « morceau en cours selon l'heure » à une **file de segments**. Ajout au contexte de `segment` (segment courant), `queue`, `skip()`, et conservation de `current` pour la compatibilité des écrans existants (`RadioPanel`, `MusicBox`). Un seul `HTMLAudioElement` enchaîne voix puis extrait (`onended` → segment suivant), extrait borné à 30 s.
- `RadioBar.tsx` : le panneau `programme` existant est enrichi (chapitres, astuces, bienvenues, ambiances) et le bouton devient visible directement dans la barre, à côté du titre en cours.
- Journalisation : chaque segment diffusé écrit une ligne `airplay_logs` (table déjà présente) pour la traçabilité, et `logUsage(..., "radio")` reste appelé sur les générations réelles.
- Autoplay navigateur : le premier son est déclenché par le clic sur Play, donc autorisé. Si le navigateur refuse quand même, un message clair invite à retoucher le bouton.
