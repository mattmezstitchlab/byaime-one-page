# Suite aux sept audits externes — plan de correction

Les sept rapports disent tous la même chose sous des angles différents : la promesse est forte, la démonstration est convaincante, mais la chaîne **récit → une seule ligne de temps → projet → action** n'est jamais dite avec des mots simples, et plusieurs pages publiques se terminent par un mur de connexion sans explication. Voici ce que je propose de corriger, par ordre d'impact.

## P0 — Ce qui casse le parcours

**1. Les portes fermées s'expliquent et se souviennent.**
« Mes projets » et « Mon espace » renvoient aujourd'hui vers la page de connexion sans un mot. Ils diront pourquoi (« Connectez-vous pour retrouver vos projets »), et ramèneront à la page demandée une fois connecté, au lieu de repartir de zéro.

**2. Une action claire après l'apparition de la ligne de temps.**
Sur l'accueil, une fois les moments posés : un seul bouton principal — « Ouvrir mon projet » — et un lien discret « Voir la démonstration ». Plus de destinations concurrentes.

**3. La phrase qui manque partout.**
Une seule ligne, répétée à l'identique sur l'accueil, la démonstration et un projet : « Votre récit devient une seule ligne de temps. Le projet, c'est cette même ligne, avec ses actions. »

**4. « AIME n'encaisse pas », écrit noir sur blanc.**
Partout où l'on voit paiements, facture ou budget engagé (démonstration et projet), une mention courte : AIME prépare et suit les paiements, mais ne les encaisse pas.

**5. Le titre de l'accueil ne correspond plus à la page.**
Le titre et la description partagés annoncent encore « le réseau des bonnes rencontres » alors que la page parle du mariage raconté. À réaligner.

## P1 — Ce qui trahit le chantier

**6. Le bandeau cookies passe devant la démonstration.** Il sera repositionné pour ne plus recouvrir la ligne de temps ni le bouton de lecture, et mémorisé.

**7. Restes de code sur l'accueil.** Deux longs blocs de contenu (témoignages, questions fréquentes) sont encore dans le fichier de l'accueil sans jamais être affichés — à supprimer.

**8. Un seul nom pour la lecture.** Même libellé et même icône pour le bouton de lecture sur l'accueil, la démonstration et les projets.

**9. Le compteur « À l'écran · 0 » du Réseau** s'affichera « Chargement… » tant que la carte n'a pas fini, pour ne plus ressembler à une absence de résultats.

**10. Étiquettes des boutons du haut.** Les boutons en icône seule (radio, réparation) reçoivent un intitulé visible au survol et pour les lecteurs d'écran.

## P2 — Référencement et guides

**11. Les pages de guides gagnent un lien de retour au parcours** (« Raconter mon projet »), pour ne plus être un annuaire isolé.
**12. Descriptions de pages** de Projets, Réseau et Guides revues pour mentionner la ligne de temps unique.
**13. Le badge d'édition visible sur le site publié** : je peux le masquer si vous le souhaitez — dites-le-moi.

## Hors périmètre

`/bureau*`, les règles de sécurité de la base, les pages légales. Aucune suppression de page dans ce lot.

## Détails techniques

- `src/routes/projets.index.tsx` et `src/routes/mon-espace.tsx` : `navigate({ to: "/auth", search: { next: pathname } })` ; `auth.tsx` accepte déjà `next` et redirige dessus après session.
- `src/routes/index.tsx` : suppression des constantes `VOICES` et `FAQ` non utilisées, refonte du `head()` (titre, description, og/twitter) sur la promesse mariage.
- `HomeJourney.tsx` : écran final réduit à une action primaire + lien démo ; ligne d'explication sous la ligne de temps.
- `ProjectStage.tsx` : mention « AIME n'encaisse pas » près des chips financiers ; même libellé de lecture que `PlayButton`.
- `CookieBanner.tsx` : position non bloquante (bas, largeur limitée, `z-index` sous les panneaux).
- `reseau.tsx` : état de chargement du compteur.
- Typecheck après chaque lot, contrôle Playwright en 1280 px et 390 px sur `/`, `/demo/mariage`, `/projets`, `/reseau`, `/guides`.
