# AIME — L'entremetteuse au centre, page Rencontre réinventée, et feuille de route en 3 passes

## 1. Accueil : le bloc entremetteuse dans le hero

Le hero devient une respiration : beaucoup de blanc, et au centre un unique champ de saisie.

- Le grand titre descend sous le bloc de saisie (il devient un sous-titre calme, plus petit, centré).
- Au centre : un champ « Que souhaitez-vous vivre ? » posé sur du vide ivoire, cadre très fin, ombre diffuse, curseur clignotant. Aucun bouton visible tant que rien n'est écrit.
- **Effet wow à la frappe** : dès le 3e caractère, des cartes du registre remontent en douceur autour du champ (apparition décalée, léger flou → net). Elles se filtrent en direct pendant la frappe, sans appel IA (recherche locale sur nom, catégorie, ville, mots-clés, univers). Les cartes non pertinentes s'effacent, les nouvelles glissent en place.
- Quand la phrase est complète, un bouton « Composer la rencontre » apparaît ; il envoie vers /rencontres avec l'intention déjà écrite (aucune ressaisie).

## 2. L'agent entremetteuse : une voix, pas un chatbot

Un ton défini une fois pour toutes, appliqué à toutes les réponses IA du site : tendre, bienveillant, souvent drôle, parfois franchement taquin quand la demande est floue ou irréaliste — jamais commercial, jamais robotique.

- Elle parle des gens, pas des « prestataires » : « Tony photographie les mariages comme on écoute quelqu'un. Il est libre ce samedi-là, ce qui n'arrivera plus avant octobre. »
- Elle fait le lien dans les deux sens : ce que la carte A apporte à B, et ce que B apporte à A. C'est le principe GIGI : deux présentations, une seule rencontre.
- Elle signale ce qui coince avec humour plutôt que de l'enterrer (« un château pour 40 000 € et un budget de 3 000 €, on va discuter »).
- Réponse en flux : le texte s'écrit progressivement pendant que les cartes se posent.

## 3. Page Rencontre : audit et refonte

Aujourd'hui, /rencontres est un formulaire (textarea + filtres + résultats). C'est utile mais froid, et c'est le doublon exact du nouveau bloc d'accueil.

Ce que je propose : /rencontres devient **la page d'intention vivante** du réseau, pas un moteur de recherche. Trois modes sur une même page, un sélecteur discret en haut.

**Mode Intention** (par défaut) — l'intention écrite en accueil arrive ici. L'entremetteuse répond en texte, présente les cartes une par une avec sa raison, propose « Aimer », « Discuter », « Créer l'événement ». On peut lui répondre, affiner, dire non — la conversation continue et les compositions se recomposent.

**Mode Flux** — le mur des intentions ouvertes des autres membres (« Je cherche quelqu'un pour transmettre le saxophone », « Je livre Lille → Paris jeudi », « Besoin d'un coup de main déménagement samedi »). On répond directement à une intention : entraide, transmission, livraison, organisation. C'est ce qui rend le réseau bidirectionnel — aujourd'hui tout part de l'utilisateur, rien ne vient vers lui.

**Mode Carte (MAP)** — géolocalisation des cartes et des intentions autour de soi. L'entremetteuse trace des **liens en pointillé animés** entre les points qu'elle juge compatibles ; on tape un lien pour lire pourquoi. Filtres par univers et par rayon, boutons d'action au tap : Aimer, Discuter, Proposer mon aide, Ajouter à mon événement.

Sur le design : je ne reprends pas les captures bleues. On reste sur l'ivoire AIME, texte noir profond, verre léger — les pointillés et la carte s'y intègrent en niveaux de gris chauds avec un seul accent.

Fonctionnalités qu'aucun concurrent n'a réunies, et qui tiennent debout ici :
- La **présentation croisée** (l'IA plaide pour chacun auprès de l'autre) plutôt que la liste de résultats.
- Le **lien en pointillé** comme objet cliquable et explicable, sur la carte comme dans les compositions.
- L'intention **datée** : une intention porte une date, donc devient un événement dès qu'on l'accepte, sans ressaisie.
- La **réciprocité** : à chaque intention, l'IA suggère aussi ce que vous pourriez offrir en retour.

## 4. Audit du site : ce qu'il reste à faire

Urgent (bloque l'usage réel)
- Aucune vraie porte d'entrée : l'accueil ne mène pas à un premier geste clair. Le nouveau hero règle ça.
- La navigation compte 10 entrées de même poids — illisible en mobile. À réduire à 5 (Accueil, Rencontres, Registre, Mon espace, Messages), le reste passant en sous-pages.
- Les intentions ne créent rien tant qu'on ne va pas manuellement dans /mon-evenement : le chaînage intention → événement doit être automatique.
- Aucune notification : une intention reçue ou un message ne se voient nulle part sans ouvrir la page.
- Les envois d'invitation par e-mail ne partent pas (lien copiable seulement).

Important
- Aucun avis n'est rédigeable depuis l'app (la table existe, pas le formulaire).
- Pas de galerie multi-photos par carte.
- Paiement réel absent (les paiements sont déclaratifs).
- Recherche globale inexistante.

Confort
- États vides et de chargement inégaux selon les pages.
- Accessibilité clavier de la timeline et de la pile de cartes.

## Les 3 passes vers un site fini

**Passe 1 — Le cœur (cette étape)**
Hero entremetteuse avec cartes en direct, voix de l'agent, /rencontres en mode Intention conversationnel, navigation réduite à 5 entrées, chaînage intention → événement.

**Passe 2 — Le réseau vivant**
Mode Flux (intentions publiques et réponses), mode MAP avec liens en pointillé, notifications en tête de navigation, rédaction d'avis, recherche globale.

**Passe 3 — L'opérationnel**
Envoi réel des invitations par e-mail, paiement réel, galerie multi-photos, modération des demandes de profil, polissage des états vides/chargement et de l'accessibilité, SEO et publication.

## Détails techniques

- Nouveau composant `IntentionHero` (accueil) : filtrage local sur les cartes déjà chargées par `cardsQuery`, animations Motion en `layout` + `AnimatePresence`, sans appel serveur pendant la frappe.
- Navigation vers `/rencontres` avec l'intention en `search param`, lue par la page.
- `src/lib/aime/ai.functions.ts` : extraction du prompt système dans un module `persona` partagé, ajout des présentations croisées (`for_you` / `for_them`) au schéma JSON, passage en réponse streamée pour l'écriture progressive.
- `/rencontres` : ajout d'un état de mode (`intention` | `flux` | `map`) ; passe 1 ne livre que `intention`, les deux autres arrivent en passe 2.
- Flux d'intentions publiques : nouvelle table `intentions` (auteur, texte, univers, ville, date visée, statut) + réponses, RLS lecture publique / écriture propriétaire, GRANT explicites.
- Mode MAP : coordonnées à ajouter sur `cards` (lat/lng) et géocodage des villes existantes ; liens en pointillé en SVG au-dessus de la carte.
- Aucune modification du design system existant hormis les tokens nécessaires au hero.
