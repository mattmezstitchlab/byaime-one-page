# AIME — Phase 0.5 : contrat d'architecture

Aucun fichier applicatif n'est modifié. Ce document est le contrat de référence
avant tout nettoyage.

## 01 — Architecture actuelle

55 fichiers de route, dont **13 ne sont déjà que des redirections** :
`/carte/:id/timeline`, `/chemin`, `/communs`, `/devis/:cardId`, `/evenement/*`,
`/evenements`, `/ma-carte`, `/monde`, `/objectif`, `/projets/nouveau`, `/registre`,
`/rencontres`, `/tableau-de-bord`. L'audit précédent classait `/rencontres`,
`/registre`, `/communs`, `/objectif`, `/evenements`, `/devis/:cardId` et
`/projets/nouveau` comme des pages à archiver : **c'était faux, elles n'existent plus
comme pages**. Correction actée. Reste un défaut réel : `/registre → /monde → /reseau`
est une double redirection.

Espaces réellement en place :

```text
ACCUEIL /            récit + timeline vitrine (statique)
DÉMO    /demo/mariage  ProjectStage sur données fictives
PROJET  /projets/:id   ProjectStage sur WorldProject  ← le bon modèle
        + 4 sous-pages verticales (participants, paiements, facture, musicbox)
COMPTE  éclaté sur 6 routes : /ma-page /parametres /credits /aimes-recues
        /messages /projets  — aucune ne joue le rôle de seuil
PUBLIC  /carte/:id (fiche + sa propre timeline persistée), /reseau, /guides
BUREAU  5 routes, périmètre gelé
```

## 02 — Architecture cible

Les cinq espaces proposés sont confirmés, avec une correction : **le Studio n'est pas
un sixième espace**, c'est une couche transverse. Et **la page publique `/carte/:id`
n'appartient pas à Mon Espace** : c'est un objet du Réseau que le compte possède.

```text
INTENTION → MONDE (projet) → SOURCE UNIQUE (WorldProject) → VUES → ACTIONS

AIME
├── ACCUEIL          porte de création : récit → IA → proposition → validation
├── MON ESPACE       seuil du compte (privé)
├── PROJET / MONDE   scène unique : film + timeline + calques + cœur
├── RÉSEAU           trouver ce qui manque (global et contextuel)
├── BUREAU           espace professionnel, frontière étanche
└── STUDIO           couche d'édition contextuelle, présente partout
```

## 03 — Mon Espace

**Aujourd'hui.** `useMyPage` cherche ou crée une carte `personne` puis navigue vers
`/carte/:id`, et ouvre le Studio si la fiche est incomplète. Le bouton « Mon espace »
mène donc à une page publique d'annuaire. `/ma-page`, `/profil`, `/tableau-de-bord`,
`/ma-carte` convergent tous vers ce même comportement.

**Diagnostic.** Incohérence architecturale confirmée : le compte n'a pas de seuil, et
sa présence publique lui sert de substitut.

**Cible.** Une route `/mon-espace` (ou la réaffectation de `/ma-page`) qui n'affiche
que ce qui appartient au compte :

| Bloc | Source actuelle | Origine |
|---|---|---|
| Mes projets / mondes | `project_snapshots`, `events` | `/projets` |
| Mes Aimes reçues | `aimes` | `/aimes-recues` |
| Mes messages (aperçu) | `threads` | `/messages` |
| Mes crédits | `credit_ledger` | `/credits` |
| Ma page publique (aperçu + Modifier) | `cards` | `/carte/:id` |
| Réglages | `profiles` | `/parametres` + Studio ME |

Séparation nette : **compte privé** = projets, Aimes, messages, crédits, réglages,
identité. **Présence publique** = `/carte/:id`, visible de tous, éditée depuis le
Studio, jamais confondue avec le seuil.

Ne doit jamais entrer dans Mon Espace : timeline, prestataires, documents, budget,
musique, coordination — tout cela appartient au projet.

## 04 — Studio AI + ME

**Aujourd'hui.** Overlay unique monté dans `AppShell`. Onglet AI = assistant
(`AiPanel`). Onglet ME = `PageSetup` (édition de la carte) + `SettingsSection`
(réglages compte, duplique `/parametres`) + `MePanel`.

**Répartition cible.**

| Fonction | Reste au Studio | Part vers |
|---|---|---|
| `PageSetup` — éditer la page publique | oui, en mode « page » | — |
| `AiPanel` — assistant | oui, mais contextualisé sur l'objet regardé | — |
| `SettingsSection` — réglages compte | non | Mon Espace |
| `MePanel` — inventaire personnel | non | Mon Espace |
| Édition du projet | à ajouter (mode « projet ») | s'appuie sur `HeartAgent` |

Le Studio devient : *« j'édite ce que je regarde »*. Un seul composant, un contexte
injecté (`page` | `projet` | `element`). Il ne doit pas exister deux éditeurs de
projet : le cœur (`HeartAgent`) est déjà l'éditeur de la timeline, le Studio en mode
projet doit l'englober ou le déléguer, pas le doubler.

## 05 — « Modifier » contextuel

| Contexte | Libellé | Ouvre |
|---|---|---|
| Ma page publique | Modifier ma page | Studio, mode page |
| Projet | Modifier le projet | Studio, mode projet |
| Repère de timeline | Modifier ce repère | bulle d'édition en place |
| Mon Espace | Réglages | section réglages |
| Page d'un tiers | *pas de bouton* | — |

Le libellé nu « Modifier » disparaît.

## 06 — Projet / Monde

`ProjectStage` est déjà la bonne réponse : un film, une timeline, des fenêtres
Tout/Avant/Pendant/Après, des calques, le cœur. Il est partagé par `/demo/mariage` et
`/projets/:id`.

Manque : les 4 sous-pages verticales (`participants`, `paiements`, `facture`,
`musicbox`) lisent Supabase en direct, hors WorldProject. Ce sont les dernières
sources parallèles du projet. Cible : elles deviennent des calques / panneaux de la
scène, leurs routes restent en redirection.

**Démo vs projet réel.** `/demo/mariage` doit redevenir strictement une vitrine
publique en lecture seule (`lifecycle: "demo"`). Le résultat d'un récit utilisateur ne
doit plus transiter par cette URL : cible `/projets/brouillon` (ou
`/projets/:id` créé immédiatement en statut brouillon), puis activation. C'est la
correction la plus visible du parcours.

**Création unique.** `/projets/nouveau` est déjà une redirection vers
`/projets?nouveau=1`, mais `ProjectForm` reste monté dans `/projets` : c'est là que
vit le second système de création. Cible : `/projets` ne fait que lister et pointer
vers l'accueil pour créer ; `ProjectForm` conservé au plus comme saisie de secours,
sans chemin de données propre.

## 07 — Timeline

| Système | Nature | Source ? | Projection ? | Ancien ? | Action |
|---|---|---|---|---|---|
| `WorldProject` (`world/types.ts`) | modèle | **oui** | non | non | source unique officielle |
| `deriveTimeline` (`world/derive.ts`) | fonction pure | non | oui | non | conserver, unique projecteur |
| `card_timeline_entries` (table) | persistance | oui (pour les cartes) | non | partiellement | conserver, mais devenir une *entrée* du WorldProject, pas un modèle rival |
| `cardTimeline.ts` | agrégation Supabase | oui de fait | non | non | à ramener sous `deriveTimeline` |
| `showcaseTimeline.ts` | données statiques | oui (factices) | non | oui | remplacer par une vraie génération sur l'accueil |
| `retroplanning.ts` | génération de tâches | non | oui (enrichissement) | non | conserver : produit des objets du WorldProject |
| `timelineAutomation.ts` | analyse / alertes | non | oui | non | conserver |

Deux vraies ruptures : `/carte/:id` possède un modèle persistant concurrent, et
l'accueil montre une timeline factice alors que c'est l'argument produit.

## 08 — Messages

Un seul modèle relationnel existe déjà côté base : `threads`, `thread_members`,
`messages`, `thread_settings`. `/devis/:cardId` n'est plus qu'une redirection vers
`/carte/:id` ; le système de devis vit dans `quotes` / `quote_items`, distinct mais
légitime.

Le seul doublon réel est `project.messages` dans le WorldProject : une liste portée
par le modèle projet, sans lien avec `threads`. Cible : un fil par projet dans
`threads`, la scène du projet en affiche une fenêtre filtrée. `project.messages`
devient une projection de lecture, jamais une écriture indépendante.

## 09 — Routes : décision par route

**CONSERVER** — `/`, `/projets/:id`, `/projets`, `/reseau`, `/messages`, `/carte/:id`,
`/auth`, `/guides`, `/guides/:metier/:ville`, `/comment-ca-marche`, `/legal/:doc`,
`/invitation`, `/demande-profil`, `/intermittent`, `/ambassadeur`, `/beta`,
`/bureau/*` (5).

**TRANSFORMER** — `/ma-page` (devient Mon Espace), `/demo/mariage` (vitrine en lecture
seule stricte), `/` (timeline réelle au lieu de la vitrine statique), `/reseau`
(mode contextuel « pourvoir une place »).

**FUSIONNER** — `/parametres`, `/credits`, `/aimes-recues` dans Mon Espace ;
`/projets/:id/{participants,paiements,facture,musicbox}` dans les calques de la scène.

**REDIRIGER (déjà fait, à garder)** — les 13 redirections existantes ; corriger
`/registre` pour viser `/reseau` directement.

**ARCHIVER** — `/entraide`, `/saisons`, `/frequence/:id`, `/profil` (doublon de
`/ma-page`), `/plan-du-site` (outil interne exposé en public).

**INTERNE / NOINDEX** — `/cockpit`, `/admin/enrichissement`, `/plan-du-site`.

## 10 — Navigation cible

```text
Capsule (4 portes)   Accueil · Réseau · Mon Espace · Bureau
Contexte             cœur (Aimes) · radio · langue
Dans un projet       Tout / Avant / Pendant / Après + calques (pas de menu global)
Pied de page         Comprendre AIME · Démo · Guides · Programme bêta · Mentions
```

Le pied de page passe de 13 à 5 liens. Tout ce qui est retiré reste atteignable
depuis Mon Espace ou le projet.

## 11 — Matrice Compte / Projet / Moteur / Réseau / Bureau

| Fonction | Compte | Projet | Moteur AIME | Réseau | Bureau |
|---|:--:|:--:|:--:|:--:|:--:|
| Identité | ✓ | | | | ✓ |
| Page publique | ✓ (possède) | | | ✓ (affiche) | |
| Projets / mondes | ✓ (liste) | ✓ (contenu) | | | ✓ (dossiers) |
| Timeline | | ✓ | ✓ (dérive) | | |
| Personnes | | ✓ | | ✓ (trouve) | ✓ (membres) |
| Lieux | | ✓ | | ✓ | |
| Prestataires | | ✓ | | ✓ | ✓ |
| Documents | | ✓ | ✓ (lit) | | ✓ |
| Budget | | ✓ | ✓ (alerte) | | ✓ |
| Musique | | ✓ | ✓ (radio) | | |
| Messages | ✓ (boîte) | ✓ (fil du projet) | ✓ (copilote) | | |
| Aimes | ✓ | | | ✓ | |
| Crédits | ✓ | | ✓ (consomme) | | |
| Paramètres | ✓ | | | | ✓ |
| IA / automatisations | | | ✓ | | |
| Recherche | | | | ✓ | |
| Radio | | ✓ (playlist) | ✓ | | |
| Coordination | | ✓ | | | ✓ |

## 12 — Matrice des actions

| Action | Mon Espace | Projet | Réseau | Studio |
|---|:--:|:--:|:--:|:--:|
| Voir ma page publique | ✓ | | ✓ | |
| Modifier ma page | ✓ (entrée) | | | ✓ |
| Créer un projet | ✓ (entrée) | | | |
| Ouvrir un projet | ✓ | | | |
| Modifier le projet | | ✓ | | ✓ |
| Modifier la timeline | | ✓ | | ✓ |
| Ajouter un repère | | ✓ | | ✓ |
| Lire un document | | ✓ | | ✓ |
| Chercher un prestataire | | ✓ (depuis une place vide) | ✓ | |
| Pourvoir une place | | ✓ | ✓ | |
| Envoyer un Aime | | | ✓ | |
| Voir les messages | ✓ | ✓ (fil du projet) | | |
| Payer / engager | | ✓ | | |
| Réglages du compte | ✓ | | | |
| Crédits | ✓ | | | |

## 13 — Contradictions restantes

1. « Mon espace » ouvre une fiche publique.
2. « Modifier » édite la page perso même sur un projet.
3. Réglages présents deux fois (`/parametres` + Studio ME).
4. `ProjectForm` = second chemin de création.
5. Un projet réel naît sous une URL « demo ».
6. Deux modèles de timeline persistants (carte vs projet).
7. Timeline d'accueil factice.
8. `project.messages` hors du système `threads`.
9. `/registre` redirige vers une redirection.
10. `/profil` et `/ma-page` font la même chose.
11. `/plan-du-site` (outil de diagnostic interne) est public et indexable.

## 14 — Règles d'architecture à verrouiller

1. Une donnée métier = une source de vérité (WorldProject pour le projet).
2. Une timeline = une seule timeline, projetée par `deriveTimeline`.
3. Une vue = une projection ; elle ne persiste jamais de donnée métier.
4. Une conversation = `threads` ; aucun second système de messages.
5. Mon Espace = compte. Projet = monde opérationnel. Jamais l'inverse.
6. Réseau = recherche et connexion, jamais un stockage parallèle.
7. Studio = édition contextuelle de l'objet regardé.
8. Une fonction = un endroit évident ; un libellé dit ce qu'il fait.
9. Une ancienne route = redirection avant suppression, jamais de double saut.
10. Un objet public (`carte`) n'est jamais le seuil d'un compte.
11. Une démo est marquée `lifecycle: "demo"` et n'écrit jamais en base.
12. Le Bureau garde sa frontière : aucune dépendance nouvelle dans les deux sens.

## 15 — Plan de migration (ordre corrigé)

L'ordre proposé est bon à une inversion près : **la timeline unique doit passer avant
le Studio contextuel**, parce que le Studio en mode projet éditera précisément cette
timeline. Et le nettoyage des routes mortes peut se faire tôt, il est sans risque.

- **Phase 1 — Mon Espace.** Créer le seuil du compte, y déplacer crédits, Aimes,
  réglages, aperçu de la page. « Mon espace » n'ouvre plus `/carte/:id`.
- **Phase 2 — Projet source unique.** Absorber les 4 sous-pages en calques ;
  `/projets/:id` devient le seul lieu opérationnel.
- **Phase 3 — Création unique.** Récit d'accueil → brouillon → `/projets/:id` ;
  `/demo/mariage` redevient une vitrine ; `ProjectForm` neutralisé.
- **Phase 4 — Timeline unique.** `/carte/:id` et l'accueil passent par
  `deriveTimeline` ; `showcaseTimeline` retiré.
- **Phase 5 — Studio contextuel.** Modes page / projet, libellés explicites, réglages
  sortis.
- **Phase 6 — Réseau contextuel.** Entrée « pourvoir une place » depuis la timeline,
  retour au projet.
- **Phase 7 — Messages unifiés.** Un fil par projet dans `threads`.
- **Phase 8 — Navigation.** Capsule à 4 portes, pied de page à 5 liens.
- **Phase 9 — Nettoyage.** 9 composants orphelins, routes archivées, `/registre`
  corrigé, `noindex` sur les outils internes.
- **Phase 10 — Tests de bout en bout** et vérification finale.

## 16 — Risques et dépendances

- **Phase 1 → tout le reste** : déplacer « Mon espace » change le point d'entrée après
  connexion ; à vérifier sur mobile et sur le premier login (création de la carte).
- **Phase 2** : les 4 sous-pages contiennent des écritures réelles (paiements,
  participants) ; migration à faire calque par calque, avec redirections, sinon perte
  de fonction.
- **Phase 4** : `card_timeline_entries` est persistée et utilisée par des cartes
  existantes ; il faut un adaptateur avant de brancher `deriveTimeline`, pas un
  remplacement sec.
- **Phase 7** : `project.messages` alimente déjà des affichages ; migrer en lecture
  d'abord, écriture ensuite.
- **SEO** : `/demo/mariage`, `/carte/:id`, `/guides/*` sont indexés ; aucune de ces
  URL ne doit changer.
- **Bureau** : gelé. Aucune phase ne doit y toucher ; si une dépendance apparaît, elle
  devient un point d'arrêt à arbitrer.
- **Pas de suppression** avant la phase 9, et seulement sur ce qui est vérifié
  inatteignable.
