# Nettoyage du Monde AIME : trois vues, une vignette directe, des filtres mariage

## 1. Les éphémères disparaissent

La fonction est retirée partout : bouton « Publier un éphémère » du bouton +, pastille rouge « N éphémères » en bas de carte, lecteur plein écran, anneaux éphémères sur les marqueurs de la carte, entrées dans le menu de création et le dock. Les données déjà en base ne sont pas touchées, simplement plus affichées.

## 2. Trois vues, exclusives : Carte · Liste · Grille

Le mode Mosaïque disparaît (doublon de la Grille). Les trois vues restantes deviennent un vrai sélecteur : une seule active à la fois, mémorisée dans l'URL. La Carte reste la vue par défaut, la Liste sert à comparer, la Grille reste la grille du Monde AIME.

Autre reste inutile supprimé au passage : le plateau « Cartes retenues » en bas à gauche (vestige des compositions, qui ne mènent plus nulle part).

## 3. La vignette au survol devient l'action directe

Au survol d'un marqueur, la petite carte sombre reste — c'est le geste différenciant, le même que sur la timeline. Mais elle va droit au but :

- « Voir la carte » est supprimé (plus d'écran intermédiaire).
- Restent : **Voir la page**, **Devis**, **Dispos**, **Écrire**.
- Un clic sur le marqueur lui-même ouvre directement la page de la carte.

## 4. Filtres remis à jour, ciblés mariage

Le panneau Filtres passe de murs de pastilles à des menus déroulants clairs :

- **Univers** (Mariage par défaut sur cette page)
- **Domaine prestataire** : Lieu de réception, Traiteur, Photographe, Vidéaste, Musique / DJ, Fleuriste, Décoration, Coiffure & maquillage, Pâtisserie, Officiant, Transport, Hébergement — la liste des rôles mariage déjà définie dans le projet.
- **Ville**
- **Fraîcheur** (Tout / 24 h / 7 jours)

Les filtres actifs restent affichés en pastilles retirables sous le champ de recherche, et « Effacer les filtres » reste disponible.

## 5. On ne crée plus « une carte », on crée « sa page »

Le vocabulaire s'aligne : « Créer ma carte » devient « Créer ma page » dans le bouton + de la carte et les libellés associés de cette page. Et en haut à droite, **Mon espace** ouvre directement sa page publique (`/carte/<son id>`) quand elle existe ; sinon il mène à l'éditeur pour la créer.

## Détails techniques

- `src/routes/reseau.tsx` : `vues` (multi) devient `vue` exclusive (`carte|liste|grille`, fallback `carte`), avec compatibilité de l'ancien paramètre ; suppression de `mosaique`, du plateau `trayCards`, de `StoryComposer`, `StoryViewer`, `activeStoriesQuery`, du compteur et du sheet de publication ; panneau Filtres reconstruit avec `Select` (shadcn) alimenté par `universesQuery`, `WEDDING_ROLES` de `src/lib/aime/presets/mariage.ts` et les villes déduites des cartes.
- `src/components/aime/CardPreview.tsx` : retrait du bouton « Voir la carte » et de la prop `onOpenCard` dans `CardGlance` ; « Ouvrir » devient « Voir la page ».
- `src/components/aime/CardsMap.tsx` : retrait des anneaux/marqueurs éphémères.
- `src/components/aime/AimeDock.tsx`, `createEntries.tsx`, `RoadmapPanel.tsx`, `tense.tsx`, `layers.ts` : retrait des entrées éphémères.
- Suppression des fichiers `StoryComposer.tsx`, `StoryViewer.tsx`, `src/lib/aime/stories.ts`.
- `src/components/aime/AppShell.tsx` : « Mon espace » pointe vers `/carte/$id` via `myCardQuery`, repli sur `/ma-carte`.
- Aucune modification de base de données, de RLS ni de route supprimée.
