# Une seule source de vérité : Mon espace

## Ce qui disparaît

**La page « Mes projets »**
Elle affiche la même liste que la section « Mes mondes » de Mon espace. On la supprime : l'adresse existante renvoie désormais vers Mon espace, et le lien « Mes projets » du menu du haut devient « Mon espace ». La page d'un projet (sa ligne de temps) reste intacte.

**La page « Messages »**
Les échanges se lisent et se répondent déjà sur la ligne de temps. On supprime la page ; ses conversations réapparaissent dans une section « Échanges » de Mon espace (liste des fils, ouverture, réponse, nouvelle conversation). L'ancienne adresse renvoie vers cette section.

**Les quatre sous-pages d'un projet**
« Facture », « Paiements », « Participants », « Musicbox » font double emploi avec les actions déjà intégrées à la bulle de la ligne de temps (devis, paiement reçu, rattacher une personne, musique). Elles sont supprimées et leurs adresses renvoient vers la page du projet.

**Les coquilles de redirection déjà vides**
`/evenements`, `/evenement/...`, `/monde`, `/registre`, `/ma-page`, `/projets/nouveau` ne contiennent plus rien d'autre qu'un renvoi. On les conserve telles quelles pour ne pas casser les liens déjà partagés — aucun travail dessus.

Ce qu'on garde : l'accueil, le Réseau, la page d'une personne, la page d'un projet, Mon espace, le Bureau, les crédits, l'invitation, la démo mariage, les guides et les pages légales.

## Ce que devient Mon espace

Une seule porte après l'accueil, avec dans l'ordre : Mes mondes (avec bouton « Ouvrir un nouveau monde » qui ramène à l'accueil), Ce qui m'attend, Échanges (nouveau), Aimes reçues, Ma page publique, Mon bureau, Réglages.

## Suite de l'accueil

- Le récit libre devient le chemin principal : un seul champ « Racontez votre mariage… », le questionnaire pas-à-pas passe en repli discret (« Répondre à quelques questions plutôt »).
- Pendant la frappe, la ligne de temps sous l'en-tête se remplit point par point, avec le compteur de moments déjà posés — c'est la démonstration du produit, rien d'autre à lire sur la page.
- Une seule action en bas : « Ouvrir mon projet ».
- Les blocs restants qui ne servent pas cette démonstration sont retirés de l'accueil. integrer le plan du site en dessous dans l'accueil, donc le site map systeme nerveux pour comprendre le site actuel et observer ce qu'il reste à faire

## Détails techniques

- `src/routes/projets.index.tsx` → redirection 301 vers `/mon-espace` ; `HEADER_NAV` dans `src/lib/aime/navigation.ts` pointe `/mon-espace`.
- `src/routes/messages.tsx` → redirection 301 vers `/mon-espace#echanges` ; le corps de la page (liste de fils, lecteur, composeur, nouvelle conversation) est extrait dans `src/components/aime/espace/ThreadsSection.tsx` et monté dans `mon-espace.tsx`.
- Suppression de `projets.$id.facture.tsx`, `projets.$id.paiements.tsx`, `projets.$id.participants.tsx`, `projets.$id.musicbox.tsx` ; leurs adresses redirigent vers `/projets/$id`. Les liens correspondants sont retirés de `ProjectPanels.tsx`, `WeddingPanels.tsx`, `FolderLinks.tsx`, `AiPanel.tsx`, `CardPreview.tsx`, `carte.$id.tsx`, `mon-espace.tsx`.
- `HomeJourney.tsx` : `free` devient l'état initial, le questionnaire reste accessible en repli ; nettoyage des sections non liées à la génération de la ligne de temps.
- Aucune modification des routes `/bureau` ni des fonctions `SECURITY DEFINER`.