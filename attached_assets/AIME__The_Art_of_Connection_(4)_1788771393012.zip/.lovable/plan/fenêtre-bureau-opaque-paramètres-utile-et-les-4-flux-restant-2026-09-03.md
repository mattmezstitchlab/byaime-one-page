# Fenêtre Bureau opaque, Paramètres utile, et les 4 flux restants

## 1. La fenêtre « Le Bureau » en blanc plein

Aujourd'hui la fenêtre est translucide (fond à 85 % + flou), donc le fond d'écran choisi transparaît à travers le contenu et gêne la lecture.

- Fond de la fenêtre passé en surface pleine (card, 100 %), sans flou derrière le contenu.
- Le fond d'écran reste visible tout autour de la fenêtre : c'est lui qui donne l'effet « bureau ».
- Les petits éléments flottants (bouton et panneau du sélecteur de fond) restent légèrement vitrés, car ils sont posés sur l'image.

## 2. Paramètres : une page qui empêche les erreurs

Aujourd'hui la page ne contient que la langue et l'accessibilité, et ces choix ne vivent que dans le navigateur : changer d'appareil les perd, alors que le compte possède déjà les champs `locale`, `a11y`, `city`, `lat/lon`, `geo_consent`, `radio_radius_km`.

Nouvelle page, en cinq blocs :

**a) Diagnostic — « Ce qui pourrait mal fonctionner »**
Une liste de contrôles réels, chacun avec un état (vert / à faire) et un lien direct :
- profil : nom affiché et ville renseignés ;
- carte : au moins une carte, et carte publiée (sinon elle n'apparaît nulle part) ;
- localisation : consentement + coordonnées connues (sinon « places à proximité », Monde et Saisons ne peuvent pas trier) ;
- son : autorisation de lecture audio du navigateur (sinon la Radio reste muette) ;
- Bureau : documents à vérifier en attente ;
- crédits : solde disponible avant les appels à l'IA.

**b) Compte et lieu** — nom affiché, ville, portée par défaut (ma ville / 40 km / 100 km / ma région / partout), consentement de géolocalisation révocable en un clic. Enregistré sur le compte.

**c) Langue et accessibilité** — les réglages actuels, mais enregistrés à la fois sur l'appareil et sur le compte, avec reprise automatique à la connexion.

**d) Radio et son** — activer/couper la voix de l'animatrice, volume, rayon d'écoute, bouton « Tester le son » qui débloque l'audio du navigateur.

**e) Confidentialité et données** — visibilité de la carte, consentement cookies/mesure d'audience modifiable, export de mes données (JSON), effacement des réglages locaux.

Chaque réglage indique en une phrase ce qu'il évite comme problème.

## 3. Les 4 flux encore rouges du système nerveux

- **Contribution → carte du Monde** : une contribution enregistrée crée un repère daté sur la timeline de la carte concernée, et fait bouger sa fréquence.
- **Communs → registre** : un moyen mis en commun apparaît comme case disponible dans Le Monde AIME, avec sa ville et sa portée.
- **Projets → veille** : les dates de projets et d'événements alimentent les alertes de la page Chemin (échéance proche, place non pourvue, document manquant).
- **Bibliothèque → rémunération** : reste rouge tant qu'aucun paiement réel n'existe ; on le rend honnête en affichant le dû calculé, l'état de documentation des ayants droit et la limite d'écoute à 30 s, sans prétendre payer.

## Détails techniques

- `BureauWindow.tsx` : `bg-background/85 backdrop-blur-2xl` → surface opaque ; sélecteur inchangé.
- `parametres.tsx` réécrite : `useQuery(profileQuery)` + mutations sur `profiles` (`display_name`, `city`, `locale`, `a11y`, `geo_consent`, `lat`, `lon`, `radio_radius_km`) ; réutilisation de `useI18n`, `RangePicker`, `proximity.ts`, `wallpapers.ts`, `useRadio`.
- Diagnostic : requêtes existantes (`myCardsQuery`, `documentsQuery`, `creditLedgerQuery`) + test `AudioContext.state` pour le son.
- Contribution → timeline : insertion dans `card_timeline_entries` + recalcul `timeline_effects` lors de `addContribution`.
- Communs → registre : lecture de `commons_items` dans la source du Monde AIME avec filtre de proximité.
- Veille : agrégation des dates de `events`/`projects` dans les alertes de `/chemin`.
- Mise à jour des arêtes correspondantes dans `systemMap.ts` seulement après vérification réelle.
- Aucun des sept avertissements de sécurité préexistants n'est touché ; `geo.ts` reste intact.
