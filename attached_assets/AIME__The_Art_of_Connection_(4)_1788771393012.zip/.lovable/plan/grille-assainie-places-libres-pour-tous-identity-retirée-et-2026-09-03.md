# Grille assainie, places libres pour tous, IDENTITY retirée — et le grand nettoyage

## 1. La superposition dans le mode Grille

En mode Grille, la page garde encore le décor de la Carte : la pastille « N cartes sur la carte » en bas à droite, la bande d'exploration et les habillages positionnés en absolu passent par-dessus la trame, et la grille se glisse sous le dock AI · + · ME et sous le pied de page (visible sur vos captures).

Correction : ces éléments propres à la Carte ne s'affichent plus qu'en mode Carte, et la Grille devient une vraie page qui coule normalement, avec une hauteur qui laisse respirer le dock en bas.

## 2. Prendre une place redevient simple et gratuit

Aujourd'hui, un clic sur une case libre tente de réserver la case en base ; comme une trace existe déjà (ou entre en conflit), le message « Cette place vient d'être prise » s'affiche à tort. Et plusieurs textes du site parlent d'une case « à 1 € » ou d'une case qui débloque des fonctions.

Nouveau comportement : cliquer sur une case libre, c'est simplement **commencer sa page**. Le clic ouvre directement la création de sa page (comme « Mon espace »), sans réservation, sans paiement, sans message d'erreur. La ligne de comptage « N places réservées » disparaît, ainsi que les mentions « case à 1 € » comme condition d'accès (génération d'image, actions « pro ») : ces fonctions ne dépendent plus d'une case.

La table des cases n'est pas supprimée en base, elle n'est simplement plus utilisée par l'interface.

## 3. IDENTITY retirée du menu AIME

La page IDENTITY (film + lien d'invitation avec crédits de parrainage) sort du menu AIME et du plan du site, et sa route est supprimée. Le lien d'invitation reste disponible via la page Invitation existante.

## 4. Audit — ce qu'on peut encore nettoyer

Pages orphelines ou doublons repérés, à supprimer ou à ranger dans le pied de page :

- `/mon-evenement` : plus lié nulle part, doublon de Projets — à supprimer.
- `/evenements` : un seul lien restant, doublon de `/projets` — à supprimer (redirection vers Projets).
- `/registre` : un seul lien restant, absorbé par Le Monde AIME — à supprimer.
- `/tableau-de-bord` : déjà une simple redirection depuis le plan « Quatre destinations » — à retirer complètement.
- `/rencontres` : redirection vers `/reseau` — à conserver le temps que les anciens liens meurent, puis retirer.
- `/monde` : redirection vers `/reseau?vue=grille` — à conserver (16 liens la pointent encore).
- `/chemin`, `/objectif`, `/entraide`, `/communs`, `/saisons` : pages secondaires peu reliées — à laisser vivre uniquement depuis le pied de page, pas dans les menus.

Détails d'interface à nettoyer au passage :

- Bloc « Ce qui se prête ici » (les communs) sous la grille : hors sujet à cet endroit, il retourne sur `/communs`.
- Sélecteur Ville / Région / Pays / Monde au-dessus de la grille : conservé, mais placé avec les autres contrôles de vue.

Si vous préférez garder certaines de ces pages, dites-le et je les laisse en place.

## Détails techniques

- `src/routes/reseau.tsx` : les habillages absolus (compteur, bandeau d'exploration) conditionnés à `hasMap` ; conteneur non contraint en hauteur quand `view === "grille"` ; marge basse suffisante pour le dock.
- `src/components/aime/WorldGrid.tsx` : bulle de case libre simplifiée en « Créer ma page » ; suppression de la prop `reserved`.
- `src/components/aime/WorldGridSection.tsx` : suppression de `takeCell` / requête `world_cells` / bloc communs ; le clic sur une case libre appelle `useMyPage().open()`.
- `src/routes/ma-carte.tsx`, `src/lib/aime/features.ts`, `src/components/aime/panels/MePanel.tsx` : retrait de la condition « case prise dans Le Monde AIME (1 €) ».
- Suppression de `src/routes/identity.tsx` et de ses entrées dans `LogoMenu.tsx`, `navigation.ts`, `systemMap.ts` (les assets vidéo restent).
- Suppression des routes `mon-evenement.tsx`, `evenements.tsx`, `registre.tsx`, `tableau-de-bord.tsx` et mise à jour des liens résiduels.
- Aucune modification de base de données, de RLS ni de sécurité.
