# Grille média universelle sur les pages publiques

## Ce que l'audit a trouvé

- **L'ancienne grille existe encore**, très réduite : dans `src/routes/carte.$id.tsx` (lignes 732-757), l'entrée « galerie » affiche une simple grille d'images (`view.gallery`) plus la vidéo `view.video_url`. Aucun survol, aucune action, aucune visionneuse.
- **Le modèle actuel** : la table des pages (`cards`) a deux champs seulement — `gallery` (liste d'adresses, texte) et `video_url` (une seule vidéo). Rien pour le type, le titre, l'ordre, ni pour les pages d'événement/projet.
- **L'édition actuelle** : dans `src/components/aime/page/EditPageSheet.tsx` (bloc « Galerie »), on colle des liens un par un. Pas d'envoi de fichier depuis cet écran.
- **Envoi de fichiers déjà en place** : `src/components/aime/PageSetup.tsx` envoie déjà des images dans l'espace de stockage « cartes ». D'autres espaces existent (musicbox, stories, bureau, timeline-media) — tous privés, avec liens signés.
- **Aucune visionneuse** n'existe aujourd'hui dans l'application, et **aucun système média** générique (pas de « MediaAsset »).
- **Droits** : la page publique connaît déjà `isOwner`; l'édition passe par ce même contrôle.

Conclusion : il y a une base réutilisable (stockage, contrôle propriétaire, esprit visuel de la grille), mais le stockage des liens en simple liste ne peut pas porter un média typé, ordonné et partagé par plusieurs types de pages. On garde donc l'existant comme source de repli et on ajoute un modèle média léger.

## Ce qui sera construit

### 1. Un modèle média unique
Une nouvelle entrée « média » rattachée soit à une page (carte), soit à un projet/événement, avec : type (photo, vidéo, YouTube, audio, lien), adresse, miniature, titre, ordre, visibilité. Lecture publique pour tout le monde, écriture réservée au propriétaire de la page (mêmes règles que les autres contenus).
Reprise automatique des images déjà présentes dans la galerie et de la vidéo de présentation, pour que rien ne soit perdu ni dupliqué.

### 2. Un composant de grille réutilisable
Une seule grille, utilisée telle quelle sur : personne, lieu, entreprise, association, artiste, prestataire, projet, événement.
- cases au même format, 2 colonnes sur mobile, 3 sur tablette, 4 à 5 sur ordinateur ;
- chargement différé des images, miniature seule pour les vidéos (aucune lecture automatique) ;
- au survol : voile léger avec les actions du type de média (Voir/Agrandir, Lire, Ouvrir YouTube, Écouter, Ouvrir) ;
- sur mobile : un premier appui révèle les actions, le second ouvre — pas de dépendance au survol ;
- pour le propriétaire : cases vides « Ajouter un média » et menu « … » (modifier, remplacer, déplacer, définir comme visuel principal, supprimer). Rien de tout cela n'apparaît pour un visiteur.

### 3. Ajout d'un média
Un petit écran de choix : Photo (envoi de fichier ou lien), Vidéo, YouTube (collage de l'adresse, miniature récupérée automatiquement), Audio, Lien. Les fichiers partent dans l'espace de stockage déjà utilisé pour les pages.

### 4. Visionneuse
Ouverture en plein écran avec passage au précédent/suivant (flèches du clavier et balayage tactile) : photo en grand, lecteur pour la vidéo, lecteur intégré pour YouTube, lecteur audio, ouverture externe pour un lien.

### 5. Emplacement
Sur la page publique, la grille devient une section visible du volet « Présentation », juste après la présentation et avant « À associer », et l'entrée « galerie » du menu affiche la même grille — même composant, aucune duplication. Sur une page de projet/événement, la grille se place après le récit de la ligne de temps.

## Détails techniques

- Migration : table `public.media_items` (`id`, `card_id`, `event_id`, `kind`, `url`, `thumb_url`, `title`, `position`, `visibility`, `created_by`, timestamps), `GRANT` explicites (`SELECT` pour anon/authenticated, écriture pour authenticated, `ALL` pour service_role), RLS : lecture publique si `visibility='public'`, écriture via les fonctions de propriété existantes (`is_card_owner`, `is_event_owner`). Aucune fonction `SECURITY DEFINER` existante n'est modifiée.
- Backfill dans la même migration depuis `cards.gallery` et `cards.video_url`; les colonnes actuelles sont conservées (aucune suppression).
- Nouveaux fichiers : `src/lib/aime/media.ts` (types, requêtes, détection YouTube/Vimeo, envoi de fichier), `src/components/aime/media/MediaGrid.tsx`, `MediaTile.tsx`, `MediaViewer.tsx`, `AddMediaDialog.tsx`.
- Fichiers modifiés : `src/routes/carte.$id.tsx` (section grille + entrée « galerie » branchée sur le composant), `src/components/aime/page/EditPageSheet.tsx` (le bloc Galerie renvoie vers la grille au lieu du collage de liens).
- Performance : `loading="lazy"`, miniatures, iframe YouTube montée uniquement à la lecture, pagination douce au-delà de 40 médias.
