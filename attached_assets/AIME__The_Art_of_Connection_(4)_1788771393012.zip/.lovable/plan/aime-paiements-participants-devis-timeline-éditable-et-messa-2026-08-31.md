# AIME — Paiements, participants, devis, timeline éditable et messagerie

Sept chantiers demandés. Ils partagent la même base de données, je les livre en un ensemble cohérent.

## 1. Base de données (nouvelles tables)

- `service_rates` — tarifs par carte : mois (ou date précise), prix, unité, note. Sert aux devis.
- `quotes` / `quote_items` — devis rattaché à un événement et à une carte : lignes de service, quantité, prix, total, statut (brouillon, envoyé, accepté).
- `event_payments` — part par participant : événement, participant, service, montant dû, montant payé, statut, date de règlement.
- `event_invitations` — invitation par e-mail : événement, e-mail, nom, statut (envoyée, ouverte, confirmée, refusée), jeton unique.
- `threads` / `messages` — fil de conversation lié à une intention (Aime) entre deux membres, avec accusé de lecture.

Toutes ces tables sont protégées : seul l'organisateur de l'événement, le prestataire concerné ou le participant invité voit ses propres lignes.

## 2. Pages nouvelles

- `/evenement/$id/paiements` — total par service, part de chaque participant, marquage payé/en attente, total global et reste à payer. Quand toutes les parts d'un service sont réglées, la date correspondante est confirmée automatiquement (statut du participant passe à « confirmé » et l'entrée apparaît confirmée dans le calendrier).
- `/evenement/$id/participants` — liste des participants, ajout par e-mail, envoi de l'invitation, suivi des statuts (envoyée / confirmée / refusée), relance. La page publique d'acceptation utilise le jeton de l'invitation.
- `/devis/$cardId` — grille tarifaire du prestataire : tarifs par mois et surcharges par date, plus simulateur (choisir une date → prix). Éditable par le propriétaire de la carte, consultable par les autres. Le devis estimé s'affiche aussi dans les combinaisons (`/rencontres`, `/mon-evenement`) : chaque carte de la composition montre son tarif pour la date visée et un total de composition.
- `/carte/$id/timeline` — éditeur de repères : créer, modifier, supprimer, avec date de début/fin, type (souvenir, événement, jalon, intention), titre, texte, univers, visibilité publique. Réservé au propriétaire de la carte ; alimente la timeline du hero.
- `/messages` + fils intégrés — messagerie directe entre membres. Un fil naît d'une intention ; il apparaît dans `/aimes-recues` (bouton « Répondre » ouvrant la conversation) et un repère « conversation » apparaît sur la timeline de la carte concernée.

## 3. Confidentialité des coordonnées

Site, téléphone et adresse sont retirés de toutes les réponses tant que l'intention « Contacter » n'est pas acceptée — page carte, `/aimes-recues`, combinaisons et événements compris. Le filtrage se fait côté serveur (les colonnes ne sont plus renvoyées au client), pas seulement masqué à l'affichage. La messagerie sert de canal de contact avant l'ouverture des coordonnées.

## 4. Données réelles de démonstration

Remplissage de la timeline d'une carte existante de Lille (Tony Masclet, photographe) avec ses disponibilités réelles converties en repères, plus quelques souvenirs et événements passés. Ensuite : création d'une intention datée depuis la timeline, qui génère un événement partagé — vérifié dans `/evenements`.

## Détails techniques

- Nouvelles fonctions serveur (`*.functions.ts`) pour les lectures qui doivent filtrer les coordonnées et pour l'envoi des invitations e-mail.
- Envoi d'e-mails via la fonctionnalité e-mail intégrée de Lovable Cloud ; si elle n'est pas encore configurée, l'invitation génère un lien copiable en repli.
- Les paiements sont un suivi de règlement (qui doit quoi, qui a payé), sans encaissement en ligne. Un vrai paiement par carte bancaire demanderait l'activation de Stripe — à dire si vous le souhaitez.
- Navigation mise à jour dans `AppShell` (Messages) et liens contextuels depuis les pages événement et carte.
