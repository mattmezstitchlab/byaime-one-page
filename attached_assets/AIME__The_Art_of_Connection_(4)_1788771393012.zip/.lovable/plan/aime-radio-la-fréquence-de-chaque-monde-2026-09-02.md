# AIME RADIO — la fréquence de chaque monde

Votre lecture est juste, et elle simplifie tout. La bande de timeline **est déjà** une bande de fréquence : un curseur qui se déplace dans le temps, des points qui s'allument, un présent au centre. Donc la radio n'est pas une nouvelle page à côté — c'est **un mode de plus de la page universelle**, à côté du mode visuel (hero), du mode timeline et du mode onglets.

D'où le principe que je retiens :

**Une page universelle = une box. Une box a des modes. La radio est le mode qui met le temps en son.**

Et la conséquence, elle est réelle : chaque personne, chaque projet, chaque monde a **sa fréquence**, qui évolue avec ce qu'on ajoute dans le passé (souvenirs, mémoire), dans le présent (ce qui se joue) et dans le futur (ce qui est programmé).

## Ce que ça change par rapport au plan précédent

Plus de page `/radio` séparée comme point d'entrée. À la place : **un onglet RADIO** avec le picto ondes, dans la barre d'onglets horizontale déjà présente sous la timeline de la page universelle. Une adresse partageable existe quand même (`/carte/$id?onglet=radio`), donc rien n'est perdu.

## Audit de l'existant

### Déjà disponible / réutilisable
- **La programmation existe** : les entrées MusicBox portent jour, heure, durée, type (morceau, message vocal, annonce, récit, biographie, tâche, rendez-vous), visibilité (privé / invités / public radio), statut, dédicace, ville et coordonnées, lien externe ou fichier audio.
- **Le direct existe** : ce qui passe à l'antenne, ce qui suit, le compte à rebours, la lecture audio ou embarquée (YouTube, Spotify, SoundCloud, MP3).
- **L'animatrice IA existe** : texte de présentation et voix, générés une fois puis conservés.
- **L'ajout depuis le calendrier existe** : on programme déjà un contenu à une heure donnée depuis la MusicBox d'une carte ou d'un projet.
- **La compréhension d'intention existe** : « programme ce morceau samedi 20h pour Julien » est déjà interprété.
- **La barre d'onglets et le filtre univers existent** sur la page universelle.

### Facile à connecter
- Afficher la grille radio **dans la même timeline** que la page carte, avec le même aperçu au survol et les mêmes boutons d'action.
- Filtrer la programmation **par univers**, exactement comme la timeline le fait déjà.
- Ajouter une annonce, un message ou une aide **par le bouton cœur**, comme partout ailleurs sur le site.
- Projeter les **événements du projet** (cérémonie, dîner, première danse) comme éléments de grille.

### Nécessite une évolution
- **Identité de fréquence** : nom, visuel, statut à l'antenne pour la radio d'un monde (aujourd'hui les stations sont fixes et liées à des villes).
- **Collaborateurs** : rôles et invitations existent pour le Bureau, pas pour une radio — à dupliquer, pas à inventer.
- **Contributions des invités** : file de validation (le champ statut existe, l'écran de modération non).

### Nouvelle brique importante
- **Grille complète proposée par Aime** (aujourd'hui : une entrée à la fois).
- **Écoute synchronisée** avec nombre d'auditeurs.

### Non présent
- Vrai streaming micro en direct. Remplacé par : message vocal enregistré, diffusé à l'heure prévue.

### Risques
- Ne pas dupliquer les contenus : la radio **lit le monde**, elle ne stocke pas une seconde fois la musique, les souvenirs et les événements.
- Droits musicaux : lecture déléguée aux plateformes ou aux fichiers de l'utilisateur.
- Charge cognitive : au premier écran, seulement « ce qui passe » et « ce qui suit ».

## Ce que je propose de construire

### 1. L'onglet RADIO de la page universelle
Picto ondes dans la barre d'onglets. Au clic, sans quitter la page :
- **À l'antenne** : le contenu en cours, le suivant, le compte à rebours, écouter / couper.
- **La programmation** rejouée dans la bande timeline : passé, présent, futur, curseur au présent.
- **Filtre univers**, identique à celui de la timeline.
- **Bouton cœur** : ajouter un morceau, une annonce, un message, une aide, une dédicace — même menu contextuel que les autres boutons cœur du site.

### 2. La box et ses modes
La page universelle affiche explicitement ses modes : **Visuel · Timeline · Onglets · Radio**. Un même contenu, quatre lectures. La radio hérite du monde affiché et du filtre univers courant.

### 3. Une fréquence par monde
Chaque carte, projet ou événement possède sa fréquence, avec nom et visuel, alimentée par ce que le monde contient déjà. Les projets ouvrent la leur depuis l'écran de projet.

### 4. Équipe de la fréquence
Invitations et rôles simples : responsable, musique, messages, souvenirs, lecture seule — même logique que les membres du Bureau.

### 5. Aime propose la grille
Un bouton : Aime lit les horaires, les personnes, les morceaux et les messages du monde, puis propose une journée entière que l'on accepte, ajuste ou refuse ligne par ligne.

### 6. Les fréquences dans Le Monde AIME
Une fréquence active apparaît comme case vivante de la grille universelle, ouverte dans le même aperçu que les cartes.

## Détails techniques

- Nouvel onglet `radio` dans la barre d'onglets de `src/routes/carte.$id.tsx` (`?onglet=radio`), plus un panneau `src/components/aime/panels/RadioPanel.tsx`.
- Réutilisation directe de `RadioProvider` (direct, suivant, compte à rebours, voix), `MusicBox` (édition de la grille), `HeroTimeline` (bande de fréquence) et `CardPreview` (aperçu au survol).
- Le bouton cœur radio réutilise `IntentionHeart` avec des actions propres à la programmation.
- Étape 3 : tables `radios` (propriétaire, monde rattaché, nom, visuel, statut) et `radio_members` (rôle, périmètres, invitation), calquées sur `bureau_members`, avec GRANT explicites et lecture publique limitée aux fréquences publiées ; rattachement optionnel des entrées MusicBox à une radio, sans déplacer les données existantes.
- Étape 5 : fonction serveur de génération de grille (Gemini déjà en place), proposition non écrite tant qu'elle n'est pas validée.
- Aucune diffusion micro temps réel dans ces étapes.

## Ordre de mise en œuvre

1. Onglet RADIO sur la page universelle : direct, bande de programmation, filtre univers, bouton cœur — sur les données actuelles, sans nouvelle table.
2. Modes explicites de la box (Visuel · Timeline · Onglets · Radio) et radio des projets.
3. Identité de fréquence et équipe.
4. Grille proposée par Aime et contributions modérées.
5. Fréquences visibles dans la grille du Monde AIME.
