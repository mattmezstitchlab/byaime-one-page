# Ma Carte — parcours guidé de bout en bout

## Ce que je comprends

La page « Ma carte » doit devenir le premier parcours d'un nouveau membre : on coche ses univers et sous-univers, on dépose des photos, l'agent construit la carte sous les yeux, puis on complète les possibilités une par une via le menu du cœur. Rien ne doit se perdre, et personne ne doit quitter la page sans savoir où elle en est.

État actuel vérifié : les univers et sous-univers utilisent déjà des menus déroulants multi-sélection (`MultiSelectMenu`), une seule photo est gérée, la génération d'image existe déjà sans condition d'accès, et les cases du Monde AIME sont stockées dans `world_cells`.

## Ce que je propose

### 1. Univers et sous-univers — cases à cocher assumées
Les deux menus deviennent explicitement multi-choix avec cases cochées, compteur, puces retirables sous le menu, et « tout décocher ». Les sous-univers de tous les univers cochés sont regroupés dans un seul menu par univers.

### 2. Photos multiples + photo de profil
- Dépôt de plusieurs photos (galerie), réordonnables, avec choix de celle qui sert de recto.
- Le bouton « Générer une photo » n'est actif que pour les membres ayant une case dans le Monde AIME payée 1 €. Sinon, le bouton explique la condition et propose de prendre une case (paiement 1 € via le tunnel existant), le déblocage étant immédiat après paiement.

### 3. Le cercle progressif + pixels animés
Pendant que l'agent qualifie la carte, le formulaire s'efface au profit du chargeur circulaire existant (`AgentLoader`), placé juste sous le hero, enrichi d'un nuage de pixels colorés qui se rassemblent progressivement en forme de carte. À la fin, la carte recto apparaît en fondu, accompagnée d'un rapport structuré : ce que l'agent a reconnu, ce qu'il a déduit, ce qui manque.

### 4. Le cœur = liste complète des possibilités de l'univers
Au clic sur le rond cœur de la carte, le menu d'intentions habituel s'ouvre mais en mode « ce qui est possible dans cet univers » : chaque ligne est une capacité (devis, disponibilités, tarifs, déplacement, langues, matériel…). Au clic sur une ligne :
- elle se déplie et demande l'information correspondante ;
- une fois renseignée, la liaison est activée et la capacité devient réellement cherchable ;
- « Répondre plus tard » la laisse visible dans les recherches comme *possibilité annoncée, non renseignée* — un autre membre voit que c'est possible et peut le demander.

### 5. Retourner la carte = comprendre AI · + · ME
Au verso, les trois lettres deviennent cliquables : AI ouvre le panneau de gauche, ME le panneau membre, + le plateau d'ajout, avec une phrase d'explication à la première ouverture.

### 6. Retenir la personne
Au moindre départ (fermeture d'onglet, retour, navigation), un message calme : « Votre carte est prête à 68 %. Tout est enregistré. Vous pouvez la découvrir maintenant ou la compléter plus tard. » Le pourcentage vient des champs remplis et des capacités activées. À chaque changement, une confirmation discrète « enregistré en mémoire » s'affiche, même si c'était déjà fait.

### 7. Guidage du premier parcours
Un fil conducteur pas à pas (une bulle à la fois, jamais bloquante) accompagne la première visite : univers → photos → agent → cœur → verso → publication. À la fin, un panneau « Ce qui va travailler pour vous en votre absence » : rappels, veille de correspondances, notifications de nouvelles cartes compatibles, relances de devis — chacun activable en un clic.

## Détails techniques

- `src/routes/ma-carte.tsx` : refonte du parcours, galerie multi-photos (bucket `cartes`), état de progression, garde de sortie (`beforeunload` + interception de navigation), autosave avec accusé visuel.
- Nouvelle table `card_capabilities` (carte, capacité, statut annoncé/renseigné, valeur JSON) + RLS et GRANT, lue par la recherche pour afficher les possibilités non encore remplies.
- Menu du cœur : extension de `src/lib/aime/capabilities.ts` et `AimeButton.tsx` pour le mode dépliable avec saisie inline.
- Chargeur : extension de `AgentLoader.tsx` avec la couche pixels (canvas léger, respect de `prefers-reduced-motion`).
- Génération d'image conditionnée à une case `world_cells` payée ; paiement 1 € via le tunnel de paiement existant.
- `CardConsole.tsx` : AI · + · ME reliés aux panneaux du dock.
- Guidage : réutilisation de `src/lib/aime/tour.ts`, état de progression stocké côté membre.

## Ordre de livraison

1. Univers/sous-univers cochables, multi-photos, autosave visible, pourcentage + message de rétention.
2. Chargeur pixels + rapport structuré de l'agent, verso AI · + · ME cliquable.
3. Capacités dépliables via le cœur (avec « plus tard » visible en recherche), génération d'image conditionnée au 1 €, guidage du premier parcours et panneau des automatismes.
