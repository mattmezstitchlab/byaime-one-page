# Audit d'incohérences — état vérifié et corrections

Audit fait par lecture du code (pas d'hypothèse). Ce qui suit sépare ce qui
est **déjà cohérent** de ce qui est **réellement incohérent** aujourd'hui.

## Ce qui est déjà propre (vérifié, rien à faire)

- Aucun lien mort : toutes les cibles `to="/..."` du site correspondent à un
  fichier de route existant.
- Aucun bouton « bientôt disponible » factice : les trois toasts de ce genre
  accompagnent une action réelle (déconnexion, échec de géolocalisation).
- Une seule barre de progression sur Ma Carte (le doublon signalé a bien été
  supprimé).
- « Treize chapitres » est exact : 6 chapitres + 7 chapitres complémentaires.
- Le champ du hero Messages transmet bien le texte au nouveau fil.

## Incohérences réelles à corriger

### 1. Pages sans hero commun alors que tout le site en a un
31 pages utilisent `PageHero`. Ces pages de contenu ne l'utilisent pas et
n'ont donc ni visuel, ni titre, ni champ AIME, ni métadonnées homogènes :
`/reseau`, `/evenements`, `/registre`, `/identity`, `/mon-evenement`,
`/bureau/dossier/$id`, `/bureau/export`, `/bureau/membres`,
`/bureau/projet/$id`, `/carte/$id/timeline`, `/projets/nouveau`,
`/devis/$cardId`.
→ Leur donner le même hero que le reste du site (titre, sous-titre, visuel),
sauf les écrans techniques qui restent volontairement nus (`/auth`,
`/legal/$doc`, `/cockpit`, `/admin/enrichissement`, consentement OAuth).

### 2. Champ AIME absent là où il aurait du sens
Le champ avec le bouton cœur n'existe que sur 8 pages. Il manque sur
`/reseau` (recherche de cartes), `/saisons` (dire où et quand on sera),
`/evenements`, `/bureau` et `/carte/$id`.
→ Ajouter le champ AIME avec le contexte propre à chaque page.

### 3. Contexte cœur générique dans le panneau IA
`AiPanel` déclare `context={{ page: "autre" }}` : le menu du cœur y est donc
le menu par défaut, sans les actions du lieu où le panneau est ouvert.
→ Passer le vrai contexte (page courante + carte concernée).

### 4. Composants orphelins jamais affichés
`HowItWorksDiagram`, `KissRitual`, `QuoteHero`, `RegistryEmpty` ne sont
importés nulle part : du code mort qui ne correspond à aucune page.
→ Soit les rebrancher là où ils ont du sens (`RegistryEmpty` sur `/registre`
vide, `HowItWorksDiagram` sur `/comment-ca-marche`), soit les supprimer. Je
rebranche les deux utiles et supprime les deux autres.

### 5. Champs qui ne se vident pas après action
Sur `/monde`, le texte saisi reste affiché après la navigation, ce qui donne
l'impression que rien ne s'est passé.
→ Vider le champ après une soumission réussie, comme ailleurs.

### 6. Barres de progression au style divergent
Trois barres maison différentes : Bureau (`score`), Projets (`pct`), Ma Carte
(`completion`).
→ Un seul composant de barre partagé, même hauteur, même couleur, même
libellé de pourcentage.

## Détails techniques

- `PageHero` accepte déjà `align`/`overlap` : réutilisation directe, pas de
  nouveau composant de hero.
- Nouveau composant `src/components/aime/ProgressBar.tsx` utilisé par les
  trois pages concernées.
- Extension de `HeartContext` seulement si nécessaire pour `AiPanel`
  (transmission de la page appelante) — pas de nouvelle table.
- Chaque page recevant un hero reçoit aussi son `head()` propre (titre,
  description, og) là où il manque.
- Aucune migration de base de données. Aucun changement de sécurité ni de
  `geo.ts`.

## Vérification

TypeScript, réponses HTTP des routes touchées, et contrôle navigateur sur
`/reseau`, `/saisons`, `/registre` et `/monde`.
