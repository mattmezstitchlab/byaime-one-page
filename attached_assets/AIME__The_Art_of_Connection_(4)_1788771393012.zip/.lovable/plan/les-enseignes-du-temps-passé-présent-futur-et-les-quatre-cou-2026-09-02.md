# Les Enseignes du temps — Passé · Présent · Futur, et les quatre couleurs d'AIME

Votre intuition est juste, et elle règle un vrai problème : aujourd'hui le
bouton `+` propose douze créations pêle-mêle, et le cœur propose sept
intentions identiques partout. Rien ne dit *quand* on agit. Or tout AIME est
déjà une affaire de temps : la timeline, la fréquence, le Jour J, le Bureau.

## Le concept

Le dock ne devient pas quatre boutons. Il reste **AI · + · ME**, mais le `+`
porte une **enseigne** — le temps dans lequel on se tient. On la change d'un
appui long ou d'un glissement latéral sur le `+`, et tout le site s'accorde :
menus de création, actions du cœur, tri de la timeline, ce que raconte AIME.

```text
♠  PIQUE     PASSÉ      ce qui est gravé      · noir
♦  CARREAU   PRÉSENT    ce qui s'échange      · rouge
♣  TRÈFLE    FUTUR      ce qui peut pousser   · vert profond
♥  CŒUR      L'INTENTION — hors du temps, toujours rouge
```

Trois enseignes pour les trois temps, la quatrième — le cœur — reste ce
qu'elle est : le geste humain, présent partout, jamais un mode. C'est ce qui
rend le jeu complet sans le rendre confus.

## Ce que change chaque mode

**♠ Passé — constater.** Le `+` devient noir. On ne crée que du révolu :
déposer une pièce au Bureau, journaliser une diffusion, ajouter un souvenir à
la timeline, écrire un avis. Le cœur ne propose plus « Réserver » mais
« Recommander », « Enregistrer », « Attester ». La timeline se replie sur
l'avant. AIME répond au passé : *ce qui s'est passé, ce que ça a produit.*

**♦ Carreau — agir.** Le `+` reste rouge, mode par défaut. Création de ce qui
se joue maintenant : intention publique, éphémère, message, devis, annonce
radio. Le cœur propose « Contacter », « Collaborer », « Associer ». C'est le
site tel qu'il fonctionne aujourd'hui — donc aucune régression.

**♣ Trèfle — prévenir.** Le `+` devient vert. Création tournée vers l'avant :
une date, une option, un projet, une échéance, une contribution promise. Le
cœur propose « Réserver », « Poser une option », « Prévenir ». Et surtout, le
mode Futur ouvre la lecture la plus forte du site : **la chaîne de causalité
du Jour J** — à partir des repères et des effets déjà en base, AIME remonte
ce qui manque *avant* qu'il ne soit trop tard : une facture non réglée qui
bloquera un paiement, une date libre qui va se fermer, un devis sans réponse
à J-14. Prévenir au lieu de guérir, littéralement.

## Pourquoi les enseignes plutôt que des mots

Un pictogramme d'enseigne se lit à 14 px, se colore sans dépendre du texte,
et se traduit tout seul dans les cinq langues du site. Il donne aussi au cœur
rouge sa place définitive : il n'est plus « un bouton rouge de plus », il est
**la seule enseigne qui ne change jamais**.

Les boutons cœur du site prennent une petite enseigne en filigrane indiquant
dans quel temps l'action sera enregistrée. Un même cœur, trois lectures, zéro
menu supplémentaire.

## Garde-fous

- Le mode par défaut est **Présent** : un visiteur qui ne touche à rien voit
  exactement le site actuel.
- Le mode ne cache jamais une action : une entrée hors-temps reste accessible
  en bas de menu sous « Autres temps ».
- Aucune donnée n'est modifiée par le mode. C'est une **lecture**, jamais un
  état stocké sur les objets — exactement comme la Fréquence.
- Les couleurs passent par les jetons du thème, pas par des valeurs en dur.

---

# Les quatre corrections déjà relevées (inchangées)

1. **Monde** — la bulle d'aperçu est coupée par le conteneur
   `overflow-hidden` : elle passe en position fixe calculée sur la case, et
   bascule sous la case quand la place manque en haut.
2. **Réseau, mode Liste seul** — la liste cesse d'être une couche flottante
   en `md:top-24` et devient une colonne en flux, sous la barre de recherche
   et les boutons de mode.
3. **Réseau, Mosaïque** — la bande de vignettes carrées est remplacée par une
   grille de vraies cartes universelles `AimeCard` (recto/verso, cœur,
   console au verso), 2 à 4 colonnes.
4. **Réseau** — un bouton « Éphémères » qui ne montre que les cartes ayant un
   éphémère en cours, actif sur les trois vues à la fois.

# Ordre de livraison proposé

1. Les quatre corrections (courtes, visibles tout de suite).
2. L'enseigne sur le `+` : trois modes, couleurs, menus de création filtrés.
3. Le cœur accordé au temps courant.
4. Le mode Futur avec la chaîne de causalité du Jour J.

## Détails techniques

Nouveau `src/lib/aime/tense.ts` : type `Tense = "passe" | "present" | "futur"`,
enseignes, jetons de couleur, et deux tables — `CREATE_BY_TENSE` (filtrage de
la liste `CREATE` d'`AimeDock`) et `INTENTS_BY_TENSE` (filtrage de `INTENTS`
et de `actionsForCard`). Contexte léger `TenseProvider` monté dans `AppShell`,
état persisté en `localStorage`, exposé aussi en `?temps=` pour être partageable.
`AimeDock.tsx` : appui long / glissement sur le `+`, couleur et picto issus du
contexte. `AimeButton.tsx` : filtrage des intentions et filigrane d'enseigne.
`HeroTimeline` / `FrequencyBand` : le mode borne la fenêtre affichée.
Le mode Futur réutilise `timeline_effects`, `card_availability`, `quotes` et
`bureau_documents` déjà chargés — aucune table nouvelle, aucune dépendance.
Les enseignes sont dessinées en SVG local (lucide ne les fournit pas).
