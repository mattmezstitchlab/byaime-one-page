# Le Bureau — fenêtre plus compacte, arborescence vivante, écrans intégrés

## 1. La fenêtre rétrécit

La fenêtre flottante passe de `max-w-6xl` à `max-w-5xl`, avec une hauteur bornée (`h-[86vh]`) : le ciel se voit tout autour, et le contenu défile à l'intérieur de la fenêtre plutôt que la page entière. Barre de titre (les trois pastilles) et arbre de gauche restent fixes pendant le défilement.

## 2. Tous les écrans du Bureau dans la même fenêtre

Aujourd'hui « Transmettre au comptable » (`/bureau/export`) et la page d'un dossier s'affichent en pleine page, hors de la fenêtre. On extrait un composant de coquille `BureauWindow` (vidéo de ciel + fenêtre + barre de titre + arbre) et les trois écrans — tableau de bord, dossier, export — s'affichent dedans, dans la zone de droite. Naviguer d'un écran à l'autre ne fait plus « sortir » du Bureau.

## 3. Arborescence : créer, renommer, supprimer, imbriquer

Oui, c'est la bonne idée — c'est ce qui transforme la liste en vrai bureau.

- **Sous-dossiers** : un dossier peut contenir des dossiers (Client → 2026 → Factures). Nouvelle colonne `parent_id` sur les dossiers, avec suppression en cascade des sous-dossiers.
- **Créer** : bouton « + » à la racine et sur chaque ligne de dossier (crée un enfant). Le champ apparaît directement dans l'arbre, on tape, on valide.
- **Renommer** : double-clic sur le nom, ou menu « … » → Renommer. Édition en place.
- **Supprimer** : menu « … » → Supprimer, avec confirmation qui annonce clairement ce qui part (sous-dossiers) et ce qui reste (les documents sont détachés, jamais effacés — ils repassent en « Non classés »).
- **Ranger** : glisser un document depuis la liste de droite vers un dossier de l'arbre pour le classer.
- L'arbre garde ses compteurs et sa pastille d'état, et l'état déplié/replié est mémorisé localement.

## 4. Ce qui manquait encore et qu'on termine

- **Vue « À faire »** : chaque anomalie (montant manquant, date absente, type non identifié, document non confirmé) devient une ligne cliquable qui ouvre le document concerné.
- **Chapitre « Le Bureau »** dans « Comment ça marche » : déposer un document, laisser AIME le lire, ranger, transmettre au comptable.

## Détails techniques

- Migration : `ALTER TABLE public.bureau_folders ADD COLUMN parent_id uuid REFERENCES public.bureau_folders(id) ON DELETE CASCADE;` + index sur `parent_id`. RLS et GRANT existants inchangés.
- Nouveau `src/components/bureau/BureauWindow.tsx` (coquille partagée) consommé par `bureau.index.tsx`, `bureau.dossier.$id.tsx`, `bureau.export.tsx`.
- `FolderTree.tsx` : rendu récursif par `parent_id`, édition en place, menu contextuel, cible de drop.
- Mutations dossiers regroupées dans `src/lib/bureau/queries.ts` (create/rename/delete/move) avec invalidation React Query.
- Aucun changement sur l'extraction IA, les rapprochements ou les exports existants.
