# Audit II — Deux lignes de temps, un seul moteur

Audit uniquement : aucun fichier de l'application n'a été modifié.

Constat majeur : la distinction que vous formalisez **existe déjà dans le code**, mais par accident et non par intention. `cardTimeline.ts` (fiche `/carte/$id`) est de fait la ligne personnelle ; `world/derive.ts` (`/projets/$id`) est de fait la ligne de projet. Le travail n'est donc pas de fusionner, mais de **nommer, unifier le moteur et créer le pont**.

## A — Modèle conceptuel

| Notion | Définition | Existant dans le code |
|---|---|---|
| **Personne** | Une identité (`cards`, `profiles`) et sa mémoire temporelle. | Fiche `/carte/$id` |
| **Projet / monde** | Un espace partagé avec un jour pivot, des participants, des ressources. | `WorldProject` (`world/types.ts`), table `events` + `project_snapshots` |
| **Ligne personnelle** | « Qu'est-ce qui me concerne ? » — agrégat de tout ce qui est daté et rattaché à moi, tous projets confondus. | `useCardTimelineSources` |
| **Ligne de projet** | « Que se passe-t-il dans ce projet ? » — projection d'un seul monde. | `deriveTimeline` |
| **Repère** | Objet daté : `id`, `time`, `kind` (14 types), `status` (7 états), `confidence`, `relatedIds`, `projectId`. | `TimelineMarker` |
| **Relation** | Lien typé entre deux repères, 7 types (`lie`, `decoule`, `facture`, `paye`, `illustre`, `prepare`, `remplace`). | table `timeline_relations` |
| **Contexte** | Le point de vue qui alimente la règle : `personne:<id>` ou `projet:<id>`. | **N'existe pas** — à créer |
| **Projection** | Changement de contexte **en conservant l'instant, le zoom et le repère d'ancrage**. | **N'existe pas** |

La projection est le concept neuf : aujourd'hui passer de la fiche au projet est une navigation qui remet tout à zéro.

## B — Matrice du commun

| Élément | Personnelle | Projet | Même composant | Même modèle |
|---|---|---|---|---|
| Repère, date, heure | oui | oui | oui | oui |
| Statut (7 états) | oui | oui | oui | oui |
| Confiance / manquant | oui | oui | oui | oui |
| Relation | oui | oui | oui | oui |
| Alerte | oui | oui | oui | oui |
| Action de bulle | oui | oui | oui | oui |
| Personne | oui | oui | oui | oui |
| Projet | oui (comme écho) | oui (le contexte) | oui | oui |
| Prestataire | non | oui | oui | oui |
| Document, devis, facture, paiement | oui | oui | oui | oui |
| Message | oui | oui | oui | oui |
| Événement | oui | oui | oui | oui |
| Tâche | oui | oui | oui | oui |
| Intention | oui | oui | oui | oui |
| Musique | oui (mes morceaux) | oui (le déroulé) | oui | oui |
| Souvenir / média | oui | oui | oui | oui |
| Disponibilité (`disponible`, `option`, `complet`) | oui | non | oui | oui |
| Calques | oui | oui | oui | oui |
| PLAY | oui | oui | oui | oui |
| Ciel du temps | oui | oui | oui | règles différentes |

Conclusion : **tout est mutualisable**. Seul l'alimentation et la lecture changent.

## C — Ce qui reste spécifique

**Personnelle** : disponibilités et réservations, ce que j'attends d'autrui vs ce qu'on attend de moi, mes réponses dues (RSVP, devis à signer), mes projets en écho, mes recommandations personnelles, ma mémoire longue (années).

**Projet** : prestataires et places à pourvoir, budget global et engagements, dépendances et conflits collectifs, déroulé du jour pivot heure par heure, décisions collectives, participants et rôles.

Formule : **même moteur, même bulle, même grammaire ; deux alimentations et deux jeux de règles pour le ciel.**

## D — Fonctions intégrables à la ligne

Rappel du premier audit, complété : bloc automatisations, liste d'édition des repères, synthèse financière, sections verticales Avant/Pendant/Après, boussole et rétroplanning, réponse aux messages (aujourd'hui limitée à la fiche), cocher une tâche (idem), musique du déroulé, documents datés, RSVP, paiements.

Nouveau : les **disponibilités** de la fiche (calendrier `CalendarFlip` / `MonthCalendar`) sont déjà des repères `disponible` / `option` / `complet` — le calendrier séparé fait doublon avec la règle.

## E — Pages supprimables (au-delà du premier audit)

| Élément | Décision | Raison |
|---|---|---|
| Onglets `calendrier`, `timeline` de la fiche | INTÉGRER | La règle est déjà là, au-dessus. |
| Onglets `budget`, `documents`, `musique`, `deroule`, `invites` (préréglage mariage) | INTÉGRER | Tous datés ; leur détail s'ouvre en secondaire depuis un repère. |
| Bloc « Automatisations et impacts » | SUPPRIMER | Devient pastilles sur la règle. |
| Liste « Modifier la ligne de temps » | SUPPRIMER | Édition dans la bulle. |
| Sections verticales Avant/Pendant/Après | SUPPRIMER | Déjà des fenêtres de la même règle. |
| `MonthCalendar` de `/projets` | CONSERVER | Vue d'ensemble multi-projets, sans équivalent. |
| `/messages` | CONSERVER | Fils de groupe et traduction ; à relier repère ↔ fil. |
| `/bureau/*` | CONSERVER | Périmètre gelé. |
| `/reseau` | CONSERVER | Dimension spatiale, pas temporelle. |
| Fichiers morts du premier audit (≈ 25) | SUPPRIMER | Aucun importeur. |

## F — Le ciel du temps

Surface d'une seule ligne, texte pâle, sans cadre ni fond.

Règles :
- **Trois mentions maximum**, jamais plus, quel que soit le nombre d'alertes.
- Priorité : bloquant > décision attendue > information manquante > jalon > suggestion.
- Chaque mention est **ancrée à une date** : elle glisse horizontalement avec la règle et s'estompe quand sa date sort du cadre.
- Au zoom large (> 6 mois), seuls les jalons et le bloquant subsistent. Au zoom serré (< 1 semaine), les mentions deviennent horaires.
- Disparition : une mention traitée s'efface en 400 ms sans notification de succès.
- Pulsation : réservée au niveau bloquant, une respiration de 3 s, désactivée sous `prefers-reduced-motion`.

Contenus : Aujourd'hui, J-30 / J-7, prochaine décision, prochaine échéance, ce qui manque, conflit, correspondance trouvée par AIME.

## G — Langage visuel (14 signes)

1. **Halo** — repère légèrement lumineux : quelque chose a changé depuis ma dernière visite.
2. **Respiration** — pulsation de 3 s : une décision est attendue de moi.
3. **Ligne fantôme** — repère en pointillé : attendu mais incomplet.
4. **Trace** — courte traînée derrière un repère créé il y a moins de 24 h.
5. **Connexion** — trait fin entre deux repères liés, visible seulement en mode relié.
6. **Écho** — anneau très fin autour d'un repère qui existe aussi dans l'autre ligne.
7. **Onde** — propagation d'un repère vers ses liés, 600 ms, une seule fois.
8. **Ombre portée** — un repère déplacé laisse la marque de sa position d'origine tant que le changement n'est pas validé.
9. **Épaisseur** — un repère qui concerne plusieurs personnes est légèrement plus large.
10. **Grisé** — hors du calque actif, le repère reste en place à 25 % d'opacité.
11. **Encoche de dépendance** — petit cran sur le bord gauche d'un repère qui en suppose un autre.
12. **Compte à rebours** — chiffre discret sous le repère le plus proche.
13. **Barre de complétude** — trait de 2 px sous un repère partiellement renseigné.
14. **Point d'ancrage** — le repère sélectionné reste plein et centré pendant toute la projection.

Aucun signe n'est décoratif : chacun répond à une question précise.

## H — « Ce qui est lié »

Séquence proposée, 3 étapes, aucune navigation :
1. **Ancrage** — le repère cliqué se fige au centre.
2. **Révélation** — 300 ms : les non-liés passent à 25 %, les liés gardent leur présence, les traits apparaissent avec leur raison (« même prestataire », « ce devis », « dépend de »).
3. **Chaîne** — pour un prestataire : devis → paiement → cérémonie → photos → mariés, parcourable de proche en proche, chaque saut ré-ancrant la règle.

Sortie par Échap, clic hors repère ou second clic sur « Ce qui est lié ». La création d'un lien se fait en glissant un repère sur un autre — cela active enfin `link()` de `timelineRelations.ts`, aujourd'hui écrit mais jamais appelé.

## I — Le temps comme navigation causale

Depuis la bulle, six questions, toutes calculables avec l'existant (`relatedIds`, `analyzeTimeline`, `simulateDateChange`, `causalImpacts.ts`) :
« Qu'y a-t-il avant ? », « Après ? », « Pourquoi ce moment existe ? », « Qu'est-ce qui en dépend ? », « Qui doit agir avant moi ? », « Que change un déplacement ? » — cette dernière montre les repères entraînés en ombre portée avant validation.

AIME intervient au bon endroit du temps plutôt que dans un panneau : doute sur une heure déduite, trou dans le déroulé, dépendance signalée, information déjà présente dans un document, étape préparée en pointillé. Règle inchangée : rien n'est écrit avant validation.

## J — Projection MOI ↔ MONDE

Mécanisme proposé :
- Chaque repère personnel issu d'un projet porte déjà `projectId`. La bulle affiche donc « Ce moment appartient au projet X » et un bouton **« Voir le contexte »**.
- Au clic, on **ne navigue pas** : le contexte de la règle change, l'instant et le zoom sont conservés, le repère reste au centre et le monde du projet se construit autour de lui (lieu, personnes, prestataires, documents, musique).
- Un fil d'Ariane d'un seul mot indique le contexte courant : *Moi* / *Mariage Camille & Thomas*, avec retour instantané.
- Inversement, sur un repère de projet qui me concerne : anneau d'écho + « Vous êtes concerné » + **« Voir ma perspective »**.
- Techniquement, l'URL porte le contexte (`?vue=personne|projet&at=<ms>&ancre=<markerId>`), donc la projection est partageable et réversible sans perte.

## K — Mobile

- Sélection : un tap ouvre la bulle épinglée ; pas de survol.
- Bulle : feuille remontant du bas, hauteur 60 % maximum, sections repliées sauf « Ce que je peux faire ».
- Actions : 2 boutons visibles maximum, le reste sous « + Voir davantage ».
- Mode relié : les traits sont remplacés par une liste ordonnée navigable ; l'estompage est conservé.
- Ciel : une seule mention.
- Zoom : pincement ; le glisser-déposer de repères est **désactivé** (conflit avec le défilement), remplacé par « Déplacer » dans la bulle.
- Projection : bascule de contexte par bouton, jamais par geste.
- Signes : halo, pointillé et respiration seulement ; ondes et traces désactivées.

## L — Architecture technique

Une seule chaîne, quatre couches :

```text
SOURCE      base : card_timeline_entries, events, quotes,
            event_payments, bureau_documents, messages,
            musicbox_entries, timeline_relations
   ↓
MODÈLE      WorldProject (world/types.ts) — un par contexte
            contexte personne = agrégat multi-projets
   ↓
PROJECTION  deriveTimeline() → TimelineMarker[]  (unique)
            + withRelations() + analyzeTimeline()
   ↓
VUE         HeroTimeline + bulle + ciel + calques + PLAY
```

Conséquence : `cardTimeline.ts` cesse d'être un second moteur et devient un **chargeur** qui construit un `WorldProject` de contexte personnel. `deriveTimeline()` reste l'unique projection. Aucun nouveau moteur n'est créé — on en retire un.

Charge cognitive, règles de densité : 4 niveaux (1 bloquant, 2 attention, 3 intéressant, 4 informatif). Au plus **1 pulsation**, **3 mentions de ciel**, **5 traits de relation**, **7 alertes** visibles simultanément ; au-delà, regroupement en dossier. Les niveaux 3 et 4 n'apparaissent qu'au zoom serré.

## M — Plan de développement

**P0 — fondation**
1. Notion de contexte (`personne` / `projet`) dans l'URL et le modèle.
2. `cardTimeline.ts` devient chargeur ; `deriveTimeline` unique projection.
3. Suppression des fichiers morts.
4. Bulle en 5 sections (ce que c'est / concerné / ce qui se passe / lié / je peux faire), 4 actions maximum.
5. `analyzeTimeline` projeté en pastilles sur la règle.
6. Ciel minimal : Aujourd'hui, prochaine décision, ce qui manque.

**P1 — interactions**
7. Mode relié complet avec traits et raisons.
8. Création de relation par glisser.
9. Projection MOI ↔ MONDE avec conservation de l'instant et anneau d'écho.
10. Actions réelles dans la bulle : cocher, répondre, payer, ouvrir un document, écouter, inviter — sur les deux contextes.
11. Retrait des blocs verticaux rendus inutiles.
12. Règles mobiles.

**P2 — intelligence et innovations**
13. Signes visuels 4 à 14.
14. Navigation causale (six questions).
15. Déplacement avec propagation et ombre portée.
16. Interventions proactives d'AIME dans le temps.
17. Rétroplanning depuis un repère.

---

Rien n'est modifié. Dites-moi si l'on démarre le P0, et si vous voulez commencer par l'unification du moteur (invisible mais structurante) ou par la bulle en 5 sections (visible immédiatement).
