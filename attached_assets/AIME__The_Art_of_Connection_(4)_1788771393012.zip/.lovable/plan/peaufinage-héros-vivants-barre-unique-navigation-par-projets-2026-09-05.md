# Peaufinage : héros vivants, barre unique, navigation par projets

Huit chantiers, tous sur l'existant — aucune nouvelle page, aucune donnée dupliquée.

## 1. Le bloc « Mode DJ » quitte le héros

Sur une page personne, l'encart DJ (morceau actuel, prochain morceau, événement suivant, « Lancer la playlist ») descend juste sous la section **Médias**, en pleine largeur, dans le même cadre que les autres sections. Le héros ne garde que le visuel et le titre.

## 2. « Ma page » devient le sélecteur de projets

Dans la barre du bas, le bouton « Ma page » se déplie vers le haut : ma page personnelle en premier, puis la liste de mes projets (titre, date, ville) et un lien « Nouveau projet ». On passe d'une page à l'autre sans repasser par l'accueil. La page en cours est marquée.

## 3. La radio s'ouvre dans l'en-tête

Le clic sur le bouton radio n'affiche plus une capsule flottante au-dessus du contenu : la capsule se loge au centre de l'en-tête (titre, lecture, cœur, suivant, fermer), et rétrécit à l'essentiel sur téléphone. Plus aucune superposition sur la page.

## 4. Page Recherche

- Le pied de page reste ancré en bas même quand la page est vide.
- Le champ reprend le design de la barre du Réseau : grande barre blanche arrondie, picto loupe, bouton cœur, bouton « Filtres ».
- Nouveau : quand la recherche interne ne suffit pas, AIME cherche aussi sur le web (lecture de pages publiques, déjà en place pour la Mémoire Web) et affiche les résultats dans le style du site, groupés par catégorie : Pages · Projets · Moments · Sur le web. Chaque résultat web indique sa source et peut être envoyé vers une ligne de temps (validation humaine, jamais d'ajout automatique).

## 5. Héros de l'accueil : une seule barre, des boutons qui se succèdent

Le héros perd ses textes. Il ne reste que le titre **THE ART OF CONNECTION** et, dessous, une barre blanche au design du Réseau. Dans cette barre, un seul bouton à la fois apparaît au même endroit, l'un après l'autre :

```text
[ Date ] → [ Ville / lieu ] → [ Budget ] → [ Nombre de personnes ] → [ Type de projet ] → [ Ouvrir mon projet ]
```

Chaque réponse reste visible en petite pastille à gauche ; on peut revenir en arrière.

## 6. L'animation « AI+ME » au chargement du projet

Au clic sur « Ouvrir mon projet », une animation centrale : le « + » tourne lentement entre **AI** et **ME**, le **ME** monte progressivement jusqu'au blanc plein à 100 %. Les étapes de construction s'écrivent une par une, lentement. À chaque information posée, un picto clignote puis file depuis la barre de saisie jusqu'à sa place sur la ligne de temps.

## 7. Le héros d'un projet devient l'écran d'information

Le héros ne liste plus « 0 places pourvues / 12 places à pourvoir / Budget à poser / Jour J passé » ni le paragraphe explicatif. Il affiche le titre, la date, le lieu — et rien d'autre au repos. Ensuite, il répond aux boutons :

- **AVANT** : ce qui est préparé, ce qui manque, prochaine échéance.
- **PENDANT** : le déroulé du jour, **et la météo** du jour J bien mise en forme (température, pluie, vent, plan B).
- **APRÈS** : « Vos souvenirs viendront ici », et ce qui est déjà arrivé.
- **Ce qui est relié** : les liens de cause à effet s'affichent dans le héros — rendre visible ce qui ne l'est pas.

**Play Jour J** ne s'ouvre plus en calque noir : la lecture se joue dans le héros, le titre et les détails du moment en cours s'y affichent, et la barre de lecture, c'est la ligne de temps elle-même qui balaie ses repères.

## 8. Le bouton « Veille » s'explique

Dans son panneau, une phrase claire en tête : à quoi sert la veille (ce qui bouge autour du projet et ce qui va suivre), avec un exemple concret, et l'état actuel quand il n'y a encore rien à signaler.

## Détails techniques

- Fichiers touchés : `DjMode.tsx` + `carte.$id.tsx` (déplacement sous `MediaGrid`), `GlobalDock.tsx` (menu projets via `eventsQuery`), `RadioBar.tsx` / `RadioStage.tsx` / `AppShell.tsx` (capsule dans le header, slot central), `recherche.tsx` + `src/lib/aime/search.ts` (barre style Réseau, résultats web via Firecrawl, `min-h-screen flex flex-col` pour ancrer `SiteFooter`), `HomeJourney.tsx` (barre séquentielle + écran de chargement AI+ME), `ProjectStage.tsx` / `HeroTimeline.tsx` / `WeatherPanel.tsx` (héros contextuel, Play dans le héros), `ProjectPanels.tsx` (texte de la veille).
- La météo réutilise `weather.functions.ts` ; les liens de causalité réutilisent `causal.ts` / `CausalPanel.tsx`. Aucune donnée n'est recopiée : le héros lit la même `WorldProject` et la même `deriveTimeline`.
- Le mode `embed` (démo dans le téléphone) garde son comportement actuel.
- Vérification navigateur sur ordinateur et téléphone, puis contrôle des types.
