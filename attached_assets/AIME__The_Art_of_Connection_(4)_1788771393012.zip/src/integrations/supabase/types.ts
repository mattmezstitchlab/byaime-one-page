export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_memory: {
        Row: {
          content: string
          created_at: string
          id: string
          kind: string
          label: string
          pinned: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          kind?: string
          label: string
          pinned?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          kind?: string
          label?: string
          pinned?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_usage: {
        Row: {
          created_at: string
          credits: number
          detail: string | null
          feature: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          credits?: number
          detail?: string | null
          feature: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          credits?: number
          detail?: string | null
          feature?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      aimes: {
        Row: {
          card_id: string
          created_at: string
          id: string
          intent: Database["public"]["Enums"]["aime_intent"]
          message: string | null
          requested_date: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          card_id: string
          created_at?: string
          id?: string
          intent?: Database["public"]["Enums"]["aime_intent"]
          message?: string | null
          requested_date?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          card_id?: string
          created_at?: string
          id?: string
          intent?: Database["public"]["Enums"]["aime_intent"]
          message?: string | null
          requested_date?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "aimes_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      airplay_logs: {
        Row: {
          artist: string | null
          card_id: string | null
          context: string | null
          created_at: string
          duration_sec: number
          ended_at: string
          entry_id: string | null
          event_id: string | null
          id: string
          isrc: string | null
          owner_id: string
          started_at: string
          title: string
          work_id: string | null
        }
        Insert: {
          artist?: string | null
          card_id?: string | null
          context?: string | null
          created_at?: string
          duration_sec: number
          ended_at: string
          entry_id?: string | null
          event_id?: string | null
          id?: string
          isrc?: string | null
          owner_id: string
          started_at: string
          title: string
          work_id?: string | null
        }
        Update: {
          artist?: string | null
          card_id?: string | null
          context?: string | null
          created_at?: string
          duration_sec?: number
          ended_at?: string
          entry_id?: string | null
          event_id?: string | null
          id?: string
          isrc?: string | null
          owner_id?: string
          started_at?: string
          title?: string
          work_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "airplay_logs_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "airplay_logs_entry_id_fkey"
            columns: ["entry_id"]
            isOneToOne: false
            referencedRelation: "musicbox_entries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "airplay_logs_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "airplay_logs_work_id_fkey"
            columns: ["work_id"]
            isOneToOne: false
            referencedRelation: "works"
            referencedColumns: ["id"]
          },
        ]
      }
      ambassador_missions: {
        Row: {
          detail: string
          effort: string
          family: string
          skill: string
          slug: string
          sort_order: number
          summary: string
          title: string
          value: number
        }
        Insert: {
          detail: string
          effort: string
          family: string
          skill: string
          slug: string
          sort_order?: number
          summary: string
          title: string
          value?: number
        }
        Update: {
          detail?: string
          effort?: string
          family?: string
          skill?: string
          slug?: string
          sort_order?: number
          summary?: string
          title?: string
          value?: number
        }
        Relationships: []
      }
      ambassadors: {
        Row: {
          accepted: boolean
          avatar_url: string | null
          city: string | null
          created_at: string
          display_name: string | null
          help_consent: boolean
          note: string | null
          online_until: string | null
          points: number
          skills: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          accepted?: boolean
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          display_name?: string | null
          help_consent?: boolean
          note?: string | null
          online_until?: string | null
          points?: number
          skills?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          accepted?: boolean
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          display_name?: string | null
          help_consent?: boolean
          note?: string | null
          online_until?: string | null
          points?: number
          skills?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      beta_feedback: {
        Row: {
          author_id: string | null
          contact: string | null
          created_at: string
          id: string
          kind: string
          message: string
          name: string | null
          page: string | null
          status: string
          supports: number
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          contact?: string | null
          created_at?: string
          id?: string
          kind?: string
          message: string
          name?: string | null
          page?: string | null
          status?: string
          supports?: number
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          contact?: string | null
          created_at?: string
          id?: string
          kind?: string
          message?: string
          name?: string | null
          page?: string | null
          status?: string
          supports?: number
          updated_at?: string
        }
        Relationships: []
      }
      blocks: {
        Row: {
          blocked_id: string
          blocker_id: string
          created_at: string
          id: string
        }
        Insert: {
          blocked_id: string
          blocker_id: string
          created_at?: string
          id?: string
        }
        Update: {
          blocked_id?: string
          blocker_id?: string
          created_at?: string
          id?: string
        }
        Relationships: []
      }
      bureau_documents: {
        Row: {
          amount_ht: number | null
          amount_ttc: number | null
          amount_vat: number | null
          confidence: number
          counterpart: string | null
          created_at: string
          currency: string
          direction: string
          doc_language: string | null
          doc_number: string | null
          doc_type: string
          due_on: string | null
          extraction: Json
          file_name: string
          folder_id: string | null
          id: string
          issued_on: string | null
          issuer: string | null
          message_id: string | null
          mime_type: string | null
          owner_id: string
          paid_on: string | null
          payment_method: string | null
          place: string | null
          purpose: string | null
          status: string
          storage_path: string
          uncertain_fields: string[]
          updated_at: string
        }
        Insert: {
          amount_ht?: number | null
          amount_ttc?: number | null
          amount_vat?: number | null
          confidence?: number
          counterpart?: string | null
          created_at?: string
          currency?: string
          direction?: string
          doc_language?: string | null
          doc_number?: string | null
          doc_type?: string
          due_on?: string | null
          extraction?: Json
          file_name: string
          folder_id?: string | null
          id?: string
          issued_on?: string | null
          issuer?: string | null
          message_id?: string | null
          mime_type?: string | null
          owner_id: string
          paid_on?: string | null
          payment_method?: string | null
          place?: string | null
          purpose?: string | null
          status?: string
          storage_path: string
          uncertain_fields?: string[]
          updated_at?: string
        }
        Update: {
          amount_ht?: number | null
          amount_ttc?: number | null
          amount_vat?: number | null
          confidence?: number
          counterpart?: string | null
          created_at?: string
          currency?: string
          direction?: string
          doc_language?: string | null
          doc_number?: string | null
          doc_type?: string
          due_on?: string | null
          extraction?: Json
          file_name?: string
          folder_id?: string | null
          id?: string
          issued_on?: string | null
          issuer?: string | null
          message_id?: string | null
          mime_type?: string | null
          owner_id?: string
          paid_on?: string | null
          payment_method?: string | null
          place?: string | null
          purpose?: string | null
          status?: string
          storage_path?: string
          uncertain_fields?: string[]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bureau_documents_folder_id_fkey"
            columns: ["folder_id"]
            isOneToOne: false
            referencedRelation: "bureau_folders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bureau_documents_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      bureau_exports: {
        Row: {
          blocking: number
          created_at: string
          customers_count: number
          doc_count: number
          file_name: string
          format: string
          id: string
          owner_id: string
          period: string
          scope: string
          status: string
          suppliers_count: number
          total_ht: number
          total_ttc: number
          total_vat: number
        }
        Insert: {
          blocking?: number
          created_at?: string
          customers_count?: number
          doc_count?: number
          file_name: string
          format?: string
          id?: string
          owner_id: string
          period: string
          scope?: string
          status?: string
          suppliers_count?: number
          total_ht?: number
          total_ttc?: number
          total_vat?: number
        }
        Update: {
          blocking?: number
          created_at?: string
          customers_count?: number
          doc_count?: number
          file_name?: string
          format?: string
          id?: string
          owner_id?: string
          period?: string
          scope?: string
          status?: string
          suppliers_count?: number
          total_ht?: number
          total_ttc?: number
          total_vat?: number
        }
        Relationships: []
      }
      bureau_folders: {
        Row: {
          card_id: string | null
          counterpart: string | null
          created_at: string
          event_id: string | null
          expected_amount: number | null
          id: string
          kind: string
          note: string | null
          owner_id: string
          parent_id: string | null
          score: number
          state: string
          thread_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          card_id?: string | null
          counterpart?: string | null
          created_at?: string
          event_id?: string | null
          expected_amount?: number | null
          id?: string
          kind?: string
          note?: string | null
          owner_id: string
          parent_id?: string | null
          score?: number
          state?: string
          thread_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          card_id?: string | null
          counterpart?: string | null
          created_at?: string
          event_id?: string | null
          expected_amount?: number | null
          id?: string
          kind?: string
          note?: string | null
          owner_id?: string
          parent_id?: string | null
          score?: number
          state?: string
          thread_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bureau_folders_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bureau_folders_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bureau_folders_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "bureau_folders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bureau_folders_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      bureau_links: {
        Row: {
          confirmed: boolean
          created_at: string
          from_document_id: string
          id: string
          origin: string
          owner_id: string
          relation: string
          to_document_id: string
        }
        Insert: {
          confirmed?: boolean
          created_at?: string
          from_document_id: string
          id?: string
          origin?: string
          owner_id: string
          relation: string
          to_document_id: string
        }
        Update: {
          confirmed?: boolean
          created_at?: string
          from_document_id?: string
          id?: string
          origin?: string
          owner_id?: string
          relation?: string
          to_document_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bureau_links_from_document_id_fkey"
            columns: ["from_document_id"]
            isOneToOne: false
            referencedRelation: "bureau_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bureau_links_to_document_id_fkey"
            columns: ["to_document_id"]
            isOneToOne: false
            referencedRelation: "bureau_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      bureau_members: {
        Row: {
          accepted_at: string | null
          created_at: string
          display_name: string | null
          email: string
          id: string
          invite_token: string
          invited_at: string
          member_user_id: string | null
          note: string | null
          owner_id: string
          role: string
          scopes: string[]
          status: string
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string
          display_name?: string | null
          email: string
          id?: string
          invite_token?: string
          invited_at?: string
          member_user_id?: string | null
          note?: string | null
          owner_id: string
          role?: string
          scopes?: string[]
          status?: string
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string
          display_name?: string | null
          email?: string
          id?: string
          invite_token?: string
          invited_at?: string
          member_user_id?: string | null
          note?: string | null
          owner_id?: string
          role?: string
          scopes?: string[]
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      card_availability: {
        Row: {
          card_id: string
          created_at: string
          day: string
          id: string
          note: string | null
          status: string
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          day: string
          id?: string
          note?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          day?: string
          id?: string
          note?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "card_availability_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_capabilities: {
        Row: {
          cap_id: string
          card_id: string
          created_at: string
          id: string
          state: string
          updated_at: string
          value: string | null
        }
        Insert: {
          cap_id: string
          card_id: string
          created_at?: string
          id?: string
          state?: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          cap_id?: string
          card_id?: string
          created_at?: string
          id?: string
          state?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "card_capabilities_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_claims: {
        Row: {
          attempts: number
          card_id: string
          code_hash: string | null
          created_at: string
          email: string
          expires_at: string | null
          id: string
          note: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          attempts?: number
          card_id: string
          code_hash?: string | null
          created_at?: string
          email: string
          expires_at?: string | null
          id?: string
          note?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          attempts?: number
          card_id?: string
          code_hash?: string | null
          created_at?: string
          email?: string
          expires_at?: string | null
          id?: string
          note?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "card_claims_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_contacts: {
        Row: {
          address: string | null
          card_id: string
          created_at: string
          phone: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          card_id: string
          created_at?: string
          phone?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          card_id?: string
          created_at?: string
          phone?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "card_contacts_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: true
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_identity: {
        Row: {
          birth_city: string | null
          birth_country: string | null
          born_on: string | null
          born_precision: string
          card_id: string
          certainty: Json
          created_at: string
          death_city: string | null
          died_on: string | null
          note: string | null
          updated_at: string
          visibility: string
        }
        Insert: {
          birth_city?: string | null
          birth_country?: string | null
          born_on?: string | null
          born_precision?: string
          card_id: string
          certainty?: Json
          created_at?: string
          death_city?: string | null
          died_on?: string | null
          note?: string | null
          updated_at?: string
          visibility?: string
        }
        Update: {
          birth_city?: string | null
          birth_country?: string | null
          born_on?: string | null
          born_precision?: string
          card_id?: string
          certainty?: Json
          created_at?: string
          death_city?: string | null
          died_on?: string | null
          note?: string | null
          updated_at?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "card_identity_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: true
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_memory: {
        Row: {
          card_id: string
          created_at: string
          disclaimer: string
          era: string | null
          summary: string
        }
        Insert: {
          card_id: string
          created_at?: string
          disclaimer?: string
          era?: string | null
          summary: string
        }
        Update: {
          card_id?: string
          created_at?: string
          disclaimer?: string
          era?: string | null
          summary?: string
        }
        Relationships: [
          {
            foreignKeyName: "card_memory_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: true
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_references: {
        Row: {
          card_id: string
          created_at: string
          id: string
          level: string
          note: string | null
          publisher: string | null
          sort_order: number
          title: string
          url: string | null
        }
        Insert: {
          card_id: string
          created_at?: string
          id?: string
          level: string
          note?: string | null
          publisher?: string | null
          sort_order?: number
          title: string
          url?: string | null
        }
        Update: {
          card_id?: string
          created_at?: string
          id?: string
          level?: string
          note?: string | null
          publisher?: string | null
          sort_order?: number
          title?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "card_references_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_sources: {
        Row: {
          address: string | null
          card_id: string | null
          city: string | null
          country: string | null
          created_at: string
          headline: string | null
          id: string
          name: string
          payload: Json
          phone: string | null
          skills: string[]
          source_url: string | null
          status: string
          sub_slug: string | null
          universe_slug: string
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          card_id?: string | null
          city?: string | null
          country?: string | null
          created_at?: string
          headline?: string | null
          id?: string
          name: string
          payload?: Json
          phone?: string | null
          skills?: string[]
          source_url?: string | null
          status?: string
          sub_slug?: string | null
          universe_slug: string
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          card_id?: string | null
          city?: string | null
          country?: string | null
          created_at?: string
          headline?: string | null
          id?: string
          name?: string
          payload?: Json
          phone?: string | null
          skills?: string[]
          source_url?: string | null
          status?: string
          sub_slug?: string | null
          universe_slug?: string
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "card_sources_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      card_timeline_entries: {
        Row: {
          card_id: string
          created_at: string
          description: string | null
          done_at: string | null
          due_at: string | null
          ends_at: string | null
          id: string
          is_public: boolean
          kind: string
          link_event_id: string | null
          metadata: Json
          priority: number
          secrecy: string
          secret_holder_ids: string[]
          starts_at: string
          status: string
          title: string
          universe_slug: string | null
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          description?: string | null
          done_at?: string | null
          due_at?: string | null
          ends_at?: string | null
          id?: string
          is_public?: boolean
          kind?: string
          link_event_id?: string | null
          metadata?: Json
          priority?: number
          secrecy?: string
          secret_holder_ids?: string[]
          starts_at: string
          status?: string
          title: string
          universe_slug?: string | null
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          description?: string | null
          done_at?: string | null
          due_at?: string | null
          ends_at?: string | null
          id?: string
          is_public?: boolean
          kind?: string
          link_event_id?: string | null
          metadata?: Json
          priority?: number
          secrecy?: string
          secret_holder_ids?: string[]
          starts_at?: string
          status?: string
          title?: string
          universe_slug?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "card_timeline_entries_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "card_timeline_entries_link_event_id_fkey"
            columns: ["link_event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      cards: {
        Row: {
          agent_rules: Json
          availability: string | null
          availability_slots: string[]
          bio: string | null
          budget_max: number | null
          budget_min: number | null
          category_slug: string
          city: string | null
          claim_status: string
          country: string
          created_at: string
          experiences: string[]
          gallery: string[]
          headline: string
          id: string
          image_url: string | null
          kind: Database["public"]["Enums"]["card_kind"]
          lat: number | null
          lon: number | null
          name: string
          owner_id: string | null
          price_level: number
          published: boolean
          rating: number
          region: string | null
          reviews_count: number
          skills: string[]
          source: string | null
          source_url: string | null
          status: Database["public"]["Enums"]["card_status"]
          tags: string[]
          universe_cards: Json
          universes: string[]
          updated_at: string
          verified: boolean
          video_url: string | null
          visual_key: string
        }
        Insert: {
          agent_rules?: Json
          availability?: string | null
          availability_slots?: string[]
          bio?: string | null
          budget_max?: number | null
          budget_min?: number | null
          category_slug: string
          city?: string | null
          claim_status?: string
          country?: string
          created_at?: string
          experiences?: string[]
          gallery?: string[]
          headline?: string
          id?: string
          image_url?: string | null
          kind?: Database["public"]["Enums"]["card_kind"]
          lat?: number | null
          lon?: number | null
          name: string
          owner_id?: string | null
          price_level?: number
          published?: boolean
          rating?: number
          region?: string | null
          reviews_count?: number
          skills?: string[]
          source?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["card_status"]
          tags?: string[]
          universe_cards?: Json
          universes?: string[]
          updated_at?: string
          verified?: boolean
          video_url?: string | null
          visual_key?: string
        }
        Update: {
          agent_rules?: Json
          availability?: string | null
          availability_slots?: string[]
          bio?: string | null
          budget_max?: number | null
          budget_min?: number | null
          category_slug?: string
          city?: string | null
          claim_status?: string
          country?: string
          created_at?: string
          experiences?: string[]
          gallery?: string[]
          headline?: string
          id?: string
          image_url?: string | null
          kind?: Database["public"]["Enums"]["card_kind"]
          lat?: number | null
          lon?: number | null
          name?: string
          owner_id?: string | null
          price_level?: number
          published?: boolean
          rating?: number
          region?: string | null
          reviews_count?: number
          skills?: string[]
          source?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["card_status"]
          tags?: string[]
          universe_cards?: Json
          universes?: string[]
          updated_at?: string
          verified?: boolean
          video_url?: string | null
          visual_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "cards_category_slug_fkey"
            columns: ["category_slug"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["slug"]
          },
        ]
      }
      categories: {
        Row: {
          emoji: string
          kind: Database["public"]["Enums"]["card_kind"]
          label: string
          registry_group: string
          slug: string
          sort_order: number
        }
        Insert: {
          emoji?: string
          kind: Database["public"]["Enums"]["card_kind"]
          label: string
          registry_group: string
          slug: string
          sort_order?: number
        }
        Update: {
          emoji?: string
          kind?: Database["public"]["Enums"]["card_kind"]
          label?: string
          registry_group?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      comments: {
        Row: {
          body: string
          card_id: string | null
          created_at: string
          id: string
          parent_id: string | null
          target_id: string
          target_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          body: string
          card_id?: string | null
          created_at?: string
          id?: string
          parent_id?: string | null
          target_id: string
          target_type?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          body?: string
          card_id?: string | null
          created_at?: string
          id?: string
          parent_id?: string | null
          target_id?: string
          target_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comments_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "comments_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
        ]
      }
      commons_items: {
        Row: {
          available: boolean
          city: string | null
          created_at: string
          detail: string | null
          id: string
          kind: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          available?: boolean
          city?: string | null
          created_at?: string
          detail?: string | null
          id?: string
          kind?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          available?: boolean
          city?: string | null
          created_at?: string
          detail?: string | null
          id?: string
          kind?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      composition_items: {
        Row: {
          card_id: string
          composition_id: string
          created_at: string
          id: string
          position: number
          slot_label: string
        }
        Insert: {
          card_id: string
          composition_id: string
          created_at?: string
          id?: string
          position?: number
          slot_label?: string
        }
        Update: {
          card_id?: string
          composition_id?: string
          created_at?: string
          id?: string
          position?: number
          slot_label?: string
        }
        Relationships: [
          {
            foreignKeyName: "composition_items_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "composition_items_composition_id_fkey"
            columns: ["composition_id"]
            isOneToOne: false
            referencedRelation: "compositions"
            referencedColumns: ["id"]
          },
        ]
      }
      compositions: {
        Row: {
          brief: string | null
          card_id: string | null
          created_at: string
          id: string
          target_week: string | null
          title: string
          universe_slug: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          brief?: string | null
          card_id?: string | null
          created_at?: string
          id?: string
          target_week?: string | null
          title?: string
          universe_slug?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          brief?: string | null
          card_id?: string | null
          created_at?: string
          id?: string
          target_week?: string | null
          title?: string
          universe_slug?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "compositions_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_ledger: {
        Row: {
          amount_cents: number
          created_at: string
          credits: number
          id: string
          kind: string
          method: string
          note: string | null
          reference: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_cents: number
          created_at?: string
          credits?: number
          id?: string
          kind: string
          method?: string
          note?: string | null
          reference?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_cents?: number
          created_at?: string
          credits?: number
          id?: string
          kind?: string
          method?: string
          note?: string | null
          reference?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      encounters: {
        Row: {
          card_ids: string[]
          created_at: string
          explanation: string | null
          id: string
          intent_text: string | null
          reasons: string[]
          score: number
          title: string
          user_id: string
        }
        Insert: {
          card_ids?: string[]
          created_at?: string
          explanation?: string | null
          id?: string
          intent_text?: string | null
          reasons?: string[]
          score?: number
          title: string
          user_id: string
        }
        Update: {
          card_ids?: string[]
          created_at?: string
          explanation?: string | null
          id?: string
          intent_text?: string | null
          reasons?: string[]
          score?: number
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      event_invitations: {
        Row: {
          created_at: string
          email: string
          event_id: string
          id: string
          name: string | null
          responded_at: string | null
          role_label: string
          sent_at: string | null
          status: string
          token: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          event_id: string
          id?: string
          name?: string | null
          responded_at?: string | null
          role_label?: string
          sent_at?: string | null
          status?: string
          token?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          event_id?: string
          id?: string
          name?: string | null
          responded_at?: string | null
          role_label?: string
          sent_at?: string | null
          status?: string
          token?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_invitations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      event_participants: {
        Row: {
          card_id: string
          created_at: string
          event_id: string
          id: string
          role_label: string
          status: string
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          event_id: string
          id?: string
          role_label?: string
          status?: string
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          event_id?: string
          id?: string
          role_label?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_participants_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_participants_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      event_payments: {
        Row: {
          amount_due: number
          amount_paid: number
          card_id: string | null
          created_at: string
          event_id: string
          id: string
          label: string
          paid_at: string | null
          participant_id: string | null
          payer_email: string | null
          payer_name: string
          status: string
          updated_at: string
        }
        Insert: {
          amount_due?: number
          amount_paid?: number
          card_id?: string | null
          created_at?: string
          event_id: string
          id?: string
          label?: string
          paid_at?: string | null
          participant_id?: string | null
          payer_email?: string | null
          payer_name?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount_due?: number
          amount_paid?: number
          card_id?: string | null
          created_at?: string
          event_id?: string
          id?: string
          label?: string
          paid_at?: string | null
          participant_id?: string | null
          payer_email?: string | null
          payer_name?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_payments_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_payments_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_payments_participant_id_fkey"
            columns: ["participant_id"]
            isOneToOne: false
            referencedRelation: "event_participants"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          card_id: string | null
          city: string | null
          created_at: string
          description: string | null
          encounter_id: string | null
          ends_at: string | null
          id: string
          location: string | null
          owner_id: string
          starts_at: string
          status: string
          title: string
          universe_slug: string | null
          updated_at: string
        }
        Insert: {
          card_id?: string | null
          city?: string | null
          created_at?: string
          description?: string | null
          encounter_id?: string | null
          ends_at?: string | null
          id?: string
          location?: string | null
          owner_id: string
          starts_at: string
          status?: string
          title: string
          universe_slug?: string | null
          updated_at?: string
        }
        Update: {
          card_id?: string | null
          city?: string | null
          created_at?: string
          description?: string | null
          encounter_id?: string | null
          ends_at?: string | null
          id?: string
          location?: string | null
          owner_id?: string
          starts_at?: string
          status?: string
          title?: string
          universe_slug?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "events_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "events_encounter_id_fkey"
            columns: ["encounter_id"]
            isOneToOne: false
            referencedRelation: "encounters"
            referencedColumns: ["id"]
          },
        ]
      }
      exploration_signals: {
        Row: {
          anon_id: string | null
          created_at: string
          id: string
          kind: string
          sub: string | null
          universe: string
          user_id: string | null
          value: Json
        }
        Insert: {
          anon_id?: string | null
          created_at?: string
          id?: string
          kind: string
          sub?: string | null
          universe: string
          user_id?: string | null
          value?: Json
        }
        Update: {
          anon_id?: string | null
          created_at?: string
          id?: string
          kind?: string
          sub?: string | null
          universe?: string
          user_id?: string | null
          value?: Json
        }
        Relationships: []
      }
      family_links: {
        Row: {
          certainty: string
          created_at: string
          created_by: string
          evidence: Json
          from_card_id: string
          id: string
          note: string | null
          relation: string
          source_ref_id: string | null
          to_card_id: string
          updated_at: string
          visibility: string
        }
        Insert: {
          certainty?: string
          created_at?: string
          created_by?: string
          evidence?: Json
          from_card_id: string
          id?: string
          note?: string | null
          relation: string
          source_ref_id?: string | null
          to_card_id: string
          updated_at?: string
          visibility?: string
        }
        Update: {
          certainty?: string
          created_at?: string
          created_by?: string
          evidence?: Json
          from_card_id?: string
          id?: string
          note?: string | null
          relation?: string
          source_ref_id?: string | null
          to_card_id?: string
          updated_at?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "family_links_from_card_id_fkey"
            columns: ["from_card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "family_links_source_ref_id_fkey"
            columns: ["source_ref_id"]
            isOneToOne: false
            referencedRelation: "card_references"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "family_links_to_card_id_fkey"
            columns: ["to_card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      follows: {
        Row: {
          card_id: string
          created_at: string
          follower_id: string
          id: string
        }
        Insert: {
          card_id: string
          created_at?: string
          follower_id: string
          id?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          follower_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "follows_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      help_needs: {
        Row: {
          amount_cents: number | null
          created_at: string
          detail: string | null
          due_on: string | null
          id: string
          kind: string
          label: string
          quantity_done: number
          quantity_needed: number
          request_id: string
          updated_at: string
        }
        Insert: {
          amount_cents?: number | null
          created_at?: string
          detail?: string | null
          due_on?: string | null
          id?: string
          kind?: string
          label: string
          quantity_done?: number
          quantity_needed?: number
          request_id: string
          updated_at?: string
        }
        Update: {
          amount_cents?: number | null
          created_at?: string
          detail?: string | null
          due_on?: string | null
          id?: string
          kind?: string
          label?: string
          quantity_done?: number
          quantity_needed?: number
          request_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "help_needs_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "help_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      help_pledges: {
        Row: {
          amount_cents: number | null
          created_at: string
          id: string
          message: string | null
          need_id: string
          quantity: number
          request_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_cents?: number | null
          created_at?: string
          id?: string
          message?: string | null
          need_id: string
          quantity?: number
          request_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_cents?: number | null
          created_at?: string
          id?: string
          message?: string | null
          need_id?: string
          quantity?: number
          request_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "help_pledges_need_id_fkey"
            columns: ["need_id"]
            isOneToOne: false
            referencedRelation: "help_needs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "help_pledges_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "help_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      help_requests: {
        Row: {
          category: string | null
          city: string | null
          created_at: string
          deadline: string | null
          declared_accurate: boolean
          detail: string | null
          event_id: string | null
          id: string
          kind: string
          reason: string | null
          review_note: string | null
          review_status: string
          reviewed_at: string | null
          reviewed_by: string | null
          reviewer_name: string | null
          status: string
          title: string
          universe_slug: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string | null
          city?: string | null
          created_at?: string
          deadline?: string | null
          declared_accurate?: boolean
          detail?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          reason?: string | null
          review_note?: string | null
          review_status?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_name?: string | null
          status?: string
          title: string
          universe_slug?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string | null
          city?: string | null
          created_at?: string
          deadline?: string | null
          declared_accurate?: boolean
          detail?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          reason?: string | null
          review_note?: string | null
          review_status?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_name?: string | null
          status?: string
          title?: string
          universe_slug?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "help_requests_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      intentions: {
        Row: {
          body: string
          city: string | null
          created_at: string
          id: string
          kind: string
          published: boolean
          status: string
          universe_slug: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          body: string
          city?: string | null
          created_at?: string
          id?: string
          kind?: string
          published?: boolean
          status?: string
          universe_slug?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          body?: string
          city?: string | null
          created_at?: string
          id?: string
          kind?: string
          published?: boolean
          status?: string
          universe_slug?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "intentions_universe_slug_fkey"
            columns: ["universe_slug"]
            isOneToOne: false
            referencedRelation: "universes"
            referencedColumns: ["slug"]
          },
        ]
      }
      invites: {
        Row: {
          code: string
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          label: string
          message: string | null
          universe_slug: string | null
          updated_at: string
          uses: number
        }
        Insert: {
          code: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          label?: string
          message?: string | null
          universe_slug?: string | null
          updated_at?: string
          uses?: number
        }
        Update: {
          code?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          label?: string
          message?: string | null
          universe_slug?: string | null
          updated_at?: string
          uses?: number
        }
        Relationships: []
      }
      kiss_prints: {
        Row: {
          card_id: string | null
          code: string
          created_at: string
          id: string
          seed: number
          user_id: string | null
        }
        Insert: {
          card_id?: string | null
          code: string
          created_at?: string
          id?: string
          seed?: number
          user_id?: string | null
        }
        Update: {
          card_id?: string | null
          code?: string
          created_at?: string
          id?: string
          seed?: number
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "kiss_prints_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      lab_boards: {
        Row: {
          created_at: string
          domain_slug: string | null
          event_id: string | null
          id: string
          owner_id: string
          title: string
          universe_slug: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          domain_slug?: string | null
          event_id?: string | null
          id?: string
          owner_id: string
          title?: string
          universe_slug?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          domain_slug?: string | null
          event_id?: string | null
          id?: string
          owner_id?: string
          title?: string
          universe_slug?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lab_boards_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      lab_members: {
        Row: {
          board_id: string
          card_id: string
          created_at: string
          id: string
          role_label: string
        }
        Insert: {
          board_id: string
          card_id: string
          created_at?: string
          id?: string
          role_label?: string
        }
        Update: {
          board_id?: string
          card_id?: string
          created_at?: string
          id?: string
          role_label?: string
        }
        Relationships: [
          {
            foreignKeyName: "lab_members_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "lab_boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lab_members_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      lab_objects: {
        Row: {
          board_id: string
          created_at: string
          created_by: string
          data: Json
          h: number | null
          id: string
          type: string
          updated_at: string
          w: number | null
          x: number
          y: number
          z: number
        }
        Insert: {
          board_id: string
          created_at?: string
          created_by: string
          data?: Json
          h?: number | null
          id?: string
          type: string
          updated_at?: string
          w?: number | null
          x?: number
          y?: number
          z?: number
        }
        Update: {
          board_id?: string
          created_at?: string
          created_by?: string
          data?: Json
          h?: number | null
          id?: string
          type?: string
          updated_at?: string
          w?: number | null
          x?: number
          y?: number
          z?: number
        }
        Relationships: [
          {
            foreignKeyName: "lab_objects_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "lab_boards"
            referencedColumns: ["id"]
          },
        ]
      }
      media_items: {
        Row: {
          card_id: string | null
          created_at: string
          created_by: string | null
          event_id: string | null
          id: string
          kind: string
          position: number
          thumb_url: string | null
          title: string | null
          updated_at: string
          url: string
          visibility: string
        }
        Insert: {
          card_id?: string | null
          created_at?: string
          created_by?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          position?: number
          thumb_url?: string | null
          title?: string | null
          updated_at?: string
          url: string
          visibility?: string
        }
        Update: {
          card_id?: string | null
          created_at?: string
          created_by?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          position?: number
          thumb_url?: string | null
          title?: string | null
          updated_at?: string
          url?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_items_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "media_items_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      meet_prefs: {
        Row: {
          card_id: string | null
          contact_policy: string
          created_at: string
          intents: string[]
          note: string | null
          range_key: string
          share_position: boolean
          updated_at: string
          user_id: string
          visible: boolean
        }
        Insert: {
          card_id?: string | null
          contact_policy?: string
          created_at?: string
          intents?: string[]
          note?: string | null
          range_key?: string
          share_position?: boolean
          updated_at?: string
          user_id: string
          visible?: boolean
        }
        Update: {
          card_id?: string | null
          contact_policy?: string
          created_at?: string
          intents?: string[]
          note?: string | null
          range_key?: string
          share_position?: boolean
          updated_at?: string
          user_id?: string
          visible?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "meet_prefs_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      meet_proposals: {
        Row: {
          created_at: string
          from_user: string
          id: string
          message: string | null
          moment: string | null
          place: string | null
          purpose: string
          signal_id: string | null
          status: string
          to_user: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          from_user: string
          id?: string
          message?: string | null
          moment?: string | null
          place?: string | null
          purpose?: string
          signal_id?: string | null
          status?: string
          to_user: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          from_user?: string
          id?: string
          message?: string | null
          moment?: string | null
          place?: string | null
          purpose?: string
          signal_id?: string | null
          status?: string
          to_user?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "meet_proposals_signal_id_fkey"
            columns: ["signal_id"]
            isOneToOne: false
            referencedRelation: "meet_signals"
            referencedColumns: ["id"]
          },
        ]
      }
      meet_signals: {
        Row: {
          created_at: string
          from_card: string | null
          from_user: string
          id: string
          kind: string
          message: string | null
          reasons: Json
          status: string
          thread_id: string | null
          to_card: string | null
          to_user: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          from_card?: string | null
          from_user: string
          id?: string
          kind?: string
          message?: string | null
          reasons?: Json
          status?: string
          thread_id?: string | null
          to_card?: string | null
          to_user: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          from_card?: string | null
          from_user?: string
          id?: string
          kind?: string
          message?: string | null
          reasons?: Json
          status?: string
          thread_id?: string | null
          to_card?: string | null
          to_user?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "meet_signals_from_card_fkey"
            columns: ["from_card"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "meet_signals_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "meet_signals_to_card_fkey"
            columns: ["to_card"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_name: string | null
          attachment_url: string | null
          body: string
          by_ai: boolean
          created_at: string
          id: string
          kind: string
          original_body: string | null
          read_at: string | null
          sender_id: string
          simplified: string | null
          source_lang: string | null
          thread_id: string
          translations: Json
        }
        Insert: {
          attachment_name?: string | null
          attachment_url?: string | null
          body: string
          by_ai?: boolean
          created_at?: string
          id?: string
          kind?: string
          original_body?: string | null
          read_at?: string | null
          sender_id: string
          simplified?: string | null
          source_lang?: string | null
          thread_id: string
          translations?: Json
        }
        Update: {
          attachment_name?: string | null
          attachment_url?: string | null
          body?: string
          by_ai?: boolean
          created_at?: string
          id?: string
          kind?: string
          original_body?: string | null
          read_at?: string | null
          sender_id?: string
          simplified?: string | null
          source_lang?: string | null
          thread_id?: string
          translations?: Json
        }
        Relationships: [
          {
            foreignKeyName: "messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      mission_intents: {
        Row: {
          created_at: string
          id: string
          message: string | null
          mission_slug: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message?: string | null
          mission_slug: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string | null
          mission_slug?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mission_intents_mission_slug_fkey"
            columns: ["mission_slug"]
            isOneToOne: false
            referencedRelation: "ambassador_missions"
            referencedColumns: ["slug"]
          },
        ]
      }
      musicbox_entries: {
        Row: {
          artist: string | null
          artwork_url: string | null
          audio_path: string | null
          card_id: string | null
          city: string | null
          created_at: string
          day: string
          dedicated_card_id: string | null
          dedicated_name: string | null
          duration_min: number
          event_id: string | null
          external_url: string | null
          id: string
          kind: string
          lat: number | null
          lon: number | null
          note: string | null
          owner_id: string
          position: number
          preview_url: string | null
          provider: string | null
          rights_status: string
          source_type: string
          source_url: string | null
          start_time: string
          status: string
          title: string
          track_id: string | null
          updated_at: string
          visibility: string
          work_id: string | null
        }
        Insert: {
          artist?: string | null
          artwork_url?: string | null
          audio_path?: string | null
          card_id?: string | null
          city?: string | null
          created_at?: string
          day: string
          dedicated_card_id?: string | null
          dedicated_name?: string | null
          duration_min?: number
          event_id?: string | null
          external_url?: string | null
          id?: string
          kind?: string
          lat?: number | null
          lon?: number | null
          note?: string | null
          owner_id: string
          position?: number
          preview_url?: string | null
          provider?: string | null
          rights_status?: string
          source_type?: string
          source_url?: string | null
          start_time?: string
          status?: string
          title: string
          track_id?: string | null
          updated_at?: string
          visibility?: string
          work_id?: string | null
        }
        Update: {
          artist?: string | null
          artwork_url?: string | null
          audio_path?: string | null
          card_id?: string | null
          city?: string | null
          created_at?: string
          day?: string
          dedicated_card_id?: string | null
          dedicated_name?: string | null
          duration_min?: number
          event_id?: string | null
          external_url?: string | null
          id?: string
          kind?: string
          lat?: number | null
          lon?: number | null
          note?: string | null
          owner_id?: string
          position?: number
          preview_url?: string | null
          provider?: string | null
          rights_status?: string
          source_type?: string
          source_url?: string | null
          start_time?: string
          status?: string
          title?: string
          track_id?: string | null
          updated_at?: string
          visibility?: string
          work_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "musicbox_entries_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "musicbox_entries_dedicated_card_id_fkey"
            columns: ["dedicated_card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "musicbox_entries_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "musicbox_entries_work_id_fkey"
            columns: ["work_id"]
            isOneToOne: false
            referencedRelation: "works"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          actor_id: string | null
          body: string | null
          created_at: string
          id: string
          kind: string
          read_at: string | null
          target_id: string | null
          target_type: string | null
          title: string
          url: string | null
          user_id: string
        }
        Insert: {
          actor_id?: string | null
          body?: string | null
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          target_id?: string | null
          target_type?: string | null
          title: string
          url?: string | null
          user_id: string
        }
        Update: {
          actor_id?: string | null
          body?: string | null
          created_at?: string
          id?: string
          kind?: string
          read_at?: string | null
          target_id?: string | null
          target_type?: string | null
          title?: string
          url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      objectives: {
        Row: {
          created_at: string
          due_on: string | null
          id: string
          is_public: boolean
          obstacles: Json
          status: string
          title: string
          updated_at: string
          user_id: string
          why: string | null
        }
        Insert: {
          created_at?: string
          due_on?: string | null
          id?: string
          is_public?: boolean
          obstacles?: Json
          status?: string
          title: string
          updated_at?: string
          user_id: string
          why?: string | null
        }
        Update: {
          created_at?: string
          due_on?: string | null
          id?: string
          is_public?: boolean
          obstacles?: Json
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
          why?: string | null
        }
        Relationships: []
      }
      passes: {
        Row: {
          card_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          card_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          card_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "passes_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_accounts: {
        Row: {
          billing_address: string | null
          created_at: string
          holder_name: string | null
          iban: string | null
          method: string
          revolut_tag: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          billing_address?: string | null
          created_at?: string
          holder_name?: string | null
          iban?: string | null
          method?: string
          revolut_tag?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          billing_address?: string | null
          created_at?: string
          holder_name?: string | null
          iban?: string | null
          method?: string
          revolut_tag?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      posts: {
        Row: {
          author_id: string
          body: string | null
          card_id: string
          created_at: string
          id: string
          media_kind: string
          media_url: string | null
          updated_at: string
          visibility: string
        }
        Insert: {
          author_id: string
          body?: string | null
          card_id: string
          created_at?: string
          id?: string
          media_kind?: string
          media_url?: string | null
          updated_at?: string
          visibility?: string
        }
        Update: {
          author_id?: string
          body?: string | null
          card_id?: string
          created_at?: string
          id?: string
          media_kind?: string
          media_url?: string | null
          updated_at?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "posts_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_geo: {
        Row: {
          id: string
          lat: number | null
          lon: number | null
          updated_at: string
        }
        Insert: {
          id: string
          lat?: number | null
          lon?: number | null
          updated_at?: string
        }
        Update: {
          id?: string
          lat?: number | null
          lon?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_geo_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profile_requests: {
        Row: {
          address: string | null
          availability: string | null
          budget_max: number | null
          budget_min: number | null
          city: string | null
          created_at: string
          email: string
          id: string
          message: string | null
          name: string
          phone: string | null
          requested_kind: string
          status: string
          universe_slug: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          availability?: string | null
          budget_max?: number | null
          budget_min?: number | null
          city?: string | null
          created_at?: string
          email: string
          id?: string
          message?: string | null
          name: string
          phone?: string | null
          requested_kind?: string
          status?: string
          universe_slug?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          availability?: string | null
          budget_max?: number | null
          budget_min?: number | null
          city?: string | null
          created_at?: string
          email?: string
          id?: string
          message?: string | null
          name?: string
          phone?: string | null
          requested_kind?: string
          status?: string
          universe_slug?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          a11y: Json
          avatar_url: string | null
          city: string | null
          created_at: string
          display_name: string
          geo_consent: boolean
          headline: string | null
          id: string
          locale: string
          radio_radius_km: number
          updated_at: string
        }
        Insert: {
          a11y?: Json
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          display_name?: string
          geo_consent?: boolean
          headline?: string | null
          id: string
          locale?: string
          radio_radius_km?: number
          updated_at?: string
        }
        Update: {
          a11y?: Json
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          display_name?: string
          geo_consent?: boolean
          headline?: string | null
          id?: string
          locale?: string
          radio_radius_km?: number
          updated_at?: string
        }
        Relationships: []
      }
      project_finance_links: {
        Row: {
          confidence: number
          confirmed: boolean
          created_at: string
          document_id: string | null
          event_id: string
          id: string
          owner_id: string
          payment_id: string | null
          quote_id: string | null
          relation: string
          updated_at: string
        }
        Insert: {
          confidence?: number
          confirmed?: boolean
          created_at?: string
          document_id?: string | null
          event_id: string
          id?: string
          owner_id: string
          payment_id?: string | null
          quote_id?: string | null
          relation?: string
          updated_at?: string
        }
        Update: {
          confidence?: number
          confirmed?: boolean
          created_at?: string
          document_id?: string | null
          event_id?: string
          id?: string
          owner_id?: string
          payment_id?: string | null
          quote_id?: string | null
          relation?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_finance_links_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "bureau_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_finance_links_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_finance_links_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "event_payments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_finance_links_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      project_roles: {
        Row: {
          created_at: string
          event_id: string
          id: string
          note: string | null
          participant_id: string | null
          role_slug: string
          subtype_slug: string | null
          updated_at: string
          user_id: string | null
          visibility: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          note?: string | null
          participant_id?: string | null
          role_slug: string
          subtype_slug?: string | null
          updated_at?: string
          user_id?: string | null
          visibility?: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          note?: string | null
          participant_id?: string | null
          role_slug?: string
          subtype_slug?: string | null
          updated_at?: string
          user_id?: string | null
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_roles_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_roles_participant_id_fkey"
            columns: ["participant_id"]
            isOneToOne: false
            referencedRelation: "event_participants"
            referencedColumns: ["id"]
          },
        ]
      }
      project_snapshots: {
        Row: {
          created_at: string
          event_id: string
          id: string
          owner_id: string
          payload: Json
          source_story: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          owner_id: string
          payload?: Json
          source_story?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          owner_id?: string
          payload?: Json
          source_story?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_snapshots_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: true
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      quote_items: {
        Row: {
          created_at: string
          id: string
          label: string
          position: number
          quantity: number
          quote_id: string
          unit_price: number
        }
        Insert: {
          created_at?: string
          id?: string
          label: string
          position?: number
          quantity?: number
          quote_id: string
          unit_price?: number
        }
        Update: {
          created_at?: string
          id?: string
          label?: string
          position?: number
          quantity?: number
          quote_id?: string
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "quote_items_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      quotes: {
        Row: {
          card_id: string
          created_at: string
          event_id: string | null
          id: string
          status: string
          target_date: string | null
          title: string
          total: number
          updated_at: string
          user_id: string
        }
        Insert: {
          card_id: string
          created_at?: string
          event_id?: string | null
          id?: string
          status?: string
          target_date?: string | null
          title?: string
          total?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          card_id?: string
          created_at?: string
          event_id?: string | null
          id?: string
          status?: string
          target_date?: string | null
          title?: string
          total?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "quotes_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          target_id: string
          target_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji?: string
          id?: string
          target_id: string
          target_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          target_id?: string
          target_type?: string
          user_id?: string
        }
        Relationships: []
      }
      referrals: {
        Row: {
          code: string
          created_at: string
          credited_at: string | null
          credits: number
          guest_id: string
          id: string
          sponsor_id: string
          status: string
        }
        Insert: {
          code: string
          created_at?: string
          credited_at?: string | null
          credits?: number
          guest_id: string
          id?: string
          sponsor_id: string
          status?: string
        }
        Update: {
          code?: string
          created_at?: string
          credited_at?: string | null
          credits?: number
          guest_id?: string
          id?: string
          sponsor_id?: string
          status?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          decision: string | null
          details: string | null
          id: string
          reason: string
          reporter_id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          target_id: string
          target_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          decision?: string | null
          details?: string | null
          id?: string
          reason: string
          reporter_id: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id: string
          target_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          decision?: string | null
          details?: string | null
          id?: string
          reason?: string
          reporter_id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          target_id?: string
          target_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          author_id: string | null
          author_name: string
          body: string
          card_id: string
          created_at: string
          id: string
          rating: number
        }
        Insert: {
          author_id?: string | null
          author_name?: string
          body?: string
          card_id: string
          created_at?: string
          id?: string
          rating?: number
        }
        Update: {
          author_id?: string | null
          author_name?: string
          body?: string
          card_id?: string
          created_at?: string
          id?: string
          rating?: number
        }
        Relationships: [
          {
            foreignKeyName: "reviews_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      service_rates: {
        Row: {
          card_id: string
          created_at: string
          day: string | null
          id: string
          label: string
          month: number | null
          note: string | null
          price: number
          unit: string
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          day?: string | null
          id?: string
          label?: string
          month?: number | null
          note?: string | null
          price?: number
          unit?: string
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          day?: string | null
          id?: string
          label?: string
          month?: number | null
          note?: string | null
          price?: number
          unit?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_rates_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      site_events: {
        Row: {
          anon_id: string | null
          created_at: string
          fix_note: string | null
          id: string
          kind: string
          label: string
          node: string | null
          payload: Json
          route: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          anon_id?: string | null
          created_at?: string
          fix_note?: string | null
          id?: string
          kind: string
          label: string
          node?: string | null
          payload?: Json
          route?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          anon_id?: string | null
          created_at?: string
          fix_note?: string | null
          id?: string
          kind?: string
          label?: string
          node?: string | null
          payload?: Json
          route?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      stories: {
        Row: {
          caption: string | null
          card_id: string | null
          city: string | null
          created_at: string
          expires_at: string
          id: string
          media_type: string
          media_url: string
          owner_id: string | null
          universe: string | null
        }
        Insert: {
          caption?: string | null
          card_id?: string | null
          city?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          media_type?: string
          media_url: string
          owner_id?: string | null
          universe?: string | null
        }
        Update: {
          caption?: string | null
          card_id?: string | null
          city?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          media_type?: string
          media_url?: string
          owner_id?: string | null
          universe?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "stories_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      story_views: {
        Row: {
          created_at: string
          id: string
          story_id: string
          viewer_key: string
        }
        Insert: {
          created_at?: string
          id?: string
          story_id: string
          viewer_key: string
        }
        Update: {
          created_at?: string
          id?: string
          story_id?: string
          viewer_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "story_views_story_id_fkey"
            columns: ["story_id"]
            isOneToOne: false
            referencedRelation: "stories"
            referencedColumns: ["id"]
          },
        ]
      }
      thread_members: {
        Row: {
          ai_delegate: boolean
          card_id: string | null
          created_at: string
          id: string
          role_label: string
          thread_id: string
          user_id: string
        }
        Insert: {
          ai_delegate?: boolean
          card_id?: string | null
          created_at?: string
          id?: string
          role_label?: string
          thread_id: string
          user_id: string
        }
        Update: {
          ai_delegate?: boolean
          card_id?: string | null
          created_at?: string
          id?: string
          role_label?: string
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_members_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_members_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      thread_settings: {
        Row: {
          ai_mode: string
          auto_translate: boolean
          created_at: string
          id: string
          my_lang: string | null
          thread_id: string
          tone: string
          translate_to: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_mode?: string
          auto_translate?: boolean
          created_at?: string
          id?: string
          my_lang?: string | null
          thread_id: string
          tone?: string
          translate_to?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_mode?: string
          auto_translate?: boolean
          created_at?: string
          id?: string
          my_lang?: string | null
          thread_id?: string
          tone?: string
          translate_to?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_settings_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      threads: {
        Row: {
          aime_id: string | null
          card_id: string | null
          created_at: string
          created_by: string | null
          event_id: string | null
          id: string
          kind: string
          last_message_at: string
          subject: string | null
          title: string | null
          updated_at: string
          user_a: string
          user_b: string | null
          visio_url: string | null
        }
        Insert: {
          aime_id?: string | null
          card_id?: string | null
          created_at?: string
          created_by?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          last_message_at?: string
          subject?: string | null
          title?: string | null
          updated_at?: string
          user_a: string
          user_b?: string | null
          visio_url?: string | null
        }
        Update: {
          aime_id?: string | null
          card_id?: string | null
          created_at?: string
          created_by?: string | null
          event_id?: string | null
          id?: string
          kind?: string
          last_message_at?: string
          subject?: string | null
          title?: string | null
          updated_at?: string
          user_a?: string
          user_b?: string | null
          visio_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "threads_aime_id_fkey"
            columns: ["aime_id"]
            isOneToOne: false
            referencedRelation: "aimes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "threads_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "threads_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      timeline_effects: {
        Row: {
          card_id: string
          confidence: string
          created_at: string
          direction: string
          document_id: string | null
          entry_id: string
          id: string
          nature: string
          note: string | null
          source: string
          unit: string | null
          updated_at: string
          value: number | null
        }
        Insert: {
          card_id: string
          confidence?: string
          created_at?: string
          direction?: string
          document_id?: string | null
          entry_id: string
          id?: string
          nature: string
          note?: string | null
          source?: string
          unit?: string | null
          updated_at?: string
          value?: number | null
        }
        Update: {
          card_id?: string
          confidence?: string
          created_at?: string
          direction?: string
          document_id?: string | null
          entry_id?: string
          id?: string
          nature?: string
          note?: string | null
          source?: string
          unit?: string | null
          updated_at?: string
          value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "timeline_effects_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timeline_effects_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "bureau_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timeline_effects_entry_id_fkey"
            columns: ["entry_id"]
            isOneToOne: false
            referencedRelation: "card_timeline_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      timeline_playlists: {
        Row: {
          card_id: string
          created_at: string
          description: string | null
          dynamic: boolean
          film: Json | null
          id: string
          item_ids: string[]
          layers: string[]
          mode: string
          name: string
          owner_id: string
          scope: Json
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          description?: string | null
          dynamic?: boolean
          film?: Json | null
          id?: string
          item_ids?: string[]
          layers?: string[]
          mode?: string
          name: string
          owner_id: string
          scope?: Json
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          description?: string | null
          dynamic?: boolean
          film?: Json | null
          id?: string
          item_ids?: string[]
          layers?: string[]
          mode?: string
          name?: string
          owner_id?: string
          scope?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "timeline_playlists_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      timeline_relations: {
        Row: {
          card_id: string
          created_at: string
          from_id: string
          from_kind: string
          id: string
          note: string | null
          relation: string
          to_id: string
          to_kind: string
          updated_at: string
        }
        Insert: {
          card_id: string
          created_at?: string
          from_id: string
          from_kind: string
          id?: string
          note?: string | null
          relation?: string
          to_id: string
          to_kind: string
          updated_at?: string
        }
        Update: {
          card_id?: string
          created_at?: string
          from_id?: string
          from_kind?: string
          id?: string
          note?: string | null
          relation?: string
          to_id?: string
          to_kind?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "timeline_relations_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
      universes: {
        Row: {
          emoji: string
          label: string
          slug: string
          sort_order: number
          tagline: string | null
        }
        Insert: {
          emoji?: string
          label: string
          slug: string
          sort_order?: number
          tagline?: string | null
        }
        Update: {
          emoji?: string
          label?: string
          slug?: string
          sort_order?: number
          tagline?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      web_memory_finds: {
        Row: {
          added_entry_id: string | null
          card_id: string
          confidence: string
          created_at: string
          created_by: string
          date_text: string | null
          duplicate_of: string | null
          id: string
          kind: string
          occurred_on: string | null
          people: string[]
          place: string | null
          query: string | null
          reason: string | null
          source_title: string | null
          source_type: string | null
          source_url: string
          status: string
          summary: string | null
          title: string
          updated_at: string
        }
        Insert: {
          added_entry_id?: string | null
          card_id: string
          confidence?: string
          created_at?: string
          created_by?: string
          date_text?: string | null
          duplicate_of?: string | null
          id?: string
          kind?: string
          occurred_on?: string | null
          people?: string[]
          place?: string | null
          query?: string | null
          reason?: string | null
          source_title?: string | null
          source_type?: string | null
          source_url: string
          status?: string
          summary?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          added_entry_id?: string | null
          card_id?: string
          confidence?: string
          created_at?: string
          created_by?: string
          date_text?: string | null
          duplicate_of?: string | null
          id?: string
          kind?: string
          occurred_on?: string | null
          people?: string[]
          place?: string | null
          query?: string | null
          reason?: string | null
          source_title?: string | null
          source_type?: string | null
          source_url?: string
          status?: string
          summary?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "web_memory_finds_added_entry_id_fkey"
            columns: ["added_entry_id"]
            isOneToOne: false
            referencedRelation: "card_timeline_entries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "web_memory_finds_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "web_memory_finds_duplicate_of_fkey"
            columns: ["duplicate_of"]
            isOneToOne: false
            referencedRelation: "card_timeline_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      work_licenses: {
        Row: {
          created_at: string
          event_id: string | null
          id: string
          license_type: string
          note: string | null
          owner_id: string
          proof_url: string | null
          radio_id: string | null
          scope: string
          status: string
          updated_at: string
          valid_from: string | null
          valid_to: string | null
          work_id: string
        }
        Insert: {
          created_at?: string
          event_id?: string | null
          id?: string
          license_type?: string
          note?: string | null
          owner_id: string
          proof_url?: string | null
          radio_id?: string | null
          scope?: string
          status?: string
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
          work_id: string
        }
        Update: {
          created_at?: string
          event_id?: string | null
          id?: string
          license_type?: string
          note?: string | null
          owner_id?: string
          proof_url?: string | null
          radio_id?: string | null
          scope?: string
          status?: string
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
          work_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_licenses_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_licenses_work_id_fkey"
            columns: ["work_id"]
            isOneToOne: false
            referencedRelation: "works"
            referencedColumns: ["id"]
          },
        ]
      }
      work_rights: {
        Row: {
          created_at: string
          holder_name: string
          id: string
          role: string
          share: number | null
          source: string | null
          work_id: string
        }
        Insert: {
          created_at?: string
          holder_name: string
          id?: string
          role: string
          share?: number | null
          source?: string | null
          work_id: string
        }
        Update: {
          created_at?: string
          holder_name?: string
          id?: string
          role?: string
          share?: number | null
          source?: string | null
          work_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_rights_work_id_fkey"
            columns: ["work_id"]
            isOneToOne: false
            referencedRelation: "works"
            referencedColumns: ["id"]
          },
        ]
      }
      works: {
        Row: {
          artist: string
          created_at: string
          created_by: string | null
          duration_sec: number | null
          id: string
          identified_via: string
          isrc: string | null
          iswc: string | null
          label: string | null
          source_platform: string | null
          source_url: string | null
          title: string
          updated_at: string
          verified: boolean
          year: number | null
        }
        Insert: {
          artist: string
          created_at?: string
          created_by?: string | null
          duration_sec?: number | null
          id?: string
          identified_via?: string
          isrc?: string | null
          iswc?: string | null
          label?: string | null
          source_platform?: string | null
          source_url?: string | null
          title: string
          updated_at?: string
          verified?: boolean
          year?: number | null
        }
        Update: {
          artist?: string
          created_at?: string
          created_by?: string | null
          duration_sec?: number | null
          id?: string
          identified_via?: string
          isrc?: string | null
          iswc?: string | null
          label?: string | null
          source_platform?: string | null
          source_url?: string | null
          title?: string
          updated_at?: string
          verified?: boolean
          year?: number | null
        }
        Relationships: []
      }
      world_cells: {
        Row: {
          card_id: string | null
          cell_index: number
          created_at: string
          id: string
          level: string
          place: string
          user_id: string
        }
        Insert: {
          card_id?: string | null
          cell_index: number
          created_at?: string
          id?: string
          level: string
          place: string
          user_id: string
        }
        Update: {
          card_id?: string | null
          cell_index?: number
          created_at?: string
          id?: string
          level?: string
          place?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "world_cells_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "cards"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_view_board: {
        Args: { p_board: string; p_user: string }
        Returns: boolean
      }
      can_view_event: {
        Args: { _event_id: string; _user_id: string }
        Returns: boolean
      }
      can_view_quote: {
        Args: { _quote_id: string; _user_id: string }
        Returns: boolean
      }
      has_contact_access: {
        Args: { _card_id: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_board_owner: {
        Args: { p_board: string; p_user: string }
        Returns: boolean
      }
      is_card_owner: {
        Args: { _card_id: string; _user_id: string }
        Returns: boolean
      }
      is_composition_member: {
        Args: { _composition_id: string; _user_id: string }
        Returns: boolean
      }
      is_event_owner: {
        Args: { _event_id: string; _user_id: string }
        Returns: boolean
      }
      is_thread_member: {
        Args: { _thread_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      aime_intent:
        | "aime"
        | "collaborer"
        | "reserver"
        | "recommander"
        | "associer"
        | "contacter"
        | "enregistrer"
      app_role: "admin" | "moderator" | "user"
      card_kind:
        | "personne"
        | "professionnel"
        | "entreprise"
        | "organisme"
        | "lieu"
        | "service"
        | "ressource"
        | "evenement"
      card_status:
        | "disponible"
        | "indisponible"
        | "nouveau"
        | "populaire"
        | "recommande"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      aime_intent: [
        "aime",
        "collaborer",
        "reserver",
        "recommander",
        "associer",
        "contacter",
        "enregistrer",
      ],
      app_role: ["admin", "moderator", "user"],
      card_kind: [
        "personne",
        "professionnel",
        "entreprise",
        "organisme",
        "lieu",
        "service",
        "ressource",
        "evenement",
      ],
      card_status: [
        "disponible",
        "indisponible",
        "nouveau",
        "populaire",
        "recommande",
      ],
    },
  },
} as const
