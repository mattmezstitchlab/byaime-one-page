import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Check, Download, ExternalLink, FileText, Send, Wand2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { documentUrl } from "@/lib/bureau/queries";
import { docParty, euros } from "@/lib/bureau/logic";
import { DOC_TYPE_LABEL, type BureauDocument, type BureauFolder, type DocType } from "@/lib/bureau/types";
import { DocumentRow } from "@/components/bureau/DocumentRow";
import { alertLabel, type DocAlert } from "@/lib/bureau/alerts";
import { cn } from "@/lib/utils";

/**
 * Une vignette de document : on le voit, on lit sa fiche, on agit
 * selon son type — sans jamais quitter l'arbre des dossiers.
 */
export function DocCard({
  doc,
  folders,
  alert,
  onSend,
  large = false,
}: {
  doc: BureauDocument;
  folders: BureauFolder[];
  alert?: DocAlert | null | undefined;
  /** Envoyer ce document dans une conversation. */
  onSend?: ((doc: BureauDocument) => void) | undefined;
  large?: boolean;
}) {
  const qc = useQueryClient();
  const [url, setUrl] = useState<string | null>(null);
  const [sheet, setSheet] = useState(large);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    void documentUrl(doc.storage_path, 60 * 60).then((u) => {
      if (alive) setUrl(u);
    });
    return () => {
      alive = false;
    };
  }, [doc.storage_path]);

  const mime = doc.mime_type ?? "";
  const isImage = mime.startsWith("image/");
  const isPdf = mime.includes("pdf");
  const type = (doc.doc_type as DocType) ?? "inconnu";

  const refresh = () => void qc.invalidateQueries({ queryKey: ["bureau-documents"] });

  async function patch(values: Partial<BureauDocument>, done: string) {
    setBusy(true);
    const { error } = await supabase.from("bureau_documents").update(values).eq("id", doc.id);

    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(done);
    refresh();
  }

  const day = doc.issued_on
    ? new Date(doc.issued_on).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })
    : null;

  return (
    <div className="overflow-hidden rounded-2xl border border-hairline bg-background">
      <button
        type="button"
        draggable
        onDragStart={(e) => e.dataTransfer.setData("text/aime-document", doc.id)}
        onClick={() => setSheet((v) => !v)}
        title={`Ouvrir la fiche de ${doc.file_name}`}
        className={cn(
          "block w-full bg-secondary text-left",
          large ? "h-[42vh]" : "h-28",
        )}
      >
        {url && isImage && (
          <img src={url} alt={doc.file_name} className="h-full w-full object-cover" />
        )}
        {url && isPdf && (
          <iframe
            src={`${url}#toolbar=0&view=FitH`}
            title={doc.file_name}
            tabIndex={-1}
            className="pointer-events-none h-full w-full"
          />
        )}
        {(!url || (!isImage && !isPdf)) && (
          <span className="flex h-full w-full items-center justify-center text-muted-foreground">
            <FileText className="h-6 w-6" strokeWidth={1.4} />
          </span>
        )}
      </button>

      <div className="space-y-1.5 px-3 py-2">
        <p className="truncate text-[13px] font-medium">{docParty(doc) ?? doc.file_name}</p>
        <p className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11.5px] text-muted-foreground">
          <span>{DOC_TYPE_LABEL[type]}</span>
          {day && <span>· {day}</span>}
          {doc.amount_ttc != null && <span>· {euros(doc.amount_ttc)}</span>}
        </p>
        {alert && (
          <p className={cn("text-[11.5px]", alert.level === "nouveau" ? "text-sky-600" : "text-amber-600")}>
            {alertLabel(alert)}
          </p>
        )}

        <div className="flex flex-wrap gap-1 pt-0.5">
          {type === "devis" && (
            <Action
              busy={busy}
              icon={Check}
              label="Accepter"
              onClick={() => void patch({ status: "accepte" }, "Devis accepté")}
            />
          )}
          {(type === "facture" || type === "acompte") && !doc.paid_on && (
            <Action
              busy={busy}
              icon={Check}
              label="Marquer payée"
              onClick={() =>
                void patch({ paid_on: new Date().toISOString().slice(0, 10) }, "Marquée payée")
              }
            />
          )}
          {type === "inconnu" && (
            <Action busy={busy} icon={Wand2} label="Compléter" onClick={() => setSheet(true)} />
          )}
          {onSend && <Action busy={busy} icon={Send} label="Envoyer" onClick={() => onSend(doc)} />}
          {url && (
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 rounded-full border border-hairline px-2.5 py-1 text-[11.5px] transition-colors hover:bg-muted"
            >
              <ExternalLink className="h-3 w-3" /> Ouvrir
            </a>
          )}
          {url && (
            <a
              href={url}
              download={doc.file_name}
              className="inline-flex items-center gap-1 rounded-full border border-hairline px-2.5 py-1 text-[11.5px] transition-colors hover:bg-muted"
            >
              <Download className="h-3 w-3" /> Télécharger
            </a>
          )}
        </div>
      </div>

      {sheet && (
        <div className="border-t border-hairline p-2">
          <DocumentRow doc={doc} folders={folders} defaultOpen />
        </div>
      )}
    </div>
  );
}

function Action({
  icon: Icon,
  label,
  onClick,
  busy,
}: {
  icon: typeof Check;
  label: string;
  onClick: () => void;
  busy: boolean;
}) {
  return (
    <button
      type="button"
      disabled={busy}
      onClick={onClick}
      className="inline-flex items-center gap-1 rounded-full border border-hairline px-2.5 py-1 text-[11.5px] transition-colors hover:bg-muted disabled:opacity-50"
    >
      <Icon className="h-3 w-3" /> {label}
    </button>
  );
}
