import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, FolderOpen } from "lucide-react";
import { AddDocument } from "@/components/bureau/AddDocument";
import { DocumentRow } from "@/components/bureau/DocumentRow";
import { useAuth } from "@/hooks/useAuth";
import { documentsQuery, foldersQuery } from "@/lib/bureau/queries";
import { bureauContextQuery, folderContext } from "@/lib/bureau/context";
import { docParty, euros, folderScore, folderState, folderTotals } from "@/lib/bureau/logic";
import { projectMoney } from "@/lib/bureau/project";
import { ProgressBar } from "@/components/aime/ProgressBar";
import { cn } from "@/lib/utils";

const FILTERS = [
  { key: "tous", label: "Tous" },
  { key: "a_verifier", label: "À vérifier" },
  { key: "facture", label: "Factures" },
  { key: "devis", label: "Devis" },
  { key: "justificatif", label: "Justificatifs" },
  { key: "recette", label: "Recettes" },
  { key: "depense", label: "Dépenses" },
] as const;

/**
 * Les documents, sans page parallèle : dépôt, dossiers et ce qui manque.
 * Sans `eventId` il montre tout le compte ; avec, uniquement le projet concerné.
 */
export function BureauPanel({ eventId, className }: { eventId?: string; className?: string }) {
  const { userId } = useAuth();
  const { data: allFolders = [] } = useQuery(foldersQuery(userId));
  const { data: allDocs = [] } = useQuery(documentsQuery(userId));
  const { data: ctx } = useQuery(bureauContextQuery(userId));

  const [folderId, setFolderId] = useState<string | null | "tous">("tous");
  const [filter, setFilter] = useState<string>("tous");
  const [tab, setTab] = useState<"documents" | "todo">("documents");

  const folders = useMemo(
    () => (eventId ? allFolders.filter((f) => f.event_id === eventId) : allFolders),
    [allFolders, eventId],
  );

  const docs = useMemo(() => {
    if (!eventId) return allDocs;
    const ids = new Set(folders.map((f) => f.id));
    return allDocs.filter((d) => d.folder_id && ids.has(d.folder_id));
  }, [allDocs, folders, eventId]);

  const totals = useMemo(() => folderTotals(docs), [docs]);

  const money = useMemo(() => {
    if (!eventId || !ctx) return null;
    return projectMoney(
      folders,
      allDocs,
      ctx.quotes.filter((q) => q.event_id === eventId),
      ctx.payments.filter((p) => p.event_id === eventId),
    );
  }, [eventId, ctx, folders, allDocs]);

  const scoped = useMemo(
    () =>
      folderId === "tous" ? docs : docs.filter((d) => (d.folder_id ?? null) === (folderId ?? null)),
    [docs, folderId],
  );

  const filtered = scoped.filter((d) => {
    if (filter === "tous") return true;
    if (filter === "a_verifier") return d.status !== "valide";
    if (filter === "recette" || filter === "depense") return d.direction === filter;
    return d.doc_type === filter;
  });

  const todos = useMemo(() => {
    const rows: { id: string; doc: (typeof docs)[number]; label: string }[] = [];
    for (const d of docs) {
      if (d.amount_ttc == null) rows.push({ id: `${d.id}-ttc`, doc: d, label: "Montant manquant" });
      if (!d.issued_on) rows.push({ id: `${d.id}-date`, doc: d, label: "Date manquante" });
      if (d.doc_type === "inconnu")
        rows.push({ id: `${d.id}-type`, doc: d, label: "Type à préciser" });
      if (d.status !== "valide") rows.push({ id: `${d.id}-ok`, doc: d, label: "À confirmer" });
      if (!d.folder_id) rows.push({ id: `${d.id}-folder`, doc: d, label: "À ranger" });
    }
    return rows;
  }, [docs]);

  const orphans = eventId ? 0 : allDocs.filter((d) => !d.folder_id).length;

  if (!userId) {
    return (
      <div className={cn("rounded-3xl hairline bg-card p-6 text-[13.5px]", className)}>
        <p className="text-muted-foreground">
          Connectez-vous pour retrouver vos devis, factures et justificatifs.
        </p>
        <Link to="/auth" className="mt-4 inline-block underline underline-offset-4">
          Se connecter
        </Link>
      </div>
    );
  }

  const stats = money
    ? [
        ["Prévu", euros(money.planned)],
        ["Facturé", euros(money.invoiced)],
        ["Payé", euros(money.paid)],
        ["Reste", euros(money.remaining)],
      ]
    : [
        ["Recettes", euros(totals.recettesTtc)],
        ["Dépenses", euros(totals.depensesTtc)],
        ["Solde", euros(totals.solde)],
        ["À vérifier", String(docs.filter((d) => d.status !== "valide").length)],
      ];

  return (
    <div className={cn("rounded-3xl hairline bg-card p-5 shadow-soft sm:p-6", className)}>
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Documents</p>
          <h2 className="mt-1 text-[20px] font-semibold leading-tight">
            {eventId ? "Devis, factures et paiements du projet" : "Vos documents et vos dossiers"}
          </h2>
          <p className="mt-1 max-w-lg text-[13.5px] text-muted-foreground">
            Déposez un document : je le lis, je le classe et je vous dis ce qui manque.
          </p>
        </div>
        <AddDocument userId={userId} folders={allFolders} />
      </header>

      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map(([label, value]) => (
          <div key={label} className="rounded-2xl hairline p-4">
            <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
            <p className="mt-2 text-[18px] tabular-nums tracking-[-0.02em]">{value}</p>
          </div>
        ))}
      </div>

      {/* Dossiers : on choisit, la liste en dessous suit. */}
      <section className="mt-7">
        <h3 className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Dossiers</h3>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setFolderId("tous")}
            className={cn(
              "rounded-full px-3.5 py-1.5 text-[12px]",
              folderId === "tous" ? "bg-foreground text-background" : "hairline text-muted-foreground",
            )}
          >
            Tout · {docs.length}
          </button>
          {orphans > 0 && (
            <button
              type="button"
              onClick={() => setFolderId(null)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-[12px]",
                folderId === null ? "bg-foreground text-background" : "hairline text-muted-foreground",
              )}
            >
              Non classés · {orphans}
            </button>
          )}
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {folders.map((f) => {
            const fdocs = docs.filter((d) => d.folder_id === f.id);
            const summary = ctx ? folderContext(f, fdocs, ctx) : null;
            const score = folderScore(f, fdocs, summary);
            const state = folderState(score, fdocs);
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFolderId(f.id)}
                className={cn(
                  "rounded-2xl p-4 text-left transition-colors",
                  folderId === f.id ? "hairline bg-muted" : "hairline hover:border-foreground/25",
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[14.5px] tracking-[-0.02em]">{f.title}</p>
                    <p className="mt-1 text-[12px] text-muted-foreground">
                      {fdocs.length} document{fdocs.length > 1 ? "s" : ""}
                      {f.counterpart ? ` · ${f.counterpart}` : ""}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "shrink-0 rounded-full px-2.5 py-1 text-[11px]",
                      state === "pret"
                        ? "bg-emerald-500/10 text-emerald-600"
                        : state === "a_verifier"
                          ? "bg-amber-500/10 text-amber-600"
                          : "bg-neutral-500/10 text-muted-foreground",
                    )}
                  >
                    {score}%
                  </span>
                </div>
                <ProgressBar value={score} className="mt-3" />
              </button>
            );
          })}
          {folders.length === 0 && (
            <p className="text-[13px] text-muted-foreground">
              Aucun dossier pour l&apos;instant : le premier document en crée un.
            </p>
          )}
        </div>
      </section>

      <section className="mt-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {(
              [
                ["documents", "Documents"],
                ["todo", `À faire${todos.length ? ` · ${todos.length}` : ""}`],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-[12px] uppercase tracking-[0.12em]",
                  tab === key ? "bg-foreground text-background" : "hairline text-muted-foreground",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {tab === "documents" ? (
          <>
            <div className="mt-3 flex flex-wrap gap-2">
              {FILTERS.map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setFilter(f.key)}
                  className={cn(
                    "rounded-full px-3.5 py-1.5 text-[12px] transition-colors",
                    filter === f.key
                      ? "bg-foreground text-background"
                      : "hairline text-muted-foreground hover:text-foreground",
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="mt-3 space-y-2">
              {filtered.map((d) => (
                <DocumentRow key={d.id} doc={d} folders={allFolders} />
              ))}
              {filtered.length === 0 && (
                <p className="flex items-center gap-2 text-[13px] text-muted-foreground">
                  <FolderOpen className="h-4 w-4" /> Rien ici pour l&apos;instant.
                </p>
              )}
            </div>
          </>
        ) : (
          <div className="mt-4 space-y-2">
            {todos.map((row) => (
              <details key={row.id} className="rounded-2xl hairline px-4 py-3 text-[13px]">
                <summary className="flex cursor-pointer list-none items-center gap-2">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
                  <span className="min-w-0 flex-1 truncate">
                    {row.label} —{" "}
                    <span className="text-muted-foreground">
                      {docParty(row.doc) ?? row.doc.file_name}
                    </span>
                  </span>
                </summary>
                <div className="mt-3">
                  <DocumentRow doc={row.doc} folders={allFolders} />
                </div>
              </details>
            ))}
            {todos.length === 0 && (
              <p className="text-[13px] text-muted-foreground">Rien à compléter, tout est clair.</p>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
