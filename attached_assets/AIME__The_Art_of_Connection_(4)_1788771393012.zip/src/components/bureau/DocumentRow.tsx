import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AlertTriangle, Check, ChevronDown, ExternalLink, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { documentUrl } from "@/lib/bureau/queries";
import { docParty, euros } from "@/lib/bureau/logic";
import {
  DIRECTION_LABEL,
  DOC_TYPES,
  DOC_TYPE_LABEL,
  type BureauDocument,
  type BureauFolder,
  type DocType,
} from "@/lib/bureau/types";
import { cn } from "@/lib/utils";

const field =
  "w-full rounded-xl border border-hairline bg-background px-3 py-2 text-[13px] outline-none focus:border-foreground/30";

export function DocumentRow({
  doc,
  folders,
  draggable = false,
  defaultOpen = false,
}: {
  doc: BureauDocument;
  folders: BureauFolder[];
  draggable?: boolean;
  defaultOpen?: boolean;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(defaultOpen);
  const [draft, setDraft] = useState(doc);
  const [saving, setSaving] = useState(false);
  const uncertain = doc.uncertain_fields ?? [];

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
    void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
  };

  async function save(extra?: Partial<BureauDocument>) {
    setSaving(true);
    const patch = {
      folder_id: draft.folder_id,
      doc_type: draft.doc_type,
      direction: draft.direction,
      counterpart: draft.counterpart,
      issuer: draft.issuer,
      doc_number: draft.doc_number,
      issued_on: draft.issued_on || null,
      paid_on: draft.paid_on || null,
      amount_ht: draft.amount_ht,
      amount_vat: draft.amount_vat,
      amount_ttc: draft.amount_ttc,
      purpose: draft.purpose,
      ...extra,
    };
    const { error } = await supabase.from("bureau_documents").update(patch).eq("id", doc.id);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Document mis à jour");
    refresh();
  }

  async function remove() {
    const { error } = await supabase.from("bureau_documents").delete().eq("id", doc.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await supabase.storage.from("bureau").remove([doc.storage_path]);
    refresh();
  }

  async function openFile() {
    const url = await documentUrl(doc.storage_path);
    if (url) window.open(url, "_blank", "noopener");
    else toast.error("Fichier introuvable");
  }

  const money = (cents: number | null) => (cents == null ? "" : (cents / 100).toFixed(2));
  const toCents = (v: string) =>
    v.trim() === "" ? null : Math.round(Number(v.replace(",", ".")) * 100);

  return (
    <div
      className="rounded-2xl border border-hairline bg-background"
      draggable={draggable}
      onDragStart={
        draggable
          ? (e) => {
              e.dataTransfer.setData("text/aime-document", doc.id);
              e.dataTransfer.effectAllowed = "move";
            }
          : undefined
      }
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-3 px-4 py-3 text-left"
      >
        <span
          className={cn(
            "grid h-8 w-8 shrink-0 place-items-center rounded-full text-[11px] font-medium",
            doc.status === "valide"
              ? "bg-emerald-500/10 text-emerald-600"
              : "bg-amber-500/10 text-amber-600",
          )}
        >
          {doc.status === "valide" ? (
            <Check className="h-4 w-4" />
          ) : (
            <AlertTriangle className="h-4 w-4" />
          )}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[14px]">
            {DOC_TYPE_LABEL[(doc.doc_type as DocType) ?? "inconnu"]}
            {docParty(doc) ? ` · ${docParty(doc)}` : ""}
          </span>
          <span className="block truncate text-[12px] text-muted-foreground">
            {doc.issued_on ?? "date à préciser"} · {DIRECTION_LABEL[doc.direction] ?? doc.direction}{" "}
            · {doc.file_name}
          </span>
        </span>
        <span className="shrink-0 text-[14px] tabular-nums">
          {doc.amount_ttc != null ? euros(doc.amount_ttc) : "—"}
        </span>
        <ChevronDown
          className={cn("h-4 w-4 shrink-0 transition-transform", open && "rotate-180")}
        />
      </button>

      {open && (
        <div className="space-y-3 border-t border-hairline px-4 py-4">
          {uncertain.length > 0 && doc.status !== "valide" && (
            <p className="rounded-xl bg-amber-500/10 px-3 py-2 text-[12px] text-amber-700">
              À confirmer : {uncertain.join(", ")}. Je préfère te le dire plutôt que d'inventer.
            </p>
          )}
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Type
              <select
                className={field}
                value={draft.doc_type}
                onChange={(e) => setDraft({ ...draft, doc_type: e.target.value })}
              >
                {DOC_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {DOC_TYPE_LABEL[t]}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Sens
              <select
                className={field}
                value={draft.direction}
                onChange={(e) => setDraft({ ...draft, direction: e.target.value })}
              >
                {Object.entries(DIRECTION_LABEL).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Tiers
              <input
                className={field}
                value={draft.counterpart ?? ""}
                onChange={(e) => setDraft({ ...draft, counterpart: e.target.value })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Numéro
              <input
                className={field}
                value={draft.doc_number ?? ""}
                onChange={(e) => setDraft({ ...draft, doc_number: e.target.value })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Date d'émission
              <input
                type="date"
                className={field}
                value={draft.issued_on ?? ""}
                onChange={(e) => setDraft({ ...draft, issued_on: e.target.value })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Date de paiement
              <input
                type="date"
                className={field}
                value={draft.paid_on ?? ""}
                onChange={(e) => setDraft({ ...draft, paid_on: e.target.value })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Montant HT (€)
              <input
                className={field}
                inputMode="decimal"
                value={money(draft.amount_ht)}
                onChange={(e) => setDraft({ ...draft, amount_ht: toCents(e.target.value) })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              TVA (€)
              <input
                className={field}
                inputMode="decimal"
                value={money(draft.amount_vat)}
                onChange={(e) => setDraft({ ...draft, amount_vat: toCents(e.target.value) })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Montant TTC (€)
              <input
                className={field}
                inputMode="decimal"
                value={money(draft.amount_ttc)}
                onChange={(e) => setDraft({ ...draft, amount_ttc: toCents(e.target.value) })}
              />
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground">
              Dossier
              <select
                className={field}
                value={draft.folder_id ?? ""}
                onChange={(e) => setDraft({ ...draft, folder_id: e.target.value || null })}
              >
                <option value="">Sans dossier</option>
                {folders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.title}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1 text-[12px] text-muted-foreground sm:col-span-2">
              Libellé
              <input
                className={field}
                value={draft.purpose ?? ""}
                onChange={(e) => setDraft({ ...draft, purpose: e.target.value })}
              />
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              disabled={saving}
              onClick={() => void save()}
              className="rounded-full border border-hairline px-4 py-2 text-[12px]"
            >
              Enregistrer
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void save({ status: "valide", uncertain_fields: [] })}
              className="rounded-full bg-neutral-950 px-4 py-2 text-[12px] text-white"
            >
              Confirmer comme exact
            </button>
            <button
              type="button"
              onClick={() => void openFile()}
              className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-4 py-2 text-[12px]"
            >
              <ExternalLink className="h-3.5 w-3.5" /> Ouvrir
            </button>
            <button
              type="button"
              onClick={() => void remove()}
              className="ml-auto inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-[12px] text-muted-foreground hover:text-rose-600"
            >
              <Trash2 className="h-3.5 w-3.5" /> Supprimer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
