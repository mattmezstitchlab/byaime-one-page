import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { FileUp, Loader2, Plus } from "lucide-react";
import { bureauContextQuery } from "@/lib/bureau/context";
import { INGEST_STEPS, ingestFile } from "@/lib/bureau/ingest";
import type { BureauFolder } from "@/lib/bureau/types";
import { cn } from "@/lib/utils";

export function AddDocument({
  userId,
  folders,
  folderId,
  className,
  openOnMount = false,
}: {
  userId: string;
  folders: BureauFolder[];
  folderId?: string | null;
  className?: string;
  /** Arrivée depuis le menu « + » : le sélecteur de fichier s'ouvre seul. */
  openOnMount?: boolean;
}) {
  const qc = useQueryClient();
  const input = useRef<HTMLInputElement>(null);
  const opened = useRef(false);

  useEffect(() => {
    if (!openOnMount || opened.current) return;
    opened.current = true;
    input.current?.click();
  }, [openOnMount]);
  const [step, setStep] = useState<number | null>(null);
  const { data: ctx } = useQuery(bureauContextQuery(userId));

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    for (const file of Array.from(files)) {
      try {
        const res = await ingestFile({
          file,
          userId,
          folders,
          folderId: folderId ?? null,
          ctx: ctx ?? null,
          onStep: setStep,
          onSoftError: (message) =>
            toast.message("Document déposé sans lecture automatique", { description: message }),
        });
        toast.success(res.read ? `${file.name} lu et classé` : `${file.name} déposé, à compléter`);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Dépôt impossible");
      }
    }
    setStep(null);
    if (input.current) input.current.value = "";
    void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
    void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
    void qc.invalidateQueries({ queryKey: ["bureau-context"] });
  }

  return (
    <div className={cn("inline-flex flex-col items-start gap-2", className)}>
      <input
        ref={input}
        type="file"
        multiple
        accept="image/*,application/pdf"
        className="hidden"
        onChange={(e) => void handleFiles(e.target.files)}
      />
      <button
        type="button"
        disabled={step !== null}
        onClick={() => input.current?.click()}
        className="inline-flex items-center gap-2 rounded-full bg-neutral-950 px-5 py-2.5 text-[13px] font-medium uppercase tracking-[0.08em] text-white transition-opacity hover:opacity-90 disabled:opacity-60"
      >
        {step !== null ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Plus className="h-4 w-4" strokeWidth={2} />
        )}
        Ajouter
      </button>
      {step !== null && (
        <p className="inline-flex items-center gap-2 text-[12px] text-muted-foreground">
          <FileUp className="h-3.5 w-3.5" /> {INGEST_STEPS[step]}…
        </p>
      )}
    </div>
  );
}
