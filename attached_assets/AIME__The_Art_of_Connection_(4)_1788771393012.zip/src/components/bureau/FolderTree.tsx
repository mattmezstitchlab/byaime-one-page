import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Check,
  ChevronRight,
  ExternalLink,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  MessageCircle,
  Pencil,
  Trash2,
  X,
} from "lucide-react";
import type { BureauDocument, BureauFolder } from "@/lib/bureau/types";
import { DOC_TYPE_LABEL, type DocType } from "@/lib/bureau/types";
import {
  createFolder,
  deleteFolder,
  descendantFolderIds,
  documentUrl,
  moveDocumentToFolder,
  renameFolder,
} from "@/lib/bureau/queries";
import { docParty } from "@/lib/bureau/logic";
import { alertLabel, folderAlertCount, type DocAlert } from "@/lib/bureau/alerts";
import { DocCard } from "@/components/bureau/DocCard";
import { cn } from "@/lib/utils";


/** Le petit repère qui pulse : ce qui manque en orange, ce qui vient d'arriver en bleu. */
function AlertDot({ alert, count }: { alert?: DocAlert | null | undefined; count?: number | undefined }) {
  if (!alert && !count) return null;
  const nouveau = alert?.level === "nouveau";
  return (
    <span
      title={alert ? alertLabel(alert) : `${count} document(s) demandent votre attention`}
      className={cn(
        "inline-flex shrink-0 items-center gap-1 rounded-full px-1 text-[10px] font-medium tabular-nums",
        nouveau ? "text-sky-600" : "text-amber-600",
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 animate-pulse rounded-full",
          nouveau ? "bg-sky-500" : "bg-amber-500",
        )}
      />
      {count ? count : null}
    </span>
  );
}

const OPEN_KEY = "aime.bureau.tree.open";

function readOpen(): Record<string, boolean> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(OPEN_KEY) ?? "{}") as Record<string, boolean>;
  } catch {
    return {};
  }
}

export function FolderTree({
  folders,
  docs,
  userId,
  onOpenDoc,
  onOpenThread,
  alerts,
  activeDocId,
  focusFolderId,
}: {
  folders: BureauFolder[];
  docs: BureauDocument[];
  userId: string | null;
  /** Ouvrir le document sur place plutôt que dans un nouvel onglet. */
  onOpenDoc?: (doc: BureauDocument) => void;
  /** Basculer sur la conversation liée au dossier. */
  onOpenThread?: (threadId: string) => void;
  alerts?: Map<string, DocAlert>;
  activeDocId?: string | null;
  /** Dossier à déplier et amener à l'écran (le projet dont on vient). */
  focusFolderId?: string | null;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState<Record<string, boolean>>(readOpen);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [creatingIn, setCreatingIn] = useState<string | null | undefined>(undefined);
  const [newTitle, setNewTitle] = useState("");
  const [dropTarget, setDropTarget] = useState<string | null>(null);

  const focusRef = useRef<HTMLLIElement | null>(null);

  // On arrive depuis un projet : son dossier s'ouvre et se montre.
  useEffect(() => {
    if (!focusFolderId) return;
    setOpen((o) => ({ ...o, [focusFolderId]: true }));
    const t = window.setTimeout(
      () => focusRef.current?.scrollIntoView({ block: "start", behavior: "smooth" }),
      120,
    );
    return () => window.clearTimeout(t);
  }, [focusFolderId]);

  const orphans = docs.filter((d) => !d.folder_id);
  const roots = folders.filter((f) => !f.parent_id);

  function toggle(id: string) {
    setOpen((o) => {
      const next = { ...o, [id]: !(o[id] ?? false) };
      try {
        window.localStorage.setItem(OPEN_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
    void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
  };

  async function submitNew(parentId: string | null) {
    if (!userId || newTitle.trim().length < 2) {
      setCreatingIn(undefined);
      setNewTitle("");
      return;
    }
    try {
      await createFolder(userId, newTitle, parentId);
      if (parentId) setOpen((o) => ({ ...o, [parentId]: true }));
      setNewTitle("");
      setCreatingIn(undefined);
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Création impossible");
    }
  }

  async function submitRename(id: string) {
    if (draft.trim().length < 2) {
      setRenaming(null);
      return;
    }
    try {
      await renameFolder(id, draft);
      setRenaming(null);
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Renommage impossible");
    }
  }

  async function remove(f: BureauFolder) {
    const kids = descendantFolderIds(folders, f.id);
    const inside = docs.filter(
      (d) => d.folder_id === f.id || kids.includes(d.folder_id ?? ""),
    ).length;
    const ok = window.confirm(
      `Supprimer « ${f.title} »${kids.length ? ` et ses ${kids.length} sous-dossier(s)` : ""} ?\n` +
        (inside
          ? `${inside} document(s) ne sont pas effacés : ils repassent en « Non classés ».`
          : "Ce dossier ne contient aucun document."),
    );
    if (!ok) return;
    try {
      await deleteFolder(f.id, kids);
      toast.success("Dossier supprimé, documents conservés");
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Suppression impossible");
    }
  }

  async function openDoc(d: BureauDocument) {
    if (onOpenDoc) {
      onOpenDoc(d);
      return;
    }
    try {
      const url = await documentUrl(d.storage_path);
      if (!url) throw new Error("Fichier introuvable");
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ouverture impossible");
    }
  }

  async function drop(folderId: string | null, e: React.DragEvent) {
    e.preventDefault();
    setDropTarget(null);
    const docId = e.dataTransfer.getData("text/aime-document");
    if (!docId) return;
    try {
      await moveDocumentToFolder(docId, folderId);
      toast.success("Document rangé");
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Rangement impossible");
    }
  }

  function renderFolder(f: BureauFolder, depth: number) {
    const children = folders.filter((c) => c.parent_id === f.id);
    const fdocs = docs.filter((d) => d.folder_id === f.id);
    const isOpen = open[f.id] ?? false;
    const count = fdocs.length + children.length;
    const pending = alerts ? folderAlertCount(f.id, folders, docs, alerts) : 0;

    return (
      <li key={f.id} ref={f.id === focusFolderId ? focusRef : undefined}>
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDropTarget(f.id);
          }}
          onDragLeave={() => setDropTarget((t) => (t === f.id ? null : t))}
          onDrop={(e) => void drop(f.id, e)}
          className={cn(
            "group flex items-center gap-1 rounded-lg pr-1",
            dropTarget === f.id && "bg-foreground/5 ring-1 ring-foreground/20",
          )}
        >
          <button
            type="button"
            onClick={() => toggle(f.id)}
            aria-label={isOpen ? "Replier" : "Déplier"}
            aria-expanded={isOpen}
            className="grid h-6 w-6 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-muted"
          >
            <ChevronRight
              className={cn("h-3.5 w-3.5 transition-transform", isOpen && "rotate-90")}
            />
          </button>

          {renaming === f.id ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void submitRename(f.id);
              }}
              className="flex min-w-0 flex-1 items-center gap-1 py-1"
            >
              <input
                autoFocus
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onBlur={() => void submitRename(f.id)}
                className="min-w-0 flex-1 rounded-md border border-hairline bg-background px-2 py-1 text-[13px] outline-none focus:border-foreground/30"
              />
              <button type="submit" aria-label="Valider" className="text-muted-foreground">
                <Check className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                aria-label="Annuler"
                onClick={() => setRenaming(null)}
                className="text-muted-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </form>
          ) : (
            <>
              <button
                type="button"
                onClick={() => toggle(f.id)}
                onDoubleClick={(e) => {
                  e.preventDefault();
                  setDraft(f.title);
                  setRenaming(f.id);
                }}
                className="flex min-w-0 flex-1 items-center gap-2 rounded-lg px-1.5 py-1.5 text-left transition-colors hover:bg-muted"
              >
                {isOpen ? (
                  <FolderOpen
                    className="h-4 w-4 shrink-0 text-muted-foreground"
                    strokeWidth={1.6}
                  />
                ) : (
                  <Folder className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.6} />
                )}
                <span className="truncate">{f.title}</span>
                <AlertDot count={pending || undefined} />
                <span className="ml-auto shrink-0 text-[11px] tabular-nums text-muted-foreground">
                  {count}
                </span>
              </button>
              <span className="flex shrink-0 items-center opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
                <button
                  type="button"
                  aria-label="Nouveau sous-dossier"
                  title="Nouveau sous-dossier"
                  onClick={() => {
                    setCreatingIn(f.id);
                    setNewTitle("");
                    setOpen((o) => ({ ...o, [f.id]: true }));
                  }}
                  className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground hover:bg-muted"
                >
                  <FolderPlus className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Renommer"
                  title="Renommer"
                  onClick={() => {
                    setDraft(f.title);
                    setRenaming(f.id);
                  }}
                  className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground hover:bg-muted"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Supprimer"
                  title="Supprimer"
                  onClick={() => void remove(f)}
                  className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-rose-600"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </span>
            </>
          )}
        </div>

        {isOpen && (
          <ul className="ml-[19px] space-y-0.5 border-l border-hairline pl-2">
            {(f.event_id || f.thread_id) && (
              <li className="flex flex-wrap gap-1.5 py-1">
                {f.event_id && (
                  <Link
                    to="/projets/$id"
                    params={{ id: f.event_id }}
                    className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-2.5 py-1 text-[12px] transition-colors hover:bg-muted"
                  >
                    <ExternalLink className="h-3 w-3" /> Ouvrir le projet
                  </Link>
                )}
                {f.thread_id && onOpenThread && (
                  <button
                    type="button"
                    onClick={() => onOpenThread(f.thread_id!)}
                    className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-2.5 py-1 text-[12px] transition-colors hover:bg-muted"
                  >
                    <MessageCircle className="h-3 w-3" /> Ouvrir la discussion
                  </button>
                )}
              </li>
            )}

            {children.map((c) => renderFolder(c, depth + 1))}


            {creatingIn === f.id && (
              <li>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void submitNew(f.id);
                  }}
                  className="py-1"
                >
                  <input
                    autoFocus
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    onBlur={() => void submitNew(f.id)}
                    placeholder="Nom du sous-dossier"
                    className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-[13px] outline-none focus:border-foreground/30"
                  />
                </form>
              </li>
            )}

            {fdocs.length > 0 && (
              <li className="grid grid-cols-1 gap-2 py-1 md:grid-cols-2">
                {fdocs.map((d) => (
                  <DocCard
                    key={d.id}
                    doc={d}
                    folders={folders}
                    alert={alerts?.get(d.id)}
                    onSend={onOpenDoc ? () => onOpenDoc(d) : undefined}
                  />
                ))}
              </li>
            )}


            {children.length === 0 && fdocs.length === 0 && creatingIn !== f.id && (
              <li className="px-2 py-1.5 text-[12px] text-muted-foreground">Dossier vide</li>
            )}
          </ul>
        )}
      </li>
    );
  }

  return (
    <div className="text-[13px]">
      <div className="flex items-center gap-1 px-2 pb-2">
        <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
          Arborescence
        </p>
        <button
          type="button"
          aria-label="Nouveau dossier"
          title="Nouveau dossier"
          onClick={() => {
            setCreatingIn(null);
            setNewTitle("");
          }}
          className="ml-auto grid h-6 w-6 place-items-center rounded-md text-muted-foreground hover:bg-muted"
        >
          <FolderPlus className="h-3.5 w-3.5" />
        </button>
      </div>

      {creatingIn === null && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submitNew(null);
          }}
          className="px-1 pb-2"
        >
          <input
            autoFocus
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            onBlur={() => void submitNew(null)}
            placeholder="Nom du dossier"
            className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-[13px] outline-none focus:border-foreground/30"
          />
        </form>
      )}

      <ul className="space-y-0.5">{roots.map((f) => renderFolder(f, 0))}</ul>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDropTarget("__none__");
        }}
        onDragLeave={() => setDropTarget((t) => (t === "__none__" ? null : t))}
        onDrop={(e) => void drop(null, e)}
        className={cn(
          "mt-4 rounded-lg py-1",
          dropTarget === "__none__" && "bg-foreground/5 ring-1 ring-foreground/20",
        )}
      >
        <p className="px-2 pb-1 text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
          Non classés · {orphans.length}
        </p>
        <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
          {orphans.slice(0, 12).map((d) => (
            <li key={d.id}>
              <DocCard
                doc={d}
                folders={folders}
                alert={alerts?.get(d.id)}
                onSend={onOpenDoc ? () => onOpenDoc(d) : undefined}
              />
            </li>
          ))}
          {orphans.length === 0 && (
            <li className="px-2 py-1.5 text-[12px] text-muted-foreground">
              Glisse un document ici pour le sortir d'un dossier.
            </li>
          )}
        </ul>

      </div>

      {folders.length === 0 && (
        <p className="mt-4 px-2 text-[12px] text-muted-foreground">
          Aucun dossier. Crée-en un avec le « + » : l'arbre se déploie ensuite tout seul.
        </p>
      )}
    </div>
  );
}
