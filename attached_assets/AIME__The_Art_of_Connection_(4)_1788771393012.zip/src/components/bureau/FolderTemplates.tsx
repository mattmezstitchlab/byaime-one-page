import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { FolderPlus } from "lucide-react";
import { applyTemplate, templatesFor } from "@/lib/bureau/templates";

/**
 * Ouvrir un dossier vivant déjà structuré, selon le rôle et le métier.
 * On ne devine pas les pièces : on ouvre les bonnes cases, l'humain les remplit.
 */
export default function FolderTemplates({
  ownerId,
  universeSlug,
  eventId,
  cardId,
  defaultTitle,
}: {
  ownerId: string | null;
  universeSlug?: string | null | undefined;
  eventId?: string | null | undefined;
  cardId?: string | null | undefined;
  defaultTitle?: string | undefined;
}) {
  const qc = useQueryClient();
  const templates = useMemo(() => templatesFor(universeSlug), [universeSlug]);
  const [busy, setBusy] = useState<string | null>(null);

  if (!ownerId) return null;

  async function create(slug: string) {
    const tpl = templates.find((t) => t.slug === slug);
    if (!tpl || !ownerId) return;
    setBusy(slug);
    try {
      await applyTemplate({
        ownerId,
        template: tpl,
        title: defaultTitle ? `${defaultTitle} · ${tpl.label}` : tpl.label,
        eventId: eventId ?? null,
        cardId: cardId ?? null,
      });
      void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
      toast.success("Dossier ouvert avec ses sous-dossiers");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Création impossible");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
      <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        <FolderPlus className="h-4 w-4" strokeWidth={1.75} /> Modèles de dossiers
      </p>
      <ul className="mt-4 space-y-4">
        {templates.map((t) => (
          <li key={t.slug} className="border-t border-hairline pt-4 first:border-0 first:pt-0">
            <p className="text-[14px] font-medium">{t.label}</p>
            <p className="mt-0.5 text-[13px] leading-relaxed text-muted-foreground">{t.hint}</p>
            <p className="mt-1 text-[12px] text-muted-foreground">
              {t.children.map((c) => c.title).join(" · ")}
            </p>
            <button
              type="button"
              onClick={() => void create(t.slug)}
              disabled={busy === t.slug}
              className="mt-2 rounded-full hairline bg-background px-3.5 py-1.5 text-[12px] disabled:opacity-50"
            >
              {busy === t.slug ? "Ouverture…" : "Ouvrir ce dossier"}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
