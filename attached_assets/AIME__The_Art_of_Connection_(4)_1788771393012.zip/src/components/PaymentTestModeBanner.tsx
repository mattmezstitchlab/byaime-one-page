const clientToken = import.meta.env["VITE_PAYMENTS_CLIENT_TOKEN"] as string | undefined;

export function PaymentTestModeBanner() {
  if (!clientToken) {
    return (
      <div className="w-full rounded-2xl bg-destructive/10 px-4 py-2 text-center text-[13px] text-destructive">
        Le paiement par carte n'est pas encore actif sur cette version publiée.
      </div>
    );
  }
  if (clientToken.startsWith("pk_test_")) {
    return (
      <div className="w-full rounded-2xl bg-amber-500/10 px-4 py-2 text-center text-[13px] text-amber-700">
        Mode test : aucun paiement réel n'est encaissé dans l'aperçu.
      </div>
    );
  }
  return null;
}
