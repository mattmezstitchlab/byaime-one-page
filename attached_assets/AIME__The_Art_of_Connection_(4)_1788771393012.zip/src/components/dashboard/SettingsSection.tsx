import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, CircleAlert, Download, MapPin, Trash2, Volume2 } from "lucide-react";
import { RangePicker } from "@/components/aime/RangePicker";
import { Switch } from "@/components/ui/switch";
import { LANGS, useI18n } from "@/lib/i18n";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { profileQuery, myCardsQuery } from "@/lib/aime/queries";
import { documentsQuery } from "@/lib/bureau/queries";
import { creditLedgerQuery } from "@/lib/aime/credits";
import { resolveCity, type RangeKey } from "@/lib/aime/proximity";
import { coordsFor } from "@/lib/aime/geo";
import { useRadio } from "@/components/aime/RadioProvider";
import { openSpace } from "@/components/aime/spaceSheet";
import {
  disableNotifications,
  enableNotifications,
  notifyEnabled,
  notifyState,
} from "@/lib/aime/notify";
import { cn } from "@/lib/utils";

const RADIUS_TO_RANGE: Record<number, RangeKey> = {
  0: "ville",
  40: "40",
  100: "100",
  200: "region",
};

function rangeToRadius(key: RangeKey) {
  return key === "ville"
    ? 0
    : key === "40"
      ? 40
      : key === "100"
        ? 100
        : key === "region"
          ? 200
          : 9999;
}

function Section({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-6 rounded-3xl hairline bg-card p-6">
      <h2 className="text-[19px] font-semibold tracking-[-0.02em]">{title}</h2>
      {hint && <p className="mt-1 text-[13.5px] text-muted-foreground">{hint}</p>}
      <div className="mt-5">{children}</div>
    </section>
  );
}

export function SettingsSection() {
  const { t, lang, setLang, a11y, setA11y } = useI18n();
  const { session } = useAuth();
  const userId = session?.user?.id ?? null;
  const qc = useQueryClient();
  const radio = useRadio();

  const { data: profile } = useQuery(profileQuery(userId));
  const { data: myCards = [] } = useQuery(myCardsQuery(userId));
  const { data: docs = [] } = useQuery(documentsQuery(userId));
  const { data: ledger = [] } = useQuery(creditLedgerQuery(userId));

  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [range, setRange] = useState<RangeKey>("40");
  const [saved, setSaved] = useState(false);
  const [soundState, setSoundState] = useState<"inconnu" | "ok" | "bloque">("inconnu");
  const [cookies, setCookies] = useState<string | null>(null);
  const [pwd, setPwd] = useState("");
  const [pwdBusy, setPwdBusy] = useState(false);
  const [pwdMsg, setPwdMsg] = useState<string | null>(null);
  /* Alertes du navigateur : la seule ligne de réglage, dans le compte. */
  const [alertsOn, setAlertsOn] = useState(false);
  const [alertsState, setAlertsState] = useState<ReturnType<typeof notifyState>>("a-demander");

  useEffect(() => {
    setAlertsOn(notifyEnabled());
    setAlertsState(notifyState());
  }, []);

  async function changePassword() {
    setPwdBusy(true);
    setPwdMsg(null);
    const { error } = await supabase.auth.updateUser({ password: pwd });
    setPwdBusy(false);
    if (error) {
      setPwdMsg("Changement impossible : " + error.message);
      return;
    }
    setPwd("");
    setPwdMsg("Mot de passe changé.");
  }

  useEffect(() => {
    if (!profile) return;
    setName(profile.display_name ?? "");
    setCity(profile.city ?? "");
    const km = profile.radio_radius_km ?? 40;
    setRange(RADIUS_TO_RANGE[km] ?? "all");
  }, [profile]);

  useEffect(() => {
    try {
      setCookies(localStorage.getItem("aime.cookies"));
    } catch {
      /* stockage indisponible */
    }
  }, []);

  /** Les préférences suivent le compte : un nouvel appareil les retrouve. */
  useEffect(() => {
    if (!profile) return;
    if (profile.locale && profile.locale !== lang && LANGS.some((l) => l.code === profile.locale)) {
      setLang(profile.locale as (typeof LANGS)[number]["code"]);
    }
    if (profile.a11y && typeof profile.a11y === "object") {
      setA11y(profile.a11y as Record<string, never>);
    }
    // Une seule reprise, au chargement du profil.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const savePrefs = useMutation({
    mutationFn: async (patch: Record<string, string | number | boolean | object | null>) => {
      if (!userId) return;
      const { error } = await supabase
        .from("profiles")
        .update(patch as never)
        .eq("id", userId);
      if (error) throw error;
    },
    onSuccess: () => {
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1800);
      qc.invalidateQueries({ queryKey: ["profile", userId] });
    },
  });

  const saveAccount = useMutation({
    mutationFn: async () => {
      if (!userId) return;
      const known = city ? coordsFor(city) : null;
      const point = known
        ? { lat: known[0], lon: known[1] }
        : city
          ? await resolveCity(city)
          : null;
      const { error } = await supabase
        .from("profiles")
        .update({
          display_name: name.trim(),
          city: city.trim() || null,
          radio_radius_km: rangeToRadius(range),
        })
        .eq("id", userId);
      if (error) throw error;
      const { error: geoErr } = await supabase.from("profile_geo").upsert({
        id: userId,
        lat: point?.lat ?? null,
        lon: point?.lon ?? null,
        updated_at: new Date().toISOString(),
      });
      if (geoErr) throw geoErr;
    },
    onSuccess: () => {
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1800);
      qc.invalidateQueries({ queryKey: ["profile", userId] });
    },
  });

  const credits = useMemo(
    () =>
      ledger
        .filter((l) => l.status === "valide" || l.status === "paye")
        .reduce((sum, l) => sum + (l.credits ?? 0), 0),
    [ledger],
  );

  const toVerify = docs.filter(
    (d) => d.status === "a_verifier" || (d.uncertain_fields ?? []).length > 0,
  ).length;

  const published = myCards.filter((c) => c.published).length;

  const checks = [
    {
      ok: Boolean(profile?.display_name && profile?.city),
      label: "Profil complet",
      detail: "Sans nom ni ville, Aime ne sait ni vous nommer ni vous situer.",
      to: "espace" as const,
    },
    {
      ok: myCards.length > 0,
      label: "Au moins une carte",
      detail: "Votre carte est votre présence : sans elle, personne ne peut vous aimer.",
      to: "espace" as const,
    },
    {
      ok: published > 0,
      label: "Carte publiée",
      detail: "Une carte non publiée n'apparaît ni dans le registre, ni sur la carte.",
      to: "espace" as const,
    },
    {
      ok: Boolean(profile?.lat && profile?.lon),
      label: "Lieu connu",
      detail: "Sans coordonnées, les places à proximité et les saisons ne peuvent pas trier.",
      to: "espace" as const,
    },
    {
      ok: soundState === "ok",
      label: "Son autorisé",
      detail: "Le navigateur bloque le son tant que vous n'avez pas cliqué une fois.",
      to: "espace" as const,
    },
    {
      ok: toVerify === 0,
      label: "Documents à jour",
      detail: `${toVerify} document(s) à compléter avant export ou facturation.`,
      to: "espace" as const,
    },
    {
      ok: credits > 0,
      label: "Crédits disponibles",
      detail: "Sans crédits, les demandes à l'IA échouent silencieusement.",
      to: "/credits" as const,
    },
  ];

  const testSound = () => {
    try {
      const AudioCtor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtor) return setSoundState("bloque");
      const ctx = new AudioCtor();
      void ctx.resume().then(() => {
        setSoundState(ctx.state === "running" ? "ok" : "bloque");
        void ctx.close();
      });
    } catch {
      setSoundState("bloque");
    }
  };

  const exportData = () => {
    const blob = new Blob(
      [
        JSON.stringify(
          { profile, cards: myCards, credits: ledger, documents: docs.length, a11y, lang },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "aime-mes-donnees.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearLocal = () => {
    try {
      Object.keys(localStorage)
        .filter((k) => k.startsWith("aime.") || k.startsWith("aime:"))
        .forEach((k) => localStorage.removeItem(k));
      window.location.reload();
    } catch {
      /* stockage indisponible */
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-5 pt-12 pb-24">
      {!userId && (
        <p className="rounded-3xl hairline bg-card p-5 text-[15px] text-muted-foreground">
          Connectez-vous pour régler votre compte et votre lieu.{" "}
          <Link to="/auth" className="underline">
            Entrer
          </Link>
        </p>
      )}

      <Section
        title="Ce qui pourrait mal fonctionner"
        hint="Chaque ligne est vérifiée pour de vrai sur votre compte."
      >
        <ul className="space-y-2">
          {checks.map((c) => (
            <li
              key={c.label}
              className="flex items-start gap-3 rounded-2xl hairline bg-background p-3"
            >
              <span
                className={cn(
                  "mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full",
                  c.ok ? "bg-emerald-500/12 text-emerald-600" : "bg-amber-500/12 text-amber-600",
                )}
              >
                {c.ok ? (
                  <Check className="h-3.5 w-3.5" strokeWidth={2} />
                ) : (
                  <CircleAlert className="h-3.5 w-3.5" strokeWidth={2} />
                )}
              </span>
              <span className="min-w-0">
                <span className="block text-[14.5px] font-medium">{c.label}</span>
                <span className="block text-[13px] text-muted-foreground">{c.detail}</span>
                {!c.ok &&
                  (c.to === "espace" ? (
                    <button
                      type="button"
                      onClick={() => openSpace()}
                      className="mt-1 inline-block text-[13px] underline"
                    >
                      Corriger
                    </button>
                  ) : (
                    <Link to={c.to} className="mt-1 inline-block text-[13px] underline">
                      Corriger
                    </Link>
                  ))}
              </span>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Compte et lieu" hint="Enregistré sur votre compte, retrouvé partout.">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-[13px] text-muted-foreground">
            Nom affiché
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] text-foreground outline-none"
              placeholder="Comment Aime vous appelle"
            />
          </label>
          <label className="text-[13px] text-muted-foreground">
            Ville
            <input
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="mt-1 w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] text-foreground outline-none"
              placeholder="Paris, Lyon, Bordeaux…"
            />
          </label>
        </div>

        <p className="mt-5 text-[14px]">Portée par défaut</p>
        <RangePicker value={range} onChange={setRange} city={city || null} className="mt-2" />
        <p className="mt-2 text-[12.5px] text-muted-foreground">
          <MapPin className="mr-1 inline h-3.5 w-3.5" strokeWidth={1.75} />
          Sert au Monde, aux Saisons et aux places à pourvoir. Aucune position n'est demandée au
          navigateur : votre ville suffit.
        </p>

        <div className="mt-5 flex items-center gap-3">
          <button
            type="button"
            disabled={!userId || saveAccount.isPending}
            onClick={() => saveAccount.mutate()}
            className="rounded-full bg-primary px-5 py-2.5 text-[13.5px] font-medium text-primary-foreground disabled:opacity-50"
          >
            Enregistrer
          </button>
          {saved && <span className="text-[13px] text-emerald-600">Enregistré.</span>}
        </div>

        <label className="mt-5 flex items-center justify-between gap-4 border-t border-hairline pt-4 text-[15px]">
          Me prévenir des nouveaux messages et documents
          <Switch
            checked={alertsOn}
            disabled={
              alertsState === "impossible" || alertsState === "onglet" || alertsState === "refusee"
            }
            onCheckedChange={async (value) => {
              if (!value) {
                disableNotifications();
                setAlertsOn(false);
                return;
              }
              const result = await enableNotifications();
              setAlertsState(result);
              setAlertsOn(result === "prete");
            }}
          />
        </label>
        <p className="mt-1.5 text-[12.5px] text-muted-foreground">
          {alertsState === "onglet"
            ? "Ouvrez l'application dans son propre onglet pour autoriser les alertes."
            : alertsState === "refusee"
              ? "Les alertes sont bloquées : autorisez-les dans les réglages du navigateur."
              : alertsState === "impossible"
                ? "Ce navigateur ne gère pas les alertes."
                : "Un message ou un document arrive : vous êtes prévenu, avec un petit son."}
        </p>
      </Section>

      <Section
        title="Radio et son"
        hint="Le navigateur exige un premier clic avant d'autoriser la voix d'AIME."
      >
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={testSound}
            className="inline-flex items-center gap-2 rounded-full hairline bg-background px-4 py-2.5 text-[13.5px]"
          >
            <Volume2 className="h-4 w-4" strokeWidth={1.75} />
            Tester le son
          </button>
          <span className="text-[13px] text-muted-foreground">
            {soundState === "ok"
              ? "Son autorisé."
              : soundState === "bloque"
                ? "Son bloqué par le navigateur."
                : "Non testé."}
          </span>
        </div>

        <label className="mt-5 flex items-center justify-between gap-4 rounded-2xl px-2 py-3 text-[15px]">
          Radio allumée
          <Switch checked={radio.on} onCheckedChange={() => radio.toggle()} />
        </label>
      </Section>

      <Section title="Confidentialité et données">
        <p className="text-[14px]">
          Mesure d&apos;audience :{" "}
          <span className="text-muted-foreground">
            {cookies === "all"
              ? "acceptée"
              : cookies === "essential"
                ? "limitée à l'essentiel"
                : "pas encore choisie"}
          </span>
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {(
            [
              { v: "all", label: "Tout accepter" },
              { v: "essential", label: "Essentiel seulement" },
            ] as const
          ).map((o) => (
            <button
              key={o.v}
              type="button"
              onClick={() => {
                try {
                  localStorage.setItem("aime.cookies", o.v);
                  setCookies(o.v);
                } catch {
                  /* stockage indisponible */
                }
              }}
              className={cn(
                "rounded-full px-4 py-2 text-[13.5px]",
                cookies === o.v
                  ? "bg-foreground text-background"
                  : "hairline bg-background text-muted-foreground hover:text-foreground",
              )}
            >
              {o.label}
            </button>
          ))}
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={exportData}
            className="inline-flex items-center gap-2 rounded-full hairline bg-background px-4 py-2.5 text-[13.5px]"
          >
            <Download className="h-4 w-4" strokeWidth={1.75} />
            Exporter mes données
          </button>
          <button
            type="button"
            onClick={clearLocal}
            className="inline-flex items-center gap-2 rounded-full hairline bg-background px-4 py-2.5 text-[13.5px] text-muted-foreground"
          >
            <Trash2 className="h-4 w-4" strokeWidth={1.75} />
            Effacer les réglages de cet appareil
          </button>
        </div>
      </Section>

      <Section title="Sécurité" hint="Votre mot de passe, changé sans quitter cette page.">
        <div className="flex flex-wrap items-end gap-3">
          <label className="text-[13px] text-muted-foreground">
            Nouveau mot de passe
            <input
              type="password"
              value={pwd}
              onChange={(e) => setPwd(e.target.value)}
              autoComplete="new-password"
              className="mt-1 w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] text-foreground outline-none"
              placeholder="Au moins 8 caractères"
            />
          </label>
          <button
            type="button"
            disabled={!userId || pwd.length < 8 || pwdBusy}
            onClick={() => void changePassword()}
            className="rounded-full bg-primary px-5 py-2.5 text-[13.5px] font-medium text-primary-foreground disabled:opacity-50"
          >
            Changer
          </button>
        </div>
        {pwdMsg && <p className="mt-3 text-[13px] text-muted-foreground">{pwdMsg}</p>}
      </Section>
    </div>
  );
}
