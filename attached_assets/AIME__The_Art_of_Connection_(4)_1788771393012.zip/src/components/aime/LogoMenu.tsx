import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronDown } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { SYSTEM_MENU } from "@/lib/aime/navigation";
import { openFeedback } from "@/components/aime/feedbackSheet";
import { useAuth } from "@/hooks/useAuth";
import { myRolesQuery } from "@/lib/aime/safety";

const ROW =
  "flex w-full items-center justify-between rounded-xl px-2.5 py-2.5 text-left text-[14px] transition-colors hover:bg-muted";

/**
 * Le logo AIME : cliquer dessus ramène à l'accueil.
 * La flèche n'ouvre plus un second espace fonctionnel : seulement l'aide,
 * la démonstration et, si besoin, la modération.
 */
export function LogoMenu() {
  const [open, setOpen] = useState(false);
  const { userId } = useAuth();
  const { data: roles = [] } = useQuery(myRolesQuery(userId));
  const canModerate = roles.some((role) => role === "moderator" || role === "admin");

  const close = () => setOpen(false);

  return (
    <div className="flex items-center gap-1">
      <Link
        to="/"
        className="inline-flex min-h-11 items-center text-[26px] font-semibold leading-none tracking-[-0.05em] md:text-[30px]"
      >
        AIME
      </Link>

      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            aria-label="Menu AIME"
            className="grid h-11 w-11 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <ChevronDown className="h-4 w-4" strokeWidth={2} />
          </button>
        </PopoverTrigger>

        <PopoverContent align="start" className="w-56 p-1.5">
          {SYSTEM_MENU.map((item) =>
            item.kind === "link" ? (
              <Link key={item.to} to={item.to} onClick={close} className={ROW}>
                {item.label}
              </Link>
            ) : (
              <button
                key={item.label}
                type="button"
                onClick={() => {
                  close();
                  openFeedback();
                }}
                className={ROW}
              >
                {item.label}
              </button>
            ),
          )}

          {canModerate ? (
            <>
              <div className="my-1.5 h-px bg-border" />
              <Link to="/moderation" onClick={close} className={ROW}>
                Modération
              </Link>
            </>
          ) : null}
        </PopoverContent>
      </Popover>
    </div>
  );
}
