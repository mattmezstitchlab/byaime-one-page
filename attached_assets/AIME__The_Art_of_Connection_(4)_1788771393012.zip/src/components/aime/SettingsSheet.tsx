import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { SettingsSection } from "@/components/dashboard/SettingsSection";
import { onSettings } from "@/components/aime/settingsSheet";
import { LANGS, useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const A11Y_TOGGLES = [
  { key: "settings.contrast", field: "contrast" },
  { key: "settings.motion", field: "reduceMotion" },
  { key: "settings.links", field: "underlineLinks" },
  { key: "settings.dyslexia", field: "dyslexia" },
] as const;

const SIZES = [
  { value: "normal", key: "size.normal" },
  { value: "large", key: "size.large" },
  { value: "xlarge", key: "size.xlarge" },
] as const;

/**
 * Les Réglages du site : langue, accessibilité et compte, réunis au même endroit,
 * accessibles depuis Mon espace.
 */
export function SettingsSheet() {
  const [open, setOpen] = useState(false);
  const { t, lang, setLang, a11y, setA11y } = useI18n();

  useEffect(() => onSettings(() => setOpen((v) => !v)), []);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-0 overflow-y-auto p-0 sm:max-w-2xl"
      >
        <SheetHeader className="border-b border-hairline px-5 py-4 text-left">
          <SheetTitle className="text-[20px] font-semibold">Réglages</SheetTitle>
        </SheetHeader>

        {open && (
          <div className="min-h-0 flex-1">
            <div className="mx-auto max-w-3xl px-5 pt-6">
              <section className="rounded-3xl hairline bg-card p-6">
                <h2 className="text-[19px] font-semibold tracking-[-0.02em]">
                  {t("nav.language")}
                </h2>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {LANGS.map((l) => (
                    <button
                      key={l.code}
                      type="button"
                      onClick={() => setLang(l.code)}
                      className={cn(
                        "flex items-center gap-1 rounded-full px-3 py-1.5 text-[13.5px] transition-colors",
                        l.code === lang
                          ? "bg-foreground text-background"
                          : "hairline bg-background hover:bg-muted",
                      )}
                    >
                      <span aria-hidden>{l.flag}</span>
                      {l.code.toUpperCase()}
                      {l.code === lang && <Check className="h-3 w-3" />}
                    </button>
                  ))}
                </div>
              </section>

              <section className="mt-6 rounded-3xl hairline bg-card p-6">
                <h2 className="text-[19px] font-semibold tracking-[-0.02em]">
                  {t("settings.a11y")}
                </h2>
                <p className="mt-1 text-[13.5px] text-muted-foreground">
                  Confort de lecture : appliqué partout, mémorisé sur votre compte.
                </p>
                <div className="mt-4">
                  {A11Y_TOGGLES.map((row) => (
                    <label
                      key={row.key}
                      className="flex items-center justify-between gap-4 py-2 text-[15px]"
                    >
                      {t(row.key)}
                      <Switch
                        checked={Boolean(a11y[row.field])}
                        onCheckedChange={(v) => setA11y({ [row.field]: v })}
                      />
                    </label>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {SIZES.map((size) => (
                    <button
                      key={size.value}
                      type="button"
                      onClick={() => setA11y({ textSize: size.value })}
                      className={cn(
                        "rounded-full px-3 py-1.5 text-[13.5px] transition-colors",
                        a11y.textSize === size.value
                          ? "bg-foreground text-background"
                          : "hairline bg-background hover:bg-muted",
                      )}
                    >
                      {t(size.key)}
                    </button>
                  ))}
                </div>
              </section>
            </div>

            <SettingsSection />
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
