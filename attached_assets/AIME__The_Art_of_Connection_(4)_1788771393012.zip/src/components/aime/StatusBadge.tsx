import { cn } from "@/lib/utils";
import { STATUS_LABEL, type CardStatus } from "@/lib/aime/types";

export function StatusBadge({
  status,
  verified,
  className,
}: {
  status: CardStatus;
  verified?: boolean;
  className?: string;
}) {
  return (
    <span className={cn("flex items-center gap-1.5", className)}>
      <span
        className={cn(
          "rounded-full px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.14em] glass-strong hairline",
          status === "indisponible" && "text-muted-foreground",
          status === "recommande" && "text-aime",
          status === "populaire" && "text-foreground",
        )}
      >
        {STATUS_LABEL[status]}
      </span>
      {verified && (
        <span
          title="Vérifié"
          className="grid h-6 w-6 place-items-center rounded-full glass-strong hairline text-[11px] text-verified"
        >
          ✓
        </span>
      )}
    </span>
  );
}
