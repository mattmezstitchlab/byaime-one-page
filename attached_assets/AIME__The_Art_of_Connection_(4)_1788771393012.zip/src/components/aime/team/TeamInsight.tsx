import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Sparkles, Users, X } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { createTeam } from "@/lib/aime/team/teams";
import {
  cardFitsRole,
  objectiveFor,
  readSelection,
  selectionChips,
  type Role,
} from "@/lib/aime/team/quintessence";
import type { Card } from "@/lib/aime/types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/**
 * La lecture d'une sélection : ce qu'elle réunit, ce qu'elle rend possible,
 * et qui manque encore. Rien n'est enregistré tant qu'on ne crée pas l'équipe.
 */
export function TeamInsight({
  cards,
  catLabel,
  need,
  onNeed,
}: {
  cards: Card[];
  catLabel: Map<string, string>;
  need: Role | null;
  onNeed: (role: Role | null) => void;
}) {
  const { userId } = useAuth();
  const navigate = useNavigate();
  const readings = useMemo(() => readSelection(cards), [cards]);
  const [formulaId, setFormulaId] = useState<string | null>(null);
  const reading = readings.find((r) => r.formula.id === formulaId) ?? readings[0];
  const chips = useMemo(() => selectionChips(cards, catLabel), [cards, catLabel]);

  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [objective, setObjective] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTitle(reading?.formula.title ?? "Notre équipe");
    setObjective(objectiveFor(reading, cards));
  }, [open, reading, cards]);

  if (cards.length === 0) return null;

  const create = async () => {
    if (!userId) {
      toast("Connectez-vous pour créer une équipe.");
      return;
    }
    setSaving(true);
    try {
      const id = await createTeam({
        userId,
        title,
        objective,
        universeSlug: chips.univers[0] ?? null,
        members: cards.map((card) => ({
          card,
          slot:
            reading?.covered.find((c) => c.cards.some((x) => x.id === card.id))?.role.label ??
            (catLabel.get(card.category_slug) ?? "Membre"),
        })),
      });
      setOpen(false);
      toast.success("L'équipe est créée : chacun reçoit une notification.");
      void navigate({ to: "/equipe/$id", params: { id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Création impossible.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="border-b border-hairline bg-accent/30 px-3 py-3">
      <p className="flex items-center gap-1.5 text-[12px] font-medium">
        <Sparkles className="h-3.5 w-3.5" strokeWidth={1.75} />
        Ce que vous réunissez
      </p>
      <div className="mt-1.5 flex flex-wrap gap-1">
        {[...chips.metiers, ...chips.villes].slice(0, 8).map((c) => (
          <span key={c} className="rounded-full bg-background px-2 py-0.5 text-[11.5px]">
            {c}
          </span>
        ))}
      </div>

      {readings.length > 0 && (
        <>
          <p className="mt-3 text-[12px] font-medium">Formules possibles</p>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {readings.map((r) => (
              <button
                key={r.formula.id}
                type="button"
                onClick={() => setFormulaId(r.formula.id)}
                aria-pressed={reading?.formula.id === r.formula.id}
                className={`rounded-full px-2.5 py-1 text-[11.5px] ${
                  reading?.formula.id === r.formula.id
                    ? "bg-foreground text-background"
                    : "bg-background"
                }`}
              >
                {r.formula.title} · {r.covered.length}/{r.formula.roles.length}
              </button>
            ))}
          </div>
          {reading && (
            <p className="mt-1.5 text-[12px] text-muted-foreground">{reading.formula.why}</p>
          )}
        </>
      )}

      {reading && reading.missing.length > 0 && (
        <>
          <p className="mt-3 text-[12px] font-medium">
            Ce qui manque
            {need && (
              <button
                type="button"
                onClick={() => onNeed(null)}
                className="ml-2 inline-flex items-center gap-1 rounded-full bg-background px-2 py-0.5 text-[11px] text-muted-foreground"
              >
                Voir tout le monde <X className="h-3 w-3" />
              </button>
            )}
          </p>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {reading.missing.map((role) => (
              <button
                key={role.label}
                type="button"
                title={role.hint}
                onClick={() => onNeed(need?.label === role.label ? null : role)}
                aria-pressed={need?.label === role.label}
                className={`rounded-full px-2.5 py-1 text-[11.5px] ${
                  need?.label === role.label
                    ? "bg-foreground text-background"
                    : "bg-background text-muted-foreground"
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>
        </>
      )}

      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1.5 text-[12.5px] text-primary-foreground"
      >
        <Users className="h-3.5 w-3.5" strokeWidth={1.75} />
        En faire une équipe
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="z-[90] sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Une équipe, une page</DialogTitle>
            <DialogDescription>
              Chaque personne réunie recevra une notification qui explique pourquoi.
            </DialogDescription>
          </DialogHeader>
          <label className="block text-[12.5px] font-medium">
            Nom de l&apos;équipe
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 h-11 w-full rounded-2xl hairline bg-background px-3 text-[14px] font-normal"
            />
          </label>
          <label className="block text-[12.5px] font-medium">
            Objectif, en une phrase
            <textarea
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              rows={3}
              className="mt-1 w-full rounded-2xl hairline bg-background p-3 text-[14px] font-normal"
            />
          </label>
          <button
            type="button"
            disabled={saving}
            onClick={() => void create()}
            className="h-11 rounded-full bg-foreground text-[13px] text-background disabled:opacity-60"
          >
            {saving ? "Création…" : `Créer l'équipe (${cards.length} personnes)`}
          </button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Filtre de liste : ne montrer que les personnes qui comblent le manque choisi. */
export function fitsNeed(card: Card, need: Role | null) {
  return !need || cardFitsRole(card, need);
}
