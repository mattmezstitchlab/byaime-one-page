/**
 * La palette du LAB, discrète comme un outil de création : contenu, formes,
 * structure, personnes et modules AIME. Chaque geste pose un objet au centre
 * de la toile ; le drag et le regroupement font le reste.
 */
import { useRef, useState } from "react";
import {
  Circle,
  FileText,
  Image as ImageIcon,
  LayoutGrid,
  Minus,
  Square,
  StickyNote,
  Type,
  UserRound,
} from "lucide-react";
import { LabCardSearch, type LabCard } from "@/components/aime/lab/LabCardSearch";

export type LabToolAction =
  | { kind: "objet"; type: "mot" | "note" | "texte" | "etape" }
  | { kind: "forme"; shape: "rect" | "cercle" | "ligne" }
  | { kind: "carte"; card: LabCard }
  | { kind: "module"; module: "timeline" | "personnes" | "documents" };

const BTN =
  "grid h-9 w-9 place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-muted hover:text-foreground";

export function LabToolbar({
  onAction,
  onFile,
  userId,
}: {
  onAction: (action: LabToolAction) => void;
  /** Image ou document : le fichier devient une pièce media_items. */
  onFile: (file: File) => void;
  userId: string | null;
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [modulesOpen, setModulesOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="relative flex shrink-0 flex-col items-center gap-1 border-r border-hairline px-1.5 py-2">
      <button
        type="button"
        title="Mot"
        aria-label="Poser un mot"
        className={BTN}
        onClick={() => onAction({ kind: "objet", type: "mot" })}
      >
        <Type className="h-4 w-4" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        title="Post-it"
        aria-label="Poser un post-it"
        className={BTN}
        onClick={() => onAction({ kind: "objet", type: "note" })}
      >
        <StickyNote className="h-4 w-4" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        title="Personne"
        aria-label="Poser une personne"
        className={BTN}
        onClick={() => {
          setModulesOpen(false);
          setSearchOpen((v) => !v);
        }}
      >
        <UserRound className="h-4 w-4" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        title="Image ou document"
        aria-label="Importer une image ou un document"
        className={BTN}
        onClick={() => fileRef.current?.click()}
      >
        <ImageIcon className="h-4 w-4" strokeWidth={1.75} />
      </button>

      <span aria-hidden className="my-1 h-px w-6 bg-hairline" />

      <button
        type="button"
        title="Rectangle"
        aria-label="Poser un rectangle"
        className={BTN}
        onClick={() => onAction({ kind: "forme", shape: "rect" })}
      >
        <Square className="h-4 w-4" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        title="Cercle"
        aria-label="Poser un cercle"
        className={BTN}
        onClick={() => onAction({ kind: "forme", shape: "cercle" })}
      >
        <Circle className="h-4 w-4" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        title="Ligne"
        aria-label="Poser une ligne"
        className={BTN}
        onClick={() => onAction({ kind: "forme", shape: "ligne" })}
      >
        <Minus className="h-4 w-4" strokeWidth={1.75} />
      </button>

      <span aria-hidden className="my-1 h-px w-6 bg-hairline" />

      <button
        type="button"
        title="Modules AIME"
        aria-label="Poser un module AIME"
        className={BTN}
        onClick={() => {
          setSearchOpen(false);
          setModulesOpen((v) => !v);
        }}
      >
        <LayoutGrid className="h-4 w-4" strokeWidth={1.75} />
      </button>

      <input
        ref={fileRef}
        type="file"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
          e.target.value = "";
        }}
      />

      {searchOpen && (
        <div className="absolute left-full top-2 z-30 ml-2">
          <LabCardSearch
            placeholder={userId ? "Chercher une personne…" : "Connectez-vous pour chercher"}
            onPick={(card) => {
              onAction({ kind: "carte", card });
              setSearchOpen(false);
            }}
          />
        </div>
      )}

      {modulesOpen && (
        <div className="absolute left-full top-2 z-30 ml-2 w-52 rounded-2xl hairline bg-background p-1.5 shadow-soft">
          {(
            [
              {
                key: "timeline",
                label: "Ligne de temps du projet",
                hint: "Ce qu'AIME a déjà compris",
              },
              { key: "personnes", label: "Personnes", hint: "Cartes posées et équipe" },
              { key: "documents", label: "Documents", hint: "Pièces apportées" },
            ] as const
          ).map((m) => (
            <button
              key={m.key}
              type="button"
              onClick={() => {
                onAction({ kind: "module", module: m.key });
                setModulesOpen(false);
              }}
              className="block w-full rounded-xl px-2.5 py-2 text-left hover:bg-muted"
            >
              <span className="block text-[13px] font-medium">{m.label}</span>
              <span className="block text-[11.5px] text-muted-foreground">{m.hint}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** L'icône d'un document, utilisée par la toile. */
export function DocumentChipIcon() {
  return <FileText className="h-4 w-4 shrink-0" strokeWidth={1.75} />;
}
