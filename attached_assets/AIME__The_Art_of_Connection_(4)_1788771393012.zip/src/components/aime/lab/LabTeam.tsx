/**
 * La colonne Équipe : qui construit, avec son rôle. Les personnes sont des
 * cartes AIME (recherche du site), les rôles ceux des projets — aucun
 * deuxième système d'utilisateurs.
 */
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, X } from "lucide-react";
import { LabCardSearch } from "@/components/aime/lab/LabCardSearch";
import { addMember, MEMBERS_QK, removeMember } from "@/lib/aime/lab/labObjects";
import type { LabBoard, LabMember } from "@/lib/aime/lab/types";

export function LabTeam({
  board,
  members,
  userId,
}: {
  board: LabBoard;
  members: LabMember[];
  userId: string | null;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const isOwner = userId === board.owner_id;
  const refresh = () => void qc.invalidateQueries({ queryKey: MEMBERS_QK(board.id) });

  const invite = useMutation({
    mutationFn: async (cardId: string) => {
      if (!isOwner) throw new Error("Seul le créateur du LAB invite pour l'instant.");
      await addMember(board.id, cardId, "Contributeur");
    },
    onSuccess: () => {
      setOpen(false);
      refresh();
    },
    onError: (e: Error) => toast(e.message),
  });

  const drop = useMutation({
    mutationFn: (id: string) => removeMember(id),
    onSuccess: refresh,
    onError: (e: Error) => toast(e.message),
  });

  return (
    <section className="rounded-3xl hairline bg-card p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h3 className="text-[15px] font-semibold">Équipe</h3>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex items-center gap-1 text-[12.5px] text-muted-foreground underline underline-offset-4 hover:text-foreground"
        >
          <Plus className="h-3.5 w-3.5" strokeWidth={1.75} /> Inviter
        </button>
      </div>

      {open && (
        <div className="mt-3">
          <LabCardSearch
            placeholder="Chercher une personne AIME…"
            onPick={(card) => invite.mutate(card.id)}
          />
        </div>
      )}

      <ul className="mt-3 space-y-1.5">
        {members.map((m) => (
          <li
            key={m.id}
            className="flex items-center gap-2.5 rounded-2xl bg-background px-2.5 py-2"
          >
            <span className="grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-full bg-muted text-[12px] font-medium">
              {m.card?.image_url ? (
                <img src={m.card.image_url} alt="" className="h-full w-full object-cover" />
              ) : (
                (m.card?.name ?? "?").slice(0, 1).toUpperCase()
              )}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[13.5px] font-medium">
                {m.card?.name ?? "Une carte"}
              </span>
              <span className="block truncate text-[11.5px] text-muted-foreground">
                {m.role_label}
              </span>
            </span>
            {(isOwner || m.card?.id) && (
              <button
                type="button"
                aria-label="Retirer de l'équipe"
                onClick={() => drop.mutate(m.id)}
                className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-muted"
              >
                <X className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            )}
          </li>
        ))}
        {members.length === 0 && (
          <li className="text-[12.5px] leading-relaxed text-muted-foreground">
            Vous seul pour l'instant. Invitez une personne AIME : elle verra la même toile.
          </li>
        )}
      </ul>
    </section>
  );
}
