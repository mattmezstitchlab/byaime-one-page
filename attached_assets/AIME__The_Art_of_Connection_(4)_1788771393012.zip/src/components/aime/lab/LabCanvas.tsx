/**
 * La toile du LAB : une grande surface calme, pan et zoom au pointeur, des
 * objets qu'on pose, déplace, redimensionne, édite et commente. Tout est
 * persisté dans lab_objects ; les commentaires passent par la table
 * `comments` du site (target_type « lab_object ») — rien de recréé ici.
 */
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, MessageCircle, Minus, Pencil, Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { HeroTimeline } from "@/components/aime/HeroTimeline";
import { LabToolbar, type LabToolAction } from "@/components/aime/lab/LabToolbar";
import { agentDef, PROPOSITION_STATUS_LABEL } from "@/lib/aime/lab/agents";
import { addObject, deleteObject, OBJECTS_QK, updateObject } from "@/lib/aime/lab/labObjects";
import { catLabel } from "@/lib/aime/lab/labRecognition";
import type { LabBoard, LabMember, LabObject } from "@/lib/aime/lab/types";
import { addComment, commentsQuery, type LabObjectTarget } from "@/lib/aime/social";
import { uploadMediaFile } from "@/lib/aime/media";
import { deriveTimeline } from "@/lib/aime/world/derive";
import type { WorldProject } from "@/lib/aime/world/types";
import { cn } from "@/lib/utils";

type Drag =
  | { kind: "pan"; pointerId: number; startX: number; startY: number; camX: number; camY: number }
  | {
      kind: "move" | "resize";
      id: string;
      pointerId: number;
      startX: number;
      startY: number;
      ox: number;
      oy: number;
      ow: number;
      oh: number;
    };

const CAT_DOT: Record<string, string> = {
  objectifs: "bg-foreground",
  personnes: "bg-sky-500",
  lieux: "bg-emerald-500",
  temps: "bg-amber-500",
  ressources: "bg-violet-500",
  idees: "bg-muted-foreground",
};

export function LabCanvas({
  board,
  objects,
  members,
  myCardId,
  userId,
  project,
  focusRequest,
  headerRight,
}: {
  board: LabBoard;
  objects: LabObject[];
  members: LabMember[];
  myCardId: string | null;
  userId: string | null;
  /** Le projet compris par AIME : la timeline en est une projection. */
  project: WorldProject | null;
  /** Demande de recentrage venue du schéma central. */
  focusRequest: { id: string; nonce: number } | null;
  /** Les boutons de la page (schéma, équipe sur téléphone). */
  headerRight?: ReactNode;
}) {
  const qc = useQueryClient();
  const hostRef = useRef<HTMLDivElement>(null);
  const [cam, setCam] = useState({ x: 0, y: 0, scale: 1 });
  const camRef = useRef(cam);
  camRef.current = cam;
  const [selected, setSelected] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [ghost, setGhost] = useState<Record<string, { x: number; y: number; w: number | null }>>(
    {},
  );
  const [commentFor, setCommentFor] = useState<string | null>(null);
  const dragRef = useRef<Drag | null>(null);

  const refresh = () => void qc.invalidateQueries({ queryKey: OBJECTS_QK(board.id) });
  const maxZ = objects.reduce((m, o) => Math.max(m, o.z), 0);

  const invalidate = useMutation({
    mutationFn: async (fn: () => Promise<unknown>) => fn(),
    onSuccess: refresh,
    onError: (e: Error) => toast(e.message),
  });

  /* Zoom molette, vers le curseur (listener non passif). */
  useEffect(() => {
    const el = hostRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const c = camRef.current;
      const factor = e.deltaY < 0 ? 1.08 : 1 / 1.08;
      const scale = Math.min(2, Math.max(0.4, c.scale * factor));
      const px = e.clientX - r.left;
      const py = e.clientY - r.top;
      setCam({
        scale,
        x: px - ((px - c.x) * scale) / c.scale,
        y: py - ((py - c.y) * scale) / c.scale,
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  /* Recentrage demandé par le schéma central. */
  useEffect(() => {
    if (!focusRequest) return;
    const o = objects.find((x) => x.id === focusRequest.id);
    const el = hostRef.current;
    if (!o || !el) return;
    const r = el.getBoundingClientRect();
    const c = camRef.current;
    setCam({ ...c, x: r.width / 2 - (o.x + 80) * c.scale, y: r.height / 2 - (o.y + 30) * c.scale });
    setSelected(o.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusRequest?.nonce]);

  /* Suppression au clavier. */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!selected || editing) return;
      if (e.key === "Delete" || e.key === "Backspace") {
        const target = e.target as HTMLElement;
        if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
        invalidate.mutate(() => deleteObject(selected));
        setSelected(null);
      }
      if (e.key === "Escape") setSelected(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected, editing, invalidate]);

  const worldAt = (clientX: number, clientY: number) => {
    const el = hostRef.current!;
    const r = el.getBoundingClientRect();
    const c = camRef.current;
    return { x: (clientX - r.left - c.x) / c.scale, y: (clientY - r.top - c.y) / c.scale };
  };

  const centerWorld = (offset = 0) => {
    const el = hostRef.current;
    const c = camRef.current;
    if (!el) return { x: 200 + offset, y: 200 + offset };
    const r = el.getBoundingClientRect();
    return {
      x: (r.width / 2 - c.x) / c.scale - 80 + offset,
      y: (r.height / 2 - c.y) / c.scale - 24 + offset,
    };
  };

  /* Poser un objet au centre, en escalier. */
  const place = async (
    type: LabObject["type"],
    data: LabObject["data"],
    opts?: { w?: number | null; edit?: boolean },
  ) => {
    if (!userId) {
      toast("Connectez-vous pour construire sur la toile.");
      return;
    }
    const p = centerWorld((objects.length % 6) * 26);
    try {
      const id = await addObject({
        boardId: board.id,
        userId,
        type,
        x: p.x,
        y: p.y,
        w: opts?.w ?? null,
        data,
        z: maxZ + 1,
      });
      refresh();
      setSelected(id);
      if (opts?.edit) {
        setEditing(id);
        setEditText("");
      }
    } catch (e) {
      toast((e as Error).message);
    }
  };

  const onFile = async (file: File) => {
    if (!userId) {
      toast("Connectez-vous pour importer un document.");
      return;
    }
    toast("Import de la pièce…");
    try {
      const url = await uploadMediaFile(userId, file);
      await place("media", {
        url,
        text: file.name,
        mediaKind: file.type.startsWith("image/") ? "image" : "document",
      });
    } catch (e) {
      toast((e as Error).message);
    }
  };

  const startEdit = (o: LabObject) => {
    setEditing(o.id);
    setEditText(o.data.text ?? "");
  };

  const commitEdit = (o: LabObject) => {
    setEditing(null);
    const text = editText.trim();
    if (text === (o.data.text ?? "")) return;
    invalidate.mutate(() => updateObject(o.id, { data: { ...o.data, text } }));
  };

  /* Le rendu d'un objet, selon sa nature. */
  const renderBody = (o: LabObject): ReactNode => {
    const cat = catLabel(o.data.cat);
    if (editing === o.id) {
      return (
        <textarea
          autoFocus
          value={editText}
          onChange={(e) => setEditText(e.target.value)}
          onBlur={() => commitEdit(o)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              commitEdit(o);
            }
          }}
          rows={o.type === "mot" ? 1 : 3}
          className={cn(
            "w-full resize-none rounded-xl border border-foreground/20 bg-white px-2.5 py-1.5 text-[14px] outline-none",
            o.type === "mot" && "w-36 rounded-full text-center",
          )}
        />
      );
    }
    switch (o.type) {
      case "mot":
        return (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-foreground/12 bg-white px-3 py-1.5 text-[13.5px] shadow-soft">
            {o.data.cat && CAT_DOT[o.data.cat] && (
              <span aria-hidden className={cn("h-1.5 w-1.5 rounded-full", CAT_DOT[o.data.cat])} />
            )}
            <span>{o.data.text || "…"}</span>
          </span>
        );
      case "note":
        return (
          <div
            className="w-48 rounded-lg border border-amber-200 bg-amber-50 p-3 text-[13.5px] leading-relaxed text-amber-950 shadow-soft"
            style={{ width: o.w ?? undefined, minHeight: o.h ?? undefined }}
          >
            {o.data.text || "Double-cliquez pour écrire…"}
          </div>
        );
      case "texte":
        return (
          <div className="w-64 text-[15px] leading-relaxed">
            {o.data.text || "Double-cliquez pour écrire…"}
          </div>
        );
      case "forme":
        if (o.data.shape === "cercle")
          return (
            <div
              className="rounded-full border-2 border-foreground/30 bg-white/60"
              style={{ width: o.w ?? 120, height: o.h ?? 120 }}
            />
          );
        if (o.data.shape === "ligne")
          return <div className="h-0.5 bg-foreground/40" style={{ width: o.w ?? 160 }} />;
        return (
          <div
            className="rounded-lg border-2 border-foreground/30 bg-white/60"
            style={{ width: o.w ?? 160, height: o.h ?? 100 }}
          />
        );
      case "media":
        return o.data.mediaKind === "image" ? (
          <img
            src={o.data.url}
            alt={o.data.text ?? ""}
            className="rounded-xl border border-foreground/10 bg-white object-cover shadow-soft"
            style={{ width: o.w ?? 224, height: o.h ?? 150 }}
          />
        ) : (
          <a
            href={o.data.url}
            target="_blank"
            rel="noreferrer"
            className="flex w-56 items-center gap-2 rounded-xl border border-foreground/12 bg-white px-3 py-2.5 text-[13px] shadow-soft hover:bg-muted"
            onClick={(e) => e.stopPropagation()}
          >
            <span aria-hidden className="text-[16px]">
              📄
            </span>
            <span className="min-w-0 flex-1 truncate">{o.data.text || "document"}</span>
          </a>
        );
      case "carte":
        return (
          <span className="flex items-center gap-2 rounded-full border border-foreground/12 bg-white py-1.5 pr-3.5 pl-1.5 shadow-soft">
            <span className="grid h-7 w-7 shrink-0 place-items-center overflow-hidden rounded-full bg-muted text-[11px] font-medium">
              {o.data.photo ? (
                <img src={o.data.photo} alt="" className="h-full w-full object-cover" />
              ) : (
                (o.data.name ?? "?").slice(0, 1).toUpperCase()
              )}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13px] font-medium">
                {o.data.name ?? "Une personne"}
              </span>
              <span className="block truncate text-[11px] text-muted-foreground">
                {(o.data.headline || o.data.city || cat) ?? ""}
              </span>
            </span>
          </span>
        );
      case "etape":
        return (
          <span className="inline-flex items-center gap-2 rounded-full border border-foreground/15 bg-foreground px-3.5 py-1.5 text-[13px] font-medium text-background shadow-soft">
            {o.data.text || "Nouvelle étape"}
          </span>
        );
      case "proposition": {
        const agent = agentDef(o.data.agent);
        const status = o.data.propositionStatus ?? "propose";
        return (
          <div
            className={cn(
              "w-[280px] rounded-2xl border bg-white p-3 shadow-soft",
              status === "valide" && "border-emerald-300",
              status === "ecarte" && "opacity-55",
            )}
          >
            <div className="flex items-center gap-1.5">
              {agent && <span aria-hidden className={cn("h-1.5 w-1.5 rounded-full", agent.dot)} />}
              <span className="text-[11px] font-medium tracking-[0.08em] uppercase">
                {agent?.label ?? "AIME"}
              </span>
              <span
                className={cn(
                  "ml-auto rounded-full px-2 py-0.5 text-[10.5px]",
                  status === "valide"
                    ? "bg-emerald-100 text-emerald-800"
                    : status === "ecarte"
                      ? "bg-muted text-muted-foreground"
                      : "bg-amber-100 text-amber-800",
                )}
              >
                {PROPOSITION_STATUS_LABEL[status]}
              </span>
            </div>
            <p className="mt-1.5 text-[13.5px] leading-relaxed">{o.data.text || "…"}</p>
            {o.data.why && (
              <p className="mt-1.5 border-t border-hairline pt-1.5 text-[12px] leading-relaxed text-muted-foreground">
                <span className="font-medium">Pourquoi : </span>
                {o.data.why}
              </p>
            )}
            {o.data.uses && o.data.uses.length > 0 && (
              <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">
                S'appuie sur : {o.data.uses.join(" · ")}
              </p>
            )}
          </div>
        );
      }
      case "module":
        if (o.data.module === "timeline") {
          const markers = project ? deriveTimeline(project) : [];
          return (
            <div className="w-[560px] max-w-[80vw] overflow-hidden rounded-2xl border border-white/10 bg-black text-white shadow-soft">
              <HeroTimeline markers={markers} preview autoScroll={false} className="w-full" />
            </div>
          );
        }
        if (o.data.module === "personnes") {
          const gens = [
            ...objects
              .filter((x) => x.type === "carte")
              .map((x) => ({ id: x.id, name: x.data.name ?? "Une personne" })),
            ...members.map((m) => ({ id: m.id, name: m.card?.name ?? "Membre" })),
          ];
          return (
            <div className="w-64 rounded-2xl border border-foreground/10 bg-white p-3 shadow-soft">
              <p className="text-[11px] tracking-[0.14em] text-muted-foreground uppercase">
                Personnes
              </p>
              <ul className="mt-2 space-y-1">
                {gens.length === 0 && (
                  <li className="text-[12.5px] text-muted-foreground">Personne pour l'instant.</li>
                )}
                {gens.slice(0, 8).map((g) => (
                  <li key={g.id} className="truncate text-[13px]">
                    · {g.name}
                  </li>
                ))}
              </ul>
            </div>
          );
        }
        return (
          <div className="w-64 rounded-2xl border border-foreground/10 bg-white p-3 shadow-soft">
            <p className="text-[11px] tracking-[0.14em] text-muted-foreground uppercase">
              Documents
            </p>
            <ul className="mt-2 space-y-1">
              {objects.filter((x) => x.type === "media").length === 0 && (
                <li className="text-[12.5px] text-muted-foreground">
                  Aucune pièce pour l'instant.
                </li>
              )}
              {objects
                .filter((x) => x.type === "media")
                .slice(0, 8)
                .map((x) => (
                  <li key={x.id} className="truncate text-[13px]">
                    · {x.data.text || "pièce"}
                  </li>
                ))}
            </ul>
          </div>
        );
      default:
        return null;
    }
  };

  const resizable = (o: LabObject) =>
    o.type === "forme" || o.type === "media" || o.type === "module" || o.type === "note";

  const selectedObj = objects.find((o) => o.id === selected) ?? null;
  const ghostOf = (o: LabObject) => ghost[o.id];
  const screenPos = (o: LabObject) => {
    const g = ghostOf(o);
    return { left: (g?.x ?? o.x) * cam.scale + cam.x, top: (g?.y ?? o.y) * cam.scale + cam.y };
  };

  /* Un geste de la palette devient un objet posé au centre. */
  const handleTool = (action: LabToolAction) => {
    switch (action.kind) {
      case "objet":
        void place(action.type, {}, { edit: true });
        break;
      case "forme":
        void place("forme", { shape: action.shape }, { w: action.shape === "ligne" ? 160 : 140 });
        break;
      case "carte":
        void place("carte", {
          cardId: action.card.id,
          name: action.card.name,
          headline: action.card.headline,
          photo: action.card.image_url,
          city: action.card.city,
        });
        break;
      case "module":
        void place(
          "module",
          { module: action.module },
          { w: action.module === "timeline" ? 560 : 264 },
        );
        break;
    }
  };

  return (
    <div className="flex min-w-0 flex-1 flex-col">
      <div className="flex items-center justify-between gap-2 border-b border-hairline px-3 py-1.5">
        <p className="min-w-0 truncate text-[13.5px] font-medium">{board.title}</p>
        {headerRight}
      </div>
      <div className="flex min-h-0 flex-1">
        <LabToolbar userId={userId} onFile={(f) => void onFile(f)} onAction={handleTool} />
        <div
          ref={hostRef}
          data-pan="1"
          className="relative h-full min-w-0 flex-1 touch-none overflow-hidden bg-[#faf9f6] select-none"
          style={{
            backgroundImage: "radial-gradient(rgba(0,0,0,0.055) 1px, transparent 1px)",
            backgroundSize: `${22 * cam.scale}px ${22 * cam.scale}px`,
            backgroundPosition: `${cam.x}px ${cam.y}px`,
          }}
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest("[data-object]")) return;
            dragRef.current = {
              kind: "pan",
              pointerId: e.pointerId,
              startX: e.clientX,
              startY: e.clientY,
              camX: cam.x,
              camY: cam.y,
            };
            hostRef.current?.setPointerCapture(e.pointerId);
            setSelected(null);
            setEditing(null);
          }}
          onPointerMove={(e) => {
            const d = dragRef.current;
            if (!d || d.pointerId !== e.pointerId) return;
            if (d.kind === "pan") {
              setCam((c) => ({
                ...c,
                x: d.camX + (e.clientX - d.startX),
                y: d.camY + (e.clientY - d.startY),
              }));
              return;
            }
            const dx = (e.clientX - d.startX) / cam.scale;
            const dy = (e.clientY - d.startY) / cam.scale;
            if (d.kind === "move") {
              setGhost((g) => ({
                ...g,
                [d.id]: { x: Math.round(d.ox + dx), y: Math.round(d.oy + dy), w: null },
              }));
            } else {
              setGhost((g) => ({
                ...g,
                [d.id]: {
                  x: g[d.id]?.x ?? 0,
                  y: g[d.id]?.y ?? 0,
                  w: Math.max(40, Math.round(d.ow + dx * cam.scale)),
                },
              }));
            }
          }}
          onPointerUp={(e) => {
            const d = dragRef.current;
            dragRef.current = null;
            if (!d || d.pointerId !== e.pointerId) return;
            if (d.kind === "move") {
              const g = ghost[d.id];
              if (g) invalidate.mutate(() => updateObject(d.id, { x: g.x, y: g.y }));
            }
            if (d.kind === "resize") {
              const g = ghost[d.id];
              if (g?.w) invalidate.mutate(() => updateObject(d.id, { w: g.w }));
            }
            setGhost({});
          }}
          onPointerCancel={() => {
            dragRef.current = null;
            setGhost({});
          }}
        >
          {/* Zoom, discret en bas à gauche. */}
          <div className="absolute bottom-3 left-3 z-20 flex items-center gap-1 rounded-full hairline bg-background/90 px-1.5 py-1 shadow-soft backdrop-blur">
            <button
              type="button"
              aria-label="Dézoomer"
              className="grid h-7 w-7 place-items-center rounded-full hover:bg-muted"
              onClick={() => setCam((c) => ({ ...c, scale: Math.max(0.4, c.scale / 1.15) }))}
            >
              <Minus className="h-3.5 w-3.5" strokeWidth={1.75} />
            </button>
            <span className="w-10 text-center text-[11.5px] tabular-nums text-muted-foreground">
              {Math.round(cam.scale * 100)}%
            </span>
            <button
              type="button"
              aria-label="Zoomer"
              className="grid h-7 w-7 place-items-center rounded-full hover:bg-muted"
              onClick={() => setCam((c) => ({ ...c, scale: Math.min(2, c.scale * 1.15) }))}
            >
              <Plus className="h-3.5 w-3.5" strokeWidth={1.75} />
            </button>
          </div>

          {objects.length === 0 && (
            <div className="pointer-events-none absolute inset-0 grid place-items-center">
              <div className="max-w-xs text-center">
                <p className="text-[15px] font-medium">Une toile blanche, à vous tous.</p>
                <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
                  Posez vos premiers mots avec la palette : plus la toile se remplit, plus AIME
                  comprend le projet que vous construisez ensemble.
                </p>
              </div>
            </div>
          )}

          {/* Les objets, dans le repère de la toile. */}
          <div
            aria-hidden={false}
            className="absolute top-0 left-0 origin-top-left"
            style={{ transform: `translate(${cam.x}px, ${cam.y}px) scale(${cam.scale})` }}
          >
            {objects.map((o) => {
              const g = ghost[o.id];
              const isSel = selected === o.id;
              return (
                <div
                  key={o.id}
                  data-object="1"
                  tabIndex={0}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    if (editing === o.id) return;
                    dragRef.current = {
                      kind: "move",
                      id: o.id,
                      pointerId: e.pointerId,
                      startX: e.clientX,
                      startY: e.clientY,
                      ox: o.x,
                      oy: o.y,
                      ow: o.w ?? 160,
                      oh: o.h ?? 100,
                    };
                    e.currentTarget.setPointerCapture(e.pointerId);
                    setSelected(o.id);
                    if (o.z < maxZ) invalidate.mutate(() => updateObject(o.id, { z: maxZ + 1 }));
                  }}
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    if (
                      o.type === "mot" ||
                      o.type === "note" ||
                      o.type === "texte" ||
                      o.type === "etape" ||
                      o.type === "proposition"
                    )
                      startEdit(o);
                  }}
                  className={cn(
                    "absolute cursor-grab outline-none active:cursor-grabbing",
                    isSel && "z-10",
                    o.type === "module" && "cursor-default active:cursor-default",
                  )}
                  style={{
                    left: g?.x ?? o.x,
                    top: g?.y ?? o.y,
                    zIndex: o.z,
                    width: g?.w ?? o.w ?? undefined,
                  }}
                >
                  <div
                    className={cn(
                      "rounded-xl",
                      isSel && "ring-2 ring-foreground/60 ring-offset-4 ring-offset-[#faf9f6]",
                    )}
                  >
                    {renderBody(o)}
                  </div>
                  {isSel && resizable(o) && (
                    <span
                      aria-label="Redimensionner"
                      role="button"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        dragRef.current = {
                          kind: "resize",
                          id: o.id,
                          pointerId: e.pointerId,
                          startX: e.clientX,
                          startY: e.clientY,
                          ox: o.x,
                          oy: o.y,
                          ow: o.w ?? (o.type === "forme" ? 160 : o.type === "media" ? 224 : 200),
                          oh: o.h ?? 100,
                        };
                        e.currentTarget.setPointerCapture(e.pointerId);
                      }}
                      className="absolute -right-1.5 -bottom-1.5 h-3 w-3 cursor-nwse-resize rounded-full border-2 border-background bg-foreground"
                    />
                  )}
                </div>
              );
            })}
          </div>

          {/* La mini-barre de l'objet sélectionné. */}
          {selectedObj && editing !== selectedObj.id && (
            <div
              className="absolute z-30 flex items-center gap-1 rounded-full hairline bg-background px-1.5 py-1 shadow-soft"
              style={{ left: screenPos(selectedObj).left, top: screenPos(selectedObj).top - 44 }}
            >
              {selectedObj.type === "proposition" && (
                <>
                  <button
                    type="button"
                    aria-label="Valider la proposition"
                    title="Valider la proposition"
                    className="grid h-7 w-7 place-items-center rounded-full text-emerald-700 hover:bg-emerald-50"
                    onClick={() => {
                      /* Valider marque l'accord humain ; la proposition
                         reste un objet de la toile — rien ne s'écrit dans
                         le World Model à ce stade. */
                      invalidate.mutate(() =>
                        updateObject(selectedObj.id, {
                          data: { ...selectedObj.data, propositionStatus: "valide" },
                        }),
                      );
                      toast(
                        "Proposition validée : elle reste sur la toile, à vous d'en tenir compte.",
                      );
                    }}
                  >
                    <Check className="h-3.5 w-3.5" strokeWidth={1.75} />
                  </button>
                  <button
                    type="button"
                    aria-label="Modifier la proposition"
                    title="Modifier la proposition"
                    className="grid h-7 w-7 place-items-center rounded-full hover:bg-muted"
                    onClick={() => startEdit(selectedObj)}
                  >
                    <Pencil className="h-3.5 w-3.5" strokeWidth={1.75} />
                  </button>
                  <button
                    type="button"
                    aria-label="Écarter la proposition"
                    title="Écarter la proposition"
                    className="grid h-7 w-7 place-items-center rounded-full text-muted-foreground hover:bg-muted"
                    onClick={() =>
                      invalidate.mutate(() =>
                        updateObject(selectedObj.id, {
                          data: { ...selectedObj.data, propositionStatus: "ecarte" },
                        }),
                      )
                    }
                  >
                    <X className="h-3.5 w-3.5" strokeWidth={1.75} />
                  </button>
                  <span aria-hidden className="h-4 w-px bg-hairline" />
                </>
              )}
              <button
                type="button"
                aria-label="Commenter"
                title="Commenter"
                className="grid h-7 w-7 place-items-center rounded-full hover:bg-muted"
                onClick={() => setCommentFor(selectedObj.id)}
              >
                <MessageCircle className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
              <button
                type="button"
                aria-label="Supprimer"
                title="Supprimer"
                className="grid h-7 w-7 place-items-center rounded-full text-rose-600 hover:bg-rose-50"
                onClick={() => {
                  invalidate.mutate(() => deleteObject(selectedObj.id));
                  setSelected(null);
                }}
              >
                <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>
          )}

          {/* Les commentaires d'un objet : la table comments du site. */}
          {commentFor && (
            <ObjectComments
              objectId={commentFor}
              userId={userId}
              myCardId={myCardId}
              onClose={() => setCommentFor(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function ObjectComments({
  objectId,
  userId,
  myCardId,
  onClose,
}: {
  objectId: string;
  userId: string | null;
  myCardId: string | null;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const target: LabObjectTarget = { type: "lab_object", id: objectId };
  const { data: comments = [] } = useQuery(commentsQuery(target));
  const [body, setBody] = useState("");

  const send = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("Connectez-vous pour commenter.");
      const text = body.trim();
      if (!text) return;
      await addComment({
        userId,
        cardId: myCardId,
        target,
        body: text,
      });
      setBody("");
    },
    onSuccess: () =>
      void qc.invalidateQueries({ queryKey: ["commentaires", "lab_object", objectId] }),
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div className="absolute top-3 right-3 z-40 w-72 rounded-2xl hairline bg-background p-3 shadow-lift">
      <div className="flex items-center justify-between">
        <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">Remarques</p>
        <button
          type="button"
          aria-label="Fermer"
          onClick={onClose}
          className="grid h-7 w-7 place-items-center rounded-full hover:bg-muted"
        >
          <X className="h-3.5 w-3.5" strokeWidth={1.75} />
        </button>
      </div>
      <ul className="mt-2 max-h-48 space-y-1.5 overflow-y-auto">
        {comments.length === 0 && (
          <li className="text-[12.5px] text-muted-foreground">Aucune remarque.</li>
        )}
        {comments.map((c) => (
          <li key={c.id} className="rounded-xl bg-muted px-2.5 py-2 text-[13px] leading-relaxed">
            {c.body}
          </li>
        ))}
      </ul>
      <div className="mt-2 flex gap-1.5">
        <input
          value={body}
          onChange={(e) => setBody(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send.mutate()}
          placeholder="Une remarque…"
          className="min-w-0 flex-1 rounded-xl border bg-background px-2.5 py-2 text-[13px] outline-none"
        />
        <button
          type="button"
          onClick={() => send.mutate()}
          disabled={send.isPending || !body.trim()}
          className="rounded-xl bg-foreground px-3 text-[12.5px] font-medium text-background disabled:opacity-40"
        >
          Dire
        </button>
      </div>
    </div>
  );
}
