/**
 * Le schéma central : une projection du projet compris — pas un modèle de
 * plus. Objectif au sommet, catégories en dessous, objets en feuilles.
 * Toucher une feuille recentre la toile sur l'objet réel.
 */
import { X } from "lucide-react";
import type { LabCategory } from "@/lib/aime/lab/labRecognition";
import type { LabBoard } from "@/lib/aime/lab/types";

const isObjectId = (id: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

export function LabSchema({
  board,
  universeLabel,
  categories,
  onFocusObject,
  onClose,
}: {
  board: LabBoard;
  universeLabel: string | null;
  categories: LabCategory[];
  onFocusObject: (id: string) => void;
  onClose: () => void;
}) {
  const n = Math.max(1, categories.length);

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto bg-[#faf9f6]/97 backdrop-blur-sm">
      <div className="mx-auto max-w-5xl px-5 py-8">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="eyebrow">Le schéma du projet</p>
            <h2 className="mt-1 text-[22px] font-semibold tracking-[-0.02em]">{board.title}</h2>
            <p className="mt-1 text-[13px] text-muted-foreground">
              Ce qu'AIME lit de votre toile{universeLabel ? ` — univers ${universeLabel}` : ""}.
              Touchez une feuille pour retrouver l'objet sur la toile.
            </p>
          </div>
          <button
            type="button"
            aria-label="Fermer le schéma"
            onClick={onClose}
            className="grid h-9 w-9 place-items-center rounded-full hairline bg-background"
          >
            <X className="h-4 w-4" strokeWidth={1.75} />
          </button>
        </div>

        {/* L'objectif, au sommet. */}
        <div className="mt-8 flex justify-center">
          <div className="rounded-2xl bg-foreground px-5 py-3 text-center text-background shadow-soft">
            <p className="text-[10.5px] tracking-[0.16em] uppercase opacity-70">Objectif</p>
            <p className="mt-0.5 text-[15px] font-medium">{board.title}</p>
          </div>
        </div>

        {/* Les connecteurs, puis les catégories. */}
        <svg className="mt-0 h-10 w-full" preserveAspectRatio="none" aria-hidden>
          {categories.map((c, i) => (
            <line
              key={c.key}
              x1="50%"
              y1="0"
              x2={`${((i + 0.5) / n) * 100}%`}
              y2="100%"
              stroke="rgba(0,0,0,0.18)"
              strokeWidth="1.5"
            />
          ))}
        </svg>

        <div
          className="grid gap-3"
          style={{ gridTemplateColumns: `repeat(${Math.min(n, 3)}, minmax(0, 1fr))` }}
        >
          {categories.map((c) => (
            <section key={c.key} className="rounded-2xl hairline bg-background p-3.5 shadow-soft">
              <h3 className="text-[11px] tracking-[0.14em] text-muted-foreground uppercase">
                {c.label}
              </h3>
              <ul className="mt-2 space-y-1">
                {c.items.slice(0, 10).map((item) => (
                  <li key={item.id}>
                    {isObjectId(item.id) ? (
                      <button
                        type="button"
                        onClick={() => onFocusObject(item.id)}
                        className="block w-full truncate rounded-lg px-2 py-1 text-left text-[13px] hover:bg-muted"
                        title={item.label}
                      >
                        {item.label}
                      </button>
                    ) : (
                      <span
                        className="block truncate px-2 py-1 text-[13px] text-muted-foreground"
                        title={item.label}
                      >
                        {item.label}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        {categories.length === 0 && (
          <p className="mt-10 text-center text-[13.5px] text-muted-foreground">
            La toile est encore vide : le schéma naîtra de vos premiers dépôts.
          </p>
        )}
      </div>
    </div>
  );
}
