/**
 * Chercher une personne AIME existante (une carte) pour la poser sur la
 * toile ou l'inviter dans l'équipe. La recherche du site, réutilisée.
 */
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { searchQuery } from "@/lib/aime/search";

export type LabCard = {
  id: string;
  name: string;
  headline: string | null;
  image_url: string | null;
  city: string | null;
};

export function LabCardSearch({
  onPick,
  placeholder,
}: {
  onPick: (card: LabCard) => void;
  placeholder: string;
}) {
  const [term, setTerm] = useState("");
  const [debounced, setDebounced] = useState("");
  const { data, isFetching } = useQuery({
    ...searchQuery(debounced),
    enabled: debounced.trim().length >= 2,
  });

  useEffect(() => {
    const t = window.setTimeout(() => setDebounced(term.trim()), 300);
    return () => window.clearTimeout(t);
  }, [term]);

  const cards = (data?.cards ?? []).slice(0, 6);

  return (
    <div className="w-64 rounded-2xl hairline bg-background p-2 shadow-soft">
      <label className="flex items-center gap-2 rounded-xl bg-muted px-2.5 py-2">
        <Search className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={1.75} />
        <input
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
        />
      </label>
      {isFetching && <p className="px-2 pt-2 text-[12px] text-muted-foreground">Recherche…</p>}
      {!isFetching && debounced.length >= 2 && cards.length === 0 && (
        <p className="px-2 pt-2 text-[12px] text-muted-foreground">Aucune carte trouvée.</p>
      )}
      <ul className="mt-1 space-y-0.5">
        {cards.map((c) => (
          <li key={c.id}>
            <button
              type="button"
              onClick={() => {
                onPick({
                  id: c.id,
                  name: c.name,
                  headline: c.headline,
                  image_url: c.image_url,
                  city: c.city,
                });
                setTerm("");
              }}
              className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left hover:bg-muted"
            >
              <span className="grid h-7 w-7 shrink-0 place-items-center overflow-hidden rounded-full bg-muted text-[11px] font-medium">
                {c.image_url ? (
                  <img src={c.image_url} alt="" className="h-full w-full object-cover" />
                ) : (
                  c.name.slice(0, 1).toUpperCase()
                )}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[13px] font-medium">{c.name}</span>
                <span className="block truncate text-[11.5px] text-muted-foreground">
                  {[c.headline, c.city].filter(Boolean).join(" · ")}
                </span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
