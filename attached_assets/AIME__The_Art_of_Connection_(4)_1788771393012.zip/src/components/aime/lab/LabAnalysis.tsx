/**
 * Ce qu'AIME comprend de la toile — et ce qu'elle propose.
 * Le pipeline est celui de la maison : bref → readStoryAI → catégories
 * proposées (validables) → plan ancré sur les capacités réelles → création
 * de l'espace via la persistance existante. AIME propose, l'humain valide.
 */
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { buildRoadmap, type Roadmap } from "@/lib/aime/roadmap.functions";
import { readStoryAI } from "@/lib/aime/world/storyRead.functions";
import { readStory, type StoryReading } from "@/lib/aime/world/parseStory";
import { projectFromJourney } from "@/lib/aime/world/journey";
import { persistValidatedProject } from "@/lib/aime/world/projectPersistence";
import { PROJECT_TYPES } from "@/lib/aime/world/blueprints";
import { UNIVERSE_TREE } from "@/lib/aime/universeTree";
import {
  briefFromObjects,
  categorize,
  LAB_CATEGORIES,
  type LabReading,
} from "@/lib/aime/lab/labRecognition";
import {
  updateBoard,
  updateObject,
  addObject,
  OBJECTS_QK,
  BOARD_QK,
} from "@/lib/aime/lab/labObjects";
import { LAB_AGENTS, agentDef } from "@/lib/aime/lab/agents";
import { runTemps } from "@/lib/aime/lab/agents/temps";
import { runCritique } from "@/lib/aime/lab/agents/critique";
import { runRelations } from "@/lib/aime/lab/agents/relations";
import { buildOverview } from "@/lib/aime/lab/agents/overview";
import type { LabMember } from "@/lib/aime/lab/types";
import type { WorldProject } from "@/lib/aime/world/types";
import type { LabBoard, LabObject } from "@/lib/aime/lab/types";

const isObjectId = (id: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

const SELECT_CLS =
  "mt-1 w-full rounded-xl hairline bg-background px-2.5 py-2 text-[13px] outline-none";

export function LabAnalysis({
  board,
  objects,
  userId,
  project,
  members,
  onRecognize,
}: {
  board: LabBoard;
  objects: LabObject[];
  userId: string | null;
  /** Le projet projeté (même moteur que l'accueil) : la matière de la critique. */
  project: WorldProject | null;
  /** L'équipe du board : la facette Relations lit qui est déjà là. */
  members: LabMember[];
  /** Remonte le bref et la lecture : la toile s'en sert (module timeline…). */
  onRecognize: (state: {
    brief: string;
    reading: LabReading | null;
    typeId: string | null;
  }) => void;
}) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const read = useServerFn(readStoryAI);
  const roadmap = useServerFn(buildRoadmap);

  const brief = useMemo(() => briefFromObjects(board, objects), [board, objects]);
  const [reading, setReading] = useState<LabReading | null>(null);
  const [typeId, setTypeId] = useState<string | null>(null);
  const [plan, setPlan] = useState<Roadmap | null>(null);
  const [planBusy, setPlanBusy] = useState(false);
  const [spaceBusy, setSpaceBusy] = useState(false);
  const [tempsBusy, setTempsBusy] = useState(false);
  const [critiqueBusy, setCritiqueBusy] = useState(false);
  const [relationsBusy, setRelationsBusy] = useState(false);

  const universe = UNIVERSE_TREE.find((u) => u.slug === board.universe_slug) ?? null;
  const types = useMemo(
    () => (universe ? PROJECT_TYPES.filter((t) => t.universeSlug === universe.slug) : []),
    [universe],
  );
  const categories = useMemo(() => categorize(board, objects, reading), [board, objects, reading]);
  const overview = useMemo(() => buildOverview(project), [project]);

  useEffect(() => {
    onRecognize({ brief, reading, typeId });
  }, [brief, reading, typeId, onRecognize]);

  /* AIME relit la toile en arrière-plan, comme elle relit le récit d'accueil. */
  useEffect(() => {
    const text = brief.trim();
    if (text.length < 12) {
      setReading(null);
      return;
    }
    let alive = true;
    const t = window.setTimeout(() => {
      read({ data: { recit: text, type: typeId } })
        .then((r) => {
          if (!alive) return;
          const base = readStory(text);
          const day = r.date ? new Date(`${r.date}T00:00:00`).getTime() : null;
          const merged: LabReading = {
            day: day && Number.isFinite(day) ? day : base.day,
            city: r.ville ?? base.city,
            venue: r.lieu ?? base.venue,
            guests: r.invites ?? base.guests,
            couple: r.couple ?? base.couple,
            booked: r.prestatairesTrouves.length
              ? r.prestatairesTrouves.map((role) => ({ role }))
              : base.booked,
            details: (r.details ?? {}) as Record<string, string>,
          };
          setReading(merged);
        })
        .catch(() => {
          if (alive) setReading(null);
        });
    }, 900);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [brief, typeId]);

  const toStoryReading = (): Partial<StoryReading> | null =>
    reading
      ? {
          day: reading.day,
          city: reading.city,
          venue: reading.venue,
          guests: reading.guests,
          couple: reading.couple,
          ceremonyH: null,
          booked: reading.booked,
          details: reading.details,
        }
      : null;

  const patchBoard = useMutation({
    mutationFn: async (patch: Parameters<typeof updateBoard>[1]) => updateBoard(board.id, patch),
    onSuccess: () => void qc.invalidateQueries({ queryKey: BOARD_QK(board.id) }),
    onError: (e: Error) => toast(e.message),
  });

  /* Valider l'organisation proposée : les étiquettes partent dans les objets. */
  const applyCategories = useMutation({
    mutationFn: async () => {
      const jobs: Promise<unknown>[] = [];
      for (const c of categories) {
        for (const item of c.items) {
          if (!isObjectId(item.id)) continue;
          const o = objects.find((x) => x.id === item.id);
          if (o && o.data.cat !== c.key)
            jobs.push(updateObject(o.id, { data: { ...o.data, cat: c.key } }));
        }
      }
      await Promise.all(jobs);
    },
    onSuccess: () => {
      toast("Organisation validée : chaque objet porte son étiquette.");
      void qc.invalidateQueries({ queryKey: OBJECTS_QK(board.id) });
    },
    onError: () => toast("L'organisation ne s'applique pas. Réessayez."),
  });

  /* Un poseur partagé : les propositions s'empilent sous celles déjà là. */
  const placeProposals = async (
    agent: string,
    proposals: { text: string; why: string; uses: string[]; target?: string }[],
    label: string,
  ) => {
    if (!userId) {
      toast("Connectez-vous d'abord.");
      return 0;
    }
    const propositions = objects.filter((o) => o.type === "proposition");
    const baseZ = objects.reduce((m, o) => Math.max(m, o.z), 0);
    const row = Math.floor(propositions.length / 2);
    let placed = 0;
    for (const [i, p] of proposals.entries()) {
      try {
        await addObject({
          boardId: board.id,
          userId,
          type: "proposition",
          x: 620 + ((propositions.length + i) % 2) * 310,
          y: 40 + (row + Math.floor(i / 2)) * 190,
          z: baseZ + 1 + i,
          data: {
            agent,
            text: p.text,
            why: p.why,
            uses: p.uses,
            ...(p.target ? { target: p.target } : {}),
          },
        });
        placed++;
      } catch {
        /* les suivantes continuent de se poser */
      }
    }
    void qc.invalidateQueries({ queryKey: OBJECTS_QK(board.id) });
    toast(
      placed
        ? `${label} a posé ${placed} proposition${placed > 1 ? "s" : ""} sur la toile.`
        : `${label} n'a rien de nouveau à proposer pour l'instant.`,
    );
    return placed;
  };

  /* La facette Temps : lecture déterministe, propositions posées sur la toile. */
  const askTemps = async () => {
    setTempsBusy(true);
    try {
      await placeProposals(
        "temps",
        runTemps({ brief, day: reading?.day ?? null, universeSlug: board.universe_slug, objects }),
        "Temps",
      );
    } finally {
      setTempsBusy(false);
    }
  };

  /* La facette Relations : qui est là, qui manque, qui mérite une invitation. */
  const askRelations = async () => {
    setRelationsBusy(true);
    try {
      await placeProposals(
        "relations",
        runRelations({
          brief,
          objects,
          members,
          universeSlug: board.universe_slug,
          domainSlug: board.domain_slug,
        }),
        "Relations",
      );
    } finally {
      setRelationsBusy(false);
    }
  };

  /* La facette Critique : elle relit le projet projeté et n'est jamais d'accord par défaut. */
  const askCritique = async () => {
    setCritiqueBusy(true);
    try {
      await placeProposals(
        "critique",
        runCritique({ brief, objects, project, universeSlug: board.universe_slug }),
        "Critique",
      );
    } finally {
      setCritiqueBusy(false);
    }
  };

  const proposePlan = async () => {
    if (brief.trim().length < 12) {
      toast("Posez encore un mot ou deux : AIME n'a pas assez de matière.");
      return;
    }
    setPlanBusy(true);
    try {
      const r = await roadmap({ data: { brief } });
      setPlan(r);
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setPlanBusy(false);
    }
  };

  /* La toile devient un espace AIME : la persistance de la maison. */
  const createSpace = async () => {
    if (!userId) {
      toast("Connectez-vous pour créer l'espace.");
      return;
    }
    setSpaceBusy(true);
    try {
      const project = projectFromJourney(
        { libre: brief, ...(typeId ? { type: typeId } : {}) },
        { ai: toStoryReading(), force: true },
      );
      if (!project) throw new Error("Il manque encore de la matière sur la toile.");
      const id = await persistValidatedProject(project, userId, brief);
      await updateBoard(board.id, { event_id: id });
      toast("Votre espace est prêt.");
      void navigate({ to: "/projets/$id", params: { id } });
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setSpaceBusy(false);
    }
  };

  const facts = [
    reading?.day &&
      new Date(reading.day).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
    reading?.city,
    reading?.venue,
    reading?.guests ? `${reading.guests} personnes` : null,
    reading?.couple,
  ].filter(Boolean) as string[];

  return (
    <section className="rounded-3xl hairline bg-card p-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4" strokeWidth={1.75} />
        <h3 className="text-[15px] font-semibold">Ce qu'AIME comprend</h3>
      </div>

      {brief.trim().length < 12 ? (
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
          Posez des mots, une note, une personne : AIME lira la toile dès qu'il y aura de la
          matière.
        </p>
      ) : (
        <>
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
            {reading
              ? "Voici ce que vous semblez vouloir réaliser."
              : "Lecture en cours, ou matière encore trop floue…"}
          </p>
          {facts.length > 0 && (
            <ul className="mt-2.5 flex flex-wrap gap-1.5">
              {facts.map((f) => (
                <li key={f} className="rounded-full bg-muted px-2.5 py-1 text-[12px]">
                  {f}
                </li>
              ))}
            </ul>
          )}
        </>
      )}

      <div className="mt-4 border-t border-hairline pt-3">
        <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">
          Est-ce que ça tient la route ?
        </p>
        <OverviewGroup
          title="Solide"
          items={overview.solide}
          empty="Aucun socle confirmé pour l'instant."
        />
        <OverviewGroup
          title="Fragile"
          items={overview.fragile}
          empty="Rien de fragile détecté sur les faits principaux."
        />
        <OverviewGroup
          title="Manquant"
          items={overview.manquant}
          empty="Aucun manque principal détecté."
        />
        <OverviewGroup
          title="Contradictoire"
          items={overview.contradictoire}
          empty="Aucune contradiction détectée."
        />
        <OverviewGroup
          title="Pour renforcer la confiance"
          items={overview.renforcer}
          empty="Rien à ajouter."
        />
      </div>

      {/* Les facettes d'AIME : on les appelle, elles posent leurs propositions sur la toile. */}
      <div className="mt-4 border-t border-hairline pt-3">
        <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">
          Les facettes
        </p>
        <ul className="mt-2 space-y-2.5">
          {(
            [
              { key: "temps", run: () => void askTemps(), busy: tempsBusy },
              { key: "critique", run: () => void askCritique(), busy: critiqueBusy },
              { key: "relations", run: () => void askRelations(), busy: relationsBusy },
            ] as const
          ).map((f) => {
            const def = agentDef(f.key);
            if (!def) return null;
            return (
              <li key={f.key} className="flex items-start gap-2">
                <span aria-hidden className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${def.dot}`} />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium">{def.label}</p>
                  <p className="text-[11.5px] leading-relaxed text-muted-foreground">{def.facet}</p>
                </div>
                <button
                  type="button"
                  onClick={f.run}
                  disabled={f.busy}
                  className="mt-0.5 shrink-0 rounded-full hairline bg-background px-3 py-1.5 text-[12px] font-medium hover:bg-muted disabled:opacity-50"
                >
                  {f.busy ? "Lecture…" : "Demander"}
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Le projet reconnu : univers, domaine, type — les listes de la maison. */}
      <div className="mt-4 space-y-2.5">
        <label className="block text-[12px] text-muted-foreground">
          Univers
          <select
            value={board.universe_slug ?? ""}
            onChange={(e) =>
              patchBoard.mutate({ universe_slug: e.target.value || null, domain_slug: null })
            }
            className={SELECT_CLS}
          >
            <option value="">À découvrir</option>
            {UNIVERSE_TREE.map((u) => (
              <option key={u.slug} value={u.slug}>
                {u.label}
              </option>
            ))}
          </select>
        </label>
        {universe && universe.subs.length > 0 && (
          <label className="block text-[12px] text-muted-foreground">
            Domaine
            <select
              value={board.domain_slug ?? ""}
              onChange={(e) => patchBoard.mutate({ domain_slug: e.target.value || null })}
              className={SELECT_CLS}
            >
              <option value="">Préciser plus tard</option>
              {universe.subs.map((s) => (
                <option key={s.slug} value={s.slug}>
                  {s.label}
                </option>
              ))}
            </select>
          </label>
        )}
        {types.length > 0 && (
          <label className="block text-[12px] text-muted-foreground">
            Type de projet
            <select
              value={typeId ?? ""}
              onChange={(e) => setTypeId(e.target.value || null)}
              className={SELECT_CLS}
            >
              <option value="">Laisser AIME deviner</option>
              {types.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>
        )}
      </div>

      {/* L'organisation proposée : AIME propose, l'équipe valide. */}
      {categories.length > 0 && (
        <div className="mt-4 border-t border-hairline pt-3">
          <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">
            Organisation proposée
          </p>
          <ul className="mt-2 space-y-1">
            {LAB_CATEGORIES.filter((c) => categories.some((x) => x.key === c.key)).map((c) => {
              const found = categories.find((x) => x.key === c.key)!;
              return (
                <li key={c.key} className="text-[12.5px] leading-relaxed">
                  <span className="font-medium">{c.label} :</span>{" "}
                  <span className="text-muted-foreground">
                    {found.items
                      .slice(0, 6)
                      .map((i) => i.label)
                      .join(" · ")}
                    {found.items.length > 6 ? "…" : ""}
                  </span>
                </li>
              );
            })}
          </ul>
          <button
            type="button"
            onClick={() => applyCategories.mutate()}
            disabled={applyCategories.isPending}
            className="mt-2.5 rounded-full hairline bg-background px-3 py-1.5 text-[12.5px] font-medium hover:bg-muted disabled:opacity-50"
          >
            Valider cette organisation
          </button>
        </div>
      )}

      {/* Le plan : ancré sur les capacités réelles d'AIME. */}
      <div className="mt-4 border-t border-hairline pt-3">
        {plan ? (
          <div>
            <p className="text-[12px] tracking-[0.14em] text-muted-foreground uppercase">
              Plan proposé
            </p>
            <p className="mt-2 text-[13.5px] font-medium">{plan.zero.objective}</p>
            <ol className="mt-2 space-y-1.5">
              {plan.steps.map((s, i) => (
                <li key={`${s.capability_id}-${i}`} className="text-[12.5px] leading-relaxed">
                  <span className="font-medium">
                    {i + 1}. {s.title}
                  </span>
                  <span className="block text-muted-foreground">{s.why}</span>
                </li>
              ))}
            </ol>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => void proposePlan()}
            disabled={planBusy}
            className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-3 py-1.5 text-[12.5px] font-medium hover:bg-muted disabled:opacity-50"
          >
            {planBusy ? "AIME réfléchit…" : "Proposer un plan"}
          </button>
        )}
      </div>

      {/* La toile devient un espace de travail AIME. */}
      <button
        type="button"
        onClick={() => void createSpace()}
        disabled={spaceBusy || brief.trim().length < 12 || !userId}
        className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-foreground px-4 text-[13.5px] font-medium text-background transition hover:opacity-90 disabled:opacity-40"
      >
        {spaceBusy ? "Création de l'espace…" : "Créer l'espace AIME"}
        <ArrowRight className="h-4 w-4" strokeWidth={1.75} aria-hidden />
      </button>
    </section>
  );
}

function OverviewGroup({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div className="mt-2.5">
      <p className="text-[12px] font-medium">{title}</p>
      {items.length > 0 ? (
        <ul className="mt-1 space-y-1">
          {items.slice(0, 4).map((item) => (
            <li
              key={`${title}-${item}`}
              className="text-[12px] leading-relaxed text-muted-foreground"
            >
              • {item}
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-1 text-[12px] text-muted-foreground">{empty}</p>
      )}
    </div>
  );
}
