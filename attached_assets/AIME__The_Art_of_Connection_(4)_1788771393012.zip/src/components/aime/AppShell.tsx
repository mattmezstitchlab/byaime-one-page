import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { AudioLines, LayoutGrid, Music, Radio, Search, Sparkles, Tv } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

import { eventsQuery, myCardQuery, receivedAimesQuery, threadsQuery } from "@/lib/aime/queries";
import { useRadio } from "@/components/aime/RadioProvider";
import { onRadioSheet } from "@/components/aime/radioSheet";
import { RadioBar } from "@/components/aime/RadioBar";
import { RadioStage } from "@/components/aime/RadioStage";
import { useTv } from "@/components/aime/tv/TvProvider";
import { TvCard } from "@/components/aime/tv/TvCard";
import { TV_CHANNELS } from "@/lib/aime/tv/channels";
import { AiSheet } from "@/components/aime/panels/AiSheet";

import { GlobalDock } from "@/components/aime/GlobalDock";
import { BackButton } from "@/components/aime/BackButton";
import { FeedbackSheet } from "@/components/aime/FeedbackSheet";
import { RepairBadge } from "@/components/aime/RepairBadge";
import { firstTime, recordEvent } from "@/lib/aime/telemetry";
import { LogoMenu } from "@/components/aime/LogoMenu";
import { DockPresenceProvider } from "@/components/aime/dockPresence";
import { SiteFooter } from "@/components/aime/SiteFooter";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { openDocuments, openMessages } from "@/components/aime/messagesSheet";
import { documentsQuery } from "@/lib/bureau/queries";
import { buildAlerts, readSeenAt } from "@/lib/bureau/alerts";
import { MessagesSheet } from "@/components/aime/MessagesSheet";
import { SettingsSheet } from "@/components/aime/SettingsSheet";
import { SpaceSheet } from "@/components/aime/space/SpaceSheet";
import { EditPageSheet } from "@/components/aime/page/EditPageSheet";
import { openSpace } from "@/components/aime/spaceSheet";
import { notify } from "@/lib/aime/notify";
import { notificationsQuery, unreadCount } from "@/lib/aime/notifications";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { recentSearches } from "@/lib/aime/search";

export function AppShell(props: {
  children: ReactNode;
  background?: string;
  chrome?: "full" | "console" | "embed";
  showBackButton?: boolean;
}) {
  return (
    <DockPresenceProvider>
      <ShellBody {...props} />
    </DockPresenceProvider>
  );
}

function ShellBody({
  children,
  background,
  chrome = "full",
  showBackButton = true,
}: {
  children: ReactNode;
  /** Visuel qui tapisse toute la page, footer compris. */
  background?: string;
  /** « console » : le pied de page s'efface (tableau de bord). « embed » : aperçu nu. */
  chrome?: "full" | "console" | "embed";

  /** Certaines expériences replacent le retour dans leur propre barre de commandes. */
  showBackButton?: boolean;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { user, userId } = useAuth();

  // Dans l'aperçu intégré (la démo dans le téléphone), la barre de défilement
  // reste sombre comme le reste du site.
  useEffect(() => {
    if (chrome !== "embed") return;
    document.documentElement.classList.add("scrollbar-dark");
    return () => document.documentElement.classList.remove("scrollbar-dark");
  }, [chrome]);

  const tv = useTv();
  const { on, setMode: setRadioMode, setProject: setRadioProject } = useRadio();
  const [radioOpen, setRadioOpen] = useState(false);
  // La capsule s'ouvre d'elle-même quand le son démarre ailleurs.
  useEffect(() => {
    if (on) setRadioOpen(true);
  }, [on]);
  useEffect(() => onRadioSheet(() => setRadioOpen((v) => !v)), []);
  const { t } = useI18n();
  const { data: myCard } = useQuery(myCardQuery(userId));
  const { data: myProjects = [] } = useQuery({ ...eventsQuery(userId), enabled: !!userId });
  const { data: received = [] } = useQuery(receivedAimesQuery(myCard?.id));
  const { data: notifs = [] } = useQuery({
    ...notificationsQuery(userId),
    refetchInterval: 60_000,
  });
  const unreadNotifs = unreadCount(notifs);
  const unread = received.filter((a) => a.status === "nouveau").length + unreadNotifs;
  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const unreadThreads = threads.filter((thread) =>
    (thread.messages ?? []).some((m) => m.sender_id !== userId && !m.read_at),
  ).length;
  const { data: myDocs = [] } = useQuery(documentsQuery(userId));
  // localStorage n'existe qu'après hydratation : sinon le serveur et le
  // navigateur n'affichent pas la même pastille.
  const [seenAt, setSeenAt] = useState<number | null>(null);
  useEffect(() => setSeenAt(readSeenAt()), []);
  const docAlerts = seenAt === null ? 0 : buildAlerts(myDocs, seenAt).size;
  const [recent, setRecent] = useState<string[]>([]);
  useEffect(() => setRecent(recentSearches()), []);

  // Alerte du navigateur dès qu'un message, un document ou une nouveauté arrive.
  const seenCounts = useRef<{ threads: number; docs: number; notifs: number } | null>(null);
  useEffect(() => {
    const prev = seenCounts.current;
    seenCounts.current = { threads: unreadThreads, docs: docAlerts, notifs: unreadNotifs };
    if (!prev) return;
    if (unreadThreads > prev.threads) {
      notify("Nouveau message", "Une conversation vous attend sur AIME.");
    }
    if (docAlerts > prev.docs) {
      notify("Nouveau document", "Un document demande votre attention.");
    }
    if (unreadNotifs > prev.notifs) {
      notify("Nouveauté sur AIME", "Quelqu'un a réagi ou écrit chez vous.");
    }
  }, [unreadThreads, docAlerts, unreadNotifs]);

  const label = (key: string, fallback: string) => {
    const value = t(key);
    return value === key ? fallback : value;
  };
  const spaceLabel = label("nav.space", "Mon espace");
  const personalUnread = unread + unreadThreads + docAlerts;

  // Journal de bêta : une ligne par page visitée, et un repère à la toute première fois.
  useEffect(() => {
    void recordEvent({
      kind: firstTime(`page:${pathname}`) ? "premiere" : "visite",
      label: pathname,
      route: pathname,
      userId,
    });
  }, [pathname, userId]);

  return (
    <div
      className="flex min-h-screen flex-col bg-background bg-cover bg-fixed bg-center"
      style={background ? { backgroundImage: `url(${background})` } : undefined}
    >
      {/* Un seul header : le logo (menu système), deux portes, puis moi. */}
      {chrome !== "embed" && (
        <header className="sticky top-0 z-[45] border-b border-hairline bg-background">
          <div className="mx-auto grid h-[64px] max-w-6xl grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 px-3 md:h-[68px] md:px-5">
            {chrome === "full" && showBackButton ? (
              <BackButton inline />
            ) : (
              <span className="hidden" />
            )}
            <div className="min-w-0">
              {/* Quand la radio est ouverte, sa capsule prend le centre de l'en-tête :
                plus rien ne vient se poser au-dessus du contenu de la page. */}
              {radioOpen ? <RadioBar open onClose={() => setRadioOpen(false)} /> : <LogoMenu />}
            </div>

            <div className="flex items-center justify-end gap-0.5 md:gap-1.5">
              <div className="hidden md:block">
                <RepairBadge />
              </div>

              {/* Le bouton radio choisit d'abord la station, puis ouvre la capsule. */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant={pathname.startsWith("/recherche") ? "secondary" : "ghost"}
                    aria-label="Rechercher"
                    title="Rechercher"
                    className="h-11 gap-2 rounded-full px-3"
                  >
                    <Search className="h-[18px] w-[18px]" strokeWidth={1.75} />
                    <span className="hidden text-[13px] md:inline">Rechercher</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="min-w-64 max-w-[86vw]">
                  <DropdownMenuLabel>Recherche</DropdownMenuLabel>
                  {recent.length === 0 ? (
                    <DropdownMenuItem asChild>
                      <Link to="/recherche">
                        <Search /> Ouvrir la recherche
                      </Link>
                    </DropdownMenuItem>
                  ) : (
                    <>
                      {recent.slice(0, 6).map((q) => (
                        <DropdownMenuItem
                          key={q}
                          onSelect={() => void navigate({ to: "/recherche", search: { q } })}
                        >
                          <Search />
                          <span className="min-w-0 flex-1 truncate">{q}</span>
                        </DropdownMenuItem>
                      ))}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link to="/recherche">
                          <Search /> Rechercher plus loin
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant={on || radioOpen ? "secondary" : "ghost"}
                    size="icon"
                    aria-label="Radio AIME"
                    title="Radio AIME"
                    className="h-11 w-11"
                  >
                    <Radio className="h-[18px] w-[18px]" strokeWidth={1.75} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="min-w-60 max-w-[86vw]">
                  <DropdownMenuLabel>Choisir la station</DropdownMenuLabel>
                  <DropdownMenuItem
                    onSelect={() => {
                      setRadioMode("musique");
                      setRadioOpen(true);
                    }}
                  >
                    <Music /> Musique
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      setRadioMode("fil");
                      setRadioOpen(true);
                    }}
                  >
                    <AudioLines /> Le fil raconté
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>Un projet raconté</DropdownMenuLabel>
                  {myProjects.length === 0 ? (
                    <DropdownMenuItem disabled>Aucun projet pour l'instant</DropdownMenuItem>
                  ) : (
                    myProjects.slice(0, 6).map((p) => (
                      <DropdownMenuItem
                        key={p.id}
                        onSelect={() => {
                          setRadioProject(p.id);
                          setRadioOpen(true);
                        }}
                      >
                        <Sparkles />
                        <span className="min-w-0 flex-1 truncate">{p.title}</span>
                      </DropdownMenuItem>
                    ))
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => setRadioOpen((v) => !v)}>
                    <Radio /> {radioOpen ? "Masquer la capsule" : "Afficher la capsule"}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <RadioStage />

              {/* AIME TV : trois chaînes, une petite fenêtre à côté de la radio. */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant={tv.on ? "secondary" : "ghost"}
                    size="icon"
                    aria-label="AIME TV"
                    title="AIME TV"
                    className="h-11 w-11"
                  >
                    <Tv className="h-[18px] w-[18px]" strokeWidth={1.75} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="min-w-64 max-w-[86vw]">
                  <DropdownMenuLabel>Choisir la chaîne</DropdownMenuLabel>
                  {myProjects.length === 0 ? (
                    <DropdownMenuItem disabled>Aucun projet à regarder</DropdownMenuItem>
                  ) : (
                    TV_CHANNELS.map((c) => (
                      <DropdownMenuItem
                        key={c.key}
                        onSelect={() => tv.open(c.key, tv.projectId ?? myProjects[0]!.id)}
                      >
                        <Tv />
                        <span className="min-w-0 flex-1 truncate">{c.label}</span>
                      </DropdownMenuItem>
                    ))
                  )}
                  {myProjects.length > 1 && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel>Le projet à l'antenne</DropdownMenuLabel>
                      {myProjects.slice(0, 6).map((p) => (
                        <DropdownMenuItem
                          key={p.id}
                          onSelect={() => (tv.on ? tv.setProject(p.id) : tv.open("jour-j", p.id))}
                        >
                          <Sparkles />
                          <span className="min-w-0 flex-1 truncate">{p.title}</span>
                        </DropdownMenuItem>
                      ))}
                    </>
                  )}
                  {tv.on && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onSelect={tv.close}>
                        <Tv /> Éteindre la télé
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
              <TvCard />

              {/* Une seule porte vers l'espace personnel : Mon espace. */}
              {user ? (
                <Button
                  type="button"
                  variant="ghost"
                  onClick={openSpace}
                  aria-label={`Ouvrir ${spaceLabel}${personalUnread > 0 ? `, ${personalUnread} nouveautés` : ""}`}
                  title={`Ouvrir ${spaceLabel}`}
                  className="relative inline-flex min-h-11 items-center gap-2 rounded-full px-2.5 text-left sm:px-3"
                >
                  <LayoutGrid className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
                  <span className="text-[12px] font-medium leading-none sm:text-[13px]">
                    {spaceLabel}
                  </span>
                  {personalUnread > 0 && (
                    <span className="absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-medium text-white">
                      {personalUnread > 9 ? "9+" : personalUnread}
                    </span>
                  )}
                </Button>
              ) : (
                <Link
                  to="/auth"
                  className="inline-flex min-h-11 items-center rounded-full bg-foreground px-3.5 text-[12px] font-medium uppercase tracking-[0.08em] text-background transition-opacity hover:opacity-85"
                >
                  Connexion
                </Link>
              )}

              {/* Les portes du réseau vivent maintenant dans la barre du bas. */}
            </div>
          </div>
        </header>
      )}

      <main className="flex-1 pb-24">{children}</main>

      {chrome === "full" && <SiteFooter />}

      <MessagesSheet />
      <SettingsSheet />
      <SpaceSheet />
      <EditPageSheet />
      <AiSheet />

      {chrome !== "embed" && (
        <GlobalDock
          myCardId={myCard?.id ?? null}
          unreadThreads={unreadThreads}
          docAlerts={docAlerts}
          onDocuments={() => openDocuments()}
          onMessages={() => openMessages()}
        />
      )}

      <FeedbackSheet />
    </div>
  );
}
