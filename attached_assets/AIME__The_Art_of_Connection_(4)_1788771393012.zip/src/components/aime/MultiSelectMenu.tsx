import { Check, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

export type MultiOption = {
  value: string;
  label: string;
  icon?: React.ComponentType<{ className?: string; strokeWidth?: number }>;
};

type Props = {
  label: string;
  placeholder?: string;
  options: MultiOption[];
  selected: string[];
  onToggle: (value: string) => void;
  className?: string;
};

/** Menu déroulant à sélection multiple, style Apple : compact, coché, discret. */
export function MultiSelectMenu({
  label,
  placeholder = "Choisir…",
  options,
  selected,
  onToggle,
  className,
}: Props) {
  const chosen = options.filter((o) => selected.includes(o.value));
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={label}
          className={cn(
            "flex w-full items-center justify-between gap-3 rounded-2xl hairline bg-card px-4 py-3 text-left text-[15px] shadow-soft outline-none focus:ring-2 focus:ring-ring/40",
            className,
          )}
        >
          <span className={cn("truncate", chosen.length === 0 && "text-muted-foreground")}>
            {chosen.length === 0
              ? placeholder
              : chosen.length <= 2
                ? chosen.map((c) => c.label).join(", ")
                : `${chosen.length} sélectionnés`}
          </span>
          <span className="flex shrink-0 items-center gap-2">
            {chosen.length > 0 && (
              <span className="rounded-full bg-primary px-2 py-0.5 text-[11px] font-medium text-primary-foreground tabular-nums">
                {chosen.length}
              </span>
            )}
            <ChevronDown className="h-4 w-4 text-muted-foreground" strokeWidth={1.75} />
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="start"
        className="z-[60] max-h-[320px] w-[--radix-dropdown-menu-trigger-width] min-w-[240px] overflow-y-auto rounded-3xl p-1.5"
      >
        {options.map((o) => {
          const on = selected.includes(o.value);
          const Icon = o.icon;
          return (
            <button
              key={o.value}
              type="button"
              role="menuitemcheckbox"
              aria-checked={on}
              onClick={(e) => {
                e.preventDefault();
                onToggle(o.value);
              }}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-2xl px-3 py-2.5 text-left text-[14px] transition-colors hover:bg-secondary",
                on && "font-medium",
              )}
            >
              <span
                aria-hidden
                className={cn(
                  "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[6px] border transition-colors",
                  on ? "border-primary bg-primary text-primary-foreground" : "border-hairline",
                )}
              >
                {on && <Check className="h-3 w-3" strokeWidth={3} />}
              </span>
              {Icon && (
                <Icon className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.75} />
              )}
              <span className="flex-1 truncate">{o.label}</span>
            </button>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
