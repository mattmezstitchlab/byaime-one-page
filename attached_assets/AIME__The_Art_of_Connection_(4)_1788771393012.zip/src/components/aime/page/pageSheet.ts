/**
 * Canal unique d'ouverture de l'édition de ma page publique.
 * L'édition se fait sur la page elle-même, dans un panneau latéral.
 */
const EVENT = "aime:page-sheet";

export function openEditPage() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onEditPage(handler: () => void) {
  const listener = () => handler();
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
