import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { onEditPage } from "@/components/aime/page/pageSheet";
import { PageSetup } from "@/components/aime/PageSetup";
import { MediaGrid } from "@/components/aime/media/MediaGrid";
import {
  ClearVisualButton,
  VisualLibraryButton,
  VisualLibraryDialog,
} from "@/components/aime/media/VisualLibraryDialog";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { myCardQuery } from "@/lib/aime/queries";
import type { Card } from "@/lib/aime/types";

/**
 * L'édition de ma page publique : un panneau, ouvert depuis la page elle-même.
 * Chaque champ s'enregistre en direct ; la page derrière se met à jour.
 */
export function EditPageSheet() {
  const [open, setOpen] = useState(false);
  const { userId } = useAuth();
  const { data: myCard } = useQuery(myCardQuery(userId));

  useEffect(() => onEditPage(() => setOpen(true)), []);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-xl">
        <SheetHeader className="border-b border-hairline px-5 py-4 text-left">
          <SheetTitle className="text-[20px] font-semibold">Modifier ma page</SheetTitle>
        </SheetHeader>

        {open && (
          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
            {myCard && userId ? (
              <>
                <PageSetup card={myCard} userId={userId} />
                <RichFields card={myCard} />
              </>
            ) : (
              <p className="text-[14px] text-muted-foreground">
                Votre page n'existe pas encore. Racontez votre projet depuis l'accueil : elle se
                crée avec lui.
              </p>
            )}
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

/** Ce qui remplit la page sous le visuel : présentation, savoir-faire, galerie, tarifs. */
function RichFields({ card }: { card: Card }) {
  const qc = useQueryClient();
  const [bio, setBio] = useState(card.bio ?? "");
  const [availability, setAvailability] = useState(card.availability ?? "");
  const [video, setVideo] = useState(card.video_url ?? "");
  const [skills, setSkills] = useState(card.skills ?? []);
  const [experiences, setExperiences] = useState(card.experiences ?? []);
  const [visualLibraryOpen, setVisualLibraryOpen] = useState(false);

  useEffect(() => {
    setBio(card.bio ?? "");
    setAvailability(card.availability ?? "");
    setVideo(card.video_url ?? "");
    setSkills(card.skills ?? []);
    setExperiences(card.experiences ?? []);
  }, [card.id, card.bio, card.availability, card.video_url, card.skills, card.experiences]);

  const save = useMutation({
    mutationFn: async (patch: Partial<Card>) => {
      const { error } = await supabase
        .from("cards")
        .update(patch as never)
        .eq("id", card.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["card", card.id] });
      qc.invalidateQueries({ queryKey: ["my-card"] });
      qc.invalidateQueries({ queryKey: ["cards"] });
    },
    onError: (e) => toast((e as Error).message),
  });

  const field = "w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] outline-none";

  return (
    <div className="mt-8 space-y-6 border-t border-hairline pt-6">
      <Block label="Présentation" hint="Ce que l'on lit sous votre visuel.">
        <textarea
          value={bio}
          rows={5}
          onChange={(e) => setBio(e.target.value)}
          onBlur={() =>
            bio !== (card.bio ?? "") && save.mutate({ bio: bio.trim() } as Partial<Card>)
          }
          placeholder="Racontez ce que vous faites, comment, et pour qui."
          className={field}
        />
      </Block>

      <Block label="Savoir-faire" hint="Un mot par ligne, ils deviennent des étiquettes.">
        <TagEditor
          values={skills}
          placeholder="Ajouter un savoir-faire"
          onChange={(next) => {
            setSkills(next);
            save.mutate({ skills: next } as Partial<Card>);
          }}
        />
      </Block>

      <Block label="Expériences" hint="Vos réalisations marquantes.">
        <TagEditor
          values={experiences}
          placeholder="Ajouter une expérience"
          onChange={(next) => {
            setExperiences(next);
            save.mutate({ experiences: next } as Partial<Card>);
          }}
        />
      </Block>

      <Block label="Médias" hint="Photos, vidéos, YouTube, audio et liens de votre page.">
        <div className="mb-2 flex flex-wrap gap-2">
          <VisualLibraryButton onClick={() => setVisualLibraryOpen(true)} />
          {(card.image_url || card.visual_key) && (
            <ClearVisualButton
              onClick={() =>
                save.mutate({ image_url: null, visual_key: "resource" } as Partial<Card>)
              }
            />
          )}
        </div>
        <MediaGrid cardId={card.id} canEdit userId={card.owner_id ?? null} />
        <input
          value={video}
          onChange={(e) => setVideo(e.target.value)}
          onBlur={() =>
            video !== (card.video_url ?? "") &&
            save.mutate({ video_url: video.trim() || null } as Partial<Card>)
          }
          placeholder="Vidéo de présentation (lien)"
          className={`${field} mt-2`}
        />
        <VisualLibraryDialog
          open={visualLibraryOpen}
          onOpenChange={setVisualLibraryOpen}
          selectedUniverse={card.universes[0] ?? null}
          selectedDomain={card.category_slug}
          onPick={({ key, url }) =>
            save.mutate(
              key
                ? ({ image_url: null, visual_key: key } as Partial<Card>)
                : ({ image_url: url } as Partial<Card>),
            )
          }
        />
      </Block>

      <Block label="Disponibilités" hint="En une phrase : quand vous êtes joignable.">
        <input
          value={availability}
          onChange={(e) => setAvailability(e.target.value)}
          onBlur={() =>
            availability !== (card.availability ?? "") &&
            save.mutate({ availability: availability.trim() || null } as Partial<Card>)
          }
          placeholder="Ex. week-ends et soirées, toute l'année"
          className={field}
        />
      </Block>

      <Block label="Tarifs" hint="Une fourchette indicative, en euros.">
        <div className="grid grid-cols-2 gap-3">
          <input
            type="number"
            defaultValue={card.budget_min ?? ""}
            onBlur={(e) =>
              save.mutate({
                budget_min: e.target.value ? Number(e.target.value) : null,
              } as Partial<Card>)
            }
            placeholder="À partir de"
            className={field}
          />
          <input
            type="number"
            defaultValue={card.budget_max ?? ""}
            onBlur={(e) =>
              save.mutate({
                budget_max: e.target.value ? Number(e.target.value) : null,
              } as Partial<Card>)
            }
            placeholder="Jusqu'à"
            className={field}
          />
        </div>
      </Block>

      <label className="flex items-center justify-between gap-4 rounded-2xl hairline bg-card px-4 py-3 text-[14.5px]">
        Page visible dans le Réseau
        <input
          type="checkbox"
          checked={card.published}
          onChange={(e) => save.mutate({ published: e.target.checked } as Partial<Card>)}
          className="h-4 w-4"
        />
      </label>
    </div>
  );
}

function Block({
  label,
  hint,
  children,
}: {
  label: string;
  hint: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <h3 className="text-[14px] font-medium">{label}</h3>
      <p className="mt-0.5 text-[12.5px] text-muted-foreground">{hint}</p>
      <div className="mt-2.5">{children}</div>
    </section>
  );
}

function TagEditor({
  values,
  placeholder,
  onChange,
}: {
  values: string[];
  placeholder: string;
  onChange: (next: string[]) => void;
}) {
  const [draft, setDraft] = useState("");
  const add = () => {
    const value = draft.trim();
    if (!value || values.includes(value)) return setDraft("");
    onChange([...values, value]);
    setDraft("");
  };
  return (
    <div>
      {values.length > 0 && (
        <ul className="mb-2 flex flex-wrap gap-1.5">
          {values.map((v) => (
            <li
              key={v}
              className="flex items-center gap-1.5 rounded-full hairline bg-background px-3 py-1.5 text-[13px]"
            >
              <span className="max-w-[220px] truncate">{v}</span>
              <button
                type="button"
                aria-label={`Retirer ${v}`}
                onClick={() => onChange(values.filter((x) => x !== v))}
              >
                <X className="h-3 w-3" strokeWidth={2} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={placeholder}
          className="w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none"
        />
        <button
          type="button"
          onClick={add}
          className="shrink-0 rounded-full hairline bg-background px-4 text-[13px]"
        >
          Ajouter
        </button>
      </div>
    </div>
  );
}
