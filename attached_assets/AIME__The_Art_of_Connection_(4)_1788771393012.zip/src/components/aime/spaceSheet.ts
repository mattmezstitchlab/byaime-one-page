/**
 * Canal unique d'ouverture de « Mon espace ».
 * Mon espace n'est plus une page mais un panneau : une seule porte, depuis l'en-tête.
 */
const EVENT = "aime:space-sheet";

export function openSpace() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onSpace(handler: () => void) {
  const listener = () => handler();
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
