import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { universeIcon } from "@/lib/aime/icons";
import { cardVisual } from "@/lib/aime/visuals";
import type { Card } from "@/lib/aime/types";
import { cn } from "@/lib/utils";

/**
 * Les savoir-faire deviennent cliquables : on reste sur place et l'on voit
 * ce que le tag relie — les autres univers de la personne, les cartes proches.
 */
export function CardSkills({
  card,
  ownerCards,
  nearby,
  universeLabel,
  onPickUniverse,
  onQuote,
}: {
  card: Card;
  /** Les autres cartes du même auteur (ses autres univers). */
  ownerCards: Card[];
  /** Cartes proches, pour montrer qui partage ce savoir-faire. */
  nearby: Card[];
  universeLabel: (slug: string) => string;
  onPickUniverse: (slug: string) => void;
  onQuote: (skill: string) => void;
}) {
  const [selected, setSelected] = useState<string | null>(null);

  if (card.skills.length === 0) {
    return (
      <p className="text-[15px] text-muted-foreground">
        Aucun savoir-faire renseigné sur cette carte pour le moment.
      </p>
    );
  }

  const matchesSkill = (c: Card, skill: string) =>
    c.skills.some((s) => s.toLowerCase() === skill.toLowerCase()) ||
    c.tags.some((t) => t.toLowerCase() === skill.toLowerCase());

  const sameSkillUniverses = selected
    ? [...new Set(ownerCards.filter((c) => matchesSkill(c, selected)).flatMap((c) => c.universes))]
    : [];
  const sharing = selected ? nearby.filter((c) => matchesSkill(c, selected)).slice(0, 6) : [];
  const context = selected
    ? (card.experiences.find((e) => e.toLowerCase().includes(selected.toLowerCase())) ??
      card.bio?.split(/(?<=\.)\s+/).find((s) => s.toLowerCase().includes(selected.toLowerCase())) ??
      null)
    : null;

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {card.skills.map((s) => {
          const on = selected === s;
          return (
            <button
              key={s}
              type="button"
              aria-pressed={on}
              onClick={() => setSelected(on ? null : s)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-[13.5px] transition-colors",
                on
                  ? "bg-foreground text-background"
                  : "bg-secondary text-foreground hover:bg-foreground/10",
              )}
            >
              {s}
            </button>
          );
        })}
      </div>

      {selected && (
        <div className="mt-5 animate-fade-in rounded-3xl hairline bg-card p-5 shadow-soft">
          <p className="text-[15px] leading-relaxed">
            {context ?? `${card.name} propose « ${selected} » dans le cadre de ses prestations.`}
          </p>

          {sameSkillUniverses.length > 0 && (
            <div className="mt-4">
              <p className="eyebrow mb-2">Aussi présent dans</p>
              <div className="flex flex-wrap gap-2">
                {sameSkillUniverses.map((u) => {
                  const Icon = universeIcon(u);
                  return (
                    <button
                      key={u}
                      type="button"
                      onClick={() => onPickUniverse(u)}
                      className="inline-flex items-center gap-2 rounded-full hairline bg-background px-3 py-1.5 text-[13px] transition-colors hover:bg-secondary"
                    >
                      <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                      {universeLabel(u)}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {sharing.length > 0 && (
            <div className="mt-4">
              <p className="eyebrow mb-2">Qui partage ce savoir-faire</p>
              <div className="flex flex-wrap gap-2">
                {sharing.map((c) => (
                  <Link
                    key={c.id}
                    to="/carte/$id"
                    params={{ id: c.id }}
                    className="inline-flex items-center gap-2 rounded-full hairline bg-background py-1 pr-3 pl-1 text-[13px] transition-colors hover:bg-secondary"
                  >
                    <img src={cardVisual(c)} alt="" className="h-6 w-6 rounded-full object-cover" />
                    {c.name}
                  </Link>
                ))}
              </div>
            </div>
          )}

          <button
            type="button"
            onClick={() => onQuote(selected)}
            className="mt-5 rounded-full bg-primary px-4 py-2 text-[13px] font-medium text-primary-foreground"
          >
            Demander un devis sur « {selected} »
          </button>
        </div>
      )}
    </div>
  );
}
