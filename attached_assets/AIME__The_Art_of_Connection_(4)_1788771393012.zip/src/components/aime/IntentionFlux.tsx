import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "motion/react";
import { toast } from "sonner";
import { CalendarPlus, CarFront, HandHeart, MapPin, Search, Sparkles, Timer } from "lucide-react";
import { intentionsQuery, universesQuery } from "@/lib/aime/queries";
import { universeIcon } from "@/lib/aime/icons";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `il y a ${h} h`;
  const d = Math.round(h / 24);
  return `il y a ${d} j`;
}

const SIGNAL_PRESETS = [
  { label: "Dernière minute", icon: Timer, text: "Dernière minute : " },
  { label: "Sortie improvisée", icon: CalendarPlus, text: "Sortie improvisée : " },
  { label: "Covoiturage", icon: CarFront, text: "Covoiturage : " },
  { label: "Place dispo", icon: Sparkles, text: "Place dispo : " },
] as const;

function signalLabel(body: string) {
  const text = body.toLowerCase();
  if (text.includes("covoitur"))
    return { label: "Covoiturage", tone: "bg-sky-500/15 text-sky-700" };
  if (text.includes("dernière minute") || text.includes("derniere minute"))
    return { label: "Dernière minute", tone: "bg-rose-500/15 text-rose-700" };
  if (text.includes("sortie") || text.includes("ce soir") || text.includes("maintenant"))
    return { label: "Moment vivant", tone: "bg-violet-500/15 text-violet-700" };
  if (text.includes("place dispo") || text.includes("place disponible"))
    return { label: "Place dispo", tone: "bg-emerald-500/15 text-emerald-700" };
  return null;
}

export function IntentionFlux({
  onReuse,
  defaultOpen = false,
}: {
  onReuse?: (body: string) => void;
  defaultOpen?: boolean;
}) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: intentions = [] } = useQuery(intentionsQuery);
  const { data: universes = [] } = useQuery(universesQuery);

  const [body, setBody] = useState("");
  const [kind, setKind] = useState<"besoin" | "offre">("besoin");
  const [city, setCity] = useState("");
  const [universe, setUniverse] = useState<string | null>(null);
  const [filter, setFilter] = useState<"tout" | "besoin" | "offre">("tout");
  const [open, setOpen] = useState(defaultOpen);

  const publish = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("Connectez-vous pour publier une intention.");
      const text = body.trim();
      if (text.length < 8) throw new Error("Dites-en un peu plus.");
      const { error } = await supabase.from("intentions").insert({
        user_id: userId,
        body: text.slice(0, 400),
        kind,
        city: city.trim() || null,
        universe_slug: universe,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setBody("");
      setCity("");
      qc.invalidateQueries({ queryKey: ["intentions"] });
      toast("Votre intention est dans le flux.");
    },
    onError: (e: Error) => toast(e.message),
  });

  const visible = intentions.filter((i) => filter === "tout" || i.kind === filter);
  const cities = [...new Set(intentions.map((i) => i.city).filter(Boolean) as string[])];

  return (
    <section className="mt-20 border-t border-hairline pt-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Le flux</p>
          <h2 className="mt-2 text-3xl font-semibold tracking-[-0.035em]">
            Ce que les autres cherchent, ce qu'ils offrent.
          </h2>
        </div>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="rounded-full hairline bg-card px-4 py-2 text-[13px] shadow-soft"
        >
          {open ? "Fermer" : "Publier une intention"}
        </button>
      </div>

      {open && (
        <div className="mt-6 rounded-4xl hairline bg-card p-5 shadow-soft">
          <div className="flex flex-wrap gap-2">
            {[
              { v: "besoin" as const, label: "Je cherche", icon: Search },
              { v: "offre" as const, label: "Je propose", icon: HandHeart },
            ].map((o) => (
              <button
                key={o.v}
                type="button"
                onClick={() => setKind(o.v)}
                className={cn(
                  "flex items-center gap-2 rounded-full px-3.5 py-2 text-[13px] transition-colors",
                  kind === o.v
                    ? "bg-primary text-primary-foreground"
                    : "hairline bg-background text-muted-foreground",
                )}
              >
                <o.icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                {o.label}
              </button>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {SIGNAL_PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() =>
                  setBody((current) =>
                    current.trim().length === 0 || current.startsWith(preset.text)
                      ? preset.text
                      : `${preset.text}${current}`,
                  )
                }
                className="inline-flex items-center gap-2 rounded-full hairline bg-background px-3 py-1.5 text-[12px] text-muted-foreground transition-colors hover:text-foreground"
              >
                <preset.icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                {preset.label}
              </button>
            ))}
          </div>

          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={2}
            maxLength={400}
            placeholder={
              kind === "besoin"
                ? "Un guitariste pour une cérémonie laïque le 12 juin près de Lille…"
                : "Je prête ma sono et je peux aider au montage un samedi…"
            }
            className="mt-4 w-full resize-none bg-transparent text-[16px] leading-relaxed outline-none placeholder:text-muted-foreground/60"
          />

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-full hairline bg-background px-3 py-2">
              <MapPin className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
              <input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Ville"
                className="w-24 bg-transparent text-[13px] outline-none"
              />
            </div>
            <select
              value={universe ?? ""}
              onChange={(e) => setUniverse(e.target.value || null)}
              className="rounded-full hairline bg-background px-3 py-2 text-[13px] outline-none"
            >
              <option value="">Tous les univers</option>
              {universes.map((u) => (
                <option key={u.slug} value={u.slug}>
                  {u.label}
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={publish.isPending || body.trim().length < 8}
              onClick={() => publish.mutate()}
              className="ml-auto rounded-full bg-primary px-4 py-2 text-[13px] font-medium text-primary-foreground disabled:opacity-40"
            >
              {publish.isPending ? "Envoi…" : "Publier"}
            </button>
          </div>
        </div>
      )}

      <div className="mt-8 flex flex-wrap items-center gap-2">
        {(["tout", "besoin", "offre"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            className={cn(
              "rounded-full px-3.5 py-2 text-[13px] transition-colors",
              filter === f
                ? "bg-foreground text-background"
                : "hairline bg-card text-muted-foreground",
            )}
          >
            {f === "tout" ? "Tout" : f === "besoin" ? "Recherches" : "Propositions"}
          </button>
        ))}
        {cities.length > 0 && (
          <span className="ml-2 text-[13px] text-muted-foreground">
            {cities.slice(0, 4).join(" · ")}
          </span>
        )}
      </div>

      {visible.length === 0 ? (
        <p className="mt-8 text-[15px] text-muted-foreground">
          Le flux est encore silencieux. Posez la première intention.
        </p>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {visible.map((i, idx) => {
            const Icon = i.universe_slug ? universeIcon(i.universe_slug) : HandHeart;
            const signal = signalLabel(i.body);
            return (
              <motion.article
                key={i.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(idx, 8) * 0.03 }}
                className="rounded-3xl hairline bg-card p-5 shadow-soft"
              >
                <div className="flex flex-wrap items-center gap-2 text-[12px] text-muted-foreground">
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-1",
                      i.kind === "offre" ? "bg-secondary" : "bg-primary/10 text-foreground",
                    )}
                  >
                    {i.kind === "offre" ? "Propose" : "Cherche"}
                  </span>
                  {signal && (
                    <span className={cn("rounded-full px-2.5 py-1", signal.tone)}>
                      {signal.label}
                    </span>
                  )}
                  <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                  {i.city && <span>{i.city}</span>}
                  <span className="ml-auto">{timeAgo(i.created_at)}</span>
                </div>
                <p className="mt-3 text-[15px] leading-relaxed">{i.body}</p>
                {onReuse && (
                  <button
                    type="button"
                    onClick={() => onReuse(i.body)}
                    className="mt-3 text-[13px] text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                  >
                    Composer une rencontre pour ça
                  </button>
                )}
              </motion.article>
            );
          })}
        </div>
      )}
    </section>
  );
}
