import { useRouter, useRouterState } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/**
 * Bouton Retour global, en haut à gauche de chaque page (accueil exclu).
 * Revient à l'écran précédent ; sans historique, ramène à l'accueil.
 */
export function BackButton({ inline = false, className }: { inline?: boolean; className?: string }) {
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (pathname === "/") return null;

  const goBack = () => {
    if (typeof window !== "undefined" && window.history.length > 1) {
      router.history.back();
      return;
    }
    void router.navigate({ to: "/" });
  };

  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      onClick={goBack}
      aria-label="Retour à l'écran précédent"
      title="Retour"
      className={cn("h-11 w-11 shrink-0 rounded-full", className)}
    >
      <ArrowLeft className="h-[18px] w-[18px]" strokeWidth={1.75} />
    </Button>
  );
}
