import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import {
  AVAILABILITY_DOT,
  WEEKDAYS,
  addMonths,
  monthGrid,
  monthLabel,
  toDayKey,
} from "@/lib/aime/calendar";
import { cn } from "@/lib/utils";

export function MonthCalendar({
  month,
  onMonthChange,
  statusByDay,
  onSelectDay,
  selectedDay,
  compact = false,
  dotClasses,
  countByDay,
  liveDay,
  onPaint,
  onHoverDay,
}: {
  month: Date;
  onMonthChange?: (next: Date) => void;
  statusByDay: Map<string, string>;
  onSelectDay?: (day: string) => void;
  selectedDay?: string | null;
  compact?: boolean;
  dotClasses?: Record<string, string>;
  countByDay?: Map<string, number>;
  liveDay?: string | null;
  /** Pinceau : peint le jour au clic et au glissé. Prioritaire sur onSelectDay. */
  onPaint?: (day: string) => void;
  /** Aperçu au survol (null quand la souris quitte la grille). */
  onHoverDay?: (day: string | null) => void;
}) {
  const cells = monthGrid(month);
  const dots = dotClasses ?? AVAILABILITY_DOT;
  const painting = useRef(false);
  const [today, setToday] = useState<string | null>(null);

  useEffect(() => setToday(toDayKey(new Date())), []);

  useEffect(() => {
    if (!onPaint) return;
    const stop = () => {
      painting.current = false;
    };
    window.addEventListener("pointerup", stop);
    return () => window.removeEventListener("pointerup", stop);
  }, [onPaint]);

  return (
    <div className={cn("rounded-3xl hairline bg-card shadow-soft", compact ? "p-3" : "p-4")}>
      <div className="flex items-center justify-between">
        {onMonthChange ? (
          <button
            type="button"
            aria-label="Mois précédent"
            onClick={() => onMonthChange(addMonths(month, -1))}
            className="grid h-8 w-8 place-items-center rounded-full hairline bg-background text-muted-foreground"
          >
            <ChevronLeft className="h-4 w-4" strokeWidth={1.75} />
          </button>
        ) : (
          <span />
        )}
        <p
          className={cn(
            "first-letter:uppercase font-medium",
            compact ? "text-[13px]" : "text-[15px]",
          )}
        >
          {monthLabel(month)}
        </p>
        {onMonthChange ? (
          <button
            type="button"
            aria-label="Mois suivant"
            onClick={() => onMonthChange(addMonths(month, 1))}
            className="grid h-8 w-8 place-items-center rounded-full hairline bg-background text-muted-foreground"
          >
            <ChevronRight className="h-4 w-4" strokeWidth={1.75} />
          </button>
        ) : (
          <span />
        )}
      </div>

      <div className="mt-3 grid grid-cols-7 gap-1 text-center text-[11px] text-muted-foreground">
        {WEEKDAYS.map((d, i) => (
          <span key={`${d}-${i}`}>{d}</span>
        ))}
      </div>

      <div className="mt-1 grid grid-cols-7 gap-1" onPointerLeave={() => onHoverDay?.(null)}>
        {cells.map((date, i) => {
          if (!date) return <span key={`empty-${i}`} />;
          const key = toDayKey(date);
          const status = statusByDay.get(key);
          const selected = selectedDay === key;
          const interactive = !!onSelectDay || !!onPaint;
          const Tag = interactive ? "button" : "div";
          return (
            <Tag
              key={key}
              {...(interactive
                ? {
                    type: "button" as const,
                    onPointerDown: () => {
                      if (!onPaint) return;
                      painting.current = true;
                      onPaint(key);
                    },
                    onPointerEnter: () => {
                      onHoverDay?.(key);
                      if (onPaint && painting.current) onPaint(key);
                    },
                    onClick: () => {
                      if (onPaint) return;
                      onSelectDay?.(key);
                    },
                  }
                : {})}
              className={cn(
                "relative grid aspect-square place-items-center rounded-xl text-[12px] transition-colors",
                selected ? "bg-primary text-primary-foreground" : "hover:bg-secondary",
                status && !selected && "bg-secondary",
                today === key && !selected && "ring-1 ring-foreground/25",
                liveDay === key && !selected && "ring-2 ring-rose-400",
              )}
            >
              {date.getDate()}
              {status && (
                <span
                  className={cn(
                    "absolute bottom-1 h-1.5 w-1.5 rounded-full",
                    dots[status] ?? "bg-muted-foreground",
                    liveDay === key && "animate-pulse",
                  )}
                />
              )}
              {countByDay && (countByDay.get(key) ?? 0) > 1 && (
                <span className="absolute right-1 top-1 text-[9px] text-muted-foreground">
                  {countByDay.get(key)}
                </span>
              )}
            </Tag>
          );
        })}
      </div>
    </div>
  );
}
