import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { PlayableItem } from "@/lib/aime/play/types";

type PlayState = {
  queue: PlayableItem[];
  index: number;
  playing: boolean;
  current: PlayableItem | null;
  /** Identifiant du repère en cours : la règle le met en évidence. */
  currentId: string | null;
  start: (items: PlayableItem[], label?: string) => void;
  label: string;
  stop: () => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  goTo: (index: number) => void;
  /** Suspend l'avance automatique tant qu'une voix parle. */
  hold: boolean;
  setHold: (value: boolean) => void;
};

const Ctx = createContext<PlayState | null>(null);

export function PlayProvider({
  children,
  onCurrent,
}: {
  children: ReactNode;
  /** Recentrage de la ligne de temps sur l'élément lu. */
  onCurrent?: (item: PlayableItem) => void;
}) {
  const [queue, setQueue] = useState<PlayableItem[]>([]);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [label, setLabel] = useState("");
  const [hold, setHold] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const current = queue[index] ?? null;

  const clear = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  };

  const start = useCallback((items: PlayableItem[], l = "") => {
    clear();
    setQueue(items);
    setLabel(l);
    setIndex(0);
    setPlaying(items.length > 0);
  }, []);

  const stop = useCallback(() => {
    clear();
    setPlaying(false);
    setQueue([]);
    setIndex(0);
  }, []);

  const next = useCallback(() => {
    clear();
    setIndex((i) => {
      if (i + 1 >= queue.length) {
        setPlaying(false);
        return i;
      }
      return i + 1;
    });
  }, [queue.length]);

  const prev = useCallback(() => {
    clear();
    setIndex((i) => Math.max(0, i - 1));
  }, []);

  // Avance automatique : la vidéo et l'audio se terminent d'eux-mêmes.
  useEffect(() => {
    if (!playing || !current || hold) return;
    if (current.type === "video" || current.type === "audio") return;
    timer.current = setTimeout(next, current.duration);
    return clear;
  }, [playing, current, next, hold]);

  useEffect(() => {
    if (current) onCurrent?.(current);
  }, [current, onCurrent]);

  const value = useMemo<PlayState>(
    () => ({
      queue,
      index,
      playing,
      current,
      currentId: current?.marker.id ?? null,
      hold,
      setHold,
      label,
      start,
      stop,
      toggle: () => setPlaying((p) => !p),
      next,
      prev,
      goTo: (i: number) => {
        clear();
        setIndex(Math.max(0, Math.min(queue.length - 1, i)));
      },
    }),
    [queue, index, playing, current, label, start, stop, next, prev, hold],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function usePlay(): PlayState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("usePlay doit être utilisé dans <PlayProvider>");
  return ctx;
}
