import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2, Music, Plus, Search, Upload, X } from "lucide-react";
import { toast } from "sonner";
import { bindAudioElement } from "@/lib/aime/audioBus";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import {
  AUDIO_TYPES,
  itunesProvider,
  uploadTimelineMedia,
  type MusicTrack,
} from "@/lib/aime/play/providers";

type Tab = "musique" | "souvenir";

function toDayTime(value: string) {
  const [day = "", time = ""] = value.split("T");
  return { day, time: time ? `${time}:00` : "00:00:00" };
}

/**
 * Bouton « ＋ Ajouter » : une musique (recherche avec extrait légal, ou fichier)
 * ou un souvenir (photo, vidéo, audio, message) placé à un moment de la ligne de temps.
 */
export function AddToTimeline({
  cardId,
  userId,
  at,
  className,
  embedded,
  onDone,
}: {
  cardId: string;
  userId: string;
  at?: number | undefined;
  className?: string;
  /** Intégré dans la fenêtre « Ajouter » : pas de bouton déclencheur. */
  embedded?: boolean;
  onDone?: () => void;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(!!embedded);
  const close = () => (embedded ? onDone?.() : setOpen(false));
  const [tab, setTab] = useState<Tab>("musique");

  const base = new Date(at ?? Date.now());
  base.setSeconds(0, 0);
  const isoLocal = new Date(base.getTime() - base.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
  const [when, setWhen] = useState(isoLocal);
  const [unknownDate, setUnknownDate] = useState(false);

  // Musique
  const [q, setQ] = useState("");
  const [results, setResults] = useState<MusicTrack[]>([]);
  const [searching, setSearching] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  // Souvenir
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const addTrack = useMutation({
    mutationFn: async (input: { track?: MusicTrack; file?: File }) => {
      const { day, time } = toDayTime(when);
      let sourceUrl: string | null = input.track?.previewUrl ?? null;
      let audioPath: string | null = null;
      if (input.file) {
        const up = await uploadTimelineMedia(cardId, input.file);
        audioPath = up.path;
        sourceUrl = up.url;
      }
      const { error } = await supabase.from("musicbox_entries").insert({
        card_id: cardId,
        owner_id: userId,
        title: input.track ? `${input.track.title}${input.track.artist ? ` — ${input.track.artist}` : ""}` : (input.file?.name ?? "Morceau"),
        day,
        start_time: time,
        duration_min: Math.max(1, Math.round((input.track?.duration ?? 180) / 60)),
        kind: "musique",
        source_type: input.track ? input.track.provider : "import",
        source_url: sourceUrl,
        audio_path: audioPath,
        rights_status: input.track?.rights ?? "import",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Musique placée sur la ligne de temps");
      qc.invalidateQueries({ queryKey: ["card-timeline-music", cardId] });
      qc.invalidateQueries({ queryKey: ["musicbox", cardId] });
      close();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addSouvenir = useMutation({
    mutationFn: async () => {
      let mediaUrl: string | null = null;
      let media: string | null = null;
      if (file) {
        const up = await uploadTimelineMedia(cardId, file);
        mediaUrl = up.url;
        media = file.type.startsWith("video")
          ? "video"
          : file.type.startsWith("audio")
            ? "audio"
            : "photo";
      }
      const starts = unknownDate ? new Date() : new Date(when);
      const { error } = await supabase.from("card_timeline_entries").insert({
        card_id: cardId,
        title: title || file?.name || "Souvenir",
        description: note || null,
        kind: "souvenir",
        starts_at: starts.toISOString(),
        status: unknownDate ? "a_valider" : "execute",
        metadata: {
          ...(mediaUrl ? { mediaUrl, thumbUrl: media === "photo" ? mediaUrl : undefined } : {}),
          ...(media ? { media } : {}),
          origine: {
            fileName: file?.name ?? null,
            fileType: file?.type ?? null,
            lastModified: file?.lastModified ?? null,
          },
          dateInconnue: unknownDate,
        },
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(unknownDate ? "Souvenir ajouté — date à confirmer" : "Souvenir ajouté");
      qc.invalidateQueries({ queryKey: ["card-timeline", cardId] });
      qc.invalidateQueries({ queryKey: ["timeline-entries", cardId] });
      setTitle("");
      setNote("");
      setFile(null);
      close();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const search = async () => {
    if (!q.trim()) return;
    setSearching(true);
    try {
      setResults(await itunesProvider.search(q.trim()));
    } finally {
      setSearching(false);
    }
  };

  if (!open && !embedded) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "hairline inline-flex items-center gap-2 rounded-full bg-background/80 px-4 py-2 text-[13px]",
          className,
        )}
      >
        <Plus className="h-3.5 w-3.5" /> Ajouter
      </button>
    );
  }

  return (
    <div className={cn("hairline rounded-3xl bg-card p-4 shadow-soft", className)}>
      <div className="flex items-center justify-between">
        <div className="flex gap-1.5">
          {(["musique", "souvenir"] as Tab[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={cn(
                "rounded-full px-3 py-1 text-[12px]",
                tab === t ? "bg-foreground text-background" : "text-muted-foreground",
              )}
            >
              {t === "musique" ? "Musique" : "Souvenir"}
            </button>
          ))}
        </div>
        <button type="button" aria-label="Fermer" onClick={close}>
          <X className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      <label className="mt-3 block text-[12px] text-muted-foreground">
        Moment
        <input
          type="datetime-local"
          value={when}
          disabled={unknownDate}
          onChange={(e) => setWhen(e.target.value)}
          className="hairline mt-1 w-full rounded-xl bg-background px-3 py-2 text-[13px] text-foreground disabled:opacity-50"
        />
      </label>

      {tab === "musique" ? (
        <div className="mt-3 space-y-3">
          <div className="flex gap-2">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && search()}
              placeholder="Rechercher un titre, un artiste"
              className="hairline w-full rounded-xl bg-background px-3 py-2 text-[13px]"
            />
            <button
              type="button"
              onClick={search}
              aria-label="Rechercher"
              className="hairline rounded-xl px-3"
            >
              {searching ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
            </button>
          </div>
          <ul className="max-h-64 space-y-1 overflow-y-auto">
            {results.map((t) => (
              <li key={t.trackId} className="flex items-center gap-2 rounded-xl p-1.5">
                {t.artwork ? (
                  <img src={t.artwork} alt="" className="h-9 w-9 rounded-md object-cover" />
                ) : (
                  <Music className="h-9 w-9 p-2 text-muted-foreground" />
                )}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px]">{t.title}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">
                    {t.artist} · extrait 30 s
                  </span>
                </span>
                {t.previewUrl ? (
                  <button
                    type="button"
                    onClick={() => setPreview(preview === t.previewUrl ? null : t.previewUrl!)}
                    className="hairline rounded-full px-2 py-1 text-[11px]"
                  >
                    {preview === t.previewUrl ? "Pause" : "Écouter"}
                  </button>
                ) : null}
                <button
                  type="button"
                  onClick={() => addTrack.mutate({ track: t })}
                  className="rounded-full bg-foreground px-2 py-1 text-[11px] text-background"
                >
                  Ajouter
                </button>
              </li>
            ))}
          </ul>
          {preview ? <audio ref={(el) => bindAudioElement("preview", el)} src={preview} autoPlay controls className="w-full" /> : null}
          <label className="hairline flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-[12px] text-muted-foreground">
            <Upload className="h-3.5 w-3.5" /> Importer un fichier audio
            <input
              type="file"
              accept={AUDIO_TYPES}
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) addTrack.mutate({ file: f });
              }}
            />
          </label>
        </div>
      ) : (
        <div className="mt-3 space-y-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Titre du souvenir"
            className="hairline w-full rounded-xl bg-background px-3 py-2 text-[13px]"
          />
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Message, dédicace…"
            rows={2}
            className="hairline w-full rounded-xl bg-background px-3 py-2 text-[13px]"
          />
          <label className="hairline flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-[12px] text-muted-foreground">
            <Upload className="h-3.5 w-3.5" />
            {file ? file.name : "Photo, vidéo ou audio"}
            <input
              type="file"
              accept="image/*,video/*,audio/*"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>
          <label className="flex items-center gap-2 text-[12px] text-muted-foreground">
            <input
              type="checkbox"
              checked={unknownDate}
              onChange={(e) => setUnknownDate(e.target.checked)}
            />
            Date inconnue — à placer plus tard
          </label>
          <button
            type="button"
            disabled={addSouvenir.isPending}
            onClick={() => addSouvenir.mutate()}
            className="w-full rounded-full bg-foreground px-4 py-2 text-[13px] text-background"
          >
            {addSouvenir.isPending ? "Ajout…" : "Ajouter à la ligne de temps"}
          </button>
        </div>
      )}
    </div>
  );
}
