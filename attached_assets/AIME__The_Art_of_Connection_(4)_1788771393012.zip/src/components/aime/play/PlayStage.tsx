import { useEffect, useRef, useState } from "react";
import { Pause, Play, SkipBack, SkipForward, Volume2, VolumeX, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { usePlay } from "./PlayProvider";
import { bindAudioElement } from "@/lib/aime/audioBus";
import { narrationAudioUrl, setVoiceEnabled, voiceEnabled } from "@/lib/aime/play/voice";

const HOUR = new Intl.DateTimeFormat("fr-FR", {
  day: "numeric",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
});

/**
 * Scène de lecture : le même moteur affiche photo, vidéo, audio, texte ou récit.
 * En mode `embedded`, la lecture se déroule dans le héros du projet : aucune
 * fenêtre noire ne recouvre l'interface.
 */
export function PlayStage({ embedded = false }: { embedded?: boolean }) {
  const { queue, index, current, playing, toggle, next, prev, stop, label, setHold } = usePlay();
  const [voice, setVoice] = useState(false);
  const [spoken, setSpoken] = useState<string | null>(null);
  const voiceRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => setVoice(voiceEnabled()), []);

  /** L'animatrice lit le repère courant ; la file attend qu'elle ait fini. */
  useEffect(() => {
    const el = voiceRef.current;
    el?.pause();
    setSpoken(null);
    if (!current || !voice || !playing) return setHold(false);
    if (current.type === "video" || current.type === "audio" || current.type === "musique") {
      return setHold(false);
    }
    const text = (current.narration ?? current.title).trim();
    if (!text) return setHold(false);

    let cancelled = false;
    setHold(true);
    setSpoken(text);
    void narrationAudioUrl(text)
      .then((url) => {
        if (cancelled) return;
        const audio = voiceRef.current ?? new Audio();
        voiceRef.current = audio;
        bindAudioElement("play", audio);
        audio.src = url;
        audio.onended = () => {
          setHold(false);
          next();
        };
        audio.onerror = () => setHold(false);
        return audio.play();
      })
      .catch(() => !cancelled && setHold(false));

    return () => {
      cancelled = true;
      setHold(false);
    };
  }, [current, voice, playing, next, setHold]);

  useEffect(() => {
    if (playing) return;
    voiceRef.current?.pause();
  }, [playing]);

  useEffect(
    () => () => {
      voiceRef.current?.pause();
    },
    [],
  );

  useEffect(() => {
    if (queue.length === 0) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") stop();
      if (e.key === " ") {
        e.preventDefault();
        toggle();
      }
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [queue.length, stop, toggle, next, prev]);

  if (!current) return null;
  const progress = queue.length > 1 ? (index / (queue.length - 1)) * 100 : 100;

  return (
    <div
      role="dialog"
      aria-label={`Lecture : ${label || "ligne de temps"}`}
      className={cn(
        "flex flex-col text-white",
        embedded
          ? "relative w-full overflow-hidden rounded-3xl border border-white/15 bg-black/45 backdrop-blur"
          : "fixed inset-0 z-[70] bg-black/95",
      )}
    >
      <div className="flex items-center justify-between px-5 py-3 text-[12px]">
        <span className="uppercase tracking-[0.16em] text-white/60">{label || "Lecture"}</span>
        <span className="tabular-nums text-white/60">
          {index + 1} / {queue.length}
        </span>
        <button
          type="button"
          onClick={() => {
            const nextValue = !voice;
            setVoice(nextValue);
            setVoiceEnabled(nextValue);
            if (!nextValue) {
              voiceRef.current?.pause();
              setHold(false);
            }
          }}
          aria-label={voice ? "Couper la voix" : "Activer la voix"}
          title={voice ? "Couper la voix" : "Activer la voix"}
          className="ml-auto mr-2 grid h-8 w-8 place-items-center rounded-full bg-white/10 hover:bg-white/20"
        >
          {voice ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>
        <button
          type="button"
          onClick={stop}
          aria-label="Fermer la lecture"
          className="grid h-8 w-8 place-items-center rounded-full bg-white/10 hover:bg-white/20"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className={cn("flex flex-1 items-center justify-center", embedded ? "px-4" : "px-6")}>
        {current.type === "video" && current.mediaUrl ? (
          <video
            key={current.id}
            ref={(el) => bindAudioElement("play", el)}
            src={current.mediaUrl}
            autoPlay
            playsInline
            controls
            onEnded={next}
            className={cn("w-full max-w-4xl rounded-2xl object-contain", embedded ? "max-h-[34vh]" : "max-h-[70vh]")}
          />
        ) : current.type === "audio" || current.type === "musique" ? (
          <div className="w-full max-w-md text-center">
            {current.thumbnail && (
              <img
                src={current.thumbnail}
                alt=""
                className="mx-auto mb-5 h-48 w-48 rounded-2xl object-cover"
              />
            )}
            <p className="text-lg font-medium">{current.title}</p>
            {current.subtitle && <p className="mt-1 text-[13px] text-white/60">{current.subtitle}</p>}
            {current.mediaUrl ? (
              <audio
                key={current.id}
                ref={(el) => bindAudioElement("play", el)}
                src={current.mediaUrl}
                autoPlay
                controls
                onEnded={next}
                className="mt-5 w-full"
              />
            ) : (
              <p className="mt-4 text-[12px] text-white/50">
                Aucun extrait disponible pour ce morceau.
              </p>
            )}
          </div>
        ) : current.type === "photo" && current.thumbnail ? (
          <img
            key={current.id}
            src={current.thumbnail}
            alt={current.title}
            className={cn("w-auto rounded-2xl object-contain", embedded ? "max-h-[34vh]" : "max-h-[70vh]")}
          />
        ) : (
          <div className="max-w-2xl text-center">
            <p className="text-[11px] uppercase tracking-[0.16em] text-white/50">
              {current.type === "narration" ? "Récit" : "Moment"}
            </p>
            <p className={cn("mt-3 leading-snug", embedded ? "text-xl" : "text-2xl")}>
              {current.title}
            </p>
            {current.narration && (
              <p className="mt-4 text-[15px] leading-relaxed text-white/70">{current.narration}</p>
            )}
          </div>
        )}
      </div>

      <div className={cn("px-5", embedded ? "pb-4 pt-2" : "pb-6")}>
        {spoken && voice && (
          <p className="mx-auto mb-3 max-w-2xl text-center text-[14px] leading-relaxed text-white/75">
            {spoken}
          </p>
        )}
        <p className="mb-2 text-center text-[12px] tabular-nums text-white/55">
          {HOUR.format(new Date(current.timestamp))} · {current.title}
        </p>
        <div className="mx-auto mb-4 h-[3px] w-full max-w-3xl overflow-hidden rounded-full bg-white/15">
          <div className="h-full bg-white/80 transition-all" style={{ width: `${progress}%` }} />
        </div>
        <div className="flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={prev}
            aria-label="Élément précédent"
            className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-white/20"
          >
            <SkipBack className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={toggle}
            aria-label={playing ? "Pause" : "Reprendre"}
            className={cn("grid h-12 w-12 place-items-center rounded-full bg-white text-black")}
          >
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-[1px]" />}
          </button>
          <button
            type="button"
            onClick={next}
            aria-label="Élément suivant"
            className="grid h-10 w-10 place-items-center rounded-full bg-white/10 hover:bg-white/20"
          >
            <SkipForward className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
