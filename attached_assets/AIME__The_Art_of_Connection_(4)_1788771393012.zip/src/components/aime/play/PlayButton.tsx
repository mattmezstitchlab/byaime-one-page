import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Play, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import { buildPlayQueue } from "@/lib/aime/play/buildQueue";
import { familiesOf } from "@/lib/aime/timelineFilters";
import type { PlayMode, PlayScope } from "@/lib/aime/play/types";
import { usePlay } from "./PlayProvider";


type Entry = { key: string; label: string; run: () => void };

/**
 * Le bouton unique de lecture de la ligne de temps : un menu de scénarios,
 * jamais un lecteur séparé. Chaque entrée construit une file avec le même moteur.
 */
export function PlayButton({
  markers,
  visibleMarkers,
  at,
  className,
}: {
  markers: TimelineMarker[];
  /** Ce qui est actuellement affiché (calques + fenêtre de temps). */
  visibleMarkers?: TimelineMarker[];
  /** Moment sélectionné sur la règle (ms epoch). */
  at?: number;
  className?: string;
}) {
  const { start, stop, playing, queue } = usePlay();
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  const moment = at ?? Date.now();

  // Le menu est posé dans une couche au-dessus de l'en-tête, jamais dessous.
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const r = btnRef.current?.getBoundingClientRect();
      if (!r) return;
      const height = Math.min(420, window.innerHeight - 120);
      const top = Math.max(84, Math.min(r.top - 8 - height, window.innerHeight - height - 16));
      setPos({ left: Math.min(r.left, window.innerWidth - 240), top });
    };
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (!ref.current?.contains(t) && !menuRef.current?.contains(t)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const play = (
    label: string,
    mode: PlayMode,
    scope: PlayScope,
    list: TimelineMarker[] = markers,
  ) => {
    start(buildPlayQueue(list, { mode, scope }), label);
    setOpen(false);
  };

  /**
   * Trois lectures, rien de plus : ce qui est affiché, le jour J, le récit.
   * Les natures d'objets (photos, musique, souvenirs…) sont des calques,
   * les périodes sont la capsule temporelle.
   */
  const readEntries: Entry[] = [
    {
      key: "affiche",
      label: "Lire le temps affiché",
      run: () => play("Le temps affiché", "tout", { kind: "tout" }, visibleMarkers ?? markers),
    },
    {
      key: "jour",
      label: "Le jour J",
      run: () => play("Le jour J", "tout", { kind: "jour", at: moment }),
    },
    {
      key: "playlist",
      label: "Écouter la playlist",
      run: () =>
        play(
          "La playlist",
          "tout",
          { kind: "tout" },
          markers.filter((m) => familiesOf(m).includes("musique")),
        ),
    },
    {
      key: "recit",
      label: "Récit",
      run: () => play("Récit", "narration", { kind: "tout" }, visibleMarkers ?? markers),
    },
  ];

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        ref={btnRef}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => (playing || queue.length ? stop() : setOpen((o) => !o))}
        className={cn(
          "grid h-10 w-10 place-items-center rounded-full border border-input bg-background text-foreground shadow-sm transition-transform hover:scale-105 hover:bg-accent",
        )}
        aria-label={playing ? "Arrêter la lecture" : "Lire la ligne de temps"}
        title={playing ? "Arrêter la lecture" : "Lire la ligne de temps"}
      >
        {playing || queue.length ? (
          <Square className="h-4 w-4" strokeWidth={2.2} />
        ) : (
          <Play className="h-4 w-4 translate-x-[1px]" strokeWidth={2.2} />
        )}
      </button>

      {open &&
        typeof document !== "undefined" &&
        pos &&
        createPortal(
          <div
            ref={menuRef}
            role="menu"
            style={{ left: pos.left, top: pos.top, maxHeight: Math.min(420, window.innerHeight - 120) }}
            className="fixed z-[60] w-56 overflow-y-auto rounded-2xl bg-foreground/90 p-2 text-background shadow-soft backdrop-blur-md"
          >
          <p className="px-2 pb-1 text-[10px] uppercase tracking-[0.16em] text-background/50">Lire</p>
          {readEntries.map((e) => (
            <button
              key={e.key}
              type="button"
              role="menuitem"
              onClick={e.run}
              className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[13px] transition-colors hover:bg-background/12"
            >
              <Play className="h-3 w-3 opacity-70" />
              {e.label}
            </button>
          ))}
          {(playing || queue.length > 0) && (
            <>
              <div className="my-1 h-px bg-background/15" />
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  stop();
                  setOpen(false);
                }}
                className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[13px] transition-colors hover:bg-background/12"
              >
                <Square className="h-3 w-3 opacity-70" />
                Arrêter
              </button>
            </>
          )}
          </div>,
          document.body,
        )}
    </div>
  );

}
