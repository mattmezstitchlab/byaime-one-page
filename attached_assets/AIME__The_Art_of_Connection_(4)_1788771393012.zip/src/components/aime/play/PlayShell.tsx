import { useCallback, useState, type ReactNode } from "react";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import type { PlayableItem } from "@/lib/aime/play/types";
import { PlayProvider, usePlay } from "./PlayProvider";
import { PlayButton } from "./PlayButton";
import { PlayStage } from "./PlayStage";

function Deck({
  markers,
  at,
  after,
  children,
  controls,
}: {
  markers: TimelineMarker[];
  at?: number | undefined;
  after?: ReactNode;
  children: (playingId: string | null) => ReactNode;
  controls?: (button: ReactNode) => ReactNode;
}) {
  const { currentId } = usePlay();
  const button = <PlayButton markers={markers} {...(at !== undefined ? { at } : {})} />;
  return (
    <>
      {children(currentId)}
      {controls ? (
        controls(button)
      ) : (
        <div className="pointer-events-none absolute -top-8 left-4 z-[36] md:left-8">
          <div className="pointer-events-auto">{button}</div>
        </div>
      )}
      {after}
      <PlayStage />
    </>
  );
}


/**
 * Enveloppe de lecture : un seul moteur PLAY autour de la ligne de temps existante.
 * `children` reçoit l'identifiant du repère en cours pour le mettre en évidence.
 */
export function PlayShell({
  markers,
  at,
  onFocus,
  after,
  children,
  controls,
}: {
  markers: TimelineMarker[];
  at?: number | undefined;
  /** Recentrage de la règle sur l'élément lu. */
  onFocus?: (time: number) => void;
  /** Contenu rendu dans le même moteur de lecture (mode DJ, ajouts…). */
  after?: ReactNode;
  children: (playingId: string | null) => ReactNode;
  /** Placement personnalisé du bouton, sans créer un second moteur de lecture. */
  controls?: (button: ReactNode) => ReactNode;
}) {
  const [, setLast] = useState(0);
  const onCurrent = useCallback(
    (item: PlayableItem) => {
      setLast(item.timestamp);
      onFocus?.(item.timestamp);
    },
    [onFocus],
  );
  return (
    <PlayProvider onCurrent={onCurrent}>
      <Deck
        markers={markers}
        {...(at !== undefined ? { at } : {})}
        after={after}
        {...(controls ? { controls } : {})}
      >
        {children}
      </Deck>
    </PlayProvider>

  );
}
