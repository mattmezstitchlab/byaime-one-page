import { useMemo } from "react";
import { Disc3, Play } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import { buildPlayQueue } from "@/lib/aime/play/buildQueue";
import { usePlay } from "./PlayProvider";

const HOUR = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" });

/**
 * Vue DJ : morceau actuel, morceau suivant, événement suivant, heure.
 * Ce n'est pas une timeline séparée, seulement une lecture filtrée de la même ligne.
 */
export function DjMode({
  markers,
  at,
  className,
}: {
  markers: TimelineMarker[];
  at?: number;
  className?: string;
}) {
  const { start, current } = usePlay();
  const moment = at ?? Date.now();

  const queue = useMemo(
    () => buildPlayQueue(markers, { mode: "musique", scope: { kind: "jour", at: moment } }),
    [markers, moment],
  );
  const events = useMemo(
    () =>
      markers
        .filter((m) => m.kind === "evenement" || m.kind === "jalon")
        .sort((a, b) => a.time - b.time),
    [markers],
  );

  if (queue.length === 0) return null;

  const idx = current ? queue.findIndex((q) => q.id === current.id) : -1;
  const now = idx >= 0 ? queue[idx] : queue[0];
  const nextTrack = queue[(idx >= 0 ? idx : 0) + 1] ?? null;
  const nextEvent = events.find((e) => e.time > (now?.timestamp ?? moment)) ?? null;

  return (
    <section
      aria-label="Mode DJ"
      className={cn("hairline rounded-3xl bg-card p-5 shadow-soft", className)}
    >
      <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
        <Disc3 className="h-3.5 w-3.5" /> Mode DJ
      </p>
      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <div>
          <p className="text-[11px] text-muted-foreground">Morceau actuel</p>
          <p className="text-[15px] font-medium">{now?.title ?? "—"}</p>
          <p className="text-[12px] tabular-nums text-muted-foreground">
            {now ? HOUR.format(new Date(now.timestamp)) : ""}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-muted-foreground">Prochain morceau</p>
          <p className="text-[15px] font-medium">{nextTrack?.title ?? "Fin de la playlist"}</p>
          <p className="text-[12px] tabular-nums text-muted-foreground">
            {nextTrack ? HOUR.format(new Date(nextTrack.timestamp)) : ""}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-muted-foreground">Événement suivant</p>
          <p className="text-[15px] font-medium">{nextEvent?.title ?? "—"}</p>
          <p className="text-[12px] tabular-nums text-muted-foreground">
            {nextEvent ? HOUR.format(new Date(nextEvent.startTime ?? nextEvent.time)) : ""}
          </p>
        </div>
      </div>
      <button
        type="button"
        onClick={() => start(queue, "Playlist du jour")}
        className="mt-4 inline-flex items-center gap-2 rounded-full bg-foreground px-4 py-2 text-[13px] text-background"
      >
        <Play className="h-3.5 w-3.5" /> Lancer la playlist
      </button>
    </section>
  );
}
