import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Mic, Square } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { eventsQuery } from "@/lib/aime/queries";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/** À quelle cadence l'annonce revient entre deux morceaux. */
export const FREQUENCIES = [
  { value: "une-fois", label: "Une seule fois" },
  { value: "jour", label: "Chaque jour" },
  { value: "semaine", label: "Chaque semaine" },
  { value: "jusqu-au-jour", label: "Jusqu'au jour du projet" },
] as const;

export type Frequency = (typeof FREQUENCIES)[number]["value"];

/** La cadence est rangée en tête de la note : aucune donnée nouvelle. */
export function frequencyTag(value: Frequency) {
  return `[diffusion:${value}]`;
}

export function readFrequency(note: string | null): Frequency | null {
  const hit = /^\[diffusion:([\w-]+)\]/.exec(note ?? "");
  return (hit?.[1] as Frequency) ?? null;
}

/**
 * Le bouton cœur de la capsule radio : laisser un vocal ou passer une annonce,
 * et choisir à quelle cadence elle revient à l'antenne.
 */
export function AnnonceDialog({
  open,
  onOpenChange,
  projectId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  projectId: string | null;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const [eventId, setEventId] = useState<string>(projectId ?? "");
  const [text, setText] = useState("");
  const [frequency, setFrequency] = useState<Frequency>("une-fois");
  const [recording, setRecording] = useState(false);
  const [blob, setBlob] = useState<Blob | null>(null);
  const recorder = useRef<MediaRecorder | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = () => {
        setBlob(new Blob(chunks, { type: rec.mimeType || "audio/webm" }));
        stream.getTracks().forEach((t) => t.stop());
      };
      rec.start();
      recorder.current = rec;
      setRecording(true);
    } catch {
      toast("Le micro n'est pas accessible.");
    }
  };

  const stopRecording = () => {
    recorder.current?.stop();
    recorder.current = null;
    setRecording(false);
  };

  const save = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("Connectez-vous pour passer une annonce.");
      if (!text.trim() && !blob) throw new Error("Écrivez l'annonce ou enregistrez un vocal.");
      let audio_path: string | null = null;
      if (blob) {
        const path = `${userId}/${crypto.randomUUID()}-annonce.webm`;
        const { error } = await supabase.storage.from("musicbox").upload(path, blob);
        if (error) throw error;
        audio_path = path;
      }
      const now = new Date();
      const { error } = await supabase.from("musicbox_entries").insert({
        owner_id: userId,
        event_id: eventId || null,
        day: now.toISOString().slice(0, 10),
        start_time: now.toTimeString().slice(0, 8),
        duration_min: 1,
        kind: blob ? "message" : "annonce",
        title: text.trim().slice(0, 80) || "Annonce vocale",
        note: `${frequencyTag(frequency)} ${text.trim()}`.trim(),
        source_type: audio_path ? "upload" : "texte",
        audio_path,
        visibility: "public",
        status: "valide",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["musicbox"] });
      void qc.invalidateQueries({ queryKey: ["public-tracks"] });
      toast.success("Annonce enregistrée : elle passera à l'antenne.");
      setText("");
      setBlob(null);
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="z-[90] sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Passer une annonce</DialogTitle>
          <DialogDescription>
            Un vocal ou quelques mots, glissés entre deux morceaux.
          </DialogDescription>
        </DialogHeader>

        <label className="block text-[12.5px] font-medium">
          Le projet concerné
          <select
            value={eventId}
            onChange={(e) => setEventId(e.target.value)}
            className="mt-1 h-11 w-full rounded-2xl hairline bg-background px-3 text-[14px] font-normal"
          >
            <option value="">Sans projet</option>
            {events.map((e) => (
              <option key={e.id} value={e.id}>
                {e.title}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-[12.5px] font-medium">
          L&apos;annonce
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={3}
            placeholder="Ce que vous voulez dire à l'antenne"
            className="mt-1 w-full rounded-2xl hairline bg-background p-3 text-[14px] font-normal"
          />
        </label>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => (recording ? stopRecording() : void startRecording())}
            className="inline-flex h-11 items-center gap-2 rounded-full bg-secondary px-4 text-[13px]"
          >
            {recording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            {recording ? "Arrêter" : "Enregistrer un vocal"}
          </button>
          {blob && <span className="text-[12.5px] text-muted-foreground">Vocal prêt</span>}
        </div>

        <label className="block text-[12.5px] font-medium">
          Fréquence de diffusion
          <select
            value={frequency}
            onChange={(e) => setFrequency(e.target.value as Frequency)}
            className="mt-1 h-11 w-full rounded-2xl hairline bg-background px-3 text-[14px] font-normal"
          >
            {FREQUENCIES.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </label>

        <button
          type="button"
          disabled={save.isPending}
          onClick={() => save.mutate()}
          className="h-11 rounded-full bg-foreground text-[13px] text-background disabled:opacity-60"
        >
          {save.isPending ? "Enregistrement…" : "Passer l'annonce"}
        </button>
      </DialogContent>
    </Dialog>
  );
}
