import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { describe, test } from "node:test";
import { fileURLToPath } from "node:url";

function read(rel: string) {
  return readFileSync(fileURLToPath(new URL(rel, import.meta.url)), "utf8");
}

describe("Hero d'accueil — barre fine, timeline ancrée", () => {
  test("HomeJourney n'affiche plus le grand panneau « Ce qu'AIME a compris »", () => {
    const home = read("./HomeJourney.tsx");
    assert.ok(!home.includes("journeySummary("));
    assert.ok(!home.includes('aria-label="Ce qu\'AIME a compris"'));
    assert.ok(!home.includes("Ce qu'AIME a compris"));
  });

  test("Le héros tient dans le premier écran : la timeline n'est plus décalée sous le pli", () => {
    const home = read("./HomeJourney.tsx");
    assert.ok(!home.includes("min-h-[100svh]"));
    assert.ok(home.includes("min-h-[calc(100svh-"));
  });

  test("Le bouton connecteur vit au-dessus de la ligne de temps, plus jamais en dessous", () => {
    const home = read("./HomeJourney.tsx");
    const connector = home.indexOf("<SourceMenu");
    const timeline = home.indexOf("<HeroTimeline");
    assert.ok(connector > -1 && timeline > -1 && connector < timeline);
    assert.ok(!home.includes("mt-6 flex flex-col items-center gap-3 px-5 pb-6"));
  });

  test("HeroBar : une barre fine, le menu univers au même design, des badges bornés", () => {
    const hero = read("./HeroBar.tsx");
    // Le grand bloc blanc a disparu, place à une barre pill fine.
    assert.ok(!hero.includes("rounded-[30px]"));
    assert.ok(hero.includes("rounded-full"));
    assert.ok(hero.includes("TEXTAREA_MAX_HEIGHT"));
    assert.ok(hero.includes("textarea"));
    assert.ok(hero.includes("onCompletionChange"));
    assert.ok(hero.includes("Touchez un badge pour modifier"));
    // Le menu des univers partage le design de la barre.
    assert.ok(hero.includes('aria-label="Univers du projet"'));
    assert.ok(hero.includes("Choisir l'univers"));
  });
});

describe("Accueil — une seule page, pas de double de l'application", () => {
  test("Le récit sous le héros a disparu : il ne reste que la bande des univers", () => {
    const index = read("../../../routes/index.tsx");
    assert.ok(index.includes("<HomeJourney />"));
    assert.ok(index.includes("<UniverseStrip />"));
    assert.ok(!index.includes("HomeStory"));
    assert.ok(!existsSync(fileURLToPath(new URL("./HomeStory.tsx", import.meta.url))));
  });

  test("La timeline de démonstration a disparu : celle du héros suffit", () => {
    const home = read("./HomeJourney.tsx");
    assert.ok(!home.includes("demoWedding"));
    assert.ok(!home.includes("deriveTimeline(demoWedding"));
  });
});

describe("Sources — toutes les connexions actives", () => {
  test("Le catalogue n'annonce plus rien « bientôt »", () => {
    const catalog = read("../../../lib/aime/sources/catalog.ts");
    assert.ok(!catalog.includes("bientot"));
    assert.ok(!catalog.includes("Bientôt disponible"));
  });

  test("Le menu des sources ouvre un flot réel pour chaque service", () => {
    const menu = read("../sources/SourceMenu.tsx");
    assert.ok(!menu.includes("bientot"));
    assert.ok(!menu.includes("Bientôt disponible"));
    assert.ok(menu.includes('if (s.key === "document") fileRef.current?.click();'));
    assert.ok(menu.includes("setLinkFor(s)"));
  });
});
