/**
 * L'écran de construction : « AI + ME ». Le « + » tourne, le « ME » blanchit
 * à mesure que le projet se construit. Les étapes affichées sont celles du
 * projet réellement en train d'être créé : elles viennent du modèle choisi.
 */
import { motion } from "motion/react";
import { Check } from "lucide-react";

export function AimeLoader({
  steps,
  active = 0,
  fading = false,
}: {
  /** Les étapes du projet en cours de construction. */
  steps: string[];
  /** Index de l'étape en cours ; les précédentes sont terminées. */
  active?: number;
  /** La séquence se termine : tout est prêt, on part vers le projet. */
  fading?: boolean;
}) {
  const list = steps.length ? steps : ["Construction de votre projet"];
  const shown = Math.min(active, list.length - 1);
  const progress = fading ? 1 : (shown + 1) / (list.length + 1);

  return (
    <motion.div
      animate={{ opacity: fading ? 0 : 1 }}
      transition={{ duration: 0.6 }}
      className="grid place-items-center py-10 text-center"
    >
      <div className="flex items-center gap-2 text-4xl font-semibold tracking-[-0.04em] md:text-6xl">
        <span className="text-white">AI</span>
        <motion.span
          animate={{ rotate: 360 }}
          transition={{ duration: 3.2, repeat: Infinity, ease: "linear" }}
          className="text-white/80"
          aria-hidden
        >
          +
        </motion.span>
        <span style={{ color: `rgba(255,255,255,${0.15 + progress * 0.85})` }}>ME</span>
      </div>

      <div
        className="mt-6 h-[3px] w-56 overflow-hidden rounded-full bg-white/20"
        role="progressbar"
        aria-valuenow={Math.round(progress * 100)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Construction du projet"
      >
        <motion.div
          className="h-full bg-white"
          animate={{ width: `${Math.round(progress * 100)}%` }}
          transition={{ duration: 0.6 }}
        />
      </div>

      <ul className="mt-6 space-y-1.5 text-left text-[13.5px] text-white/70">
        {list.slice(0, shown + 1).map((s, i) => {
          const finished = fading || i < shown;
          return (
            <motion.li
              key={s}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2"
            >
              <span
                aria-hidden
                className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${
                  finished ? "border-white bg-white text-black" : "border-white/40"
                }`}
              >
                {finished && <Check className="h-2.5 w-2.5" strokeWidth={3} />}
              </span>
              <span className={finished ? "text-white/85" : "text-white"}>{s}</span>
            </motion.li>
          );
        })}
      </ul>
    </motion.div>
  );
}
