/**
 * Canal unique d'ouverture de la feuille de retours.
 * Il n'existe qu'une seule porte : AIME → Aide & retours.
 */
const EVENT = "aime:feedback-sheet";

export function openFeedback() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onFeedback(handler: () => void) {
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}
