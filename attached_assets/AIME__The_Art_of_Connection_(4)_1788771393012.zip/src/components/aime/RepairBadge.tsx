import { useEffect, useState } from "react";
import { Wrench, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { visitorId } from "@/lib/aime/telemetry";
import { cn } from "@/lib/utils";

type Row = { id: string; status: string; label: string };

/**
 * Pastille centrale du header : elle n'apparaît que pour la personne concernée
 * par un incident, et dit honnêtement ce qui se passe.
 */
export function RepairBadge() {
  const { userId } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);

  useEffect(() => {
    let alive = true;
    const anon = visitorId();

    const load = async () => {
      const query = supabase
        .from("site_events")
        .select("id,status,label")
        .in("status", ["en_cours", "resolu_recemment"])
        .order("updated_at", { ascending: false })
        .limit(3);
      const { data } = userId ? await query.eq("user_id", userId) : await query.eq("anon_id", anon);
      if (alive) setRows((data as Row[]) ?? []);
    };

    void load();

    const channel = supabase
      .channel("repair-badge")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "site_events" },
        () => void load(),
      )
      .subscribe();

    return () => {
      alive = false;
      void supabase.removeChannel(channel);
    };
  }, [userId]);

  const active = rows[0];
  if (!active) return null;

  const repaired = active.status === "resolu_recemment";

  return (
    <div
      className={cn(
        "pointer-events-none hidden items-center gap-2 rounded-full px-3 py-1.5 text-[12px] font-medium sm:flex",
        repaired ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-800",
      )}
      title={active.label}
      aria-label={`${repaired ? "C'est réparé" : "On répare ça"} : ${active.label}`}
    >
      {repaired ? (
        <Check className="h-3.5 w-3.5" strokeWidth={2.2} />
      ) : (
        <Wrench className="h-3.5 w-3.5 animate-[spin_3s_linear_infinite]" strokeWidth={2} />
      )}
      {repaired ? "C'est réparé" : "On répare ça"}
    </div>
  );
}
