import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Paperclip } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { eventsQuery, threadQuery } from "@/lib/aime/queries";
import { ensureThread } from "@/lib/aime/messaging";
import { postMessage } from "@/lib/aime/chat";
import { ingestFile } from "@/lib/bureau/ingest";
import { foldersQuery } from "@/lib/bureau/queries";
import { bureauContextQuery } from "@/lib/bureau/context";
import { ensureThreadFolder, linkDocumentToMessage } from "@/lib/bureau/threadFolders";
import { openMessages } from "@/components/aime/messagesSheet";
import { cn } from "@/lib/utils";

type Base = {
  cardId: string;
  cardName: string;
  ownerId: string | null;
  userId: string | null;
};

function SignIn() {
  return (
    <p className="text-[13px] text-muted-foreground">
      Connectez-vous pour utiliser cette action.
    </p>
  );
}

/** Rattacher cette page à l'un de mes projets, en un clic. */
export function AddToProject({ cardId, cardName, userId }: Base) {
  const qc = useQueryClient();
  const { data: events = [] } = useQuery({ ...eventsQuery(userId), enabled: !!userId });
  const [busy, setBusy] = useState<string | null>(null);

  if (!userId) return <SignIn />;

  const add = async (eventId: string) => {
    setBusy(eventId);
    const { error } = await supabase
      .from("event_participants")
      .insert({ event_id: eventId, card_id: cardId, status: "invite", role_label: cardName });
    setBusy(null);
    if (error) {
      toast(error.message);
      return;
    }
    toast.success("Ajouté au projet");
    void qc.invalidateQueries({ queryKey: ["events"] });
  };

  if (events.length === 0) {
    return (
      <p className="text-[13px] text-muted-foreground">
        Vous n'avez pas encore de projet. Créez-en un depuis Mon espace, puis revenez ici.
      </p>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-[13px] text-muted-foreground">
        Choisissez le projet auquel rattacher {cardName}.
      </p>
      {events.slice(0, 12).map((e) => (
        <button
          key={e.id}
          type="button"
          disabled={busy === e.id}
          onClick={() => void add(e.id)}
          className="block w-full rounded-2xl hairline px-3.5 py-2.5 text-left text-[13.5px] hover:bg-secondary"
        >
          {e.title}
        </button>
      ))}
    </div>
  );
}

/** Recommander cette page à quelqu'un : partage natif, sinon lien copié. */
export function RecommendCard({ cardId, cardName }: Base) {
  const [to, setTo] = useState("");
  const url = typeof window === "undefined" ? "" : `${window.location.origin}/carte/${cardId}`;

  const send = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: cardName, url });
        toast.success("Recommandation envoyée");
        return;
      } catch {
        /* partage annulé */
      }
    }
    await navigator.clipboard.writeText(to.trim() ? `${to.trim()} — ${url}` : url);
    toast.success("Lien copié, prêt à être envoyé");
  };

  return (
    <div className="space-y-2">
      <input
        value={to}
        onChange={(e) => setTo(e.target.value)}
        placeholder="À qui ? (nom ou e-mail)"
        className="w-full rounded-full hairline bg-background px-4 py-2 text-[14px] outline-none"
      />
      <button
        type="button"
        onClick={() => void send()}
        className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
      >
        Recommander {cardName}
      </button>
    </div>
  );
}

/** Envoyer un document : il part dans la conversation et se range dans les documents. */
export function SendDocument({ cardId, cardName, ownerId, userId }: Base) {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const { data: folders = [] } = useQuery({ ...foldersQuery(userId), enabled: !!userId });
  const { data: ctx } = useQuery({ ...bureauContextQuery(userId), enabled: !!userId });

  const share = useMutation({
    mutationFn: async (file: File) => {
      if (!userId || !ownerId) throw new Error("Conversation indisponible.");
      const threadId = await ensureThread({
        me: userId,
        other: ownerId,
        cardId,
        subject: cardName,
      });
      const folderId = await ensureThreadFolder({
        userId,
        threadId,
        title: cardName,
        cardId,
      });
      const res = await ingestFile({
        file,
        userId,
        folders,
        folderId,
        ctx: ctx ?? null,
        onSoftError: () => undefined,
      });
      await postMessage({
        threadId,
        senderId: userId,
        body: res.understood || `Document partagé : ${file.name}`,
        kind: "document",
        attachmentName: file.name,
      });
      const last = await qc.fetchQuery(threadQuery(threadId));
      const message = [...last].reverse().find((m) => m.attachment_name === file.name);
      if (res.documentId && message) await linkDocumentToMessage(res.documentId, message.id);
      return threadId;
    },
    onSuccess: (threadId) => {
      toast.success("Document envoyé et rangé dans vos documents");
      void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
      void qc.invalidateQueries({ queryKey: ["threads"] });
      if (threadId) openMessages(threadId);
    },
    onError: (e: Error) => toast(e.message),
  });

  if (!userId) return <SignIn />;
  if (!ownerId)
    return (
      <p className="text-[13px] text-muted-foreground">
        Cette page n'a pas de destinataire pour recevoir un document.
      </p>
    );

  return (
    <div className="space-y-2">
      <p className="text-[13px] text-muted-foreground">
        Le fichier part dans votre conversation avec {cardName} et se range tout seul dans le
        dossier de l'échange.
      </p>
      <input
        ref={fileRef}
        type="file"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) share.mutate(f);
          e.target.value = "";
        }}
      />
      <button
        type="button"
        disabled={share.isPending}
        onClick={() => fileRef.current?.click()}
        className={cn(
          "flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground",
          share.isPending && "opacity-60",
        )}
      >
        <Paperclip className="h-4 w-4" strokeWidth={1.75} />
        {share.isPending ? "Envoi…" : "Choisir un document"}
      </button>
    </div>
  );
}
