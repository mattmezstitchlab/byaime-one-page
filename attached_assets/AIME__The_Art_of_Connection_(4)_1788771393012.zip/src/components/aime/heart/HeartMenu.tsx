import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "motion/react";
import { ArrowRight, Check, Heart, Pencil, X } from "lucide-react";
import type { FieldAction } from "@/components/aime/AimeField";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

/** Une ligne du fil de l'agent : ce qu'il a compris, horodaté, à confirmer. */
export type AgentNote = {
  id: string;
  at: number;
  /** Ce que l'utilisateur a demandé. */
  said: string;
  /** Ce que l'agent a compris, en une phrase. */
  understood: string;
  /** Un repère est prêt à être posé sur la ligne de temps. */
  confirmable: boolean;
  state: "attente" | "confirme" | "corrige";
};

function timeLabel(at: number) {
  return new Date(at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

/** Les familles du menu, dans l'ordre où elles se lisent. */
const GROUPS: { key: string; label: string | null }[] = [
  { key: "_", label: null },
  { key: "decouvrir", label: "Découvrir" },
  { key: "ensemble", label: "Travailler ensemble" },
  { key: "lien", label: "Rester en lien" },
  { key: "ma-page", label: "Ma page" },
];

function groupsOf(actions: FieldAction[]) {
  return GROUPS.map((g) => ({
    ...g,
    items: actions.filter((a) => (a.group ?? "_") === g.key),
  })).filter((g) => g.items.length > 0);
}

/**
 * Le cœur, posé au centre de la ligne de temps : un seul point d'entrée.
 * Au clic, tout se fait sur place — actions, écriture libre, et le fil de
 * l'agent qui demande confirmation avant de poser un repère.
 */
export function HeartMenu({
  open,
  onOpenChange,
  actions,
  active,
  onPick,
  value,
  onChange,
  onSubmit,
  placeholder = "Écrivez ce que vous cherchez…",
  notes,
  onConfirm,
  onCorrect,
  title,
  tone = "aime",
  context,
  children,
  inline = false,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  actions: FieldAction[];
  active?: string | null;
  onPick: (key: string) => void;
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  placeholder?: string;
  notes: AgentNote[];
  onConfirm: (note: AgentNote) => void;
  onCorrect: (note: AgentNote) => void;
  title?: string | undefined;
  /** Teinte du cœur : rouge AIME par défaut. */
  tone?: "ink" | "aime";
  /** Rappel de ce qui s'est déjà passé avec cette page. */
  context?: string | undefined;
  children?: ReactNode;
  /** Rend le déclencheur dans le flux, pour les barres de commandes. */
  inline?: boolean;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  const aime = tone === "aime";

  const panel = (
    <AnimatePresence>
        {open && (
          <>
            <motion.button
              type="button"
              aria-label="Fermer"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => onOpenChange(false)}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px]"
            />
            <motion.div
              ref={panelRef}
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.98 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
              className="fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[86vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-4xl hairline bg-card shadow-card sm:bottom-10 sm:rounded-4xl"
            >
              <div className="flex items-center justify-between gap-3 border-b border-hairline px-5 py-3.5">
                <p className="eyebrow">{title ?? "Que puis-je faire ?"}</p>
                <button
                  type="button"
                  onClick={() => onOpenChange(false)}
                  className="rounded-full hairline px-3 py-1 text-[12px] text-muted-foreground hover:bg-secondary"
                >
                  Fermer
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-5 py-4">
                {context && (
                  <p className="mb-3 rounded-2xl bg-secondary px-3.5 py-2 text-[12.5px] text-muted-foreground">
                    {context}
                  </p>
                )}
                <div className="space-y-4">
                  {groupsOf(actions).map((g) => (
                    <div key={g.key}>
                      {g.label && <p className="eyebrow mb-2">{g.label}</p>}
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {g.items.map((a) => {
                          const Icon = a.icon;
                          const on = a.key === active;
                          const off = !!a.disabled;
                          return (
                            <button
                              key={a.key}
                              type="button"
                              disabled={off}
                              title={off ? a.disabledReason : undefined}
                              onClick={() => onPick(a.key)}
                              className={cn(
                                "flex items-start gap-2 rounded-2xl px-3 py-2.5 text-left transition-colors",
                                off
                                  ? "cursor-default bg-secondary/60 text-muted-foreground"
                                  : on
                                    ? "bg-foreground text-background"
                                    : "hairline bg-background hover:bg-secondary",
                              )}
                            >
                              {Icon && (
                                <Icon className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
                              )}
                              <span className="min-w-0">
                                <span className="block truncate text-[13px] font-medium">
                                  {a.label}
                                </span>
                                {(off ? a.disabledReason : a.hint) && (
                                  <span
                                    className={cn(
                                      "block truncate text-[11.5px]",
                                      on && !off ? "text-background/70" : "text-muted-foreground",
                                    )}
                                  >
                                    {off ? a.disabledReason : a.hint}
                                  </span>
                                )}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                {children && <div className="mt-5">{children}</div>}

                {notes.length > 0 && (
                  <div className="mt-6 space-y-2">
                    <p className="eyebrow">L'agent</p>
                    {notes.map((n) => (
                      <div key={n.id} className="rounded-2xl hairline bg-background p-3.5">
                        <p className="text-[11.5px] tabular-nums text-muted-foreground">
                          {timeLabel(n.at)} · « {n.said} »
                        </p>
                        <p className="mt-1 text-[14px]">{n.understood}</p>
                        {n.state === "attente" && n.confirmable && (
                          <div className="mt-3 flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => onConfirm(n)}
                              className="flex items-center gap-1.5 rounded-full bg-primary px-3.5 py-1.5 text-[12.5px] text-primary-foreground"
                            >
                              <Check className="h-3.5 w-3.5" strokeWidth={2} /> Confirmer
                            </button>
                            <button
                              type="button"
                              onClick={() => onCorrect(n)}
                              className="flex items-center gap-1.5 rounded-full hairline px-3.5 py-1.5 text-[12.5px] text-muted-foreground hover:bg-secondary"
                            >
                              <Pencil className="h-3.5 w-3.5" strokeWidth={1.75} /> Corriger
                            </button>
                          </div>
                        )}
                        {n.state === "confirme" && (
                          <p className="mt-2 text-[12.5px] text-muted-foreground">
                            Posé sur la ligne de temps.
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="border-t border-hairline p-3">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    onSubmit();
                  }}
                  className="flex items-center gap-2 rounded-full hairline bg-background px-4 py-2"
                >
                  <input
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    placeholder={placeholder}
                    aria-label="Demander à l'agent"
                    className="min-w-0 flex-1 bg-transparent text-[14px] outline-none"
                  />
                  <button
                    type="submit"
                    aria-label="Demander"
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground"
                  >
                    <ArrowRight className="h-4 w-4" strokeWidth={2} />
                  </button>
                </form>
              </div>
            </motion.div>
          </>
        )}
    </AnimatePresence>
  );

  return (
    <>
      {/* Le cœur peut être ancré à la règle ou intégré à une barre de commandes. */}
      <div
        className={cn(
          inline
            ? "shrink-0"
            : "pointer-events-none absolute inset-x-0 -top-6 z-30 flex justify-center sm:-top-8",
        )}
      >
        <Button
          type="button"
          size="icon"
          variant={inline ? "outline" : "default"}
          aria-expanded={open}
          aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          title="AIME"
          onClick={() => onOpenChange(!open)}
          className={cn(
            "pointer-events-auto relative grid place-items-center rounded-full transition-transform hover:scale-105",
            inline ? "h-10 w-10" : "h-11 w-11 shadow-card sm:h-14 sm:w-14",
            aime && !inline
              ? "bg-aime text-primary-foreground"
              : open
                ? "bg-primary text-primary-foreground"
                : inline
                  ? ""
                  : "bg-foreground/55 text-background backdrop-blur-md",
          )}
        >
          {open ? (
            <X className="h-4 w-4 sm:h-5 sm:w-5" strokeWidth={1.75} />
          ) : (
            <Heart className="h-5 w-5 fill-current sm:h-6 sm:w-6" strokeWidth={1.75} />
          )}
        </Button>
      </div>

      {/* Le panneau vit dans le body : aucun parent transformé ne le rogne. */}
      {mounted ? createPortal(panel, document.body) : null}
    </>
  );
}
