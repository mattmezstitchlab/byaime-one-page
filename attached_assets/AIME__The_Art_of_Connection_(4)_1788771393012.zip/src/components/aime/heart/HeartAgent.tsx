import { useRef, useState } from "react";
import { Camera, Check, FileUp, Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { HeartMenu, type AgentNote } from "@/components/aime/heart/HeartMenu";
import type { FieldAction } from "@/components/aime/AimeField";
import { useAuth } from "@/hooks/useAuth";
import { analyzeDocument } from "@/lib/bureau/documents.functions";
import {
  applyProposal,
  proposalFromExtraction,
  type IngestProposal,
} from "@/lib/aime/world/ingestToProject";
import type { WorldProject } from "@/lib/aime/world/types";

async function toBase64(file: File) {
  const buf = new Uint8Array(await file.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  return btoa(bin);
}

const euro = (cents: number) =>
  (cents / 100).toLocaleString("fr-FR", { style: "currency", currency: "EUR" });

/**
 * Le cœur : le seul endroit où l'on donne quelque chose à AIME.
 * Une question, un fichier, une photo — l'agent lit, propose, on valide.
 * Rien n'est écrit avant le geste de validation.
 */
export function HeartAgent({
  open,
  onOpenChange,
  actions,
  onPick,
  value,
  onChange,
  onSubmit,
  notes,
  onCorrect,
  title,
  tone = "aime",
  project,
  onAdopt,
  contextLabel,
  inline = false,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  actions: FieldAction[];
  onPick: (key: string) => void;
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  notes: AgentNote[];
  onCorrect: (note: AgentNote) => void;
  title?: string | undefined;
  tone?: "ink" | "aime";
  project: WorldProject;
  /** Absent : la lecture est proposée mais l'ajout est verrouillé (démo). */
  onAdopt?: ((next: WorldProject, proposal: IngestProposal) => void | Promise<void>) | undefined;
  /** Ce que la personne regarde en ce moment : un repère, une période. */
  contextLabel?: string | undefined;
  /** Posé dans une barre de commandes plutôt qu'en flottant. */
  inline?: boolean;
  children?: React.ReactNode;
}) {
  const { userId } = useAuth();
  const file = useRef<HTMLInputElement>(null);
  const photo = useRef<HTMLInputElement>(null);
  const [reading, setReading] = useState(false);
  const [proposal, setProposal] = useState<IngestProposal | null>(null);
  const [edit, setEdit] = useState(false);

  async function read(f: File | null | undefined) {
    if (!f) return;
    if (!userId) {
      toast.error("Connectez-vous pour qu'AIME lise vos documents.");
      return;
    }
    setProposal(null);
    setReading(true);
    try {
      const ext = await analyzeDocument({
        data: { fileName: f.name, mimeType: f.type || "application/pdf", base64: await toBase64(f) },
      });
      setProposal(proposalFromExtraction(ext, f.name, project));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Lecture impossible.");
    } finally {
      setReading(false);
    }
  }

  async function adopt() {
    if (!proposal) return;
    if (!onAdopt) {
      toast.info("Cette page est une démonstration : rien n'y est enregistré.");
      return;
    }
    await onAdopt(applyProposal(project, proposal), proposal);
    setProposal(null);
    setEdit(false);
    onOpenChange(false);
    toast.success("Ajouté au projet — visible sur la ligne de temps.");
  }

  return (
    <HeartMenu
      inline={inline}
      open={open}
      onOpenChange={onOpenChange}
      actions={actions}
      onPick={onPick}
      value={value}
      onChange={onChange}
      onSubmit={onSubmit}
      placeholder="Que souhaitez-vous ajouter ou demander à AIME ?"
      notes={notes}
      onConfirm={() => {}}
      onCorrect={onCorrect}
      title={title ?? "Demander à AIME"}
      tone={tone}
    >
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => file.current?.click()}
            className="flex items-center gap-2 rounded-full hairline bg-background px-3.5 py-2 text-[13px]"
          >
            <FileUp className="h-4 w-4" strokeWidth={1.75} /> Joindre un fichier
          </button>
          <button
            type="button"
            onClick={() => photo.current?.click()}
            className="flex items-center gap-2 rounded-full hairline bg-background px-3.5 py-2 text-[13px]"
          >
            <Camera className="h-4 w-4" strokeWidth={1.75} /> Prendre une photo
          </button>
          {reading && (
            <span className="flex items-center gap-2 text-[12.5px] text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> AIME lit le document…
            </span>
          )}
        </div>

        {contextLabel && !proposal && (
          <p className="text-[12.5px] text-muted-foreground">
            Vous regardez « {contextLabel} » : ce que vous déposez pourra y être rattaché.
          </p>
        )}

        <input
          ref={file}
          type="file"
          accept="application/pdf,image/*"
          className="hidden"
          onChange={(e) => {
            void read(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
        <input
          ref={photo}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            void read(e.target.files?.[0]);
            e.target.value = "";
          }}
        />

        {proposal && (
          <div className="rounded-2xl hairline bg-background p-4">
            <p className="eyebrow">J'ai reconnu ce document</p>
            <p className="mt-1 text-[15px] font-medium">{proposal.headline}</p>

            {edit ? (
              <div className="mt-3 space-y-2">
                <input
                  value={proposal.document.title}
                  onChange={(e) =>
                    setProposal({
                      ...proposal,
                      document: { ...proposal.document, title: e.target.value },
                    })
                  }
                  aria-label="Titre du document"
                  className="w-full rounded-xl hairline bg-card px-3 py-2 text-[14px] outline-none"
                />
                {proposal.provider && (
                  <input
                    value={proposal.provider.name ?? ""}
                    onChange={(e) =>
                      setProposal({
                        ...proposal,
                        provider: { ...proposal.provider!, name: e.target.value },
                      })
                    }
                    aria-label="Prestataire"
                    className="w-full rounded-xl hairline bg-card px-3 py-2 text-[14px] outline-none"
                  />
                )}
                {proposal.document.amountCents != null && (
                  <input
                    type="number"
                    step="0.01"
                    value={(proposal.document.amountCents / 100).toString()}
                    onChange={(e) => {
                      const cents = Math.round(Number(e.target.value) * 100);
                      if (!Number.isFinite(cents)) return;
                      setProposal({
                        ...proposal,
                        document: { ...proposal.document, amountCents: cents },
                        payments: proposal.payments.map((p) => ({ ...p, amountCents: cents })),
                      });
                    }}
                    aria-label="Montant en euros"
                    className="w-full rounded-xl hairline bg-card px-3 py-2 text-[14px] outline-none"
                  />
                )}
              </div>
            ) : (
              <dl className="mt-3 grid gap-1.5">
                {proposal.recap.map((r) => (
                  <div key={r.label} className="flex justify-between gap-4 text-[13.5px]">
                    <dt className="text-muted-foreground">{r.label}</dt>
                    <dd className="text-right">{r.value}</dd>
                  </div>
                ))}
                {proposal.payments.map((p) => (
                  <div key={p.id} className="flex justify-between gap-4 text-[13.5px]">
                    <dt className="text-muted-foreground">Échéance</dt>
                    <dd className="text-right">
                      {euro(p.amountCents)} · {p.state === "paye" ? "réglé" : "à régler"}
                    </dd>
                  </div>
                ))}
              </dl>
            )}

            <p className="mt-3 text-[12.5px] text-muted-foreground">
              À ajouter dans : {proposal.targets.join(" · ")}
            </p>
            {proposal.uncertain.length > 0 && (
              <p className="mt-1 text-[12.5px] text-muted-foreground">
                À vérifier : {proposal.uncertain.join(", ")}
              </p>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => void adopt()}
                className="flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
              >
                <Check className="h-4 w-4" strokeWidth={2} /> Ajouter au projet
              </button>
              <button
                type="button"
                onClick={() => setEdit((v) => !v)}
                className="flex items-center gap-1.5 rounded-full hairline px-4 py-2 text-[13px] text-muted-foreground hover:bg-secondary"
              >
                <Pencil className="h-3.5 w-3.5" strokeWidth={1.75} /> {edit ? "Terminer" : "Modifier"}
              </button>
            </div>
          </div>
        )}

        {children}
      </div>
    </HeartMenu>
  );
}
