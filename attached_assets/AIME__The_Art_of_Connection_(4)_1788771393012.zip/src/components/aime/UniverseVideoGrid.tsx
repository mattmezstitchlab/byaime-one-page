import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, X } from "lucide-react";
import { universeVideo } from "@/lib/aime/universeMedia";
import { universePoster } from "@/lib/aime/universePoster";
import { UNIVERSE_TREE, type UniverseNode } from "@/lib/aime/universeTree";
import { useQuery } from "@tanstack/react-query";
import { cardsQuery, categoriesQuery } from "@/lib/aime/queries";
import { worldsForTrade, type WorldSlug } from "@/lib/aime/tradeWorlds";
import { recordSignal } from "@/lib/aime/exploration";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import type { Card } from "@/lib/aime/types";
import { CardOverlay } from "./CardPreview";

function UniverseTile({
  universe,
  index,
  onOpenCard,
}: {
  universe: UniverseNode;
  index: number;
  onOpenCard: (card: Card) => void;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  const holder = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const { userId } = useAuth();

  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: categories = [] } = useQuery(categoriesQuery);

  /**
   * Le verso n'est plus une hiérarchie conceptuelle : il liste les métiers
   * réellement présents dans ce monde, avec leur nombre de résultats.
   */
  const trades = useMemo(() => {
    const label = new Map(categories.map((c) => [c.slug, c.label]));
    const counts = new Map<string, number>();
    for (const c of cards) {
      if (!c.category_slug) continue;
      if (!worldsForTrade(c.category_slug).includes(universe.slug as WorldSlug)) continue;
      counts.set(c.category_slug, (counts.get(c.category_slug) ?? 0) + 1);
    }
    return [...counts.entries()]
      .map(([slug, count]) => ({ slug, label: label.get(slug) ?? slug, count }))
      .sort((a, b) => b.count - a.count);
  }, [cards, categories, universe.slug]);


  // La vidéo n'est montée (et donc téléchargée) qu'une fois la tuile réellement visible.
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    const el = holder.current;
    if (!el || armed) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setArmed(true);
          io.disconnect();
        }
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [armed]);

  const play = () => {
    const el = ref.current;
    if (el && !open) void el.play().catch(() => {});
  };
  const pause = () => {
    const el = ref.current;
    if (el) el.pause();
  };

  return (
    <motion.div
      ref={holder}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.06 }}
      onMouseEnter={play}
      onMouseLeave={pause}
      className="relative overflow-hidden rounded-4xl hairline bg-card shadow-card"
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        onFocus={play}
        onBlur={pause}
        aria-expanded={open}
        aria-label={`Voir les sous-univers de ${universe.label}`}
        className="group block w-full text-left"
      >
        {armed ? (
          <video
            ref={ref}
            src={universeVideo(universe.video)}
            poster={universePoster(universe.slug)}
            muted
            loop
            playsInline
            preload="none"
            aria-hidden
            className="aspect-4/5 w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <img
            src={universePoster(universe.slug)}
            alt=""
            loading="lazy"
            className="aspect-4/5 w-full object-cover"
          />
        )}

        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 bg-gradient-to-t from-foreground/75 to-transparent p-5">
          <h3 className="text-[20px] font-semibold tracking-[-0.02em] text-background">
            {universe.label}
          </h3>
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-background/95 transition-transform group-hover:-translate-y-0.5">
            <ArrowUpRight className="h-4 w-4 text-foreground" strokeWidth={1.75} />
          </span>
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="absolute inset-0 flex flex-col bg-foreground/95 p-4 text-background backdrop-blur-sm sm:p-5"
          >
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-[17px] font-semibold tracking-[-0.02em] sm:text-[19px]">
                {universe.label}
              </h3>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Fermer"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-background/15 transition-colors hover:bg-background/25"
              >
                <X className="h-4 w-4" strokeWidth={1.75} />
              </button>
            </div>

            <div className="scrollbar-dark mt-3 min-h-0 flex-1 overflow-y-auto pr-1">
              {trades.length === 0 ? (
                <p className="px-1 text-[13.5px] text-background/75">
                  Personne n'a encore rejoint ce monde.
                </p>
              ) : (
                <ul className="space-y-0">
                  {trades.map((trade, i) => (
                    <motion.li
                      key={trade.slug}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.28, delay: 0.04 + i * 0.035 }}
                    >
                      <Link
                        to="/reseau"
                        search={{ monde: universe.slug, metier: trade.slug }}
                        onClick={() =>
                          recordSignal(
                            { universe: universe.slug, sub: trade.slug, kind: "clic" },
                            userId,
                          )
                        }
                        className="flex w-full items-center gap-2 rounded-xl px-2.5 py-1 text-left text-[13.5px] leading-tight text-background/85 transition-colors hover:bg-background/10 hover:text-background sm:text-[14px]"
                      >
                        <span className="flex-1">{trade.label}</span>
                        <span className="tabular-nums text-background/60">{trade.count}</span>
                      </Link>
                    </motion.li>
                  ))}
                </ul>
              )}
            </div>


            <Link
              to="/reseau"
              search={{ monde: universe.slug }}
              onClick={() => recordSignal({ universe: universe.slug, kind: "clic" }, userId)}
              className="mt-3 flex items-center justify-between gap-3 rounded-full bg-background px-4 py-2.5 text-[13.5px] font-medium text-foreground sm:text-[14px]"
            >
              Voir tout {universe.label}
              <ArrowUpRight className="h-4 w-4" strokeWidth={1.75} />
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/**
 * Bande horizontale des 12 mondes : défilement automatique lent, arrêté au
 * survol/toucher, et défilement manuel (drag, molette, flèches clavier).
 */
export function UniverseVideoGrid() {
  const track = useRef<HTMLDivElement>(null);
  const [opened, setOpened] = useState<Card | null>(null);
  const paused = useRef(false);
  const drag = useRef<{ x: number; left: number } | null>(null);

  useEffect(() => {
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const step = () => {
      const el = track.current;
      if (el && !paused.current && !drag.current) {
        // La bande est doublée : on reboucle sans à-coup à la moitié.
        const half = el.scrollWidth / 2;
        el.scrollLeft = el.scrollLeft >= half ? el.scrollLeft - half + 0.4 : el.scrollLeft + 0.4;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);

  const nudge = (dir: 1 | -1) => {
    track.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
  };

  return (
    <div
      className="relative mt-8 sm:mt-10"
      onMouseEnter={() => (paused.current = true)}
      onMouseLeave={() => {
        paused.current = false;
        drag.current = null;
      }}
      onTouchStart={() => (paused.current = true)}
      onTouchEnd={() => (paused.current = false)}
    >
      <div
        ref={track}
        role="region"
        aria-label="Les douze mondes AIME"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") nudge(1);
          if (e.key === "ArrowLeft") nudge(-1);
        }}
        onPointerDown={(e) => {
          const el = track.current;
          if (!el) return;
          drag.current = { x: e.clientX, left: el.scrollLeft };
        }}
        onPointerMove={(e) => {
          const el = track.current;
          if (!el || !drag.current) return;
          el.scrollLeft = drag.current.left - (e.clientX - drag.current.x);
        }}
        onPointerUp={() => (drag.current = null)}
        onFocusCapture={() => (paused.current = true)}
        onBlurCapture={() => (paused.current = false)}
        className="no-scrollbar flex gap-4 overflow-x-auto px-1 pb-2 sm:gap-6"
        style={{ scrollbarWidth: "none" }}
      >
        {[0, 1].map((copy) =>
          UNIVERSE_TREE.map((u, i) => (
            <div
              key={`${copy}-${u.slug}`}
              aria-hidden={copy === 1 || undefined}
              {...(copy === 1 ? { inert: "" as unknown as boolean } : {})}
              className="w-[240px] shrink-0 sm:w-[280px] lg:w-[300px]"
            >
              <UniverseTile universe={u} index={i} onOpenCard={setOpened} />
            </div>
          )),
        )}
      </div>

      <button
        type="button"
        onClick={() => nudge(-1)}
        aria-label="Monde précédent"
        className="absolute top-1/2 -left-2 hidden h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-background/90 shadow-card hairline md:grid"
      >
        <ArrowUpRight className="h-4 w-4 -rotate-135" strokeWidth={1.75} />
      </button>
      <button
        type="button"
        onClick={() => nudge(1)}
        aria-label="Monde suivant"
        className="absolute top-1/2 -right-2 hidden h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-background/90 shadow-card hairline md:grid"
      >
        <ArrowUpRight className="h-4 w-4 rotate-45" strokeWidth={1.75} />
      </button>

      {opened && <CardOverlay card={opened} onClose={() => setOpened(null)} />}
    </div>
  );
}
