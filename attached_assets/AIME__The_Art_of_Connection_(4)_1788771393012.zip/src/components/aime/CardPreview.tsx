import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { CalendarDays, FileText, Heart, Layers, MessageCircle, X } from "lucide-react";
import type { Card } from "@/lib/aime/types";
import { cardVisual } from "@/lib/aime/visuals";
import { immersiveVisual } from "@/lib/aime/universeVisuals";
import { useAimes } from "@/hooks/useAimes";
import { cn } from "@/lib/utils";

import { AimeCard } from "./AimeCard";
import { openMessages } from "@/components/aime/messagesSheet";

type Slide =
  | { kind: "video"; src: string; label: string }
  | { kind: "image"; src: string; label: string }
  | { kind: "audio"; label: string }
  | { kind: "note"; label: string; text: string };

/** Les médias d'un coup d'œil : ce que la carte porte déjà, sans nouveau champ. */
function slidesOf(card: Card): Slide[] {
  const out: Slide[] = [];
  if (card.video_url) out.push({ kind: "video", src: card.video_url, label: "Vidéo" });
  out.push({ kind: "image", src: cardVisual(card), label: "Visuel" });
  const universe = card.universes?.[0];
  if (universe) {
    const alt = immersiveVisual(card);
    if (alt && alt !== cardVisual(card)) out.push({ kind: "image", src: alt, label: universe });
  }
  if (card.experiences?.length) {
    out.push({ kind: "note", label: "Projets", text: card.experiences.slice(0, 3).join(" · ") });
  }
  if (card.skills?.length) {
    out.push({ kind: "note", label: "Savoir-faire", text: card.skills.slice(0, 4).join(" · ") });
  }
  return out;
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const m = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(m.matches);
    const on = () => setReduced(m.matches);
    m.addEventListener("change", on);
    return () => m.removeEventListener("change", on);
  }, []);
  return reduced;
}

export const GLANCE_WIDTH = 268;

/**
 * L'habillage du coup d'œil : bulle noire posée au-dessus du point (ou en
 * dessous quand l'écran manque de place), jamais hors cadre, et posée en bas
 * de l'écran sur téléphone. Partagée par le Monde AIME et la carte du Réseau.
 */
export function GlanceBubble({
  anchor,
  mobile = false,
  children,
  ...rest
}: {
  anchor: { top: number; bottom: number; left: number };
  mobile?: boolean;
  children: React.ReactNode;
} & React.HTMLAttributes<HTMLDivElement>) {
  const vw = typeof window === "undefined" ? 1280 : window.innerWidth;
  const vh = typeof window === "undefined" ? 800 : window.innerHeight;
  const below = anchor.top < 260;
  const style = mobile
    ? undefined
    : {
        width: GLANCE_WIDTH,
        left: Math.min(Math.max(anchor.left, GLANCE_WIDTH / 2 + 8), vw - GLANCE_WIDTH / 2 - 8),
        ...(below ? { top: anchor.bottom + 8 } : { bottom: vh - anchor.top + 8 }),
      };

  return (
    <div
      {...rest}
      data-glance=""
      style={style}
      className={cn(
        "pointer-events-auto fixed z-[60] rounded-2xl border border-white/15 bg-black/80 p-3 text-white shadow-2xl backdrop-blur-xl",
        mobile ? "inset-x-3 bottom-3" : "-translate-x-1/2",
        rest.className,
      )}
    >
      {children}
    </div>
  );
}

/**
 * Le coup d'œil : bulle sombre partagée par la grille du Monde AIME,
 * les pins de la carte et la timeline. Le switch ouvre la vraie carte universelle.
 */
export function CardGlance({
  card,
  onClose,
  showClose = false,
}: {
  card: Card;
  onClose?: () => void;
  showClose?: boolean;
}) {
  const slides = useMemo(() => slidesOf(card), [card]);
  const reduced = useReducedMotion();
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => setI(0), [card.id]);

  useEffect(() => {
    if (reduced || paused || slides.length < 2) return;
    const t = window.setInterval(() => setI((v) => (v + 1) % slides.length), 3400);
    return () => window.clearInterval(t);
  }, [reduced, paused, slides.length]);

  const slide = slides[Math.min(i, slides.length - 1)];

  return (
    <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="relative mb-2 h-24 w-full overflow-hidden rounded-xl bg-white/10">
        {slide?.kind === "video" && (
          <video
            src={slide.src}
            autoPlay
            muted
            loop
            playsInline
            className="h-full w-full object-cover"
          />
        )}
        {slide?.kind === "image" && (
          <img src={slide.src} alt="" loading="lazy" className="h-full w-full object-cover" />
        )}
        {slide?.kind === "audio" && (
          <div className="flex h-full items-end justify-center gap-[3px] px-3 py-4">
            {[6, 14, 9, 20, 12, 24, 8, 17, 11, 22].map((h, k) => (
              <span
                key={k}
                className="animate-audio-wave w-[3px] rounded-full bg-aime/90"
                style={{ height: h, animationDelay: `${(k % 6) * 0.11}s` }}
              />
            ))}
          </div>
        )}
        {slide?.kind === "note" && (
          <p className="flex h-full items-center px-3 text-[12px] leading-snug text-white/85">
            {slide.text}
          </p>
        )}

        {slides.length > 1 && (
          <div className="absolute inset-x-0 bottom-1.5 flex justify-center gap-1">
            {slides.map((s, k) => (
              <button
                key={`${s.label}-${k}`}
                type="button"
                aria-label={s.label}
                onClick={() => setI(k)}
                className={cn(
                  "h-1 rounded-full transition-all",
                  k === i ? "w-4 bg-white" : "w-1 bg-white/45 hover:bg-white/70",
                )}
              />
            ))}
          </div>
        )}
      </div>

      <p className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.16em] text-white/55">
        <span className="h-1.5 w-1.5 rounded-full bg-aime" />
        {[card.universes?.[0], card.city].filter(Boolean).join(" · ") || "Carte AIME"}
      </p>
      <p className="mt-1 text-[14px] font-medium leading-snug">{card.name}</p>
      {card.headline && (
        <p className="mt-0.5 line-clamp-2 text-[12px] leading-snug text-white/70">
          {card.headline}
        </p>
      )}

      <div className="mt-3 flex flex-wrap gap-1.5 border-t border-white/10 pt-2.5">
        <Link
          to="/carte/$id"
          params={{ id: card.id }}
          className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-[12px] font-medium text-black transition-opacity hover:opacity-90"
        >
          <Heart className="h-3.5 w-3.5" strokeWidth={1.9} /> Voir la page
        </Link>
        <Link
          to="/carte/$id"
          params={{ id: card.id }}
          search={{ onglet: "devis" }}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
        >
          <FileText className="h-3.5 w-3.5" strokeWidth={1.9} /> Devis
        </Link>
        <Link
          to="/carte/$id"
          params={{ id: card.id }}
          search={{ onglet: "calendrier" }}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
        >
          <CalendarDays className="h-3.5 w-3.5" strokeWidth={1.9} /> Dispos
        </Link>
        <button
          type="button"
          onClick={() => openMessages()}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
        >
          <MessageCircle className="h-3.5 w-3.5" strokeWidth={1.9} /> Écrire
        </button>
      </div>

      {showClose && onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Fermer l'aperçu"
          className="absolute top-2 right-2 grid h-6 w-6 place-items-center rounded-full bg-white/12 text-white/70 transition-colors hover:bg-white/25 hover:text-white"
        >
          <X className="h-3.5 w-3.5" strokeWidth={2} />
        </button>
      )}
    </div>
  );
}

/** La vraie carte universelle, recto/verso, ouverte par-dessus sans quitter la page. */
export function CardOverlay({ card, onClose }: { card: Card; onClose: () => void }) {
  const { isLiked, intentsByCard, toggle } = useAimes();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[70] grid place-items-center bg-black/60 p-4 backdrop-blur-sm"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-label={`Carte de ${card.name}`}
    >
      <div className="relative w-full max-w-[330px]">
        <AimeCard
          card={card}
          liked={isLiked(card.id)}
          activeIntents={intentsByCard.get(card.id) ?? []}
          onIntent={(intent, message) => toggle(card.id, intent, message)}
          priority
        />
        <button
          type="button"
          onClick={onClose}
          aria-label="Fermer la carte"
          className="absolute -top-3 -right-3 grid h-9 w-9 place-items-center rounded-full bg-white text-black shadow-lg transition-transform hover:scale-105"
        >
          <X className="h-4 w-4" strokeWidth={2} />
        </button>
      </div>
    </div>
  );
}
