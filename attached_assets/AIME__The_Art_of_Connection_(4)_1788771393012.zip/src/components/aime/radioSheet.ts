/**
 * Petit canal d'événements pour ouvrir la radio en feuille sur téléphone,
 * sans faire remonter d'état jusqu'à AppShell.
 */
const EVENT = "aime:radio-sheet";

export function openRadioSheet() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onRadioSheet(handler: () => void) {
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}
