import { useEffect, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { askSupport } from "@/lib/aime/support.functions";
import { availableHelpers } from "@/lib/aime/ambassadors";
import { recordEvent } from "@/lib/aime/telemetry";
import { CreditTag } from "@/components/aime/CreditTag";
import { toast } from "sonner";
import { Bug, Lightbulb, HelpCircle, Heart, X } from "lucide-react";
import { onFeedback } from "@/components/aime/feedbackSheet";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

/** Les quatre natures de retour de la bêta, en langage d'usage. */
export const FEEDBACK_KINDS = [
  { value: "bug", label: "Ça ne marche pas", icon: Bug },
  { value: "idee", label: "J'ai une idée", icon: Lightbulb },
  { value: "confusion", label: "Je n'ai pas compris", icon: HelpCircle },
  { value: "coup-de-coeur", label: "Coup de cœur", icon: Heart },
] as const;

export type FeedbackKind = (typeof FEEDBACK_KINDS)[number]["value"];

const field =
  "w-full rounded-2xl hairline bg-background px-3.5 py-2.5 text-[14px] outline-none placeholder:text-muted-foreground";

/** Formulaire de retour, réutilisable dans la feuille flottante et sur /beta. */
export function FeedbackForm({
  page,
  onSent,
  compact = false,
}: {
  page: string;
  onSent?: () => void;
  compact?: boolean;
}) {
  const { userId, user } = useAuth();
  const [kind, setKind] = useState<FeedbackKind>("bug");
  const [message, setMessage] = useState("");
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");

  const send = useMutation({
    mutationFn: async () => {
      const body = message.trim();
      if (body.length < 3) throw new Error("court");
      const { error } = await supabase.from("beta_feedback").insert({
        author_id: userId ?? null,
        kind,
        message: body,
        page,
        name: name.trim() || null,
        contact: contact.trim() || user?.email || null,
        status: "nouveau",
        supports: 0,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setMessage("");
      toast("Merci — votre retour est arrivé");
      onSent?.();
    },
    onError: (e: Error) =>
      toast(e.message === "court" ? "Écrivez quelques mots de plus" : "Envoi impossible"),
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        send.mutate();
      }}
      className="space-y-2.5"
    >
      <div className="flex flex-wrap gap-1.5">
        {FEEDBACK_KINDS.map((k) => (
          <button
            key={k.value}
            type="button"
            onClick={() => setKind(k.value)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] font-medium transition-colors",
              kind === k.value ? "bg-primary text-primary-foreground" : "hairline bg-card",
            )}
          >
            <k.icon className="h-3.5 w-3.5" strokeWidth={1.9} />
            {k.label}
          </button>
        ))}
      </div>

      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        rows={compact ? 3 : 4}
        placeholder="Ce que vous avez vu, ce que vous attendiez…"
        className={cn(field, "resize-none")}
      />

      <div className="grid gap-2 sm:grid-cols-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Votre prénom (facultatif)"
          className={field}
        />
        <input
          value={contact}
          onChange={(e) => setContact(e.target.value)}
          placeholder="E-mail pour la réponse (facultatif)"
          className={field}
        />
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-[12px] text-muted-foreground">Page : {page}</p>
        <button
          type="submit"
          disabled={send.isPending}
          className="rounded-full bg-primary px-5 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-60"
        >
          {send.isPending ? "Envoi…" : "Envoyer"}
        </button>
      </div>
    </form>
  );
}

type Msg = { mine: boolean; text: string };

/**
 * Bouton flottant présent sur tout le site pendant la bêta.
 * Ce n'est plus un formulaire : c'est une conversation avec Aime, qui garde
 * la trace du problème et, quand il le faut, propose une vraie personne.
 */
export function FeedbackSheet() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { userId, user } = useAuth();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      mine: false,
      text: "Racontez-moi ce qui coince — en vos mots, même approximatifs. Si une solution existe, je vous la donne tout de suite.",
    },
  ]);
  const [draft, setDraft] = useState("");
  const [options, setOptions] = useState<string[]>([]);
  const [needsHuman, setNeedsHuman] = useState(false);
  /** Deux natures de retour, rien de plus : un problème, ou une idée. */
  const [tone, setTone] = useState<"bug" | "idee">("bug");

  const { data: helpers = [] } = useQuery({
    queryKey: ["helpers-online"],
    enabled: open && needsHuman,
    queryFn: () => availableHelpers(4),
    refetchInterval: 60_000,
  });

  // Une seule porte : AIME → Aide & retours.
  useEffect(() => onFeedback(() => setOpen(true)), []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);


  const ask = useMutation({
    mutationFn: async (text: string) => {
      const transcript = [...msgs, { mine: true, text }].slice(-12);
      const reply = await askSupport({ data: { transcript, route: pathname } });

      // On garde toujours la trace, même quand Aime a su répondre.
      await supabase.from("beta_feedback").insert({
        author_id: userId ?? null,
        kind: tone === "idee" ? "idee" : reply.needsHuman ? "bug" : "confusion",
        message: `${text}\n\n— Aime : ${reply.reply}`,
        page: pathname,
        name: null,
        contact: user?.email ?? null,
        status: reply.solved ? "repondu" : "nouveau",
        supports: 0,
      });
      if (!reply.solved) {
        void recordEvent({
          kind: "blocage",
          label: text.slice(0, 200),
          route: pathname,
          userId,
          payload: { resume: reply.summary },
        });
      }
      return reply;
    },
    onMutate: (text: string) => {
      setMsgs((m) => [...m, { mine: true, text }]);
      setDraft("");
      setOptions([]);
    },
    onSuccess: (reply) => {
      setMsgs((m) => [...m, { mine: false, text: reply.reply }]);
      setOptions(reply.options ?? []);
      setNeedsHuman(reply.needsHuman);
    },
    onError: (e: Error) => {
      setMsgs((m) => [...m, { mine: false, text: e.message }]);
    },
  });

  const submit = (text: string) => {
    const value = text.trim();
    if (value.length < 3 || ask.isPending) return;
    ask.mutate(value);
  };

  return (
    <>
      {open && (

        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/40 p-3 backdrop-blur-sm md:items-center">
          <div className="flex max-h-[88vh] w-full max-w-lg flex-col rounded-3xl hairline bg-card p-5 shadow-2xl">
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <p className="eyebrow">Bêta AIME</p>
                <h2 className="text-[19px] font-semibold tracking-[-0.02em]">
                  Aide &amp; retours
                  <CreditTag feature="chat" />
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Fermer"
                className="grid h-8 w-8 place-items-center rounded-full hairline"
              >
                <X className="h-4 w-4" strokeWidth={1.9} />
              </button>
            </div>

            <div className="mb-3 flex gap-1.5">
              {(
                [
                  { key: "bug", label: "Signaler un problème", icon: Bug },
                  { key: "idee", label: "Partager une idée", icon: Lightbulb },
                ] as const
              ).map((o) => (
                <button
                  key={o.key}
                  type="button"
                  aria-pressed={tone === o.key}
                  onClick={() => setTone(o.key)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] transition-colors",
                    tone === o.key
                      ? "bg-foreground text-background"
                      : "hairline bg-background text-muted-foreground hover:text-foreground",
                  )}
                >
                  <o.icon className="h-3.5 w-3.5" strokeWidth={1.9} />
                  {o.label}
                </button>
              ))}
            </div>



            <div className="flex-1 space-y-2 overflow-y-auto pr-1">
              {msgs.map((m, i) => (
                <div
                  key={i}
                  className={cn(
                    "max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[14px] leading-relaxed",
                    m.mine
                      ? "ml-auto bg-foreground text-background"
                      : "hairline bg-background text-foreground",
                  )}
                >
                  {m.text}
                </div>
              ))}
              {ask.isPending && (
                <p className="text-[12.5px] text-muted-foreground">Aime réfléchit…</p>
              )}

              {needsHuman && (
                <div className="rounded-2xl hairline bg-background p-3">
                  <p className="text-[13px] font-medium">Quelqu'un est déjà passé par là</p>
                  <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                    Ces membres sont en ligne et ont accepté d'aider. Vous pouvez leur écrire.
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    {helpers.length === 0 && (
                      <p className="text-[12.5px] text-muted-foreground">
                        Personne en ligne à l'instant — votre retour est enregistré.
                      </p>
                    )}
                    {helpers.map((h) => (
                      <span
                        key={h.user_id}
                        title={`${h.display_name ?? "Membre AIME"}${h.city ? ` · ${h.city}` : ""}`}
                        className="grid h-9 w-9 place-items-center overflow-hidden rounded-full hairline bg-card text-[12px] font-semibold"
                      >
                        {h.avatar_url ? (
                          <img
                            src={h.avatar_url}
                            alt={h.display_name ?? "Membre AIME"}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          (h.display_name ?? "A").slice(0, 1).toUpperCase()
                        )}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {options.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {options.map((o) => (
                  <button
                    key={o}
                    type="button"
                    onClick={() => submit(o)}
                    className="rounded-full hairline bg-background px-3 py-1.5 text-[12.5px]"
                  >
                    {o}
                  </button>
                ))}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit(draft);
              }}
              className="mt-3 flex items-end gap-2"
            >
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    submit(draft);
                  }
                }}
                rows={2}
                placeholder="Ce que vous avez vu, ce que vous attendiez…"
                className={cn(field, "resize-none")}
              />
              <button
                type="submit"
                disabled={ask.isPending}
                className="rounded-full bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-60"
              >
                Envoyer
              </button>
            </form>

            <p className="mt-2 text-[12px] text-muted-foreground">
              Page : {pathname}
            </p>
          </div>
        </div>
      )}
    </>
  );
}
