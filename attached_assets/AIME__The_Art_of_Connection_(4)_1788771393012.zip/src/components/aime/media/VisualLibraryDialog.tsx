import { useEffect, useMemo, useState } from "react";
import { ImagePlus, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { UNIVERSE_TREE } from "@/lib/aime/universeTree";
import {
  allVisualLibrary,
  visualLibraryForDomain,
  visualLibraryForUniverse,
  visualKeyFromUrl,
} from "@/lib/aime/visuals";

function dbUniverseFor(nodeSlug: string): string | null {
  const node = UNIVERSE_TREE.find((u) => u.slug === nodeSlug);
  if (!node) return null;
  return node.db.find((slug) => visualLibraryForUniverse(slug).length > 0) ?? node.db[0] ?? null;
}

export function VisualLibraryDialog({
  open,
  onOpenChange,
  selectedUniverse,
  selectedDomain,
  onPick,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedUniverse: string | null;
  selectedDomain: string | null;
  onPick: (picked: { key: string | null; url: string }) => void;
}) {
  const [universe, setUniverse] = useState<string>(selectedUniverse ?? "");
  const [domain, setDomain] = useState<string>(selectedDomain ?? "");

  useEffect(() => {
    if (!open) return;
    setUniverse(selectedUniverse ?? "");
    setDomain(selectedDomain ?? "");
  }, [open, selectedUniverse, selectedDomain]);

  const domains = useMemo(() => {
    const node = UNIVERSE_TREE.find((u) => u.slug === universe);
    return node?.subs ?? [];
  }, [universe]);

  const visuals = useMemo(() => {
    const byDomain = visualLibraryForDomain(domain);
    if (byDomain.length > 0) return byDomain;
    const dbUniverse = dbUniverseFor(universe);
    const byUniverse = visualLibraryForUniverse(dbUniverse);
    if (byUniverse.length > 0) return byUniverse;
    return allVisualLibrary();
  }, [domain, universe]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Bibliothèque visuelle AIME</DialogTitle>
        </DialogHeader>

        <div className="grid gap-2 sm:grid-cols-2">
          <label className="space-y-1 text-[12px] text-muted-foreground">
            Univers
            <select
              value={universe}
              onChange={(e) => {
                setUniverse(e.target.value);
                setDomain("");
              }}
              className="w-full rounded-xl border bg-background px-3 py-2 text-[14px] text-foreground outline-none"
            >
              <option value="">Tous</option>
              {UNIVERSE_TREE.map((u) => (
                <option key={u.slug} value={u.slug}>
                  {u.label}
                </option>
              ))}
            </select>
          </label>
          <label className="space-y-1 text-[12px] text-muted-foreground">
            Domaine
            <select
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="w-full rounded-xl border bg-background px-3 py-2 text-[14px] text-foreground outline-none"
            >
              <option value="">Tous</option>
              {domains.map((d) => (
                <option key={d.slug} value={d.slug}>
                  {d.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid max-h-[52vh] grid-cols-2 gap-2 overflow-y-auto sm:grid-cols-3 md:grid-cols-4">
          {visuals.map((url) => (
            <button
              key={url}
              type="button"
              onClick={() => {
                onPick({ key: visualKeyFromUrl(url), url });
                onOpenChange(false);
              }}
              className="group relative aspect-square overflow-hidden rounded-2xl border border-hairline"
              title="Choisir ce visuel"
            >
              <img
                src={url}
                alt=""
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover transition-transform group-hover:scale-[1.03]"
              />
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function VisualLibraryButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-3.5 py-1.5 text-[13px]"
    >
      <ImagePlus className="h-3.5 w-3.5" strokeWidth={1.75} />
      Bibliothèque AIME
    </button>
  );
}

export function ClearVisualButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-3.5 py-1.5 text-[13px]"
    >
      <X className="h-3.5 w-3.5" strokeWidth={1.75} />
      Retirer le visuel
    </button>
  );
}
