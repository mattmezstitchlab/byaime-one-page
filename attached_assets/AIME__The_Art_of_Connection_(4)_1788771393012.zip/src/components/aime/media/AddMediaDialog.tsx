import { useRef, useState } from "react";
import { toast } from "sonner";
import { Loader2, X } from "lucide-react";
import { AddToTimeline } from "@/components/aime/play/AddToTimeline";
import {
  MEDIA_KINDS,
  guessKind,
  hostOfUrl,
  isPdfUrl,
  uploadMediaFile,
  youtubeId,
  type MediaKind,
  type NewMedia,
} from "@/lib/aime/media";

type Choice = MediaKind | "musique" | "souvenir";

/**
 * Une seule porte pour ajouter : un média, une musique ou un souvenir daté.
 * Ce qui est daté part sur la ligne de temps, le reste reste dans les médias.
 */
export function AddMediaDialog({
  userId,
  cardId,
  onClose,
  onAdd,
}: {
  userId: string | null;
  /** Page concernée : ouvre les entrées Musique et Souvenir. */
  cardId?: string | null;
  onClose: () => void;
  onAdd: (media: NewMedia) => Promise<void> | void;
}) {
  const [kind, setKind] = useState<Choice | null>(null);
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const timeline = kind === "musique" || kind === "souvenir";
  const CHOICES: { key: Choice; label: string }[] = [
    ...MEDIA_KINDS,
    ...(cardId && userId
      ? ([
          { key: "musique", label: "Musique" },
          { key: "souvenir", label: "Souvenir" },
        ] as { key: Choice; label: string }[])
      : []),
  ];

  const submit = async (value: string, forced?: MediaKind) => {
    const clean = value.trim();
    if (!clean) return;
    const finalKind: MediaKind =
      forced ?? (kind && kind !== "musique" && kind !== "souvenir" ? kind : guessKind(clean));
    if (finalKind === "youtube" && !youtubeId(clean)) {
      toast("Cette adresse YouTube n'est pas reconnue.");
      return;
    }
    setBusy(true);
    try {
      const host = hostOfUrl(clean);
      await onAdd({
        kind: finalKind,
        url: clean,
        title:
          title.trim() || (host && (finalKind === "lien" || finalKind === "doc") ? host : null),
      });
      onClose();
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const pickFile = async (file: File) => {
    if (!userId) {
      toast("Connectez-vous pour envoyer un fichier.");
      return;
    }
    setBusy(true);
    try {
      const publicUrl = await uploadMediaFile(userId, file);
      const isPdf = file.type === "application/pdf" || isPdfUrl(file.name);
      await onAdd({
        kind: isPdf
          ? "doc"
          : file.type.startsWith("video")
            ? "video"
            : file.type.startsWith("audio")
              ? "audio"
              : "photo",
        url: publicUrl,
        title: title.trim() || null,
      });
      onClose();
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const field = "w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] outline-none";

  return (
    <div
      className="fixed inset-0 z-[95] grid place-items-center bg-black/60 p-4 backdrop-blur-sm"
      onPointerDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className={`w-full ${timeline ? "max-w-md" : "max-w-sm"} rounded-3xl bg-card p-5 shadow-xl`}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-[17px] font-semibold">Ajouter</h3>
          <button type="button" onClick={onClose} aria-label="Fermer" className="p-1">
            <X className="h-4 w-4" strokeWidth={1.75} />
          </button>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {CHOICES.map((k) => (
            <button
              key={k.key}
              type="button"
              onClick={() => setKind(k.key)}
              className={`rounded-full px-3.5 py-1.5 text-[13px] transition-colors ${
                kind === k.key ? "bg-primary text-primary-foreground" : "hairline bg-background"
              }`}
            >
              {k.label}
            </button>
          ))}
        </div>

        {timeline && cardId && userId && (
          <AddToTimeline
            embedded
            cardId={cardId}
            userId={userId}
            onDone={onClose}
            className="mt-4 max-h-[65vh] overflow-y-auto border-0 bg-transparent p-0 shadow-none"
          />
        )}

        {kind && !timeline && (
          <div className="mt-4 space-y-3">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Titre (facultatif)"
              className={field}
            />

            {(kind === "photo" || kind === "video" || kind === "audio" || kind === "doc") && (
              <>
                <input
                  ref={fileRef}
                  type="file"
                  accept={
                    kind === "photo"
                      ? "image/*"
                      : kind === "video"
                        ? "video/*"
                        : kind === "audio"
                          ? "audio/*"
                          : "application/pdf"
                  }
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void pickFile(f);
                  }}
                />
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => fileRef.current?.click()}
                  className="w-full rounded-2xl bg-primary px-4 py-3 text-[14px] text-primary-foreground disabled:opacity-60"
                >
                  {busy ? "Envoi en cours…" : "Choisir un fichier"}
                </button>
                <p className="text-center text-[12px] text-muted-foreground">ou collez un lien</p>
              </>
            )}

            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder={
                kind === "youtube" ? "https://www.youtube.com/watch?v=…" : "Coller une adresse"
              }
              className={field}
            />
            <button
              type="button"
              disabled={busy || !url.trim()}
              onClick={() => void submit(url)}
              className="flex w-full items-center justify-center gap-2 rounded-2xl hairline bg-background px-4 py-3 text-[14px] disabled:opacity-50"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Ajouter
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
