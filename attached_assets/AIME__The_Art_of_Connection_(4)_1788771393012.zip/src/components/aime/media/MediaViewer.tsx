import { useEffect } from "react";
import { ChevronLeft, ChevronRight, ExternalLink, X } from "lucide-react";
import { hostOfUrl, isPdfUrl, mediaLabel, youtubeEmbed, type MediaItem } from "@/lib/aime/media";

/**
 * La visionneuse : un média en grand, et on continue à parcourir la collection
 * sans revenir à la page.
 */
export function MediaViewer({
  items,
  index,
  onIndex,
  onClose,
}: {
  items: MediaItem[];
  index: number;
  onIndex: (i: number) => void;
  onClose: () => void;
}) {
  const item = items[index];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onIndex((index + 1) % items.length);
      if (e.key === "ArrowLeft") onIndex((index - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, items.length, onIndex, onClose]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-[90] grid place-items-center bg-black/85 backdrop-blur-sm p-4"
      onPointerDown={(e) => e.target === e.currentTarget && onClose()}
      role="dialog"
      aria-modal="true"
      aria-label={mediaLabel(item)}
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Fermer"
        className="absolute right-4 top-4 rounded-full bg-white/15 p-2 text-white transition-colors hover:bg-white/25"
      >
        <X className="h-5 w-5" strokeWidth={1.75} />
      </button>

      {items.length > 1 && (
        <>
          <button
            type="button"
            aria-label="Précédent"
            onClick={() => onIndex((index - 1 + items.length) % items.length)}
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/15 p-2 text-white transition-colors hover:bg-white/25"
          >
            <ChevronLeft className="h-6 w-6" strokeWidth={1.75} />
          </button>
          <button
            type="button"
            aria-label="Suivant"
            onClick={() => onIndex((index + 1) % items.length)}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/15 p-2 text-white transition-colors hover:bg-white/25"
          >
            <ChevronRight className="h-6 w-6" strokeWidth={1.75} />
          </button>
        </>
      )}

      <div className="w-full max-w-5xl">
        <MediaBody item={item} />
        <p className="mt-3 text-center text-[13px] text-white/75">
          {mediaLabel(item)} · {index + 1} / {items.length}
        </p>
      </div>
    </div>
  );
}

function MediaBody({ item }: { item: MediaItem }) {
  if (item.kind === "photo")
    return (
      <img
        src={item.url}
        alt={mediaLabel(item)}
        className="mx-auto max-h-[78vh] w-auto max-w-full rounded-2xl object-contain"
      />
    );

  if (item.kind === "video")
    return (
      <video
        src={item.url}
        controls
        autoPlay
        playsInline
        className="mx-auto max-h-[78vh] w-full rounded-2xl bg-black"
      />
    );

  if (item.kind === "youtube") {
    const src = youtubeEmbed(item.url);
    if (!src) return <OpenLink item={item} />;
    return (
      <div className="aspect-video w-full overflow-hidden rounded-2xl bg-black">
        <iframe
          src={`${src}?autoplay=1`}
          title={mediaLabel(item)}
          allow="accelerometer; autoplay; encrypted-media; picture-in-picture"
          allowFullScreen
          className="h-full w-full"
        />
      </div>
    );
  }

  if (item.kind === "audio")
    return (
      <div className="rounded-2xl bg-white/10 p-6">
        <p className="mb-3 text-center text-[15px] text-white">{mediaLabel(item)}</p>
        <audio src={item.url} controls autoPlay className="w-full" />
      </div>
    );

  if ((item.kind === "doc" || isPdfUrl(item.url)) && canEmbedPdf(item.url))
    return (
      <div className="space-y-2">
        <div className="h-[74vh] overflow-hidden rounded-2xl bg-black">
          <iframe src={item.url} title={mediaLabel(item)} className="h-full w-full" />
        </div>
        <div className="space-y-1 text-center">
          <p className="text-[12px] text-white/65">
            Si l’aperçu PDF ne s’affiche pas, ouvrez le document dans un nouvel onglet.
          </p>
          <a
            href={item.url}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-1.5 text-[12px] text-white/75 underline underline-offset-4 hover:text-white"
          >
            <ExternalLink className="h-3.5 w-3.5" strokeWidth={1.75} /> Ouvrir le document
          </a>
        </div>
      </div>
    );

  return <OpenLink item={item} />;
}

/** Les PDF externes non fiables restent en ouverture externe. */
function canEmbedPdf(url: string): boolean {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    if (typeof window !== "undefined" && host === window.location.hostname.toLowerCase())
      return true;
    return host.endsWith(".supabase.co") || host === "supabase.co" || host.endsWith(".byaime.fr");
  } catch {
    return false;
  }
}

function OpenLink({ item }: { item: MediaItem }) {
  const host = hostOfUrl(item.url);
  return (
    <div className="rounded-2xl bg-white/10 p-8 text-center">
      <p className="text-[15px] text-white">{mediaLabel(item)}</p>
      {host && <p className="mt-1 text-[12px] text-white/70">{host}</p>}
      <a
        href={item.url}
        target="_blank"
        rel="noreferrer noopener"
        className="mt-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-medium text-black"
      >
        <ExternalLink className="h-4 w-4" strokeWidth={1.75} /> Ouvrir
      </a>
    </div>
  );
}
