import { useState } from "react";
import {
  ArrowLeft,
  CalendarPlus,
  Copy,
  Send,
  ArrowRight,
  ExternalLink,
  Expand,
  FileText,
  Headphones,
  Link2,
  MoreHorizontal,
  Play,
  Star,
  Trash2,
} from "lucide-react";
import { hostOfUrl, mediaLabel, mediaThumb, type MediaItem } from "@/lib/aime/media";

/**
 * Une case de la grille. Au survol (ou au premier appui sur mobile), elle
 * révèle les actions correspondant au type du média.
 */
export function MediaTile({
  item,
  canEdit,
  onOpen,
  onRemove,
  onMove,
  onFeature,
  onRename,
  onCopyLink,
  onPublish,
  onToTimeline,
}: {
  item: MediaItem;
  canEdit: boolean;
  onOpen: () => void;
  onRemove: () => void;
  onMove: (dir: -1 | 1) => void;
  onFeature: () => void;
  onRename: () => void;
  onCopyLink?: () => void;
  onPublish?: () => void;
  onToTimeline?: () => void;
}) {
  const [armed, setArmed] = useState(false);
  const [menu, setMenu] = useState(false);
  const thumb = mediaThumb(item);
  const host = hostOfUrl(item.url);

  const primary =
    item.kind === "photo"
      ? { label: "Agrandir", icon: Expand }
      : item.kind === "audio"
        ? { label: "Écouter", icon: Headphones }
        : item.kind === "doc"
          ? { label: "Lire", icon: FileText }
          : item.kind === "lien"
            ? { label: "Ouvrir", icon: ExternalLink }
            : { label: "Lire", icon: Play };
  const Icon = primary.icon;

  return (
    <div
      className="group relative aspect-square overflow-hidden rounded-2xl bg-secondary"
      onMouseEnter={() => setArmed(true)}
      onMouseLeave={() => {
        setArmed(false);
        setMenu(false);
      }}
    >
      {thumb ? (
        <img
          src={thumb}
          alt={mediaLabel(item)}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground">
          {item.kind === "audio" ? (
            <Headphones className="h-6 w-6" strokeWidth={1.5} />
          ) : item.kind === "video" ? (
            <Play className="h-6 w-6" strokeWidth={1.5} />
          ) : item.kind === "doc" ? (
            <FileText className="h-6 w-6" strokeWidth={1.5} />
          ) : (
            <Link2 className="h-6 w-6" strokeWidth={1.5} />
          )}
          <span className="px-2 text-center text-[12px]">{mediaLabel(item)}</span>
          {(item.kind === "lien" || item.kind === "doc") && host && (
            <span className="px-2 text-center text-[11px] text-muted-foreground">{host}</span>
          )}
        </div>
      )}

      {/* Le voile d'actions : survol sur ordinateur, premier appui sur mobile. */}
      <button
        type="button"
        aria-label={`${primary.label} — ${mediaLabel(item)}`}
        onClick={() => {
          if (!armed) {
            setArmed(true);
            return;
          }
          onOpen();
        }}
        className={`absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/45 text-white transition-opacity ${
          armed ? "opacity-100" : "opacity-0"
        }`}
      >
        <span className="flex items-center gap-1.5 rounded-full bg-white/90 px-3.5 py-1.5 text-[12.5px] font-medium text-black">
          <Icon className="h-3.5 w-3.5" strokeWidth={2} />
          {primary.label}
        </span>
        {item.title && <span className="px-3 text-center text-[12px]">{item.title}</span>}
      </button>

      {item.kind === "youtube" && armed && (
        <a
          href={item.url}
          target="_blank"
          rel="noreferrer noopener"
          onClick={(e) => e.stopPropagation()}
          className="absolute bottom-2 left-2 rounded-full bg-black/60 px-2.5 py-1 text-[11px] text-white"
        >
          Ouvrir YouTube
        </a>
      )}

      {canEdit && armed && (
        <button
          type="button"
          aria-label="Autres actions"
          onClick={(e) => {
            e.stopPropagation();
            setMenu((v) => !v);
          }}
          className="absolute right-2 top-2 rounded-full bg-black/60 p-1.5 text-white"
        >
          <MoreHorizontal className="h-4 w-4" strokeWidth={2} />
        </button>
      )}

      {canEdit && menu && (
        <div
          className="absolute right-2 top-11 z-10 w-56 overflow-hidden rounded-2xl bg-card text-[13px] shadow-xl"
          onClick={(e) => e.stopPropagation()}
        >
          <MenuItem icon={Link2} label="Modifier le titre" onClick={onRename} />
          {onToTimeline && (
            <MenuItem
              icon={CalendarPlus}
              label="Poser sur la ligne de temps"
              onClick={onToTimeline}
            />
          )}
          {onPublish && <MenuItem icon={Send} label="Publier dans le fil" onClick={onPublish} />}
          {onCopyLink && <MenuItem icon={Copy} label="Copier le lien" onClick={onCopyLink} />}
          <MenuItem icon={ArrowLeft} label="Déplacer avant" onClick={() => onMove(-1)} />
          <MenuItem icon={ArrowRight} label="Déplacer après" onClick={() => onMove(1)} />
          {item.kind === "photo" && (
            <MenuItem icon={Star} label="Visuel principal" onClick={onFeature} />
          )}
          <MenuItem icon={Trash2} label="Supprimer" onClick={onRemove} danger />
        </div>
      )}
    </div>
  );
}

function MenuItem({
  icon: Icon,
  label,
  onClick,
  danger,
}: {
  icon: typeof Link2;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-2 px-3 py-2.5 text-left transition-colors hover:bg-secondary ${
        danger ? "text-destructive" : ""
      }`}
    >
      <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
      {label}
    </button>
  );
}
