import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  CalendarPlus,
  Check,
  Paperclip,
  Pencil,
  Receipt,
  Send,
  ThumbsDown,
  ThumbsUp,
  UserPlus,
  Wallet,
  X,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { sendMessage } from "@/lib/aime/messaging";
import { uploadTimelineMedia } from "@/lib/aime/play/providers";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import { TimelineEntryEditor } from "@/components/aime/TimelineEntryEditor";

/** Personnes rattachées à un moment, gardées dans ses métadonnées. */
type Attached = { id: string; name: string };

function peopleOf(marker: TimelineMarker): Attached[] {
  const raw = (marker.metadata as Record<string, unknown> | undefined)?.["people"];
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (p): p is Attached =>
      !!p && typeof p === "object" && typeof (p as Attached).id === "string",
  );
}

function mediaKindOf(file: File): "photo" | "video" | "audio" | "doc" {
  if (file.type.startsWith("image/")) return "photo";
  if (file.type.startsWith("video/")) return "video";
  if (file.type.startsWith("audio/")) return "audio";
  return "doc";
}

const CHIP =
  "inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22 disabled:opacity-50";
const FIELD =
  "w-full rounded-xl bg-white/12 px-2.5 py-1.5 text-[12.5px] text-white placeholder:text-white/45 outline-none focus:bg-white/20";

/** Date/heure locale au format attendu par un champ datetime-local. */
function toLocalInput(ms: number) {
  const d = new Date(ms);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/**
 * Ce qui se fait dans la bulle, sans quitter la ligne de temps :
 * modifier un moment, cocher une tâche, décider d'un devis,
 * marquer un paiement, répondre à un message.
 */
export function TimelineBubbleExtra({
  marker,
  cardId,
  userId,
  canEdit,
  onDone,
}: {
  marker: TimelineMarker;
  cardId: string;
  userId: string | null;
  canEdit: boolean;
  onDone: () => void;
}) {
  const qc = useQueryClient();
  const [reply, setReply] = useState("");
  const [editing, setEditing] = useState(false);
  const [seeking, setSeeking] = useState(false);
  const [search, setSearch] = useState("");
  const [proposing, setProposing] = useState(false);
  const [proposed, setProposed] = useState(toLocalInput(marker.time));
  const fileRef = useRef<HTMLInputElement | null>(null);

  const isEntry = marker.id.startsWith("entry-");
  const entryId = marker.id.replace("entry-", "");
  const people = peopleOf(marker);

  useEffect(() => {
    setEditing(false);
    setSeeking(false);
    setSearch("");
    setProposing(false);
    setProposed(toLocalInput(marker.time));
  }, [marker.id, marker.time]);

  const refreshTimeline = () => {
    qc.invalidateQueries({ queryKey: ["card-timeline", cardId] });
    qc.invalidateQueries({ queryKey: ["timeline-quotes", cardId] });
    qc.invalidateQueries({ queryKey: ["timeline-payments", cardId] });
  };

  /** Met à jour les métadonnées d'un moment sans écraser les autres clés. */
  const patchMeta = useMutation({
    mutationFn: async (patch: Record<string, unknown>) => {
      const current = (marker.metadata ?? {}) as Record<string, unknown>;
      const { error } = await supabase
        .from("card_timeline_entries")
        .update({ metadata: { ...current, ...patch } as Json })
        .eq("id", entryId);
      if (error) throw error;
    },
    onSuccess: () => refreshTimeline(),
    onError: (e: Error) => toast(e.message),
  });

  /** Recherche courte de personnes ou de prestataires à rattacher. */
  const candidates = useQuery({
    queryKey: ["timeline-people-search", search],
    enabled: seeking && search.trim().length >= 2,
    queryFn: async (): Promise<Attached[]> => {
      const { data, error } = await supabase
        .from("cards")
        .select("id,name")
        .ilike("name", `%${search.trim()}%`)
        .limit(6);
      if (error) throw error;
      return data ?? [];
    },
  });

  const attachFile = useMutation({
    mutationFn: async (file: File) => {
      const up = await uploadTimelineMedia(cardId, file);
      const kind = mediaKindOf(file);
      const current = (marker.metadata ?? {}) as Record<string, unknown>;
      const { error } = await supabase
        .from("card_timeline_entries")
        .update({
          metadata: {
            ...current,
            media: kind,
            ...(up.url ? { mediaUrl: up.url } : {}),
            ...(up.url && kind === "photo" ? { thumbUrl: up.url } : {}),
            mediaPath: up.path,
          } as Json,
        })
        .eq("id", entryId);
      if (error) throw error;
    },
    onSuccess: () => {
      refreshTimeline();
      toast("Pièce jointe ajoutée");
    },
    onError: (e: Error) => toast(e.message),
  });

  const proposeDate = useMutation({
    mutationFn: async () => {
      if (!userId || !marker.threadId) throw new Error("Aucune conversation liée.");
      const d = new Date(proposed);
      await sendMessage(
        marker.threadId,
        userId,
        `Je propose le ${d.toLocaleDateString("fr-FR", {
          weekday: "long",
          day: "numeric",
          month: "long",
        })} à ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}. Cela vous convient-il ?`,
      );
    },
    onSuccess: () => {
      setProposing(false);
      qc.invalidateQueries({ queryKey: ["timeline-messages", cardId] });
      toast("Date proposée");
    },
    onError: (e: Error) => toast(e.message),
  });

  const toggleTask = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("card_timeline_entries")
        .update({ done_at: marker.done ? null : new Date().toISOString() })
        .eq("id", entryId);
      if (error) throw error;
    },
    onSuccess: () => {
      refreshTimeline();
      toast(marker.done ? "Tâche rouverte" : "Tâche faite");
    },
    onError: (e: Error) => toast(e.message),
  });

  /** Décider d'un devis ou d'une facture sans ouvrir de page. */
  const setQuoteStatus = useMutation({
    mutationFn: async (status: string) => {
      const { error } = await supabase
        .from("quotes")
        .update({ status })
        .eq("id", marker.id.replace("quote-", ""));
      if (error) throw error;
      return status;
    },
    onSuccess: (status) => {
      refreshTimeline();
      toast(
        status === "accepte"
          ? "Devis accepté"
          : status === "refuse"
            ? "Devis refusé"
            : "Transformé en facture",
      );
    },
    onError: (e: Error) => toast(e.message),
  });

  /** Marquer un paiement comme reçu : AIME suit, mais n'encaisse pas. */
  const markPaid = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("event_payments")
        .update({ status: "paye", paid_at: new Date().toISOString() })
        .eq("id", marker.id.replace("pay-", ""));
      if (error) throw error;
    },
    onSuccess: () => {
      refreshTimeline();
      toast("Paiement marqué reçu · AIME n'encaisse pas");
    },
    onError: (e: Error) => toast(e.message),
  });

  const send = useMutation({
    mutationFn: async () => {
      if (!userId || !marker.threadId || !reply.trim()) throw new Error("Écrivez un message.");
      await sendMessage(marker.threadId, userId, reply.trim());
    },
    onSuccess: () => {
      setReply("");
      qc.invalidateQueries({ queryKey: ["timeline-messages", cardId] });
      toast("Message envoyé");
      onDone();
    },
    onError: (e: Error) => toast(e.message),
  });

  // Ouvrir la bulle d'un échange vaut lecture : la pastille cesse de clignoter.
  useEffect(() => {
    if (!marker.unread || !marker.threadId || !userId) return;
    void supabase
      .from("messages")
      .update({ read_at: new Date().toISOString() })
      .eq("thread_id", marker.threadId)
      .neq("sender_id", userId)
      .is("read_at", null)
      .then(() => qc.invalidateQueries({ queryKey: ["timeline-messages", cardId] }));
  }, [marker.unread, marker.threadId, userId, cardId, qc]);


  // 1 — Édition complète d'un moment sur place
  if (isEntry && canEdit && editing) {
    return (
      <TimelineEntryEditor
        entryId={entryId}
        onCancel={() => setEditing(false)}
        onSaved={() => {
          refreshTimeline();
          setEditing(false);
        }}
        onRemoved={() => {
          refreshTimeline();
          onDone();
        }}
      />
    );
  }

  const chips: React.ReactNode[] = [];

  if (isEntry && canEdit) {
    chips.push(
      <button key="edit" type="button" onClick={() => setEditing(true)} className={CHIP}>
        <Pencil className="h-3.5 w-3.5" strokeWidth={2} />
        Modifier
      </button>,
    );
  }

  if (marker.kind === "tache" && canEdit && isEntry) {
    chips.push(
      <button
        key="task"
        type="button"
        disabled={toggleTask.isPending}
        onClick={() => toggleTask.mutate()}
        className={CHIP}
      >
        <Check className="h-3.5 w-3.5" strokeWidth={2} />
        {marker.done ? "Rouvrir la tâche" : "Marquer comme faite"}
      </button>,
    );
  }

  if (marker.id.startsWith("quote-")) {
    if (marker.kind === "devis") {
      chips.push(
        <button
          key="accept"
          type="button"
          disabled={setQuoteStatus.isPending}
          onClick={() => setQuoteStatus.mutate("accepte")}
          className={CHIP}
        >
          <ThumbsUp className="h-3.5 w-3.5" strokeWidth={2} />
          Accepter
        </button>,
        <button
          key="decline"
          type="button"
          disabled={setQuoteStatus.isPending}
          onClick={() => setQuoteStatus.mutate("refuse")}
          className={CHIP}
        >
          <ThumbsDown className="h-3.5 w-3.5" strokeWidth={2} />
          Refuser
        </button>,
        <button
          key="invoice"
          type="button"
          disabled={setQuoteStatus.isPending}
          onClick={() => setQuoteStatus.mutate("facture")}
          className={CHIP}
        >
          <Receipt className="h-3.5 w-3.5" strokeWidth={2} />
          En facture
        </button>,
      );
    } else {
      chips.push(
        <button
          key="paid"
          type="button"
          disabled={setQuoteStatus.isPending}
          onClick={() => setQuoteStatus.mutate("paye")}
          className={CHIP}
        >
          <Wallet className="h-3.5 w-3.5" strokeWidth={2} />
          Marquer payée
        </button>,
      );
    }
  }

  if (marker.id.startsWith("pay-")) {
    chips.push(
      <button
        key="markpaid"
        type="button"
        disabled={markPaid.isPending}
        onClick={() => markPaid.mutate()}
        className={CHIP}
      >
        <Wallet className="h-3.5 w-3.5" strokeWidth={2} />
        Marquer reçu
      </button>,
    );
  }

  // Réunir : rattacher quelqu'un, joindre un fichier, proposer une date
  if (isEntry && canEdit) {
    chips.push(
      <button
        key="people"
        type="button"
        onClick={() => setSeeking((v) => !v)}
        className={CHIP}
      >
        <UserPlus className="h-3.5 w-3.5" strokeWidth={2} />
        Ajouter quelqu'un
      </button>,
      <button
        key="attach"
        type="button"
        disabled={attachFile.isPending}
        onClick={() => fileRef.current?.click()}
        className={CHIP}
      >
        <Paperclip className="h-3.5 w-3.5" strokeWidth={2} />
        {attachFile.isPending ? "Envoi…" : "Joindre"}
      </button>,
    );
  }

  if (marker.threadId && userId) {
    chips.push(
      <button
        key="propose"
        type="button"
        onClick={() => setProposing((v) => !v)}
        className={CHIP}
      >
        <CalendarPlus className="h-3.5 w-3.5" strokeWidth={2} />
        Proposer une date
      </button>,
    );
  }

  const money =
    marker.id.startsWith("quote-") || marker.id.startsWith("pay-") || marker.kind === "paiement";

  const messageForm =
    marker.kind === "message" && marker.threadId && userId ? (
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send.mutate();
        }}
        className="flex items-center gap-1.5"
      >
        <input
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          placeholder="Répondre…"
          className="min-w-0 flex-1 rounded-full bg-white/12 px-3 py-1.5 text-[12.5px] text-white placeholder:text-white/45 outline-none focus:bg-white/20"
        />
        <button
          type="submit"
          disabled={send.isPending}
          aria-label="Envoyer"
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white text-black disabled:opacity-50"
        >
          <Send className="h-3.5 w-3.5" strokeWidth={2} />
        </button>
      </form>
    ) : null;

  if (chips.length === 0 && !messageForm && people.length === 0) return null;

  return (
    <div className="space-y-1.5">
      {people.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {people.map((p) => (
            <span
              key={p.id}
              className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2.5 py-1 text-[11.5px] text-white/85"
            >
              {p.name}
              {canEdit && isEntry && (
                <button
                  type="button"
                  aria-label={`Retirer ${p.name}`}
                  onClick={() =>
                    patchMeta.mutate({ people: people.filter((x) => x.id !== p.id) })
                  }
                  className="text-white/50 hover:text-white"
                >
                  <X className="h-3 w-3" strokeWidth={2} />
                </button>
              )}
            </span>
          ))}
        </div>
      )}
      {chips.length > 0 && <div className="flex flex-wrap gap-1.5">{chips}</div>}
      <input
        ref={fileRef}
        type="file"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) attachFile.mutate(f);
          e.target.value = "";
        }}
      />
      {seeking && (
        <div className="space-y-1">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Chercher une personne…"
            className={FIELD}
            autoFocus
          />
          {(candidates.data ?? []).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                if (people.some((p) => p.id === c.id)) return;
                patchMeta.mutate({ people: [...people, { id: c.id, name: c.name }] });
                setSeeking(false);
                setSearch("");
              }}
              className="block w-full rounded-lg px-2.5 py-1 text-left text-[12.5px] text-white/85 hover:bg-white/12"
            >
              {c.name}
            </button>
          ))}
        </div>
      )}
      {proposing && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            proposeDate.mutate();
          }}
          className="flex items-center gap-1.5"
        >
          <input
            type="datetime-local"
            value={proposed}
            onChange={(e) => setProposed(e.target.value)}
            className={FIELD}
          />
          <button type="submit" disabled={proposeDate.isPending} className={CHIP}>
            <Send className="h-3.5 w-3.5" strokeWidth={2} />
            Envoyer
          </button>
        </form>
      )}
      {money && (
        <p className="text-[10.5px] leading-snug text-white/45">
          AIME prépare et suit les paiements, mais ne les encaisse pas.
        </p>
      )}
      {messageForm}
    </div>
  );
}
