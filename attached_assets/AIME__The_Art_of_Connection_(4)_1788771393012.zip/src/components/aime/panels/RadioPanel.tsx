import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Music, Pause, Play, Radio, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRadio } from "@/components/aime/RadioProvider";
import { bindAudioElement } from "@/lib/aime/audioBus";
import { itunesProvider, type MusicTrack } from "@/lib/aime/play/providers";
import { listenUrl, playlistQuery, trackArtist, trackTitle } from "@/lib/aime/playlist";
import { cn } from "@/lib/utils";

type Props = {
  cardId?: string | null;
  eventId?: string | null;
  cardName: string;
  city?: string | null;
  canManage?: boolean;
};

/**
 * La musique d'AIME : une playlist, rien de plus.
 * On cherche un artiste ou un titre, on l'ajoute, on l'écoute.
 */
export function RadioPanel({
  cardId = null,
  eventId = null,
  cardName,
  canManage = false,
}: Props) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { on, toggle, current: onAir } = useRadio();
  const { data: tracks = [] } = useQuery(playlistQuery(cardId, eventId));

  const [q, setQ] = useState("");
  const [results, setResults] = useState<MusicTrack[]>([]);
  const [searching, setSearching] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [audio] = useState(() => (typeof Audio === "undefined" ? null : new Audio()));

  const listenable = useMemo(() => tracks.filter((t) => !!listenUrl(t)), [tracks]);

  const search = async () => {
    const term = q.trim();
    if (term.length < 2) return;
    setSearching(true);
    try {
      setResults(await itunesProvider.search(term));
    } catch {
      toast.error("Recherche indisponible pour l'instant.");
    } finally {
      setSearching(false);
    }
  };

  const add = useMutation({
    mutationFn: async (track: MusicTrack) => {
      if (!userId || !cardId) throw new Error("Connectez-vous pour ajouter un morceau.");
      const now = new Date();
      const { error } = await supabase.from("musicbox_entries").insert({
        card_id: cardId,
        event_id: eventId,
        owner_id: userId,
        kind: "musique",
        title: track.title,
        artist: track.artist ?? null,
        provider: track.provider,
        track_id: track.trackId,
        artwork_url: track.artwork?.replace("100x100", "300x300") ?? null,
        preview_url: track.previewUrl ?? null,
        external_url: track.externalUrl ?? null,
        source_type: track.provider,
        source_url: track.previewUrl ?? track.externalUrl ?? null,
        day: now.toISOString().slice(0, 10),
        start_time: now.toTimeString().slice(0, 8),
        duration_min: Math.max(1, Math.round((track.duration ?? 180) / 60)),
        visibility: "public",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Morceau ajouté à la playlist");
      void qc.invalidateQueries({ queryKey: ["playlist"] });
      void qc.invalidateQueries({ queryKey: ["public-tracks"] });
      void qc.invalidateQueries({ queryKey: ["card-timeline-music", cardId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("musicbox_entries").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["playlist"] });
      void qc.invalidateQueries({ queryKey: ["public-tracks"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const listen = (id: string, url: string | null) => {
    if (!audio || !url) return;
    if (playingId === id) {
      audio.pause();
      setPlayingId(null);
      return;
    }
    bindAudioElement("playlist", audio);
    audio.src = url;
    audio.onended = () => setPlayingId(null);
    void audio.play().catch(() => toast("Lecture refusée par le navigateur."));
    setPlayingId(id);
  };

  return (
    <div className="space-y-8">
      {/* ÉCOUTE AU HASARD */}
      <section className="rounded-3xl hairline bg-card p-5 sm:p-6">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-[11.5px] font-medium tracking-[0.08em] text-muted-foreground uppercase">
            <Radio className="h-3.5 w-3.5" />
            Radio AIME
          </span>
          <span className="text-[13px] text-muted-foreground">
            {on && onAir
              ? `${trackTitle(onAir)}${trackArtist(onAir) ? ` · ${trackArtist(onAir)}` : ""}`
              : "Les morceaux publics de la communauté, au hasard."}
          </span>
          <button
            type="button"
            onClick={toggle}
            className="ml-auto inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
          >
            {on ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {on ? "Couper" : "Écouter au hasard"}
          </button>
        </div>
      </section>

      {/* AJOUTER UN MORCEAU */}
      {canManage && (
        <section>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Ajouter un morceau</h2>
          <p className="mt-1 text-[13.5px] text-muted-foreground">
            Tapez un artiste ou un titre : le morceau s&apos;ajoute avec sa pochette et son extrait.
          </p>
          <div className="mt-3 flex gap-2">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void search()}
              placeholder="Artiste ou chanson"
              className="h-11 flex-1 rounded-full hairline bg-background px-4 text-[14px]"
              aria-label="Rechercher un morceau"
            />
            <button
              type="button"
              onClick={() => void search()}
              className="inline-flex h-11 items-center gap-2 rounded-full bg-foreground px-4 text-[13px] text-background"
            >
              {searching ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
              Chercher
            </button>
          </div>

          {results.length > 0 && (
            <ul className="mt-3 divide-y divide-hairline rounded-3xl hairline bg-card">
              {results.map((r) => (
                <li key={`${r.provider}-${r.trackId}`} className="flex items-center gap-3 p-3">
                  {r.artwork ? (
                    <img src={r.artwork} alt="" className="h-11 w-11 rounded-lg object-cover" />
                  ) : (
                    <span className="grid h-11 w-11 place-items-center rounded-lg bg-secondary">
                      <Music className="h-4 w-4 text-muted-foreground" />
                    </span>
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium">{r.title}</span>
                    <span className="block truncate text-[12px] text-muted-foreground">
                      {r.artist ?? "Artiste inconnu"}
                    </span>
                  </span>
                  {r.previewUrl && (
                    <button
                      type="button"
                      onClick={() => listen(r.trackId, r.previewUrl ?? null)}
                      aria-label="Écouter l'extrait"
                      className="grid h-9 w-9 place-items-center rounded-full bg-secondary"
                    >
                      {playingId === r.trackId ? (
                        <Pause className="h-4 w-4" />
                      ) : (
                        <Play className="h-4 w-4" />
                      )}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => add.mutate(r)}
                    className="rounded-full bg-foreground px-3 py-1.5 text-[12.5px] text-background"
                  >
                    Ajouter
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      {/* LA PLAYLIST */}
      <section>
        <h2 className="text-xl font-semibold tracking-[-0.02em]">La playlist de {cardName}</h2>
        <ul className="mt-3 divide-y divide-hairline rounded-3xl hairline bg-card">
          {tracks.length === 0 && (
            <li className="p-4 text-[13.5px] text-muted-foreground">
              Aucun morceau pour l&apos;instant.
            </li>
          )}
          {tracks.map((t) => {
            const url = listenUrl(t);
            return (
              <li key={t.id} className="flex items-center gap-3 p-3">
                {t.artwork_url ? (
                  <img src={t.artwork_url} alt="" className="h-11 w-11 rounded-lg object-cover" />
                ) : (
                  <span className="grid h-11 w-11 place-items-center rounded-lg bg-secondary">
                    <Music className="h-4 w-4 text-muted-foreground" />
                  </span>
                )}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] font-medium">{trackTitle(t)}</span>
                  <span className="block truncate text-[12px] text-muted-foreground">
                    {trackArtist(t) ?? "Artiste inconnu"}
                    {t.visibility === "public" ? " · public" : ""}
                  </span>
                </span>
                <button
                  type="button"
                  disabled={!url}
                  onClick={() => listen(t.id, url)}
                  aria-label="Écouter"
                  className={cn(
                    "grid h-9 w-9 place-items-center rounded-full bg-secondary",
                    !url && "opacity-40",
                  )}
                >
                  {playingId === t.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </button>
                {t.external_url && (
                  <a
                    href={t.external_url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[12.5px] text-muted-foreground underline underline-offset-2"
                  >
                    Écouter en entier
                  </a>
                )}
                {canManage && (
                  <button
                    type="button"
                    onClick={() => remove.mutate(t.id)}
                    aria-label="Retirer de la playlist"
                    className="grid h-9 w-9 place-items-center rounded-full text-muted-foreground hover:text-foreground"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </li>
            );
          })}
        </ul>
        {listenable.length === 0 && tracks.length > 0 && (
          <p className="mt-2 text-[12.5px] text-muted-foreground">
            Aucun de ces morceaux n&apos;a d&apos;extrait écoutable.
          </p>
        )}
      </section>
    </div>
  );
}
