import type { ReactNode } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

/**
 * Un panneau s'affiche en tiroir latéral (toujours à droite, comme tous
 * les panneaux d'AIME) ; « embedded » le pose nu, sans habillage.
 */
export function PanelShell({
  embedded,
  open,
  onOpenChange,
  side,
  title,
  children,
}: {
  embedded?: boolean | undefined;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  side: "left" | "right";
  title: string;
  children: ReactNode;
}) {
  if (embedded) return <>{children}</>;
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side={side} className="w-full overflow-y-auto sm:max-w-md">
        <SheetHeader>
          <SheetTitle>{title}</SheetTitle>
        </SheetHeader>
        {children}
      </SheetContent>
    </Sheet>
  );
}
