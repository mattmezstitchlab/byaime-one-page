import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CalendarDays, Check, Heart, MapPin, Plus, Users, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { QuotePanel } from "@/components/aime/panels/QuotePanel";
import { TimelinePanel } from "@/components/aime/panels/TimelinePanel";
import { MusicBox } from "@/components/aime/MusicBox";
import FolderTemplates from "@/components/bureau/FolderTemplates";
import { cardVisual } from "@/lib/aime/visuals";
import { cardsQuery, invitationsQuery, paymentsQuery } from "@/lib/aime/queries";
import { readSlots } from "@/lib/aime/compositionAdd";
import {
  WEDDING_ROLES,
  WEDDING_STEPS,
  daysUntil,
  formatWeddingDate,
  matchesRole,
} from "@/lib/aime/presets/mariage";
import {
  clearRole,
  ensureWeddingPlan,
  ensureWeddingProject,
  fillRole,
  weddingPlanQuery,
  weddingProjectQuery,
} from "@/lib/aime/wedding";
import type { Card } from "@/lib/aime/types";
import { PARTICIPANT_STATUS_LABEL } from "@/lib/aime/calendar";
import { cn } from "@/lib/utils";

type Props = {
  card: Card;
  tab: string;
  isOwner: boolean;
  userId: string | null;
  onPickTab: (key: never) => void;
};

/** Le fil conducteur : ce qui est fait, ce qu'il reste, la prochaine chose à faire. */
export function WeddingRibbon({ card, isOwner }: { card: Card; isOwner: boolean }) {
  const { data: plan } = useQuery(weddingPlanQuery(card.id));
  const { data: project } = useQuery(weddingProjectQuery(card.id));
  const filled = plan?.composition_items?.length ?? 0;
  const open = readSlots(plan?.brief ?? null).length;
  const total = filled + open;
  const date = formatWeddingDate(project?.starts_at ?? null);
  const left = daysUntil(project?.starts_at ?? null);

  return (
    <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-3 gap-y-1 px-5 pt-4 text-[13px] text-muted-foreground">
      <span className="font-medium text-foreground">{card.name}</span>
      {date && (
        <span className="flex items-center gap-1">
          <CalendarDays className="h-3.5 w-3.5" strokeWidth={1.75} /> {date}
          {typeof left === "number" && left >= 0 && <span>· J−{left}</span>}
        </span>
      )}
      {card.city && (
        <span className="flex items-center gap-1">
          <MapPin className="h-3.5 w-3.5" strokeWidth={1.75} /> {card.city}
        </span>
      )}
      {total > 0 && (
        <span>
          {filled} place{filled > 1 ? "s" : ""} sur {total} pourvue{filled > 1 ? "s" : ""}
        </span>
      )}
      {isOwner && !plan && <span>Le plan des places n'est pas encore ouvert.</span>}
    </div>
  );
}

export function WeddingPanels({ card, tab, isOwner, userId }: Props) {
  const qc = useQueryClient();
  const { data: plan } = useQuery(weddingPlanQuery(card.id));
  const { data: project } = useQuery(weddingProjectQuery(card.id));
  const { data: cards = [] } = useQuery(cardsQuery);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["wedding-plan", card.id] });
    qc.invalidateQueries({ queryKey: ["wedding-project", card.id] });
  };

  const openPlan = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("Connectez-vous pour ouvrir le plan.");
      await ensureWeddingPlan({ userId, card });
    },
    onSuccess: () => {
      invalidate();
      toast("Plan des places ouvert");
    },
    onError: (e) => toast((e as Error).message),
  });

  const openProject = useMutation({
    mutationFn: async (startsAt?: string | null) => {
      if (!userId) throw new Error("Connectez-vous pour ouvrir le suivi.");
      await ensureWeddingProject({ userId, card, startsAt: startsAt ?? null });
    },
    onSuccess: () => {
      invalidate();
      toast("Suivi du mariage ouvert");
    },
    onError: (e) => toast((e as Error).message),
  });

  const setDate = useMutation({
    mutationFn: async (day: string) => {
      if (!userId) throw new Error("Connectez-vous pour fixer la date.");
      const eventId = await ensureWeddingProject({ userId, card, startsAt: `${day}T15:00:00Z` });
      const { error } = await supabase
        .from("events")
        .update({ starts_at: `${day}T15:00:00Z` })
        .eq("id", eventId);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast("Date du jour J enregistrée");
    },
    onError: (e) => toast((e as Error).message),
  });

  const place = useMutation({
    mutationFn: async ({ slotLabel, cardId }: { slotLabel: string; cardId: string }) => {
      if (!userId) throw new Error("Connectez-vous pour composer votre mariage.");
      const compositionId = plan?.id ?? (await ensureWeddingPlan({ userId, card }));
      await fillRole({ compositionId, slotLabel, cardId });
    },
    onSuccess: () => {
      invalidate();
      toast("Place pourvue");
    },
    onError: (e) => toast((e as Error).message),
  });

  const unplace = useMutation({
    mutationFn: async ({ itemId, slotLabel }: { itemId: string; slotLabel: string }) => {
      if (!plan) return;
      await clearRole({
        compositionId: plan.id,
        itemId,
        slotLabel,
        brief: plan.brief,
      });
    },
    onSuccess: () => {
      invalidate();
      toast("Place rouverte");
    },
  });

  const addStep = useMutation({
    mutationFn: async (step: { label: string; hour: number }) => {
      const base = project?.starts_at ? new Date(project.starts_at) : new Date();
      base.setHours(Math.floor(step.hour), Math.round((step.hour % 1) * 60), 0, 0);
      const { error } = await supabase.from("card_timeline_entries").insert({
        card_id: card.id,
        kind: "jalon",
        title: step.label,
        starts_at: base.toISOString(),
        universe_slug: "mariage",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["card-timeline", card.id] });
      toast("Étape ajoutée au déroulé");
    },
    onError: (e) => toast((e as Error).message),
  });

  const byId = useMemo(() => new Map(cards.map((c) => [c.id, c])), [cards]);
  const items = plan?.composition_items ?? [];
  const filledBy = useMemo(() => {
    const map = new Map<string, { itemId: string; card: Card | undefined }>();
    for (const it of items) map.set(it.slot_label, { itemId: it.id, card: byId.get(it.card_id) });
    return map;
  }, [items, byId]);

  if (tab === "jour-j") {
    const date = formatWeddingDate(project?.starts_at ?? null);
    const left = daysUntil(project?.starts_at ?? null);
    return (
      <section className="max-w-3xl space-y-6">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Le jour J</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            La date, le lieu, et le temps qu'il reste. Tout le reste s'organise à partir d'ici.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl hairline bg-card p-4">
            <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Date</p>
            <p className="mt-1 text-[15px] font-medium">{date ?? "À fixer"}</p>
            {typeof left === "number" && left >= 0 && (
              <p className="text-[13px] text-muted-foreground">Dans {left} jours</p>
            )}
          </div>
          <div className="rounded-2xl hairline bg-card p-4">
            <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Lieu</p>
            <p className="mt-1 text-[15px] font-medium">{card.city ?? "À définir"}</p>
          </div>
          <div className="rounded-2xl hairline bg-card p-4">
            <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Places</p>
            <p className="mt-1 text-[15px] font-medium">
              {items.length} pourvue{items.length > 1 ? "s" : ""} ·{" "}
              {readSlots(plan?.brief ?? null).length} à pourvoir
            </p>
          </div>
        </div>

        {isOwner && (
          <div className="flex flex-wrap items-center gap-3 rounded-2xl hairline bg-card p-4">
            <label className="text-[13px] text-muted-foreground" htmlFor="wedding-day">
              Fixer la date
            </label>
            <input
              id="wedding-day"
              type="date"
              defaultValue={project?.starts_at ? project.starts_at.slice(0, 10) : ""}
              onChange={(e) => e.target.value && setDate.mutate(e.target.value)}
              className="rounded-xl hairline bg-background px-3 py-2 text-[13px]"
            />
            {!plan && (
              <button
                type="button"
                onClick={() => openPlan.mutate()}
                className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
              >
                Ouvrir le plan des places
              </button>
            )}
          </div>
        )}
      </section>
    );
  }

  if (tab === "prestataires") {
    return (
      <section className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Les prestataires</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            Chaque place vide vous propose des cartes proches de {card.city ?? "votre ville"}. Vous
            posez, vous retirez, sans quitter cette page.
          </p>
        </div>
        {!plan && isOwner && (
          <button
            type="button"
            onClick={() => openPlan.mutate()}
            className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
          >
            Ouvrir le plan des places
          </button>
        )}
        <div className="space-y-3">
          {WEDDING_ROLES.map((role) => (
            <RoleRow
              key={role.label}
              role={role}
              cards={cards}
              city={card.city}
              filled={filledBy.get(role.label)}
              canEdit={isOwner}
              onPlace={(cardId) => place.mutate({ slotLabel: role.label, cardId })}
              onClear={(itemId) => unplace.mutate({ itemId, slotLabel: role.label })}
            />
          ))}
        </div>
      </section>
    );
  }

  if (tab === "deroule") {
    return (
      <section className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Le déroulé</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            Heure par heure. Ajoutez les étapes habituelles d'un mariage, puis ajustez.
          </p>
        </div>
        {isOwner && (
          <div className="flex flex-wrap gap-2">
            {WEDDING_STEPS.map((s) => (
              <button
                key={s.label}
                type="button"
                onClick={() => addStep.mutate(s)}
                className="inline-flex items-center gap-1.5 rounded-full hairline bg-card px-3 py-1.5 text-[12.5px] hover:bg-secondary"
              >
                <Plus className="h-3.5 w-3.5" strokeWidth={2} /> {s.label}
              </button>
            ))}
          </div>
        )}
        <TimelinePanel cardId={card.id} />
      </section>
    );
  }

  if (tab === "invites") {
    return (
      <section className="space-y-5">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Les invités</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            Les personnes rattachées à votre mariage et leurs réponses.
          </p>
        </div>
        {!project ? (
          isOwner ? (
            <button
              type="button"
              onClick={() => openProject.mutate(null)}
              className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
            >
              Ouvrir le suivi des invités
            </button>
          ) : (
            <p className="text-[14px] text-muted-foreground">Aucune liste ouverte.</p>
          )
        ) : (
          <>
            <ul className="space-y-2">
              {(project.event_participants ?? []).map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
                >
                  <span>{byId.get(p.card_id)?.name ?? "Invité"}</span>
                  <span className="text-[12.5px] text-muted-foreground">
                    {p.role_label} · {PARTICIPANT_STATUS_LABEL[p.status] ?? p.status}
                  </span>
                </li>
              ))}
              {(project.event_participants ?? []).length === 0 && (
                <li className="text-[14px] text-muted-foreground">
                  Personne n'est encore inscrit.
                </li>
              )}
            </ul>
            <Link
              to="/projets/$id"
              params={{ id: project.id }}
              search={{ panneau: "personnes" as const }}
              className="inline-flex rounded-full hairline bg-card px-4 py-2 text-[13px]"
            >
              <Users className="mr-1.5 h-4 w-4" strokeWidth={1.75} /> Inviter et suivre les réponses
            </Link>
          </>
        )}
      </section>
    );
  }

  if (tab === "budget") {
    return (
      <section className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Budget</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            Les devis demandés à vos prestataires et les acomptes déjà versés.
          </p>
        </div>
        {project ? (
          <PaymentsSummary eventId={project.id} />
        ) : isOwner ? (
          <button
            type="button"
            onClick={() => openProject.mutate(null)}
            className="rounded-full hairline bg-card px-4 py-2 text-[13px]"
          >
            Ouvrir le suivi des paiements
          </button>
        ) : null}
        <QuotePanel cardId={card.id} />
      </section>
    );
  }

  if (tab === "musique") {
    return (
      <section className="space-y-4">
        <h2 className="text-xl font-semibold tracking-[-0.02em]">Musique</h2>
        <MusicBox
          cardId={card.id}
          eventId={project?.id ?? null}
          canManage={isOwner}
          city={card.city}
          title="La musique de votre mariage"
          intro="Programmez les moments du jour : entrée, ouverture de bal, dédicaces."
        />
      </section>
    );
  }

  if (tab === "documents") {
    return (
      <section className="space-y-5">
        <div>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Documents</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">
            Contrats, devis signés, factures : un dossier déjà structuré vous attend.
          </p>
        </div>
        <FolderTemplates
          ownerId={userId}
          universeSlug="mariage"
          eventId={project?.id ?? null}
          cardId={card.id}
          defaultTitle={card.name}
        />
      </section>
    );
  }

  return null;
}

function PaymentsSummary({ eventId }: { eventId: string }) {
  const { data: payments = [] } = useQuery(paymentsQuery(eventId));
  const { data: invitations = [] } = useQuery(invitationsQuery(eventId));
  const total = payments.reduce((sum, p) => sum + (p.amount_due ?? 0), 0);
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <div className="rounded-2xl hairline bg-card p-4">
        <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Engagé</p>
        <p className="mt-1 text-[18px] font-medium">{total.toFixed(0)} €</p>
      </div>
      <div className="rounded-2xl hairline bg-card p-4">
        <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Paiements</p>
        <p className="mt-1 text-[18px] font-medium">{payments.length}</p>
      </div>
      <div className="rounded-2xl hairline bg-card p-4">
        <p className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Invitations</p>
        <p className="mt-1 text-[18px] font-medium">{invitations.length}</p>
      </div>
    </div>
  );
}

function RoleRow({
  role,
  cards,
  city,
  filled,
  canEdit,
  onPlace,
  onClear,
}: {
  role: { label: string; hint: string; match: string[] };
  cards: Card[];
  city: string | null;
  filled: { itemId: string; card: Card | undefined } | undefined;
  canEdit: boolean;
  onPlace: (cardId: string) => void;
  onClear: (itemId: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const suggestions = useMemo(() => {
    const pool = cards.filter((c) => matchesRole(c, role));
    const near = pool.filter((c) => city && c.city === city);
    const rest = pool.filter((c) => !city || c.city !== city);
    return [...near, ...rest].slice(0, 6);
  }, [cards, role, city]);

  return (
    <div className="rounded-2xl hairline bg-card p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-[15px] font-medium">
            {filled?.card ? (
              <Check className="h-4 w-4 text-primary" strokeWidth={2} />
            ) : (
              <Plus className="h-4 w-4 text-muted-foreground" strokeWidth={2} />
            )}
            {role.label}
          </p>
          <p className="mt-0.5 text-[12.5px] text-muted-foreground">{role.hint}</p>
        </div>
        {filled?.card ? (
          <div className="flex items-center gap-2">
            <Link
              to="/carte/$id"
              params={{ id: filled.card.id }}
              className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-[13px]"
            >
              <img
                src={cardVisual(filled.card)}
                alt=""
                className="h-6 w-6 rounded-full object-cover"
              />
              {filled.card.name}
            </Link>
            {canEdit && (
              <button
                type="button"
                aria-label={`Retirer ${filled.card.name} de ${role.label}`}
                onClick={() => onClear(filled.itemId)}
                className="grid h-8 w-8 place-items-center rounded-full hairline text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" strokeWidth={1.75} />
              </button>
            )}
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className={cn(
              "rounded-full px-4 py-2 text-[13px]",
              open ? "bg-secondary" : "bg-foreground text-background",
            )}
          >
            {open ? "Fermer" : "Trouver"}
          </button>
        )}
      </div>

      {open && !filled?.card && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {suggestions.length === 0 && (
            <p className="text-[13px] text-muted-foreground">
              Aucune carte ne correspond encore à cette place près de {city ?? "chez vous"}.
            </p>
          )}
          {suggestions.map((c) => (
            <div
              key={c.id}
              className="flex items-center justify-between gap-2 rounded-xl hairline bg-background p-2"
            >
              <Link
                to="/carte/$id"
                params={{ id: c.id }}
                className="flex min-w-0 items-center gap-2"
              >
                <img src={cardVisual(c)} alt="" className="h-9 w-9 rounded-lg object-cover" />
                <span className="min-w-0">
                  <span className="block truncate text-[13.5px] font-medium">{c.name}</span>
                  <span className="block truncate text-[12px] text-muted-foreground">
                    {c.city ?? c.region} · ★ {c.rating.toFixed(1)}
                  </span>
                </span>
              </Link>
              {canEdit && (
                <button
                  type="button"
                  onClick={() => onPlace(c.id)}
                  className="inline-flex shrink-0 items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-[12.5px] text-primary-foreground"
                >
                  <Heart className="h-3.5 w-3.5" strokeWidth={2} /> Poser
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
