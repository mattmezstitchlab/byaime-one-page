import { Link } from "@tanstack/react-router";
import type { Card } from "@/lib/aime/types";

/** Les quelques lignes qui disent l'essentiel d'une carte, sans jargon. */
function lines(card: Card): string[] {
  const out: string[] = [];
  if (card.city) out.push(`${card.city}${card.region ? ` · ${card.region}` : ""}`);
  if (card.skills?.length) out.push(card.skills.slice(0, 4).join(" · "));
  if (card.reviews_count > 0) out.push(`${card.rating.toFixed(1)} ★ · ${card.reviews_count} avis`);
  if (card.budget_min && card.budget_max) out.push(`${card.budget_min} – ${card.budget_max} €`);
  if (card.availability) out.push(card.availability);
  return out;
}

/** Verso de la Carte AIME : une présentation courte, puis sa page. */
export function CardConsole({ card }: { card: Card }) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {card.bio || card.headline ? (
          <p className="text-[13.5px] leading-relaxed text-muted-foreground">
            {card.bio ?? card.headline}
          </p>
        ) : null}

        <ul className="mt-3 space-y-1.5 text-[13px] text-muted-foreground">
          {lines(card).map((l) => (
            <li key={l}>{l}</li>
          ))}
        </ul>
      </div>

      <Link
        to="/carte/$id"
        params={{ id: card.id }}
        className="mt-4 shrink-0 rounded-full bg-foreground px-4 py-2.5 text-center text-[13.5px] font-medium text-background transition-opacity hover:opacity-90"
      >
        Voir la page
      </Link>
    </div>
  );
}
