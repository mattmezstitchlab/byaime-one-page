import { useEffect, useState } from "react";
import { AiPanel } from "@/components/aime/panels/AiPanel";
import { onAi } from "@/components/aime/panels/aiSheet";
import { useAuth } from "@/hooks/useAuth";

/**
 * AIME elle-même : un panneau latéral droit, ouvert depuis n'importe où.
 * L'ancienne fenêtre qui descendait du haut (le « Studio ») a disparu :
 * une seule expression, cohérente avec Mon espace et les messages.
 */
export function AiSheet() {
  const { userId } = useAuth();
  const [open, setOpen] = useState(false);

  useEffect(() => onAi(() => setOpen(true)), []);

  return <AiPanel open={open} onOpenChange={setOpen} userId={userId} />;
}
