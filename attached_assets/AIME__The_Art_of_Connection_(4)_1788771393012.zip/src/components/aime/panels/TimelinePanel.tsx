import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { cardQuery, timelineQuery } from "@/lib/aime/queries";
import { EffectEditor } from "@/components/aime/panels/EffectEditor";
import { WebMemory } from "@/components/aime/memory/WebMemory";

import { cn } from "@/lib/utils";

const KINDS = ["souvenir", "evenement", "jalon", "intention", "contribution"] as const;
const KIND_LABEL: Record<(typeof KINDS)[number], string> = {
  souvenir: "Souvenir",
  evenement: "Événement",
  jalon: "Jalon",
  intention: "Intention",
  contribution: "Contribution (don, temps, compétence)",
};

/** Édition des repères de la timeline, sans quitter la page de la carte. */
export function TimelinePanel({
  cardId,
  initialKind,
}: {
  cardId: string;
  /** Type pré-choisi quand on arrive depuis le menu « + » (ex. contribution). */
  initialKind?: (typeof KINDS)[number];
}) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: card } = useQuery(cardQuery(cardId));
  const { data: entries = [] } = useQuery(timelineQuery(cardId));

  const isOwner = !!userId && card?.owner_id === userId;
  const [editing, setEditing] = useState<string | null>(null);
  const [kind, setKind] = useState<(typeof KINDS)[number]>(initialKind ?? "souvenir");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [startsAt, setStartsAt] = useState("");
  const [isPublic, setIsPublic] = useState(true);

  const reset = () => {
    setEditing(null);
    setTitle("");
    setDescription("");
    setStartsAt("");
    setKind("souvenir");
    setIsPublic(true);
  };

  const save = useMutation({
    mutationFn: async () => {
      if (!title.trim()) throw new Error("Donnez un titre au repère.");
      if (!startsAt) throw new Error("Choisissez une date.");
      const payload = {
        card_id: cardId,
        kind,
        title: title.trim(),
        description: description.trim() || null,
        starts_at: new Date(startsAt).toISOString(),
        is_public: isPublic,
      };
      if (editing) {
        const { error } = await supabase
          .from("card_timeline_entries")
          .update(payload)
          .eq("id", editing);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("card_timeline_entries").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      reset();
      qc.invalidateQueries({ queryKey: ["card-timeline", cardId] });
      toast("Repère enregistré");
    },
    onError: (e: Error) => toast(e.message),
  });

  const remove = useMutation({
    mutationFn: async (entryId: string) => {
      const { error } = await supabase.from("card_timeline_entries").delete().eq("id", entryId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["card-timeline", cardId] });
      toast("Repère supprimé");
    },
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div className="max-w-3xl">
      <p className="text-[16px] leading-relaxed text-muted-foreground">
        Passé, présent, futur : chaque repère s'affiche sur la règle graduée en haut de la page.
      </p>

      {isOwner && (
        <div className="mt-8">
          <WebMemory cardId={cardId} cardName={card?.name ?? ""} />
        </div>
      )}

      {isOwner && (

        <section className="mt-8 rounded-3xl hairline bg-card p-5 shadow-soft">
          <h3 className="text-[17px] font-semibold tracking-[-0.02em]">
            {editing ? "Modifier le repère" : "Nouveau repère"}
          </h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as (typeof KINDS)[number])}
              aria-label="Type de repère"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            >
              {KINDS.map((k) => (
                <option key={k} value={k}>
                  {KIND_LABEL[k]}
                </option>
              ))}
            </select>
            <input
              type="datetime-local"
              value={startsAt}
              onChange={(e) => setStartsAt(e.target.value)}
              aria-label="Date du repère"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Titre"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring sm:col-span-2"
            />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Détail (facultatif)"
              rows={3}
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring sm:col-span-2"
            />
          </div>
          <label className="mt-3 flex items-center gap-2 text-[14px]">
            <input
              type="checkbox"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
            />
            Visible publiquement
          </label>
          <div className="mt-4 flex gap-2">
            <button
              type="button"
              disabled={save.isPending}
              onClick={() => save.mutate()}
              className="inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-50"
            >
              <Plus className="h-4 w-4" strokeWidth={1.75} />
              {editing ? "Enregistrer" : "Ajouter le repère"}
            </button>
            {editing && (
              <button
                type="button"
                onClick={reset}
                className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px]"
              >
                Annuler
              </button>
            )}
          </div>
        </section>
      )}

      <section className="mt-8">
        <h3 className="text-[17px] font-semibold tracking-[-0.02em]">Repères existants</h3>
        {entries.length === 0 ? (
          <p className="mt-3 text-[15px] text-muted-foreground">Aucun repère pour l'instant.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {entries.map((e) => (
              <li
                key={e.id}
                className="flex flex-wrap items-start justify-between gap-3 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
              >
                <div>
                  <p className="font-medium">
                    {e.title}
                    <span className="text-muted-foreground">
                      {" · "}
                      {KIND_LABEL[e.kind as (typeof KINDS)[number]] ?? e.kind}
                    </span>
                  </p>
                  <p className="text-[13px] text-muted-foreground">
                    {new Date(e.starts_at).toLocaleString("fr-FR", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                    {!e.is_public && " · privé"}
                  </p>
                  {e.description && (
                    <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
                      {e.description}
                    </p>
                  )}
                </div>
                <EffectEditor
                  cardId={cardId}
                  entryId={e.id}
                  cardKind={card?.kind}
                  canManage={isOwner}
                />

                {isOwner && (
                  <span className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setEditing(e.id);
                        setKind((e.kind as (typeof KINDS)[number]) ?? "souvenir");
                        setTitle(e.title);
                        setDescription(e.description ?? "");
                        setIsPublic(e.is_public);
                        const d = new Date(e.starts_at);
                        const pad = (n: number) => `${n}`.padStart(2, "0");
                        setStartsAt(
                          `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`,
                        );
                      }}
                      className={cn(
                        "text-[13px] underline underline-offset-4",
                        editing === e.id && "font-medium",
                      )}
                    >
                      Modifier
                    </button>
                    <button
                      type="button"
                      aria-label="Supprimer"
                      onClick={() => remove.mutate(e.id)}
                      className="text-muted-foreground transition-colors hover:text-foreground"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                    </button>
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
