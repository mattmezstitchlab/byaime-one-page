import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  CONFIDENCE_LABEL,
  DIRECTION_SIGN,
  NATURES,
  SOURCE_HINT,
  SOURCE_LABEL,
  allowsIndicators,
  deriveConfidence,
  effectsQuery,
  formatIndicator,
  type EffectConfidence,
  type EffectSource,
} from "@/lib/aime/frequency";
import type { Database } from "@/integrations/supabase/types";

type CardKind = Database["public"]["Enums"]["card_kind"];

type Props = {
  cardId: string;
  entryId: string;
  cardKind: CardKind | null | undefined;
  canManage: boolean;
};

/**
 * Effets d'évolution d'un repère : ce qui a changé, avec quelle preuve.
 * Jamais un score — une trace vérifiable.
 */
export function EffectEditor({ cardId, entryId, cardKind, canManage }: Props) {
  const qc = useQueryClient();
  const { data: all = [] } = useQuery(effectsQuery(cardId));
  const effects = all.filter((e) => e.entry_id === entryId);
  const withNumbers = allowsIndicators(cardKind);

  const [open, setOpen] = useState(false);
  const [nature, setNature] = useState<string>(NATURES[0]);
  const [direction, setDirection] = useState("neutre");
  const [value, setValue] = useState("");
  const [unit, setUnit] = useState("€");
  const [source, setSource] = useState<EffectSource>("declare");
  const [note, setNote] = useState("");

  const add = useMutation({
    mutationFn: async () => {
      const numeric = withNumbers && value.trim() ? Number(value.replace(",", ".")) : null;
      if (numeric !== null && Number.isNaN(numeric)) throw new Error("Valeur invalide.");
      const { error } = await supabase.from("timeline_effects").insert({
        entry_id: entryId,
        card_id: cardId,
        nature,
        direction: withNumbers ? direction : "neutre",
        value: numeric,
        unit: numeric !== null ? unit.trim() || null : null,
        source,
        confidence: deriveConfidence(source, false),
        note: note.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setValue("");
      setNote("");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["timeline-effects", cardId] });
      toast("Évolution enregistrée");
    },
    onError: (e: Error) => toast(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("timeline_effects").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["timeline-effects", cardId] }),
    onError: (e: Error) => toast(e.message),
  });

  if (effects.length === 0 && !canManage) return null;

  return (
    <div className="mt-2 w-full">
      {effects.length > 0 && (
        <ul className="flex flex-wrap gap-1.5">
          {effects.map((f) => (
            <li
              key={f.id}
              className="inline-flex items-center gap-1.5 rounded-full hairline bg-secondary px-2.5 py-1 text-[12px]"
            >
              <span className="text-muted-foreground">{DIRECTION_SIGN[f.direction] ?? "—"}</span>
              <span>{f.nature}</span>
              {f.value !== null && (
                <span className="font-medium">{formatIndicator(Number(f.value), f.unit)}</span>
              )}
              <span className="text-muted-foreground">
                {SOURCE_LABEL[f.source as EffectSource]} ·{" "}
                {CONFIDENCE_LABEL[f.confidence as EffectConfidence]}
              </span>
              {canManage && (
                <button
                  type="button"
                  aria-label="Supprimer l'évolution"
                  onClick={() => remove.mutate(f.id)}
                  className="text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Trash2 className="h-3 w-3" strokeWidth={1.75} />
                </button>
              )}
            </li>
          ))}
        </ul>
      )}

      {canManage && !open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="mt-2 inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground underline underline-offset-4"
        >
          <Plus className="h-3.5 w-3.5" strokeWidth={1.75} />
          Qualifier ce qui a changé
        </button>
      )}

      {canManage && open && (
        <div className="mt-3 rounded-2xl hairline bg-background p-3">
          <div className="grid gap-2 sm:grid-cols-2">
            <select
              value={nature}
              onChange={(e) => setNature(e.target.value)}
              className="rounded-xl hairline bg-card px-3 py-2 text-[13.5px]"
            >
              {NATURES.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
            <select
              value={source}
              onChange={(e) => setSource(e.target.value as EffectSource)}
              className="rounded-xl hairline bg-card px-3 py-2 text-[13.5px]"
            >
              {(["declare", "documente", "estime"] as EffectSource[]).map((s) => (
                <option key={s} value={s}>
                  {SOURCE_LABEL[s]}
                </option>
              ))}
            </select>

            {withNumbers && (
              <>
                <select
                  value={direction}
                  onChange={(e) => setDirection(e.target.value)}
                  className="rounded-xl hairline bg-card px-3 py-2 text-[13.5px]"
                >
                  <option value="neutre">Sans variation</option>
                  <option value="hausse">En hausse</option>
                  <option value="baisse">En baisse</option>
                </select>
                <div className="flex gap-2">
                  <input
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    inputMode="decimal"
                    placeholder="Valeur (facultatif)"
                    className="min-w-0 flex-1 rounded-xl hairline bg-card px-3 py-2 text-[13.5px]"
                  />
                  <input
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="€"
                    className="w-20 rounded-xl hairline bg-card px-3 py-2 text-[13.5px]"
                  />
                </div>
              </>
            )}

            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Précision (facultatif)"
              className="rounded-xl hairline bg-card px-3 py-2 text-[13.5px] sm:col-span-2"
            />
          </div>

          <p className="mt-2 text-[12px] text-muted-foreground">{SOURCE_HINT[source]}</p>
          {!withNumbers && (
            <p className="mt-1 text-[12px] text-muted-foreground">
              Ce Monde est une personne : aucune valeur chiffrée n'est enregistrée, seulement ce qui
              a changé.
            </p>
          )}

          <div className="mt-3 flex gap-2">
            <button
              type="button"
              disabled={add.isPending}
              onClick={() => add.mutate()}
              className="rounded-xl bg-primary px-3.5 py-2 text-[13px] text-primary-foreground disabled:opacity-50"
            >
              Enregistrer l'évolution
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-xl hairline bg-card px-3.5 py-2 text-[13px]"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
