import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Share2, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { cardQuery, serviceRatesQuery } from "@/lib/aime/queries";
import { MONTHS, formatPrice, rateForDate, type Rate } from "@/lib/aime/pricing";
import { cn } from "@/lib/utils";

/**
 * Devis & tarifs — le contenu vit dans la page de la carte (onglet),
 * plus dans une page séparée : on ne quitte jamais le hero ni la timeline.
 */
export function QuotePanel({ cardId }: { cardId: string }) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: card } = useQuery(cardQuery(cardId));
  const { data: rates = [] } = useQuery(serviceRatesQuery(cardId));

  const isOwner = !!userId && card?.owner_id === userId;
  const [date, setDate] = useState("");
  const [label, setLabel] = useState("Prestation");
  const [month, setMonth] = useState<string>("");
  const [day, setDay] = useState("");
  const [price, setPrice] = useState("");
  const [unit, setUnit] = useState("forfait");

  const estimate = useMemo(
    () => rateForDate(rates as Rate[], date ? new Date(`${date}T12:00:00`) : null),
    [rates, date],
  );

  async function shareQuote() {
    const url = `${window.location.origin}/carte/${cardId}?onglet=devis${date ? `&date=${date}` : ""}`;
    const text = `Devis ${card?.name ?? ""}${
      estimate ? ` — ${formatPrice(estimate.price)} / ${estimate.unit}` : ""
    }`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "Devis AIME", text, url });
        return;
      }
      await navigator.clipboard.writeText(`${text}\n${url}`);
      toast("Lien du devis copié — il n'y a plus qu'à l'envoyer.");
    } catch {
      /* partage annulé */
    }
  }

  const addRate = useMutation({
    mutationFn: async () => {
      const value = Number.parseInt(price, 10);
      if (!Number.isFinite(value)) throw new Error("Indiquez un prix.");
      const { error } = await supabase.from("service_rates").insert({
        card_id: cardId,
        label: label.trim() || "Prestation",
        month: month ? Number.parseInt(month, 10) : null,
        day: day || null,
        price: value,
        unit,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setPrice("");
      setDay("");
      qc.invalidateQueries({ queryKey: ["service-rates"] });
      qc.invalidateQueries({ queryKey: ["service-rates-many"] });
      toast("Tarif ajouté");
    },
    onError: (e: Error) => toast(e.message),
  });

  const removeRate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("service_rates").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-rates"] });
      qc.invalidateQueries({ queryKey: ["service-rates-many"] });
    },
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div className="max-w-3xl">
      <p className="text-[16px] leading-relaxed text-muted-foreground">
        Les tarifs varient selon la saison et la date. Choisissez une date pour obtenir l'estimation
        exacte.
      </p>

      <section className="mt-8 rounded-3xl hairline bg-card p-5 shadow-soft">
        <h3 className="text-[17px] font-semibold tracking-[-0.02em]">Estimation par date</h3>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          aria-label="Date de la prestation"
          className="mt-3 rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
        />
        <p className="mt-4 text-[22px] font-semibold tracking-[-0.03em]">
          {estimate ? formatPrice(estimate.price) : "Sur demande"}
          {estimate && (
            <span className="ml-2 text-[13px] font-normal text-muted-foreground">
              / {estimate.unit} · {estimate.label}
            </span>
          )}
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={shareQuote}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-[13px] font-medium text-primary-foreground"
          >
            <Share2 className="h-4 w-4" strokeWidth={1.75} />
            Partager ce devis
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="rounded-full hairline bg-background px-4 py-2 text-[13px]"
          >
            Imprimer
          </button>
        </div>
      </section>

      <section className="mt-8">
        <h3 className="text-[17px] font-semibold tracking-[-0.02em]">Tarifs publiés</h3>
        {rates.length === 0 ? (
          <p className="mt-3 text-[15px] text-muted-foreground">
            Aucun tarif publié pour l'instant.
          </p>
        ) : (
          <ul className="mt-3 space-y-2">
            {rates.map((r) => (
              <li
                key={r.id}
                className="flex items-center justify-between gap-3 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
              >
                <span>
                  {r.label}
                  <span className="text-muted-foreground">
                    {" · "}
                    {r.day
                      ? new Date(`${r.day}T12:00:00`).toLocaleDateString("fr-FR", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })
                      : r.month
                        ? MONTHS[r.month - 1]
                        : "Toute l'année"}
                  </span>
                </span>
                <span className="flex items-center gap-3">
                  <span className="font-medium">{formatPrice(r.price)}</span>
                  <span className="text-[12px] text-muted-foreground">/ {r.unit}</span>
                  {isOwner && (
                    <button
                      type="button"
                      onClick={() => removeRate.mutate(r.id)}
                      aria-label="Supprimer"
                      className="text-muted-foreground transition-colors hover:text-foreground"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                    </button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {isOwner && (
        <section className="mt-8 rounded-3xl hairline bg-card p-5 shadow-soft">
          <h3 className="text-[17px] font-semibold tracking-[-0.02em]">Ajouter un tarif</h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Intitulé"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <input
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              inputMode="numeric"
              placeholder="Prix en €"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <select
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              aria-label="Mois concerné"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">Toute l'année</option>
              {MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
            <input
              type="date"
              value={day}
              onChange={(e) => setDay(e.target.value)}
              aria-label="Date précise"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <input
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              placeholder="Unité (forfait, journée…)"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="button"
              disabled={addRate.isPending}
              onClick={() => addRate.mutate()}
              className={cn(
                "inline-flex items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground",
                addRate.isPending && "opacity-50",
              )}
            >
              <Plus className="h-4 w-4" strokeWidth={1.75} />
              Ajouter
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
