import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Trash2, Wallet } from "lucide-react";
import { toast } from "sonner";
import { AimeField } from "@/components/aime/AimeField";
import { PanelShell } from "@/components/aime/panels/PanelShell";
import { documentsQuery } from "@/lib/bureau/queries";
import { creditLedgerQuery, creditsPurchased } from "@/lib/aime/credits";
import {
  aiMemoryQuery,
  aiUsageQuery,
  creditsThisMonth,
  deleteMemory,
  MONTHLY_AI_CREDITS,
  saveMemory,
} from "@/lib/aime/dashboard";

/**
 * Panneau droit d'AIME, réduit à l'essentiel — tout ce qui n'existait qu'ici
 * vit déjà ailleurs : la conversation dans Échanges, la création dans le
 * héros et le bouton « + », la mémoire et les crédits dans Mon espace.
 * Restent trois choses vraies : ce qu'elle doit retenir, ce qui réclame une
 * vérification, et le niveau de crédits.
 */
export function AiPanel({
  open,
  onOpenChange,
  userId,
  embedded,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  userId: string | null;
  embedded?: boolean;
}) {
  const qc = useQueryClient();
  const [note, setNote] = useState("");

  const { data: memories = [] } = useQuery(aiMemoryQuery(userId));
  const { data: usage = [] } = useQuery(aiUsageQuery(userId));
  const { data: ledger = [] } = useQuery(creditLedgerQuery(userId));
  const { data: documents = [] } = useQuery(documentsQuery(userId));

  const purchased = creditsPurchased(ledger);
  const left = Math.max(0, MONTHLY_AI_CREDITS - creditsThisMonth(usage));
  const total = MONTHLY_AI_CREDITS + purchased;

  const toFix = documents.filter(
    (d) => d.status !== "valide" || (d.uncertain_fields?.length ?? 0) > 0,
  ).length;

  const add = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("Connectez-vous d'abord.");
      const content = note.trim();
      if (!content) throw new Error("Écrivez ce qu'elle doit retenir.");
      /* Un titre court, dérivé des premiers mots : pas de champ en plus. */
      const label = content.split(/\s+/).slice(0, 4).join(" ");
      await saveMemory(userId, label, content);
    },
    onSuccess: () => {
      setNote("");
      qc.invalidateQueries({ queryKey: ["ai_memory"] });
      toast("C'est noté, elle s'en souviendra.");
    },
    onError: (e: Error) => toast(e.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteMemory(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ai_memory"] }),
  });

  return (
    <PanelShell
      embedded={embedded}
      open={open}
      onOpenChange={onOpenChange}
      side="right"
      title="AIME"
    >
      <div className="flex flex-col gap-8 px-4 pt-4 pb-10">
        {/* Ce qu'elle doit retenir : le seul geste du panneau. */}
        <section>
          <p className="eyebrow">Dites-lui</p>
          <AimeField
            value={note}
            onChange={setNote}
            onSubmit={() => add.mutate()}
            disabled={!note.trim() || add.isPending}
            tone="light"
            placeholder="Ce qu'elle doit retenir de vous…"
            submitLabel="Retenir"
            className="mt-3"
          />
          <ul className="mt-4 space-y-2">
            {memories.map((m) => (
              <li
                key={m.id}
                className="flex items-start justify-between gap-3 rounded-2xl hairline bg-card px-4 py-3"
              >
                <span>
                  <span className="block text-[14px] font-medium">{m.label}</span>
                  <span className="block text-[13px] text-muted-foreground">{m.content}</span>
                </span>
                <button
                  type="button"
                  aria-label="Oublier"
                  onClick={() => remove.mutate(m.id)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                </button>
              </li>
            ))}
            {memories.length === 0 && (
              <li className="text-[13px] text-muted-foreground">
                Elle ne retient rien pour l'instant.
              </li>
            )}
          </ul>
        </section>

        {/* Une seule alerte, quand il y a vraiment quelque chose à vérifier. */}
        {toFix > 0 && (
          <Link
            to="/mon-espace"
            hash="documents"
            onClick={() => onOpenChange(false)}
            className="flex items-center gap-3 rounded-2xl hairline bg-card p-4"
          >
            <AlertTriangle className="h-4 w-4 text-amber-500" strokeWidth={1.75} />
            <span className="text-[14px]">
              {toFix} pièce{toFix > 1 ? "s" : ""} à vérifier dans Documents
            </span>
          </Link>
        )}

        {/* Les crédits : une ligne, plus une carte. */}
        <div className="flex items-center justify-between gap-3 rounded-2xl hairline bg-card px-4 py-3">
          <span className="text-[14px] tabular-nums">
            {left + purchased}
            <span className="text-muted-foreground"> / {total} crédits</span>
          </span>
          <Link
            to="/credits"
            onClick={() => onOpenChange(false)}
            className="inline-flex items-center gap-2 text-[13px] font-medium underline underline-offset-4"
          >
            <Wallet className="h-4 w-4" strokeWidth={1.75} />
            Recharger
          </Link>
        </div>
      </div>
    </PanelShell>
  );
}
