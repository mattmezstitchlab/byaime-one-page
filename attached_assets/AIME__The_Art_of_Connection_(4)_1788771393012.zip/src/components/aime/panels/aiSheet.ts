/**
 * Canal unique d'ouverture du panneau d'AIME.
 * AIME s'ouvre toujours en panneau latéral droit, comme Mon espace et
 * les messages — plus aucune fenêtre qui descend du haut.
 */
const EVENT = "aime:ai-sheet";

export function openAi() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onAi(handler: () => void) {
  const listener = () => handler();
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
