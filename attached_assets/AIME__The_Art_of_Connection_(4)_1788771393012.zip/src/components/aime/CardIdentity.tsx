/**
 * Sous le hero d'une page publique : ce que la personne fait, ses autres pages,
 * ce qu'elle propose, ses projets, ses mondes. Les mondes sont déduits du métier
 * (`category_slug`) via la table de correspondance unique et s'affichent en
 * cartes vidéo : le verso montre les personnes de ce monde.
 * On ne quitte jamais la page : un savoir-faire ou un monde s'ouvre ici même.
 */
import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, X } from "lucide-react";
import { serviceRatesQuery, cardsQuery } from "@/lib/aime/queries";
import { supabase } from "@/integrations/supabase/client";
import { queryOptions } from "@tanstack/react-query";
import { worldsForTrade, worldLabel } from "@/lib/aime/tradeWorlds";
import { findUniverse } from "@/lib/aime/universeTree";
import { universeVideo } from "@/lib/aime/universeMedia";
import { universePoster } from "@/lib/aime/universePoster";
import { cardVisual } from "@/lib/aime/visuals";
import { KIND_LABEL } from "@/lib/aime/types";
import { cn } from "@/lib/utils";
import type { Card } from "@/lib/aime/types";

function cardEventsQuery(cardId: string) {
  return queryOptions({
    queryKey: ["card-events", cardId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("id,title,starts_at,city")
        .eq("card_id", cardId)
        .order("starts_at");
      if (error) return [];
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

/** Les autres pages de la même personne : association, société, lieu, projet… */
function siblingCardsQuery(ownerId: string | null) {
  return queryOptions({
    queryKey: ["sibling-cards", ownerId],
    enabled: !!ownerId,
    queryFn: async (): Promise<Card[]> => {
      const { data, error } = await supabase
        .from("cards")
        .select("*")
        .eq("owner_id", ownerId!)
        .order("created_at", { ascending: true });
      if (error) return [];
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

/** Les personnes que ce savoir-faire ou ce monde rassemble, ici même. */
function Neighbours({
  cards,
  exclude,
  to,
  search,
}: {
  cards: Card[];
  exclude: string;
  to: "/reseau";
  search: { tag?: string; monde?: string };
}) {
  const list = cards.filter((c) => c.id !== exclude).slice(0, 6);
  return (
    <div className="mt-3 rounded-2xl hairline bg-card p-4">
      {list.length === 0 ? (
        <p className="text-[13px] text-muted-foreground">Personne d'autre pour l'instant.</p>
      ) : (
        <ul className="space-y-1.5">
          {list.map((c) => (
            <li key={c.id}>
              <Link
                to="/carte/$id"
                params={{ id: c.id }}
                className="flex items-baseline justify-between gap-3 text-[14px] underline-offset-4 hover:underline"
              >
                <span className="truncate">{c.name}</span>
                {c.city && (
                  <span className="shrink-0 text-[12px] text-muted-foreground">{c.city}</span>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}
      <Link
        to={to}
        search={search}
        className="mt-3 inline-block text-[12px] text-muted-foreground underline-offset-4 hover:underline"
      >
        Voir sur la carte du réseau
      </Link>
    </div>
  );
}

/** Une carte vidéo de monde : au recto la vidéo, au verso les personnes. */
function WorldCard({
  world,
  index,
  cards,
  exclude,
}: {
  world: string;
  index: number;
  cards: Card[];
  exclude: string;
}) {
  const video = useRef<HTMLVideoElement>(null);
  const holder = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [armed, setArmed] = useState(false);
  const node = findUniverse(world);
  const label = worldLabel(world);
  const people = cards.filter((c) => c.id !== exclude).slice(0, 8);

  useEffect(() => {
    const el = holder.current;
    if (!el || armed) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setArmed(true);
          io.disconnect();
        }
      },
      { threshold: 0.35 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [armed]);

  const play = () => {
    const el = video.current;
    if (el && !open) void el.play().catch(() => {});
  };
  const pause = () => video.current?.pause();

  return (
    <motion.div
      ref={holder}
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: (index % 3) * 0.06 }}
      onMouseEnter={play}
      onMouseLeave={pause}
      className="relative overflow-hidden rounded-4xl hairline bg-card shadow-card"
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        onFocus={play}
        onBlur={pause}
        aria-expanded={open}
        aria-label={`Voir qui se rencontre dans ${label}`}
        className="group block w-full text-left"
      >
        {armed ? (
          <video
            ref={video}
            src={universeVideo(node?.video ?? world)}
            poster={universePoster(world)}
            muted
            loop
            playsInline
            preload="none"
            aria-hidden
            className="aspect-4/5 w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <img
            src={universePoster(world)}
            alt=""
            loading="lazy"
            className="aspect-4/5 w-full object-cover"
          />
        )}
        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 bg-gradient-to-t from-foreground/75 to-transparent p-4">
          <h3 className="text-[17px] font-semibold tracking-[-0.02em] text-background">{label}</h3>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-background/95 transition-transform group-hover:-translate-y-0.5">
            <ArrowUpRight className="h-4 w-4 text-foreground" strokeWidth={1.75} />
          </span>
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="absolute inset-0 flex flex-col bg-foreground/95 p-4 text-background backdrop-blur-sm"
          >
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-[16px] font-semibold tracking-[-0.02em]">{label}</h3>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Fermer"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-background/15 transition-colors hover:bg-background/25"
              >
                <X className="h-4 w-4" strokeWidth={1.75} />
              </button>
            </div>

            <div className="scrollbar-dark mt-3 min-h-0 flex-1 overflow-y-auto pr-1">
              {people.length === 0 ? (
                <p className="px-1 text-[13px] text-background/75">
                  Personne d'autre pour l'instant.
                </p>
              ) : (
                <ul className="space-y-0.5">
                  {people.map((c) => (
                    <li key={c.id}>
                      <Link
                        to="/carte/$id"
                        params={{ id: c.id }}
                        className="flex items-center gap-2 rounded-xl px-2 py-1 text-[13.5px] text-background/85 transition-colors hover:bg-background/10 hover:text-background"
                      >
                        <span className="min-w-0 flex-1 truncate">{c.name}</span>
                        {c.city && (
                          <span className="shrink-0 text-[12px] text-background/60">{c.city}</span>
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <Link
              to="/reseau"
              search={{ monde: world }}
              className="mt-3 flex items-center justify-between gap-3 rounded-full bg-background px-4 py-2.5 text-[13.5px] font-medium text-foreground"
            >
              Voir sur la carte du réseau
              <ArrowUpRight className="h-4 w-4" strokeWidth={1.75} />
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function CardIdentity({ card, tradeLabel }: { card: Card; tradeLabel?: string }) {
  const { data: rates = [] } = useQuery(serviceRatesQuery(card.id));
  const { data: events = [] } = useQuery(cardEventsQuery(card.id));
  const { data: allCards = [] } = useQuery(cardsQuery);
  const { data: siblings = [] } = useQuery(siblingCardsQuery(card.owner_id));
  const worlds = worldsForTrade(card.category_slug);
  const [openTag, setOpenTag] = useState<string | null>(null);

  const otherPages = siblings.filter((c) => c.id !== card.id);

  return (
    <div className="mx-auto max-w-5xl space-y-10 px-5 py-12">
      <section>
        <h2 className="text-xl font-semibold tracking-[-0.02em]">Ce que je fais</h2>
        <p className="mt-2 text-[15px] text-muted-foreground">
          {tradeLabel ?? card.category_slug ?? "Métier non renseigné"}
        </p>
        {card.skills.length > 0 && (
          <>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {card.skills.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setOpenTag((v) => (v === s ? null : s))}
                  className={cn(
                    "rounded-full bg-secondary px-2.5 py-1 text-[12px] transition-colors hover:bg-primary hover:text-primary-foreground",
                    openTag === s && "bg-primary text-primary-foreground",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
            {openTag && (
              <Neighbours
                cards={allCards.filter((c) => (c.skills ?? []).includes(openTag))}
                exclude={card.id}
                to="/reseau"
                search={{ tag: openTag }}
              />
            )}
          </>
        )}

        {otherPages.length > 0 && (
          <div className="mt-6">
            <p className="text-[14px] text-muted-foreground">
              Ses autres pages — association, société, lieu, projet.
            </p>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {otherPages.map((c) => (
                <li key={c.id}>
                  <Link
                    to="/carte/$id"
                    params={{ id: c.id }}
                    className="flex items-center gap-3 rounded-2xl hairline bg-card p-3 transition-colors hover:bg-secondary"
                  >
                    <img
                      src={cardVisual(c)}
                      alt=""
                      loading="lazy"
                      className="h-12 w-12 shrink-0 rounded-xl object-cover"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[14.5px] font-medium">{c.name}</span>
                      <span className="block truncate text-[12.5px] text-muted-foreground">
                        {[KIND_LABEL[c.kind], c.city].filter(Boolean).join(" · ")}
                      </span>
                    </span>
                    <ArrowUpRight
                      className="h-4 w-4 shrink-0 text-muted-foreground"
                      strokeWidth={1.75}
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      {rates.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Ce que je propose</h2>
          <ul className="mt-3 space-y-2">
            {rates.map((r) => (
              <li
                key={r.id}
                className="flex items-baseline justify-between gap-4 rounded-2xl hairline bg-card p-4"
              >
                <span className="text-[15px]">{r.label}</span>
                <span className="text-[14px] text-muted-foreground">
                  {r.price} € {r.unit}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {events.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Mes projets</h2>
          <ul className="mt-3 space-y-2">
            {events.slice(0, 8).map((e) => (
              <li key={e.id} className="rounded-2xl hairline bg-card p-4">
                <Link
                  to="/projets/$id"
                  params={{ id: e.id }}
                  className="text-[15px] font-medium underline-offset-4 hover:underline"
                >
                  {e.title}
                </Link>
                {e.city && <p className="mt-1 text-[13px] text-muted-foreground">{e.city}</p>}
              </li>
            ))}
          </ul>
        </section>
      )}

      {worlds.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold tracking-[-0.02em]">Mes mondes</h2>
          <p className="mt-1 text-[14px] text-muted-foreground">
            Les territoires où ce métier se rencontre. Ouvrez une carte pour voir qui s'y trouve.
          </p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {worlds.map((w, i) => (
              <WorldCard
                key={w}
                world={w}
                index={i}
                exclude={card.id}
                cards={allCards.filter((c) =>
                  (worldsForTrade(c.category_slug) as string[]).includes(w),
                )}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
