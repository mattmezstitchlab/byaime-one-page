import { cn } from "@/lib/utils";

type Props = {
  /** Valeur affichée, de 0 à 100. */
  value: number;
  className?: string;
};

/**
 * La seule barre de progression du site : même hauteur, même rayon,
 * même couleur partout (Ma Carte, Bureau, Projets).
 */
export function ProgressBar({ value, className }: Props) {
  const pct = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div
      role="progressbar"
      aria-valuenow={pct}
      aria-valuemin={0}
      aria-valuemax={100}
      className={cn("h-1.5 w-full overflow-hidden rounded-full bg-muted", className)}
    >
      <div
        className="h-full rounded-full bg-primary transition-all duration-500"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
