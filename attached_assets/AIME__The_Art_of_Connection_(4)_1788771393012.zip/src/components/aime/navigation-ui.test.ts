import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { describe, test } from "node:test";
import { fileURLToPath } from "node:url";

function read(rel: string) {
  return readFileSync(fileURLToPath(new URL(rel, import.meta.url)), "utf8");
}

describe("Navigation AIME — hiérarchie simplifiée", () => {
  test("LogoMenu reste minimal et n'expose plus les doubles portes", () => {
    const logo = read("./LogoMenu.tsx");
    assert.ok(!logo.includes("DISCOVER_MENU"));
    assert.ok(!logo.includes("Studio d'Aime"));
    assert.ok(!logo.includes("openStudio"));
    assert.ok(!logo.includes("Réglages et accessibilité"));
    assert.ok(!logo.includes("openSettings"));
    assert.ok(!logo.includes("Organiser un mariage"));
    assert.ok(!logo.includes("Carte du réseau"));
    assert.ok(!logo.includes("Rencontres"));
  });

  test("AppShell garde un point d'entrée unique vers Mon espace", () => {
    const shell = read("./AppShell.tsx");
    assert.ok(shell.includes("const personalUnread = unread + unreadThreads + docAlerts;"));
    assert.ok(shell.includes("onClick={openSpace}"));
    assert.ok(shell.includes("Ouvrir ${spaceLabel}"));
    assert.ok(!shell.includes("Mon espace et mes documents"));
    assert.ok(!shell.includes('className="hidden text-[13px] font-medium md:inline"'));
  });

  test("Le Studio a disparu : AIME vit dans un panneau latéral droit", () => {
    const shell = read("./AppShell.tsx");
    const space = read("./space/SpaceSheet.tsx");
    const panel = read("./panels/AiPanel.tsx");
    const sheet = read("./panels/AiSheet.tsx");

    // Plus de fenêtre qui descend du haut, plus de doublon « Studio ».
    assert.ok(!shell.includes("studio/Studio"));
    assert.ok(!shell.includes("<Studio />"));
    assert.ok(!space.includes("Studio"));
    assert.ok(!panel.includes("Studio"));

    // Une seule expression : le panneau d'AIME, à droite comme les autres.
    assert.ok(shell.includes("<AiSheet />"));
    assert.ok(sheet.includes("AiPanel"));
    assert.ok(panel.includes('side="right"'));
    assert.ok(space.includes("openAi()"));
    assert.ok(space.includes("Tout ce qui vous concerne est ici"));
  });

  test("Le panneau d'AIME est réduit à l'essentiel, tout réel", () => {
    const panel = read("./panels/AiPanel.tsx");
    // Les sections dupliquées ailleurs ont disparu.
    assert.ok(!panel.includes("Ses discussions"));
    assert.ok(!panel.includes("SECTION_ORDER"));
    assert.ok(!panel.includes("Ce qu'elle a fait"));
    assert.ok(!panel.includes("Comprendre"));
    assert.ok(!panel.includes("RoadmapPanel"));
    // Restent : la mémoire (Dites-lui), l'alerte documents, la ligne crédits.
    assert.ok(panel.includes("Dites-lui"));
    assert.ok(panel.includes("à vérifier dans Documents"));
    assert.ok(panel.includes("Recharger"));
  });

  test("Mon espace : une seule file d'attente et un pied allégé", () => {
    const space = read("./space/SpaceSheet.tsx");
    // Notifications + À faire fusionnées.
    assert.ok(space.includes("Ce qui vous attend"));
    assert.ok(!space.includes('">À faire<'));
    // Échanges vit dans la barre du bas, les crédits dans le panneau d'AIME.
    assert.ok(!space.includes('to="/credits"'));
    assert.ok(!space.includes("openMessages()"));
    // Le pied garde : Parler à AIME, Réglages, Déconnexion.
    assert.ok(space.includes("Parler à AIME"));
    assert.ok(space.includes("Réglages et accessibilité"));
    assert.ok(space.includes("Se déconnecter"));
  });

  test("Les barres basses deviennent icon-only tout en gardant leurs labels accessibles", () => {
    const dock = read("./GlobalDock.tsx");
    const panels = read("./project/ProjectPanels.tsx");

    for (const label of [
      "Chercher",
      "Le fil",
      "Réseau",
      "Documents",
      "Échanges",
      "Ma page et mes projets",
    ]) {
      assert.ok(dock.includes(`<span className="sr-only">${label}</span>`), label);
    }

    assert.ok(!dock.includes("<Bell /> Mon espace"));
    assert.ok(panels.includes('<span className="sr-only">{PROJECT_PANEL_LABEL[key]}</span>'));
  });
});
