import { cn } from "@/lib/utils";
import { Check, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  FAMILY_LABEL,
  FAMILY_ORDER,
  type TimelineFamily,
} from "@/lib/aime/timelineFilters";

/**
 * Calques de la ligne de temps. Désactiver un calque masque l'affichage,
 * jamais les données : « Tout » revient à l'état complet.
 */
export function TimelineLayers({
  active,
  onChange,
  counts,
  className,
  tone = "clair",
}: {
  active: TimelineFamily[];
  onChange: (next: TimelineFamily[]) => void;
  counts?: Partial<Record<TimelineFamily, number>>;
  className?: string;
  /** « media » : pastilles lisibles quand elles sont posées sur un visuel. */
  tone?: "clair" | "media";
}) {
  const toggle = (f: TimelineFamily) =>
    onChange(active.includes(f) ? active.filter((x) => x !== f) : [...active, f]);
  const available = FAMILY_ORDER.filter((f) => !counts || counts[f]);

  return (
    <Popover>
      <div className={cn("flex justify-end", className)}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            size="icon"
            className={cn(
              "relative h-10 w-10 rounded-full",
              tone === "media" &&
                "border-white/25 bg-black/55 text-white backdrop-blur-md hover:bg-black/75 hover:text-white",
            )}
            aria-label="Calques de la ligne de temps"
            title="Calques de la ligne de temps"
          >
            <SlidersHorizontal className="h-4 w-4" />
            {active.length > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-medium tabular-nums text-primary-foreground">
                {active.length}
              </span>
            )}
            <span className="sr-only">Calques</span>
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" side="top" sideOffset={8} className="w-64 p-2">
          <p className="px-2 pb-2 pt-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
            Afficher sur la ligne
          </p>
          <Button
            type="button"
            variant="ghost"
            onClick={() => onChange([])}
            className="h-9 w-full justify-between rounded-md px-2 text-[13px]"
          >
            Tous les repères
            {active.length === 0 && <Check className="h-4 w-4" />}
          </Button>
          <div role="group" aria-label="Calques de la ligne de temps" className="max-h-64 overflow-y-auto">
            {available.map((f) => {
              const n = counts?.[f];
              const on = active.includes(f);
              return (
                <Button
                  key={f}
                  type="button"
                  variant="ghost"
                  aria-pressed={on}
                  onClick={() => toggle(f)}
                  className="h-9 w-full justify-between rounded-md px-2 text-[13px]"
                >
                  <span>{FAMILY_LABEL[f]}</span>
                  <span className="flex items-center gap-2 text-muted-foreground">
                    {n ?? 0}
                    {on && <Check className="h-4 w-4 text-foreground" />}
                  </span>
                </Button>
              );
            })}
          </div>
        </PopoverContent>
      </div>
    </Popover>
  );
}
