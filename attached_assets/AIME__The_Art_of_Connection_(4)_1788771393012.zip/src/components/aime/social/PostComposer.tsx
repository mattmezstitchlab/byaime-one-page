import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ImagePlus, Link2, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { myCardsQuery } from "@/lib/aime/queries";
import { addPost } from "@/lib/aime/feed";
import { notifyFollowersOfPost } from "@/lib/aime/notifications";
import { guessKind, uploadMediaFile } from "@/lib/aime/media";
import { firstLinkIn } from "@/lib/aime/textLink";
import { cardVisual } from "@/lib/aime/visuals";
import { PostMedia } from "@/components/aime/social/PostMedia";

/** Écrire un moment court sur une de mes pages. */
export function PostComposer({ cardId }: { cardId?: string }) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const mine = useQuery(myCardsQuery(userId ?? null)).data ?? [];
  const [target, setTarget] = useState<string>(cardId ?? "");
  const [body, setBody] = useState("");
  const [media, setMedia] = useState<string | null>(null);
  const [linkOpen, setLinkOpen] = useState(false);
  const [linkDraft, setLinkDraft] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const kind = media ? guessKind(media) : "photo";

  /* Aperçu : le média joint (champ « Lien » ou photo) a priorité ; sinon la
     première adresse du texte — exactement la règle que PostCard appliquera
     à la publication. Le texte n'est jamais modifié ; éditer la phrase fait
     évoluer l'aperçu en direct. */
  const previewUrl = media ?? firstLinkIn(body);
  const previewKind = previewUrl ? guessKind(previewUrl) : null;


  const chosen = cardId ?? target ?? mine[0]?.id ?? "";
  const active = cardId ? cardId : chosen || mine[0]?.id || "";
  const card = mine.find((c) => c.id === active) ?? null;

  const upload = useMutation({
    mutationFn: async (file: File) => uploadMediaFile(userId!, file),
    onSuccess: (url) => setMedia(url),
    onError: () => toast.error("Envoi de l'image impossible"),
  });

  const send = useMutation({
    mutationFn: async () => {
      if (!userId || !active) throw new Error("auth");
      if (!body.trim() && !media) throw new Error("vide");
      if (body.trim().length > 3000) throw new Error("longueur");
      const post = await addPost({
        cardId: active,
        authorId: userId,
        body,
        mediaUrl: media,
        mediaKind: kind,
      });
      try {
        await notifyFollowersOfPost({
          postId: post.id,
          cardId: active,
          authorId: userId,
          cardName: card?.name ?? "Une page",
        });
      } catch {
        // La publication reste réussie même si une alerte secondaire n'est pas distribuée.
      }
    },
    onSuccess: () => {
      setBody("");
      setMedia(null);
      setLinkDraft("");
      setLinkOpen(false);
      void qc.invalidateQueries({ queryKey: ["fil"] });
      void qc.invalidateQueries({ queryKey: ["fil-decouverte"] });
      void qc.invalidateQueries({ queryKey: ["publications"] });
      toast.success("Publié");
    },
    onError: (e: Error) =>
      toast.error(
        e.message === "vide"
          ? "Écrivez un mot, ajoutez une photo ou un lien"

          : e.message === "longueur"
            ? "Votre moment est trop long"
            : "Publication impossible",
      ),
  });

  if (!userId || !mine.length) return null;

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex gap-3">
        <img
          src={cardVisual(card)}
          alt=""
          className="h-10 w-10 shrink-0 rounded-full object-cover"
        />
        <div className="flex-1 space-y-3">
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={3000}
            rows={2}
            placeholder="Quoi de neuf ?"
            className="w-full resize-none rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          {previewUrl ? (
            /* Aperçu avant publication : exactement la représentation que la
               publication aura dans le fil (même composant, même moteur). */
            <div className="relative">
              <PostMedia url={previewUrl} kind={previewKind} light className="border border-border" />
              {media ? (
                <button
                  type="button"
                  onClick={() => setMedia(null)}
                  className="absolute right-2 top-2 min-h-11 rounded-full bg-background/80 px-3 text-xs"
                >
                  Retirer
                </button>
              ) : null}
            </div>
          ) : null}
          {linkOpen && !media ? (
            <div className="flex gap-2">
              <input
                value={linkDraft}
                onChange={(e) => setLinkDraft(e.target.value)}
                placeholder="Collez une adresse YouTube, une vidéo, un article…"
                className="min-h-11 flex-1 rounded-xl border border-border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                type="button"
                onClick={() => {
                  const v = linkDraft.trim();
                  if (!/^https?:\/\//i.test(v)) {
                    toast.error("Adresse invalide : elle doit commencer par https://");
                    return;
                  }
                  setMedia(v);
                  setLinkDraft("");
                  setLinkOpen(false);
                }}
                className="min-h-11 rounded-full border border-border px-4 text-xs"
              >
                Ajouter
              </button>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center gap-2">
            {!cardId && mine.length > 1 ? (
              <select
                value={active}
                onChange={(e) => setTarget(e.target.value)}
                className="rounded-full border border-border bg-background px-3 py-1.5 text-xs"
              >
                {mine.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            ) : null}
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload.mutate(f);
                e.target.value = "";
              }}
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-border px-3 text-xs"
            >
              {upload.isPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <ImagePlus className="h-3.5 w-3.5" />
              )}
              Photo
            </button>
            <button
              type="button"
              onClick={() => setLinkOpen((v) => !v)}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-border px-3 text-xs"
            >
              <Link2 className="h-3.5 w-3.5" />
              Lien
            </button>

            <button
              type="button"
              onClick={() => send.mutate()}
              disabled={send.isPending}
              className="ml-auto inline-flex min-h-11 items-center gap-1.5 rounded-full bg-primary px-4 text-xs font-medium text-primary-foreground disabled:opacity-50"
            >
              {send.isPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Send className="h-3.5 w-3.5" />
              )}
              Publier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
