import { useQuery } from "@tanstack/react-query";
import { cardPostsQuery, type FeedItem } from "@/lib/aime/feed";
import { PostCard } from "@/components/aime/social/PostCard";
import { PostComposer } from "@/components/aime/social/PostComposer";
import type { Card } from "@/lib/aime/types";

/** Les moments publiés sur une page publique. */
export function CardMoments({ card, isMine }: { card: Card; isMine: boolean }) {
  const posts = useQuery(cardPostsQuery(card.id)).data ?? [];
  if (!posts.length && !isMine) return null;

  return (
    <section>
      <div id="moments" className="scroll-mt-28" />
      <h2 className="text-xl font-semibold tracking-[-0.02em]">Moments publiés</h2>
      <p className="mt-1 text-[14px] text-muted-foreground">
        Les nouvelles publiées par cette page. Les mots laissés par les visiteurs sont plus bas.
      </p>
      {isMine ? (
        <div className="mt-4">
          <PostComposer cardId={card.id} />
        </div>
      ) : null}
      <div className="mt-4 space-y-4">
        {posts.map((p) => (
          <PostCard key={p.id} item={{ ...p, card } as FeedItem} />
        ))}
      </div>
    </section>
  );
}
