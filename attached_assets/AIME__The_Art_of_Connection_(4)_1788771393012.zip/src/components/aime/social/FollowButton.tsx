import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { UserCheck, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { follow, followersQuery, unfollow } from "@/lib/aime/social";
import { pushNotification } from "@/lib/aime/notifications";

/** Suivre une page : on est prévenu de ce qui s'y passe. */
export function FollowButton({
  cardId,
  ownerId,
  cardName,
}: {
  cardId: string;
  ownerId?: string | null;
  cardName?: string | null;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const followers = useQuery(followersQuery(cardId));
  const list = followers.data ?? [];
  const mine = !!userId && list.some((f) => f.follower_id === userId);

  const act = useMutation({
    mutationFn: async () => {
      if (!userId) {
        await navigate({ to: "/auth", search: { next: `/carte/${cardId}` } });
        return;
      }
      if (mine) return unfollow(userId, cardId);
      await follow(userId, cardId);
      await pushNotification({
        userId: ownerId,
        from: userId,
        kind: "abonnement",
        title: "Une personne suit votre page",
        body: cardName ? `Nouvel abonné sur « ${cardName} »` : "Nouvel abonné",
        url: `/carte/${cardId}`,
        targetType: "carte",
        targetId: cardId,
      });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["follows", cardId] });
      void qc.invalidateQueries({ queryKey: ["mes-abonnements"] });
    },
    onError: (e: Error) =>
      toast.error(e.message === "auth" ? "Connectez-vous pour suivre" : "Action impossible"),
  });

  return (
    <Button
      type="button"
      variant={mine ? "secondary" : "default"}
      className="min-h-11 rounded-full"
      disabled={act.isPending}
      onClick={() => act.mutate()}
    >
      {mine ? <UserCheck className="mr-1.5 size-4" /> : <UserPlus className="mr-1.5 size-4" />}
      {mine ? "Suivi" : "Suivre"}
      {list.length > 0 && (
        <span className="ml-1.5 text-[12px] opacity-70">{list.length}</span>
      )}
    </Button>
  );
}
