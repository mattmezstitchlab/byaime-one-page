import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import {
  EMOJIS,
  REACTION_LABEL,
  countByEmoji,
  reactionsQuery,
  toggleReaction,
  type Target,
} from "@/lib/aime/social";
import { pushNotification } from "@/lib/aime/notifications";
import { HandHeart, Heart, PartyPopper, Smile, Sparkle } from "lucide-react";
import { cn } from "@/lib/utils";

/** Les petites réactions : un signe, un compte, un clic. */
export function ReactionBar({
  target,
  ownerId,
  url,
}: {
  target: Target;
  ownerId?: string | null;
  url?: string;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const list = useQuery(reactionsQuery(target)).data ?? [];
  const counts = countByEmoji(list);

  const act = useMutation({
    mutationFn: async (emoji: string) => {
      if (!userId) {
        await navigate({ to: "/auth", search: { next: url ?? "/fil" } });
        return;
      }
      const mine = list.find((r) => r.user_id === userId && r.emoji === emoji);
      await toggleReaction(userId, target, emoji, mine);
      if (!mine) {
        await pushNotification({
          userId: ownerId,
          from: userId,
          kind: "reaction",
          title: `Nouvelle réaction · ${REACTION_LABEL[emoji] ?? ""}`.trim(),
          body: "Quelqu’un a réagi à votre publication.",
          url: url ?? null,
          targetType: target.type,
          targetId: target.id,
        });
      }
    },
    onSuccess: () =>
      void qc.invalidateQueries({ queryKey: ["reactions", target.type, target.id] }),
    onError: (e: Error) =>
      toast.error(e.message === "auth" ? "Connectez-vous pour réagir" : "Action impossible"),
  });

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {EMOJIS.map((emoji) => {
        const mine = !!userId && list.some((r) => r.user_id === userId && r.emoji === emoji);
        const n = counts[emoji] ?? 0;
        const Icon = REACTION_ICONS[emoji] ?? Heart;
        return (
          <button
            key={emoji}
            type="button"
            onClick={() => act.mutate(emoji)}
            title={REACTION_LABEL[emoji]}
            className={cn(
              "flex min-h-10 items-center justify-center gap-1.5 rounded-full border border-transparent px-3 text-[13px] transition-colors",
              mine
                ? "bg-primary/10 text-primary"
                : "bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground",
            )}
            aria-pressed={mine}
            aria-label={REACTION_LABEL[emoji]}
          >
            <Icon
              className="h-[18px] w-[18px]"
              strokeWidth={1.75}
              {...(mine ? { fill: "currentColor", fillOpacity: 0.18 } : {})}
              aria-hidden
            />
            {n > 0 && <span className="tabular-nums">{n}</span>}
          </button>
        );
      })}
    </div>
  );
}

/** Pictos modernes au trait — plus d'émoticônes système. */
const REACTION_ICONS: Record<string, typeof Heart> = {
  coeur: Heart,
  bravo: PartyPopper,
  rire: Smile,
  waouh: Sparkle,
  merci: HandHeart,
};
