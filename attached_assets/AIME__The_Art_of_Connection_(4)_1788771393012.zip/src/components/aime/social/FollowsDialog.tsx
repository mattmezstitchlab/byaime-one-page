import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Users, UserRound, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { cardsQuery } from "@/lib/aime/queries";
import { followersQuery, myFollowsQuery, peopleQuery, unfollow } from "@/lib/aime/social";

/** « 12 abonnés » : la liste des personnes qui suivent une page. */
export function FollowersButton({ cardId }: { cardId: string }) {
  const [open, setOpen] = useState(false);
  const followers = useQuery(followersQuery(cardId));
  const list = followers.data ?? [];
  const people = useQuery(peopleQuery(list.map((f) => f.follower_id)));

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="ghost" className="min-h-11 rounded-full px-3 text-[13px]">
          <Users className="mr-1.5 size-4" strokeWidth={1.75} />
          {list.length} abonné{list.length > 1 ? "s" : ""}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Abonnés</DialogTitle>
          <DialogDescription>Les personnes qui suivent cette page.</DialogDescription>
        </DialogHeader>
        {followers.isLoading ? (
          <p className="py-6 text-center text-[13.5px] text-muted-foreground">Chargement…</p>
        ) : list.length === 0 ? (
          <p className="py-6 text-center text-[13.5px] text-muted-foreground">
            Personne ne suit encore cette page.
          </p>
        ) : (
          <ul className="max-h-[60vh] space-y-1 overflow-y-auto">
            {list.map((f) => {
              const person = people.data?.[f.follower_id];
              return (
                <li key={f.follower_id} className="flex min-h-11 items-center gap-3 rounded-2xl px-2 py-1.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full hairline bg-background">
                    {person?.avatar ? (
                      <img src={person.avatar} alt="" className="h-full w-full object-cover" loading="lazy" />
                    ) : (
                      <UserRound className="h-4 w-4" strokeWidth={1.75} />
                    )}
                  </span>
                  <span className="truncate text-[14px]">{person?.name ?? "Quelqu'un"}</span>
                </li>
              );
            })}
          </ul>
        )}
      </DialogContent>
    </Dialog>
  );
}

/** Mes abonnements : les pages que je suis, avec la sortie à portée de doigt. */
export function MyFollowsList() {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const follows = useQuery(myFollowsQuery(userId));
  const cards = useQuery(cardsQuery);
  const byId = new Map((cards.data ?? []).map((c) => [c.id, c]));
  const list = follows.data ?? [];

  const stop = useMutation({
    mutationFn: async (cardId: string) => {
      if (!userId) return;
      await unfollow(userId, cardId);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["mes-abonnements"] });
      void qc.invalidateQueries({ queryKey: ["follows"] });
    },
    onError: () => toast.error("Action impossible"),
  });

  if (follows.isLoading) {
    return <p className="mt-3 text-[13.5px] text-muted-foreground">Chargement…</p>;
  }
  if (list.length === 0) {
    return (
      <p className="mt-3 text-[13.5px] text-muted-foreground">
        Vous ne suivez encore aucune page.
      </p>
    );
  }

  return (
    <ul className="mt-3 space-y-1.5">
      {list.map((f) => {
        const card = byId.get(f.card_id);
        return (
          <li
            key={f.card_id}
            className="flex items-center gap-3 rounded-2xl hairline bg-card px-3 py-2 shadow-soft"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full hairline bg-background">
              {card?.image_url ? (
                <img src={card.image_url} alt="" className="h-full w-full object-cover" loading="lazy" />
              ) : (
                <UserRound className="h-4 w-4" strokeWidth={1.75} />
              )}
            </span>
            <Link
              to="/carte/$id"
              params={{ id: f.card_id }}
              className="min-w-0 flex-1 truncate text-[14px]"
            >
              {card?.name ?? "Une page"}
            </Link>
            <button
              type="button"
              onClick={() => stop.mutate(f.card_id)}
              disabled={stop.isPending}
              aria-label={`Ne plus suivre ${card?.name ?? "cette page"}`}
              title="Ne plus suivre"
              className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-muted"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </li>
        );
      })}
    </ul>
  );
}
