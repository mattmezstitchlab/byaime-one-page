import { Link } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { ago, removePost, type FeedItem } from "@/lib/aime/feed";
import { cardVisual } from "@/lib/aime/visuals";
import { ReactionBar } from "@/components/aime/social/ReactionBar";
import { CommentsSection } from "@/components/aime/social/CommentsSection";
import { guessKind } from "@/lib/aime/media";
import { firstLinkIn } from "@/lib/aime/textLink";
import { SocialSafetyMenu } from "@/components/aime/social/SocialSafetyMenu";
import { PostMedia } from "@/components/aime/social/PostMedia";

/** Une publication du fil : qui, quand, quoi, et les échanges dessous. */
export function PostCard({ item }: { item: FeedItem }) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const mine = !!userId && (userId === item.author_id || userId === item.card?.owner_id);

  const del = useMutation({
    mutationFn: () => removePost(item.id),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["fil"] });
      void qc.invalidateQueries({ queryKey: ["fil-decouverte"] });
      void qc.invalidateQueries({ queryKey: ["publications"] });
      toast.success("Publication retirée");
    },
    onError: () => toast.error("Suppression impossible"),
  });

  const url = `/carte/${item.card_id}`;

  /* Média joint explicitement (champ media_url) ou, à défaut, première
     adresse collée dans le texte — le moteur média existant la classe
     (YouTube, vidéo, audio, image, lien) et la montre. Les publications
     anciennes gagnent la prévisualisation, aucune écriture nécessaire ;
     texte sans adresse : rien ne change. */
  const mediaUrl = item.media_url ?? firstLinkIn(item.body);
  const mediaKind = item.media_url ? item.media_kind : mediaUrl ? guessKind(mediaUrl) : null;

  return (
    <article className="rounded-2xl border border-border bg-card p-4">
      <header className="flex items-center gap-3">
        <img src={cardVisual(item.card)} alt="" className="h-10 w-10 rounded-full object-cover" />
        <div className="min-w-0 flex-1">
          <Link to="/carte/$id" params={{ id: item.card_id }} className="block truncate font-medium">
            {item.card?.name ?? "Une page"}
          </Link>
          <p className="text-xs text-muted-foreground">{ago(item.created_at)}</p>
        </div>
        {mine ? (
          <button
            type="button"
            onClick={() => del.mutate()}
            aria-label="Supprimer"
            className="grid h-11 w-11 place-items-center rounded-full text-muted-foreground hover:text-foreground"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        ) : (
          <SocialSafetyMenu
            targetType="moment"
            targetId={item.id}
            personId={item.author_id}
            personName={item.card?.name}
          />
        )}
      </header>

      {item.body ? <p className="mt-3 whitespace-pre-wrap text-sm">{item.body}</p> : null}

      {mediaUrl ? <PostMedia url={mediaUrl} kind={mediaKind} className="mt-3" /> : null}


      <div className="mt-3 space-y-3 border-t border-border pt-3">
        <ReactionBar
          target={{ type: "moment", id: item.id }}
          ownerId={item.card?.owner_id ?? null}
          url={url}
        />
        <CommentsSection
          target={{ type: "moment", id: item.id }}
          cardId={item.card_id}
          ownerId={item.card?.owner_id ?? null}
          url={url}
        />
      </div>
    </article>
  );
}
