import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import {
  addComment,
  commentsQuery,
  peopleQuery,
  removeComment,
  type Target,
} from "@/lib/aime/social";
import { pushNotification } from "@/lib/aime/notifications";
import { SocialSafetyMenu } from "@/components/aime/social/SocialSafetyMenu";

function when(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Les commentaires publics d'une page, d'un média ou d'un moment. */
export function CommentsSection({
  target,
  cardId,
  ownerId,
  url,
}: {
  target: Target;
  cardId?: string | null;
  ownerId?: string | null;
  url?: string;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const comments = useQuery(commentsQuery(target)).data ?? [];
  const people = useQuery(peopleQuery(comments.map((c) => c.user_id))).data ?? {};
  const canDelete = (authorId: string) => !!userId && (userId === authorId || userId === ownerId);

  const refresh = () =>
    void qc.invalidateQueries({ queryKey: ["commentaires", target.type, target.id] });

  const send = useMutation({
    mutationFn: async () => {
      if (!userId) throw new Error("auth");
      if (!text.trim()) throw new Error("vide");
      await addComment({ userId, cardId: cardId ?? null, target, body: text });
      await pushNotification({
        userId: ownerId,
        from: userId,
        kind: "commentaire",
        title: "Nouveau commentaire",
        body: text.slice(0, 120),
        url: url ?? null,
        targetType: target.type,
        targetId: target.id,
      });
    },
    onSuccess: () => {
      setText("");
      refresh();
    },
    onError: (e: Error) =>
      toast.error(
        e.message === "auth"
          ? "Connectez-vous pour écrire"
          : e.message === "vide"
            ? "Écrivez d'abord un message"
            : "Envoi impossible",
      ),
  });

  const drop = useMutation({
    mutationFn: (id: string) => removeComment(id),
    onSuccess: refresh,
    onError: () => toast.error("Suppression impossible"),
  });

  return (
    <div className="space-y-4">
      <ul className="space-y-3">
        {comments.map((c) => {
          const p = people[c.user_id];
          return (
            <li key={c.id} className="flex gap-3">
              <span className="mt-0.5 size-8 shrink-0 overflow-hidden rounded-full bg-secondary">
                {p?.avatar && (
                  <img src={p.avatar} alt="" className="size-full object-cover" loading="lazy" />
                )}
              </span>
              <div className="min-w-0 flex-1 rounded-2xl bg-secondary px-3.5 py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-[13px] font-medium">{p?.name ?? "Quelqu'un"}</p>
                  <span className="shrink-0 text-[12px] text-muted-foreground">
                    {when(c.created_at)}
                  </span>
                </div>
                <p className="mt-1 whitespace-pre-wrap text-[14px] leading-relaxed">{c.body}</p>
              </div>
              {canDelete(c.user_id) ? (
                <button
                  type="button"
                  aria-label="Supprimer ce commentaire"
                  onClick={() => drop.mutate(c.id)}
                  className="mt-0 grid h-11 w-11 shrink-0 place-items-center rounded-full text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              ) : (
                <SocialSafetyMenu targetType="commentaire" targetId={c.id} personId={c.user_id} personName={p?.name} />
              )}
            </li>
          );
        })}
        {comments.length === 0 && (
          <li className="text-[14px] text-muted-foreground">
            Personne n'a encore écrit ici. Lancez la conversation.
          </li>
        )}
      </ul>

      {userId ? (
        <div className="space-y-2">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={2}
            placeholder="Écrire un commentaire…"
            maxLength={1500}
            className="min-h-24 rounded-2xl"
          />
          <div className="flex justify-end">
            <Button
              type="button"
              className="min-h-11 rounded-full"
              disabled={send.isPending || !text.trim()}
              onClick={() => send.mutate()}
            >
              Publier
            </Button>
          </div>
        </div>
      ) : (
        <Button asChild variant="outline" className="min-h-11 rounded-full">
          <Link to="/auth" search={{ next: url ?? `/carte/${cardId ?? ""}` }}>Se connecter pour laisser un mot</Link>
        </Button>
      )}
    </div>
  );
}
