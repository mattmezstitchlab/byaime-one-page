import { useState } from "react";
import { Link2, Play } from "lucide-react";
import { youtubeEmbed, youtubeThumb } from "@/lib/aime/media";
import { cn } from "@/lib/utils";

/** Le nom du site derrière une adresse, pour un lien lisible. */
function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

/**
 * La représentation d'un média de publication — une seule, partagée par le
 * fil (PostCard) et l'aperçu avant publication (PostComposer) : YouTube en
 * fenêtre, vidéo et audio directes en lecteurs natifs, image en grand, et
 * toute autre adresse en carte de lien — fallback propre, jamais de casse.
 * Le type vient du moteur média existant (guessKind / champ stocké).
 *
 * `light` (aperçu avant publication) : YouTube devient simple miniature —
 * aucun iframe ne se charge dans le Compositeur. Miniature impossible
 * (adresse atypique) ou image en échec (vidéo retirée) → retour au
 * comportement existant ; rien ne devient inutilisable.
 */
export function PostMedia({
  url,
  kind,
  className,
  light = false,
}: {
  url: string;
  kind?: string | null;
  className?: string;
  /** Aperçu léger : miniature YouTube au lieu de la fenêtre. */
  light?: boolean;
}) {
  const [thumbFailed, setThumbFailed] = useState(false);
  const thumb = light && kind === "youtube" && !thumbFailed ? youtubeThumb(url) : null;
  return (
    <div className={cn("overflow-hidden rounded-xl", className)}>
      {thumb ? (
        <div className="relative">
          <img
            src={thumb}
            alt="Miniature de la vidéo"
            loading="lazy"
            onError={() => setThumbFailed(true)}
            className="aspect-video w-full object-cover"
          />
          <span className="absolute inset-0 grid place-items-center" aria-hidden>
            <span className="grid h-12 w-12 place-items-center rounded-full bg-black/60 text-white">
              <Play className="h-5 w-5 fill-current" />
            </span>
          </span>
        </div>
      ) : kind === "youtube" && youtubeEmbed(url) ? (
        <iframe
          src={youtubeEmbed(url)!}
          title="Vidéo"
          allowFullScreen
          className="aspect-video w-full"
        />
      ) : kind === "video" ? (
        <video src={url} controls className="w-full" />
      ) : kind === "audio" ? (
        <audio src={url} controls className="w-full" />
      ) : kind === "lien" ? (
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer nofollow"
          className="flex items-center gap-2 rounded-xl border border-border px-3 py-3 text-sm hover:bg-muted"
        >
          <Link2 className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="truncate">{hostOf(url)}</span>
        </a>
      ) : (
        <img src={url} alt="" loading="lazy" className="max-h-[460px] w-full object-cover" />
      )}
    </div>
  );
}
