import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, Flag, MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import {
  blockPerson,
  myBlocksQuery,
  reportContent,
  unblockPerson,
  type ReportReason,
  type ReportTarget,
} from "@/lib/aime/safety";

const REASONS: Array<{ value: ReportReason; label: string }> = [
  { value: "harcelement", label: "Harcèlement" },
  { value: "haine", label: "Propos haineux" },
  { value: "nudite", label: "Contenu intime" },
  { value: "spam", label: "Spam ou arnaque" },
  { value: "usurpation", label: "Usurpation" },
  { value: "danger", label: "Danger immédiat" },
  { value: "autre", label: "Autre" },
];

export function SocialSafetyMenu({
  targetType,
  targetId,
  personId,
  personName,
}: {
  targetType: ReportTarget;
  targetId: string;
  personId?: string | null | undefined;
  personName?: string | null | undefined;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState<ReportReason>("spam");
  const [details, setDetails] = useState("");
  const blocks = useQuery(myBlocksQuery(userId)).data ?? [];
  const blocked = !!personId && blocks.some((item) => item.blocked_id === personId);

  const report = useMutation({
    mutationFn: () => {
      if (!userId) throw new Error("auth");
      return reportContent({ reporterId: userId, targetType, targetId, reason, details });
    },
    onSuccess: () => {
      setReportOpen(false);
      setDetails("");
      toast.success("Signalement transmis");
    },
    onError: (error: Error) =>
      toast.error(error.message === "auth" ? "Connectez-vous pour signaler" : "Signalement impossible"),
  });

  const block = useMutation({
    mutationFn: async () => {
      if (!userId || !personId) throw new Error("auth");
      return blocked ? unblockPerson(userId, personId) : blockPerson(userId, personId);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["blocages"] });
      void qc.invalidateQueries({ queryKey: ["fil"] });
      void qc.invalidateQueries({ queryKey: ["fil-decouverte"] });
      void qc.invalidateQueries({ queryKey: ["cards"] });
      void qc.invalidateQueries({ queryKey: ["publications"] });
      void qc.invalidateQueries({ queryKey: ["commentaires"] });
      void qc.invalidateQueries({ queryKey: ["reactions"] });
      void qc.invalidateQueries({ queryKey: ["notifications"] });
      toast.success(blocked ? "Personne débloquée" : "Personne bloquée");
    },
    onError: () => toast.error("Action impossible"),
  });

  if (!userId || personId === userId) return null;

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button type="button" variant="ghost" size="icon" className="h-11 w-11 rounded-full" aria-label="Sécurité et signalement">
            <MoreHorizontal />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onSelect={() => setReportOpen(true)} className="min-h-11">
            <Flag /> Signaler
          </DropdownMenuItem>
          {personId ? (
            <DropdownMenuItem onSelect={() => block.mutate()} className="min-h-11">
              <Ban /> {blocked ? "Débloquer" : `Bloquer ${personName ?? "cette personne"}`}
            </DropdownMenuItem>
          ) : null}
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>Signaler ce contenu</DialogTitle>
            <DialogDescription>Le signalement est transmis à l’équipe de modération.</DialogDescription>
          </DialogHeader>
          <label className="space-y-2 text-sm">
            <span className="font-medium">Motif</span>
            <select value={reason} onChange={(event) => setReason(event.target.value as ReportReason)} className="min-h-11 w-full rounded-xl border border-input bg-background px-3">
              {REASONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
            </select>
          </label>
          <label className="space-y-2 text-sm">
            <span className="font-medium">Précisions facultatives</span>
            <Textarea value={details} onChange={(event) => setDetails(event.target.value)} maxLength={1000} rows={4} />
          </label>
          <DialogFooter>
            <Button type="button" variant="outline" className="min-h-11" onClick={() => setReportOpen(false)}>Annuler</Button>
            <Button type="button" className="min-h-11" disabled={report.isPending} onClick={() => report.mutate()}>Envoyer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}