import { cn } from "@/lib/utils";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";

const DAY = 86_400_000;

export type PhaseKey = "tout" | "avant" | "pendant" | "apres";

export type CapsuleMode = "projet" | "personne";

const LABELS: Record<CapsuleMode, Record<PhaseKey, { label: string; hint: string }>> = {
  projet: {
    tout: { label: "Tout", hint: "Toute la ligne de temps" },
    avant: { label: "Avant", hint: "Les préparatifs" },
    pendant: { label: "Pendant", hint: "Le jour J, heure par heure" },
    apres: { label: "Après", hint: "Souvenirs et remerciements" },
  },
  personne: {
    tout: { label: "Tout", hint: "Toute la ligne de temps" },
    avant: { label: "Avant", hint: "Ce qui s'est déjà passé" },
    pendant: { label: "Aujourd'hui", hint: "Ce qui se joue en ce moment" },
    apres: { label: "À venir", hint: "Ce qui l'attend" },
  },
};

export function phaseKeys(mode: CapsuleMode): PhaseKey[] {
  return mode === "projet"
    ? ["tout", "avant", "pendant", "apres"]
    : ["tout", "avant", "pendant", "apres"];
}

/** Une même donnée, trois fenêtres : avant le pivot, le jour du pivot, après. */
export function inPhase(time: number, phase: PhaseKey, pivot: number): boolean {
  if (phase === "tout") return true;
  if (phase === "avant") return time < pivot;
  if (phase === "pendant") return time >= pivot && time < pivot + DAY;
  return time >= pivot + DAY;
}

export function phaseCountsOf(
  markers: TimelineMarker[],
  pivot: number,
): Record<PhaseKey, number> {
  const counts: Record<PhaseKey, number> = {
    tout: markers.length,
    avant: 0,
    pendant: 0,
    apres: 0,
  };
  for (const m of markers) {
    if (m.time < pivot) counts.avant += 1;
    else if (m.time < pivot + DAY) counts.pendant += 1;
    else counts.apres += 1;
  }
  return counts;
}

/** Les bornes de la fenêtre choisie, pour recadrer la ligne de temps. */
export function phaseWindow(
  phase: PhaseKey,
  pivot: number,
  first: number,
  last: number,
): { from: number; to: number } {
  if (phase === "avant") return { from: first, to: pivot };
  if (phase === "pendant") return { from: pivot, to: pivot + DAY };
  if (phase === "apres") return { from: pivot + DAY, to: last };
  return { from: first, to: last };
}

/**
 * Une seule capsule temporelle, partout : revenir à maintenant,
 * puis choisir la fenêtre de temps que l'on regarde.
 */
export function TimeCapsule({
  phase,
  counts,
  onPhase,
  onRecenter,
  mode = "projet",
  className,
  compact = false,
}: {
  phase: PhaseKey;
  counts: Record<PhaseKey, number>;
  onPhase: (phase: PhaseKey) => void;
  onRecenter: () => void;
  mode?: CapsuleMode;
  className?: string;
  compact?: boolean;
}) {
  const labels = LABELS[mode];
  return (
    <div
      className={cn(
        compact
          ? "grid grid-cols-4 items-center rounded-full border border-input bg-muted p-0.5"
          : "flex max-w-full items-center gap-0.5 overflow-x-auto rounded-full border border-primary-foreground/20 bg-foreground/40 p-0.5 backdrop-blur sm:gap-1 sm:p-1",
        className,
      )}
    >
      {!compact && <button
        type="button"
        title="Revenir à maintenant"
        onClick={onRecenter}
        className="shrink-0 rounded-full px-2 py-0.5 text-[11px] text-primary-foreground/70 transition hover:text-primary-foreground sm:px-3 sm:py-1 sm:text-[12px]"
      >
        Aujourd'hui
      </button>}
      {!compact && <span className="h-4 w-px shrink-0 bg-primary-foreground/25" />}
      {phaseKeys(mode).map((key) => (
        <button
          key={key}
          type="button"
          title={labels[key].hint}
          onClick={() => onPhase(key)}
          className={cn(
            compact
              ? "min-w-0 rounded-full px-2 py-1.5 text-[10px] text-muted-foreground transition sm:px-3 sm:text-[12px]"
              : "shrink-0 rounded-full px-2 py-0.5 text-[11px] text-primary-foreground/70 transition sm:px-3 sm:py-1 sm:text-[12px]",
            phase === key &&
              (compact ? "bg-background text-foreground shadow-sm" : "bg-primary-foreground text-foreground"),
          )}
        >
          {labels[key].label}
          <span className="ml-1 hidden tabular-nums opacity-60 sm:inline">{counts[key]}</span>
        </button>
      ))}
    </div>
  );
}
