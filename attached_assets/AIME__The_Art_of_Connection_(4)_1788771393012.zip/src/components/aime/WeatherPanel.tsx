import { useQuery } from "@tanstack/react-query";
import { CloudSun, Umbrella } from "lucide-react";
import { lookupWeather, planB, type WeatherLook } from "@/lib/aime/weather.functions";

/**
 * Météo de la date et du lieu, puis plan B. La météo n'annule rien :
 * elle donne à l'humain de quoi décider avant que ce soit urgent.
 */
export default function WeatherPanel({
  city,
  startsAt,
}: {
  city?: string | null | undefined;
  startsAt?: string | null | undefined;
}) {
  const day = startsAt ? startsAt.slice(0, 10) : null;

  const { data, isLoading } = useQuery({
    queryKey: ["weather", city, day],
    enabled: !!city && !!day,
    staleTime: 30 * 60 * 1000,
    queryFn: () => lookupWeather({ data: { city: city as string, day: day as string } }),
  });

  if (!city || !day) {
    return (
      <div className="rounded-3xl hairline bg-card p-5 text-[13px] text-muted-foreground shadow-soft">
        Indiquez une ville et une date sur le projet pour préparer un plan B.
      </div>
    );
  }

  const look = data as WeatherLook | undefined;

  return (
    <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
      <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        <CloudSun className="h-4 w-4" strokeWidth={1.75} /> Météo · {city}
      </p>
      {isLoading && <p className="mt-3 text-[13px] text-muted-foreground">Lecture du ciel…</p>}
      {look && (
        <>
          <p className="mt-3 text-[15px] leading-relaxed">{look.summary}</p>
          {look.kind === "saison" && (
            <p className="mt-1 text-[12px] text-muted-foreground">
              La date est trop lointaine pour une prévision : ceci est une tendance, pas une
              promesse.
            </p>
          )}
          {look.kind !== "inconnu" && (
            <div className="mt-4 border-t border-hairline pt-3">
              <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                <Umbrella className="h-4 w-4" strokeWidth={1.75} /> Plan B
              </p>
              <ul className="mt-2 space-y-1.5 text-[13px] leading-relaxed text-muted-foreground">
                {planB(look).map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </div>
  );
}
