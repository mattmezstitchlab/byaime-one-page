import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { bindAudioElement } from "@/lib/aime/audioBus";
import { speakNarration } from "@/lib/aime/play/speak.functions";
import { ago, discoverFeedQuery, type FeedItem } from "@/lib/aime/feed";
import { buildProjectStory } from "@/lib/aime/play/projectNarration";
import { guessKind, youtubeId } from "@/lib/aime/media";
import {
  listenUrl,
  publicTracksQuery,
  shuffle,
  trackArtist,
  trackTitle,
  type Track,
} from "@/lib/aime/playlist";

/** Deux écoutes : la musique au hasard, ou l'animatrice qui raconte le fil. */
export type RadioMode = "musique" | "fil" | "projet";

/** Ce qui se passe pendant une publication racontée. */
export type RadioPhase = "voix" | "media";

type RadioValue = {
  /** L'écoute est en cours. */
  on: boolean;
  toggle: () => void;
  mode: RadioMode;
  /** Choisir l'écoute — allume la radio si elle est éteinte. */
  setMode: (mode: RadioMode) => void;
  current: Track | null;
  next: Track | null;
  /** Morceau ou publication suivante. */
  skip: () => void;
  /** Tous les morceaux publics disponibles. */
  program: Track[];
  /** La publication racontée en ce moment. */
  post: FeedItem | null;
  phase: RadioPhase;
  /** La voix parle en ce moment. */
  speaking: boolean;
  /** La vidéo YouTube à lancer dans la scène, s'il y en a une. */
  youtube: string | null;
  /** Le projet raconté, quand l'écoute est en mode « projet ». */
  projectId: string | null;
  setProject: (id: string) => void;
  /** Le titre du projet raconté. */
  projectTitle: string | null;
};

const Ctx = createContext<RadioValue | null>(null);

const FALLBACK: RadioValue = {
  on: false,
  toggle: () => {},
  mode: "musique",
  setMode: () => {},
  current: null,
  next: null,
  skip: () => {},
  program: [],
  post: null,
  phase: "voix",
  speaking: false,
  youtube: null,
  projectId: null,
  setProject: () => {},
  projectTitle: null,
};

/** Renvoie un état inerte hors provider (routes d'erreur, rendus isolés). */
export function useRadio() {
  return useContext(Ctx) ?? FALLBACK;
}

/** Le média joué après la voix, s'il y en a un. */
function postMedia(p: FeedItem): { kind: "youtube" | "audio" | "video"; url: string } | null {
  const url = p.media_url;
  if (!url) return null;
  if (youtubeId(url)) return { kind: "youtube", url };
  const kind = guessKind(url);
  if (kind === "audio" || kind === "video") return { kind, url };
  return null;
}

/** Le texte que l'animatrice lit à voix haute. */
function narrationText(p: FeedItem): string {
  const who = p.card?.name ?? "Une page d'AIME";
  const body = (p.body ?? "").trim();
  const media = postMedia(p);
  const parts = [`${who}, ${ago(p.created_at)}.`];
  if (body) parts.push(body);
  if (media?.kind === "youtube") parts.push("Écoutons ce qui a été partagé.");
  else if (!body && p.media_url) parts.push("Une image partagée sur le fil.");
  return parts.join(" ").slice(0, 900);
}

/**
 * La radio d'AIME : plus de fréquence, plus de grille.
 * Une écoute au hasard des morceaux publics, ou le fil raconté à voix haute.
 */
export function RadioProvider({ children }: { children: ReactNode }) {
  const [on, setOn] = useState(false);
  const [mode, setModeState] = useState<RadioMode>("musique");
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState<RadioPhase>("voix");
  const [speaking, setSpeaking] = useState(false);
  const [youtube, setYoutube] = useState<string | null>(null);
  const [projectId, setProjectId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const voiceCache = useRef(new Map<string, string>());

  const speak = useServerFn(speakNarration);

  const { data: tracks = [] } = useQuery({
    ...publicTracksQuery,
    enabled: on && mode === "musique",
  });
  const { data: posts = [] } = useQuery({
    ...discoverFeedQuery(0),
    enabled: on && mode === "fil",
  });
  const { data: story = null } = useQuery({
    queryKey: ["project-story", projectId],
    enabled: on && mode === "projet" && !!projectId,
    staleTime: 5 * 60_000,
    queryFn: () => buildProjectStory(projectId!),
  });
  const [order, setOrder] = useState<Track[]>([]);
  const [feed, setFeed] = useState<FeedItem[]>([]);

  useEffect(() => {
    if (!on || mode !== "musique") return;
    setOrder((prev) => (prev.length === tracks.length ? prev : shuffle(tracks)));
  }, [on, mode, tracks]);

  useEffect(() => {
    if (!on || mode !== "fil") return;
    setFeed((prev) => (prev.length === posts.length ? prev : shuffle(posts)));
  }, [on, mode, posts]);

  const current = order[index % Math.max(1, order.length)] ?? null;
  const next = order[(index + 1) % Math.max(1, order.length)] ?? null;
  const post = mode === "fil" ? (feed[index % Math.max(1, feed.length)] ?? null) : null;

  const skip = useCallback(() => {
    setPhase("voix");
    setYoutube(null);
    setSpeaking(false);
    audioRef.current?.pause();
    setIndex((i) => i + 1);
  }, []);

  const setProject = useCallback((id: string) => {
    setProjectId(id);
    setModeState("projet");
    setIndex(0);
    setPhase("voix");
    setYoutube(null);
    setOn(true);
  }, []);

  const setMode = useCallback((m: RadioMode) => {
    setModeState(m);
    setIndex(0);
    setPhase("voix");
    setYoutube(null);
    setOn(true);
  }, []);

  // Musique : lecture d'un morceau à la fois dans toute l'application.
  useEffect(() => {
    if (!on || mode !== "musique") return;
    const url = current ? listenUrl(current) : null;
    if (!url) {
      if (order.length > 0) {
        const t = setTimeout(skip, 800);
        return () => clearTimeout(t);
      }
      return;
    }
    const el = audioRef.current ?? new Audio();
    if (!audioRef.current) bindAudioElement("radio", el);
    audioRef.current = el;
    el.src = url;
    el.onended = skip;
    el.onerror = skip;
    void el.play().catch(() => toast("Touchez le bouton radio pour lancer l'écoute."));
    return () => {
      el.onended = null;
      el.onerror = null;
    };
  }, [on, mode, current, order.length, skip]);

  // Le projet raconté : une phrase après l'autre, la voix seule.
  useEffect(() => {
    if (!on || mode !== "projet" || !story || story.parts.length === 0) return;
    const line = story.parts[index % story.parts.length]!;
    let cancelled = false;
    setSpeaking(true);
    void speak({ data: { text: line } })
      .then((r) => {
        if (cancelled) return;
        const el = audioRef.current ?? new Audio();
        if (!audioRef.current) bindAudioElement("radio", el);
        audioRef.current = el;
        el.src = `data:audio/mpeg;base64,${r.audio}`;
        el.onended = () => {
          setSpeaking(false);
          if (!cancelled) setIndex((i) => i + 1);
        };
        el.onerror = () => {
          setSpeaking(false);
          if (!cancelled) setIndex((i) => i + 1);
        };
        void el.play().catch(() => toast("Touchez le bouton radio pour lancer l'écoute."));
      })
      .catch((e: Error) => {
        setSpeaking(false);
        if (!cancelled) toast(e.message);
      });
    return () => {
      cancelled = true;
      setSpeaking(false);
    };
  }, [on, mode, story, index, speak]);

  // Le fil raconté : d'abord la voix, ensuite le média de la publication.
  useEffect(() => {
    if (!on || mode !== "fil" || phase !== "voix" || !post) return;
    let cancelled = false;
    setSpeaking(true);

    const play = (base64: string) => {
      if (cancelled) return;
      const el = audioRef.current ?? new Audio();
      if (!audioRef.current) bindAudioElement("radio", el);
      audioRef.current = el;
      el.src = `data:audio/mpeg;base64,${base64}`;
      el.onended = () => {
        setSpeaking(false);
        if (cancelled) return;
        if (postMedia(post)) setPhase("media");
        else skip();
      };
      el.onerror = () => {
        setSpeaking(false);
        if (!cancelled) skip();
      };
      void el.play().catch(() => toast("Touchez le bouton radio pour lancer l'écoute."));
    };

    const cached = voiceCache.current.get(post.id);
    if (cached) {
      play(cached);
    } else {
      void speak({ data: { text: narrationText(post) } })
        .then((r) => {
          voiceCache.current.set(post.id, r.audio);
          play(r.audio);
        })
        .catch((e: Error) => {
          setSpeaking(false);
          if (cancelled) return;
          toast(e.message);
          if (postMedia(post)) setPhase("media");
          else skip();
        });
    }

    return () => {
      cancelled = true;
      setSpeaking(false);
    };
  }, [on, mode, phase, post, skip, speak]);

  // Le média de la publication : trente secondes, puis on enchaîne.
  useEffect(() => {
    if (!on || mode !== "fil" || phase !== "media" || !post) return;
    const media = postMedia(post);
    if (!media) {
      skip();
      return;
    }
    if (media.kind === "youtube") {
      setYoutube(youtubeId(media.url));
      const t = setTimeout(skip, 32_000);
      return () => {
        clearTimeout(t);
        setYoutube(null);
      };
    }
    const el = audioRef.current ?? new Audio();
    if (!audioRef.current) bindAudioElement("radio", el);
    audioRef.current = el;
    el.src = media.url;
    el.onended = skip;
    el.onerror = skip;
    void el.play().catch(() => skip());
    const t = setTimeout(skip, 30_000);
    return () => {
      clearTimeout(t);
      el.onended = null;
      el.onerror = null;
    };
  }, [on, mode, phase, post, skip]);

  useEffect(() => {
    if (on) return;
    audioRef.current?.pause();
    setIndex(0);
    setOrder([]);
    setFeed([]);
    setPhase("voix");
    setYoutube(null);
    setSpeaking(false);
  }, [on]);

  // Écoute hors écran : contrôles média du système.
  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    if (!on) return;
    if (mode === "fil" && post) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: post.card?.name ?? "Le fil",
        artist: "Le fil raconté",
        album: "Radio AIME",
      });
      return;
    }
    if (!current) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: trackTitle(current),
      artist: trackArtist(current) ?? "Radio AIME",
      album: "Radio AIME",
    });
  }, [on, mode, current, post]);

  const value = useMemo<RadioValue>(
    () => ({
      on,
      toggle: () => setOn((v) => !v),
      mode,
      setMode,
      current,
      next,
      skip,
      program: order,
      post,
      phase,
      speaking,
      youtube,
      projectId,
      setProject,
      projectTitle: story?.title ?? null,
    }),
    [
      on,
      mode,
      setMode,
      current,
      next,
      skip,
      order,
      post,
      phase,
      speaking,
      youtube,
      projectId,
      setProject,
      story,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
