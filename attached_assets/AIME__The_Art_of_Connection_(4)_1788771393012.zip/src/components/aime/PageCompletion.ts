import type { Card } from "@/lib/aime/types";

/** Le même calcul que l'éditeur : quatre temps, un pourcentage. */
export function pageCompletion(card: Card): number {
  const steps = [
    card.name.trim().length > 2 && (card.headline ?? "").trim().length > 4,
    !!card.image_url,
    card.universes.length > 0 && card.category_slug !== "personne",
    !!card.city,
  ];
  return Math.round((steps.filter(Boolean).length / steps.length) * 100);
}
