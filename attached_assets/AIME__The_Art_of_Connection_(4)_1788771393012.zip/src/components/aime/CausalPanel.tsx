import { useMemo, useState } from "react";
import { Eye, EyeOff, Radar, Target, Waves, Zap } from "lucide-react";
import {
  WAVE_HINT,
  WAVE_LABEL,
  causalVariables,
  causalityFor,
  wavesFrom,
  type CausalLink,
} from "@/lib/aime/causal";
import { Suit, TENSE, useTense } from "@/lib/aime/tense";

/**
 * Le panneau causal d'un projet : point zéro, ondes proposées, et ce que chaque rôle
 * voit, subit ou ignore. Rien n'est appliqué : le moteur propose, l'humain décide.
 */
export default function CausalPanel({
  universeSlug,
  roleSlug,
  onAccept,
  acceptLabel = "Inscrire cet impact",
}: {
  universeSlug?: string | null | undefined;
  roleSlug?: string | null | undefined;
  onAccept?: ((variable: string, wave: CausalLink) => void) | undefined;
  acceptLabel?: string | undefined;
}) {
  const world = causalityFor(universeSlug);
  const variables = useMemo(() => causalVariables(universeSlug), [universeSlug]);
  const [variable, setVariable] = useState<string>(variables[0] ?? "");
  const waves = useMemo(() => wavesFrom(universeSlug, variable), [universeSlug, variable]);
  const role = world.roles.find((r) => r.slug === roleSlug) ?? world.roles[0];
  const { tense } = useTense();

  /** ♣ Futur : toutes les ondes du monde, dans l'ordre direct → indirect → différé. */
  const ORDER = { direct: 0, indirect: 1, differe: 2 } as const;
  const allWaves = useMemo(
    () => [...world.links].sort((a, b) => ORDER[a.wave] - ORDER[b.wave]),
    [world],
  );

  return (
    <section className="space-y-5">
      <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
        <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
          <Target className="h-4 w-4" strokeWidth={1.75} /> Point zéro · {world.label}
        </p>
        <p className="mt-3 text-[15px] leading-relaxed">{world.zeroPoint}</p>
        <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
          Variable critique : {world.criticalVariable}. {world.rupture}.
        </p>
        {world.secret ? (
          <p className="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-muted-foreground">
            <EyeOff className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
            Zone secrète possible : {world.secret}. La durée reste visible de tous, le contenu
            seulement de ses porteurs.
          </p>
        ) : null}
      </div>

      <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
        <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
          <Waves className="h-4 w-4" strokeWidth={1.75} /> Si cela bouge…
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {variables.map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => setVariable(v)}
              className={`rounded-full px-3.5 py-1.5 text-[13px] transition ${
                v === variable
                  ? "bg-primary text-primary-foreground"
                  : "hairline bg-background text-muted-foreground"
              }`}
            >
              {v}
            </button>
          ))}
        </div>

        <ul className="mt-4 space-y-3">
          {waves.map((w: CausalLink, i) => (
            <li
              key={`${w.to}-${i}`}
              className="border-t border-hairline pt-3 first:border-0 first:pt-0"
            >
              <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                <Zap className="h-3.5 w-3.5" strokeWidth={1.75} /> {WAVE_LABEL[w.wave]}
              </p>
              <p className="mt-1 text-[14px] font-medium">{w.to}</p>
              <p className="text-[13px] leading-relaxed text-muted-foreground">{w.effect}</p>
              <p className="mt-0.5 text-[12px] text-muted-foreground">{WAVE_HINT[w.wave]}</p>
              {onAccept ? (
                <button
                  type="button"
                  onClick={() => onAccept(variable, w)}
                  className="mt-2 rounded-full hairline bg-background px-3.5 py-1.5 text-[12px]"
                >
                  {acceptLabel}
                </button>
              ) : null}
            </li>
          ))}
          {waves.length === 0 && (
            <li className="text-[13px] text-muted-foreground">
              Aucune onde connue pour cette variable.
            </li>
          )}
        </ul>
        <p className="mt-4 text-[12px] leading-relaxed text-muted-foreground">
          Ces impacts sont proposés, jamais appliqués tout seuls. À vous de valider ce qui compte.
        </p>
      </div>

      {tense === "futur" ? (
        <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
          <p
            className={`flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] ${TENSE.futur.text}`}
          >
            <Suit suit="trefle" className="h-3.5 w-3.5" /> Futur · si rien ne bouge
          </p>
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
            Les ondes qui se déclencheront d'elles-mêmes dans ce monde, tant que personne ne
            tranche. Rien n'est fatal : c'est une liste d'occasions de prévenir.
          </p>
          <ul className="mt-4 space-y-2.5">
            {allWaves.map((w, i) => (
              <li key={`futur-${w.from}-${w.to}-${i}`} className="text-[13px] leading-relaxed">
                <span className="font-medium">{w.from}</span>
                <span className="text-muted-foreground"> → {w.to}</span>
                <span className="text-muted-foreground"> · {WAVE_LABEL[w.wave].toLowerCase()}</span>
                <p className="text-muted-foreground">{w.effect}</p>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {role ? (
        <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
          <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <Radar className="h-4 w-4" strokeWidth={1.75} /> Rôle · {role.label}
          </p>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div>
              <p className="flex items-center gap-1.5 text-[13px] font-semibold">
                <Eye className="h-3.5 w-3.5" strokeWidth={1.75} /> Ce que vous voyez
              </p>
              <ul className="mt-1.5 space-y-1 text-[13px] leading-relaxed text-muted-foreground">
                {role.sees.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
            <div>
              <p className="flex items-center gap-1.5 text-[13px] font-semibold">
                <Zap className="h-3.5 w-3.5" strokeWidth={1.75} /> Ce qui vous impacte
              </p>
              <ul className="mt-1.5 space-y-1 text-[13px] leading-relaxed text-muted-foreground">
                {role.impacted.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
            <div>
              <p className="flex items-center gap-1.5 text-[13px] font-semibold">
                <EyeOff className="h-3.5 w-3.5" strokeWidth={1.75} /> Ce qui vous est caché
              </p>
              <ul className="mt-1.5 space-y-1 text-[13px] leading-relaxed text-muted-foreground">
                {role.hidden.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
