import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bell,
  CalendarDays,
  FileText,
  FlaskConical,
  FolderOpen,
  LayoutGrid,
  Map,
  MessageCircle,
  Newspaper,
  Plus,
  Search,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import { eventsQuery, threadsQuery } from "@/lib/aime/queries";
import { documentsQuery } from "@/lib/bureau/queries";
import { notificationsQuery } from "@/lib/aime/notifications";
import { openMessages } from "@/components/aime/messagesSheet";
import { recentSearches } from "@/lib/aime/search";
import { Z } from "@/lib/aime/layers";
import { useDockHost, useDockMenu } from "@/components/aime/dockPresence";

/**
 * La barre du bas, partout : téléphone comme ordinateur.
 * Les portes restent les mêmes, mais leur expression devient iconique :
 * le picto agit, le libellé reste accessible via aria-label et title.
 */

/** Date courte, lisible : « 4 sept. ». */
function shortDate(iso: string | null | undefined) {
  if (!iso) return "";
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

export function GlobalDock({
  myCardId,
  unreadThreads,
  docAlerts,
  onDocuments,
  onMessages,
}: {
  myCardId: string | null;
  unreadThreads: number;
  docAlerts: number;
  onDocuments: () => void;
  onMessages: () => void;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { data: projects = [] } = useQuery({ ...eventsQuery(userId), enabled: !!userId });
  const { data: documents = [] } = useQuery(documentsQuery(userId));
  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const { data: notifications = [] } = useQuery(notificationsQuery(userId));
  const recent = recentSearches();
  useDockHost();
  const dockMenu = useDockMenu();

  const triggerCls = "relative h-11 min-w-0 flex-1 px-0";

  return (
    <div
      className={`fixed inset-x-0 bottom-0 ${Z.dock} border-t border-hairline bg-background/95 backdrop-blur-xl`}
    >
      <div
        className="mx-auto flex w-full max-w-3xl items-center gap-1 px-2 py-1.5"
        style={{ paddingBottom: "max(0.375rem, env(safe-area-inset-bottom))" }}
      >
        {/* Les portes de la page en cours (un projet) : même barre, un menu de plus. */}
        {dockMenu && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                variant={dockMenu.items.some((i) => i.active) ? "default" : "ghost"}
                className={triggerCls}
                aria-label={dockMenu.label}
                title={dockMenu.label}
              >
                <LayoutGrid className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
                <span className="sr-only">{dockMenu.label}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="min-w-60">
              <DropdownMenuLabel>{dockMenu.label}</DropdownMenuLabel>
              {dockMenu.items.map((item) => {
                const Icon = item.icon;
                return (
                  <DropdownMenuItem key={item.key} onSelect={() => dockMenu.onPick(item.key)}>
                    <Icon />
                    <span className="min-w-0 flex-1 truncate">
                      {item.label}
                      {item.hint && (
                        <span className="block truncate text-[11px] text-muted-foreground">
                          {item.hint}
                        </span>
                      )}
                    </span>
                    {item.active && (
                      <span className="ml-auto text-[11px] text-muted-foreground">ici</span>
                    )}
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {/* Chercher : les recherches récentes, puis la page complète. */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant={pathname.startsWith("/recherche") ? "default" : "ghost"}
              className={triggerCls}
              aria-label="Rechercher"
              title="Rechercher"
            >
              <Search className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">Chercher</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="start" className="min-w-64 max-w-[86vw]">
            <DropdownMenuLabel>Recherches récentes</DropdownMenuLabel>
            {recent.length === 0 ? (
              <DropdownMenuItem disabled>Aucune recherche pour l'instant</DropdownMenuItem>
            ) : (
              recent.slice(0, 6).map((q) => (
                <DropdownMenuItem
                  key={q}
                  onSelect={() => void navigate({ to: "/recherche", search: { q } })}
                >
                  <Search />
                  <span className="min-w-0 flex-1 truncate">{q}</span>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/recherche">
                <Search /> Ouvrir la recherche
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Le fil : les dernières notifications, puis le fil. */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant={pathname.startsWith("/fil") ? "default" : "ghost"}
              className={triggerCls}
              aria-label="Le fil"
              title="Le fil"
            >
              <Newspaper className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">Le fil</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="start" className="min-w-72 max-w-[86vw]">
            <DropdownMenuLabel>Dernières nouvelles</DropdownMenuLabel>
            {notifications.length === 0 ? (
              <DropdownMenuItem disabled>Rien de neuf pour l'instant</DropdownMenuItem>
            ) : (
              notifications.slice(0, 5).map((n) => (
                <DropdownMenuItem key={n.id} onSelect={() => void navigate({ to: "/mon-espace" })}>
                  <Bell />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{n.title}</span>
                    <span className="block truncate text-[11px] text-muted-foreground">
                      {[n.body, shortDate(n.created_at)].filter(Boolean).join(" · ")}
                    </span>
                  </span>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/fil">
                <Newspaper /> Aller au fil
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button
          asChild
          variant={pathname.startsWith("/reseau") ? "default" : "ghost"}
          className={triggerCls}
        >
          <Link to="/reseau" title="Carte du réseau" aria-label="Carte du réseau">
            <Map className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
            <span className="sr-only">Réseau</span>
          </Link>
        </Button>

        {/* Documents : les derniers déposés, puis le classeur complet. */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              title="Documents"
              aria-label="Documents"
              className={triggerCls}
            >
              <FolderOpen className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">Documents</span>
              {docAlerts > 0 && (
                <span className="absolute right-1 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[10px] font-medium text-white">
                  {docAlerts > 9 ? "9+" : docAlerts}
                </span>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="center" className="min-w-72 max-w-[86vw]">
            <DropdownMenuLabel>Derniers documents</DropdownMenuLabel>
            {documents.length === 0 ? (
              <DropdownMenuItem disabled>Aucun document déposé</DropdownMenuItem>
            ) : (
              documents.slice(0, 5).map((d) => (
                <DropdownMenuItem key={d.id} onSelect={() => onDocuments()}>
                  <FileText />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{d.file_name}</span>
                    <span className="block truncate text-[11px] text-muted-foreground">
                      {[d.counterpart ?? d.issuer, shortDate(d.issued_on ?? d.created_at)]
                        .filter(Boolean)
                        .join(" · ")}
                    </span>
                  </span>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => onDocuments()}>
              <FolderOpen /> Ouvrir les documents
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Échanges : les dernières conversations, puis la messagerie. */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              title="Échanges"
              aria-label="Échanges"
              className={triggerCls}
            >
              <MessageCircle className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">Échanges</span>
              {unreadThreads > 0 && (
                <span className="absolute right-1 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-medium text-white">
                  {unreadThreads > 9 ? "9+" : unreadThreads}
                </span>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="center" className="min-w-72 max-w-[86vw]">
            <DropdownMenuLabel>Derniers échanges</DropdownMenuLabel>
            {threads.length === 0 ? (
              <DropdownMenuItem disabled>Aucune conversation</DropdownMenuItem>
            ) : (
              threads.slice(0, 5).map((t) => {
                const msgs = [...(t.messages ?? [])].sort((a, b) =>
                  a.created_at < b.created_at ? 1 : -1,
                );
                const last = msgs[0];
                const unread = msgs.some((m) => !m.read_at && m.sender_id !== userId);
                return (
                  <DropdownMenuItem key={t.id} onSelect={() => openMessages(t.id)}>
                    <MessageCircle />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate">{t.title ?? "Conversation"}</span>
                      <span className="block truncate text-[11px] text-muted-foreground">
                        {last?.body ?? "Pas encore de message"}
                      </span>
                    </span>
                    {unread && <span className="ml-auto h-2 w-2 rounded-full bg-rose-500" />}
                  </DropdownMenuItem>
                );
              })
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => onMessages()}>
              <MessageCircle /> Tout voir
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Ma page et mes projets restent accessibles, sans doubler l'entrée Mon espace. */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant={
                pathname.startsWith("/carte/") || pathname.startsWith("/projets/")
                  ? "default"
                  : "ghost"
              }
              className={triggerCls}
              aria-label="Ma page et mes projets"
              title="Ma page et mes projets"
            >
              <UserRound className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">Ma page et mes projets</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="end" className="min-w-64 max-w-[86vw]">
            <DropdownMenuLabel>Ma page</DropdownMenuLabel>
            <DropdownMenuItem asChild>
              {myCardId ? (
                <Link to="/carte/$id" params={{ id: myCardId }}>
                  <UserRound /> Ma page personnelle
                </Link>
              ) : (
                <Link to="/bienvenue">
                  <UserRound /> Créer ma page
                </Link>
              )}
            </DropdownMenuItem>

            <DropdownMenuSeparator />
            <DropdownMenuLabel>Mes projets</DropdownMenuLabel>
            {projects.length === 0 ? (
              <DropdownMenuItem disabled>Aucun projet pour l'instant</DropdownMenuItem>
            ) : (
              projects.map((p) => (
                <DropdownMenuItem key={p.id} asChild>
                  <Link to="/projets/$id" params={{ id: p.id }}>
                    <CalendarDays />
                    <span className="min-w-0 flex-1 truncate">
                      {p.title}
                      <span className="block truncate text-[11px] text-muted-foreground">
                        {[
                          p.starts_at
                            ? new Date(p.starts_at).toLocaleDateString("fr-FR", {
                                day: "numeric",
                                month: "short",
                                year: "numeric",
                              })
                            : null,
                          p.city,
                        ]
                          .filter(Boolean)
                          .join(" · ")}
                      </span>
                    </span>
                    {pathname === `/projets/${p.id}` && (
                      <span className="ml-auto text-[11px] text-muted-foreground">ici</span>
                    )}
                  </Link>
                </DropdownMenuItem>
              ))
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/">
                <Plus /> Nouveau projet
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/lab">
                <FlaskConical /> Ouvrir un LAB
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
