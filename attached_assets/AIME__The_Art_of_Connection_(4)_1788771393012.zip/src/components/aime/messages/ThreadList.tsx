import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Search, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { cardsQuery, eventsQuery, threadsQuery } from "@/lib/aime/queries";
import { directoryQuery } from "@/lib/aime/chat";
import { cn } from "@/lib/utils";

function when(iso: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  if (diff < 60_000) return "à l'instant";
  if (diff < 3_600_000) return `${Math.round(diff / 60_000)} min`;
  if (diff < 86_400_000) return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (diff < 7 * 86_400_000) return d.toLocaleDateString("fr-FR", { weekday: "short" });
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

/** La liste des conversations : photo, nom, dernier message, non-lus. Rien d'autre. */
export function ThreadList({
  onOpen,
  onNew,
}: {
  onOpen: (id: string) => void;
  onNew: () => void;
}) {
  const { userId } = useAuth();
  const [q, setQ] = useState("");

  const { data: threads = [] } = useQuery({ ...threadsQuery(userId), refetchInterval: 8000 });
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: people = [] } = useQuery(directoryQuery);
  const { data: events = [] } = useQuery(eventsQuery(userId));

  const cardById = useMemo(() => new Map(cards.map((c) => [c.id, c])), [cards]);
  const eventById = useMemo(() => new Map(events.map((e) => [e.id, e])), [events]);
  const personById = useMemo(() => new Map(people.map((p) => [p.id, p])), [people]);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return threads
      .map((t) => {
        const card = t.card_id ? cardById.get(t.card_id) : null;
        const other = t.user_a === userId ? t.user_b : t.user_a;
        const person = other ? personById.get(other) : null;
        const title =
          t.title ?? t.subject ?? card?.name ?? person?.display_name ?? "Conversation";
        const messages = t.messages ?? [];
        const last = messages.at(-1);
        const unread = messages.filter((m) => m.sender_id !== userId && !m.read_at).length;
        const project = t.event_id ? (eventById.get(t.event_id)?.title ?? null) : null;
        const avatar = card?.image_url ?? person?.avatar_url ?? null;
        return { t, title, last, unread, project, avatar, group: t.kind !== "direct" };
      })
      .filter((r) =>
        !needle
          ? true
          : r.title.toLowerCase().includes(needle) ||
            (r.last?.body ?? "").toLowerCase().includes(needle),
      );
  }, [threads, cardById, personById, eventById, userId, q]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 pb-3">
        <div className="relative flex-1">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            strokeWidth={1.75}
          />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher"
            className="w-full rounded-full bg-secondary py-2.5 pl-9 pr-4 text-[14px] outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <button
          type="button"
          onClick={onNew}
          aria-label="Nouvelle conversation"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary"
        >
          <Plus className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </div>

      <ul className="min-h-0 flex-1 overflow-y-auto px-2 pb-4">
        {rows.length === 0 && (
          <li className="px-3 py-6 text-[14px] text-muted-foreground">
            Aucune conversation pour l'instant.
          </li>
        )}
        {rows.map(({ t, title, last, unread, project, avatar, group }) => (
          <li key={t.id}>
            <button
              type="button"
              onClick={() => onOpen(t.id)}
              className="flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors hover:bg-secondary"
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full bg-secondary">
                {avatar ? (
                  <img src={avatar} alt="" className="h-full w-full object-cover" />
                ) : group ? (
                  <Users className="h-5 w-5 text-muted-foreground" strokeWidth={1.75} />
                ) : (
                  <span className="text-[15px] font-medium text-muted-foreground">
                    {title.slice(0, 1).toUpperCase()}
                  </span>
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-baseline justify-between gap-2">
                  <span
                    className={cn("truncate text-[15px]", unread > 0 ? "font-semibold" : "font-medium")}
                  >
                    {title}
                  </span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">
                    {when(last?.created_at ?? t.last_message_at)}
                  </span>
                </span>
                <span className="flex items-center gap-2">
                  <span
                    className={cn(
                      "truncate text-[13px]",
                      unread > 0 ? "text-foreground" : "text-muted-foreground",
                    )}
                  >
                    {last?.body ?? "Nouveau fil"}
                  </span>
                  {unread > 0 && (
                    <span className="ml-auto h-2.5 w-2.5 shrink-0 rounded-full bg-primary" />
                  )}
                </span>
                {project && (
                  <span className="mt-0.5 block truncate text-[11px] text-muted-foreground">
                    Projet · {project}
                  </span>
                )}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
