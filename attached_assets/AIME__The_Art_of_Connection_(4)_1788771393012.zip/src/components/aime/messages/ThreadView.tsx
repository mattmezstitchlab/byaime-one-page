import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  ArrowLeft,
  ChevronDown,
  FileText,
  Loader2,
  Settings2,
  Paperclip,
  Send,
  Sparkle,
  Video,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { cardsQuery, eventsQuery, threadQuery, threadsQuery } from "@/lib/aime/queries";
import {
  directoryQuery,
  postMessage,
  saveThreadSettings,
  setVisio,
  threadMembersQuery,
  threadSettingsQuery,
  visioUrlFor,
  type AiMode,
} from "@/lib/aime/chat";
import { chatCopilot } from "@/lib/aime/chat.functions";
import { ingestFile } from "@/lib/bureau/ingest";
import { foldersQuery } from "@/lib/bureau/queries";
import { bureauContextQuery } from "@/lib/bureau/context";
import { ensureThreadFolder, linkDocumentToMessage } from "@/lib/bureau/threadFolders";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const TONES = ["tendre", "direct", "professionnel", "taquin"];

/** Une conversation : les bulles, le champ d'écriture, et l'aide d'Aime en tiroir. */
export function ThreadView({ threadId, onBack }: { threadId: string; onBack: () => void }) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const copilot = useServerFn(chatCopilot);

  const [draft, setDraft] = useState("");
  const [cockpit, setCockpit] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: people = [] } = useQuery(directoryQuery);
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const { data: folders = [] } = useQuery(foldersQuery(userId));
  const { data: ctx } = useQuery(bureauContextQuery(userId));
  const { data: messages = [] } = useQuery({ ...threadQuery(threadId), refetchInterval: 5000 });
  const { data: members = [] } = useQuery(threadMembersQuery(threadId));
  const { data: settings } = useQuery(threadSettingsQuery(threadId, userId));

  const thread = threads.find((t) => t.id === threadId) ?? null;
  const personById = useMemo(() => new Map(people.map((p) => [p.id, p])), [people]);
  const cardById = useMemo(() => new Map(cards.map((c) => [c.id, c])), [cards]);

  const nameOf = (id: string | null) =>
    !id ? "Membre" : id === userId ? "Moi" : (personById.get(id)?.display_name ?? "Membre");

  const title =
    (thread?.title as string | null) ||
    (thread?.subject as string | null) ||
    (thread?.card_id ? (cardById.get(thread.card_id)?.name ?? null) : null) ||
    "Conversation";

  const projectTitle = thread?.event_id
    ? (events.find((e) => e.id === thread.event_id)?.title ?? null)
    : null;

  const aiMode = (settings?.ai_mode ?? "off") as AiMode;
  const tone = settings?.tone ?? "tendre";

  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "end" });
  }, [messages.length, threadId]);

  const saveSettings = useMutation({
    mutationFn: async (patch: { ai_mode?: AiMode; tone?: string; auto_translate?: boolean }) => {
      if (!userId) return;
      await saveThreadSettings(threadId, userId, patch);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["thread-settings", threadId, userId] }),
    onError: (e: Error) => toast(e.message),
  });

  const send = useMutation({
    mutationFn: async (body?: string) => {
      const text = (body ?? draft).trim();
      if (!userId || !text) return;
      await postMessage({ threadId, senderId: userId, body: text });
    },
    onSuccess: () => {
      setDraft("");
      setSuggestion(null);
      void qc.invalidateQueries({ queryKey: ["thread", threadId] });
      void qc.invalidateQueries({ queryKey: ["threads"] });
    },
    onError: (e: Error) => toast(e.message),
  });

  /** Un document partagé entre dans la bibliothèque : même objet, deux chemins. */
  const attach = useMutation({
    mutationFn: async (file: File) => {
      if (!userId) return;
      const folderId = await ensureThreadFolder({
        userId,
        threadId,
        title,
        eventId: thread?.event_id ?? null,
        cardId: thread?.card_id ?? null,
      });
      const res = await ingestFile({
        file,
        userId,
        folders,
        folderId,
        ctx: ctx ?? null,
        onSoftError: () => undefined,
      });
      const inserted = await postMessage({
        threadId,
        senderId: userId,
        body: res.understood || `Document partagé : ${file.name}`,
        kind: "document",
        attachmentName: file.name,
      });
      void inserted;
      const last = await qc.fetchQuery(threadQuery(threadId));
      const message = [...last].reverse().find((m) => m.attachment_name === file.name);
      if (res.documentId && message) await linkDocumentToMessage(res.documentId, message.id);
    },
    onSuccess: () => {
      toast.success("Document partagé et rangé dans les documents");
      void qc.invalidateQueries({ queryKey: ["thread", threadId] });
      void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
      void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
    },
    onError: (e: Error) => toast(e.message),
  });

  const startVisio = useMutation({
    mutationFn: async () => {
      if (!userId) return;
      const url = thread?.visio_url ?? visioUrlFor(threadId);
      if (!thread?.visio_url) await setVisio(threadId, url);
      await postMessage({
        threadId,
        senderId: userId,
        body: `Visioconférence ouverte : ${url}`,
        kind: "visio",
      });
      window.open(url, "_blank", "noopener");
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["thread", threadId] });
      void qc.invalidateQueries({ queryKey: ["threads"] });
    },
    onError: (e: Error) => toast(e.message),
  });

  async function ask(mode: "suggestions" | "reponse" | "resume") {
    setBusy(mode);
    try {
      const out = await copilot({
        data: {
          mode,
          transcript: messages.slice(-24).map((m) => ({
            who: nameOf(m.sender_id),
            mine: m.sender_id === userId,
            text: m.body.slice(0, 2000),
          })),
          subject: title,
          participants: members.map((m) => nameOf(m.user_id)),
          tone,
          translateTo: null,
          target: null,
          instruction: null,
        },
      });
      const text = out?.body ?? out?.options?.[0] ?? null;
      if (text) setSuggestion(text);
      else toast("Aime n'a rien à proposer pour l'instant.");
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center gap-2 border-b border-hairline px-3 py-2.5">
        <button
          type="button"
          onClick={onBack}
          aria-label="Retour aux conversations"
          className="grid h-9 w-9 place-items-center rounded-full hover:bg-secondary"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.75} />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[15px] font-medium">{title}</p>
          <p className="truncate text-[11px] text-muted-foreground">
            {projectTitle ? `Projet · ${projectTitle}` : `${members.length || 2} participants`}
          </p>
        </div>
        <button
          type="button"
          onClick={() => startVisio.mutate()}
          aria-label="Ouvrir la visioconférence"
          className="grid h-9 w-9 place-items-center rounded-full hover:bg-secondary"
        >
          <Video className="h-4 w-4" strokeWidth={1.75} />
        </button>
        <button
          type="button"
          onClick={() => setCockpit((v) => !v)}
          aria-label="Aide d'Aime"
          className={cn(
            "grid h-9 w-9 place-items-center rounded-full hover:bg-secondary",
            cockpit && "bg-secondary",
          )}
        >
          <Sparkle className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </header>

      {cockpit && (
        <div className="border-b border-hairline bg-secondary/50 px-4 py-3">
          <div className="flex items-center gap-1 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {(["suggestions", "reponse", "resume"] as const).map((m) => (
              <button
                key={m}
                type="button"
                disabled={busy !== null}
                onClick={() => void ask(m)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-card px-3 py-1.5 text-[12px] hairline disabled:opacity-50"
              >
                {busy === m ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Sparkle className="h-3.5 w-3.5" strokeWidth={1.75} />
                )}
                {m === "suggestions" ? "Me souffler" : m === "reponse" ? "Écrire pour moi" : "Résumer"}
              </button>
            ))}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  aria-label="Réglages de l’aide AIME"
                  title="Réglages de l’aide AIME"
                  className="ml-auto grid h-8 w-8 shrink-0 place-items-center rounded-full bg-card hairline"
                >
                  <Settings2 className="h-3.5 w-3.5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Ton</DropdownMenuLabel>
                <DropdownMenuRadioGroup
                  value={tone}
                  onValueChange={(value) => saveSettings.mutate({ tone: value })}
                >
                  {TONES.map((item) => (
                    <DropdownMenuRadioItem key={item} value={item}>
                      {item}
                    </DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
                <DropdownMenuSeparator />
                <DropdownMenuCheckboxItem
                  checked={aiMode !== "off"}
                  onCheckedChange={(checked) =>
                    saveSettings.mutate({ ai_mode: checked ? "conseil" : "off" })
                  }
                >
                  AIME veille sur ce fil
                </DropdownMenuCheckboxItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          {suggestion && (
            <div className="mt-3 rounded-2xl bg-card p-3 text-[13px] hairline">
              <p className="whitespace-pre-wrap">{suggestion}</p>
              <div className="mt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDraft(suggestion);
                    setSuggestion(null);
                  }}
                  className="rounded-full bg-primary px-3 py-1.5 text-[12px] text-primary-foreground"
                >
                  Utiliser ce texte
                </button>
                <button
                  type="button"
                  onClick={() => setSuggestion(null)}
                  className="rounded-full px-3 py-1.5 text-[12px] hairline"
                >
                  Ignorer
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {messages.length === 0 && (
          <p className="text-[14px] text-muted-foreground">
            Écrivez le premier message de cette conversation.
          </p>
        )}
        {messages.map((m) => {
          const mine = m.sender_id === userId;
          return (
            <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
              <div
                className={cn(
                  "max-w-[78%] rounded-3xl px-4 py-2.5 text-[14px]",
                  mine ? "bg-primary text-primary-foreground" : "bg-secondary",
                )}
              >
                {!mine && (
                  <p className="mb-0.5 text-[11px] opacity-70">{nameOf(m.sender_id)}</p>
                )}
                <p className="whitespace-pre-wrap">{m.body}</p>
                {m.attachment_name && (
                  <p className="mt-1 inline-flex items-center gap-1.5 text-[12px] opacity-90">
                    <FileText className="h-3.5 w-3.5" strokeWidth={1.75} /> {m.attachment_name}
                  </p>
                )}
              </div>
            </div>
          );
        })}
        <div ref={bottom} />
      </div>

      <form
        className="flex items-end gap-2 border-t border-hairline px-3 py-3"
        onSubmit={(e) => {
          e.preventDefault();
          send.mutate(undefined);
        }}
      >
        <input
          ref={fileRef}
          type="file"
          accept="image/*,application/pdf"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) attach.mutate(file);
            if (fileRef.current) fileRef.current.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={attach.isPending}
          aria-label="Partager un document"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full hover:bg-secondary disabled:opacity-50"
        >
          {attach.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Paperclip className="h-4 w-4" strokeWidth={1.75} />
          )}
        </button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send.mutate(undefined);
            }
          }}
          rows={1}
          placeholder="Votre message"
          className="max-h-32 min-h-10 flex-1 resize-none rounded-3xl bg-secondary px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
        />
        <button
          type="submit"
          disabled={send.isPending || draft.trim().length === 0}
          aria-label="Envoyer"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-40"
        >
          <Send className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </form>

      <button type="button" onClick={onBack} className="sr-only">
        <ChevronDown className="h-4 w-4" /> Fermer
      </button>
    </div>
  );
}
