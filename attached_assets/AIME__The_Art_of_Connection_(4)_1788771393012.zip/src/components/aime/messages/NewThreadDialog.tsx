import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { X } from "lucide-react";
import { createGroupThread } from "@/lib/aime/chat";
import { sendMessage } from "@/lib/aime/messaging";
import { cn } from "@/lib/utils";

export type Person = {
  id: string;
  display_name: string;
  headline: string | null;
  city: string | null;
  avatar_url: string | null;
};

export function NewThreadDialog({
  me,
  people,
  onClose,
  onCreated,
  initialTitle,
  firstMessage,
}: {
  me: string;
  people: Person[];
  onClose: () => void;
  onCreated: (id: string) => void;
  initialTitle?: string;
  firstMessage?: string;
}) {
  const [title, setTitle] = useState(initialTitle ?? "");
  const [kind, setKind] = useState<"groupe" | "equipe">("groupe");
  const [picked, setPicked] = useState<string[]>([]);
  const [q, setQ] = useState("");

  const create = useMutation({
    mutationFn: () =>
      createGroupThread({
        me,
        title: title.trim() || "Nouvelle conversation",
        kind,
        memberIds: picked,
      }).then(async (id) => {
        const body = firstMessage?.trim();
        if (body) await sendMessage(id, me, body);
        return id;
      }),
    onSuccess: onCreated,
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-foreground/30 p-4">
      <div className="w-full max-w-md rounded-3xl bg-card p-6 shadow-soft">
        <div className="flex items-center justify-between">
          <p className="text-[16px] font-medium">Nouvelle conversation</p>
          <button type="button" onClick={onClose} aria-label="Fermer">
            <X className="h-4 w-4" strokeWidth={1.75} />
          </button>
        </div>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Titre — ex. Mariage du 12 juin"
          className="mt-4 w-full rounded-full hairline bg-background px-4 py-2.5 text-[14px] outline-none"
        />
        <div className="mt-3 grid grid-cols-2 gap-1 rounded-full bg-secondary p-1">
          {(
            [
              ["groupe", "Groupe"],
              ["equipe", "Équipe de travail"],
            ] as const
          ).map(([v, l]) => (
            <button
              key={v}
              type="button"
              onClick={() => setKind(v)}
              className={cn(
                "rounded-full px-2 py-1.5 text-[12px]",
                kind === v && "bg-primary text-primary-foreground",
              )}
            >
              {l}
            </button>
          ))}
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Chercher un membre…"
          className="mt-3 w-full rounded-full hairline bg-background px-4 py-2 text-[13px] outline-none"
        />
        <ul className="mt-2 max-h-52 space-y-1 overflow-y-auto">
          {people
            .filter((p) => p.display_name.toLowerCase().includes(q.toLowerCase()))
            .slice(0, 30)
            .map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() =>
                    setPicked((s) => (s.includes(p.id) ? s.filter((x) => x !== p.id) : [...s, p.id]))
                  }
                  className={cn(
                    "w-full rounded-2xl px-3 py-2 text-left text-[13px]",
                    picked.includes(p.id) ? "bg-primary text-primary-foreground" : "hairline",
                  )}
                >
                  {p.display_name}
                  <span className="opacity-70"> · {p.headline ?? p.city ?? "membre AIME"}</span>
                </button>
              </li>
            ))}
        </ul>
        <button
          type="button"
          disabled={create.isPending}
          onClick={() => create.mutate()}
          className="mt-4 w-full rounded-full bg-primary py-2.5 text-[14px] text-primary-foreground disabled:opacity-50"
        >
          Créer la conversation
        </button>
      </div>
    </div>
  );
}
