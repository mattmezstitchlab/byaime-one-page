import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { documentsQuery, foldersQuery } from "@/lib/bureau/queries";
import { eventsQuery } from "@/lib/aime/queries";
import { ensureProjectFolder } from "@/lib/bureau/threadFolders";
import { buildAlerts, markSeenNow, readSeenAt } from "@/lib/bureau/alerts";
import { FolderTree } from "@/components/bureau/FolderTree";
import { AddDocument } from "@/components/bureau/AddDocument";
import { DocViewer } from "@/components/aime/messages/DocViewer";

/**
 * Le mode Documents, dans le même panneau que les Échanges :
 * un arbre de dossiers vivant, un dossier par projet, un par conversation,
 * et le document s'ouvre sur place.
 */
export function DocumentsTab({
  onOpenThread,
  eventId,
}: {
  onOpenThread: (threadId: string) => void;
  /** Projet à mettre en avant : son dossier s'ouvre en premier. */
  eventId?: string | null;
}) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: folders = [] } = useQuery(foldersQuery(userId));
  const { data: docs = [] } = useQuery(documentsQuery(userId));
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const ensured = useRef(false);
  const [openDocId, setOpenDocId] = useState<string | null>(null);
  const [seenAt] = useState(() => readSeenAt());

  // Un projet = un dossier : on crée seulement ceux qui manquent.
  useEffect(() => {
    if (!userId || ensured.current || events.length === 0) return;
    const mine = events.filter((e) => e.owner_id === userId);
    const missing = mine.filter((e) => !folders.some((f) => f.event_id === e.id));
    if (missing.length === 0) return;
    ensured.current = true;
    void (async () => {
      for (const event of missing) {
        try {
          await ensureProjectFolder({ userId, eventId: event.id, title: event.title });
        } catch {
          /* un dossier de moins, ce n'est pas bloquant */
        }
      }
      void qc.invalidateQueries({ queryKey: ["bureau-folders"] });
    })();
  }, [userId, events, folders, qc]);

  // La visite vaut lecture : les pastilles « nouveau » s'éteignent en sortant.
  useEffect(() => () => markSeenNow(), []);

  const focusFolderId = eventId ? (folders.find((f) => f.event_id === eventId)?.id ?? null) : null;

  const alerts = useMemo(() => buildAlerts(docs, seenAt), [docs, seenAt]);
  const openDoc = docs.find((d) => d.id === openDocId) ?? null;

  if (!userId) return null;

  if (openDoc) {
    return (
      <DocViewer
        doc={openDoc}
        folders={folders}
        userId={userId}
        alert={alerts.get(openDoc.id)}
        onBack={() => setOpenDocId(null)}
        onOpenThread={onOpenThread}
      />
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between gap-3 border-b border-hairline px-4 pb-2.5">
        <p className="min-w-0 truncate text-[13px] text-muted-foreground">
          Tout ce qui circule dans vos échanges se range ici.
        </p>
        <AddDocument userId={userId} folders={folders} />
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-6">
        <FolderTree
          folders={folders}
          docs={docs}
          userId={userId}
          alerts={alerts}
          activeDocId={openDocId}
          focusFolderId={focusFolderId}
          onOpenDoc={(doc) => setOpenDocId(doc.id)}
          onOpenThread={onOpenThread}
        />
      </div>
    </div>
  );
}
