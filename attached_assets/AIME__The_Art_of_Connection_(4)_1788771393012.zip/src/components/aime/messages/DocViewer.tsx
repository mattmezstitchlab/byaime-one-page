import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, Send } from "lucide-react";
import { documentUrl } from "@/lib/bureau/queries";
import { postMessage, directoryQuery } from "@/lib/aime/chat";
import { cardsQuery, threadsQuery } from "@/lib/aime/queries";
import { linkDocumentToMessage } from "@/lib/bureau/threadFolders";
import { supabase } from "@/integrations/supabase/client";
import type { BureauDocument, BureauFolder } from "@/lib/bureau/types";
import { DocumentRow } from "@/components/bureau/DocumentRow";
import { alertLabel, type DocAlert } from "@/lib/bureau/alerts";
import { cn } from "@/lib/utils";

/**
 * Un document ouvert sur place : on le voit, on le corrige, on l'envoie
 * à la bonne personne — sans quitter le panneau.
 */
export function DocViewer({
  doc,
  folders,
  userId,
  alert,
  onBack,
  onOpenThread,
}: {
  doc: BureauDocument;
  folders: BureauFolder[];
  userId: string;
  alert?: DocAlert | null | undefined;
  onBack: () => void;
  onOpenThread: (threadId: string) => void;
}) {
  const qc = useQueryClient();
  const [url, setUrl] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [sending, setSending] = useState(false);

  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: people = [] } = useQuery(directoryQuery);

  useEffect(() => {
    let alive = true;
    void documentUrl(doc.storage_path, 60 * 60).then((u) => {
      if (alive) setUrl(u);
    });
    return () => {
      alive = false;
    };
  }, [doc.storage_path]);

  const rows = useMemo(() => {
    const cardById = new Map(cards.map((c) => [c.id, c]));
    const personById = new Map(people.map((p) => [p.id, p]));
    return threads.map((t) => {
      const other = t.user_a === userId ? t.user_b : t.user_a;
      const person = other ? personById.get(other) : null;
      const card = t.card_id ? cardById.get(t.card_id) : null;
      const title = t.title ?? t.subject ?? card?.name ?? person?.display_name ?? "Conversation";
      return { id: t.id, title };
    });
  }, [threads, cards, people, userId]);

  const isImage = (doc.mime_type ?? "").startsWith("image/");
  const isPdf = (doc.mime_type ?? "").includes("pdf");

  async function sendTo(threadId: string) {
    setSending(true);
    try {
      const link = await documentUrl(doc.storage_path, 60 * 60 * 24 * 365);
      await postMessage({
        threadId,
        senderId: userId,
        body: `Document partagé : ${doc.file_name}`,
        kind: "document",
        attachmentUrl: link,
        attachmentName: doc.file_name,
      });
      const { data: last } = await supabase
        .from("messages")
        .select("id")
        .eq("thread_id", threadId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (last?.id) await linkDocumentToMessage(doc.id, last.id);
      void qc.invalidateQueries({ queryKey: ["bureau-documents"] });
      toast.success("Document envoyé dans la conversation");
      setPicking(false);
      onOpenThread(threadId);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Envoi impossible");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-2 px-4 pb-3">
        <button
          type="button"
          onClick={onBack}
          aria-label="Retour aux dossiers"
          className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <p className="min-w-0 flex-1 truncate text-[14px] font-medium">{doc.file_name}</p>
        <button
          type="button"
          onClick={() => setPicking((v) => !v)}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border border-hairline px-3 py-1.5 text-[12px]",
            picking && "bg-muted",
          )}
        >
          <Send className="h-3.5 w-3.5" /> Envoyer
        </button>
        {url && (
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            title="Ouvrir en grand"
            className="grid h-8 w-8 place-items-center rounded-full hover:bg-muted"
          >
            <ExternalLink className="h-4 w-4" />
          </a>
        )}
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pb-6">
        {alert && (
          <p className="rounded-xl bg-amber-500/10 px-3 py-2 text-[12px] text-amber-700">
            {alertLabel(alert)}
          </p>
        )}

        {picking && (
          <div className="rounded-2xl border border-hairline p-3">
            <p className="pb-2 text-[12px] text-muted-foreground">
              À qui l'envoyer ? Le document reste rangé ici.
            </p>
            <ul className="max-h-48 space-y-1 overflow-y-auto">
              {rows.map((r) => (
                <li key={r.id}>
                  <button
                    type="button"
                    disabled={sending}
                    onClick={() => void sendTo(r.id)}
                    className="w-full rounded-lg px-2 py-1.5 text-left text-[13px] hover:bg-muted"
                  >
                    {r.title}
                  </button>
                </li>
              ))}
              {rows.length === 0 && (
                <li className="px-2 py-1.5 text-[12px] text-muted-foreground">
                  Aucune conversation pour l'instant.
                </li>
              )}
            </ul>
          </div>
        )}

        <div className="overflow-hidden rounded-2xl border border-hairline bg-secondary">
          {url && isImage && (
            <img src={url} alt={doc.file_name} className="max-h-[42vh] w-full object-contain" />
          )}
          {url && isPdf && <iframe src={url} title={doc.file_name} className="h-[42vh] w-full" />}
          {url && !isImage && !isPdf && (
            <p className="px-4 py-6 text-center text-[12px] text-muted-foreground">
              Aperçu indisponible pour ce format — utilisez « Ouvrir en grand ».
            </p>
          )}
          {!url && (
            <p className="px-4 py-6 text-center text-[12px] text-muted-foreground">Chargement…</p>
          )}
        </div>

        <DocumentRow doc={doc} folders={folders} defaultOpen />
      </div>
    </div>
  );
}
