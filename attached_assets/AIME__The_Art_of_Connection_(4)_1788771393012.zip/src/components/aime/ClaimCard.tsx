import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { BadgeCheck, ShieldQuestion } from "lucide-react";
import { requestCardClaim, verifyCardClaim } from "@/lib/aime/claim.functions";
import { useAuth } from "@/hooks/useAuth";

type Props = { cardId: string; cardName: string };

/** Bloc « C'est ma carte » pour les fiches publiques sans propriétaire. */
export function ClaimCard({ cardId, cardName }: Props) {
  const { userId } = useAuth();
  const queryClient = useQueryClient();
  const request = useServerFn(requestCardClaim);
  const verify = useServerFn(verifyCardClaim);

  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [note, setNote] = useState("");
  const [claimId, setClaimId] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      const res = await request({
        data: { cardId, email: email.trim(), note: note.trim() || undefined },
      });
      toast(res.message);
      if (res.status === "code_sent") setClaimId(res.claimId);
      else setOpen(false);
    } catch (err) {
      toast((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const confirm = async () => {
    if (!claimId) return;
    setBusy(true);
    try {
      await verify({ data: { claimId, code: code.trim() } });
      toast("Carte revendiquée. Elle est désormais la vôtre.");
      setOpen(false);
      setClaimId(null);
      await queryClient.invalidateQueries();
    } catch (err) {
      toast((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-3xl hairline bg-card p-5">
      <div className="flex items-start gap-3">
        <ShieldQuestion
          className="mt-0.5 h-[18px] w-[18px] shrink-0 text-muted-foreground"
          strokeWidth={1.75}
        />
        <div className="min-w-0">
          <p className="text-[14px] font-medium">Fiche publique, sans propriétaire</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
            Cette carte a été composée à partir de sources publiques. Si {cardName}, c'est vous,
            reprenez-en la main : vous pourrez tout modifier, publier vos disponibilités et répondre
            aux intentions.
          </p>
        </div>
      </div>

      {!userId ? (
        <Link
          to="/auth"
          className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-[13px] font-medium text-primary-foreground"
        >
          <BadgeCheck className="h-4 w-4" strokeWidth={1.75} />
          Se connecter pour revendiquer
        </Link>
      ) : !open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-[13px] font-medium text-primary-foreground"
        >
          <BadgeCheck className="h-4 w-4" strokeWidth={1.75} />
          C'est ma carte
        </button>
      ) : claimId ? (
        <div className="mt-4 space-y-2">
          <label className="eyebrow" htmlFor="claim-code">
            Code reçu par e-mail
          </label>
          <input
            id="claim-code"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            inputMode="numeric"
            placeholder="123456"
            className="w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[15px] tracking-[0.3em] outline-none"
          />
          <button
            type="button"
            onClick={confirm}
            disabled={busy || code.length !== 6}
            className="rounded-full bg-primary px-4 py-2.5 text-[13px] font-medium text-primary-foreground disabled:opacity-40"
          >
            Valider le code
          </button>
        </div>
      ) : (
        <div className="mt-4 space-y-2">
          <label className="eyebrow" htmlFor="claim-email">
            E-mail au nom du domaine officiel
          </label>
          <input
            id="claim-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="contact@votre-domaine.fr"
            className="w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[15px] outline-none"
          />
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={2}
            placeholder="Un mot pour la vérification (facultatif)"
            className="w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none"
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={submit}
              disabled={busy || !email.includes("@")}
              className="rounded-full bg-primary px-4 py-2.5 text-[13px] font-medium text-primary-foreground disabled:opacity-40"
            >
              Envoyer la demande
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-full hairline px-4 py-2.5 text-[13px]"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
