/**
 * Les sources d'un projet : ce que la personne a apporté ou connecté.
 * Même porte qu'à l'accueil, même composant.
 */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ExternalLink, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { SourceMenu } from "@/components/aime/sources/SourceMenu";
import { attachSource, projectSourcesQuery, type NewSource } from "@/lib/aime/sources/sources";
import { removeMedia } from "@/lib/aime/media";

export function ProjectSources({
  eventId,
  userId,
  canEdit,
}: {
  eventId: string;
  userId: string | null;
  canEdit: boolean;
}) {
  const qc = useQueryClient();
  const { data: sources = [] } = useQuery(projectSourcesQuery(eventId));

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["project-sources", eventId] });
    qc.invalidateQueries({ queryKey: ["media-items"] });
  };

  const add = useMutation({
    mutationFn: (source: NewSource) => attachSource(eventId, source, userId),
    onSuccess: refresh,
    onError: (e: Error) => toast(e.message),
  });

  const drop = useMutation({
    mutationFn: (id: string) => removeMedia(id),
    onSuccess: refresh,
    onError: (e: Error) => toast(e.message),
  });

  return (
    <section className="mt-8 rounded-3xl border bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Sources du projet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Documents, liens et comptes reliés. Rien n'est ajouté à la ligne de temps sans votre
            validation.
          </p>
        </div>
        {canEdit && (
          <SourceMenu
            userId={userId}
            label="Ajouter une source"
            onSource={(source) => add.mutateAsync(source)}
          />
        )}
      </div>

      {sources.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">Aucune source pour l'instant.</p>
      ) : (
        <ul className="mt-4 space-y-2">
          {sources.map((s) => (
            <li key={s.id} className="flex items-center gap-3 rounded-2xl bg-muted p-3">
              <span className="min-w-0 flex-1 truncate text-sm">{s.title || s.url}</span>
              <a
                href={s.url}
                target="_blank"
                rel="noreferrer"
                className="text-muted-foreground hover:text-foreground"
                aria-label="Ouvrir la source"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
              {canEdit && (
                <button
                  type="button"
                  onClick={() => drop.mutate(s.id)}
                  aria-label="Retirer la source"
                  className="text-muted-foreground hover:text-foreground"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
