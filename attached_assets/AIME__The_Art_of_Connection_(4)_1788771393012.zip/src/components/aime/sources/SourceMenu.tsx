/**
 * Le même bouton partout : « ＋ Connecter une source ».
 * Toutes les sources du catalogue sont actives : un document s'importe, tout
 * le reste se rattache par son lien (agenda partagé, dossier, profil,
 * événement…). La pièce rejoint le projet et attend la validation — rien
 * n'est simulé, rien ne se pose sur la ligne de temps sans votre accord.
 */
import { useRef, useState } from "react";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SOURCES, type SourceDef } from "@/lib/aime/sources/catalog";
import { uploadSourceFile, type NewSource } from "@/lib/aime/sources/sources";

export function SourceMenu({
  onSource,
  userId,
  tone = "clair",
  label = "Connecter une source",
  compact = false,
}: {
  onSource: (source: NewSource) => void | Promise<void>;
  userId: string | null;
  tone?: "clair" | "sombre";
  label?: string;
  compact?: boolean;
}) {
  /** Le service en cours de raccordement (tous passent par un lien). */
  const [linkFor, setLinkFor] = useState<SourceDef | null>(null);
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const pickFile = async (file: File | undefined) => {
    if (!file) return;
    if (!userId) {
      toast("Connectez-vous pour importer un document.");
      return;
    }
    setBusy(true);
    try {
      const source = await uploadSourceFile(userId, file);
      await onSource(source);
      toast("Document rattaché au projet");
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const submitLink = async () => {
    const clean = url.trim();
    if (!clean || !linkFor) return;
    setBusy(true);
    try {
      /* Le nom par défaut est le service lui-même : la pastille du projet
         reste courte et lisible même sans titre saisi. */
      await onSource({
        key: "lien",
        url: clean,
        title: title.trim() || (linkFor.key === "lien" ? null : linkFor.label),
      });
      setUrl("");
      setTitle("");
      setLinkFor(null);
      toast("Source rattachée au projet");
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const triggerClass = compact
    ? tone === "sombre"
      ? "inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/25 text-white/85 transition-colors hover:bg-white/10"
      : "inline-flex h-9 w-9 items-center justify-center rounded-full border text-muted-foreground transition-colors hover:bg-muted"
    : tone === "sombre"
      ? "inline-flex min-h-10 items-center gap-1.5 rounded-full border border-white/25 px-3.5 text-[13px] text-white/85 transition-colors hover:bg-white/10"
      : "inline-flex min-h-9 items-center gap-1.5 rounded-full border px-3.5 text-[13px] text-muted-foreground transition-colors hover:bg-muted";

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          className={triggerClass}
          disabled={busy}
          aria-label={compact ? "Connecter une source" : label}
          title={compact ? "Connecter une source" : undefined}
        >
          <Plus className="h-4 w-4" strokeWidth={1.75} aria-hidden />
          {!compact && label}
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-72">
          <DropdownMenuLabel>Connecter une source</DropdownMenuLabel>
          {SOURCES.map((s) => (
            <DropdownMenuItem
              key={s.key}
              onSelect={(e) => {
                e.preventDefault();
                if (s.key === "document") fileRef.current?.click();
                else setLinkFor(s);
              }}
              className="gap-2"
            >
              <s.icon className="h-4 w-4" strokeWidth={1.75} aria-hidden />
              <span className="flex-1">{s.label}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <input
        ref={fileRef}
        type="file"
        className="hidden"
        onChange={(e) => {
          void pickFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />

      <Dialog open={!!linkFor} onOpenChange={(v) => !v && setLinkFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{linkFor ? `Lier ${linkFor.label}` : "Ajouter un lien"}</DialogTitle>
            <DialogDescription>
              {linkFor?.hint ??
                "L'adresse reste telle quelle : rien n'est ajouté à votre projet sans votre accord."}
              {linkFor?.missing ? ` ${linkFor.missing}` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://…"
              className="min-h-11 w-full rounded-xl border bg-background px-3 text-[14px] outline-none"
            />
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Nom (facultatif)"
              className="min-h-11 w-full rounded-xl border bg-background px-3 text-[14px] outline-none"
            />
            <button
              type="button"
              disabled={!url.trim() || busy}
              onClick={() => void submitLink()}
              className="min-h-11 w-full rounded-xl bg-primary text-[14px] font-medium text-primary-foreground disabled:opacity-50"
            >
              Rattacher au projet
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
