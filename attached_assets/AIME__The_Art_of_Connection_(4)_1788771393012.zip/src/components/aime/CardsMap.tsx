import { useEffect, useRef } from "react";
// Le fichier de travail de MapLibre est construit avec l'application : sans cet
// import, il n'est pas publié et la carte reste vide sur le site en ligne.
import mapWorkerUrl from "maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url";
import type { Card } from "@/lib/aime/types";
import { cardCoords, DEFAULT_CENTER } from "@/lib/aime/geo";
import { cardVisual } from "@/lib/aime/visuals";


type Props = {
  cards: Card[];
  onSelect?: (card: Card) => void;
  className?: string;
  /** Carte à centrer (vignette mise en avant). */
  focusId?: string | null;
  /** Identifiant de la carte actuellement ouverte (anneau actif). */
  selectedId?: string | null;
  scrollWheelZoom?: boolean;
  /** Liens du réseau (paires d'identifiants de cartes) tracés en constellation. */
  links?: [string, string][];
  /** Identifiants des cartes visibles à l'écran, à chaque déplacement. */
  onViewport?: (ids: string[]) => void;
  /** Cartes du plateau de composition : anneau accentué. */
  trayIds?: string[];
  /** Survol d'un pin : aperçu « coup d'œil » affiché par la page, à cette position écran. */
  onHoverCard?: (card: Card | null, at: { x: number; y: number }) => void;
  /** Clic sur un pin : la vignette d'aperçu est épinglée à cette position écran. */
  onPinCard?: (card: Card, at: { x: number; y: number }) => void;
  /** Survol d'un groupe : aperçu de ses premières cartes et action de zoom. */
  onHoverCluster?: (
    preview: { cards: Card[]; count: number; x: number; y: number; zoom: () => void } | null,
  ) => void;
};

/** Fond vectoriel clair, recoloré aux tons ivoire du design system. */
const STYLE_URL = "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json";
const IVORY = "#FBF8F4";
const WATER = "#E9E2D8";
const LINE = "#EAE3D9";
const INK = "#8A8378";

/** Carte géolocalisée des cartes AIME (MapLibre, chargé uniquement côté client). */
export function CardsMap({
  cards,
  onSelect,
  className,
  focusId = null,
  selectedId = null,
  scrollWheelZoom = false,
  links = [],
  onViewport,
  trayIds = [],
  onHoverCard,
  onPinCard,
  onHoverCluster,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const glRef = useRef<any>(null);
  const readyRef = useRef(false);
  const markersRef = useRef<Map<string, { marker: any; state: string }>>(new Map());
  const selectRef = useRef(onSelect);
  selectRef.current = onSelect;
  const stateRef = useRef({ cards, selectedId, links, trayIds });
  stateRef.current = { cards, selectedId, links, trayIds };
  const hoverRef = useRef(onHoverCard);
  hoverRef.current = onHoverCard;
  const pinRef = useRef(onPinCard);
  pinRef.current = onPinCard;
  const clusterHoverRef = useRef(onHoverCluster);
  clusterHoverRef.current = onHoverCluster;
  const viewportRef = useRef(onViewport);
  viewportRef.current = onViewport;
  const fittedRef = useRef(false);
  const emitRef = useRef<(() => void) | null>(null);
  const markerSigRef = useRef("");

  const cardMarkerEl = (card: Card, active: boolean) => {
    const el = document.createElement("button");
    el.type = "button";
    el.title = `${card.name} · ${card.city ?? ""}`;
    const size = active ? 52 : 42;
    const inTray = stateRef.current.trayIds.includes(card.id);
    el.style.cssText = `width:${size}px;height:${size}px;border-radius:999px;overflow:hidden;padding:0;cursor:pointer;background:none;border:${
      active ? "3px solid #111" : inTray ? "3px solid #e11d48" : "2px solid #fff"
    };box-shadow:0 8px 22px rgba(0,0,0,.18);transition:transform .18s ease`;
    // L'agrandissement se joue sur l'image : le bouton garde la transformation
    // de placement appliquée par la carte, sinon le repère saute puis revient.
    el.innerHTML = `<img src="${cardVisual(card)}" alt="" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;display:block;transition:transform .18s ease" />`;
    const img = el.firstElementChild as HTMLImageElement | null;
    el.addEventListener("mouseenter", () => {
      if (img) img.style.transform = "scale(1.12)";
      const r = el.getBoundingClientRect();
      hoverRef.current?.(card, { x: r.left + r.width / 2, y: r.top });
    });
    el.addEventListener("mouseleave", () => {
      if (img) img.style.transform = "scale(1)";
      hoverRef.current?.(null, { x: 0, y: 0 });
    });
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      const r = el.getBoundingClientRect();
      if (pinRef.current) pinRef.current(card, { x: r.left + r.width / 2, y: r.top });
      else selectRef.current?.(card);
    });
    return el;
  };

  /** Points des cartes en GeoJSON, pour le regroupement natif. */
  const cardsGeoJSON = () => {
    const { cards: list } = stateRef.current;
    const features: any[] = [];
    for (const card of list) {
      const pos = cardCoords(card);
      if (!pos) continue;
      features.push({
        type: "Feature",
        id: features.length + 1,
        properties: { id: card.id, name: card.name },
        geometry: { type: "Point", coordinates: [pos[1], pos[0]] },
      });
    }
    return { type: "FeatureCollection", features } as any;
  };

  /** Traits fins entre les cartes réellement reliées (rencontres, projets communs). */
  const linkLines = () => {
    const { cards: list, links: pairs } = stateRef.current;
    const byId = new Map(list.map((c) => [c.id, c]));
    const features: any[] = [];
    for (const [a, b] of pairs) {
      const ca = byId.get(a);
      const cb = byId.get(b);
      if (!ca || !cb) continue;
      const pa = cardCoords(ca);
      const pb = cardCoords(cb);
      if (!pa || !pb) continue;
      features.push({
        type: "Feature",
        properties: { a, b },
        geometry: {
          type: "LineString",
          coordinates: [
            [pa[1], pa[0]],
            [pb[1], pb[0]],
          ],
        },
      });
    }
    return { type: "FeatureCollection", features } as any;
  };

  /**
   * Vignettes HTML pour les points non regroupés.
   * Rendu incrémental : on réutilise les pastilles déjà à l'écran pour éviter
   * le clignotement (les points noirs de la couche de fond) au survol.
   */
  const renderMarkers = () => {
    const map = mapRef.current;
    const gl = glRef.current;
    if (!map || !gl || !readyRef.current) return;

    const { cards: list, selectedId: sel, trayIds: tray } = stateRef.current;
    const byId = new Map(list.map((c2) => [c2.id, c2]));
    const store = markersRef.current;
    const keep = new Set<string>();

    let features: any[] = [];
    try {
      features = map.querySourceFeatures("cards", { filter: ["!", ["has", "point_count"]] });
    } catch {
      features = [];
    }

    // Rien n'a bougé ni changé : on ne reconstruit pas les vignettes.
    const c = map.getCenter();
    const featureIds = features
      .map((feature) => String(feature.properties?.id ?? ""))
      .filter(Boolean)
      .sort()
      .join(",");
    const sig = `${c.lng.toFixed(4)}|${c.lat.toFixed(4)}|${map.getZoom().toFixed(2)}|${featureIds}|${list.length}|${sel}|${tray.join(",")}`;
    if (sig === markerSigRef.current) return;
    markerSigRef.current = sig;

    const upsert = (key: string, state: string, lngLat: [number, number], make: () => any) => {
      const prev = store.get(key);
      if (prev && prev.state === state) {
        prev.marker.setLngLat(lngLat);
      } else {
        prev?.marker.remove();
        const marker = new gl.Marker({ element: make() }).setLngLat(lngLat).addTo(map);
        store.set(key, { marker, state });
      }
      keep.add(key);
    };

    const seen = new Set<string>();

    for (const f of features) {
      // Au-delà de ce nombre, les points restent des pastilles : la carte reste fluide.
      if (seen.size >= 90) break;
      const id = f.properties?.id as string | undefined;
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const card = byId.get(id);
      if (!card) continue;
      const active = card.id === sel;
      upsert(
        `card:${id}`,
        `${active}|${tray.includes(id)}|${cardVisual(card)}`,
        f.geometry.coordinates as [number, number],
        () => cardMarkerEl(card, active),
      );
    }

    for (const [key, entry] of store) {
      if (keep.has(key)) continue;
      entry.marker.remove();
      store.delete(key);
    }

    // Les points noirs ne servent que là où aucune vignette n'est posée.
    if (map.getLayer("point")) {
      const covered = [...seen];
      map.setFilter("point", [
        "all",
        ["!", ["has", "point_count"]],
        ["!", ["in", ["get", "id"], ["literal", covered]]],
      ]);
    }
  };

  const syncData = () => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    map.getSource("cards")?.setData(cardsGeoJSON());
    map.getSource("links")?.setData(linkLines());
    const sel = stateRef.current.selectedId;
    if (map.getLayer("links"))
      map.setPaintProperty(
        "links",
        "line-opacity",
        sel
          ? ["case", ["any", ["==", ["get", "a"], sel], ["==", ["get", "b"], sel]], 0.85, 0.12]
          : 0.3,
      );
    renderMarkers();
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const gl: any = await import("maplibre-gl");
      await import("maplibre-gl/dist/maplibre-gl.css");
      if (cancelled || !ref.current || mapRef.current) return;
      // Le fichier de travail est celui construit avec l'application, servi par
      // l'origine courante : il fonctionne donc aussi sur un lien partagé.
      try {
        const url = new URL(mapWorkerUrl, window.location.href);
        gl.setWorkerUrl?.(`${url.pathname}${url.search}`);
      } catch (err) {
        console.error("[map] worker", err);
      }

      glRef.current = gl;

      const map = new gl.Map({
        container: ref.current,
        style: STYLE_URL,
        center: [DEFAULT_CENTER[1], DEFAULT_CENTER[0]],
        zoom: 8,
        attributionControl: false,
        scrollZoom: scrollWheelZoom,
      });
      mapRef.current = map;
      map.on("error", (e: any) => console.error("[map]", e?.error?.message ?? e));
      map.addControl(new gl.NavigationControl({ showCompass: false }), "bottom-right");

      map.on("style.load", () => {
        if (cancelled) return;
        // Recolore le fond aux tons ivoire du design system.
        for (const layer of map.getStyle().layers ?? []) {
          const id = layer.id;
          try {
            if (layer.type === "background") map.setPaintProperty(id, "background-color", IVORY);
            else if (layer.type === "fill")
              map.setPaintProperty(id, "fill-color", /water|ocean|sea/i.test(id) ? WATER : IVORY);
            else if (layer.type === "line") {
              map.setPaintProperty(id, "line-color", LINE);
              map.setPaintProperty(id, "line-opacity", 0.9);
            } else if (layer.type === "symbol") {
              map.setPaintProperty(id, "text-color", INK);
              map.setPaintProperty(id, "text-halo-color", IVORY);
            }
          } catch {
            /* couche non modifiable */
          }
        }

        map.addSource("cards", {
          type: "geojson",
          data: cardsGeoJSON(),
          cluster: true,
          clusterRadius: 62,
          clusterMaxZoom: 11,
        });
        map.addSource("links", { type: "geojson", data: linkLines() });

        map.addLayer({
          id: "links",
          type: "line",
          source: "links",
          paint: { "line-color": "#111111", "line-width": 1, "line-opacity": 0.3 },
        });

        // Halos de densité : la taille dit le nombre de cartes du réseau.
        map.addLayer({
          id: "clusters-halo",
          type: "circle",
          source: "cards",
          filter: ["has", "point_count"],
          paint: {
            "circle-color": "#111111",
            "circle-opacity": 0.08,
            "circle-radius": ["+", 22, ["*", 3, ["sqrt", ["get", "point_count"]]]],
          },
        });
        map.addLayer({
          id: "clusters",
          type: "circle",
          source: "cards",
          filter: ["has", "point_count"],
          paint: {
            "circle-color": "#111111",
            "circle-radius": ["+", 15, ["*", 2, ["sqrt", ["get", "point_count"]]]],
            "circle-stroke-width": 2,
            "circle-stroke-color": "#ffffff",
          },
        });
        map.addLayer({
          id: "clusters-count",
          type: "symbol",
          source: "cards",
          filter: ["has", "point_count"],
          layout: {
            "text-field": ["get", "point_count_abbreviated"],
            "text-size": 13,
            "text-font": ["Open Sans Semibold"],
          },
          paint: { "text-color": "#ffffff" },
        });

        // Point isolé : pastille discrète, remplacée par la vignette dès que possible.
        map.addLayer({
          id: "point",
          type: "circle",
          source: "cards",
          filter: ["!", ["has", "point_count"]],
          paint: {
            "circle-color": "#111111",
            "circle-radius": 6,
            "circle-stroke-width": 2,
            "circle-stroke-color": "#ffffff",
          },
        });
        map.on("click", "point", (e: any) => {
          const id = e.features?.[0]?.properties?.id;
          const card = stateRef.current.cards.find((c) => c.id === id);
          if (!card) return;
          if (pinRef.current) pinRef.current(card, { x: e.point.x, y: e.point.y });
          else selectRef.current?.(card);
        });
        // Survol d'une pastille : la petite carte apparaît, comme sur les vignettes.
        map.on("mousemove", "point", (e: any) => {
          map.getCanvas().style.cursor = "pointer";
          const id = e.features?.[0]?.properties?.id;
          const card = stateRef.current.cards.find((c) => c.id === id);
          if (!card) return;
          const rect = map.getCanvas().getBoundingClientRect();
          hoverRef.current?.(card, { x: rect.left + e.point.x, y: rect.top + e.point.y - 8 });
        });
        map.on("mouseleave", "point", () => {
          map.getCanvas().style.cursor = "";
          hoverRef.current?.(null, { x: 0, y: 0 });
        });

        /** Un clic sur un cercle chiffré amène directement sur ses pins. */
        const zoomCluster = async (feature: any) => {
          if (!feature) return;
          clusterHoverRef.current?.(null);
          const clusterId = Number(feature.properties?.cluster_id);
          const count = Number(feature.properties?.point_count ?? 0);
          const source: any = map.getSource("cards");
          if (Number.isFinite(clusterId) && source?.getClusterLeaves) {
            try {
              const leaves = await source.getClusterLeaves(clusterId, Math.max(count, 1), 0);
              const coords = leaves
                .map((leaf: any) => leaf?.geometry?.coordinates)
                .filter((c: any) => Array.isArray(c) && Number.isFinite(c[0]) && Number.isFinite(c[1]));
              if (coords.length > 0) {
                let minX = coords[0][0];
                let maxX = coords[0][0];
                let minY = coords[0][1];
                let maxY = coords[0][1];
                for (const [x, y] of coords) {
                  minX = Math.min(minX, x);
                  maxX = Math.max(maxX, x);
                  minY = Math.min(minY, y);
                  maxY = Math.max(maxY, y);
                }
                const spread = Math.max(maxX - minX, maxY - minY);
                if (spread < 0.0005) {
                  map.easeTo({ center: [minX, minY], zoom: 15, duration: 600 });
                } else {
                  map.fitBounds(
                    [
                      [minX, minY],
                      [maxX, maxY],
                    ],
                    { padding: 80, maxZoom: 15, duration: 600 },
                  );
                }
                return;
              }
            } catch (error) {
              console.error("[map] cluster zoom", error);
            }
          }
          map.easeTo({
            center: feature.geometry.coordinates,
            zoom: Math.min((map.getZoom() ?? 8) + 2.2, 15),
            duration: 600,
          });
        };
        const previewCluster = async (e: any) => {
          const feature = e.features?.[0];
          const clusterId = Number(feature?.properties?.cluster_id);
          const count = Number(feature?.properties?.point_count ?? 0);
          const source = map.getSource("cards");
          if (!feature || !Number.isFinite(clusterId) || !source?.getClusterLeaves) return;
          try {
            const leaves = await source.getClusterLeaves(clusterId, 5, 0);
            const cards = leaves
              .map((leaf: any) =>
                stateRef.current.cards.find((card) => card.id === leaf.properties?.id),
              )
              .filter(Boolean) as Card[];
            if (cards.length === 0) return;
            const rect = map.getCanvas().getBoundingClientRect();
            clusterHoverRef.current?.({
              cards,
              count,
              x: rect.left + e.point.x,
              y: rect.top + e.point.y,
              zoom: () => void zoomCluster(feature),
            });
          } catch (error) {
            console.error("[map] cluster preview", error);
          }
        };
        let clusterTouchAt = 0;
        map.on("touchend", "clusters", (e: any) => {
          clusterTouchAt = Date.now();
          const feature = e.features?.[0];
          if (feature) void zoomCluster(feature);
        });
        map.on("click", "clusters", (e: any) => {
          const f = e.features?.[0];
          if (!f) return;
          if (Date.now() - clusterTouchAt < 500) return;
          void zoomCluster(f);
        });
        map.on("mouseenter", "clusters", (e: any) => {
          map.getCanvas().style.cursor = "pointer";
          void previewCluster(e);
        });
        map.on("mouseleave", "clusters", () => {
          map.getCanvas().style.cursor = "";
          clusterHoverRef.current?.(null);
        });

        readyRef.current = true;
        renderMarkers();
        map.on("idle", renderMarkers);
        const emitViewport = () => {
          const b = map.getBounds();
          const ids = stateRef.current.cards
            .filter((c) => {
              const pos = cardCoords(c);
              return pos ? b.contains([pos[1], pos[0]]) : false;
            })
            .map((c) => c.id);
          viewportRef.current?.(ids);
        };
        emitRef.current = emitViewport;
        map.on("moveend", emitViewport);
        emitViewport();
        fitAll();
      });
    })();
    return () => {
      cancelled = true;
      for (const [, entry] of markersRef.current) entry.marker.remove();
      markersRef.current.clear();
      readyRef.current = false;
      mapRef.current?.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fitAll = () => {
    const map = mapRef.current;
    const gl = glRef.current;
    if (!map || !gl || fittedRef.current) return;
    const pts: [number, number][] = [];
    for (const card of stateRef.current.cards) {
      const pos = cardCoords(card);
      if (pos) pts.push([pos[1], pos[0]]);
    }
    if (pts.length < 2) return;
    fittedRef.current = true;
    const bounds = pts.reduce((b, p) => b.extend(p), new gl.LngLatBounds(pts[0], pts[0]));
    map.fitBounds(bounds, { padding: 80, duration: 0, maxZoom: 12 });
  };

  useEffect(() => {
    syncData();
    fitAll();
    // Les données arrivent après la carte : on recompte aussitôt « À l'écran ».
    markerSigRef.current = "";
    emitRef.current?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cards, selectedId, links, trayIds]);

  useEffect(() => {
    if (!focusId || !mapRef.current) return;
    const card = cards.find((c) => c.id === focusId);
    const pos = card ? cardCoords(card) : null;
    if (pos)
      mapRef.current.flyTo({
        center: [pos[1], pos[0]],
        zoom: Math.max(mapRef.current.getZoom() ?? 9, 12),
        duration: 900,
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusId]);

  return (
    <div
      ref={ref}
      className={`isolate bg-[#FBF8F4] ${className ?? "h-[420px] w-full rounded-4xl"}`}
      style={{ zIndex: 0 }}
    />
  );
}
