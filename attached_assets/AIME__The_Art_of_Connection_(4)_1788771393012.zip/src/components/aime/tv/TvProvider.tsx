import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useQuery } from "@tanstack/react-query";
import { shuffled, tvChannelQuery, type TvChannel, type TvItem } from "@/lib/aime/tv/channels";

type TvValue = {
  /** La petite fenêtre est allumée. */
  on: boolean;
  open: (channel: TvChannel, projectId: string) => void;
  close: () => void;
  channel: TvChannel;
  setChannel: (c: TvChannel) => void;
  projectId: string | null;
  setProject: (id: string) => void;
  items: TvItem[];
  index: number;
  current: TvItem | null;
  next: () => void;
  prev: () => void;
  playing: boolean;
  setPlaying: (v: boolean) => void;
  /** Son de l'image en cours (vidéo). */
  muted: boolean;
  setMuted: (v: boolean) => void;
  /** Musique posée par-dessus les images. */
  music: boolean;
  setMusic: (v: boolean) => void;
  volume: number;
  setVolume: (v: number) => void;
  full: boolean;
  setFull: (v: boolean) => void;
  loading: boolean;
};

const FALLBACK: TvValue = {
  on: false,
  open: () => {},
  close: () => {},
  channel: "jour-j",
  setChannel: () => {},
  projectId: null,
  setProject: () => {},
  items: [],
  index: 0,
  current: null,
  next: () => {},
  prev: () => {},
  playing: false,
  setPlaying: () => {},
  muted: true,
  setMuted: () => {},
  music: true,
  setMusic: () => {},
  volume: 0.4,
  setVolume: () => {},
  full: false,
  setFull: () => {},
  loading: false,
};

const Ctx = createContext<TvValue | null>(null);

export function useTv() {
  return useContext(Ctx) ?? FALLBACK;
}

export function TvProvider({ children }: { children: ReactNode }) {
  const [on, setOn] = useState(false);
  const [channel, setChannelState] = useState<TvChannel>("jour-j");
  const [projectId, setProjectId] = useState<string | null>(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [music, setMusic] = useState(true);
  const [volume, setVolume] = useState(0.4);
  const [full, setFull] = useState(false);

  const { data: raw = [], isLoading } = useQuery({
    ...tvChannelQuery(projectId, channel),
    enabled: on && !!projectId,
    refetchInterval: on ? 60_000 : false,
  });

  // L'ordre change à chaque nouvelle antenne : jamais deux fois le même défilé.
  const items = useMemo(() => shuffled(raw), [raw]);
  useEffect(() => setIndex(0), [channel, projectId, raw.length]);

  const current = items.length > 0 ? (items[index % items.length] ?? null) : null;

  const value: TvValue = {
    on,
    open: (c, id) => {
      setChannelState(c);
      setProjectId(id);
      setIndex(0);
      setPlaying(true);
      setOn(true);
    },
    close: () => {
      setOn(false);
      setFull(false);
    },
    channel,
    setChannel: (c) => {
      setChannelState(c);
      setIndex(0);
    },
    projectId,
    setProject: (id) => {
      setProjectId(id);
      setIndex(0);
    },
    items,
    index,
    current,
    next: () => setIndex((i) => (items.length ? (i + 1) % items.length : 0)),
    prev: () => setIndex((i) => (items.length ? (i - 1 + items.length) % items.length : 0)),
    playing,
    setPlaying,
    muted,
    setMuted,
    music,
    setMusic,
    volume,
    setVolume,
    full,
    setFull,
    loading: isLoading,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
