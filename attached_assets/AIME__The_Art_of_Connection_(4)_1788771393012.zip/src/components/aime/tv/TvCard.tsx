import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Music,
  Pause,
  Play,
  Plus,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { useTv } from "./TvProvider";
import { TvDeposit } from "./TvDeposit";
import { CHANNEL_LABEL, TV_CHANNELS, tvCaption } from "@/lib/aime/tv/channels";
import { bindAudioElement, claimAudio } from "@/lib/aime/audioBus";
import { listenUrl, publicTracksQuery, shuffle } from "@/lib/aime/playlist";
import { useRadio } from "@/components/aime/RadioProvider";

const PHOTO_MS = 5_000;

/**
 * La petite fenêtre de télé : ce qui a été déposé sur le projet passe tout
 * seul, en boucle, avec la musique par-dessus si on le souhaite.
 */
export function TvCard() {
  const tv = useTv();
  const { on: radioOn, mode: radioMode, post } = useRadio();
  const {
    on: tvOn,
    music: tvMusic,
    playing,
    current,
    index,
    next,
    full,
    items,
    channel,
    setChannel,
    setFull,
    close,
    prev,
    muted,
    setMuted,
    setMusic,
    volume,
    setVolume,
    projectId,
  } = tv;
  const [deposit, setDeposit] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const musicRef = useRef<HTMLAudioElement | null>(null);
  const [progress, setProgress] = useState(0);

  const { data: tracks = [] } = useQuery({ ...publicTracksQuery, enabled: tvOn && tvMusic });
  // Un fond musical tiré au hasard, stable tant que le programme ne change pas.
  const musicUrl = useMemo(() => {
    if (!tvOn || !tvMusic || tracks.length === 0) return null;
    return listenUrl(shuffle(tracks)[0]!);
  }, [tracks, tvMusic, tvOn]);

  // Un seul son sur AIME : dès que la télé parle, la radio se tait.
  useEffect(() => {
    if (!tvOn) return;
    return bindAudioElement("tv", musicRef.current);
  }, [musicUrl, tvOn]);

  useEffect(() => {
    if (!tvOn || !tvMusic) return;
    claimAudio("tv", () => musicRef.current?.pause());
  }, [tvMusic, tvOn]);

  useEffect(() => {
    const el = musicRef.current;
    if (el) el.volume = volume;
  }, [musicUrl, volume]);

  // Enchaînement : les photos durent cinq secondes, les vidéos vont au bout.
  useEffect(() => {
    setProgress(0);
    if (!tvOn || !playing || !current) return;
    if (current.kind === "video") return;
    const started = Date.now();
    const tick = window.setInterval(() => {
      const done = (Date.now() - started) / PHOTO_MS;
      setProgress(Math.min(1, done));
      if (done >= 1) next();
    }, 100);
    return () => window.clearInterval(tick);
  }, [current, index, next, playing, tvOn]);

  if (!tvOn) return null;

  const item = current;
  const radioFloating = radioOn && radioMode === "fil" && !!post;
  const box = full
    ? "fixed inset-0 z-[80] flex items-center justify-center bg-black/95 p-4"
    : `fixed right-4 ${radioFloating ? "top-[392px]" : "top-[108px]"} z-[61] w-[min(22rem,calc(100vw-2rem))]`;

  return (
    <div className={box}>
      <div
        className={`overflow-hidden rounded-3xl hairline bg-card/95 shadow-soft backdrop-blur ${full ? "w-full max-w-3xl" : ""}`}
      >
        <div className="flex items-center justify-between gap-2 px-3 pt-2.5">
          <select
            value={channel}
            onChange={(e) => setChannel(e.target.value as never)}
            aria-label="Chaîne AIME TV"
            className="min-w-0 truncate rounded-full bg-transparent text-[13px] font-medium outline-none"
          >
            {TV_CHANNELS.map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
          </select>
          <div className="flex shrink-0 items-center gap-1 text-muted-foreground">
            <span className="text-[11px]">
              {items.length > 0 ? `${index + 1}/${items.length}` : "0"}
            </span>
            <button
              type="button"
              onClick={() => setFull(!full)}
              aria-label={full ? "Réduire" : "Plein écran"}
              className="flex h-8 w-8 items-center justify-center rounded-full hover:text-foreground"
            >
              {full ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </button>
            <button
              type="button"
              onClick={close}
              aria-label="Éteindre AIME TV"
              className="flex h-8 w-8 items-center justify-center rounded-full hover:text-foreground"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        <div className="mt-2 bg-black/70">
          {!item ? (
            <div className="grid aspect-video place-items-center px-4 text-center text-[12px] text-white/70">
              {tv.loading
                ? "Recherche des images…"
                : `Rien encore sur « ${CHANNEL_LABEL[channel]} ». Déposez la première image.`}
            </div>
          ) : item.kind === "video" ? (
            <video
              key={item.id}
              ref={videoRef}
              src={item.url}
              autoPlay={playing}
              muted={muted}
              playsInline
              onEnded={next}
              onTimeUpdate={(e) => {
                const el = e.currentTarget;
                setProgress(el.duration ? el.currentTime / el.duration : 0);
              }}
              className="aspect-video w-full object-cover"
            />
          ) : item.kind === "youtube" && item.embed ? (
            <iframe
              key={item.id}
              src={`${item.embed}?autoplay=1&mute=${muted ? 1 : 0}&rel=0`}
              title={item.title}
              allow="autoplay; encrypted-media"
              className="aspect-video w-full"
            />
          ) : (
            <img key={item.id} src={item.url} alt="" className="aspect-video w-full object-cover" />
          )}
        </div>

        <div className="h-1 w-full bg-muted">
          <div
            className="h-full bg-foreground transition-[width] duration-100"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>

        <div className="p-3">
          <p className="truncate text-[12px] text-muted-foreground">
            {item ? tvCaption(item) : "En attente d'images"}
          </p>

          <div className="mt-2 flex items-center gap-1">
            <button
              type="button"
              onClick={prev}
              aria-label="Précédent"
              className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => tv.setPlaying(!playing)}
              aria-label={playing ? "Mettre en pause" : "Lancer"}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background"
            >
              {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Suivant"
              className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setMuted(!muted)}
              aria-label={muted ? "Activer le son de l'image" : "Couper le son de l'image"}
              className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => setMusic(!tvMusic)}
              aria-label={tvMusic ? "Couper la musique" : "Mettre la musique"}
              className={`flex h-9 w-9 items-center justify-center rounded-full ${tvMusic ? "text-foreground" : "text-muted-foreground"}`}
            >
              <Music className="h-4 w-4" />
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              aria-label="Volume de la musique"
              className="ml-1 h-1 w-16 accent-foreground"
            />
            <button
              type="button"
              onClick={() => setDeposit(true)}
              className="ml-auto inline-flex h-9 items-center gap-1 rounded-full border border-hairline px-3 text-[12px] font-medium hover:bg-muted"
            >
              <Plus className="h-3.5 w-3.5" /> Déposer
            </button>
          </div>
        </div>
      </div>

      {musicUrl && (
        <audio
          ref={musicRef}
          src={musicUrl}
          autoPlay
          loop
          onEnded={() => undefined}
          className="hidden"
        />
      )}

      <TvDeposit open={deposit} onOpenChange={setDeposit} projectId={projectId} />
    </div>
  );
}
