import { useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Camera, Loader2, Square, Upload } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { addMedia, uploadMediaFile } from "@/lib/aime/media";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const MAX_SECONDS = 10;

/** Durée d'une vidéo, lue par le navigateur avant tout envoi. */
function videoSeconds(file: File): Promise<number> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const el = document.createElement("video");
    el.preload = "metadata";
    el.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(el.duration) ? el.duration : 0);
    };
    el.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(0);
    };
    el.src = url;
  });
}

/**
 * Le dépôt des invités : une photo, ou une vidéo de dix secondes maximum.
 * Ce qui est déposé apparaît tout de suite sur la chaîne du jour.
 */
export function TvDeposit({
  open,
  onOpenChange,
  projectId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  projectId: string | null;
}) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [left, setLeft] = useState(MAX_SECONDS);
  const recorder = useRef<MediaRecorder | null>(null);
  const preview = useRef<HTMLVideoElement | null>(null);

  const send = async (file: File, kind: "photo" | "video") => {
    if (!projectId) return;
    if (!userId) {
      toast.error("Connectez-vous pour déposer un souvenir.");
      return;
    }
    setBusy(true);
    try {
      const url = await uploadMediaFile(userId, file);
      await addMedia({ eventId: projectId }, { kind, url, title: null }, userId, Date.now() % 100000);
      await qc.invalidateQueries({ queryKey: ["aime-tv"] });
      await qc.invalidateQueries({ queryKey: ["media-items"] });
      toast.success("C'est à l'antenne : votre souvenir passe sur Jour J.");
      onOpenChange(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Le dépôt n'a pas abouti.");
    } finally {
      setBusy(false);
    }
  };

  const pick = async (file: File | undefined) => {
    if (!file) return;
    const isVideo = file.type.startsWith("video/");
    if (isVideo) {
      const seconds = await videoSeconds(file);
      if (seconds > MAX_SECONDS + 0.5) {
        toast.error(
          `Cette vidéo dure ${Math.round(seconds)} secondes. Dix secondes maximum, merci de la raccourcir.`,
        );
        return;
      }
    }
    await send(file, isVideo ? "video" : "photo");
  };

  const startDirect = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (preview.current) {
        preview.current.srcObject = stream;
        void preview.current.play();
      }
      const chunks: Blob[] = [];
      const rec = new MediaRecorder(stream);
      recorder.current = rec;
      rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (preview.current) preview.current.srcObject = null;
        setRecording(false);
        const blob = new Blob(chunks, { type: rec.mimeType || "video/webm" });
        const ext = blob.type.includes("mp4") ? "mp4" : "webm";
        await send(new File([blob], `direct-${Date.now()}.${ext}`, { type: blob.type }), "video");
      };
      rec.start();
      setRecording(true);
      setLeft(MAX_SECONDS);
      const tick = window.setInterval(() => {
        setLeft((v) => {
          if (v <= 1) {
            window.clearInterval(tick);
            if (recorder.current?.state === "recording") recorder.current.stop();
            return 0;
          }
          return v - 1;
        });
      }, 1000);
    } catch {
      toast.error("La caméra n'est pas accessible.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Déposer sur AIME TV</DialogTitle>
          <DialogDescription>
            Une photo, ou une vidéo de dix secondes maximum. Elle passe aussitôt sur la chaîne
            Jour J.
          </DialogDescription>
        </DialogHeader>

        <video
          ref={preview}
          muted
          playsInline
          className={`w-full rounded-2xl bg-black/60 ${recording ? "block aspect-video" : "hidden"}`}
        />

        <div className="grid gap-2">
          <label className="inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full border border-hairline px-4 text-sm font-medium hover:bg-muted">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Choisir une photo ou une vidéo
            <input
              type="file"
              accept="image/*,video/*"
              className="hidden"
              disabled={busy || recording}
              onChange={(e) => void pick(e.target.files?.[0])}
            />
          </label>

          {recording ? (
            <Button type="button" variant="destructive" onClick={() => recorder.current?.stop()}>
              <Square className="h-4 w-4" /> Arrêter ({left}s)
            </Button>
          ) : (
            <Button type="button" variant="secondary" disabled={busy} onClick={() => void startDirect()}>
              <Camera className="h-4 w-4" /> Direct court : se filmer dix secondes
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
