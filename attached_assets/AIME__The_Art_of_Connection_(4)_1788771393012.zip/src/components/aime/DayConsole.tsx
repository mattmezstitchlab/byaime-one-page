import { useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, CalendarCheck, CircleDot, Flag, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  AVAILABILITY_DOT,
  AVAILABILITY_LABEL,
  AVAILABILITY_STATUSES,
  formatDay,
} from "@/lib/aime/calendar";
import { KIND_LABEL, formatSlot, type MusicboxEntry } from "@/lib/aime/musicbox";
import { cn } from "@/lib/utils";
import type { AimeIntent, Card } from "@/lib/aime/types";

type Mode = "jour" | "moments" | "events" | "people" | "repere" | "reserver" | "dispo";

const EVENT_KINDS = new Set(["rdv", "annonce", "tache"]);

/** Dos du bloc calendrier : vues du jour réellement alimentées. */
export function DayConsole({
  card,
  day,
  onBack,
  isOwner,
  currentStatus,
  onIntent,
  dayEntries,
}: {
  card: Card;
  day: string;
  onBack: () => void;
  isOwner: boolean;
  currentStatus?: string | undefined;
  onIntent: (intent: AimeIntent, message?: string) => void;
  dayEntries: MusicboxEntry[];
}) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const [mode, setMode] = useState<Mode>("jour");
  const [title, setTitle] = useState("");
  const [word, setWord] = useState("");

  const eventEntries = useMemo(
    () => dayEntries.filter((e) => EVENT_KINDS.has((e.kind ?? "").toLowerCase())),
    [dayEntries],
  );
  const peopleEntries = useMemo(
    () => dayEntries.filter((e) => (e.dedicated_name ?? "").trim() || e.dedicated_card_id),
    [dayEntries],
  );

  const setAvailability = useMutation({
    mutationFn: async (status: string) => {
      const { error } = await supabase
        .from("card_availability")
        .upsert({ card_id: card.id, day, status }, { onConflict: "card_id,day" });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["availability"] });
      toast("Disponibilité enregistrée");
      setMode("jour");
    },
    onError: (e: Error) => toast(e.message),
  });

  const addMarker = useMutation({
    mutationFn: async () => {
      if (!title.trim()) throw new Error("Donnez un titre au repère.");
      const { error } = await supabase.from("card_timeline_entries").insert({
        card_id: card.id,
        kind: "jalon",
        title: title.trim(),
        starts_at: new Date(`${day}T12:00:00`).toISOString(),
        ...(card.universes[0] ? { universe_slug: card.universes[0] } : {}),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["card-timeline", card.id] });
      setTitle("");
      setMode("jour");
      toast("Repère ajouté à la timeline");
    },
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div className="flex h-full flex-col rounded-3xl hairline bg-card p-3 shadow-soft">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => (mode === "jour" ? onBack() : setMode("jour"))}
          aria-label={mode === "jour" ? "Revenir au calendrier" : "Revenir aux vues du jour"}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full hairline bg-background text-muted-foreground"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.75} />
        </button>
        <p className="min-w-0 flex-1 truncate text-[13px] font-medium first-letter:uppercase">
          {formatDay(day)}
        </p>
        {currentStatus && (
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full hairline bg-background px-2.5 py-1 text-[11px] text-muted-foreground">
            <span className={cn("h-1.5 w-1.5 rounded-full", AVAILABILITY_DOT[currentStatus])} />
            {AVAILABILITY_LABEL[currentStatus] ?? currentStatus}
          </span>
        )}
      </div>

      <div className="mt-3 min-h-0 flex-1 overflow-y-auto">
        <div className="mb-3 flex flex-wrap gap-1.5">
          <ViewButton active={mode === "jour"} label="Jour" onClick={() => setMode("jour")} />
          {dayEntries.length > 0 && (
            <ViewButton
              active={mode === "moments"}
              label={`Moments (${dayEntries.length})`}
              onClick={() => setMode("moments")}
            />
          )}
          {eventEntries.length > 0 && (
            <ViewButton
              active={mode === "events"}
              label={`Événements (${eventEntries.length})`}
              onClick={() => setMode("events")}
            />
          )}
          {peopleEntries.length > 0 && (
            <ViewButton
              active={mode === "people"}
              label={`Personnes (${peopleEntries.length})`}
              onClick={() => setMode("people")}
            />
          )}
        </div>

        {mode === "jour" && (
          <div className="space-y-2">
            {currentStatus ? (
              <p className="text-[12px] text-muted-foreground">
                Disponibilité actuelle : {AVAILABILITY_LABEL[currentStatus] ?? currentStatus}.
              </p>
            ) : (
              <p className="text-[12px] text-muted-foreground">
                Aucun statut de disponibilité enregistré pour ce jour.
              </p>
            )}
            <div className="flex flex-wrap gap-2">
              {isOwner ? (
                <>
                  <button
                    type="button"
                    onClick={() => setMode("repere")}
                    className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-3.5 py-1.5 text-[13px]"
                  >
                    <Flag className="h-3.5 w-3.5" strokeWidth={1.75} /> Ajouter un repère
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode("dispo")}
                    className="inline-flex items-center gap-1.5 rounded-full hairline bg-background px-3.5 py-1.5 text-[13px]"
                  >
                    <CircleDot className="h-3.5 w-3.5" strokeWidth={1.75} /> Régler la dispo
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => setMode("reserver")}
                  className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3.5 py-1.5 text-[13px] text-primary-foreground"
                >
                  <CalendarCheck className="h-3.5 w-3.5" strokeWidth={1.75} /> Réserver cette date
                </button>
              )}
            </div>
            {!userId && (
              <p className="text-[12px] text-muted-foreground">
                Connectez-vous pour agir sur cette date.
              </p>
            )}
          </div>
        )}

        {mode === "moments" && (
          <EntryList entries={dayEntries} empty="Aucun moment n'est posé sur ce jour." />
        )}

        {mode === "events" && (
          <EntryList entries={eventEntries} empty="Aucun événement n'est planifié sur ce jour." />
        )}

        {mode === "people" && (
          <div className="space-y-2">
            {peopleEntries.length === 0 ? (
              <p className="text-[12px] text-muted-foreground">
                Aucune personne n'est associée à ce jour.
              </p>
            ) : (
              peopleEntries.map((e) => (
                <div key={e.id} className="rounded-xl hairline bg-background px-3 py-2">
                  <p className="text-[13px] font-medium">{e.dedicated_name || "Personne liée"}</p>
                  <p className="text-[11px] text-muted-foreground">
                    <Users className="mr-1 inline h-3 w-3" strokeWidth={1.75} />
                    {formatSlot(e)} · {KIND_LABEL[e.kind] ?? e.kind}
                  </p>
                </div>
              ))
            )}
          </div>
        )}

        {mode === "repere" && (
          <div className="space-y-2">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Titre du repère"
              className="w-full rounded-xl hairline bg-background px-3 py-2.5 text-[14px] outline-none"
            />
            <button
              type="button"
              onClick={() => addMarker.mutate()}
              className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
            >
              Ajouter à la timeline
            </button>
          </div>
        )}

        {mode === "reserver" && (
          <div className="space-y-2">
            <textarea
              value={word}
              onChange={(e) => setWord(e.target.value)}
              rows={3}
              placeholder="Un mot sur ce que vous imaginez ce jour-là…"
              className="w-full rounded-xl hairline bg-background px-3 py-2.5 text-[14px] outline-none"
            />
            <button
              type="button"
              onClick={() => {
                onIntent(
                  "reserver",
                  `Date souhaitée : ${formatDay(day)}${word.trim() ? ` — ${word.trim()}` : ""}`,
                );
                setWord("");
                setMode("jour");
              }}
              className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground"
            >
              Réserver cette date
            </button>
          </div>
        )}

        {mode === "dispo" && (
          <div className="flex flex-wrap gap-2">
            {AVAILABILITY_STATUSES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setAvailability.mutate(s)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[13px]",
                  currentStatus === s
                    ? "bg-primary text-primary-foreground"
                    : "hairline bg-background",
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", AVAILABILITY_DOT[s])} />
                {AVAILABILITY_LABEL[s]}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ViewButton({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full px-2.5 py-1 text-[11px]",
        active
          ? "bg-primary text-primary-foreground"
          : "hairline bg-background text-muted-foreground",
      )}
    >
      {label}
    </button>
  );
}

function EntryList({ entries, empty }: { entries: MusicboxEntry[]; empty: string }) {
  if (entries.length === 0) return <p className="text-[12px] text-muted-foreground">{empty}</p>;
  return (
    <div className="space-y-2">
      {entries.map((e) => (
        <div key={e.id} className="rounded-xl hairline bg-background px-3 py-2">
          <p className="truncate text-[13px] font-medium">{e.title}</p>
          <p className="text-[11px] text-muted-foreground">
            {formatSlot(e)} · {KIND_LABEL[e.kind] ?? e.kind}
          </p>
        </div>
      ))}
    </div>
  );
}
