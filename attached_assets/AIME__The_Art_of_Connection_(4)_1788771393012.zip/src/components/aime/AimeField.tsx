import { useEffect, useState } from "react";
import { ArrowRight, Heart } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

/** Une entrée du cœur : ce qu'on peut demander à l'agent depuis ce champ. */
export type FieldActionGroup = "decouvrir" | "ensemble" | "lien" | "ma-page";

export type FieldAction = {
  key: string;
  label: string;
  hint?: string;
  icon: typeof Heart;
  /** Famille d'appartenance dans le menu du cœur. */
  group?: FieldActionGroup;
  /** Rien à montrer derrière : la tuile reste visible mais inerte. */
  disabled?: boolean;
  /** Pourquoi la tuile est inerte, dit simplement. */
  disabledReason?: string;
};

type Props = {
  value: string;
  onChange: (next: string) => void;
  onSubmit: () => void;
  placeholder?: string;
  /** Placeholders qui défilent automatiquement quand le champ est vide. */
  rotatingPlaceholders?: string[];
  submitLabel?: string;
  disabled?: boolean;
  /** "dark" : posé sur un visuel. "light" : posé sur fond ivoire. */
  tone?: "dark" | "light";
  /** Menu du cœur, posé au début du champ. */
  actions?: FieldAction[];
  onPick?: (key: string) => void;
  className?: string;
};

/**
 * Barre d'intention unique du site : un champ libre et un envoi.
 * Même apparence partout, seul le comportement à l'envoi change.
 */
export function AimeField({
  value,
  onChange,
  onSubmit,
  placeholder = "Que souhaitez-vous vivre ?",
  rotatingPlaceholders,
  submitLabel = "Continuer",
  disabled = false,
  tone = "dark",
  actions,
  onPick,
  className,
}: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const dark = tone === "dark";

  const [rotorIndex, setRotorIndex] = useState(0);
  useEffect(() => {
    if (!rotatingPlaceholders?.length || value) return;
    const id = window.setInterval(() => {
      setRotorIndex((i) => (i + 1) % rotatingPlaceholders.length);
    }, 3200);
    return () => window.clearInterval(id);
  }, [rotatingPlaceholders, value]);

  const activePlaceholder =
    (value ? placeholder : (rotatingPlaceholders?.[rotorIndex] ?? placeholder)) || placeholder;

  return (
    <div
      className={cn(
        "flex w-full items-center gap-2 rounded-full py-2 pr-2 pl-2 shadow-card",
        dark ? "bg-black/35 backdrop-blur-md" : "bg-card hairline",
        className,
      )}
    >
      {actions && actions.length > 0 && (
        <Popover open={menuOpen} onOpenChange={setMenuOpen}>
          <PopoverTrigger asChild>
            <button
              type="button"
              aria-label="Que voulez-vous savoir ?"
              className={cn(
                "grid h-9 w-9 shrink-0 place-items-center rounded-full transition-transform hover:scale-105",
                dark ? "bg-white/15 text-white" : "hairline bg-secondary text-foreground",
              )}
            >
              <Heart className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </PopoverTrigger>
          <PopoverContent align="start" className="w-72 rounded-3xl p-1.5">
            <div className="max-h-[340px] overflow-y-auto">
              {actions.map((a) => (
                <button
                  key={a.key}
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onPick?.(a.key);
                  }}
                  className="flex w-full items-start gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors hover:bg-secondary"
                >
                  <a.icon
                    className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground"
                    strokeWidth={1.75}
                  />
                  <span className="min-w-0">
                    <span className="block text-[14px] leading-tight">{a.label}</span>
                    {a.hint && (
                      <span className="block text-[12px] text-muted-foreground">{a.hint}</span>
                    )}
                  </span>
                </button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      )}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            if (!disabled) onSubmit();
          }
        }}
        placeholder={activePlaceholder}
        aria-label={activePlaceholder}
        className={cn(
          "min-w-0 flex-1 bg-transparent text-[15px] outline-none",
          dark
            ? "text-white placeholder:text-white/60"
            : "text-foreground placeholder:text-muted-foreground",
        )}
      />
      <button
        type="button"
        onClick={onSubmit}
        disabled={disabled}
        className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary px-4 py-2.5 text-[13px] font-medium text-primary-foreground transition-opacity disabled:opacity-40"
      >
        {submitLabel}
        <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.75} />
      </button>
    </div>
  );
}
