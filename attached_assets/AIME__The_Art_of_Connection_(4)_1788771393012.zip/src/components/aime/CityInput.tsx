import { useMemo, useState } from "react";
import { MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

type Props = {
  value: string;
  onChange: (next: string) => void;
  suggestions: { city: string; count?: number }[];
  placeholder?: string;
  className?: string;
};

/** Champ de saisie de ville avec suggestions filtrées, à la place des longues listes. */
export function CityInput({
  value,
  onChange,
  suggestions,
  placeholder = "Saisir une ville…",
  className,
}: Props) {
  const [focus, setFocus] = useState(false);
  const [draft, setDraft] = useState(value);

  const q = draft.trim().toLowerCase();
  const list = useMemo(
    () => suggestions.filter((s) => !q || s.city.toLowerCase().includes(q)).slice(0, 8),
    [suggestions, q],
  );

  return (
    <div className={cn("relative", className)}>
      <div className="flex items-center gap-2 rounded-2xl hairline bg-card px-4 py-3 shadow-soft focus-within:ring-2 focus-within:ring-ring/40">
        <MapPin className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.75} />
        <input
          value={focus ? draft : value}
          onFocus={() => {
            setDraft(value);
            setFocus(true);
          }}
          onBlur={() => {
            setFocus(false);
            onChange(draft.trim());
          }}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              onChange(draft.trim());
              (e.target as HTMLInputElement).blur();
            }
          }}
          placeholder={placeholder}
          className="w-full bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
        />
      </div>
      {focus && list.length > 0 && (
        <ul className="absolute inset-x-0 top-full z-[60] mt-2 max-h-[240px] overflow-y-auto rounded-3xl hairline bg-card p-1.5 shadow-lift">
          {list.map((s) => (
            <li key={s.city}>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setDraft(s.city);
                  onChange(s.city);
                  setFocus(false);
                }}
                className="flex w-full items-center justify-between gap-3 rounded-2xl px-3 py-2.5 text-left text-[14px] transition-colors hover:bg-secondary"
              >
                <span className="truncate">{s.city}</span>
                {s.count != null && (
                  <span className="text-[12px] text-muted-foreground">{s.count}</span>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
