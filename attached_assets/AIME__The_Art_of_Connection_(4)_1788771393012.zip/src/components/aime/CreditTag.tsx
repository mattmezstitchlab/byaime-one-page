import { FEATURES, TAG_HELP, type FeatureKey } from "@/lib/aime/features";
import { cn } from "@/lib/utils";

/**
 * Petite mention grise posée à côté d'un déclencheur : « up » ou « pro ».
 * Discrète, jamais colorée : elle informe, elle n'alerte pas.
 */
export function CreditTag({ feature, className }: { feature: FeatureKey; className?: string }) {
  const f = FEATURES[feature];
  return (
    <span
      title={`${TAG_HELP[f.tag]}${f.credits ? ` (${f.credits} crédits)` : ""}`}
      className={cn(
        "ml-1.5 inline-flex select-none items-center rounded-full border border-hairline px-1.5 py-0.5 align-middle text-[10px] font-medium uppercase tracking-[0.08em] text-muted-foreground",
        className,
      )}
    >
      {f.tag}
    </span>
  );
}
