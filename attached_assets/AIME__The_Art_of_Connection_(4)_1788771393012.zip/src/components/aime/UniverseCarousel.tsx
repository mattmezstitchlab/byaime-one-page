import { useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import { cardVisual } from "@/lib/aime/visuals";
import type { Card } from "@/lib/aime/types";

export type UniverseSlide = {
  slug: string;
  label: string;
  /** Image ou vidéo de la slide. */
  media: string;
  kind: "image" | "video";
  subtitle?: string | undefined;
  /** Tarif d'entrée, en euros. */
  from?: number | undefined;
};

/**
 * La vitrine : une slide par univers coché, pilotée par les pictos du hero.
 * Le titre de l'univers vit au centre, avec son sous-titre et son « à partir de ».
 */
export function UniverseCarousel({
  card,
  slides,
  active,
  onActiveChange,
  auto = true,
}: {
  card: Card;
  slides: UniverseSlide[];
  active: string | null;
  onActiveChange: (slug: string) => void;
  auto?: boolean;
}) {
  const index = Math.max(
    0,
    slides.findIndex((s) => s.slug === active),
  );
  const current = slides[index];

  useEffect(() => {
    if (!auto || slides.length < 2) return;
    const t = window.setInterval(() => {
      const next = slides[(index + 1) % slides.length];
      if (next) onActiveChange(next.slug);
    }, 7000);
    return () => window.clearInterval(t);
  }, [auto, slides, index, onActiveChange]);

  const media = current?.media ?? cardVisual(card);

  return (
    <>
      <AnimatePresence mode="sync" initial={false}>
        {current?.kind === "video" ? (
          <motion.video
            key={media}
            src={media}
            autoPlay
            muted
            loop
            playsInline
            initial={{ opacity: 0, scale: 1.03 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute inset-0 h-full w-full object-cover"
          />
        ) : (
          <motion.img
            key={media}
            src={media}
            alt={current ? `${card.name} — ${current.label}` : card.name}
            initial={{ opacity: 0, scale: 1.03 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
      </AnimatePresence>

      {/* Le titre centré ne s'affiche que s'il dit autre chose que le nom déjà écrit plus bas. */}
      {current && slides.length > 0 && current.label !== card.name && (
        <div className="pointer-events-none absolute inset-x-0 top-[34%] flex flex-col items-center px-6 text-center text-white">
          <motion.p
            key={`${current.slug}-title`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-[26px] font-semibold tracking-[-0.03em] drop-shadow-lg sm:text-[34px]"
          >
            {current.label}
          </motion.p>
          {current.subtitle && (
            <p className="mt-1 max-w-xl text-[14px] text-white/85 drop-shadow">{current.subtitle}</p>
          )}
          {typeof current.from === "number" && current.from > 0 && (
            <p className="mt-2 rounded-full bg-black/40 px-3 py-1 text-[12px] text-white/90 backdrop-blur-md">
              À partir de {current.from} €
            </p>
          )}
        </div>
      )}
    </>
  );
}
