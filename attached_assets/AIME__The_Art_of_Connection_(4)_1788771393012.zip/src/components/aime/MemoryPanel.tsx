import { BookOpen, ExternalLink, ShieldQuestion } from "lucide-react";
import { LEVEL_HINT, LEVEL_LABEL, type CardMemory, type SourceLevel } from "@/lib/aime/memory";

const ORDER: SourceLevel[] = ["declare", "documente", "interprete"];

/**
 * Carte de mémoire : un récit adossé à ses sources, séparées en trois niveaux.
 * Aucune note, aucun score, aucune hiérarchie : seulement l'origine de chaque
 * information et le lien pour la vérifier soi-même.
 */
export default function MemoryPanel({ memory }: { memory: CardMemory }) {
  return (
    <section className="space-y-5">
      <div className="rounded-3xl hairline bg-card p-5 shadow-soft">
        <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
          <BookOpen className="h-4 w-4" strokeWidth={1.75} /> Carte de mémoire
          {memory.era ? <span className="normal-case tracking-normal">· {memory.era}</span> : null}
        </p>
        <p className="mt-3 text-[15px] leading-relaxed">{memory.summary}</p>
        <p className="mt-4 flex items-start gap-2 text-[12px] leading-relaxed text-muted-foreground">
          <ShieldQuestion className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
          {memory.disclaimer}
        </p>
      </div>

      {ORDER.map((level) => {
        const list = memory.references.filter((r) => r.level === level);
        if (list.length === 0) return null;
        return (
          <div key={level} className="rounded-3xl hairline bg-card p-5 shadow-soft">
            <h3 className="text-[15px] font-semibold tracking-[-0.01em]">{LEVEL_LABEL[level]}</h3>
            <p className="mt-1 text-[12px] text-muted-foreground">{LEVEL_HINT[level]}</p>
            <ul className="mt-3 space-y-3">
              {list.map((r) => (
                <li key={r.id} className="border-t border-hairline pt-3 first:border-0 first:pt-0">
                  <p className="text-[14px] font-medium">
                    {r.url ? (
                      <a
                        href={r.url}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="inline-flex items-center gap-1.5 underline underline-offset-4"
                      >
                        {r.title}
                        <ExternalLink className="h-3.5 w-3.5" strokeWidth={1.75} />
                      </a>
                    ) : (
                      r.title
                    )}
                  </p>
                  {r.publisher ? (
                    <p className="text-[12px] text-muted-foreground">{r.publisher}</p>
                  ) : null}
                  {r.note ? (
                    <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
                      {r.note}
                    </p>
                  ) : null}
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </section>
  );
}
