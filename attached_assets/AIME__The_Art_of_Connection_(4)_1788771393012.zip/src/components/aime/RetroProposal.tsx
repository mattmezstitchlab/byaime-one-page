import { Check, ListTree, X } from "lucide-react";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";

/**
 * Rétroplanning proposé depuis l'intention : rien n'est enregistré tant que
 * la personne n'a pas validé. Les étapes restent en pointillé sur la règle.
 */
export function RetroProposal({
  label,
  targetTime,
  steps,
  busy,
  onConfirm,
  onCancel,
  onPick,
  className = "",
}: {
  label: string;
  targetTime: number;
  steps: TimelineMarker[];
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  onPick?: (marker: TimelineMarker) => void;
  className?: string;
}) {
  if (steps.length === 0) return null;
  return (
    <section className={className} aria-label="Rétroplanning proposé">
      <div className="rounded-3xl hairline bg-card p-4 shadow-soft">
        <header className="flex flex-wrap items-center gap-2">
          <ListTree className="h-4 w-4 text-muted-foreground" strokeWidth={1.75} />
          <h3 className="text-[14px] font-medium">
            Rétroplanning · {label}
          </h3>
          <span className="text-[13px] text-muted-foreground">
            {steps.length} étapes jusqu'au{" "}
            {new Date(targetTime).toLocaleDateString("fr-FR", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </span>
          <span className="ml-auto flex items-center gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={onConfirm}
              className="flex items-center gap-1.5 rounded-full bg-primary px-3.5 py-1.5 text-[13px] text-primary-foreground disabled:opacity-50"
            >
              <Check className="h-3.5 w-3.5" strokeWidth={2} /> Poser les étapes
            </button>
            <button
              type="button"
              onClick={onCancel}
              aria-label="Écarter le rétroplanning"
              className="grid h-8 w-8 place-items-center rounded-full hairline"
            >
              <X className="h-3.5 w-3.5" strokeWidth={2} />
            </button>
          </span>
        </header>

        <ol className="mt-3 grid gap-1.5 sm:grid-cols-2">
          {steps.map((s) => (
            <li key={s.id}>
              <button
                type="button"
                onClick={() => onPick?.(s)}
                className="flex w-full items-center gap-2 rounded-2xl px-2.5 py-1.5 text-left text-[13px] hover:bg-muted"
              >
                <span className="w-14 shrink-0 text-muted-foreground">{s.detail}</span>
                <span className="min-w-0 flex-1 truncate">{s.title}</span>
                <span className="shrink-0 text-muted-foreground">
                  {new Date(s.time).toLocaleDateString("fr-FR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "2-digit",
                  })}
                </span>
              </button>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
