import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ExternalLink, Loader2, Search, Sparkles } from "lucide-react";
import {
  acceptFind,
  CONFIDENCE_LABEL,
  FIND_KINDS,
  removeFind,
  setFindStatus,
  webMemoryQuery,
  type FindEdit,
  type WebFind,
} from "@/lib/aime/memoryWeb";
import { runWebMemorySearch } from "@/lib/aime/memoryWeb.functions";

const inputClass =
  "rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring";

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function dateInput(find: WebFind) {
  if (find.occurred_on) return `${find.occurred_on}T12:00`;
  return "";
}

/** Une trace trouvée : on la lit, on la corrige, puis on décide. */
function FindCard({ find, onDone }: { find: WebFind; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<FindEdit>({
    title: find.title,
    summary: find.summary ?? "",
    kind: find.kind,
    date: dateInput(find),
    place: find.place ?? "",
    isPublic: true,
  });

  const accept = useMutation({
    mutationFn: () => acceptFind(find, edit),
    onSuccess: () => {
      toast.success("Ajouté à votre ligne de temps");
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const refuse = useMutation({
    mutationFn: () => setFindStatus(find.id, "refusee"),
    onSuccess: onDone,
  });

  const later = useMutation({
    mutationFn: () => setFindStatus(find.id, "a_revoir"),
    onSuccess: onDone,
  });

  const forget = useMutation({ mutationFn: () => removeFind(find.id), onSuccess: onDone });

  if (find.status === "validee") {
    return (
      <li className="rounded-2xl hairline bg-card px-4 py-3 text-[14px] text-muted-foreground">
        <span className="font-medium text-foreground">{find.title}</span> — déjà ajouté à votre
        ligne de temps.{" "}
        <button type="button" onClick={() => forget.mutate()} className="underline">
          Retirer de cette liste
        </button>
      </li>
    );
  }

  return (
    <li className="rounded-3xl hairline bg-card p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[15px] font-medium">{find.title}</p>
          <p className="text-[13px] text-muted-foreground">
            {find.occurred_on
              ? new Date(find.occurred_on).toLocaleDateString("fr-FR", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })
              : find.date_text || "Date à retrouver"}
            {find.place ? ` · ${find.place}` : ""}
          </p>
        </div>
        <span className="rounded-full hairline px-3 py-1 text-[12px] text-muted-foreground">
          {CONFIDENCE_LABEL[find.confidence] ?? find.confidence}
        </span>
      </div>

      {find.summary && (
        <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{find.summary}</p>
      )}
      {find.reason && <p className="mt-2 text-[13px] italic">« {find.reason} »</p>}
      {find.duplicate_of && (
        <p className="mt-2 rounded-2xl bg-muted px-3 py-2 text-[13px]">
          Ce moment ressemble à un moment déjà présent sur votre ligne de temps.
        </p>
      )}

      <a
        href={find.source_url}
        target="_blank"
        rel="noopener noreferrer nofollow"
        className="mt-2 inline-flex items-center gap-1.5 text-[13px] text-muted-foreground underline underline-offset-4"
      >
        <ExternalLink className="h-3.5 w-3.5" />
        {find.source_title || hostOf(find.source_url)}
      </a>

      {open && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <select
            value={edit.kind}
            onChange={(e) => setEdit({ ...edit, kind: e.target.value })}
            aria-label="Type de moment"
            className={inputClass}
          >
            {FIND_KINDS.map((k) => (
              <option key={k.key} value={k.key}>
                {k.label}
              </option>
            ))}
          </select>
          <input
            type="datetime-local"
            value={edit.date}
            onChange={(e) => setEdit({ ...edit, date: e.target.value })}
            aria-label="Date du moment"
            className={inputClass}
          />
          <input
            value={edit.title}
            onChange={(e) => setEdit({ ...edit, title: e.target.value })}
            placeholder="Titre"
            className={`${inputClass} sm:col-span-2`}
          />
          <input
            value={edit.place}
            onChange={(e) => setEdit({ ...edit, place: e.target.value })}
            placeholder="Lieu"
            className={`${inputClass} sm:col-span-2`}
          />
          <textarea
            value={edit.summary}
            onChange={(e) => setEdit({ ...edit, summary: e.target.value })}
            rows={3}
            placeholder="Ce qu'on en raconte"
            className={`${inputClass} sm:col-span-2`}
          />
          <label className="flex items-center gap-2 text-[14px] sm:col-span-2">
            <input
              type="checkbox"
              checked={edit.isPublic}
              onChange={(e) => setEdit({ ...edit, isPublic: e.target.checked })}
            />
            Visible publiquement
          </label>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => (open ? accept.mutate() : setOpen(true))}
          disabled={accept.isPending}
          className="inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-50"
        >
          {accept.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
          {open ? "Ajouter à ma ligne de temps" : "Vérifier et ajouter"}
        </button>
        {open && (
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px]"
          >
            Annuler
          </button>
        )}
        <button
          type="button"
          onClick={() => later.mutate()}
          className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px]"
        >
          Plus tard
        </button>
        <button
          type="button"
          onClick={() => refuse.mutate()}
          className="rounded-2xl px-4 py-2.5 text-[14px] text-muted-foreground underline underline-offset-4"
        >
          Ce n'est pas moi
        </button>
      </div>
    </li>
  );
}

/**
 * Mémoire Web — retrouver des traces publiques de son histoire.
 * Rien n'est jamais ajouté tout seul : recherche → proposition → vérification → ajout.
 */
export function WebMemory({ cardId, cardName }: { cardId: string; cardName: string }) {
  const qc = useQueryClient();
  const search = useServerFn(runWebMemorySearch);
  const { data: finds = [], isLoading } = useQuery(webMemoryQuery(cardId));
  const [openForm, setOpenForm] = useState(false);
  const [form, setForm] = useState({
    name: cardName,
    aliases: "",
    activity: "",
    places: "",
    keywords: "",
    from: "",
    to: "",
  });

  const refresh = () => void qc.invalidateQueries({ queryKey: ["memoire-web", cardId] });

  const run = useMutation({
    mutationFn: () =>
      search({
        data: {
          cardId,
          name: form.name.trim(),
          aliases: form.aliases.trim() || undefined,
          activity: form.activity.trim() || undefined,
          places: form.places.trim() || undefined,
          keywords: form.keywords.trim() || undefined,
          from: form.from.trim() || undefined,
          to: form.to.trim() || undefined,
        },
      }),
    onSuccess: (r) => {
      refresh();
      qc.invalidateQueries({ queryKey: ["card-timeline", cardId] });
      toast(r.message);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toReview = finds.filter((f) => f.status !== "validee");

  return (
    <section className="rounded-3xl hairline bg-card p-5 shadow-soft">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="inline-flex items-center gap-2 text-[17px] font-semibold tracking-[-0.02em]">
            <Sparkles className="h-4 w-4" strokeWidth={1.75} />
            Mémoire Web
          </h3>
          <p className="mt-1 text-[14px] text-muted-foreground">
            Aime cherche des traces publiques de votre histoire. Vous seul décidez de ce qui
            rejoint votre ligne de temps.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpenForm((v) => !v)}
          className="inline-flex items-center gap-2 rounded-2xl hairline bg-background px-4 py-2.5 text-[14px]"
        >
          <Search className="h-4 w-4" strokeWidth={1.75} />
          Chercher
        </button>
      </div>

      {openForm && (
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Votre nom"
            className={inputClass}
          />
          <input
            value={form.aliases}
            onChange={(e) => setForm({ ...form, aliases: e.target.value })}
            placeholder="Autres noms, pseudonyme"
            className={inputClass}
          />
          <input
            value={form.activity}
            onChange={(e) => setForm({ ...form, activity: e.target.value })}
            placeholder="Activité (saxophoniste, association…)"
            className={inputClass}
          />
          <input
            value={form.places}
            onChange={(e) => setForm({ ...form, places: e.target.value })}
            placeholder="Villes, salles"
            className={inputClass}
          />
          <input
            value={form.from}
            onChange={(e) => setForm({ ...form, from: e.target.value })}
            placeholder="À partir de (année)"
            inputMode="numeric"
            className={inputClass}
          />
          <input
            value={form.to}
            onChange={(e) => setForm({ ...form, to: e.target.value })}
            placeholder="Jusqu'à (année)"
            inputMode="numeric"
            className={inputClass}
          />
          <input
            value={form.keywords}
            onChange={(e) => setForm({ ...form, keywords: e.target.value })}
            placeholder="Mots-clés (festival, groupe, projet…)"
            className={`${inputClass} sm:col-span-2`}
          />
          <button
            type="button"
            onClick={() => run.mutate()}
            disabled={run.isPending || form.name.trim().length < 2}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-50 sm:col-span-2"
          >
            {run.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" strokeWidth={1.75} />
            )}
            {run.isPending ? "Aime cherche…" : "Lancer la recherche"}
          </button>
        </div>
      )}

      {isLoading ? null : toReview.length === 0 ? (
        <p className="mt-4 text-[14px] text-muted-foreground">
          Aucune trace en attente. Lancez une recherche pour voir ce que le Web garde de vous.
        </p>
      ) : (
        <ul className="mt-4 space-y-3">
          {toReview.map((f) => (
            <FindCard key={f.id} find={f} onDone={refresh} />
          ))}
        </ul>
      )}
    </section>
  );
}
