import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import {
  AudioLines,
  Ban,
  CalendarCheck,
  CalendarDays,
  CircleDollarSign,
  Clock3,
  ChevronLeft,
  ChevronRight,
  FileText,
  Flag,
  Folder,
  Heart,
  History,
  ListChecks,
  MessageCircle,
  MousePointer2,
  Play,
  ReceiptText,
  ScrollText,
  Lightbulb,
  Users,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { clusterPictos, pictoFor, STATUS_DOT } from "@/lib/aime/timelineIcons";
import type { TimelineAction } from "@/lib/aime/timelineActions";
import { useIsMobile } from "@/hooks/use-mobile";

const DAY = 86_400_000;

/** Nature du contenu porté par un repère (vitrine média de la timeline). */
export type TimelineMedia = "video" | "audio" | "doc" | "historique" | "rencontre";

export type TimelineKind =
  | "souvenir"
  | "evenement"
  | "disponible"
  | "option"
  | "complet"
  | "intention"
  | "jalon"
  | "tache"
  | "message"
  | "dossier"
  | "document"
  | "devis"
  | "facture"
  | "paiement";

/** État d'un objet temporel : rien de sensible n'est exécuté sans validation humaine. */
export type TimelineStatus =
  | "prepare"
  | "a_valider"
  | "execute"
  | "bloque"
  | "en_attente"
  | "annule"
  | "echoue";

export const STATUS_LABEL: Record<TimelineStatus, string> = {
  prepare: "Préparé",
  a_valider: "À valider",
  execute: "Exécuté",
  bloque: "Bloqué",
  en_attente: "En attente",
  annule: "Annulé",
  echoue: "Échoué",
};

export const STATUS_RING: Record<TimelineStatus, string> = {
  prepare: "ring-white/50",
  a_valider: "ring-amber-400",
  execute: "ring-emerald-400",
  bloque: "ring-rose-500",
  en_attente: "ring-sky-400",
  annule: "ring-white/25",
  echoue: "ring-rose-400",
};

export type TimelineMarker = {
  id: string;
  time: number;
  kind: TimelineKind;
  title: string;
  detail?: string | undefined;
  universe?: string | undefined;
  /** Montant en centimes, affiché dans la bulle pour les repères d'argent. */
  amountCents?: number | undefined;
  /** Type de contenu : affiche un picto ou une vignette ronde. */
  media?: TimelineMedia | undefined;
  /** Vignette ronde (photo de la personne, image du document…). */
  thumbUrl?: string | undefined;
  /** Média joué dans l'aperçu (vidéo muette en boucle). */
  mediaUrl?: string | undefined;
  /** Tâche : cochée ou non. */
  done?: boolean | undefined;
  /** Message : fil de discussion à ouvrir dans la bulle. */
  threadId?: string | undefined;
  /** Message reçu et non encore lu : la pastille clignote sur la ligne. */
  unread?: boolean | undefined;

  /** Dossier : repères regroupés sous une même pastille. */
  children?: TimelineMarker[] | undefined;
  /** Créneau horaire : début et fin dans la journée (ms epoch). */
  startTime?: number | undefined;
  endTime?: number | undefined;
  /** Proposition de l'agent, en attente de validation. */
  pending?: boolean | undefined;
  /** État de l'objet : préparé, à valider, exécuté… */
  status?: TimelineStatus | undefined;
  /** Urgence relative (0 = normal, 2 = critique). */
  priority?: number | undefined;
  /** Projet / événement de rattachement. */
  projectId?: string | undefined;
  /** Personnes concernées. */
  personIds?: string[] | undefined;
  /** Autres objets reliés (identifiants de repères). */
  relatedIds?: string[] | undefined;
  /** D'où vient l'objet : saisie, document importé, agent, import bancaire… */
  source?: string | undefined;
  /** Lieu associé. */
  location?: string | undefined;
  /** Échéance (paiement, tâche, déclaration). */
  dueAt?: number | undefined;
  /** Données libres selon la nature de l'objet. */
  metadata?: Record<string, unknown> | undefined;
};

/** Alias : le modèle unique d'objet temporel de la ligne de temps AIME. */
export type TimelineItem = TimelineMarker;

/** Ce qui est concerné : le monde auquel appartient le repère. */
export type TimelineContext = {
  label: string;
  actionLabel?: string | undefined;
  open?: (() => void) | undefined;
};

/** Ce qui se passe : alerte ou information manquante attachée à un repère. */
export type TimelineAlert = {
  id: string;
  title: string;
  severity: "info" | "attention" | "critique";
};

const ALERT_DOT: Record<TimelineAlert["severity"], string> = {
  info: "bg-sky-400",
  attention: "bg-amber-400",
  critique: "bg-rose-500",
};

const BUBBLE_TITLE = "mb-1 text-[9.5px] uppercase tracking-[0.18em] text-white/40";


/** Période continue (disponibilités regroupées) affichée en barre sous la règle. */
export type TimelineBand = {
  id: string;
  start: number;
  end: number;
  kind: Extract<TimelineKind, "disponible" | "option" | "complet">;
  label?: string | undefined;
};

export const MEDIA_ICON = {
  video: Play,
  audio: AudioLines,
  doc: FileText,
  historique: History,
  rencontre: Users,
} as const;

/** Un langage visuel unique : chaque nature d'objet garde le même picto sur la règle. */
export const KIND_ICON = {
  souvenir: Heart,
  evenement: CalendarDays,
  disponible: CalendarCheck,
  option: Clock3,
  complet: Ban,
  intention: Lightbulb,
  jalon: Flag,
  tache: ListChecks,
  message: MessageCircle,
  dossier: Folder,
  document: FileText,
  devis: ReceiptText,
  facture: ScrollText,
  paiement: CircleDollarSign,
} as const;

export const MEDIA_LABEL: Record<TimelineMedia, string> = {
  video: "Vidéo",
  audio: "Audio",
  doc: "Document",
  historique: "Historique",
  rencontre: "Rencontre",
};

export const MARKER_DOT: Record<TimelineKind, string> = {
  souvenir: "bg-white/60",
  evenement: "bg-white",
  disponible: "bg-emerald-400",
  option: "bg-amber-400",
  complet: "bg-rose-400",
  intention: "bg-aime",
  jalon: "bg-sky-400",
  document: "bg-slate-300",
  devis: "bg-indigo-300",
  facture: "bg-violet-300",
  paiement: "bg-teal-300",
  tache: "bg-orange-300",
  message: "bg-cyan-300",
  dossier: "bg-white/85",
};

export const KIND_LABEL_TIMELINE: Record<TimelineKind, string> = {
  souvenir: "Souvenir",
  evenement: "Événement",
  disponible: "Disponible",
  option: "En option",
  complet: "Complet",
  intention: "Intention",
  jalon: "Jalon",
  document: "Document",
  devis: "Devis",
  facture: "Facture",
  paiement: "Paiement",
  tache: "Tâche",
  message: "Message",
  dossier: "Dossier",
};

type Tick = { time: number; major: boolean; label?: string };

/** Choisit la graduation en fonction du zoom (px par jour). */
function buildTicks(startMs: number, endMs: number, pxPerDay: number): Tick[] {
  const ticks: Tick[] = [];
  const start = new Date(startMs);
  if (pxPerDay >= 14) {
    // jours, libellé chaque lundi
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    for (let t = d.getTime(); t <= endMs; t += DAY) {
      const date = new Date(t);
      const major = date.getDay() === 1;
      ticks.push({
        time: t,
        major,
        ...(major
          ? { label: date.toLocaleDateString("fr-FR", { timeZone: "Europe/Paris", day: "numeric", month: "short" }) }
          : {}),
      });
    }
  } else if (pxPerDay >= 1.6) {
    // mois, libellé chaque mois
    const d = new Date(start.getFullYear(), start.getMonth(), 1);
    while (d.getTime() <= endMs) {
      const isYear = d.getMonth() === 0;
      ticks.push({
        time: d.getTime(),
        major: true,
        label: isYear ? `${d.getFullYear()}` : d.toLocaleDateString("fr-FR", { timeZone: "Europe/Paris", month: "short" }),
      });
      // sous-graduations : semaines
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1);
      for (let t = d.getTime() + 7 * DAY; t < next.getTime(); t += 7 * DAY) {
        ticks.push({ time: t, major: false });
      }
      d.setMonth(d.getMonth() + 1);
    }
  } else if (pxPerDay >= 0.12) {
    // années, sous-graduations mensuelles
    const d = new Date(start.getFullYear(), 0, 1);
    while (d.getTime() <= endMs) {
      ticks.push({ time: d.getTime(), major: true, label: `${d.getFullYear()}` });
      for (let m = 1; m < 12; m += 1) {
        ticks.push({ time: new Date(d.getFullYear(), m, 1).getTime(), major: false });
      }
      d.setFullYear(d.getFullYear() + 1);
    }
  } else {
    // décennies
    const y0 = Math.floor(start.getFullYear() / 10) * 10;
    for (let y = y0; new Date(y, 0, 1).getTime() <= endMs; y += 10) {
      ticks.push({ time: new Date(y, 0, 1).getTime(), major: true, label: `${y}` });
      for (let k = 1; k < 10; k += 1) {
        ticks.push({ time: new Date(y + k, 0, 1).getTime(), major: false });
      }
    }
  }
  return ticks;
}

function zoomLabel(pxPerDay: number) {
  if (pxPerDay >= 14) return "Semaine";
  if (pxPerDay >= 1.6) return "Mois";
  if (pxPerDay >= 0.12) return "Année";
  return "Décennie";
}

export function HeroTimeline({
  markers,
  bands = [],
  onSelectMarker,
  onPickDate,
  onMoveMarker,
  canMove,
  actionsFor,
  renderExtra,
  contextFor,
  alertsFor,
  relatedFor,

  preview = true,
  autoScroll = false,
  activeUniverse,
  focus,
  visible,
  playingId,
  recenter,
  className,
}: {
  markers: TimelineMarker[];
  /** Périodes continues (disponibilités regroupées). */
  bands?: TimelineBand[];
  onSelectMarker?: (marker: TimelineMarker) => void;
  onPickDate?: (time: number) => void;
  /** Déplacement d'un repère dans le temps par glisser-déposer. */
  onMoveMarker?: (marker: TimelineMarker, time: number) => void;
  /** Quels repères peuvent être déplacés (par défaut : aucun). */
  canMove?: (marker: TimelineMarker) => boolean;
  /** Actions proposées dans la bulle d'aperçu. */
  actionsFor?: (marker: TimelineMarker) => TimelineAction[];
  /** Contenu supplémentaire dans la bulle : édition en place, réponse à un message… */
  renderExtra?: (marker: TimelineMarker, close: () => void) => ReactNode;

  /** Ce qui est concerné : projet, monde ou dossier de rattachement du repère. */
  contextFor?: (marker: TimelineMarker) => TimelineContext | null | undefined;
  /** Ce qui se passe : alertes et informations manquantes portées par le repère. */
  alertsFor?: (marker: TimelineMarker) => TimelineAlert[];
  /** Ce qui est lié : autres repères de la même ligne de temps. */
  relatedFor?: (marker: TimelineMarker) => TimelineMarker[];

  /** Affiche l'aperçu interne (vidéo, audio, document, souvenir, rencontre). */
  preview?: boolean;
  /** Déroulé lent à l'arrivée, interrompu au premier geste. */
  autoScroll?: boolean;
  /** Univers sélectionné : les repères des autres univers s'estompent. */
  activeUniverse?: string;
  /** Recentrage animé demandé par l'agent : la ligne se déplace sur cette période. */
  focus?: { from: number; to: number; at?: number } | null;
  /** Calques : un repère masqué reste en base, il n'est simplement pas dessiné. */
  visible?: (marker: TimelineMarker) => boolean;
  /** Repère actuellement lu par PLAY : la règle le met en évidence. */
  playingId?: string | null;
  /** Jeton de recentrage : à chaque nouvelle valeur, la règle revient sur maintenant. */
  recenter?: number;
  className?: string;
}) {

  const ref = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const [width, setWidth] = useState(0);
  const now = useMemo(() => Date.now(), []);
  const [center, setCenter] = useState(now);
  const [pxPerDay, setPxPerDay] = useState(1.2);
  const [hovered, setHovered] = useState<TimelineMarker | null>(null);
  const [pinned, setPinned] = useState<TimelineMarker | null>(null);
  const active = pinned ?? hovered;
  const bubbleRef = useRef<HTMLDivElement>(null);
  const [bubblePosition, setBubblePosition] = useState({ left: 0, top: 76 });
  /** Repère en cours de déplacement : sa date suit le doigt avant d'être enregistrée. */
  const [moving, setMoving] = useState<{ id: string; time: number } | null>(null);
  const moveRef = useRef<{
    id: string;
    pointerId: number;
    x: number;
    time: number;
    moved: boolean;
  } | null>(null);
  const suppressClick = useRef(false);

  const [drifting, setDrifting] = useState(autoScroll);
  /** Survol simulé par la flèche de démonstration (n'arrête pas le déroulé). */
  const [ghost, setGhost] = useState(false);
  /** Indices de gestes (pincer / glisser), montrés quelques secondes au départ. */
  const [hint, setHint] = useState<"pinch" | "drag" | null>(autoScroll ? "pinch" : null);

  const stateRef = useRef({ center, pxPerDay, width });
  stateRef.current = { center, pxPerDay, width };

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const closeBubble = () => {
    setPinned(null);
    setHovered(null);
  };

  // La bulle ne survit pas à la sortie d'écran de la ligne de temps
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) closeBubble();
      },
      { threshold: 0 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Recentrage animé demandé par l'agent : la ligne se déplace sur la période cherchée
  useEffect(() => {
    if (!focus) return;
    const s = stateRef.current;
    const span = Math.max(DAY, focus.to - focus.from);
    const target = focus.from + span / 2;
    // Une période courte (quelques heures) a le droit d'occuper toute la largeur.
    const zoom =
      s.width > 240 ? Math.min(900, Math.max(0.05, (s.width * 0.7) / (span / DAY))) : 1.2;
    setDrifting(false);
    const from = s.center;
    const fromZoom = s.pxPerDay;
    const t0 = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - t0) / 700);
      const e = 1 - Math.pow(1 - k, 3);
      setCenter(from + (target - from) * e);
      setPxPerDay(fromZoom + (zoom - fromZoom) * e);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [focus]);

  // Recentrage sur maintenant, au zoom par défaut (bouton « Aujourd'hui » de la capsule)
  useEffect(() => {
    if (!recenter) return;
    setDrifting(false);
    setCenter(Date.now());
    setPxPerDay(1.2);
  }, [recenter]);

  // Bulle épinglée : fermeture au clic extérieur ou avec Échap (comme le menu du cœur)
  useEffect(() => {
    if (!pinned) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (bubbleRef.current?.contains(t)) return;
      if (ref.current?.contains(t)) return;
      closeBubble();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeBubble();
    };
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [pinned]);

  // L'aperçu vit au niveau de la page : aucun hero ne peut le découper.
  useEffect(() => {
    if (!active || isMobile) return;
    const place = () => {
      const rect = ref.current?.getBoundingClientRect();
      if (!rect) return;
      const markerX = rect.left + timeToX(active.time);
      const bubbleHeight = bubbleRef.current?.offsetHeight ?? 320;
      const top = Math.max(76, Math.min(rect.top - bubbleHeight - 8, window.innerHeight - bubbleHeight - 12));
      setBubblePosition({
        left: Math.min(Math.max(markerX, 142), window.innerWidth - 142),
        top,
      });
    };
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [active, center, pxPerDay, width, isMobile]);

  // Déroulé lent d'accueil (respecte prefers-reduced-motion), stoppé au premier geste
  useEffect(() => {
    if (!drifting || pinned || (hovered && !ghost)) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setDrifting(false);
      return;
    }
    let raf = 0;
    let last = performance.now();
    const tick = (t: number) => {
      const dt = t - last;
      last = t;
      setCenter((c) => c + (dt / 1000) * 2.4 * DAY);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [drifting, hovered, pinned, ghost]);

  // Flèche de démonstration : elle se pose d'un repère à l'autre et ouvre le bloc
  const markersRef = useRef(markers);
  markersRef.current = markers;
  useEffect(() => {
    if (!drifting || pinned || isMobile) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const pick = () => {
      const s = stateRef.current;
      if (s.width < 240) return;
      const target = s.center + ((s.width * 0.12) / s.pxPerDay) * DAY;
      let best: TimelineMarker | null = null;
      let bestGap = Infinity;
      for (const m of markersRef.current) {
        const x = s.width / 2 + ((m.time - s.center) / DAY) * s.pxPerDay;
        if (x < 90 || x > s.width - 90) continue;
        const gap = Math.abs(m.time - target);
        if (gap < bestGap) {
          bestGap = gap;
          best = m;
        }
      }
      if (best) {
        setGhost(true);
        setHovered(best);
      }
    };
    const first = window.setTimeout(pick, 1600);
    const id = window.setInterval(pick, 3600);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(id);
    };
  }, [drifting, pinned, isMobile]);

  // Indices de gestes : pincer pour élargir, puis glisser pour se déplacer
  useEffect(() => {
    if (!autoScroll) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setHint(null);
      return;
    }
    const toDrag = window.setTimeout(() => setHint("drag"), 4200);
    const off = window.setTimeout(() => setHint(null), 9000);
    return () => {
      window.clearTimeout(toDrag);
      window.clearTimeout(off);
    };
  }, [autoScroll]);

  // Premier geste réel : la démonstration s'efface
  useEffect(() => {
    if (drifting) return;
    setHint(null);
    setGhost((g) => {
      if (g) setHovered(null);
      return false;
    });
  }, [drifting]);

  // Zoom molette / pinch, listener natif non passif
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      setDrifting(false);
      const s = stateRef.current;
      const rect = el.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
      const nextZoom = Math.min(80, Math.max(0.02, s.pxPerDay * Math.exp(-dy * 0.0022)));
      // temps sous le curseur conservé
      const anchorTime = s.center + ((px - s.width / 2) / s.pxPerDay) * DAY;
      const nextCenter = anchorTime - ((px - s.width / 2) / nextZoom) * DAY;
      setPxPerDay(nextZoom);
      setCenter(nextCenter);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  // Glisser (souris + tactile) et pinch deux doigts
  const pointers = useRef(new Map<number, { x: number }>());
  const dragRef = useRef<{ x: number; center: number; moved: boolean } | null>(null);
  const pinchRef = useRef<{ dist: number; zoom: number } | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    setDrifting(false);
    (e.target as Element).setPointerCapture?.(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX });
    if (pointers.current.size === 1) {
      dragRef.current = { x: e.clientX, center, moved: false };
    } else if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      pinchRef.current = { dist: Math.abs(a!.x - b!.x) || 1, zoom: pxPerDay };
      dragRef.current = null;
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX });
    const s = stateRef.current;
    if (pointers.current.size >= 2 && pinchRef.current) {
      const [a, b] = [...pointers.current.values()];
      const dist = Math.abs(a!.x - b!.x) || 1;
      setPxPerDay(
        Math.min(80, Math.max(0.02, pinchRef.current.zoom * (dist / pinchRef.current.dist))),
      );
      return;
    }
    const drag = dragRef.current;
    if (!drag) return;
    const dx = e.clientX - drag.x;
    if (Math.abs(dx) > 3) drag.moved = true;
    setCenter(drag.center - (dx / s.pxPerDay) * DAY);
  };

  const endPointer = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinchRef.current = null;
    if (pointers.current.size === 0) {
      const drag = dragRef.current;
      dragRef.current = null;
      if (drag && !drag.moved && onPickDate) {
        const rect = ref.current?.getBoundingClientRect();
        if (rect) {
          const px = e.clientX - rect.left;
          onPickDate(stateRef.current.center + ((px - width / 2) / pxPerDay) * DAY);
        }
      }
    }
  };

  const timeToX = (t: number) => width / 2 + ((t - center) / DAY) * pxPerDay;
  const spanMs = width > 0 ? (width / pxPerDay) * DAY : 0;
  const startMs = center - spanMs / 2;
  const endMs = center + spanMs / 2;
  const ticks = width > 0 ? buildTicks(startMs, endMs, pxPerDay) : [];

  const filtered = visible ? markers.filter((m) => visible(m)) : markers;
  const filteredBands = visible
    ? bands.filter((b) =>
        visible({ id: b.id, time: (b.start + b.end) / 2, kind: b.kind, title: b.label ?? "" }),
      )
    : bands;


  const inWindow = filtered.filter((m) => m.time >= startMs - DAY && m.time <= endMs + DAY);

  /** Regroupement : des repères trop proches à l'écran deviennent un dossier. */
  const visibleMarkers = useMemo(() => {
    if (width <= 0) return inWindow;
    const sorted = [...inWindow].sort((a, b) => a.time - b.time);
    const gapMs = (18 / pxPerDay) * DAY;
    const out: TimelineMarker[] = [];
    let pack: TimelineMarker[] = [];
    const flush = () => {
      if (pack.length === 0) return;
      if (pack.length === 1) {
        out.push(pack[0]!);
      } else {
        const mid = (pack[0]!.time + pack[pack.length - 1]!.time) / 2;
        out.push({
          id: `dossier-${pack[0]!.id}-${pack.length}`,
          time: mid,
          kind: "dossier",
          title: `${pack.length} repères`,
          detail: pack
            .slice(0, 3)
            .map((p) => p.title)
            .join(" · "),
          children: pack,
        });
      }
      pack = [];
    };
    for (const m of sorted) {
      const last = pack[pack.length - 1];
      if (last && m.time - last.time <= gapMs) pack.push(m);
      else {
        flush();
        pack = [m];
      }
    }
    flush();
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inWindow.map((m) => m.id).join("|"), pxPerDay, width]);

  const visibleBands = filteredBands.filter((b) => b.end >= startMs && b.start <= endMs);
  const activeActions = active && actionsFor && active.kind !== "dossier" ? actionsFor(active) : [];
  /** Les cinq sections de la bulle : ce que c'est, concerné, ce qui se passe, lié, actions. */
  const context = active && contextFor ? contextFor(active) : null;
  const alerts = active && alertsFor ? alertsFor(active) : [];
  const related = active && relatedFor ? relatedFor(active) : [];
  const hasDeep = Boolean(context || alerts.length > 0 || related.length > 0 || renderExtra);
  const [deep, setDeep] = useState(false);
  useEffect(() => {
    setDeep(false);
  }, [active?.id]);


  return (
    <div
      className={cn("relative select-none", className)}
      onMouseEnter={() => setDrifting(false)}
      onMouseLeave={() => setHovered(null)}
    >
      <div className="flex items-center justify-end px-4 pb-1.5 text-[11px] text-white/70">
        <span className="tabular-nums">{zoomLabel(pxPerDay)}</span>
      </div>


      <div
        ref={ref}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
        style={{ touchAction: "none" }}
        className="relative h-24 w-full cursor-ew-resize overflow-hidden border-t border-white/15 bg-black backdrop-blur-md"
      >
        {/* graduations */}
        {ticks.map((t) => {
          const x = timeToX(t.time);
          if (x < -60 || x > width + 60) return null;
          return (
            <div
              key={`${t.time}-${t.major}`}
              className="pointer-events-none absolute"
              style={{ left: x }}
            >
              <div
                className={cn(
                  "absolute top-0 w-px -translate-x-1/2 bg-white",
                  t.major ? "h-5 opacity-60" : "h-2.5 opacity-25",
                )}
              />
              {t.label && (
                <span className="absolute top-6 -translate-x-1/2 whitespace-nowrap text-[10px] tabular-nums text-white/60">
                  {t.label}
                </span>
              )}
            </div>
          );
        })}

        {/* périodes continues (disponibilités regroupées) */}
        {visibleBands.map((b) => {
          const x1 = timeToX(b.start);
          const x2 = timeToX(b.end);
          const left = Math.max(x1, -20);
          const w = Math.max(3, Math.min(x2, width + 20) - left);
          return (
            <div
              key={b.id}
              title={b.label ?? KIND_LABEL_TIMELINE[b.kind]}
              className={cn(
                "pointer-events-none absolute bottom-[9px] h-[5px] rounded-full opacity-90",
                MARKER_DOT[b.kind],
              )}
              style={{ left, width: w }}
            />
          );
        })}

        {/* repères */}
        {visibleMarkers.map((m) => {
          const dimmed = !!activeUniverse && !!m.universe && m.universe !== activeUniverse;
          const movable = Boolean(onMoveMarker && canMove?.(m) && m.kind !== "dossier");
          const shownTime = moving?.id === m.id ? moving.time : m.time;
          const x = timeToX(shownTime);
          if (x < -80 || x > width + 80) return null;
          const Icon = pictoFor(m);
          const cluster = m.kind === "dossier" ? clusterPictos(m.children ?? []) : null;
          const statusDot = m.status ? STATUS_DOT[m.status] : null;
          return (
            <button
              key={m.id}
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                if (!movable) return;
                moveRef.current = {
                  id: m.id,
                  pointerId: e.pointerId,
                  x: e.clientX,
                  time: m.time,
                  moved: false,
                };
                e.currentTarget.setPointerCapture(e.pointerId);
              }}
              onPointerMove={(e) => {
                const mv = moveRef.current;
                if (!mv || mv.pointerId !== e.pointerId) return;
                const dx = e.clientX - mv.x;
                if (Math.abs(dx) > 3) mv.moved = true;
                if (!mv.moved) return;
                setDrifting(false);
                setMoving({ id: mv.id, time: mv.time + (dx / pxPerDay) * DAY });
              }}
              onPointerUp={(e) => {
                const mv = moveRef.current;
                moveRef.current = null;
                if (!mv || mv.pointerId !== e.pointerId) return;
                const dropped = moving?.id === mv.id ? moving.time : null;
                setMoving(null);
                if (mv.moved && dropped !== null) {
                  suppressClick.current = true;
                  onMoveMarker?.(m, Math.round(dropped));
                }
              }}
              onPointerCancel={() => {
                moveRef.current = null;
                setMoving(null);
              }}
              onMouseEnter={() => {
                if (!preview || pinned) return;
                setGhost(false);
                setHovered(m);
              }}
              onFocus={() => {
                if (!preview || pinned) return;
                setGhost(false);
                setHovered(m);
              }}
              onClick={() => {
                if (suppressClick.current) {
                  suppressClick.current = false;
                  return;
                }
                if (preview) {
                  setDrifting(false);
                  setPinned((p) => (p?.id === m.id ? null : m));
                  setHovered(null);
                }
                onSelectMarker?.(m);
              }}

              className={cn(
                "absolute bottom-2 -translate-x-1/2 text-left transition-opacity",
                dimmed && "opacity-25",
                m.pending && "animate-pulse",
                movable && "cursor-grab active:cursor-grabbing",
                moving?.id === m.id && "z-30 opacity-90",
                playingId === m.id && "z-20 scale-125",
              )}


              style={{ left: x }}
              aria-label={`${m.title}${m.media ? ` — ${MEDIA_LABEL[m.media]}` : ""}`}
            >
              {cluster ? (
                <span
                  className={cn(
                    "mx-auto flex h-7 items-center gap-0.5 rounded-full bg-black/70 px-1.5 text-white ring-2 backdrop-blur-md transition-transform",
                    active?.id === m.id ? "scale-110 ring-aime" : "ring-white/50",
                  )}
                >
                  {cluster.icons.map((Picto, i) => (
                    <Picto key={i} className="h-3.5 w-3.5" strokeWidth={1.9} />
                  ))}
                  {cluster.rest > 0 && (
                    <span className="text-[9px] tabular-nums text-white/70">+{cluster.rest}</span>
                  )}
                </span>
              ) : m.thumbUrl ? (
                <img
                  src={m.thumbUrl}
                  alt=""
                  className={cn(
                    "mx-auto block h-8 w-8 rounded-full object-cover ring-2 transition-transform",
                    active?.id === m.id ? "scale-110 ring-aime" : "ring-white/70",
                  )}
                />
              ) : (
                <span
                  className={cn(
                    "mx-auto grid h-7 w-7 place-items-center rounded-full bg-black/65 text-white ring-2 backdrop-blur-md transition-transform",
                    active?.id === m.id ? "scale-110 ring-aime" : "ring-white/50",
                  )}
                >
                  <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
                </span>
              )}
              {m.unread && (
                <span
                  aria-hidden
                  className="pointer-events-none absolute -left-1 -top-1 block h-2.5 w-2.5 animate-ping rounded-full bg-aime"
                />
              )}
              {m.unread && (
                <span
                  aria-hidden
                  className="pointer-events-none absolute -left-1 -top-1 block h-2.5 w-2.5 rounded-full bg-aime ring-1 ring-black/40"
                />
              )}
              {statusDot && (
                <span
                  aria-hidden
                  title={m.status ? STATUS_LABEL[m.status] : undefined}
                  className={cn(
                    "absolute -right-0.5 -top-0.5 block h-2 w-2 rounded-full ring-1 ring-black/50",
                    statusDot,
                  )}
                />
              )}

              {moving?.id === m.id && (
                <span className="pointer-events-none absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-white px-2 py-0.5 text-[10px] font-medium tabular-nums text-black">
                  {new Date(shownTime).toLocaleDateString("fr-FR", {
                    timeZone: "Europe/Paris",
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                </span>
              )}
              {playingId === m.id && (
                <span
                  aria-hidden
                  className="pointer-events-none absolute inset-0 -m-2 animate-pulse rounded-full ring-2 ring-aime"
                />
              )}

            </button>

          );
        })}

        {/* curseur présent */}
        {(() => {
          const x = timeToX(now);
          if (x < 0 || x > width) return null;
          return (
            <div className="pointer-events-none absolute inset-y-0" style={{ left: x }}>
              <div className="absolute inset-y-0 w-px -translate-x-1/2 bg-aime" />
              <span className="absolute top-1 -translate-x-1/2 rounded-full bg-aime px-2 py-0.5 text-[9px] font-medium uppercase tracking-[0.12em] text-white">
                Aujourd'hui
              </span>
            </div>
          );
        })()}

        {/* flèche de démonstration : elle se pose sur le repère mis en avant */}
        {ghost && active && (
          <div
            className="pointer-events-none absolute bottom-[26px] transition-[left] duration-700 ease-out"
            style={{ left: timeToX(active.time) + 6 }}
          >
            <MousePointer2 className="h-4 w-4 animate-ghost-tap fill-white text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.6)]" />
          </div>
        )}

        {/* indices de gestes */}
        {hint && (
          <div className="pointer-events-none absolute inset-x-0 bottom-1 flex justify-center">
            <span className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[10.5px] text-white/75 backdrop-blur-md">
              {hint === "pinch" ? (
                <>
                  <span className="flex w-9 items-center justify-center">
                    <ChevronLeft className="h-3.5 w-3.5 animate-spread-left" strokeWidth={2} />
                    <ChevronRight className="h-3.5 w-3.5 animate-spread-right" strokeWidth={2} />
                  </span>
                  Pincez pour élargir la ligne
                </>
              ) : (
                <>
                  <span className="flex w-9 items-center justify-center">
                    <MousePointer2 className="h-3.5 w-3.5 animate-hand-slide" strokeWidth={2} />
                  </span>
                  Glissez pour vous déplacer dans le temps
                </>
              )}
            </span>
          </div>
        )}
      </div>

      {/* aperçu du repère : survol sur ordinateur, appui volontaire sur mobile */}
      {preview && active && (!isMobile || pinned) && typeof document !== "undefined" && createPortal(
        <div
          ref={bubbleRef}
          onMouseEnter={() => !pinned && setHovered(active)}
          className={cn(
            "scrollbar-dark z-[60] max-h-[calc(100vh-84px)] overflow-y-auto rounded-2xl border border-white/15 bg-black/80 p-3 text-white shadow-2xl backdrop-blur-xl",
            isMobile
              ? "fixed inset-x-3 bottom-3"
              : "fixed w-[260px] -translate-x-1/2 pb-3",
          )}
          style={
            isMobile
              ? undefined
              : { left: bubblePosition.left, top: bubblePosition.top }
          }
          role={pinned ? "dialog" : "status"}
        >
          {active.mediaUrl && active.media === "video" && (
            <video
              src={active.mediaUrl}
              autoPlay
              muted
              loop
              playsInline
              className="mb-2 h-24 w-full rounded-xl object-cover"
            />
          )}
          {active.thumbUrl && !active.mediaUrl && (
            <img
              src={active.thumbUrl}
              alt=""
              className="mb-2 h-24 w-full rounded-xl object-cover"
            />
          )}
          {active.media === "audio" && (
            <div className="mb-2 flex h-10 items-end gap-[3px] rounded-xl bg-white/10 px-3 py-2">
              {[6, 14, 9, 20, 12, 24, 8, 17, 11, 22, 7, 15].map((h, i) => (
                <span
                  key={i}
                  className="animate-audio-wave w-[3px] rounded-full bg-aime/90"
                  style={{
                    height: h,
                    animationDelay: `${(i % 6) * 0.11}s`,
                    animationDuration: `${0.9 + (i % 4) * 0.14}s`,
                  }}
                />
              ))}
            </div>
          )}
          {/* 1 — CE QUE C'EST */}
          <p className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.16em] text-white/55">
            {(() => {
              const Picto = pictoFor(active);
              return <Picto className="h-3.5 w-3.5 text-white/80" strokeWidth={1.9} />;
            })()}
            {active.kind === "dossier"
              ? `${active.children?.length ?? 0} repères`
              : KIND_LABEL_TIMELINE[active.kind]}
            {active.pending && <span className="text-aime">· proposition</span>}
          </p>
          <p className="mt-1 text-[14px] font-medium leading-snug">{active.title}</p>
          {active.detail && (
            <p className="mt-0.5 text-[12px] leading-snug text-white/70">{active.detail}</p>
          )}
          <p className="mt-1.5 flex items-center justify-between gap-3 text-[11px] tabular-nums text-white/50">
            <span>
              {new Date(active.time).toLocaleDateString("fr-FR", { timeZone: "Europe/Paris",
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
              {typeof active.startTime === "number" && (
                <>
                  {" · "}
                  {new Date(active.startTime).toLocaleTimeString("fr-FR", { timeZone: "Europe/Paris",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                  {typeof active.endTime === "number" &&
                    ` – ${new Date(active.endTime).toLocaleTimeString("fr-FR", { timeZone: "Europe/Paris",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}`}
                </>
              )}
            </span>
            {typeof active.amountCents === "number" && (
              <span className="font-medium text-white/85">
                {(active.amountCents / 100).toLocaleString("fr-FR", {
                  style: "currency",
                  currency: "EUR",
                  maximumFractionDigits: 0,
                })}
              </span>
            )}
          </p>

          {active.kind === "dossier" && active.children && (
            <>
            <div className="mt-2 flex flex-wrap gap-1.5 border-t border-white/10 pt-2">
              <button
                type="button"
                onClick={() => {
                  const kids = active.children ?? [];
                  const from = Math.min(...kids.map((c) => c.time));
                  const to = Math.max(...kids.map((c) => c.time));
                  const span = Math.max(DAY, (to - from) * 1.6);
                  setCenter((from + to) / 2);
                  setPxPerDay(
                    Math.min(900, Math.max(0.05, (stateRef.current.width * 0.7) / (span / DAY))),
                  );
                }}
                className="rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
              >
                Séparer
              </button>
              {onMoveMarker &&
                (
                  [
                    ["− 1 jour", -DAY],
                    ["+ 1 jour", DAY],
                    ["+ 1 semaine", 7 * DAY],
                  ] as const
                ).map(([label, delta]) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => {
                      for (const c of active.children ?? []) {
                        if (canMove?.(c)) onMoveMarker(c, c.time + delta);
                      }
                    }}
                    className="rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
                  >
                    {label}
                  </button>
                ))}
            </div>
            <ul className="scrollbar-dark mt-2 max-h-56 space-y-1 overflow-y-auto border-t border-white/10 pt-2">
              {active.children.map((c) => {
                const Picto = pictoFor(c);
                return (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setPinned(c);
                      setHovered(null);
                      onSelectMarker?.(c);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors hover:bg-white/10"
                  >
                    <Picto className="h-3.5 w-3.5 shrink-0 text-white/75" strokeWidth={1.9} />
                    <span className="min-w-0 flex-1 truncate text-[12.5px]">{c.title}</span>
                    <span className="shrink-0 text-[10.5px] tabular-nums text-white/45">
                      {new Date(c.time).toLocaleDateString("fr-FR", { timeZone: "Europe/Paris",
                        day: "numeric",
                        month: "short",
                      })}
                    </span>
                  </button>
                </li>
                );
              })}
            </ul>
            </>
          )}

          {active.kind !== "dossier" && (deep || !isMobile) && (
            <>
              {/* 2 — CE QUI EST CONCERNÉ */}
              {(context || active.location) && (
                <div className="mt-2.5 border-t border-white/10 pt-2.5">
                  <p className={BUBBLE_TITLE}>Ce qui est concerné</p>
                  {active.location && (
                    <p className="text-[12px] text-white/75">{active.location}</p>
                  )}
                  {context && (
                    <button
                      type="button"
                      onClick={() => context.open?.()}
                      disabled={!context.open}
                      className="mt-1 flex w-full items-center justify-between gap-2 rounded-xl bg-white/8 px-2.5 py-1.5 text-left text-[12px] transition-colors enabled:hover:bg-white/16 disabled:cursor-default"
                    >
                      <span className="min-w-0 truncate text-white/85">{context.label}</span>
                      {context.open && (
                        <span className="shrink-0 text-[11px] text-white/55">
                          {context.actionLabel ?? "Voir le contexte"}
                        </span>
                      )}
                    </button>
                  )}
                </div>
              )}

              {/* 3 — CE QUI SE PASSE */}
              {(active.status || alerts.length > 0) && (
                <div className="mt-2.5 border-t border-white/10 pt-2.5">
                  <p className={BUBBLE_TITLE}>Ce qui se passe</p>
                  {active.status && (
                    <p className="flex items-center gap-1.5 text-[12px] text-white/75">
                      <span
                        className={cn(
                          "h-1.5 w-1.5 rounded-full",
                          STATUS_DOT[active.status] ?? "bg-white/40",
                        )}
                      />
                      {STATUS_LABEL[active.status]}
                    </p>
                  )}
                  {alerts.slice(0, 3).map((a) => (
                    <p
                      key={a.id}
                      className="mt-1 flex items-start gap-1.5 text-[12px] leading-snug text-white/75"
                    >
                      <span
                        className={cn(
                          "mt-1 h-1.5 w-1.5 shrink-0 rounded-full",
                          ALERT_DOT[a.severity],
                        )}
                      />
                      {a.title}
                    </p>
                  ))}
                </div>
              )}

              {/* 4 — CE QUI EST LIÉ */}
              {related.length > 0 && (
                <div className="mt-2.5 border-t border-white/10 pt-2.5">
                  <p className={BUBBLE_TITLE}>Ce qui est lié</p>
                  <ul className="space-y-0.5">
                    {related.slice(0, 5).map((r) => {
                      const Picto = pictoFor(r);
                      return (
                        <li key={r.id}>
                          <button
                            type="button"
                            onClick={() => {
                              setPinned(r);
                              setHovered(null);
                              onSelectMarker?.(r);
                            }}
                            className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-left transition-colors hover:bg-white/10"
                          >
                            <Picto className="h-3 w-3 shrink-0 text-white/65" strokeWidth={1.9} />
                            <span className="min-w-0 flex-1 truncate text-[12px] text-white/80">
                              {r.title}
                            </span>
                            <span className="shrink-0 text-[10.5px] tabular-nums text-white/45">
                              {new Date(r.time).toLocaleDateString("fr-FR", {
                                timeZone: "Europe/Paris",
                                day: "numeric",
                                month: "short",
                              })}
                            </span>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}

              {renderExtra && (
                <div className="mt-2.5 border-t border-white/10 pt-2.5">
                  {renderExtra(active, closeBubble)}
                </div>
              )}
            </>
          )}

          {/* 5 — CE QUE JE PEUX FAIRE : quatre actions au plus, deux sur mobile */}
          {activeActions.length > 0 && (
            <div className="mt-3 border-t border-white/10 pt-2.5">
              <p className={BUBBLE_TITLE}>Ce que je peux faire</p>
              <div className="flex flex-wrap gap-1.5">
                {activeActions.slice(0, isMobile && !deep ? 2 : 4).map((a) => (
                  <button
                    key={a.key}
                    type="button"
                    onClick={() => {
                      a.run();
                      if (isMobile) closeBubble();
                    }}
                    className="inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1.5 text-[12px] font-medium text-white transition-colors hover:bg-white/22"
                  >
                    <a.icon className="h-3.5 w-3.5" strokeWidth={1.9} />
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {active.kind !== "dossier" && hasDeep && isMobile && (
            <button
              type="button"
              onClick={() => setDeep((v) => !v)}
              className="mt-2 text-[11.5px] text-white/55 transition-colors hover:text-white/85"
            >
              {deep ? "Voir moins" : "+ Voir davantage"}
            </button>
          )}


          <button
            type="button"
            onClick={closeBubble}
            aria-label="Fermer l'aperçu"
            className="absolute top-2 right-2 grid h-6 w-6 place-items-center rounded-full bg-white/12 text-white/70 transition-colors hover:bg-white/25 hover:text-white"
          >
            <X className="h-3.5 w-3.5" strokeWidth={2} />
          </button>
        </div>,
        document.body,
      )}
    </div>
  );
}
