import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { CityInput } from "@/components/aime/CityInput";
import { MultiSelectMenu } from "@/components/aime/MultiSelectMenu";
import { ProgressBar } from "@/components/aime/ProgressBar";
import { categoriesQuery, cardsQuery } from "@/lib/aime/queries";
import { universeIcon } from "@/lib/aime/icons";
import {
  UNIVERSE_TREE,
  categoriesForUniverses,
  dbUniversesFor,
  findUniverse,
  regionForCity,
  tagsForSubs,
} from "@/lib/aime/universeTree";
import type { Card } from "@/lib/aime/types";
import { cn } from "@/lib/utils";

/**
 * Mise en route de sa page, directement sur sa page.
 * Quatre temps, tous passables ; chaque champ enregistre en direct.
 */
export function PageSetup({ card, userId }: { card: Card; userId: string }) {
  const qc = useQueryClient();
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: cards = [] } = useQuery(cardsQuery);

  const [name, setName] = useState(card.name);
  const [headline, setHeadline] = useState(card.headline ?? "");
  const [city, setCity] = useState(card.city ?? "");
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setName(card.name);
    setHeadline(card.headline ?? "");
    setCity(card.city ?? "");
  }, [card.id, card.name, card.headline, card.city]);

  const save = useMutation({
    mutationFn: async (patch: Partial<Card>) => {
      const { error } = await supabase
        .from("cards")
        .update(patch as never)
        .eq("id", card.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["card", card.id] });
      qc.invalidateQueries({ queryKey: ["my-card"] });
      qc.invalidateQueries({ queryKey: ["my-cards"] });
      qc.invalidateQueries({ queryKey: ["cards"] });
    },
    onError: (e) => toast("Enregistrement impossible : " + (e as Error).message),
  });
  const busy = save.isPending;


  const parents = useMemo(
    () =>
      UNIVERSE_TREE.filter((u) => u.db.some((d) => card.universes.includes(d))).map((u) => u.slug),
    [card.universes],
  );

  const subOptions = useMemo(
    () =>
      parents.flatMap((p) =>
        (findUniverse(p)?.subs ?? []).map((s) => ({
          value: `${p}:${s.slug}`,
          label: s.label,
        })),
      ),
    [parents],
  );

  const chosenSubs = useMemo(
    () =>
      subOptions.filter((o) => card.tags.includes(o.value.split(":")[1] ?? "")).map((o) => o.value),
    [subOptions, card.tags],
  );

  const categoryOptions = useMemo(() => {
    const allowed = new Set(categoriesForUniverses(parents));
    const list = categories.filter((c) => allowed.size === 0 || allowed.has(c.slug));
    return (list.length > 0 ? list : categories).map((c) => ({ value: c.slug, label: c.label }));
  }, [categories, parents]);

  const citySuggestions = useMemo(() => {
    const counts = new Map<string, number>();
    for (const c of cards) if (c.city) counts.set(c.city, (counts.get(c.city) ?? 0) + 1);
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([city, count]) => ({ city, count }));
  }, [cards]);

  const steps = [
    {
      key: "identite",
      done: card.name.trim().length > 2 && (card.headline ?? "").trim().length > 4,
    },
    { key: "photo", done: !!card.image_url },
    { key: "activite", done: card.universes.length > 0 && card.category_slug !== "personne" },
    { key: "lieu", done: !!card.city },
  ];
  const done = steps.filter((s) => s.done).length;
  const percent = Math.round((done / steps.length) * 100);

  const toggleUniverse = (slug: string) => {
    const next = parents.includes(slug) ? parents.filter((p) => p !== slug) : [...parents, slug];
    save.mutate({ universes: dbUniversesFor(next, chosenSubs) } as Partial<Card>);
  };

  const toggleSub = (value: string) => {
    const next = chosenSubs.includes(value)
      ? chosenSubs.filter((s) => s !== value)
      : [...chosenSubs, value];
    save.mutate({ tags: tagsForSubs(next) } as Partial<Card>);
  };

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const path = `${userId}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage.from("cartes").upload(path, file, { upsert: true });
      if (error) throw error;
      const { data, error: signErr } = await supabase.storage
        .from("cartes")
        .createSignedUrl(path, 60 * 60 * 24 * 365 * 5);
      if (signErr) throw signErr;
      save.mutate({ image_url: data.signedUrl } as Partial<Card>);
      toast("Photo ajoutée");
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <div className="mb-5">
        <ProgressBar value={percent} />
        <p className="mt-2 text-[13px] text-muted-foreground">
          Votre page est remplie à {percent} %.{" "}
          {busy ? "Enregistrement…" : "Chaque champ s'enregistre tout seul."}
        </p>
      </div>


      <div className="space-y-6">
            {/* 1 — Qui / quoi */}
            <Step index={1} label="Qui vous êtes" done={steps[0]?.done ?? false}>
              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() =>
                    name.trim() &&
                    name !== card.name &&
                    save.mutate({ name: name.trim() } as Partial<Card>)
                  }
                  placeholder="Votre nom"
                  className="w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] outline-none"
                />
                <input
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  onBlur={() =>
                    headline !== (card.headline ?? "") &&
                    save.mutate({ headline: headline.trim() } as Partial<Card>)
                  }
                  placeholder="Une phrase qui vous résume"
                  className="w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] outline-none"
                />
              </div>
            </Step>

            {/* 2 — Photo */}
            <Step index={2} label="Votre photo" done={steps[1]?.done ?? false}>
              <div className="flex items-center gap-3">
                {card.image_url && (
                  <img
                    src={card.image_url}
                    alt={card.name}
                    className="h-14 w-14 rounded-2xl object-cover"
                  />
                )}
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void upload(f);
                  }}
                />
                <button
                  type="button"
                  disabled={uploading}
                  onClick={() => fileRef.current?.click()}
                  className={cn(
                    "flex items-center gap-2 rounded-full hairline bg-background px-4 py-2.5 text-[13px]",
                    uploading && "opacity-50",
                  )}
                >
                  <Camera className="h-4 w-4" strokeWidth={1.75} />
                  {card.image_url ? "Changer la photo" : "Ajouter une photo"}
                </button>
              </div>
            </Step>

            {/* 3 — Activité */}
            <Step index={3} label="Ce que vous faites" done={steps[2]?.done ?? false}>
              <div className="flex flex-wrap gap-2">
                {UNIVERSE_TREE.map((u) => {
                  const Icon = universeIcon(u.slug);
                  const active = parents.includes(u.slug);
                  return (
                    <button
                      key={u.slug}
                      type="button"
                      disabled={busy}
                      aria-pressed={active}
                      onClick={() => toggleUniverse(u.slug)}
                      className={cn(
                        "flex min-h-11 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] transition-colors",
                        active
                          ? "bg-foreground text-background"
                          : "hairline bg-background hover:bg-accent",
                        busy && "opacity-60",
                      )}
                    >

                      <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                      {u.label}
                    </button>
                  );
                })}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <MultiSelectMenu
                  label="Activité"
                  placeholder="Votre métier"
                  options={categoryOptions}
                  selected={[card.category_slug]}
                  onToggle={(value) => save.mutate({ category_slug: value } as Partial<Card>)}
                />
                {subOptions.length > 0 && (
                  <MultiSelectMenu
                    label="Domaines"
                    placeholder="Vos domaines"
                    options={subOptions}
                    selected={chosenSubs}
                    onToggle={toggleSub}
                  />
                )}
              </div>
            </Step>

            {/* 4 — Où */}
            <Step index={4} label="Où vous êtes" done={steps[3]?.done ?? false}>
              <CityInput
                value={city}
                onChange={(next) => {
                  setCity(next);
                  save.mutate({ city: next, region: regionForCity(next) } as Partial<Card>);
                }}
                suggestions={citySuggestions}
                className="max-w-sm"
              />
              <p className="mt-2 text-[13px] text-muted-foreground">
                Le reste — disponibilités, repères, projets — se remplit directement sur la ligne de
                temps ci-dessus.
              </p>
            </Step>

            {!card.published && percent >= 75 && (
              <button
                type="button"
                onClick={() => {
                  save.mutate({ published: true } as Partial<Card>);
                  toast("Votre page est visible sur le réseau");
                }}
                className="rounded-full bg-primary px-5 py-2.5 text-[14px] font-medium text-primary-foreground"
              >
                Publier ma page
              </button>
            )}
      </div>
    </div>
  );
}

function Step({
  index,
  label,
  done,
  children,
}: {
  index: number;
  label: string;
  done: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="flex items-center gap-2">
        <span
          className={cn(
            "grid h-5 w-5 place-items-center rounded-full text-[11px]",
            done ? "bg-foreground text-background" : "hairline bg-background text-muted-foreground",
          )}
        >
          {done ? <Check className="h-3 w-3" strokeWidth={2.5} /> : index}
        </span>
        <span className="text-[13px] font-medium">{label}</span>
      </div>
      <div className="mt-3">{children}</div>
    </div>
  );
}
