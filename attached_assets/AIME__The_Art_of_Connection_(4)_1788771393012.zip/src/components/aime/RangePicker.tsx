import { MapPin } from "lucide-react";
import { RANGES, type RangeKey } from "@/lib/aime/proximity";
import { cn } from "@/lib/utils";

/** La barre de portée : jusqu'où on regarde autour de soi. */
export function RangePicker({
  value,
  onChange,
  city,
  className,
}: {
  value: RangeKey;
  onChange: (key: RangeKey) => void;
  city?: string | null;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <span className="inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground">
        <MapPin className="h-3.5 w-3.5" strokeWidth={1.75} />
        {city ? `Autour de ${city}` : "Portée"}
      </span>
      <div className="flex flex-wrap gap-1.5">
        {RANGES.map((r) => (
          <button
            key={r.key}
            type="button"
            onClick={() => onChange(r.key)}
            aria-pressed={value === r.key}
            className={cn(
              "rounded-full px-3 py-1.5 text-[12.5px] transition",
              value === r.key
                ? "bg-primary text-primary-foreground"
                : "hairline bg-card text-muted-foreground hover:text-foreground",
            )}
          >
            {r.label}
          </button>
        ))}
      </div>
    </div>
  );
}
