/**
 * Canal unique d'ouverture des Réglages.
 * Les réglages (accessibilité comprise) s'ouvrent depuis Mon espace.
 */
const EVENT = "aime:settings-sheet";

export function openSettings() {
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function onSettings(handler: () => void) {
  const listener = () => handler();
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
