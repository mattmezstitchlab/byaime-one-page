import { cn } from "@/lib/utils";

export type CardTabKey =
  | "presentation"
  | "savoir-faire"
  | "experiences"
  | "calendrier"
  | "avis"
  | "devis"
  | "timeline"
  | "origines"
  | "radio"
  | "contact"
  // Onglets privés : visibles uniquement sur sa propre carte
  | "projets"
  | "bureau"
  // Préréglage Mariage : la même page, des étapes d'organisation
  | "jour-j"
  | "prestataires"
  | "deroule"
  | "invites"
  | "budget"
  | "musique"
  | "documents";

export type CardTab = { key: CardTabKey; label: string };

/**
 * Navigation d'onglets sous la timeline : le hero et la règle du temps
 * restent en place, seul le contenu change. Une carte = une page unique.
 */
export function CardTabs({
  tabs,
  active,
  onChange,
  className,
}: {
  tabs: CardTab[];
  active: CardTabKey;
  onChange: (key: CardTabKey) => void;
  className?: string;
}) {
  return (
    <div
      className={cn(
        // Sous le niveau « chrome » (capsule de navigation, bouton retour) : voir src/lib/aime/layers.ts
        "sticky top-16 z-[15] border-b border-hairline bg-background/85 backdrop-blur-xl",
        className,
      )}
    >
      <div
        role="tablist"
        aria-label="Sections de la carte"
        className="mx-auto flex max-w-5xl gap-1 overflow-x-auto px-5 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {tabs.map((t) => {
          const on = t.key === active;
          return (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={on}
              onClick={() => onChange(t.key)}
              className={cn(
                "shrink-0 rounded-full px-4 py-2 text-[13.5px] whitespace-nowrap transition-colors",
                on
                  ? "bg-foreground text-background"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground",
              )}
            >
              {t.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
