import { Link } from "@tanstack/react-router";
import { Check, Eye, Hand, HandHeart, MapPin, Undo2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cardVisual } from "@/lib/aime/visuals";
import type { Reason } from "@/lib/aime/meet/convergences";
import {
  SIGNAL_LABEL,
  purposeLabel,
  type MeetProposal,
  type MeetSignal,
  type SignalKind,
} from "@/lib/aime/meet/signals";
import { ConvergenceStory } from "./ConvergenceStory";

/** Carte publique minimale : tout ce qu'il faut pour reconnaître quelqu'un. */
export type InboxCard = {
  id: string;
  owner_id?: string | null;
  name: string;
  headline: string | null;
  city: string | null;
  category_slug: string | null;
  image_url: string | null;
  universes: string[] | null;
};

/** Les raisons sont figées en base : on les relit telles qu'elles ont été envoyées. */
function readReasons(raw: unknown): Reason[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (r): r is Reason =>
      !!r && typeof r === "object" && "axis" in r && "label" in r && "weight" in r,
  );
}

function whenFr(iso: string | null) {
  if (!iso) return null;
  return new Date(iso).toLocaleString("fr-FR", {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function Identity({ card, fallback }: { card: InboxCard | null; fallback: string }) {
  return (
    <div className="flex min-w-0 flex-1 gap-3">
      {card ? (
        <img
          src={cardVisual(card)}
          alt={card.name}
          loading="lazy"
          className="h-14 w-14 shrink-0 rounded-2xl object-cover"
        />
      ) : (
        <div className="h-14 w-14 shrink-0 rounded-2xl bg-muted" />
      )}
      <div className="min-w-0 flex-1">
        <h3 className="truncate text-[15px] font-semibold tracking-[-0.01em]">
          {card?.name ?? fallback}
        </h3>
        {card?.headline ? (
          <p className="truncate text-[13px] text-muted-foreground">{card.headline}</p>
        ) : null}
        {card?.city ? (
          <p className="mt-0.5 flex items-center gap-1 text-[12px] text-muted-foreground">
            <MapPin className="h-3 w-3" /> {card.city}
          </p>
        ) : null}
      </div>
    </div>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <article className="overflow-hidden rounded-3xl border border-border bg-card p-4">
      {children}
    </article>
  );
}

/** Un signal reçu : qui, pourquoi, et que puis-je en faire. */
export function ReceivedSignalCard({
  signal,
  card,
  busy,
  onAccept,
  onDecline,
}: {
  signal: MeetSignal;
  card: InboxCard | null;
  busy: boolean;
  onAccept: () => void;
  onDecline: () => void;
}) {
  const reasons = readReasons(signal.reasons);
  const label = SIGNAL_LABEL[signal.kind as SignalKind] ?? signal.kind;
  const answered = signal.status === "accepte" || signal.status === "refuse";

  return (
    <Shell>
      <div className="flex gap-3">
        <Identity card={card} fallback="Quelqu'un sur AIME" />
        <span className="h-fit shrink-0 rounded-full border border-border px-2 py-[2px] text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
          {label}
        </span>
      </div>

      {signal.message ? (
        <p className="mt-3 rounded-2xl bg-muted/50 px-3 py-2 text-[13px] leading-snug">
          « {signal.message} »
        </p>
      ) : null}

      {reasons.length ? (
        <div className="mt-3 border-t border-border pt-3">
          <ConvergenceStory reasons={reasons} dense />
        </div>
      ) : null}

      <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">
        {card ? (
          <Button asChild variant="secondary" size="sm">
            <Link to="/rencontres/$id" params={{ id: card.id }}>
              <Eye className="mr-1.5 h-4 w-4" /> Découvrir
            </Link>
          </Button>
        ) : null}
        {answered ? (
          <p className="text-[13px] text-muted-foreground">
            {signal.status === "accepte"
              ? "Vous avez accepté — l'échange est ouvert."
              : "Vous avez décliné."}
          </p>
        ) : (
          <>
            <Button size="sm" disabled={busy} onClick={onAccept}>
              <Check className="mr-1.5 h-4 w-4" /> Accepter et répondre
            </Button>
            <Button variant="ghost" size="sm" disabled={busy} onClick={onDecline}>
              <X className="mr-1.5 h-4 w-4" /> Décliner
            </Button>
          </>
        )}
      </div>
    </Shell>
  );
}

/** Une proposition de rencontre reçue : l'objet, le lieu, le moment. */
export function ReceivedProposalCard({
  proposal,
  card,
  busy,
  onAccept,
  onDecline,
}: {
  proposal: MeetProposal;
  card: InboxCard | null;
  busy: boolean;
  onAccept: () => void;
  onDecline: () => void;
}) {
  const moment = whenFr(proposal.moment);
  const answered = proposal.status === "accepte" || proposal.status === "refuse";

  return (
    <Shell>
      <div className="flex gap-3">
        <Identity card={card} fallback="Quelqu'un sur AIME" />
        <span className="h-fit shrink-0 rounded-full border border-border px-2 py-[2px] text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
          <HandHeart className="mr-1 inline h-3 w-3" />
          {purposeLabel(proposal.purpose)}
        </span>
      </div>

      <ul className="mt-3 space-y-1 text-[13px] text-muted-foreground">
        {proposal.place ? <li>Lieu — {proposal.place}</li> : null}
        {moment ? <li>Moment — {moment}</li> : null}
      </ul>

      {proposal.message ? (
        <p className="mt-3 rounded-2xl bg-muted/50 px-3 py-2 text-[13px] leading-snug">
          « {proposal.message} »
        </p>
      ) : null}

      <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">
        {answered ? (
          <p className="text-[13px] text-muted-foreground">
            {proposal.status === "accepte" ? "Vous avez accepté." : "Vous avez décliné."}
          </p>
        ) : (
          <>
            <Button size="sm" disabled={busy} onClick={onAccept}>
              <Check className="mr-1.5 h-4 w-4" /> Accepter
            </Button>
            <Button variant="ghost" size="sm" disabled={busy} onClick={onDecline}>
              <X className="mr-1.5 h-4 w-4" /> Décliner
            </Button>
          </>
        )}
      </div>
    </Shell>
  );
}

/** Un signal que j'ai envoyé : je peux le retirer tant qu'il n'a pas été accepté. */
export function SentSignalRow({
  signal,
  card,
  busy,
  onWithdraw,
}: {
  signal: MeetSignal;
  card: InboxCard | null;
  busy: boolean;
  onWithdraw: () => void;
}) {
  const label = SIGNAL_LABEL[signal.kind as SignalKind] ?? signal.kind;
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-border bg-card px-3 py-2.5">
      <Hand className="h-4 w-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px]">{card?.name ?? "Une personne"}</p>
        <p className="text-[12px] text-muted-foreground">
          {label}
          {signal.status === "accepte" ? " · accepté" : ""}
          {signal.status === "refuse" ? " · décliné" : ""}
        </p>
      </div>
      <Button variant="ghost" size="sm" disabled={busy} onClick={onWithdraw}>
        <Undo2 className="mr-1.5 h-4 w-4" /> Retirer
      </Button>
    </div>
  );
}
