import { useMemo } from "react";
import type { Convergence } from "@/lib/aime/meet/convergences";
import { cardVisual } from "@/lib/aime/visuals";

/**
 * La carte des convergences : moi au centre, le passé à gauche,
 * le présent au centre, le futur à droite. Plus c'est proche, plus nos
 * chemins se croisent.
 */
export function ConvergenceMap({
  list,
  selectedId,
  onSelect,
}: {
  list: Convergence[];
  selectedId?: string | null;
  onSelect: (c: Convergence) => void;
}) {
  const points = useMemo(() => {
    const max = Math.max(...list.map((c) => c.score), 1);
    return list.slice(0, 24).map((c, index) => {
      const past = c.reasons.filter((r) => r.axis === "passe").length;
      const future = c.reasons.filter((r) => r.axis === "futur").length;
      const bias = (future - past) / Math.max(1, future + past + 1);
      const near = 1 - c.score / (max * 1.3);
      const angle = (index / Math.max(1, Math.min(list.length, 24))) * Math.PI * 2;
      const radius = 14 + near * 32;
      return {
        c,
        x: 50 + Math.cos(angle) * radius + bias * 18,
        y: 50 + Math.sin(angle) * radius * 0.7,
      };
    });
  }, [list]);

  return (
    <div className="relative aspect-[16/10] w-full overflow-hidden rounded-3xl border border-border bg-muted/30">
      <div className="pointer-events-none absolute inset-0 flex items-center justify-between px-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        <span>Passé</span>
        <span>Futur</span>
      </div>
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {points.map(({ c, x, y }) => (
          <line
            key={c.userId}
            x1={50}
            y1={50}
            x2={x}
            y2={y}
            stroke="currentColor"
            strokeWidth={0.2}
            className="text-border"
          />
        ))}
      </svg>
      <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 rounded-full border border-foreground/30 bg-background px-3 py-1 text-[11px] uppercase tracking-[0.2em]">
        Moi
      </div>
      {points.map(({ c, x, y }) => (
        <button
          key={c.userId}
          type="button"
          onClick={() => onSelect(c)}
          style={{ left: `${x}%`, top: `${y}%` }}
          className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border transition ${
            selectedId === c.userId ? "border-foreground ring-2 ring-foreground/30" : "border-border"
          }`}
          title={`${c.card.name} — ${c.reasons.length} convergences`}
        >
          <img
            src={cardVisual(c.card)}
            alt={c.card.name}
            loading="lazy"
            className="h-9 w-9 rounded-full object-cover"
          />
        </button>
      ))}
      {!list.length ? (
        <p className="absolute inset-x-0 bottom-4 text-center text-[12px] text-muted-foreground">
          Personne à afficher pour l'instant.
        </p>
      ) : null}
    </div>
  );
}
