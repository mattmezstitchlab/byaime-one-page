import { Link } from "@tanstack/react-router";
import { Bookmark, Eye, HandHeart, Hand, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cardVisual } from "@/lib/aime/visuals";
import type { Convergence } from "@/lib/aime/meet/convergences";
import { intentLabel } from "@/lib/aime/meet/prefs";
import { ConvergenceStory } from "./ConvergenceStory";

/** La carte de rencontre : qui, où, et pourquoi cette personne apparaît. */
export function MeetCard({
  item,
  state,
  onHello,
  onKeep,
  onFollow,
  onPropose,
}: {
  item: Convergence;
  state?: string | null;
  onHello: () => void;
  onKeep: () => void;
  onFollow: () => void;
  onPropose: () => void;
}) {
  const canContact = item.prefs.contact_policy !== "personne";
  return (
    <article className="overflow-hidden rounded-3xl border border-border bg-card">
      <div className="flex gap-4 p-4">
        <img
          src={cardVisual(item.card)}
          alt={item.card.name}
          loading="lazy"
          className="h-20 w-20 shrink-0 rounded-2xl object-cover"
        />
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-[16px] font-semibold tracking-[-0.01em]">{item.card.name}</h3>
          <p className="truncate text-[13px] text-muted-foreground">
            {item.card.headline || item.card.category_slug}
          </p>
          <p className="mt-1 text-[12px] text-muted-foreground">
            {item.card.city ?? "Ville non précisée"}
            {item.km != null ? ` · ${item.km} km` : ""}
          </p>
          {item.intents.length ? (
            <div className="mt-2 flex flex-wrap gap-1">
              {item.intents.slice(0, 3).map((key) => (
                <span
                  key={key}
                  className="rounded-full border border-border px-2 py-[2px] text-[10px] uppercase tracking-[0.12em] text-muted-foreground"
                >
                  {intentLabel(key)}
                </span>
              ))}
            </div>
          ) : null}
        </div>
      </div>

      <div className="border-t border-border px-4 py-3">
        <ConvergenceStory reasons={item.reasons} dense />
      </div>

      <div className="flex flex-wrap gap-2 border-t border-border px-4 py-3">
        <Button asChild variant="secondary" size="sm">
          <Link to="/rencontres/$id" params={{ id: item.card.id }}>
            <Eye className="mr-1.5 h-4 w-4" /> Découvrir
          </Link>
        </Button>
        {canContact ? (
          <Button size="sm" onClick={onHello} disabled={state === "bonjour"}>
            <Hand className="mr-1.5 h-4 w-4" /> {state === "bonjour" ? "Bonjour envoyé" : "Dire bonjour"}
          </Button>
        ) : null}
        <Button variant="ghost" size="sm" onClick={onKeep} disabled={state === "garde"}>
          <Bookmark className="mr-1.5 h-4 w-4" /> Garder
        </Button>
        <Button variant="ghost" size="sm" onClick={onFollow} disabled={state === "suivi"}>
          <UserPlus className="mr-1.5 h-4 w-4" /> Suivre
        </Button>
        {canContact ? (
          <Button variant="ghost" size="sm" onClick={onPropose}>
            <HandHeart className="mr-1.5 h-4 w-4" /> Proposer
          </Button>
        ) : null}
      </div>
    </article>
  );
}
