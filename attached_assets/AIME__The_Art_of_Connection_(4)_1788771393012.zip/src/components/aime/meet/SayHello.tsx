import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { Convergence } from "@/lib/aime/meet/convergences";
import { ConvergenceStory } from "./ConvergenceStory";

/** Un signal léger : « bonjour », avec un mot si on veut. */
export function SayHello({
  item,
  open,
  onOpenChange,
  onSend,
}: {
  item: Convergence | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSend: (message: string) => Promise<void> | void;
}) {
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Dire bonjour à {item.card.name}</DialogTitle>
          <DialogDescription>
            Un signal léger. La personne voit pourquoi vos chemins se croisent et décide si elle
            répond.
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-2xl border border-border p-3">
          <ConvergenceStory reasons={item.reasons} />
        </div>
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          maxLength={280}
          placeholder="Un mot, si vous le souhaitez (facultatif)."
        />
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await onSend(message);
                setMessage("");
                onOpenChange(false);
              } finally {
                setBusy(false);
              }
            }}
          >
            Envoyer le bonjour
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
