import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  CONTACT_POLICIES,
  MEET_INTENTS,
  MEET_RANGES,
  saveMeetPrefs,
  type MeetPrefs,
} from "@/lib/aime/meet/prefs";

/** Vie privée et contrôle : ce que je cherche, jusqu'où, qui peut me parler. */
export function MeetPrefsPanel({
  userId,
  cardId,
  prefs,
}: {
  userId: string;
  cardId: string | null;
  prefs: MeetPrefs | null;
}) {
  const qc = useQueryClient();
  const [visible, setVisible] = useState(prefs?.visible ?? false);
  const [intents, setIntents] = useState<string[]>(prefs?.intents ?? ["collaboration", "projet"]);
  const [rangeKey, setRangeKey] = useState(prefs?.range_key ?? "100");
  const [policy, setPolicy] = useState(prefs?.contact_policy ?? "convergents");
  const [sharePosition, setSharePosition] = useState(prefs?.share_position ?? false);

  useEffect(() => {
    if (!prefs) return;
    setVisible(prefs.visible);
    setIntents(prefs.intents ?? []);
    setRangeKey(prefs.range_key);
    setPolicy(prefs.contact_policy);
    setSharePosition(prefs.share_position);
  }, [prefs]);

  const save = useMutation({
    mutationFn: () =>
      saveMeetPrefs({
        userId,
        cardId,
        visible,
        intents,
        rangeKey,
        contactPolicy: policy,
        sharePosition,
      }),
    onSuccess: async () => {
      toast.success("Vos choix de rencontre sont enregistrés.");
      await qc.invalidateQueries({ queryKey: ["meet-prefs"] });
      await qc.invalidateQueries({ queryKey: ["meet-pool"] });
    },
    onError: () => toast.error("Impossible d'enregistrer pour l'instant."),
  });

  return (
    <div className="space-y-5 rounded-3xl border border-border bg-card p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-[15px] font-semibold">Ma présence dans Rencontres</h2>
          <p className="text-[13px] text-muted-foreground">
            Tant que ceci est fermé, personne ne vous voit ici.
          </p>
        </div>
        <Switch checked={visible} onCheckedChange={setVisible} aria-label="Être visible" />
      </div>

      <div>
        <Label className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">
          Ce que je cherche
        </Label>
        <div className="mt-2 flex flex-wrap gap-2">
          {MEET_INTENTS.map((intent) => {
            const on = intents.includes(intent.key);
            return (
              <button
                key={intent.key}
                type="button"
                onClick={() =>
                  setIntents((prev) =>
                    prev.includes(intent.key) ? prev.filter((k) => k !== intent.key) : [...prev, intent.key],
                  )
                }
                className={`rounded-full border px-3 py-1 text-[13px] transition ${
                  on ? "border-foreground bg-foreground text-background" : "border-border"
                }`}
              >
                {intent.label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <Label className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Jusqu'où</Label>
        <div className="mt-2 flex flex-wrap gap-2">
          {MEET_RANGES.map((r) => (
            <button
              key={r.key}
              type="button"
              onClick={() => setRangeKey(r.key)}
              className={`rounded-full border px-3 py-1 text-[13px] transition ${
                rangeKey === r.key ? "border-foreground bg-foreground text-background" : "border-border"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <Label className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">
          Qui peut me contacter
        </Label>
        <div className="mt-2 flex flex-wrap gap-2">
          {CONTACT_POLICIES.map((p) => (
            <button
              key={p.key}
              type="button"
              onClick={() => setPolicy(p.key)}
              className={`rounded-full border px-3 py-1 text-[13px] transition ${
                policy === p.key ? "border-foreground bg-foreground text-background" : "border-border"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-[14px]">Partager ma position précise</p>
          <p className="text-[13px] text-muted-foreground">
            Facultatif. Sans cela, tout fonctionne à l'échelle de la ville.
          </p>
        </div>
        <Switch checked={sharePosition} onCheckedChange={setSharePosition} aria-label="Partager ma position" />
      </div>

      <Button onClick={() => save.mutate()} disabled={save.isPending}>
        Enregistrer mes choix
      </Button>
    </div>
  );
}
