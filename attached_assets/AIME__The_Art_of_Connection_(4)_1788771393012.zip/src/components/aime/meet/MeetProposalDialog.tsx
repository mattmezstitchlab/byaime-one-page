import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PROPOSAL_PURPOSES } from "@/lib/aime/meet/signals";
import type { Convergence } from "@/lib/aime/meet/convergences";

/** Proposer une rencontre : pourquoi, où, quand. Rien n'est inscrit sans accord. */
export function MeetProposalDialog({
  item,
  open,
  onOpenChange,
  onSend,
}: {
  item: Convergence | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSend: (input: { purpose: string; place: string; moment: string; message: string }) => Promise<void> | void;
}) {
  const [purpose, setPurpose] = useState<string>("faire-connaissance");
  const [place, setPlace] = useState("");
  const [moment, setMoment] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Proposer une rencontre à {item.card.name}</DialogTitle>
          <DialogDescription>
            La rencontre ne devient un moment de votre ligne de temps que si vous l'inscrivez tous les
            deux, plus tard.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div>
            <Label className="text-[12px] uppercase tracking-[0.14em] text-muted-foreground">Pourquoi</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              {PROPOSAL_PURPOSES.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => setPurpose(p.key)}
                  className={`rounded-full border px-3 py-1 text-[13px] transition ${
                    purpose === p.key ? "border-foreground bg-foreground text-background" : "border-border"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label htmlFor="meet-place">Où</Label>
              <Input
                id="meet-place"
                value={place}
                onChange={(e) => setPlace(e.target.value)}
                placeholder={item.card.city ?? "Un lieu"}
              />
            </div>
            <div>
              <Label htmlFor="meet-moment">Quand</Label>
              <Input
                id="meet-moment"
                type="datetime-local"
                value={moment}
                onChange={(e) => setMoment(e.target.value)}
              />
            </div>
          </div>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            maxLength={400}
            placeholder="Un mot d'explication (facultatif)."
          />
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await onSend({ purpose, place, moment, message });
                onOpenChange(false);
              } finally {
                setBusy(false);
              }
            }}
          >
            Envoyer la proposition
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
