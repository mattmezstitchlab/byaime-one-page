import { AXIS_LABEL, reasonsByAxis, type Axis, type Reason } from "@/lib/aime/meet/convergences";

const ORDER: Axis[] = ["passe", "present", "futur"];

/** Le récit des convergences : jamais un score, toujours une raison lisible. */
export function ConvergenceStory({ reasons, dense = false }: { reasons: Reason[]; dense?: boolean }) {
  const byAxis = reasonsByAxis(reasons);
  const count = reasons.length;
  return (
    <div className="space-y-2">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        {count} point{count > 1 ? "s" : ""} de convergence
      </p>
      <ul className="space-y-1.5">
        {ORDER.flatMap((axis) =>
          (dense ? byAxis[axis].slice(0, 1) : byAxis[axis]).map((reason, index) => (
            <li key={`${axis}-${index}`} className="flex gap-2 text-[13px] leading-snug">
              <span className="mt-[2px] shrink-0 rounded-full border border-border px-2 py-[1px] text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                {AXIS_LABEL[axis]}
              </span>
              <span>{reason.label}</span>
            </li>
          )),
        )}
      </ul>
    </div>
  );
}
