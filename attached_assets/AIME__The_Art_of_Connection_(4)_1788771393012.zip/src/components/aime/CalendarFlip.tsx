import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Brush } from "lucide-react";
import { MonthCalendar } from "@/components/aime/MonthCalendar";
import { DayConsole } from "@/components/aime/DayConsole";
import { supabase } from "@/integrations/supabase/client";
import { musicboxQuery } from "@/lib/aime/queries";
import {
  AVAILABILITY_DOT,
  AVAILABILITY_LABEL,
  AVAILABILITY_STATUSES,
  monthGrid,
  toDayKey,
} from "@/lib/aime/calendar";
import { KIND_DOT, KIND_LABEL, formatSlot } from "@/lib/aime/musicbox";
import { cn } from "@/lib/utils";
import type { AimeIntent, Card } from "@/lib/aime/types";

/**
 * Bloc calendrier qui se retourne sur place : recto la grille du mois,
 * verso la console du jour. Plus aucun panneau latéral.
 */
export function CalendarFlip({
  card,
  month,
  onMonthChange,
  statusByDay,
  isOwner,
  onIntent,
}: {
  card: Card;
  month: Date;
  onMonthChange: (d: Date) => void;
  statusByDay: Map<string, string>;
  isOwner: boolean;
  onIntent: (intent: AimeIntent, message?: string) => void;
}) {
  const qc = useQueryClient();
  const [day, setDay] = useState<string | null>(null);
  const [brush, setBrush] = useState<string | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const { data: entries = [] } = useQuery(musicboxQuery({ cardId: card.id }));

  const byDay = useMemo(() => {
    const m = new Map<string, typeof entries>();
    for (const e of entries) {
      const list = m.get(e.day) ?? [];
      list.push(e);
      m.set(e.day, list);
    }
    return m;
  }, [entries]);

  const paint = useMutation({
    mutationFn: async ({ d, status }: { d: string; status: string }) => {
      const { error } = await supabase
        .from("card_availability")
        .upsert({ card_id: card.id, day: d, status }, { onConflict: "card_id,day" });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["availability"] }),
    onError: (e: Error) => toast(e.message),
  });

  const ribbon = useMemo(
    () =>
      monthGrid(month)
        .filter((d): d is Date => !!d)
        .map(toDayKey),
    [month],
  );

  const preview = hover ?? day;
  const previewStatus = preview ? statusByDay.get(preview) : undefined;
  const previewEntries = preview ? (byDay.get(preview) ?? []) : [];

  return (
    <div className="[perspective:1400px]">
      <div
        className={cn(
          "relative transition-transform duration-500 [transform-style:preserve-3d]",
          day && "[transform:rotateY(180deg)]",
        )}
      >
        {/* Recto */}
        <div className={cn("[backface-visibility:hidden]", day && "invisible")}>
          {isOwner && (
            <div className="mb-2 flex flex-wrap items-center gap-1.5">
              <Brush className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
              {AVAILABILITY_STATUSES.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setBrush(brush === s ? null : s)}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px]",
                    brush === s ? "bg-primary text-primary-foreground" : "hairline bg-card",
                  )}
                >
                  <span className={cn("h-1.5 w-1.5 rounded-full", AVAILABILITY_DOT[s])} />
                  {AVAILABILITY_LABEL[s]}
                </button>
              ))}
            </div>
          )}

          <MonthCalendar
            month={month}
            onMonthChange={onMonthChange}
            statusByDay={statusByDay}
            selectedDay={day}
            onSelectDay={(d) => setDay(d)}
            onHoverDay={setHover}
            {...(brush ? { onPaint: (d: string) => paint.mutate({ d, status: brush }) } : {})}
            countByDay={new Map([...byDay].map(([d, l]) => [d, l.length]))}
            compact
          />

          <div className="mt-2 flex gap-[3px]">
            {ribbon.map((d) => {
              const st = statusByDay.get(d);
              const kind = byDay.get(d)?.[0]?.kind;
              return (
                <span
                  key={d}
                  className={cn(
                    "h-1 flex-1 rounded-full",
                    st ? AVAILABILITY_DOT[st] : kind ? (KIND_DOT[kind] ?? "bg-muted") : "bg-muted",
                  )}
                />
              );
            })}
          </div>

          <div className="mt-2 min-h-[34px] text-[12px] text-muted-foreground">
            {preview ? (
              <>
                {previewStatus && <span>{AVAILABILITY_LABEL[previewStatus]}</span>}
                {previewEntries.slice(0, 2).map((e) => (
                  <span key={e.id} className="block truncate">
                    {formatSlot(e)} · {e.title} · {KIND_LABEL[e.kind] ?? e.kind}
                  </span>
                ))}
                {!previewStatus && previewEntries.length === 0 && (
                  <span>Rien ce jour-là. Touchez pour agir.</span>
                )}
              </>
            ) : brush ? (
              <span>Glissez sur les jours pour peindre « {AVAILABILITY_LABEL[brush]} ».</span>
            ) : (
              <span>Touchez une date : le calendrier se retourne.</span>
            )}
          </div>
        </div>

        {/* Verso */}
        {day && (
          <div className="absolute inset-0 [backface-visibility:hidden] [transform:rotateY(180deg)]">
            <DayConsole
              card={card}
              day={day}
              dayEntries={byDay.get(day) ?? []}
              onBack={() => setDay(null)}
              isOwner={isOwner}
              {...(statusByDay.get(day) ? { currentStatus: statusByDay.get(day) } : {})}
              onIntent={onIntent}
            />
          </div>
        )}
      </div>
    </div>
  );
}
