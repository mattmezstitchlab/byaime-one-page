import { useState } from "react";
import { motion } from "motion/react";
import { cn } from "@/lib/utils";
import { cardVisual } from "@/lib/aime/visuals";
import { KIND_LABEL, type AimeIntent, type Card } from "@/lib/aime/types";

import { AimeButton } from "./AimeButton";
import { CardConsole } from "./panels/CardConsole";

function priceLabel(level: number) {
  return "€".repeat(Math.max(1, Math.min(4, level)));
}

export function AimeCard({
  card,
  categoryLabel,
  liked,
  activeIntents,
  onIntent,
  className,
  priority = false,
}: {
  card: Card;
  categoryLabel?: string | undefined;
  liked: boolean;
  activeIntents: AimeIntent[];
  onIntent: (intent: AimeIntent, message?: string) => void;
  className?: string;
  priority?: boolean;
}) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div className={cn("card-3d w-full", className)}>
      <motion.div
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ type: "spring", stiffness: 180, damping: 22 }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative aspect-[3/4.35] w-full"
      >
        {/* Recto */}
        <div className="backface-hidden absolute inset-0 overflow-hidden rounded-card bg-card shadow-card hairline">
          {card.video_url ? (
            <video
              src={card.video_url}
              poster={cardVisual(card)}
              autoPlay
              muted
              loop
              playsInline
              preload={priority ? "auto" : "metadata"}
              aria-label={card.name}
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : (
            <img
              src={cardVisual(card)}
              alt={card.name}
              width={900}
              height={1200}
              loading={priority ? "eager" : "lazy"}
              className="absolute inset-0 h-full w-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-black/15" />

          <div className="absolute inset-x-0 top-0 flex items-start justify-end p-5">
            <button
              type="button"
              onClick={() => setFlipped(true)}
              aria-label="Voir le verso"
              className="text-[18px] leading-none text-white/85 transition-opacity hover:opacity-70"
            >
              ↻
            </button>
          </div>

          <div className="absolute inset-x-0 bottom-0 p-5 text-white">
            <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-white/70">
              {categoryLabel ?? KIND_LABEL[card.kind]}
            </p>
            <h3 className="mt-1.5 text-[26px] font-semibold leading-[1.05] tracking-[-0.03em]">
              {card.name}
            </h3>
            <p className="mt-1 line-clamp-2 text-[14px] text-white/80">{card.headline}</p>

            <div className="mt-4 flex items-end justify-between">
              <div className="space-y-1 text-[13px] text-white/80">
                <p>
                  {card.city ?? card.region ?? card.country} · {priceLabel(card.price_level)}
                </p>
                <p>
                  ★ {card.rating.toFixed(1)}{" "}
                  <span className="text-white/55">({card.reviews_count})</span>
                </p>
              </div>
              <AimeButton
                card={card}
                liked={liked}
                activeIntents={activeIntents}
                onIntent={onIntent}
                size="lg"
              />
            </div>
          </div>
        </div>

        {/* Verso */}
        <div
          style={{ transform: "rotateY(180deg)" }}
          className="backface-hidden absolute inset-0 overflow-hidden rounded-card bg-card p-6 shadow-card hairline"
        >
          <div className="flex h-full flex-col">
            <div className="flex items-start justify-between">
              <div>
                <p className="eyebrow">{categoryLabel ?? KIND_LABEL[card.kind]}</p>
                <h3 className="mt-1 text-2xl font-semibold tracking-[-0.03em]">{card.name}</h3>
              </div>
              <button
                type="button"
                onClick={() => setFlipped(false)}
                aria-label="Voir le recto"
                className="text-[18px] leading-none text-foreground/60 transition-opacity hover:opacity-70"
              >
                ↺
              </button>
            </div>

            <div className="mt-4 min-h-0 flex-1">
              <CardConsole card={card} />
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
