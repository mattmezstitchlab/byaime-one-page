import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";

const KEY = "aime.cookies";

export function CookieBanner() {
  const { t } = useI18n();
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Dans un aperçu intégré (démonstration de l'accueil), on ne sollicite personne.
    if (window.self !== window.top) return;
    // Léger délai : on laisse la page s'installer avant de solliciter le visiteur.
    const timer = window.setTimeout(() => {
      try {
        if (!localStorage.getItem(KEY)) setShow(true);
      } catch {
        /* stockage indisponible */
      }
    }, 1600);
    return () => window.clearTimeout(timer);
  }, []);


  const choose = (value: "all" | "essential") => {
    try {
      localStorage.setItem(KEY, value);
    } catch {
      /* stockage indisponible */
    }
    setShow(false);
  };

  if (!show) return null;

  return (
    <div
      role="dialog"
      aria-label={t("cookies.title")}
      className="fixed inset-x-3 bottom-3 z-[35] mx-auto max-w-sm rounded-3xl hairline glass-strong p-4 shadow-soft md:inset-x-auto md:left-4 md:bottom-4 md:mx-0"
    >
      <p className="text-[15px] font-medium">{t("cookies.title")}</p>
      <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
        {t("cookies.body")}{" "}
        <Link to="/legal/$doc" params={{ doc: "cookies" }} className="inline-flex min-h-11 items-center underline">
          {t("footer.cookies")}
        </Link>
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => choose("all")}
          className="inline-flex min-h-11 items-center rounded-full bg-primary px-5 text-[14px] font-medium text-primary-foreground"
        >
          {t("cookies.accept")}
        </button>
        <button
          type="button"
          onClick={() => choose("essential")}
          className="inline-flex min-h-11 items-center rounded-full hairline bg-background px-5 text-[14px]"
        >
          {t("cookies.essential")}
        </button>
      </div>
    </div>
  );
}
