import { cn } from "@/lib/utils";
import { CERTAINTY_SHAPE } from "@/lib/aime/memory/certainty";
import type { TreeNode } from "@/lib/aime/origins/tree";

/** Plein, demi, vide : la différence se voit sans lire un manuel. */
function Dot({ shape }: { shape: "plein" | "demi" | "vide" }) {
  if (shape === "plein") return <span className="h-2.5 w-2.5 rounded-full bg-foreground" />;
  if (shape === "demi")
    return (
      <span className="h-2.5 w-2.5 overflow-hidden rounded-full border border-foreground">
        <span className="block h-full w-1/2 bg-foreground" />
      </span>
    );
  return <span className="h-2.5 w-2.5 rounded-full border border-dashed border-muted-foreground" />;
}

type Placed = TreeNode & { x: number; y: number };

function place(nodes: TreeNode[], depth: number): Placed[] {
  const out: Placed[] = [];
  for (let g = 0; g <= depth; g++) {
    const row = nodes.filter((n) => n.generation === g);
    const y = depth === 0 ? 50 : 92 - (g / depth) * 84;
    row.forEach((n, i) => out.push({ ...n, x: ((i + 0.5) / row.length) * 100, y }));
  }
  return out;
}

/**
 * L'arbre des origines : les places attendues restent visibles,
 * même quand l'identité n'est pas connue.
 */
export function OriginsTree({
  nodes,
  depth = 2,
  activeSlot,
  onPick,
}: {
  nodes: TreeNode[];
  depth?: number;
  activeSlot?: string | null;
  onPick: (node: TreeNode) => void;
}) {
  const placed = place(nodes, depth);
  const bySlot = new Map(placed.map((p) => [p.slot, p]));

  return (
    <div className="relative h-[380px] w-full overflow-hidden rounded-3xl hairline bg-card p-2 shadow-soft sm:h-[420px]">
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-0 h-full w-full"
        aria-hidden="true"
      >
        {placed.map((n) => {
          const p = n.parentSlot ? bySlot.get(n.parentSlot) : null;
          if (!p) return null;
          return (
            <line
              key={`l-${n.slot}`}
              x1={n.x}
              y1={n.y}
              x2={p.x}
              y2={p.y}
              stroke="currentColor"
              strokeWidth={0.25}
              strokeDasharray={n.cardId ? undefined : "1 1.4"}
              className="text-muted-foreground/50"
            />
          );
        })}
      </svg>

      {placed.map((n) => {
        const shape = CERTAINTY_SHAPE[n.certainty];
        const on = activeSlot === n.slot;
        return (
          <button
            key={n.slot}
            type="button"
            onClick={() => onPick(n)}
            style={{ left: `${n.x}%`, top: `${n.y}%` }}
            className={cn(
              "absolute w-[27%] max-w-[180px] -translate-x-1/2 -translate-y-1/2 rounded-2xl px-2.5 py-2 text-left transition-colors sm:w-[22%]",
              n.cardId ? "hairline bg-background" : "border border-dashed border-hairline bg-background/50",
              on && "ring-2 ring-ring",
            )}
          >
            <span className="flex items-center gap-1.5">
              <Dot shape={shape} />
              <span className="truncate text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                {n.role}
              </span>
            </span>
            <span className="mt-1 block truncate text-[13.5px] font-medium">
              {n.name ?? "Identité inconnue"}
            </span>
            <span className="block truncate text-[12px] text-muted-foreground">
              {n.cardId ? (n.city ?? "Lieu non renseigné") : "À découvrir"}
            </span>
          </button>
        );
      })}
    </div>
  );
}

export default OriginsTree;
