import { Circle } from "lucide-react";
import type { OpenQuestion } from "@/lib/aime/origins/tree";

/** Ce qui reste à découvrir. AIME ne prétend pas tout savoir. */
export function OpenQuestions({
  questions,
  onExplore,
}: {
  questions: OpenQuestion[];
  onExplore: (slot: string) => void;
}) {
  if (questions.length === 0) return null;
  return (
    <div className="rounded-3xl hairline bg-card p-4 shadow-soft">
      <h3 className="text-[15px] font-medium">Votre mémoire est encore incomplète</h3>
      <ul className="mt-3 space-y-2">
        {questions.map((q, i) => (
          <li key={`${q.slot}-${i}`} className="flex items-start gap-2.5">
            <Circle className="mt-1 h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={1.5} />
            <div>
              <p className="text-[14px]">{q.label}</p>
              <p className="text-[12.5px] text-muted-foreground">{q.detail}</p>
            </div>
          </li>
        ))}
      </ul>
      <button
        type="button"
        onClick={() => onExplore(questions[0]!.slot)}
        className="mt-3 rounded-full hairline bg-background px-4 py-2 text-[13px]"
      >
        Explorer
      </button>
    </div>
  );
}

export default OpenQuestions;
