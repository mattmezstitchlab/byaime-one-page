import { Check, CircleAlert, Info } from "lucide-react";
import {
  CERTAINTY_HINT,
  CERTAINTY_LABEL,
  type Certainty,
  type EvidenceItem,
} from "@/lib/aime/memory/certainty";

/**
 * Pourquoi AIME sait — ou pourquoi il suppose.
 * Jamais un pourcentage : les éléments, un par un.
 */
export function LinkEvidence({
  certainty,
  items,
  source,
}: {
  certainty: Certainty;
  items: EvidenceItem[];
  source?: { url: string | null; title: string | null } | undefined;
}) {
  return (
    <div className="rounded-2xl hairline bg-background p-3">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
        {CERTAINTY_LABEL[certainty]}
      </p>
      <p className="mt-1 text-[13px] text-muted-foreground">{CERTAINTY_HINT[certainty]}</p>
      {items.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {items.map((it, i) => (
            <li key={`${it.label}-${i}`} className="flex items-start gap-2 text-[13px]">
              {it.ok === false ? (
                <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.75} />
              ) : it.ok ? (
                <Check className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} />
              ) : (
                <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.75} />
              )}
              <span>
                {it.label}
                {it.detail ? <span className="text-muted-foreground"> · {it.detail}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      )}
      {source?.url && (
        <a
          href={source.url}
          target="_blank"
          rel="noreferrer"
          className="mt-3 inline-block text-[13px] underline underline-offset-4"
        >
          Voir la source{source.title ? ` · ${source.title}` : ""}
        </a>
      )}
    </div>
  );
}

export default LinkEvidence;
