import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Loader2, Search, Trash2, UserPlus } from "lucide-react";
import {
  CERTAINTIES,
  CERTAINTY_LABEL,
  type Certainty,
} from "@/lib/aime/memory/certainty";
import {
  createFamilyLink,
  ensurePersonCard,
  familyLinksQuery,
  identityQuery,
  removeFamilyLink,
  updateFamilyLink,
  VISIBILITY_LABEL,
  type Relation,
  type Visibility,
} from "@/lib/aime/origins/origins";
import { buildOriginsTree, openQuestions, type TreeNode } from "@/lib/aime/origins/tree";
import {
  acceptLead,
  leadEvidence,
  leadsQuery,
  refuseLead,
  suggestedCertainty,
  type Lead,
} from "@/lib/aime/origins/leads";
import { runOriginsLeads } from "@/lib/aime/origins/leads.functions";
import { OriginsTree } from "@/components/aime/origins/OriginsTree";
import { IdentityForm } from "@/components/aime/origins/IdentityForm";
import { OpenQuestions } from "@/components/aime/origins/OpenQuestions";
import { LinkEvidence } from "@/components/aime/origins/LinkEvidence";

const inputClass =
  "w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring";

/** Une piste : lue, expliquée, puis acceptée ou écartée. Jamais enregistrée seule. */
function LeadCard({
  lead,
  cardId,
  onDone,
}: {
  lead: Lead;
  cardId: string;
  onDone: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(lead.title);
  const [certainty, setCertainty] = useState<Certainty>(suggestedCertainty(lead));
  const relation: Relation = "parent";

  const accept = useMutation({
    mutationFn: () => acceptLead(lead, { cardId, relation, certainty, name }),
    onSuccess: () => {
      toast.success("Ajouté à votre arbre, au niveau que vous avez choisi");
      onDone();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const refuse = useMutation({ mutationFn: () => refuseLead(lead.id), onSuccess: onDone });

  return (
    <li className="rounded-2xl hairline bg-card p-3">
      <p className="text-[14px] font-medium">{lead.title}</p>
      <p className="text-[12.5px] text-muted-foreground">
        {[lead.date_text, lead.place, lead.source_type].filter(Boolean).join(" · ")}
      </p>
      {lead.summary && <p className="mt-1.5 text-[13px]">{lead.summary}</p>}
      <div className="mt-2 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="rounded-full hairline bg-background px-3 py-1.5 text-[12.5px]"
        >
          {open ? "Fermer" : "Examiner"}
        </button>
        <button
          type="button"
          onClick={() => refuse.mutate()}
          className="text-[12.5px] text-muted-foreground underline underline-offset-4"
        >
          Écarter
        </button>
      </div>
      {open && (
        <div className="mt-3 space-y-3">
          <LinkEvidence
            certainty={certainty}
            items={leadEvidence(lead)}
            source={{ url: lead.source_url, title: lead.source_title }}
          />
          <div className="grid gap-2 sm:grid-cols-2">
            <label className="block">
              <span className="text-[12px] text-muted-foreground">Nom retenu</span>
              <input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
            </label>
            <label className="block">
              <span className="text-[12px] text-muted-foreground">Niveau de certitude</span>
              <select
                value={certainty}
                onChange={(e) => setCertainty(e.target.value as Certainty)}
                className={inputClass}
              >
                {CERTAINTIES.map((c) => (
                  <option key={c} value={c}>
                    {CERTAINTY_LABEL[c]}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <button
            type="button"
            onClick={() => accept.mutate()}
            disabled={accept.isPending}
            className="rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground disabled:opacity-60"
          >
            Ajouter à l'arbre
          </button>
        </div>
      )}
    </li>
  );
}

/**
 * Origines — l'arbre, ce qui est certain, ce qui est supposé,
 * et ce qui reste à découvrir. Rien n'entre sans validation humaine.
 */
export function OriginsPanel({
  cardId,
  cardName,
  cardCity,
  isOwner,
  momentsCount = 0,
}: {
  cardId: string;
  cardName: string;
  cardCity: string | null;
  isOwner: boolean;
  momentsCount?: number;
}) {
  const qc = useQueryClient();
  const identity = useQuery(identityQuery(cardId));
  const links = useQuery(familyLinksQuery(cardId));
  const leads = useQuery(leadsQuery(cardId));
  const search = useServerFn(runOriginsLeads);

  const [slot, setSlot] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  const [newCertainty, setNewCertainty] = useState<Certainty>("confirme");

  const nodes = useMemo(
    () => buildOriginsTree(cardId, cardName, cardCity, links.data ?? [], 2),
    [cardId, cardName, cardCity, links.data],
  );
  const active = nodes.find((n) => n.slot === slot) ?? null;

  const questions = useMemo(
    () =>
      openQuestions(nodes, {
        hasBirth: !!identity.data?.born_on,
        hasBirthPlace: !!identity.data?.birth_city,
        momentsCount,
      }),
    [nodes, identity.data, momentsCount],
  );

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["family-links", cardId] });
    void qc.invalidateQueries({ queryKey: ["origins-leads", cardId] });
  };

  /** Relier une personne connue : elle devient une page, jamais une donnée dupliquée. */
  const connect = useMutation({
    mutationFn: async (node: TreeNode) => {
      const parentSlotNode = nodes.find((n) => n.slot === node.parentSlot);
      if (!parentSlotNode?.cardId) throw new Error("Reliez d'abord la génération précédente.");
      const personId = await ensurePersonCard(newName);
      await createFamilyLink({
        fromCardId: parentSlotNode.cardId,
        toCardId: personId,
        relation: "parent",
        certainty: newCertainty,
        visibility: "private",
        evidence: [{ label: "Déclaré par la personne", ok: true }],
      });
    },
    onSuccess: () => {
      toast.success("Lien enregistré");
      setNewName("");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const findTraces = useMutation({
    mutationFn: async (node: TreeNode) => {
      const parentNode = nodes.find((n) => n.slot === node.parentSlot);
      return search({
        data: {
          cardId,
          name: parentNode?.name ?? cardName,
          relation: "parent" as const,
          slot: node.slot,
          ...(identity.data?.born_on ? { bornYear: identity.data.born_on.slice(0, 4) } : {}),
          ...(identity.data?.birth_city ? { birthPlace: identity.data.birth_city } : {}),
        },
      });
    },
    onSuccess: (r) => {
      toast.success(r.message);
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setCertainty = useMutation({
    mutationFn: (v: { id: string; certainty: Certainty }) =>
      updateFamilyLink(v.id, { certainty: v.certainty }),
    onSuccess: refresh,
  });
  const setVisibility = useMutation({
    mutationFn: (v: { id: string; visibility: Visibility }) =>
      updateFamilyLink(v.id, { visibility: v.visibility }),
    onSuccess: refresh,
  });
  const drop = useMutation({
    mutationFn: (id: string) => removeFamilyLink(id),
    onSuccess: () => {
      toast.success("Lien supprimé");
      setSlot(null);
      refresh();
    },
  });

  const slotLeads = (leads.data ?? []).filter((l) => (l.query ?? "").endsWith(`:${slot}`));

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold tracking-[-0.02em]">Origines</h2>
        <p className="mt-1 text-[14px] text-muted-foreground">
          Ce qui est certain, ce qui est supposé, et ce qui reste à découvrir. Une place vide n'est
          pas rien : c'est une information manquante.
        </p>
      </div>

      <OriginsTree nodes={nodes} activeSlot={slot} onPick={(n) => setSlot(n.slot)} />

      {active && (
        <div className="rounded-3xl hairline bg-card p-4 shadow-soft">
          <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            {active.role}
          </p>
          <p className="mt-1 text-[16px] font-medium">
            {active.name ?? "Information à clarifier"}
          </p>

          {active.cardId && active.slot !== "moi" && (
            <Link
              to="/carte/$id"
              params={{ id: active.cardId }}
              className="mt-1 inline-block text-[13px] underline underline-offset-4"
            >
              Découvrir sa page
            </Link>
          )}

          {active.linkId && (
            <div className="mt-3 space-y-3">
              <LinkEvidence
                certainty={active.certainty}
                items={
                  (links.data ?? []).find((l) => l.id === active.linkId)?.evidence ?? []
                }
              />
              {isOwner && (
                <div className="grid gap-2 sm:grid-cols-2">
                  <label className="block">
                    <span className="text-[12px] text-muted-foreground">Niveau de certitude</span>
                    <select
                      value={active.certainty}
                      onChange={(e) =>
                        setCertainty.mutate({
                          id: active.linkId!,
                          certainty: e.target.value as Certainty,
                        })
                      }
                      className={inputClass}
                    >
                      {CERTAINTIES.map((c) => (
                        <option key={c} value={c}>
                          {CERTAINTY_LABEL[c]}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="block">
                    <span className="text-[12px] text-muted-foreground">Qui peut voir ce lien</span>
                    <select
                      value={
                        (links.data ?? []).find((l) => l.id === active.linkId)?.visibility ??
                        "private"
                      }
                      onChange={(e) =>
                        setVisibility.mutate({
                          id: active.linkId!,
                          visibility: e.target.value as Visibility,
                        })
                      }
                      className={inputClass}
                    >
                      {(Object.keys(VISIBILITY_LABEL) as Visibility[]).map((v) => (
                        <option key={v} value={v}>
                          {VISIBILITY_LABEL[v]}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
              )}
              {isOwner && (
                <button
                  type="button"
                  onClick={() => drop.mutate(active.linkId!)}
                  className="flex items-center gap-1.5 text-[13px] text-muted-foreground underline underline-offset-4"
                >
                  <Trash2 className="h-4 w-4" strokeWidth={1.75} /> Supprimer ce lien
                </button>
              )}
            </div>
          )}

          {!active.cardId && isOwner && (
            <div className="mt-3 space-y-3">
              <p className="text-[13px] text-muted-foreground">
                Cette place existe forcément. Son identité, elle, reste à documenter.
              </p>
              <div className="grid gap-2 sm:grid-cols-2">
                <label className="block">
                  <span className="text-[12px] text-muted-foreground">Nom de la personne</span>
                  <input
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Si vous le connaissez"
                    className={inputClass}
                  />
                </label>
                <label className="block">
                  <span className="text-[12px] text-muted-foreground">Niveau de certitude</span>
                  <select
                    value={newCertainty}
                    onChange={(e) => setNewCertainty(e.target.value as Certainty)}
                    className={inputClass}
                  >
                    {CERTAINTIES.map((c) => (
                      <option key={c} value={c}>
                        {CERTAINTY_LABEL[c]}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={!newName.trim() || connect.isPending}
                  onClick={() => connect.mutate(active)}
                  className="flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground disabled:opacity-60"
                >
                  <UserPlus className="h-4 w-4" strokeWidth={1.75} /> Relier cette personne
                </button>
                <button
                  type="button"
                  disabled={findTraces.isPending}
                  onClick={() => findTraces.mutate(active)}
                  className="flex items-center gap-1.5 rounded-full hairline bg-background px-4 py-2 text-[13px] disabled:opacity-60"
                >
                  {findTraces.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.75} />
                  ) : (
                    <Search className="h-4 w-4" strokeWidth={1.75} />
                  )}
                  Rechercher des traces
                </button>
              </div>
            </div>
          )}

          {slotLeads.length > 0 && (
            <div className="mt-4">
              <p className="text-[13px] text-muted-foreground">
                {slotLeads.length} piste(s) trouvée(s). Rien n'est enregistré tant que vous n'avez
                pas décidé.
              </p>
              <ul className="mt-2 space-y-2">
                {slotLeads.map((l) => (
                  <LeadCard key={l.id} lead={l} cardId={cardId} onDone={refresh} />
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {isOwner && <IdentityForm cardId={cardId} identity={identity.data ?? null} />}
      {isOwner && <OpenQuestions questions={questions} onExplore={(s) => setSlot(s)} />}
    </div>
  );
}

export default OriginsPanel;
