import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  CERTAINTY_LABEL,
  CERTAINTIES,
  type Certainty,
} from "@/lib/aime/memory/certainty";
import {
  saveIdentity,
  VISIBILITY_LABEL,
  type CardIdentity,
  type Visibility,
} from "@/lib/aime/origins/origins";

const inputClass =
  "w-full rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring";

/** La naissance : le point d'ancrage. Chaque champ dit d'où il vient. */
export function IdentityForm({
  cardId,
  identity,
}: {
  cardId: string;
  identity: CardIdentity | null;
}) {
  const qc = useQueryClient();
  const [bornOn, setBornOn] = useState(identity?.born_on ?? "");
  const [precision, setPrecision] = useState(identity?.born_precision ?? "jour");
  const [city, setCity] = useState(identity?.birth_city ?? "");
  const [country, setCountry] = useState(identity?.birth_country ?? "");
  const [visibility, setVisibility] = useState<Visibility>(identity?.visibility ?? "private");
  const [certainty, setCertainty] = useState<Certainty>(
    (identity?.certainty?.["naissance"] as Certainty) ?? "confirme",
  );

  useEffect(() => {
    if (!identity) return;
    setBornOn(identity.born_on ?? "");
    setPrecision(identity.born_precision);
    setCity(identity.birth_city ?? "");
    setCountry(identity.birth_country ?? "");
    setVisibility(identity.visibility);
    setCertainty((identity.certainty?.["naissance"] as Certainty) ?? "confirme");
  }, [identity]);

  const save = useMutation({
    mutationFn: () =>
      saveIdentity(cardId, {
        born_on: bornOn || null,
        born_precision: precision,
        birth_city: city.trim() || null,
        birth_country: country.trim() || null,
        visibility,
        certainty: { naissance: certainty },
      }),
    onSuccess: () => {
      toast.success("Naissance enregistrée");
      void qc.invalidateQueries({ queryKey: ["card-identity", cardId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="rounded-3xl hairline bg-card p-4 shadow-soft">
      <h3 className="text-[15px] font-medium">Naissance</h3>
      <p className="mt-1 text-[13px] text-muted-foreground">
        Une date et un lieu suffisent pour ouvrir toute la recherche.
      </p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Date</span>
          <input
            type="date"
            value={bornOn}
            onChange={(e) => setBornOn(e.target.value)}
            className={inputClass}
          />
        </label>
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Précision</span>
          <select
            value={precision}
            onChange={(e) => setPrecision(e.target.value as typeof precision)}
            className={inputClass}
          >
            <option value="jour">Jour exact</option>
            <option value="mois">Mois seulement</option>
            <option value="annee">Année seulement</option>
          </select>
        </label>
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Ville</span>
          <input value={city} onChange={(e) => setCity(e.target.value)} className={inputClass} />
        </label>
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Pays</span>
          <input
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className={inputClass}
          />
        </label>
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Ce que vaut cette information</span>
          <select
            value={certainty}
            onChange={(e) => setCertainty(e.target.value as Certainty)}
            className={inputClass}
          >
            {CERTAINTIES.map((c) => (
              <option key={c} value={c}>
                {CERTAINTY_LABEL[c]}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="text-[12px] text-muted-foreground">Qui peut le voir</span>
          <select
            value={visibility}
            onChange={(e) => setVisibility(e.target.value as Visibility)}
            className={inputClass}
          >
            {(Object.keys(VISIBILITY_LABEL) as Visibility[]).map((v) => (
              <option key={v} value={v}>
                {VISIBILITY_LABEL[v]}
              </option>
            ))}
          </select>
        </label>
      </div>
      <button
        type="button"
        onClick={() => save.mutate()}
        disabled={save.isPending}
        className="mt-3 rounded-full bg-primary px-4 py-2 text-[13px] text-primary-foreground disabled:opacity-60"
      >
        Enregistrer
      </button>
    </div>
  );
}

export default IdentityForm;
