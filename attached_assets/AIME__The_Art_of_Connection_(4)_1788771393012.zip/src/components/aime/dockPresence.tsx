import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { LucideIcon } from "lucide-react";

/**
 * Une seule barre du bas, partout et toujours collée en bas.
 * Une page qui a ses propres portes (un projet : Personnes, Argent,
 * Documents, Le jour J, Veille) ne pose pas une seconde barre : elle
 * confie ses portes à la barre commune, qui les déplie vers le haut.
 */
export type DockMenuItem = {
  key: string;
  label: string;
  hint?: string;
  icon: LucideIcon;
  active?: boolean;
};

export type DockMenu = {
  label: string;
  items: DockMenuItem[];
  onPick: (key: string) => void;
};

const Ctx = createContext<{
  menu: DockMenu | null;
  register: (m: DockMenu | null) => void;
  host: boolean;
  setHost: (v: boolean) => void;
}>({ menu: null, register: () => {}, host: false, setHost: () => {} });

export function DockPresenceProvider({ children }: { children: ReactNode }) {
  const [menu, setMenu] = useState<DockMenu | null>(null);
  const [host, setHost] = useState(false);
  const value = useMemo(() => ({ menu, register: setMenu, host, setHost }), [menu, host]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Lu par la barre commune : les portes de la page en cours. */
export function useDockMenu() {
  return useContext(Ctx).menu;
}

/** La barre commune se signale : les pages n'ont plus à poser la leur. */
export function useDockHost() {
  const { setHost } = useContext(Ctx);
  useEffect(() => {
    setHost(true);
    return () => setHost(false);
  }, [setHost]);
}

/** Vrai quand la barre commune est là (elle ne l'est pas dans la démo). */
export function useDockHostPresent() {
  return useContext(Ctx).host;
}

/** Une page confie ses portes à la barre commune. */
export function useRegisterDockMenu(menu: DockMenu) {
  const { register } = useContext(Ctx);
  const latest = useRef(menu);
  latest.current = menu;
  const signature = `${menu.label}|${menu.items
    .map((i) => `${i.key}${i.active ? "*" : ""}`)
    .join(",")}`;

  useEffect(() => {
    register({
      label: latest.current.label,
      items: latest.current.items,
      onPick: (key) => latest.current.onPick(key),
    });
    return () => register(null);
  }, [register, signature]);
}
