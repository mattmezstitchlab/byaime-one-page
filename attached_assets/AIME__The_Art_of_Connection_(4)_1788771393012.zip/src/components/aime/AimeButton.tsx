import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Check, ChevronDown, Heart, Loader2 } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { createDraftQuote } from "@/lib/aime/quotes";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ensureThread, sendMessage } from "@/lib/aime/messaging";
import {
  availabilityQuery,
  compositionsQuery,
  eventsQuery,
  paymentsQuery,
} from "@/lib/aime/queries";
import { actionsForCard, DEFAULT_ACTIONS, type CardAction } from "@/lib/aime/cardActions";
import { intentInTense, useTense } from "@/lib/aime/tense";
import type { AimeIntent, Card } from "@/lib/aime/types";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

type Props = {
  liked: boolean;
  activeIntents?: AimeIntent[];
  onIntent: (intent: AimeIntent, message?: string) => void;
  card?: Card | null;
  size?: "sm" | "md" | "lg";
  withLabel?: boolean;
  className?: string;
  side?: "top" | "bottom" | "left" | "right";
  align?: "start" | "center" | "end";
};

const inputCls =
  "w-full rounded-2xl hairline bg-background px-3 py-2 text-[13px] outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-ring";
const primaryCls =
  "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-4 py-2 text-[13px] font-medium text-primary-foreground transition-opacity disabled:opacity-40";

function today() {
  return new Date().toISOString().slice(0, 10);
}

export function AimeButton({
  liked,
  activeIntents = [],
  onIntent,
  card = null,
  size = "md",
  withLabel = false,
  className,
  side = "bottom",
  align = "end",
}: Props) {
  const [open, setOpen] = useState(false);
  const [burst, setBurst] = useState(0);
  const [expanded, setExpanded] = useState<string | null>(null);
  const { userId } = useAuth();
  const qc = useQueryClient();

  const isOwn = !!card?.owner_id && card.owner_id === userId;
  const all = card ? actionsForCard(card.kind, isOwn) : DEFAULT_ACTIONS;
  const { tense } = useTense();
  /** Un seul menu, sans bandeau : ce qui parle au temps courant remonte, c'est tout. */
  const actions = [
    ...all.filter((a) => intentInTense(a.intent, tense)),
    ...all.filter((a) => !intentInTense(a.intent, tense)),
  ];


  const dims =
    size === "sm"
      ? "h-9 w-9 text-[15px]"
      : size === "lg"
        ? "h-14 w-14 text-2xl"
        : "h-11 w-11 text-lg";

  const close = () => {
    setExpanded(null);
    setOpen(false);
  };

  const fireInstant = (intent: AimeIntent, message?: string) => {
    setBurst((b) => b + 1);
    onIntent(intent, message);
    close();
  };

  const clickAction = (a: CardAction) => {
    if (!a.panel) {
      if (a.intent) fireInstant(a.intent);
      return;
    }
    setExpanded((e) => (e === a.key ? null : a.key));
  };

  return (
    <Popover
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) setExpanded(null);
      }}
    >
      <div className={cn("flex items-center gap-2", className)}>
        <PopoverTrigger asChild>
          <motion.button
            type="button"
            aria-label="AIME"
            whileTap={{ scale: 0.88 }}
            transition={{ type: "spring", stiffness: 520, damping: 24 }}
            onDoubleClick={(e) => {
              e.preventDefault();
              fireInstant("aime");
            }}
            className={cn(
              "relative grid place-items-center rounded-full hairline glass-strong shadow-soft transition-colors",
              dims,
              liked ? "text-aime" : "text-foreground/70 hover:text-foreground",
            )}
          >
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.span
                key={liked ? `full-${burst}` : `empty-${burst}`}
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.6, opacity: 0 }}
                transition={{ type: "spring", stiffness: 460, damping: 18 }}
                className="leading-none"
              >
                <Heart
                  className={cn(size === "sm" ? "h-4 w-4" : size === "lg" ? "h-6 w-6" : "h-5 w-5")}
                  strokeWidth={1.75}
                  fill={liked ? "currentColor" : "none"}
                />
              </motion.span>
            </AnimatePresence>
            {liked && (
              <motion.span
                key={`ring-${burst}`}
                initial={{ scale: 0.7, opacity: 0.5 }}
                animate={{ scale: 1.9, opacity: 0 }}
                transition={{ duration: 0.7, ease: "easeOut" }}
                className="pointer-events-none absolute inset-0 rounded-full border border-aime"
              />
            )}
          </motion.button>
        </PopoverTrigger>
        {withLabel && <span className="eyebrow text-foreground/80">AIME</span>}
      </div>

      <PopoverContent
        side={side}
        align={align}
        sideOffset={12}
        className="z-[90] max-h-[70vh] w-80 overflow-y-auto rounded-3xl border-hairline glass-strong p-2 shadow-lift"
      >
        <div className="px-3 pb-1 pt-2">
          <p className="eyebrow">
            {isOwn ? "Ma page" : card ? `Agir sur ${card.name}` : "Votre intention"}
          </p>
        </div>

        <div className="flex flex-col">
          {actions.map((a) => {
            const active = a.intent ? activeIntents.includes(a.intent) : false;
            const isOpen = expanded === a.key;
            const Icon = a.icon;
            return (
              <div key={a.key}>
                <button
                  type="button"
                  onClick={() => clickAction(a)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors",
                    isOpen || active ? "bg-accent" : "hover:bg-accent/60",
                  )}
                >

                  <Icon
                    className="h-[18px] w-[18px] shrink-0 text-foreground/70"
                    strokeWidth={1.75}
                  />
                  <span className="flex-1">
                    <span className="block text-[14px] font-medium">{a.label}</span>
                    <span className="block text-[12px] text-muted-foreground">{a.hint}</span>
                  </span>
                  {active && <span className="text-aime">●</span>}
                  {a.panel && (
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform",
                        isOpen && "rotate-180",
                      )}
                      strokeWidth={1.75}
                    />
                  )}
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.18, ease: "easeOut" }}
                      className="overflow-hidden"
                    >
                      <div className="px-3 pb-3 pt-1">
                        <ActionPanel
                          action={a}
                          card={card}
                          userId={userId}
                          onIntent={onIntent}
                          onDone={() => {
                            qc.invalidateQueries();
                            close();
                          }}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}

/* ------------------------------------------------------------------ */
/* Panneaux dépliables                                                 */
/* ------------------------------------------------------------------ */

type PanelProps = {
  action: CardAction;
  card: Card | null;
  userId: string | null;
  onIntent: (intent: AimeIntent, message?: string) => void;
  onDone: () => void;
};

function ActionPanel(props: PanelProps) {
  const { action, card, userId } = props;
  if (action.panel === "own") return <OwnPanel card={card} />;
  if (!card) return <p className="text-[12px] text-muted-foreground">Carte indisponible.</p>;
  if (!userId)
    return (
      <p className="text-[12px] text-muted-foreground">
        <Link to="/auth" className="underline">
          Connectez-vous
        </Link>{" "}
        pour agir sur cette carte.
      </p>
    );

  switch (action.panel) {
    case "contact":
      return <ContactPanel {...props} card={card} userId={userId} />;
    case "reserve":
      return <ReservePanel {...props} card={card} userId={userId} />;
    case "associate":
      return <AssociatePanel {...props} card={card} userId={userId} />;
    case "quote":
      return <QuotePanel {...props} card={card} userId={userId} />;
    case "pay":
      return <PayPanel {...props} card={card} userId={userId} />;
    case "recommend":
      return <RecommendPanel {...props} card={card} userId={userId} />;
    case "invite":
      return <InvitePanel {...props} card={card} userId={userId} />;
    default:
      return null;
  }
}

type Ready = PanelProps & { card: Card; userId: string };

function useSubmit(fn: () => Promise<void>, onDone: () => void) {
  const [busy, setBusy] = useState(false);
  const run = async () => {
    if (busy) return;
    setBusy(true);
    try {
      await fn();
      onDone();
    } catch (e) {
      toast((e as Error).message || "Action impossible");
    } finally {
      setBusy(false);
    }
  };
  return { busy, run };
}

function SubmitButton({
  busy,
  label,
  disabled,
}: {
  busy: boolean;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button type="submit" className={primaryCls} disabled={busy || disabled}>
      {busy ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Check className="h-4 w-4" strokeWidth={2} />
      )}
      {label}
    </button>
  );
}

function OwnPanel({ card }: { card: Card | null }) {
  if (!card) return null;
  return (
    <div className="flex flex-wrap gap-2">
      <Link to="/mon-espace" hash="ma-page" className="rounded-full hairline px-3 py-1.5 text-[12px]">
        Modifier
      </Link>
      <Link
        to="/carte/$id"
        params={{ id: card.id }}
        search={{ onglet: "timeline" as const }}
        className="rounded-full hairline px-3 py-1.5 text-[12px]"
      >
        Timeline
      </Link>
      <Link
        to="/carte/$id"
        params={{ id: card.id }}
        search={{ onglet: "devis" as const }}
        className="rounded-full hairline px-3 py-1.5 text-[12px]"
      >
        Tarifs
      </Link>
      <button
        type="button"
        className="rounded-full hairline px-3 py-1.5 text-[12px]"
        onClick={() => {
          void navigator.clipboard?.writeText(`${window.location.origin}/carte/${card.id}`);
          toast("Lien copié");
        }}
      >
        Copier le lien
      </button>
    </div>
  );
}

function ContactPanel({ card, userId, onIntent, onDone, action }: Ready) {
  const [body, setBody] = useState("");
  const { busy, run } = useSubmit(async () => {
    if (!card.owner_id) throw new Error("Cette carte n'a pas encore de membre rattaché.");
    if (!body.trim()) throw new Error("Écrivez un mot avant d'envoyer.");
    const threadId = await ensureThread({
      me: userId,
      other: card.owner_id,
      cardId: card.id,
      subject: card.name,
    });
    await sendMessage(threadId, userId, body.trim());
    if (action.intent) onIntent(action.intent, body.trim());
    toast("Message envoyé");
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={3}
        placeholder="Un mot pour accompagner votre intention…"
        className={cn(inputCls, "resize-none")}
      />
      <SubmitButton busy={busy} label="Envoyer" disabled={!body.trim()} />
    </form>
  );
}

function ReservePanel({ card, onIntent, onDone, action, userId }: Ready) {
  const [day, setDay] = useState(today());
  const [note, setNote] = useState("");
  const { data: slots = [] } = useQuery(availabilityQuery([card.id]));

  const free = useMemo(
    () => slots.filter((s) => s.status === "disponible" && s.day >= today()).slice(0, 6),
    [slots],
  );

  const { busy, run } = useSubmit(async () => {
    const { error } = await supabase.from("aimes").insert({
      user_id: userId,
      card_id: card.id,
      intent: action.intent ?? "reserver",
      requested_date: day,
      message: note.trim() || null,
    });
    if (error) throw error;
    if (card.owner_id) {
      const threadId = await ensureThread({
        me: userId,
        other: card.owner_id,
        cardId: card.id,
        subject: card.name,
      });
      await sendMessage(
        threadId,
        userId,
        `${action.label} — date souhaitée : ${day}${note.trim() ? ` · ${note.trim()}` : ""}`,
      );
    }
    toast(`Demande envoyée pour le ${day}`);
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      {free.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {free.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setDay(s.day)}
              className={cn(
                "rounded-full px-2.5 py-1 text-[11px] transition-colors",
                day === s.day ? "bg-primary text-primary-foreground" : "hairline",
              )}
            >
              {new Date(s.day).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}
            </button>
          ))}
        </div>
      )}
      <input
        type="date"
        value={day}
        min={today()}
        onChange={(e) => setDay(e.target.value)}
        className={inputCls}
      />
      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Précision (horaire, lieu…)"
        className={inputCls}
      />
      <SubmitButton busy={busy} label="Demander cette date" />
    </form>
  );
}

function AssociatePanel({ card, userId, onIntent, onDone }: Ready) {
  const { data: compositions = [] } = useQuery(compositionsQuery(userId));
  const [selected, setSelected] = useState<string>("");
  const [title, setTitle] = useState("");

  const { busy, run } = useSubmit(async () => {
    let compositionId = selected;
    if (!compositionId) {
      if (!title.trim()) throw new Error("Nommez la nouvelle composition.");
      const { data, error } = await supabase
        .from("compositions")
        .insert({ user_id: userId, title: title.trim() })
        .select("id")
        .single();
      if (error) throw error;
      compositionId = data.id;
    }
    const { error } = await supabase.from("composition_items").insert({
      composition_id: compositionId,
      card_id: card.id,
      slot_label: card.category_slug,
      position: 0,
    });
    if (error) throw error;
    onIntent("associer");
    toast("Ajouté à la composition");
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      <div className="space-y-1">
        {compositions.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setSelected(c.id === selected ? "" : c.id)}
            className={cn(
              "block w-full rounded-2xl px-3 py-2 text-left text-[13px] transition-colors",
              selected === c.id ? "bg-primary text-primary-foreground" : "hairline",
            )}
          >
            {c.title}
          </button>
        ))}
      </div>
      {!selected && (
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Nouvelle composition…"
          className={inputCls}
        />
      )}
      <SubmitButton busy={busy} label="Ajouter" />
    </form>
  );
}

function QuotePanel({ card, userId, onDone }: Ready) {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(today());
  const { busy, run } = useSubmit(async () => {
    await createDraftQuote({
      userId,
      cardId: card.id,
      cardName: card.name,
      title,
      targetDate: date,
    });
    toast("Demande de devis envoyée");
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Prestation souhaitée"
        className={inputCls}
      />
      <input
        type="date"
        value={date}
        min={today()}
        onChange={(e) => setDate(e.target.value)}
        className={inputCls}
      />
      <div className="flex items-center gap-2">
        <SubmitButton busy={busy} label="Demander un devis" />
        <Link
          to="/carte/$id"
          params={{ id: card.id }}
          search={{ onglet: "devis" as const }}
          className="rounded-full hairline px-3 py-1.5 text-[12px]"
        >
          Voir la grille
        </Link>
      </div>
    </form>
  );
}

function PayPanel({ card, userId, onDone }: Ready) {
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const [eventId, setEventId] = useState<string>("");
  const { data: payments = [] } = useQuery(paymentsQuery(eventId));

  const due = payments.filter((p) => p.status !== "paye" && (!p.card_id || p.card_id === card.id));

  const pay = async (id: string, amount: number) => {
    const { error } = await supabase
      .from("event_payments")
      .update({ status: "paye", amount_paid: amount, paid_at: new Date().toISOString() })
      .eq("id", id);
    if (error) {
      toast(error.message);
      return;
    }
    toast("Part réglée");
    onDone();
  };

  return (
    <div className="space-y-2">
      <select value={eventId} onChange={(e) => setEventId(e.target.value)} className={inputCls}>
        <option value="">Choisir un événement…</option>
        {events.map((e) => (
          <option key={e.id} value={e.id}>
            {e.title}
          </option>
        ))}
      </select>
      {eventId && due.length === 0 && (
        <p className="text-[12px] text-muted-foreground">Aucune part à régler pour cette carte.</p>
      )}
      {due.map((p) => (
        <div
          key={p.id}
          className="flex items-center justify-between gap-2 rounded-2xl hairline px-3 py-2"
        >
          <span className="text-[12px]">
            {p.label} · {p.payer_name}
          </span>
          <button
            type="button"
            onClick={() => void pay(p.id, p.amount_due)}
            className="rounded-full bg-primary px-3 py-1 text-[12px] text-primary-foreground"
          >
            {(p.amount_due / 100).toFixed(0)} € · Payer
          </button>
        </div>
      ))}
      <p className="text-[11px] text-muted-foreground">
        Suivi de règlement. L'encaissement par carte bancaire demande l'activation des paiements.
      </p>
    </div>
  );
}

function RecommendPanel({ card, onIntent, onDone }: Ready) {
  const [to, setTo] = useState("");
  const { busy, run } = useSubmit(async () => {
    if (!to.trim()) throw new Error("Indiquez à qui la recommander.");
    onIntent("recommander", `Recommandée à ${to.trim()}`);
    if (navigator.share) {
      try {
        await navigator.share({
          title: card.name,
          url: `${window.location.origin}/carte/${card.id}`,
        });
      } catch {
        /* partage annulé */
      }
    }
    toast("Recommandation enregistrée");
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      <input
        value={to}
        onChange={(e) => setTo(e.target.value)}
        placeholder="À qui ? (nom ou e-mail)"
        className={inputCls}
      />
      <SubmitButton busy={busy} label="Envoyer la recommandation" />
    </form>
  );
}

function InvitePanel({ card, userId, onDone }: Ready) {
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const [eventId, setEventId] = useState("");
  const [role, setRole] = useState("");

  const { busy, run } = useSubmit(async () => {
    if (!eventId) throw new Error("Choisissez un événement.");
    const { error } = await supabase.from("event_participants").insert({
      event_id: eventId,
      card_id: card.id,
      role_label: role.trim() || card.category_slug,
      status: "invite",
    });
    if (error) throw error;
    toast("Invitation ajoutée à l'événement");
  }, onDone);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void run();
      }}
      className="space-y-2"
    >
      <select value={eventId} onChange={(e) => setEventId(e.target.value)} className={inputCls}>
        <option value="">Choisir un événement…</option>
        {events.map((e) => (
          <option key={e.id} value={e.id}>
            {e.title}
          </option>
        ))}
      </select>
      <input
        value={role}
        onChange={(e) => setRole(e.target.value)}
        placeholder="Rôle (facultatif)"
        className={inputCls}
      />
      <SubmitButton busy={busy} label="Inviter" />
    </form>
  );
}
