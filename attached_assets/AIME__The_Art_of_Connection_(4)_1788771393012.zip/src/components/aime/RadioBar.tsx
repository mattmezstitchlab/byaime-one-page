import { useState } from "react";
import { Heart, Music4, Pause, Play, Radio, SkipForward, Speech, Sparkles, X } from "lucide-react";
import { useRadio } from "@/components/aime/RadioProvider";
import { KIND_LABEL } from "@/lib/aime/musicbox";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { eventsQuery } from "@/lib/aime/queries";
import { AnnonceDialog } from "@/components/aime/play/AnnonceDialog";

/**
 * Écoute discrète : le son accompagne la navigation, rien de plus.
 * La narration et le récit appartiennent au bouton Play de la ligne de temps.
 */
export function RadioBar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { on, toggle, current, skip, mode, setMode, post, projectId, setProject, projectTitle } =
    useRadio();
  const [annonce, setAnnonce] = useState(false);
  const { userId } = useAuth();
  const { data: events = [] } = useQuery({ ...eventsQuery(userId), enabled: !!userId });

  const title =
    mode === "projet"
      ? (projectTitle ?? "Un projet")
      : mode === "fil"
        ? (post?.card?.name ?? "Le fil")
        : (current?.title ?? "Radio AIME");
  const detail =
    mode === "projet"
      ? "le projet raconté"
      : mode === "fil"
        ? "le fil raconté"
        : (current?.artist ??
          (current ? (KIND_LABEL[current.kind] ?? current.kind) : "au hasard des playlists"));

  return (
    <div className={cn("min-w-0", open ? "flex" : "hidden")}>
      <div className="flex min-w-0 items-center gap-1.5 rounded-full hairline bg-card/95 px-2 py-1.5 shadow-soft backdrop-blur md:gap-2 md:px-2.5">
        <button
          type="button"
          onClick={toggle}
          aria-label={on ? "Couper l'écoute" : "Lancer l'écoute"}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-foreground text-background"
        >
          {on ? (
            <Pause className="h-3.5 w-3.5" strokeWidth={2} />
          ) : (
            <Play className="h-3.5 w-3.5" strokeWidth={2} />
          )}
        </button>

        <span className="flex shrink-0 items-center gap-0.5 rounded-full bg-secondary/70 p-0.5">
          {(
            [
              { key: "musique" as const, label: "Musique", icon: Music4 },
              { key: "fil" as const, label: "Le fil raconté", icon: Speech },
              { key: "projet" as const, label: "Un projet raconté", icon: Sparkles },
            ]
          ).map((m) => {
            const Icon = m.icon;
            return (
              <button
                key={m.key}
                type="button"
                onClick={() => {
                  if (m.key === "projet") {
                    const first = projectId ?? events[0]?.id;
                    if (!first) {
                      setMode("projet");
                      return;
                    }
                    setProject(first);
                    return;
                  }
                  setMode(m.key);
                }}
                aria-pressed={mode === m.key}
                aria-label={m.label}
                title={m.label}
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full transition-colors",
                  mode === m.key
                    ? "bg-foreground text-background"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            );
          })}
        </span>

        <span className="flex min-w-0 items-center gap-1.5 pr-1">
          <Radio className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={1.75} />
          <span className="max-w-[42vw] truncate text-[13px] md:max-w-[280px]">
            {title}
            <span className="text-muted-foreground"> · {detail}</span>
          </span>
        </span>

        {mode === "projet" && events.length > 0 && (
          <select
            value={projectId ?? ""}
            onChange={(e) => setProject(e.target.value)}
            aria-label="Projet raconté"
            className="max-w-[28vw] shrink-0 rounded-full bg-secondary/70 px-2 py-1 text-[12px] md:max-w-[160px]"
          >
            {events.map((e) => (
              <option key={e.id} value={e.id}>
                {e.title}
              </option>
            ))}
          </select>
        )}

        {userId && (
          <button
            type="button"
            onClick={() => setAnnonce(true)}
            aria-label="Passer une annonce ou laisser un vocal"
            title="Passer une annonce ou laisser un vocal"
            className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-rose-500"
          >
            <Heart className="h-3.5 w-3.5" strokeWidth={1.75} />
          </button>
        )}

        {on && (
          <button
            type="button"
            onClick={skip}
            aria-label="Titre suivant"
            className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground"
          >
            <SkipForward className="h-3.5 w-3.5" strokeWidth={1.75} />
          </button>
        )}

        <button
          type="button"
          onClick={onClose}
          aria-label="Masquer l'écoute"
          className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground"
        >
          <X className="h-3.5 w-3.5" strokeWidth={1.75} />
        </button>
      </div>
      <AnnonceDialog open={annonce} onOpenChange={setAnnonce} projectId={projectId} />
    </div>
  );
}
