import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { documentsQuery, foldersQuery } from "@/lib/bureau/queries";
import { bureauContextQuery } from "@/lib/bureau/context";
import { projectMoney } from "@/lib/bureau/project";
import { euros } from "@/lib/bureau/logic";

/**
 * Les quatre chiffres du projet, lisibles sans ouvrir de tiroir :
 * même source que les documents, simplement posée sur la page.
 */
export function ProjectMoneyStrip({ eventId }: { eventId: string }) {
  const { userId } = useAuth();
  const { data: folders = [] } = useQuery(foldersQuery(userId));
  const { data: docs = [] } = useQuery(documentsQuery(userId));
  const { data: ctx } = useQuery(bureauContextQuery(userId));

  const money = useMemo(() => {
    if (!ctx) return null;
    return projectMoney(
      folders.filter((f) => f.event_id === eventId),
      docs,
      ctx.quotes.filter((q) => q.event_id === eventId),
      ctx.payments.filter((p) => p.event_id === eventId),
    );
  }, [ctx, folders, docs, eventId]);

  if (!userId || !money) return null;

  const stats: [string, string][] = [
    ["Prévu", euros(money.planned)],
    ["Facturé", euros(money.invoiced)],
    ["Payé", euros(money.paid)],
    ["Reste", euros(money.remaining)],
  ];

  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {stats.map(([label, value]) => (
        <div key={label} className="rounded-2xl hairline bg-card p-4">
          <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
          <p className="mt-1.5 text-[18px] tabular-nums tracking-[-0.02em]">{value}</p>
        </div>
      ))}
    </div>
  );
}
