/**
 * Canal unique d'ouverture des Échanges.
 * Les messages sont une fonction globale : une seule porte, depuis l'en-tête.
 */
const EVENT = "aime:messages-sheet";

export type MessagesTab = "discussions" | "documents";

export type MessagesRequest = {
  threadId: string | null;
  tab: MessagesTab | null;
  /** Projet à mettre en avant dans les documents. */
  eventId?: string | null;
};

export function openMessages(threadId?: string, tab?: MessagesTab, eventId?: string) {
  window.dispatchEvent(
    new CustomEvent<MessagesRequest>(EVENT, {
      detail: { threadId: threadId ?? null, tab: tab ?? null, eventId: eventId ?? null },
    }),
  );
}

/** Raccourci : ouvrir la bibliothèque, éventuellement sur le dossier d'un projet. */
export function openDocuments(eventId?: string) {
  openMessages(undefined, "documents", eventId);
}


export function onMessages(handler: (request: MessagesRequest) => void) {
  const listener = (event: Event) => {
    const detail = (event as CustomEvent).detail as MessagesRequest | string | null;
    if (detail && typeof detail === "object") handler(detail);
    else handler({ threadId: (detail as string | null) ?? null, tab: null });
  };
  window.addEventListener(EVENT, listener);
  return () => window.removeEventListener(EVENT, listener);
}
