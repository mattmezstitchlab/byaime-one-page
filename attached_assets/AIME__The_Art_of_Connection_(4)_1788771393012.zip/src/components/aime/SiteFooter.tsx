import { Link } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { FOOTER_LEGAL } from "@/lib/aime/navigation";

/**
 * Pied de page réduit : uniquement les mentions réglementaires.
 * La navigation vit dans le header et le menu AIME.
 */
export function SiteFooter() {
  const { t } = useI18n();

  return (
    <footer className="border-t border-white/10 bg-neutral-950 text-white">
      <div className="mx-auto max-w-6xl px-5 py-8">
        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-[13px] text-white/60">
          {FOOTER_LEGAL.map((l) => (
            <Link
              key={l.doc}
              to="/legal/$doc"
              params={{ doc: l.doc }}
              className="inline-flex min-h-11 items-center transition-colors hover:text-white"
            >
              {t(l.key)}
            </Link>
          ))}
        </nav>

        <p className="mt-6 border-t border-white/10 pt-5 text-[12px] text-white/45">
          © {new Date().getFullYear()} AIME — Édité en France.
        </p>
      </div>
    </footer>
  );
}
