import { Link } from "@tanstack/react-router";
import { SkipForward, X } from "lucide-react";
import { useRadio } from "@/components/aime/RadioProvider";
import { ago } from "@/lib/aime/feed";
import { youtubeEmbed, youtubeId } from "@/lib/aime/media";

/**
 * La scène du fil raconté : la publication en cours, l'onde de la voix,
 * et le média qui prend le relais quand la phrase est finie.
 */
export function RadioStage() {
  const { on, mode, post, speaking, youtube, skip, toggle } = useRadio();
  if (!on || mode !== "fil" || !post) return null;

  const embed = youtube ? youtubeEmbed(`https://youtu.be/${youtube}`) : null;
  const photo = post.media_url && !youtubeId(post.media_url) ? post.media_url : null;

  return (
    <div className="fixed right-4 top-[108px] z-[62] w-[min(22rem,calc(100vw-2rem))]">
      <div className="overflow-hidden rounded-3xl hairline bg-card/95 shadow-soft backdrop-blur">
        {embed ? (
          <iframe
            key={embed}
            src={`${embed}?autoplay=1&rel=0`}
            title="Média de la publication"
            allow="autoplay; encrypted-media"
            className="aspect-video w-full"
          />
        ) : photo ? (
          <img src={photo} alt="" className="aspect-video w-full object-cover" />
        ) : null}

        <div className="p-3">
          <div className="flex items-center justify-between gap-2">
            <Link to="/fil" className="min-w-0 truncate text-[13px] font-medium hover:underline">
              {post.card?.name ?? "Le fil"}
              <span className="text-muted-foreground"> · {ago(post.created_at)}</span>
            </Link>
            <div className="flex shrink-0 items-center gap-1">
              <button
                type="button"
                onClick={skip}
                aria-label="Publication suivante"
                className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
              >
                <SkipForward className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
              <button
                type="button"
                onClick={toggle}
                aria-label="Couper l'écoute"
                className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>
          </div>

          {post.body && (
            <p className="mt-1.5 line-clamp-4 text-[13px] leading-relaxed text-muted-foreground">
              {post.body}
            </p>
          )}

          <div className="mt-2 flex items-end gap-[3px]" aria-hidden>
            {[0, 1, 2, 3, 4, 5, 6].map((i) => (
              <span
                key={i}
                className={`w-[3px] rounded-full bg-foreground/70 ${speaking ? "animate-pulse" : ""}`}
                style={{
                  height: speaking ? `${6 + ((i * 7) % 16)}px` : "3px",
                  animationDelay: `${i * 90}ms`,
                  transition: "height 200ms ease",
                }}
              />
            ))}
            <span className="ml-2 text-[11px] text-muted-foreground">
              {speaking ? "L'animatrice raconte…" : "Écoute du média"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
