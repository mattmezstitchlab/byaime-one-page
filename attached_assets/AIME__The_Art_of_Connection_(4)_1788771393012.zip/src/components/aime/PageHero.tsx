import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Hauteur unique et fixe des heroes du site. Non négociable :
 * aucune page n'utilise de hauteur en vh ni le ratio natif du média.
 */
export const HERO_HEIGHT = "h-[340px] md:h-[560px]";

type Props = {
  /** Petit surtitre en capitales (nom de la section). */
  eyebrow?: string;
  /** Titre de la page, centré en bas du visuel. */
  title: ReactNode;
  /** Baseline courte sous le titre. */
  subtitle?: ReactNode;
  /** Média de fond : image ou vidéo. */
  media: { type: "image" | "video"; src: string; poster?: string };

  alt: string;
  /** Contenu optionnel sous le titre (champ Aime, actions…). */
  children?: ReactNode;
  /** Hauteur du bloc de texte : "bottom" (défaut) ou "raised" (remonté). */
  align?: "bottom" | "raised";
  /** Espace réservé en bas quand un bloc flottant vient se poser sur le hero. */
  overlap?: "none" | "third";
  className?: string;
};

/**
 * Hero unique du site : même hauteur fixe, même voile, même position de titre
 * sur toutes les pages. La hauteur ne dépend jamais du viewport ni du ratio du média.
 */
export function PageHero({
  eyebrow,
  title,
  subtitle,
  media,
  alt,
  children,
  align = "bottom",
  overlap = "none",
  className,
}: Props) {
  return (
    <section
      className={cn(
        "relative -mt-16 left-1/2 w-screen -translate-x-1/2 overflow-hidden",
        HERO_HEIGHT,
        className,
      )}
    >
      {media.type === "video" ? (
        <video
          src={media.src}
          {...(media.poster ? { poster: media.poster } : {})}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          aria-label={alt}
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
      ) : (
        <img
          src={media.src}
          alt={alt}
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
      )}

      <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-foreground/25" />

      <div
        className={cn(
          "absolute inset-x-0 bottom-0 mx-auto max-w-6xl p-5 pt-20 text-center md:p-10 md:pt-28",
          align === "raised" && "pb-10 md:pb-24",
          overlap === "third" && "pb-[110px] md:pb-[210px]",
        )}
      >
        {eyebrow && (
          <p className="text-[11px] tracking-[0.2em] text-background/80 uppercase md:text-[12px]">
            {eyebrow}
          </p>
        )}
        <h1 className="mx-auto mt-2 max-w-2xl text-[28px] font-semibold leading-tight tracking-[-0.035em] text-background md:text-5xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mx-auto mt-3 max-w-xl text-[15px] leading-relaxed text-background/85">
            {subtitle}
          </p>
        )}
        {children && <div className="mx-auto mt-6 w-full max-w-xl">{children}</div>}
      </div>
    </section>
  );
}
