import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CalendarDays,
  Heart,
  LogOut,
  MapPin,
  Eye,
  Pencil,
  Settings2,
  Sparkles,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { onSpace } from "@/components/aime/spaceSheet";
import { NotificationsList } from "@/components/aime/space/NotificationsList";
import { MyFollowsList } from "@/components/aime/social/FollowsDialog";
import { openSettings } from "@/components/aime/settingsSheet";
import { openEditPage } from "@/components/aime/page/pageSheet";
import { openAi } from "@/components/aime/panels/aiSheet";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import {
  cardsQuery,
  compositionsQuery,
  eventsQuery,
  myCardQuery,
  myQuotesQuery,
  receivedAimesQuery,
  threadsQuery,
} from "@/lib/aime/queries";
import { documentsQuery, foldersQuery } from "@/lib/bureau/queries";
import { pageCompletion } from "@/components/aime/PageCompletion";
import { actionsForEvent, buildSpaceActions, type SpaceAction } from "@/lib/aime/space/actions";
import { cn } from "@/lib/utils";

const DOT: Record<SpaceAction["tone"], string> = {
  orange: "bg-amber-500",
  bleu: "bg-sky-500",
  vert: "bg-emerald-500",
};

/**
 * Mon espace : un panneau, pas une page.
 * Chaque ligne porte son point de couleur et son chemin d'un clic.
 */
export function SpaceSheet() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [pending, setPending] = useState<SpaceAction | null>(null);
  const { user, userId } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => onSpace(() => setOpen((v) => !v)), []);

  const { data: myCard } = useQuery(myCardQuery(userId));
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: events = [] } = useQuery(eventsQuery(userId));
  const { data: aimes = [] } = useQuery(receivedAimesQuery(myCard?.id));
  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const { data: quotes = [] } = useQuery(myQuotesQuery(userId));
  const { data: docs = [] } = useQuery(documentsQuery(userId));
  const { data: folders = [] } = useQuery(foldersQuery(userId));
  /* Les équipes déjà composées : la page /equipe/$id existait sans porte. */
  const { data: teams = [] } = useQuery(compositionsQuery(userId));

  const actions = useMemo(
    () =>
      userId
        ? buildSpaceActions({ userId, myCard, cards, quotes, docs, folders, aimes, threads })
        : [],
    [userId, myCard, cards, quotes, docs, folders, aimes, threads],
  );

  const myEvents = useMemo(() => events.filter((e) => e.owner_id === userId), [events, userId]);

  const run = async (action: SpaceAction) => {
    setPending(null);
    setBusy(action.id);
    try {
      const message = await action.run();
      toast(message);
      qc.invalidateQueries();
    } catch (e) {
      toast((e as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-xl">
        <SheetHeader className="border-b border-hairline px-5 py-4 text-left">
          <SheetTitle className="text-[20px] font-semibold">Mon espace</SheetTitle>
          <p className="mt-1 text-[13.5px] text-muted-foreground">
            Tout ce qui vous concerne est ici : vos projets, vos messages, votre page, vos échanges
            avec AIME et vos réglages.
          </p>
        </SheetHeader>

        {open && (
          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
            {/* Une seule file : les chemins d'un clic, puis les nouveautés. */}
            <section>
              <h3 className="text-[15px] font-semibold">Ce qui vous attend</h3>
              {actions.length === 0 ? (
                <p className="mt-2 text-[13.5px] text-muted-foreground">
                  Rien ne vous attend. Tout est à jour.
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {actions.map((a) => (
                    <li key={a.id} className="rounded-2xl hairline bg-card p-3.5 shadow-soft">
                      <div className="flex items-start gap-2.5">
                        <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", DOT[a.tone])} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[14.5px] font-medium">{a.title}</p>
                          <p className="mt-0.5 text-[13px] text-muted-foreground">{a.detail}</p>
                        </div>
                      </div>

                      {pending?.id === a.id ? (
                        <div className="mt-3 rounded-xl bg-muted p-3">
                          <p className="text-[13.5px]">{a.confirm}</p>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => void run(a)}
                              className="rounded-full bg-foreground px-3.5 py-1.5 text-[12.5px] font-medium text-background"
                            >
                              Oui, faire
                            </button>
                            <button
                              type="button"
                              onClick={() => setPending(null)}
                              className="rounded-full hairline bg-background px-3.5 py-1.5 text-[12.5px]"
                            >
                              Annuler
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={busy === a.id}
                          onClick={() => setPending(a)}
                          className="mt-3 rounded-full hairline bg-background px-3.5 py-1.5 text-[12.5px] font-medium disabled:opacity-50"
                        >
                          {busy === a.id ? "En cours…" : a.label}
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
              <div className="mt-6">
                <NotificationsList
                  onGo={(url) => {
                    setOpen(false);
                    void navigate({ to: url });
                  }}
                />
              </div>
            </section>

            {/* Mes mondes */}
            <section className="mt-8">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="text-[15px] font-semibold">Mes mondes</h3>
                <Link
                  to="/"
                  onClick={() => setOpen(false)}
                  className="text-[13px] underline underline-offset-4"
                >
                  Ouvrir un nouveau monde
                </Link>
              </div>
              {myEvents.length === 0 ? (
                <p className="mt-2 text-[13.5px] text-muted-foreground">
                  Aucun monde pour l'instant. Racontez votre projet depuis l'accueil.
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {myEvents.map((e) => {
                    const todo = actionsForEvent(actions, e.id).length;
                    return (
                      <li key={e.id} className="rounded-2xl hairline bg-card p-3.5 shadow-soft">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="flex items-center gap-2 truncate text-[15px] font-medium">
                              {todo > 0 && (
                                <span className="h-2 w-2 shrink-0 rounded-full bg-amber-500" />
                              )}
                              {e.title}
                            </p>
                            <p className="mt-1 flex flex-wrap items-center gap-2 text-[12.5px] text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <CalendarDays className="h-3.5 w-3.5" strokeWidth={1.75} />
                                {e.starts_at
                                  ? new Date(e.starts_at).toLocaleDateString("fr-FR", {
                                      day: "numeric",
                                      month: "long",
                                      year: "numeric",
                                      timeZone: "Europe/Paris",
                                    })
                                  : "Date à confirmer"}
                              </span>
                              {e.city && (
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3.5 w-3.5" strokeWidth={1.75} />
                                  {e.city}
                                </span>
                              )}
                            </p>
                          </div>
                          <Link
                            to="/projets/$id"
                            params={{ id: e.id }}
                            onClick={() => setOpen(false)}
                            className="shrink-0 rounded-full hairline bg-background px-3 py-1.5 text-[12.5px]"
                          >
                            Ouvrir
                          </Link>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>

            {/* Mes équipes — la page existait, il lui manquait une porte. */}
            {teams.length > 0 && (
              <section className="mt-8">
                <h3 className="text-[15px] font-semibold">Mes équipes</h3>
                <ul className="mt-3 space-y-2">
                  {teams.map((team) => (
                    <li
                      key={team.id}
                      className="flex items-center justify-between gap-3 rounded-2xl hairline bg-card p-3.5 shadow-soft"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-[15px] font-medium">{team.title}</p>
                        <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                          {(team.composition_items ?? []).length} personne
                          {(team.composition_items ?? []).length > 1 ? "s" : ""}
                        </p>
                      </div>
                      <Link
                        to="/equipe/$id"
                        params={{ id: team.id }}
                        onClick={() => setOpen(false)}
                        className="shrink-0 rounded-full hairline bg-background px-3 py-1.5 text-[12.5px]"
                      >
                        Ouvrir
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Mes abonnements */}
            <section className="mt-8">
              <h3 className="text-[15px] font-semibold">Pages que je suis</h3>
              <MyFollowsList />
            </section>

            {/* Aimes */}
            <section className="mt-8">
              <h3 className="flex items-center gap-2 text-[15px] font-semibold">
                <Heart className="h-4 w-4" strokeWidth={1.75} /> Aimes reçues
              </h3>
              {aimes.length === 0 ? (
                <p className="mt-2 text-[13.5px] text-muted-foreground">
                  Personne ne vous a encore fait signe.
                </p>
              ) : (
                <ul className="mt-3 space-y-1.5">
                  {aimes.slice(0, 8).map((a) => (
                    <li
                      key={a.id}
                      className="flex items-start justify-between gap-3 rounded-2xl hairline bg-card px-3.5 py-2.5"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-[14px] font-medium">
                          {a.author ?? "Quelqu'un"}
                          <span className="ml-2 text-[12.5px] font-normal text-muted-foreground">
                            {a.intent}
                          </span>
                        </p>
                        {a.message && (
                          <p className="mt-0.5 line-clamp-1 text-[13px] text-muted-foreground">
                            {a.message}
                          </p>
                        )}
                      </div>
                      {a.status === "nouveau" && (
                        <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-sky-500" />
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Ma page publique */}
            <section className="mt-8">
              <h3 className="text-[15px] font-semibold">Ma page publique</h3>
              <div className="mt-3 flex items-center gap-3 rounded-2xl hairline bg-card p-3.5 shadow-soft">
                <span className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full hairline bg-background">
                  {myCard?.image_url ? (
                    <img
                      src={myCard.image_url}
                      alt={myCard.name}
                      className="h-full w-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <User className="h-4 w-4" strokeWidth={1.75} />
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14.5px] font-medium">
                    {myCard?.name ?? "Votre page n'existe pas encore"}
                  </p>
                  {myCard && (
                    <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                      Remplie à {pageCompletion(myCard)} %
                    </p>
                  )}
                </div>
                {myCard && (
                  <div className="flex shrink-0 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setOpen(false);
                        openEditPage();
                      }}
                      aria-label="Modifier ma page"
                      title="Modifier ma page"
                      className="grid h-9 w-9 place-items-center rounded-full hairline bg-background"
                    >
                      <Pencil className="h-4 w-4" strokeWidth={1.75} />
                    </button>
                    <Link
                      to="/carte/$id"
                      params={{ id: myCard.id }}
                      onClick={() => setOpen(false)}
                      aria-label="Voir ma page publique"
                      title="Voir ma page publique"
                      className="grid h-9 w-9 place-items-center rounded-full hairline bg-background"
                    >
                      <Eye className="h-4 w-4" strokeWidth={1.75} />
                    </Link>
                  </div>
                )}
              </div>
            </section>

            {/* Pied : les outils personnels regroupés au même endroit. */}
            <section className="mt-8 space-y-1.5 border-t border-hairline pt-4">
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  openAi();
                }}
                className="flex w-full items-start gap-2.5 rounded-2xl px-3.5 py-2.5 text-left hover:bg-muted"
              >
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.75} />
                <span className="min-w-0">
                  <span className="block text-[14.5px] font-medium">Parler à AIME</span>
                  <span className="block text-[12.5px] text-muted-foreground">
                    L'assistant s'ouvre à droite, comme tous les panneaux.
                  </span>
                </span>
              </button>
              <button
                type="button"
                onClick={() => openSettings()}
                className="flex w-full items-center gap-2 rounded-2xl px-3.5 py-2.5 text-left text-[14.5px] hover:bg-muted"
              >
                <Settings2 className="h-4 w-4" strokeWidth={1.75} /> Réglages et accessibilité
              </button>
              {user && (
                <button
                  type="button"
                  onClick={async () => {
                    await supabase.auth.signOut();
                    setOpen(false);
                    void navigate({ to: "/" });
                  }}
                  className="flex w-full items-center gap-2 rounded-2xl px-3.5 py-2.5 text-left text-[14.5px] hover:bg-muted"
                >
                  <LogOut className="h-4 w-4" strokeWidth={1.75} /> Se déconnecter
                </button>
              )}
            </section>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
