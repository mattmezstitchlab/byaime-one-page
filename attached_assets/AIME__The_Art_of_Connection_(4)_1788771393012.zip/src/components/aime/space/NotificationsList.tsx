import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import {
  markAllRead,
  markRead,
  notificationsQuery,
  removeNotification,
  unreadCount,
} from "@/lib/aime/notifications";
import { cn } from "@/lib/utils";

function when(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Ce qui s'est passé pendant votre absence : ça reste jusqu'à lecture. */
export function NotificationsList({ onGo }: { onGo?: (url: string) => void }) {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const query = useQuery(notificationsQuery(userId));
  const list = query.data ?? [];
  const unread = unreadCount(list);

  const refresh = () => void qc.invalidateQueries({ queryKey: ["notifications"] });
  const readAll = useMutation({
    mutationFn: () => markAllRead(userId!),
    onSuccess: refresh,
  });
  const drop = useMutation({
    mutationFn: (id: string) => removeNotification(id),
    onSuccess: refresh,
  });

  if (!userId) return null;

  if (query.isLoading) {
    return <p className="text-[14px] text-muted-foreground">Chargement des nouveautés…</p>;
  }

  if (query.isError) {
    return (
      <button type="button" className="min-h-11 text-[14px] underline" onClick={() => void query.refetch()}>
        Impossible de charger les nouveautés. Réessayer
      </button>
    );
  }

  if (list.length === 0) {
    return <p className="text-[14px] text-muted-foreground">Aucune nouveauté pour le moment.</p>;
  }

  return (
    <section>
      <div className="flex items-baseline justify-between gap-3">
        <h3 className="text-[15px] font-semibold">
          Nouveautés{unread > 0 ? ` · ${unread}` : ""}
        </h3>
        {unread > 0 && (
          <button
            type="button"
            onClick={() => readAll.mutate()}
            className="text-[12.5px] underline text-muted-foreground"
          >
            Tout marquer comme lu
          </button>
        )}
      </div>
      <ul className="mt-3 space-y-2">
        {list.slice(0, 12).map((n) => (
          <li
            key={n.id}
            className={cn(
              "flex items-start gap-2.5 rounded-2xl hairline p-3.5",
              n.read_at ? "bg-card" : "bg-primary/5",
            )}
          >
            <span
              className={cn(
                "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                n.read_at ? "bg-muted-foreground/40" : "bg-primary",
              )}
            />
            <button
              type="button"
              className="min-w-0 flex-1 text-left"
              onClick={() => {
                if (!n.read_at) void markRead(n.id).then(refresh);
                if (n.url && onGo) onGo(n.url);
              }}
            >
              <p className="truncate text-[14.5px] font-medium">{n.title}</p>
              {n.body && (
                <p className="mt-0.5 line-clamp-2 text-[13px] text-muted-foreground">{n.body}</p>
              )}
              <p className="mt-0.5 text-[12px] text-muted-foreground">{when(n.created_at)}</p>
            </button>
            <button
              type="button"
              aria-label="Retirer"
              onClick={() => drop.mutate(n.id)}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" />
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
