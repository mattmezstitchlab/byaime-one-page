import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment } from "@/lib/stripe";
import { createCreditsCheckout } from "@/utils/payments.functions";

export function StripeCreditsCheckout({
  amountInCents,
  userId,
  customerEmail,
  returnUrl,
}: {
  amountInCents: number;
  userId: string;
  customerEmail?: string;
  returnUrl: string;
}) {
  const fetchClientSecret = async (): Promise<string> => {
    const result = await createCreditsCheckout({
      data: {
        amountInCents,
        userId,
        ...(customerEmail ? { customerEmail } : {}),
        returnUrl,
        environment: getStripeEnvironment(),
      },
    });
    if ("error" in result) throw new Error(result.error);
    if (!result.clientSecret) throw new Error("Le paiement n'a pas pu être ouvert.");
    return result.clientSecret;
  };

  return (
    <div id="checkout" className="overflow-hidden rounded-3xl hairline bg-card p-2">
      <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}
