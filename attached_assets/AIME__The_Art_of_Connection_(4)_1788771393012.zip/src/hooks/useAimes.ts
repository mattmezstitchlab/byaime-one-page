import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { aimesQuery } from "@/lib/aime/queries";
import { INTENT_LABEL } from "@/lib/aime/intents";
import type { AimeIntent } from "@/lib/aime/types";
import { useAuth } from "./useAuth";

export function useAimes() {
  const { userId } = useAuth();
  const qc = useQueryClient();
  const { data: aimes = [] } = useQuery(aimesQuery(userId));

  const intentsByCard = new Map<string, AimeIntent[]>();
  for (const a of aimes) {
    intentsByCard.set(a.card_id, [...(intentsByCard.get(a.card_id) ?? []), a.intent]);
  }

  const mutation = useMutation({
    mutationFn: async ({
      cardId,
      intent,
      message,
    }: {
      cardId: string;
      intent: AimeIntent;
      message?: string | undefined;
    }) => {
      if (!userId) throw new Error("auth");
      const existing = aimes.find((a) => a.card_id === cardId && a.intent === intent);
      if (existing) {
        const { error } = await supabase.from("aimes").delete().eq("id", existing.id);
        if (error) throw error;
        return { removed: true, intent };
      }
      const { error } = await supabase.from("aimes").insert({
        user_id: userId,
        card_id: cardId,
        intent,
        message: message?.trim() ? message.trim() : null,
      });
      if (error) throw error;
      return { removed: false, intent };
    },
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["aimes"] });
      qc.invalidateQueries({ queryKey: ["card-aimes"] });
      toast(res.removed ? "Intention retirée" : `${INTENT_LABEL[res.intent]} · enregistré`);
    },
    onError: (e: Error) => {
      toast(e.message === "auth" ? "Connectez-vous pour aimer une carte" : "Action impossible");
    },
  });

  return {
    userId,
    aimes,
    intentsByCard,
    hasIntent: (cardId: string, intent: AimeIntent) =>
      intentsByCard.get(cardId)?.includes(intent) ?? false,
    isLiked: (cardId: string) => (intentsByCard.get(cardId)?.length ?? 0) > 0,
    toggle: (cardId: string, intent: AimeIntent, message?: string) =>
      mutation.mutate({ cardId, intent, message }),
    pending: mutation.isPending,
  };
}
