import { useEffect, useState } from "react";

const KEY = "aime.guest";

export type GuestSession = { code: string; label: string; since: string };

export function readGuest(): GuestSession | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as GuestSession) : null;
  } catch {
    return null;
  }
}

export function startGuest(session: GuestSession) {
  window.localStorage.setItem(KEY, JSON.stringify(session));
  window.dispatchEvent(new Event("aime-guest"));
}

export function endGuest() {
  window.localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("aime-guest"));
}

/** Mode invité : lecture du registre et des rencontres sans compte. */
export function useGuest() {
  const [guest, setGuest] = useState<GuestSession | null>(null);

  useEffect(() => {
    const sync = () => setGuest(readGuest());
    sync();
    window.addEventListener("aime-guest", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("aime-guest", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  return { guest, isGuest: !!guest };
}
