import { supabase } from "@/integrations/supabase/client";
import { analyzeDocument } from "@/lib/bureau/documents.functions";
import { logUsage } from "@/lib/aime/credits";
import { recordEvent, recordError } from "@/lib/aime/telemetry";
import { docParty, guessFolderForDocument } from "@/lib/bureau/logic";
import { matchCard, matchEvent, matchQuotes, type BureauContext } from "@/lib/bureau/context";
import type { BureauFolder } from "@/lib/bureau/types";

export const INGEST_STEPS = [
  "Dépôt du fichier en lieu sûr",
  "Lecture du document",
  "Extraction des montants et des dates",
  "Classement dans le bon dossier",
];

export type IngestResult = {
  fileName: string;
  /** Une phrase lisible : ce que l'agent a compris du document. */
  understood: string;
  read: boolean;
  /** Le document créé, pour pouvoir le confirmer d'un geste. */
  documentId: string | null;
  /** Le dossier proposé : on le referme pour valider. */
  folderId: string | null;
  folderTitle: string | null;
  /** Récapitulatif structuré, ligne par ligne. */
  recap: { label: string; value: string }[];
};

async function toBase64(file: File): Promise<string> {
  const buf = new Uint8Array(await file.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 0x8000) {
    bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

/**
 * Le geste unique du Bureau : déposer un fichier, le faire lire, le classer.
 * Utilisé par le bouton « Ajouter » du Bureau et par le cœur du point zéro.
 */
export async function ingestFile({
  file,
  userId,
  folders,
  folderId = null,
  ctx = null,
  onStep,
  onSoftError,
}: {
  file: File;
  userId: string;
  folders: BureauFolder[];
  folderId?: string | null;
  ctx?: BureauContext | null;
  onStep?: (step: number | null) => void;
  onSoftError?: (message: string) => void;
}): Promise<IngestResult> {
  onStep?.(0);
  const path = `${userId}/${crypto.randomUUID()}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
  const up = await supabase.storage.from("bureau").upload(path, file, {
    contentType: file.type || "application/octet-stream",
  });
  if (up.error) throw new Error(up.error.message);

  onStep?.(1);
  let extraction: Awaited<ReturnType<typeof analyzeDocument>> | null = null;
  if (file.size < 7_000_000 && /^(image\/|application\/pdf)/.test(file.type)) {
    try {
      const base64 = await toBase64(file);
      onStep?.(2);
      extraction = await analyzeDocument({
        data: { fileName: file.name, mimeType: file.type, base64 },
      });
      await logUsage(userId, "document", file.name);
      void recordEvent({
        kind: "fonction",
        label: "Lecture d'un document",
        node: "bureau",
        userId,
      });
    } catch (err) {
      recordError(err, { node: "bureau", userId, where: "analyzeDocument" });
      onSoftError?.(err instanceof Error ? err.message : "Complète les champs à la main.");
    }
  }

  onStep?.(3);
  const draft = {
    owner_id: userId,
    folder_id: folderId ?? null,
    file_name: file.name,
    storage_path: path,
    mime_type: file.type || null,
    doc_type: extraction?.doc_type ?? "inconnu",
    direction: extraction?.direction ?? "inconnu",
    issuer: extraction?.issuer ?? null,
    counterpart: extraction?.counterpart ?? null,
    doc_number: extraction?.doc_number ?? null,
    issued_on: extraction?.issued_on ?? null,
    due_on: extraction?.due_on ?? null,
    paid_on: extraction?.paid_on ?? null,
    amount_ht: extraction?.amount_ht ?? null,
    amount_vat: extraction?.amount_vat ?? null,
    amount_ttc: extraction?.amount_ttc ?? null,
    currency: extraction?.currency ?? "EUR",
    doc_language: extraction?.doc_language ?? null,
    payment_method: extraction?.payment_method ?? null,
    purpose: extraction?.purpose ?? extraction?.summary ?? null,
    place: extraction?.place ?? null,
    confidence: extraction?.confidence ?? 0,
    uncertain_fields: extraction?.uncertain_fields ?? [],
    status: "a_verifier",
    extraction: (extraction ?? {}) as never,
  };

  // Rattachement au réel : devis, projet, lieu ou prestataire déjà présents dans AIME.
  const quoteMatch = ctx ? (matchQuotes(draft as never, ctx)[0] ?? null) : null;
  const eventMatch = ctx ? matchEvent(draft as never, ctx) : null;
  const cardMatch = ctx ? matchCard(draft as never, ctx) : null;

  if (!folderId) {
    const guess = guessFolderForDocument(draft as never, folders);
    if (guess) draft.folder_id = guess.id;
  }

  if (!draft.folder_id && (quoteMatch || eventMatch || cardMatch)) {
    const title =
      quoteMatch?.item.title ??
      eventMatch?.item.title ??
      cardMatch?.name ??
      docParty(draft as never) ??
      file.name;
    const created = await supabase
      .from("bureau_folders")
      .insert({
        owner_id: userId,
        title,
        kind: eventMatch ? "projet" : "tiers",
        card_id: quoteMatch?.item.card_id ?? cardMatch?.id ?? null,
        event_id: eventMatch?.item.id ?? quoteMatch?.item.event_id ?? null,
        counterpart: docParty(draft as never) ?? cardMatch?.name ?? null,
        expected_amount: quoteMatch?.item.total ?? null,
      })
      .select("id")
      .single();
    if (created.data) draft.folder_id = created.data.id;
  }

  const { data: inserted, error } = await supabase
    .from("bureau_documents")
    .insert(draft)
    .select("id")
    .single();
  if (error) throw new Error(error.message);

  const folderTitle = draft.folder_id
    ? ((await supabase.from("bureau_folders").select("title").eq("id", draft.folder_id).maybeSingle())
        .data?.title ?? null)
    : null;

  const money = (n: number | null | undefined) =>
    n == null ? null : `${n.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} ${draft.currency}`;

  const recap = [
    { label: "Nature", value: draft.doc_type },
    { label: "Sens", value: draft.direction },
    { label: "Émetteur", value: draft.issuer ?? "—" },
    { label: "Tiers", value: draft.counterpart ?? "—" },
    { label: "Numéro", value: draft.doc_number ?? "—" },
    { label: "Date", value: draft.issued_on ?? "—" },
    { label: "Montant TTC", value: money(draft.amount_ttc) ?? "—" },
    { label: "Dossier", value: folderTitle ?? "À classer" },
  ].filter((r) => r.value);

  onStep?.(null);
  return {
    fileName: file.name,
    read: Boolean(extraction),
    understood: extraction?.summary ?? `${file.name} déposé, à compléter à la main.`,
    documentId: inserted?.id ?? null,
    folderId: draft.folder_id ?? null,
    folderTitle,
    recap,
  };
}
