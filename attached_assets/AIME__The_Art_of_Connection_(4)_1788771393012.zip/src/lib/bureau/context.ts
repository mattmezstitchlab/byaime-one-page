import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import type { BureauDocument, BureauFolder } from "./types";

export type QuoteCtx = Database["public"]["Tables"]["quotes"]["Row"] & {
  cards: { id: string; name: string; category_slug: string; city: string | null } | null;
};
export type PaymentCtx = Database["public"]["Tables"]["event_payments"]["Row"] & {
  events: { id: string; title: string; starts_at: string } | null;
};
export type EventCtx = Database["public"]["Tables"]["events"]["Row"];
export type CardCtx = Pick<
  Database["public"]["Tables"]["cards"]["Row"],
  "id" | "name" | "kind" | "category_slug" | "city" | "universes"
>;

export type BureauContext = {
  quotes: QuoteCtx[];
  payments: PaymentCtx[];
  events: EventCtx[];
  cards: CardCtx[];
};

const EMPTY: BureauContext = { quotes: [], payments: [], events: [], cards: [] };

/**
 * Tout ce que le Bureau peut relier au réel : devis émis ou reçus, paiements de projet,
 * projets (événements) et cartes — lieux, prestataires, artistes du spectacle.
 */
export function bureauContextQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["bureau-context", userId],
    enabled: !!userId,
    queryFn: async (): Promise<BureauContext> => {
      if (!userId) return EMPTY;
      const [quotes, payments, events, cards] = await Promise.all([
        supabase
          .from("quotes")
          .select("*, cards(id, name, category_slug, city)")
          .order("created_at", { ascending: false }),
        supabase
          .from("event_payments")
          .select("*, events(id, title, starts_at)")
          .order("created_at", { ascending: false }),
        supabase.from("events").select("*").order("starts_at", { ascending: false }),
        supabase
          .from("cards")
          .select("id, name, kind, category_slug, city, universes")
          .eq("owner_id", userId),
      ]);
      return {
        quotes: (quotes.data ?? []) as QuoteCtx[],
        payments: (payments.data ?? []) as PaymentCtx[],
        events: (events.data ?? []) as EventCtx[],
        cards: (cards.data ?? []) as CardCtx[],
      };
    },
  });
}

const norm = (s: string | null | undefined) =>
  (s ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");

const sameParty = (a: string | null | undefined, b: string | null | undefined) => {
  const x = norm(a);
  const y = norm(b);
  if (!x || !y || x.length < 3 || y.length < 3) return false;
  return x === y || x.includes(y) || y.includes(x);
};

const closeAmount = (a: number | null | undefined, b: number | null | undefined) => {
  if (a == null || b == null) return false;
  if (a === b) return true;
  return Math.abs(a - b) <= Math.max(100, Math.round(a * 0.02));
};

export type CtxMatch<T> = { item: T; reason: string; confidence: number };

/** Devis réels (table quotes) qui correspondent à un document déposé. */
export function matchQuotes(doc: BureauDocument, ctx: BureauContext): CtxMatch<QuoteCtx>[] {
  const out: CtxMatch<QuoteCtx>[] = [];
  for (const q of ctx.quotes) {
    const party = sameParty(doc.counterpart, q.cards?.name) || sameParty(doc.issuer, q.cards?.name);
    const amount = closeAmount(doc.amount_ttc, q.total);
    if (!party && !amount) continue;
    const reasons = [
      party ? `même prestataire (${q.cards?.name ?? "carte"})` : null,
      doc.amount_ttc === q.total ? "montant identique au devis" : amount ? "montant proche" : null,
    ].filter(Boolean);
    out.push({
      item: q,
      reason: reasons.join(", "),
      confidence: party && amount ? 0.95 : amount ? 0.75 : 0.6,
    });
  }
  return out.sort((a, b) => b.confidence - a.confidence);
}

/** Paiements réels de projet (event_payments) qui correspondent à un document. */
export function matchPayments(doc: BureauDocument, ctx: BureauContext): CtxMatch<PaymentCtx>[] {
  const out: CtxMatch<PaymentCtx>[] = [];
  for (const p of ctx.payments) {
    const party = sameParty(doc.counterpart, p.payer_name) || sameParty(doc.issuer, p.payer_name);
    const amount =
      closeAmount(doc.amount_ttc, p.amount_due) || closeAmount(doc.amount_ttc, p.amount_paid);
    if (!party && !amount) continue;
    const reasons = [
      party ? `même personne (${p.payer_name})` : null,
      amount ? "montant qui correspond" : null,
      p.status === "paye" ? "paiement encaissé" : null,
    ].filter(Boolean);
    out.push({
      item: p,
      reason: reasons.join(", "),
      confidence: party && amount ? 0.95 : amount ? 0.7 : 0.55,
    });
  }
  return out.sort((a, b) => b.confidence - a.confidence);
}

/** Projet (événement) probable pour un document : par le devis relié, la date ou le lieu. */
export function matchEvent(doc: BureauDocument, ctx: BureauContext): CtxMatch<EventCtx> | null {
  const viaQuote = matchQuotes(doc, ctx).find((m) => m.item.event_id);
  if (viaQuote) {
    const ev = ctx.events.find((e) => e.id === viaQuote.item.event_id);
    if (ev) return { item: ev, reason: "projet du devis relié", confidence: 0.9 };
  }
  const day = doc.issued_on ? new Date(doc.issued_on).getTime() : null;
  for (const e of ctx.events) {
    if (sameParty(doc.place, e.location) || sameParty(doc.place, e.city)) {
      return { item: e, reason: `même lieu (${e.location ?? e.city})`, confidence: 0.6 };
    }
    if (day != null) {
      const start = new Date(e.starts_at).getTime();
      if (Math.abs(start - day) <= 1000 * 60 * 60 * 24 * 21) {
        return { item: e, reason: "date proche du projet", confidence: 0.5 };
      }
    }
  }
  return null;
}

/** Carte (lieu, prestataire, artiste) reconnue dans le document. */
export function matchCard(doc: BureauDocument, ctx: BureauContext): CardCtx | null {
  return (
    ctx.cards.find((c) => sameParty(doc.counterpart, c.name) || sameParty(doc.issuer, c.name)) ??
    (ctx.quotes.find((q) => sameParty(doc.counterpart, q.cards?.name))?.cards as
      CardCtx | undefined) ??
    null
  );
}

export type FolderContextSummary = {
  quotes: CtxMatch<QuoteCtx>[];
  payments: CtxMatch<PaymentCtx>[];
  events: CtxMatch<EventCtx>[];
  cardName: string | null;
  cardId: string | null;
  eventId: string | null;
  counterpart: string | null;
  expectedAmount: number | null;
  paidReal: boolean;
  quotedReal: boolean;
};

/** Ce qu'AIME sait déjà d'un dossier grâce aux devis, paiements, projets et cartes existants. */
export function folderContext(
  folder: BureauFolder,
  docs: BureauDocument[],
  ctx: BureauContext,
): FolderContextSummary {
  const quotes = new Map<string, CtxMatch<QuoteCtx>>();
  const payments = new Map<string, CtxMatch<PaymentCtx>>();
  const events = new Map<string, CtxMatch<EventCtx>>();
  let cardName: string | null = null;
  let cardId: string | null = folder.card_id;

  for (const d of docs) {
    for (const m of matchQuotes(d, ctx)) {
      const prev = quotes.get(m.item.id);
      if (!prev || prev.confidence < m.confidence) quotes.set(m.item.id, m);
    }
    for (const m of matchPayments(d, ctx)) {
      const prev = payments.get(m.item.id);
      if (!prev || prev.confidence < m.confidence) payments.set(m.item.id, m);
    }
    const e = matchEvent(d, ctx);
    if (e && !events.has(e.item.id)) events.set(e.item.id, e);
    const c = matchCard(d, ctx);
    if (c) {
      cardName ??= c.name;
      cardId ??= c.id;
    }
  }

  if (folder.card_id) {
    const own = ctx.cards.find((c) => c.id === folder.card_id);
    if (own) cardName = own.name;
  }

  const quoteList = [...quotes.values()].sort((a, b) => b.confidence - a.confidence);
  const paymentList = [...payments.values()].sort((a, b) => b.confidence - a.confidence);
  const eventList = [...events.values()].sort((a, b) => b.confidence - a.confidence);

  return {
    quotes: quoteList,
    payments: paymentList,
    events: eventList,
    cardName,
    cardId,
    eventId: folder.event_id ?? eventList[0]?.item.id ?? null,
    counterpart:
      folder.counterpart ?? cardName ?? docs.find((d) => d.counterpart)?.counterpart ?? null,
    expectedAmount: folder.expected_amount ?? quoteList[0]?.item.total ?? null,
    paidReal: paymentList.some(
      (p) => p.item.status === "paye" || (p.item.amount_paid ?? 0) >= (p.item.amount_due ?? 0),
    ),
    quotedReal: quoteList.length > 0,
  };
}
