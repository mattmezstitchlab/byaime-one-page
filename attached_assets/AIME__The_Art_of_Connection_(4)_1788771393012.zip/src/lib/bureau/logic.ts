import type { FolderContextSummary } from "./context";
import type { BureauDocument, BureauFolder, BureauLink, FolderState } from "./types";

export function euros(cents: number | null | undefined, locale = "fr-FR"): string {
  const v = (cents ?? 0) / 100;
  return v.toLocaleString(locale, {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  });
}

export type Check = {
  key: string;
  /** Clé i18n. */
  label: string;
  ok: boolean;
  /** Clé i18n. */
  hint?: string;
  count?: number;
};

/** Checklist honnête d'un dossier : ce qui est là, ce qui manque. */
export function folderChecks(
  folder: BureauFolder,
  docs: BureauDocument[],
  ctx?: FolderContextSummary | null,
): Check[] {
  const has = (t: string) => docs.some((d) => d.doc_type === t);
  const invoices = docs.filter((d) => d.doc_type === "facture");
  const paid = invoices.filter((d) => d.paid_on);
  const uncertain = docs.filter(
    (d) => d.status === "a_verifier" || (d.uncertain_fields?.length ?? 0) > 0,
  );
  const amounts = docs.filter((d) => d.amount_ttc != null);

  return [
    {
      key: "identite",
      label: "check.party",
      ok: Boolean(folder.counterpart || ctx?.cardName || docs.some((d) => d.counterpart)),
      hint: "check.party.hint",
    },
    {
      key: "engagement",
      label: "check.engagement",
      ok: has("devis") || has("contrat") || Boolean(ctx?.quotedReal),
      hint: "check.engagement.hint",
    },
    {
      key: "facture",
      label: "check.invoice",
      ok: invoices.length > 0,
      hint: "check.invoice.hint",
    },
    {
      key: "montants",
      label: "check.amounts",
      ok: amounts.length > 0 && amounts.length === docs.length,
      hint: "check.amounts.hint",
    },
    {
      key: "paiement",
      label: "check.payment",
      ok: (invoices.length > 0 && paid.length === invoices.length) || Boolean(ctx?.paidReal),
      hint: "check.payment.hint",
    },
    {
      key: "rattachement",
      label: "check.attach",
      ok: Boolean(folder.event_id || folder.card_id || ctx?.eventId || ctx?.cardId),
      hint: "check.attach.hint",
    },
    {
      key: "verification",
      label: "check.review",
      ok: uncertain.length === 0,
      hint: "check.review.hint",
      count: uncertain.length,
    },
  ];
}

export function folderScore(
  folder: BureauFolder,
  docs: BureauDocument[],
  ctx?: FolderContextSummary | null,
): number {
  const checks = folderChecks(folder, docs, ctx);
  if (docs.length === 0) return 0;
  return Math.round((checks.filter((c) => c.ok).length / checks.length) * 100);
}

export function folderState(score: number, docs: BureauDocument[]): FolderState {
  if (docs.length === 0) return "incomplet";

  if (score >= 100) return "pret";
  if (score >= 60) return "a_verifier";
  return "incomplet";
}

export function folderTotals(docs: BureauDocument[]) {
  const sum = (list: BureauDocument[], key: "amount_ht" | "amount_vat" | "amount_ttc") =>
    list.reduce((acc, d) => acc + (d[key] ?? 0), 0);
  const recettes = docs.filter((d) => d.direction === "recette");
  const depenses = docs.filter((d) => d.direction === "depense");
  return {
    recettesTtc: sum(recettes, "amount_ttc"),
    depensesTtc: sum(depenses, "amount_ttc"),
    tvaCollectee: sum(recettes, "amount_vat"),
    tvaDeductible: sum(depenses, "amount_vat"),
    solde: sum(recettes, "amount_ttc") - sum(depenses, "amount_ttc"),
  };
}

const norm = (s: string | null | undefined) =>
  (s ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");

export type Suggestion = {
  from: BureauDocument;
  to: BureauDocument;
  relation: string;
  reason: string;
  confidence: number;
};

/** Rapprochement automatique : propose des liens évidents, jamais inventés. */
export function suggestLinks(docs: BureauDocument[], links: BureauLink[]): Suggestion[] {
  const existing = new Set(
    links.map((l) => `${l.from_document_id}|${l.to_document_id}|${l.relation}`),
  );
  const out: Suggestion[] = [];

  const pairRules: { from: string; to: string; relation: string }[] = [
    { from: "devis", to: "facture", relation: "devis_facture" },
    { from: "acompte", to: "facture", relation: "acompte_facture" },
    { from: "facture", to: "paiement", relation: "facture_paiement" },
    { from: "facture", to: "recu", relation: "facture_paiement" },
    { from: "facture", to: "avoir", relation: "facture_avoir" },
  ];

  for (const rule of pairRules) {
    for (const a of docs.filter((d) => d.doc_type === rule.from)) {
      for (const b of docs.filter((d) => d.doc_type === rule.to)) {
        if (a.id === b.id) continue;
        if (existing.has(`${a.id}|${b.id}|${rule.relation}`)) continue;
        const sameParty = norm(a.counterpart) && norm(a.counterpart) === norm(b.counterpart);
        const sameAmount =
          a.amount_ttc != null && b.amount_ttc != null && a.amount_ttc === b.amount_ttc;
        const closeAmount =
          a.amount_ttc != null &&
          b.amount_ttc != null &&
          Math.abs(a.amount_ttc - b.amount_ttc) <= Math.max(100, a.amount_ttc * 0.02);
        if (!sameParty && !sameAmount) continue;
        const reasons = [
          sameParty ? "même tiers" : null,
          sameAmount ? "montant identique" : closeAmount ? "montant proche" : null,
        ].filter(Boolean);
        out.push({
          from: a,
          to: b,
          relation: rule.relation,
          reason: reasons.join(", "),
          confidence: sameParty && sameAmount ? 0.95 : sameAmount ? 0.8 : 0.6,
        });
      }
    }
  }

  return out.sort((x, y) => y.confidence - x.confidence).slice(0, 12);
}

/**
 * Le tiers d'un document, du point de vue du propriétaire du Bureau.
 * Sur une dépense, le tiers est l'émetteur de la pièce (le fournisseur) :
 * le nom « client » imprimé dessus, c'est nous.
 */
export function docParty(
  doc: Pick<BureauDocument, "direction" | "issuer" | "counterpart">,
): string | null {
  const issuer = doc.issuer?.trim() || null;
  const counterpart = doc.counterpart?.trim() || null;
  if (doc.direction === "depense") return issuer ?? counterpart;
  if (doc.direction === "recette") return counterpart ?? issuer;
  return counterpart ?? issuer;
}

export function guessFolderForDocument(doc: BureauDocument, folders: BureauFolder[]) {
  const party = norm(docParty(doc)) || norm(doc.counterpart) || norm(doc.issuer);
  if (!party) return null;
  return (
    folders.find((f) => norm(f.counterpart) === party) ??
    folders.find((f) => norm(f.title).includes(party) || party.includes(norm(f.title))) ??
    null
  );
}
