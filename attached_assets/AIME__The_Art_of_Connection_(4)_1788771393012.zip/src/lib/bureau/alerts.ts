import type { BureauDocument, BureauFolder } from "./types";

/**
 * Les repères qui pulsent dans l'arbre : ce qui manque, ce qui vient d'arriver.
 * Tout est déduit des documents eux-mêmes — aucune table supplémentaire.
 */
export type DocAlert = { level: "manque" | "nouveau"; reasons: string[] };

const SEEN_KEY = "aime.docs.seen";

export function readSeenAt(): number {
  if (typeof window === "undefined") return Date.now();
  const raw = window.localStorage.getItem(SEEN_KEY);
  const value = raw ? Number(raw) : NaN;
  return Number.isFinite(value) ? value : 0;
}

export function markSeenNow() {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(SEEN_KEY, String(Date.now()));
}

export function alertFor(doc: BureauDocument, seenAt: number): DocAlert | null {
  const reasons: string[] = [];
  if (doc.status !== "valide") {
    if (doc.amount_ttc == null) reasons.push("montant manquant");
    if (!doc.issued_on) reasons.push("date manquante");
    if (!doc.doc_type || doc.doc_type === "inconnu") reasons.push("type à préciser");
    for (const f of doc.uncertain_fields ?? []) if (!reasons.includes(f)) reasons.push(f);
  }
  if (reasons.length > 0) return { level: "manque", reasons };
  const created = doc.created_at ? new Date(doc.created_at).getTime() : 0;
  if (created > seenAt) return { level: "nouveau", reasons: ["arrivé depuis votre dernière visite"] };
  return null;
}

export function buildAlerts(docs: BureauDocument[], seenAt: number) {
  const map = new Map<string, DocAlert>();
  for (const d of docs) {
    const a = alertFor(d, seenAt);
    if (a) map.set(d.id, a);
  }
  return map;
}

/** Compte les alertes d'un dossier et de tous ses sous-dossiers. */
export function folderAlertCount(
  folderId: string,
  folders: BureauFolder[],
  docs: BureauDocument[],
  alerts: Map<string, DocAlert>,
): number {
  const ids = new Set<string>([folderId]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const f of folders) {
      if (f.parent_id && ids.has(f.parent_id) && !ids.has(f.id)) {
        ids.add(f.id);
        grew = true;
      }
    }
  }
  return docs.filter((d) => d.folder_id && ids.has(d.folder_id) && alerts.has(d.id)).length;
}

export function alertLabel(alert: DocAlert) {
  return alert.level === "nouveau"
    ? "Nouveau document depuis votre dernière visite"
    : `Il manque : ${alert.reasons.join(", ")}`;
}
