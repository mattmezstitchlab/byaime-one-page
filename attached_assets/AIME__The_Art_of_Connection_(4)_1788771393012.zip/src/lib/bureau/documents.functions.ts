import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const Input = z.object({
  fileName: z.string().min(1).max(300),
  mimeType: z.string().min(3).max(120),
  /** Contenu du fichier en base64 (sans préfixe data:) */
  base64: z.string().min(16).max(9_000_000),
});

export type DocumentExtraction = {
  doc_type: string;
  direction: string;
  issuer: string | null;
  counterpart: string | null;
  doc_number: string | null;
  issued_on: string | null;
  due_on: string | null;
  paid_on: string | null;
  amount_ht: number | null;
  amount_vat: number | null;
  amount_ttc: number | null;
  currency: string;
  payment_method: string | null;
  purpose: string | null;
  place: string | null;
  confidence: number;
  uncertain_fields: string[];
  summary: string;
  doc_language?: string;
};

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: [
    "doc_type",
    "direction",
    "issuer",
    "counterpart",
    "doc_number",
    "issued_on",
    "due_on",
    "paid_on",
    "amount_ht",
    "amount_vat",
    "amount_ttc",
    "currency",
    "payment_method",
    "purpose",
    "place",
    "confidence",
    "uncertain_fields",
    "summary",
  ],
  properties: {
    doc_type: {
      type: "string",
      enum: [
        "devis",
        "facture",
        "avoir",
        "acompte",
        "recu",
        "justificatif",
        "contrat",
        "paiement",
        "releve",
        "administratif",
        "inconnu",
      ],
    },
    direction: { type: "string", enum: ["recette", "depense", "inconnu"] },
    issuer: { type: ["string", "null"] },
    counterpart: { type: ["string", "null"] },
    doc_number: { type: ["string", "null"] },
    issued_on: { type: ["string", "null"] },
    due_on: { type: ["string", "null"] },
    paid_on: { type: ["string", "null"] },
    amount_ht: { type: ["number", "null"] },
    amount_vat: { type: ["number", "null"] },
    amount_ttc: { type: ["number", "null"] },
    currency: { type: "string" },
    payment_method: { type: ["string", "null"] },
    purpose: { type: ["string", "null"] },
    place: { type: ["string", "null"] },
    confidence: { type: "number" },
    uncertain_fields: { type: "array", items: { type: "string" } },
    summary: { type: "string" },
    doc_language: { type: "string" },
  },
} as const;

const SYSTEM = [
  "Tu es le Bureau d'AIME : un assistant administratif et financier d'une honnêteté absolue.",
  "Tu lis un document déposé par une personne (facture, devis, reçu, contrat, relevé, papier administratif) et tu en extrais les informations RÉELLEMENT présentes.",
  "RÈGLE ABSOLUE : tu n'inventes jamais. Si une donnée n'est pas lisible ou pas certaine, tu mets null et tu ajoutes le nom du champ dans uncertain_fields.",
  "Les montants sont exprimés en CENTIMES entiers (12,50 € = 1250). Les dates sont au format AAAA-MM-JJ.",
  "direction = 'recette' si la personne qui dépose le document est celle qui encaisse (elle a émis la facture), 'depense' si elle paie, 'inconnu' si tu ne peux pas trancher.",
  "issuer = l'entité qui A ÉMIS le document (en-tête, logo, SIRET, coordonnées de l'expéditeur) : le fournisseur sur une facture d'achat, l'organisme sur un courrier administratif.",
  "counterpart = le DESTINATAIRE du document (le client facturé, la personne à qui le courrier est adressé). Ne les inverse jamais.",
  "confidence = 0 à 1, ta certitude globale de lecture.",
  "summary : une phrase simple et humaine décrivant le document, sans jargon comptable.",
  "LANGUES : le document peut être rédigé dans n'importe quelle langue (français, anglais, espagnol, allemand, italien, néerlandais...). Reconnais les équivalents : Invoice/Factura/Rechnung/Fattura = facture ; Quote/Quotation/Presupuesto/Angebot/Preventivo = devis ; Receipt/Recibo/Quittung/Ricevuta = reçu ; Total/Importe/Betrag/Importo, VAT/IVA/MwSt/TVA, Due date/Vencimiento/Fälligkeit/Scadenza, Paid/Pagado/Bezahlt/Pagato.",
  "Les dates étrangères sont normalisées en AAAA-MM-JJ : attention au format anglo-saxon MM/JJ/AAAA et aux mois écrits en toutes lettres (January, Enero, Januar, Gennaio).",
  "Les séparateurs de milliers et décimales varient (1,234.56 en anglais = 1.234,56 en français) : convertis toujours en centimes entiers.",
  "currency : code ISO réellement indiqué (EUR, GBP, USD, CHF...), pas une supposition.",
  "doc_language : code de la langue du document (fr, en, es, de, it, nl...).",
  "summary : rédige-le TOUJOURS en français, même si le document est en langue étrangère.",
].join("\n");

export const analyzeDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<DocumentExtraction> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Le Bureau n'est pas configuré.");

    const isImage = data.mimeType.startsWith("image/");
    const isPdf = data.mimeType === "application/pdf";

    const content: unknown[] = [
      {
        type: "text",
        text: `Lis ce document (${data.fileName}) et remplis la fiche. N'invente rien.`,
      },
    ];
    if (isImage) {
      content.push({
        type: "image_url",
        image_url: { url: `data:${data.mimeType};base64,${data.base64}` },
      });
    } else if (isPdf) {
      content.push({
        type: "file",
        file: {
          filename: data.fileName,
          file_data: `data:${data.mimeType};base64,${data.base64}`,
        },
      });
    } else {
      throw new Error(
        "Ce format n'est pas lisible directement. Dépose une image ou un PDF, ou renseigne les champs à la main.",
      );
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "fiche_document",
              description: "Fiche extraite du document",
              parameters: SCHEMA,
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "fiche_document" } },
      }),
    });

    if (res.status === 429)
      throw new Error("Le Bureau est très sollicité. Réessaie dans quelques instants.");
    if (res.status === 402)
      throw new Error("Crédits IA épuisés : recharge le solde pour relancer la lecture.");
    if (!res.ok) throw new Error(`Lecture impossible (${res.status}).`);

    const json = await res.json();
    const call = json?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call) throw new Error("Le document n'a pas pu être lu.");
    const parsed = JSON.parse(call.function.arguments) as DocumentExtraction;
    return {
      ...parsed,
      currency: parsed.currency || "EUR",
      doc_language: parsed.doc_language || "fr",
      uncertain_fields: parsed.uncertain_fields ?? [],
    };
  });
