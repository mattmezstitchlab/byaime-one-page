import { supabase } from "@/integrations/supabase/client";

/** Trois niveaux de vérité, jamais mélangés. */
export type SourceLevel = "declare" | "documente" | "interprete";

export const LEVEL_LABEL: Record<SourceLevel, string> = {
  declare: "Déclaré",
  documente: "Documenté",
  interprete: "Interprété",
};

export const LEVEL_HINT: Record<SourceLevel, string> = {
  declare: "Ce que la personne, la marque ou la tradition affirme d'elle-même.",
  documente: "Ce qu'une source extérieure vérifiable atteste.",
  interprete: "Ce qu'AIME résume ou met en perspective, sans le présenter comme certain.",
};

export type CardReference = {
  id: string;
  level: SourceLevel;
  title: string;
  publisher: string | null;
  url: string | null;
  note: string | null;
  sort_order: number;
};

export type CardMemory = {
  summary: string;
  era: string | null;
  disclaimer: string;
  references: CardReference[];
};

/** Mémoire d'une carte : renvoie null pour une carte ordinaire. */
export const cardMemoryQuery = (cardId: string) => ({
  queryKey: ["card-memory", cardId],
  queryFn: async (): Promise<CardMemory | null> => {
    const { data: mem, error } = await supabase
      .from("card_memory")
      .select("summary,era,disclaimer")
      .eq("card_id", cardId)
      .maybeSingle();
    if (error) throw error;
    if (!mem) return null;

    const { data: refs } = await supabase
      .from("card_references")
      .select("id,level,title,publisher,url,note,sort_order")
      .eq("card_id", cardId)
      .order("sort_order", { ascending: true });

    return {
      summary: mem.summary,
      era: mem.era,
      disclaimer: mem.disclaimer,
      references: (refs ?? []) as CardReference[],
    };
  },
  staleTime: 5 * 60_000,
});
