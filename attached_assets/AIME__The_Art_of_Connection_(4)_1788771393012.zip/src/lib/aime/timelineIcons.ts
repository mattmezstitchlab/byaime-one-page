/**
 * Le langage visuel de la ligne de temps : un pictogramme dit la nature de
 * l'objet, une pastille dit son état. Rien n'est décoratif — le picto est une
 * information, exactement comme la position dans le temps.
 * Une seule source : le repère lui-même (nature, média, métadonnées).
 */
import {
  AlarmClock,
  AlertTriangle,
  Ban,
  Building2,
  Cake,
  CalendarCheck,
  CalendarDays,
  Camera,
  Car,
  Church,
  Clock3,
  CreditCard,
  FileText,
  Flag,
  Flower2,
  Folder,
  Gem,
  Heart,
  Hotel,
  Image,
  Lamp,
  Lightbulb,
  ListChecks,
  ListMusic,
  MapPin,
  MessageCircle,
  Music2,
  Phone,
  ReceiptText,
  Scissors,
  ScrollText,
  UtensilsCrossed,
  Users,
  Video,
} from "lucide-react";
import type {
  TimelineKind,
  TimelineMarker,
  TimelineStatus,
} from "@/components/aime/HeroTimeline";

export type PictoComponent = typeof Heart;

/** Pictogramme par nature d'objet temporel. */
export const KIND_PICTO: Record<TimelineKind, PictoComponent> = {
  souvenir: Heart,
  evenement: CalendarDays,
  disponible: CalendarCheck,
  option: Clock3,
  complet: Ban,
  intention: Lightbulb,
  jalon: Flag,
  tache: ListChecks,
  message: MessageCircle,
  dossier: Folder,
  document: FileText,
  devis: ReceiptText,
  facture: ScrollText,
  paiement: CreditCard,
};

/** Pictogramme par métier : reconnu sur le libellé du rôle, sans nouvelle saisie. */
const ROLE_PICTO: { test: RegExp; icon: PictoComponent }[] = [
  { test: /photograph/i, icon: Camera },
  { test: /vid[ée]/i, icon: Video },
  { test: /musique|dj|orchestre|groupe/i, icon: Music2 },
  { test: /playlist/i, icon: ListMusic },
  { test: /traiteur|repas|d[îi]ner|cocktail|buffet/i, icon: UtensilsCrossed },
  { test: /p[âa]tisserie|g[âa]teau|pi[èe]ce mont[ée]e/i, icon: Cake },
  { test: /fleur/i, icon: Flower2 },
  { test: /coiffure|maquillage|beaut[ée]/i, icon: Scissors },
  { test: /transport|navette|voiture/i, icon: Car },
  { test: /h[ée]bergement|h[ôo]tel|chambre/i, icon: Hotel },
  { test: /lieu|domaine|salle|r[ée]ception/i, icon: MapPin },
  { test: /officiant|c[ée]r[ée]monie|mairie|[ée]glise/i, icon: Church },
  { test: /d[ée]cor|lumi[èe]re/i, icon: Lamp },
  { test: /invit[ée]|convive|t[ée]moin/i, icon: Users },
  { test: /t[ée]l[ée]phone|appel/i, icon: Phone },
  { test: /prestataire|agence|soci[ée]t[ée]/i, icon: Building2 },
];

const MEDIA_PICTO: Record<string, PictoComponent> = {
  video: Video,
  audio: Music2,
  photo: Image,
};

/** Le pictogramme d'un repère : média, puis métier, puis nature. */
export function pictoFor(m: {
  kind: TimelineKind;
  media?: string | undefined;
  title?: string | undefined;
  source?: string | undefined;
  metadata?: Record<string, unknown> | undefined;
}): PictoComponent {
  // Ce qui vient d'AIME n'a pas d'icône propre : on montre toujours la nature
  // réelle de l'objet. Le cœur reste le seul symbole de l'intelligence AIME.
  const meta = m.metadata ?? {};
  if (m.kind === "souvenir") {
    const mediaKind = typeof meta["mediaKind"] === "string" ? (meta["mediaKind"] as string) : "";
    return MEDIA_PICTO[mediaKind] ?? Image;
  }
  if (m.source === "musique") return Music2;
  if (m.kind === "paiement") return CreditCard;
  if (m.kind === "devis") return ReceiptText;
  if (m.kind === "facture") return ScrollText;
  if (m.kind === "document") return FileText;
  if (m.kind === "message") return MessageCircle;
  if (m.kind === "tache") return ListChecks;

  const role = typeof meta["role"] === "string" ? (meta["role"] as string) : "";
  const hay = `${role} ${m.title ?? ""}`;
  for (const r of ROLE_PICTO) if (r.test.test(hay)) return r.icon;

  if (m.kind === "evenement") return Gem;
  return KIND_PICTO[m.kind];
}

/** Pastille d'état : très sobre, une seule information par couleur. */
export const STATUS_DOT: Record<TimelineStatus, string | null> = {
  prepare: null,
  execute: "bg-emerald-400",
  a_valider: "bg-amber-400",
  en_attente: "bg-sky-400",
  bloque: "bg-rose-500",
  annule: "bg-white/40",
  echoue: "bg-rose-400",
};

export const ALERT_PICTO = AlertTriangle;
export const DUE_PICTO = AlarmClock;

/** Les natures dominantes d'un groupe de repères, pour l'afficher en grappe. */
export function clusterPictos(children: TimelineMarker[], max = 3): {
  icons: PictoComponent[];
  rest: number;
} {
  const seen: PictoComponent[] = [];
  for (const child of children) {
    const icon = pictoFor(child);
    if (!seen.includes(icon)) seen.push(icon);
  }
  return { icons: seen.slice(0, max), rest: Math.max(0, seen.length - max) };
}
