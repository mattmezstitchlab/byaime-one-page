/**
 * Les modèles de projet (« blueprints ») : un par famille de projet.
 *
 * Le mariage n'est plus le seul chemin possible. Chaque type de projet apporte
 * ses questions, ses places à pourvoir, son déroulé du jour et son
 * rétroplanning. `buildProject` remplace `buildWedding` : c'est le même moteur,
 * nourri par des données différentes selon le type choisi.
 */
import { DAY, fact, type Confidence, type WorldProject, type WorldProvider } from "./types";
import { UNIVERSE_TREE } from "@/lib/aime/universeTree";

export type QuestionKey = "quand" | "ou" | "existant" | "qui";

export type BlueprintQuestion = {
  key: QuestionKey;
  /** Le mot affiché sur le bouton et la pastille. */
  label: string;
  placeholder: string;
  type: "date" | "text" | "number";
  examples?: string[];
  /** La phrase enregistrée dans le récit. */
  sentence: (value: string) => string;
};

export type FlowStep = {
  key: string;
  /** Décalage en heures par rapport à l'heure pivot du jour J. */
  delta: number;
  label: string;
  detail: string;
  role?: string;
};

export type RetroStep = {
  key: string;
  /** Nombre de jours avant le jour J (négatif = après). */
  days: number;
  label: string;
  detail: string;
  role?: string;
  /** Étapes qui doivent être terminées avant celle-ci. */
  after?: string[];
};

export type Blueprint = {
  id: string;
  label: string;
  /** Nom d'univers affiché sur le projet. */
  universe: string;
  /** Slug d'univers / de type conservé sur le projet. */
  kind: string;
  titleFallback: string;
  /** Heure de référence du jour J. */
  pivotHour: number;
  /** Le mot employé pour parler du jour J. */
  dayWord: string;
  roles: string[];
  flow: FlowStep[];
  retro: RetroStep[];
  questions: BlueprintQuestion[];
  loadingSteps: string[];
};

const euros = (v: string) => `Notre budget est d'environ ${v} €.`;

/** Les quatre questions génériques, réutilisées et adaptées par chaque modèle. */
function questions(opts: {
  quand: [string, string, string?];
  ou: [string, string];
  qui: [string, string];
  quiSentence?: (v: string) => string;
  existantLabel?: string;
}): BlueprintQuestion[] {
  return [
    {
      key: "quand",
      label: opts.quand[0],
      placeholder: opts.quand[1],
      type: "date",
      sentence: (v) => {
        const d = new Date(v);
        const t = Number.isNaN(d.getTime())
          ? v
          : d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
        return `${opts.quand[2] ?? "La date prévue est le"} ${t}.`;
      },
    },
    {
      key: "ou",
      label: opts.ou[0],
      placeholder: opts.ou[1],
      type: "text",
      /* Le repérage relit cette réponse telle quelle : on la garde brute. */
      sentence: (v) => v,
    },
    {
      key: "existant",
      label: opts.existantLabel ?? "Budget",
      placeholder: "Budget en euros",
      type: "number",
      sentence: euros,
    },
    {
      key: "qui",
      label: opts.qui[0],
      placeholder: opts.qui[1],
      type: "number",
      sentence: opts.quiSentence ?? ((v) => `Nous serons ${v} personnes.`),
    },
  ];
}

/* ─────────────────────────── Les modèles ─────────────────────────── */

const mariage: Blueprint = {
  id: "mariage",
  label: "Mariage",
  universe: "Mariage",
  kind: "mariage",
  titleFallback: "Votre mariage",
  pivotHour: 15,
  dayWord: "Jour J",
  roles: [
    "Lieu de réception",
    "Traiteur",
    "Photographe",
    "Vidéaste",
    "Musique / DJ",
    "Fleuriste",
    "Décoration",
    "Coiffure & maquillage",
    "Pâtisserie",
    "Officiant / cérémonie",
    "Transport",
    "Hébergement",
  ],
  flow: [
    { key: "preparation", delta: -7, label: "Préparatifs", detail: "Réveil, petit-déjeuner, mise en place calme.", role: "Coiffure & maquillage" },
    { key: "habillage", delta: -2.5, label: "Habillage", detail: "Tenues, derniers essayages, photos des préparatifs.", role: "Photographe" },
    { key: "deplacement", delta: -1.5, label: "Déplacement", detail: "Trajet vers le lieu de cérémonie.", role: "Transport" },
    { key: "installation", delta: -1, label: "Installation & décor", detail: "Arche, tables, signalétique, son.", role: "Décoration" },
    { key: "accueil", delta: -0.5, label: "Accueil des invités", detail: "Arrivée, placement, musique douce." },
    { key: "ceremonie", delta: 0, label: "Cérémonie", detail: "Échange des vœux et des consentements.", role: "Officiant / cérémonie" },
    { key: "sortie", delta: 0.75, label: "Sortie", detail: "Haie d'honneur, félicitations." },
    { key: "photos", delta: 1.25, label: "Photos de groupe", detail: "Familles, témoins, puis les mariés.", role: "Photographe" },
    { key: "cocktail", delta: 2.5, label: "Cocktail", detail: "Pièces salées et premières retrouvailles.", role: "Traiteur" },
    { key: "diner", delta: 4.5, label: "Dîner", detail: "Entrée en salle et service.", role: "Traiteur" },
    { key: "discours", delta: 6, label: "Discours", detail: "Prises de parole entre les plats." },
    { key: "gateau", delta: 7, label: "Pièce montée", detail: "Dessert et feux froids.", role: "Pâtisserie" },
    { key: "bal", delta: 7.5, label: "Ouverture de bal", detail: "Première danse.", role: "Musique / DJ" },
    { key: "soiree", delta: 8.5, label: "Soirée", detail: "La piste ne se vide plus.", role: "Musique / DJ" },
    { key: "fin", delta: 13, label: "Fin de soirée", detail: "Dernier morceau, retours.", role: "Transport" },
  ],
  retro: [
    { key: "lieu", days: 540, label: "Réserver le lieu", detail: "Visiter, comparer, poser une option.", role: "Lieu de réception" },
    { key: "traiteur", days: 450, label: "Choisir le traiteur", detail: "Dégustation et devis.", role: "Traiteur", after: ["lieu"] },
    { key: "photo", days: 450, label: "Choisir le photographe", detail: "Comparer les portfolios.", role: "Photographe" },
    { key: "musique", days: 330, label: "Choisir la musique", detail: "DJ ou groupe, style de soirée.", role: "Musique / DJ" },
    { key: "tenues", days: 300, label: "Tenues des mariés", detail: "Essayages et retouches." },
    { key: "invites", days: 270, label: "Arrêter la liste des invités", detail: "Familles, amis, capacité du lieu.", after: ["lieu"] },
    { key: "faire-part", days: 240, label: "Envoyer les faire-part", detail: "Envoi et suivi des réponses.", after: ["invites"] },
    { key: "fleurs", days: 180, label: "Fleurs et décoration", detail: "Arche, centres de table, bouquet.", role: "Fleuriste" },
    { key: "menu", days: 90, label: "Finaliser le menu", detail: "Allergies, régimes, nombre de couverts.", role: "Traiteur", after: ["traiteur", "faire-part"] },
    { key: "plan", days: 45, label: "Plan de table", detail: "Placement et signalétique.", after: ["faire-part"] },
    { key: "solde", days: 15, label: "Dernier paiement du traiteur", detail: "Solde avant la réception.", role: "Traiteur", after: ["menu"] },
    { key: "repetition", days: 7, label: "Répétition", detail: "Déroulé, entrées, prises de parole.", after: ["plan"] },
    { key: "materiel", days: -3, label: "Retour du matériel", detail: "Vaisselle, décor, location." },
    { key: "remerciements", days: -21, label: "Remerciements", detail: "Un mot aux invités et aux prestataires." },
    { key: "album", days: -30, label: "Album photo", detail: "Sélection et commande.", role: "Photographe" },
  ],
  questions: questions({
    quand: ["Date", "Le jour du mariage", "Le mariage est prévu le"],
    ou: ["Lieu", "Lille, un domaine…"],
    qui: ["Invités", "Nombre d'invités"],
    quiSentence: (v) => `Nous serons ${v} invités.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date du mariage se pose",
    "Le déroulé du jour J se construit",
    "Les places à pourvoir s'ouvrent",
    "Le rétroplanning se déroule",
  ],
};

const celebration: Blueprint = {
  id: "celebration",
  label: "Fête & célébration",
  universe: "Événement",
  kind: "evenement",
  titleFallback: "Votre célébration",
  pivotHour: 19,
  dayWord: "Jour de la fête",
  roles: ["Lieu", "Traiteur", "Musique / DJ", "Décoration", "Photographe", "Gâteau", "Animation"],
  flow: [
    { key: "installation", delta: -3, label: "Installation", detail: "Salle, tables, lumières.", role: "Décoration" },
    { key: "livraison", delta: -1.5, label: "Livraisons", detail: "Boissons, buffet, gâteau.", role: "Traiteur" },
    { key: "accueil", delta: 0, label: "Accueil", detail: "Arrivée des invités." },
    { key: "aperitif", delta: 0.5, label: "Apéritif", detail: "Premiers verres et retrouvailles.", role: "Traiteur" },
    { key: "repas", delta: 2, label: "Repas", detail: "Service à table ou buffet.", role: "Traiteur" },
    { key: "gateau", delta: 3.5, label: "Gâteau", detail: "Le moment attendu.", role: "Gâteau" },
    { key: "musique", delta: 4, label: "Musique et danse", detail: "La soirée démarre.", role: "Musique / DJ" },
    { key: "fin", delta: 8, label: "Fin de soirée", detail: "Dernier morceau et rangement." },
  ],
  retro: [
    { key: "date", days: 120, label: "Fixer la date", detail: "Vérifier les disponibilités des proches." },
    { key: "lieu", days: 90, label: "Réserver le lieu", detail: "Capacité, horaires, sonorisation.", role: "Lieu", after: ["date"] },
    { key: "invitations", days: 60, label: "Envoyer les invitations", detail: "Liste et réponses.", after: ["lieu"] },
    { key: "traiteur", days: 45, label: "Commander le buffet", detail: "Devis et nombre de couverts.", role: "Traiteur", after: ["invitations"] },
    { key: "musique", days: 40, label: "Choisir la musique", detail: "DJ, playlist ou groupe.", role: "Musique / DJ" },
    { key: "deco", days: 20, label: "Décoration", detail: "Thème, ballons, éclairage.", role: "Décoration" },
    { key: "confirmation", days: 5, label: "Confirmer tout le monde", detail: "Horaires et adresses.", after: ["traiteur", "musique"] },
    { key: "rangement", days: -1, label: "Rangement et retours", detail: "Matériel loué, nettoyage." },
    { key: "souvenirs", days: -10, label: "Partager les photos", detail: "Album commun avec les invités." },
  ],
  questions: questions({
    quand: ["Date", "Le jour de la fête", "La fête est prévue le"],
    ou: ["Lieu", "Une salle, une maison…"],
    qui: ["Invités", "Nombre d'invités"],
    quiSentence: (v) => `Nous serons ${v} invités.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date de la fête se pose",
    "Le déroulé de la soirée se construit",
    "Les préparatifs s'organisent",
    "Le rétroplanning se déroule",
  ],
};

const concert: Blueprint = {
  id: "concert",
  label: "Concert",
  universe: "Musique & Scène",
  kind: "concert",
  titleFallback: "Votre concert",
  pivotHour: 20.5,
  dayWord: "Soir du concert",
  roles: [
    "Salle / lieu",
    "Plateau artistique",
    "Sonorisation",
    "Lumière",
    "Régie technique",
    "Billetterie",
    "Communication",
    "Sécurité",
    "Catering",
  ],
  flow: [
    { key: "chargement", delta: -9, label: "Chargement", detail: "Arrivée du matériel et du backline.", role: "Régie technique" },
    { key: "montage", delta: -8, label: "Montage", detail: "Scène, son, lumière.", role: "Sonorisation" },
    { key: "balances", delta: -5, label: "Balances", detail: "Réglages plateau par plateau.", role: "Plateau artistique" },
    { key: "catering", delta: -3, label: "Catering", detail: "Repas des équipes et des artistes.", role: "Catering" },
    { key: "ouverture", delta: -1, label: "Ouverture des portes", detail: "Contrôle billets et placement.", role: "Billetterie" },
    { key: "premiere", delta: -0.25, label: "Première partie", detail: "Le plateau s'ouvre." },
    { key: "concert", delta: 0, label: "Concert", detail: "Le set principal.", role: "Plateau artistique" },
    { key: "rappel", delta: 1.5, label: "Rappel", detail: "Le dernier morceau." },
    { key: "demontage", delta: 2.5, label: "Démontage", detail: "Rangement et chargement.", role: "Régie technique" },
  ],
  retro: [
    { key: "artistique", days: 180, label: "Arrêter le programme artistique", detail: "Plateau, durée, ordre de passage.", role: "Plateau artistique" },
    { key: "salle", days: 150, label: "Réserver la salle", detail: "Date, jauge, conditions.", role: "Salle / lieu", after: ["artistique"] },
    { key: "contrats", days: 120, label: "Contrats et cachets", detail: "Engagements, déclarations.", after: ["artistique", "salle"] },
    { key: "budget", days: 110, label: "Boucler le budget", detail: "Recettes, cachets, technique.", after: ["contrats"] },
    { key: "technique", days: 75, label: "Fiche technique", detail: "Plan de scène, patch, besoins.", role: "Régie technique", after: ["artistique"] },
    { key: "billetterie", days: 70, label: "Ouvrir la billetterie", detail: "Tarifs et mise en vente.", role: "Billetterie", after: ["salle"] },
    { key: "comm", days: 60, label: "Communication", detail: "Affiche, réseaux, presse.", role: "Communication", after: ["billetterie"] },
    { key: "presta", days: 45, label: "Confirmer son et lumière", detail: "Prestataires et matériel.", role: "Sonorisation", after: ["technique"] },
    { key: "repetitions", days: 21, label: "Répétitions", detail: "Filages du set.", after: ["artistique"] },
    { key: "runsheet", days: 7, label: "Feuille de route", detail: "Horaires précis de la journée.", after: ["presta", "repetitions"] },
    { key: "solde", days: -7, label: "Régler les cachets et factures", detail: "Soldes et déclarations." },
    { key: "bilan", days: -21, label: "Bilan et captation", detail: "Fréquentation, photos, vidéos." },
  ],
  questions: questions({
    quand: ["Date", "Le soir du concert", "Le concert est prévu le"],
    ou: ["Salle", "Une salle, une ville…"],
    qui: ["Public", "Public attendu"],
    quiSentence: (v) => `Nous attendons environ ${v} personnes.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date du concert se pose",
    "Le programme et les balances se placent",
    "L'organisation de la production démarre",
    "Le rétroplanning se déroule",
  ],
};

const festival: Blueprint = {
  id: "festival",
  label: "Festival",
  universe: "Musique & Scène",
  kind: "festival",
  titleFallback: "Votre festival",
  pivotHour: 14,
  dayWord: "Ouverture",
  roles: [
    "Site / terrain",
    "Programmation",
    "Production technique",
    "Bénévoles",
    "Sécurité",
    "Buvette & restauration",
    "Billetterie",
    "Communication",
    "Assurances & autorisations",
  ],
  flow: [
    { key: "montage", delta: -30, label: "Montage du site", detail: "Scènes, barrières, signalétique.", role: "Production technique" },
    { key: "benevoles", delta: -6, label: "Briefing des bénévoles", detail: "Postes et horaires.", role: "Bénévoles" },
    { key: "balances", delta: -4, label: "Balances", detail: "Passage des groupes.", role: "Programmation" },
    { key: "ouverture", delta: 0, label: "Ouverture des portes", detail: "Accueil du public.", role: "Billetterie" },
    { key: "scene1", delta: 2, label: "Premiers concerts", detail: "La programmation démarre.", role: "Programmation" },
    { key: "tetedaffiche", delta: 8, label: "Tête d'affiche", detail: "Le temps fort de la soirée." },
    { key: "fermeture", delta: 12, label: "Fermeture", detail: "Fin des concerts, évacuation.", role: "Sécurité" },
    { key: "demontage", delta: 20, label: "Démontage", detail: "Remise en état du site.", role: "Production technique" },
  ],
  retro: [
    { key: "concept", days: 300, label: "Poser le projet du festival", detail: "Identité, durée, ambition." },
    { key: "site", days: 270, label: "Sécuriser le site", detail: "Terrain, convention, accès.", role: "Site / terrain", after: ["concept"] },
    { key: "budget", days: 240, label: "Budget prévisionnel", detail: "Dépenses, recettes, subventions.", after: ["concept"] },
    { key: "subventions", days: 220, label: "Demandes de subventions", detail: "Dossiers et partenaires.", after: ["budget"] },
    { key: "programmation", days: 180, label: "Programmation", detail: "Contacts, offres, confirmations.", role: "Programmation", after: ["budget"] },
    { key: "autorisations", days: 120, label: "Autorisations et assurances", detail: "Mairie, préfecture, sécurité.", role: "Assurances & autorisations", after: ["site"] },
    { key: "billetterie", days: 110, label: "Ouvrir la billetterie", detail: "Tarifs, pass, mise en vente.", role: "Billetterie", after: ["programmation"] },
    { key: "comm", days: 90, label: "Campagne de communication", detail: "Affiche, réseaux, presse.", role: "Communication", after: ["billetterie"] },
    { key: "technique", days: 75, label: "Plan technique du site", detail: "Scènes, électricité, flux.", role: "Production technique", after: ["autorisations"] },
    { key: "benevoles", days: 45, label: "Recruter les bénévoles", detail: "Postes, plannings, repas.", role: "Bénévoles" },
    { key: "restauration", days: 40, label: "Buvette et restauration", detail: "Stands, licences, stocks.", role: "Buvette & restauration" },
    { key: "runsheet", days: 10, label: "Feuille de route générale", detail: "Horaires, contacts, secours.", after: ["technique", "benevoles"] },
    { key: "remise", days: -3, label: "Remise en état", detail: "Nettoyage et restitution du site." },
    { key: "bilan", days: -30, label: "Bilan et comptes", detail: "Fréquentation, comptes, rapports." },
  ],
  questions: questions({
    quand: ["Date", "Le premier jour", "Le festival ouvre le"],
    ou: ["Site", "Un site, une ville…"],
    qui: ["Public", "Capacité attendue"],
    quiSentence: (v) => `Nous attendons environ ${v} festivaliers.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "Les dates du festival se posent",
    "Le site et la programmation s'installent",
    "La production s'organise",
    "Le rétroplanning se déroule",
  ],
};

const spectacle: Blueprint = {
  id: "spectacle",
  label: "Spectacle & exposition",
  universe: "Culture & Art",
  kind: "culture",
  titleFallback: "Votre projet culturel",
  pivotHour: 19,
  dayWord: "Jour d'ouverture",
  roles: [
    "Lieu / salle",
    "Équipe artistique",
    "Scénographie",
    "Technique",
    "Médiation",
    "Communication",
    "Partenaires",
  ],
  flow: [
    { key: "montage", delta: -10, label: "Montage", detail: "Accrochage ou installation du décor.", role: "Scénographie" },
    { key: "reglages", delta: -6, label: "Réglages", detail: "Lumière, son, parcours.", role: "Technique" },
    { key: "filage", delta: -4, label: "Filage / dernière visite", detail: "Vérification complète.", role: "Équipe artistique" },
    { key: "accueil", delta: -0.5, label: "Accueil du public", detail: "Ouverture des portes.", role: "Médiation" },
    { key: "ouverture", delta: 0, label: "Ouverture", detail: "Représentation ou vernissage." },
    { key: "echange", delta: 2, label: "Rencontre avec le public", detail: "Échange, dédicaces, verre.", role: "Médiation" },
    { key: "demontage", delta: 4, label: "Rangement", detail: "Fin de soirée et remise en ordre." },
  ],
  retro: [
    { key: "intention", days: 240, label: "Écrire l'intention artistique", detail: "Le propos et la forme." },
    { key: "equipe", days: 200, label: "Réunir l'équipe", detail: "Artistes, technique, médiation.", role: "Équipe artistique", after: ["intention"] },
    { key: "lieu", days: 180, label: "Trouver le lieu", detail: "Dates, jauge, conditions.", role: "Lieu / salle", after: ["intention"] },
    { key: "budget", days: 160, label: "Budget et financements", detail: "Aides, coproductions, billetterie.", after: ["lieu", "equipe"] },
    { key: "creation", days: 90, label: "Temps de création", detail: "Répétitions ou production des œuvres.", after: ["equipe"] },
    { key: "scenographie", days: 60, label: "Scénographie", detail: "Décor, accrochage, parcours.", role: "Scénographie", after: ["lieu"] },
    { key: "comm", days: 45, label: "Communication", detail: "Dossier, affiche, presse, réseaux.", role: "Communication", after: ["lieu"] },
    { key: "technique", days: 30, label: "Fiche technique", detail: "Besoins son, lumière, matériel.", role: "Technique", after: ["scenographie"] },
    { key: "generale", days: 3, label: "Générale", detail: "Dernier filage dans les conditions du jour.", after: ["creation", "technique"] },
    { key: "demontage", days: -7, label: "Démontage", detail: "Restitution du lieu et des œuvres." },
    { key: "bilan", days: -21, label: "Bilan", detail: "Public, retours, traces du projet." },
  ],
  questions: questions({
    quand: ["Date", "Le jour d'ouverture", "L'ouverture est prévue le"],
    ou: ["Lieu", "Une salle, une galerie…"],
    qui: ["Public", "Public attendu"],
    quiSentence: (v) => `Nous attendons environ ${v} personnes.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date d'ouverture se pose",
    "Le temps de création se place",
    "L'équipe et le lieu s'organisent",
    "Le rétroplanning se déroule",
  ],
};

const entreprise: Blueprint = {
  id: "entreprise",
  label: "Événement professionnel",
  universe: "Entreprise & Pro",
  kind: "entreprise",
  titleFallback: "Votre événement professionnel",
  pivotHour: 9,
  dayWord: "Jour de l'événement",
  roles: [
    "Lieu",
    "Traiteur",
    "Audiovisuel",
    "Intervenants",
    "Inscriptions",
    "Communication",
    "Transport & hébergement",
  ],
  flow: [
    { key: "installation", delta: -2, label: "Installation", detail: "Salle, écrans, signalétique.", role: "Audiovisuel" },
    { key: "accueil", delta: -0.5, label: "Accueil café", detail: "Émargement et badges.", role: "Inscriptions" },
    { key: "ouverture", delta: 0, label: "Ouverture", detail: "Mot d'accueil et cadrage." },
    { key: "pleniere", delta: 0.5, label: "Plénière", detail: "Interventions principales.", role: "Intervenants" },
    { key: "ateliers", delta: 2.5, label: "Ateliers", detail: "Groupes de travail en parallèle." },
    { key: "dejeuner", delta: 4, label: "Déjeuner", detail: "Pause et échanges.", role: "Traiteur" },
    { key: "aprem", delta: 5.5, label: "Séquence de l'après-midi", detail: "Restitutions et décisions." },
    { key: "cloture", delta: 8, label: "Clôture", detail: "Synthèse et suites." },
    { key: "cocktail", delta: 8.5, label: "Cocktail", detail: "Temps informel.", role: "Traiteur" },
  ],
  retro: [
    { key: "objectif", days: 120, label: "Définir l'objectif", detail: "Message, cible, résultat attendu." },
    { key: "budget", days: 110, label: "Valider le budget", detail: "Enveloppe et validation interne.", after: ["objectif"] },
    { key: "lieu", days: 90, label: "Réserver le lieu", detail: "Capacité, accès, équipement.", role: "Lieu", after: ["budget"] },
    { key: "programme", days: 75, label: "Construire le programme", detail: "Séquences et intervenants.", role: "Intervenants", after: ["objectif"] },
    { key: "invitations", days: 60, label: "Envoyer les invitations", detail: "Cible et inscriptions.", role: "Inscriptions", after: ["lieu", "programme"] },
    { key: "presta", days: 45, label: "Traiteur et audiovisuel", detail: "Devis et commandes.", role: "Traiteur", after: ["lieu"] },
    { key: "supports", days: 21, label: "Supports et contenus", detail: "Présentations, badges, livret.", role: "Communication", after: ["programme"] },
    { key: "logistique", days: 14, label: "Transports et hébergements", detail: "Intervenants et participants venus de loin.", role: "Transport & hébergement", after: ["invitations"] },
    { key: "runsheet", days: 5, label: "Déroulé minuté", detail: "Rôles de chacun le jour même.", after: ["supports", "presta"] },
    { key: "compterendu", days: -5, label: "Compte rendu", detail: "Synthèse envoyée aux participants." },
    { key: "bilan", days: -20, label: "Bilan et factures", detail: "Retours, coûts réels, suites." },
  ],
  questions: questions({
    quand: ["Date", "Le jour de l'événement", "L'événement est prévu le"],
    ou: ["Lieu", "Une ville, un site…"],
    qui: ["Participants", "Nombre de participants"],
    quiSentence: (v) => `Nous attendons ${v} participants.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date de l'événement se pose",
    "Le déroulé de la journée se construit",
    "La logistique s'organise",
    "Le rétroplanning se déroule",
  ],
};

const voyage: Blueprint = {
  id: "voyage",
  label: "Voyage & séjour",
  universe: "Voyage & Séjour",
  kind: "voyage",
  titleFallback: "Votre voyage",
  pivotHour: 8,
  dayWord: "Jour du départ",
  roles: ["Transport", "Hébergement", "Activités", "Restauration", "Assurances"],
  flow: [
    { key: "preparatifs", delta: -3, label: "Derniers préparatifs", detail: "Bagages et documents." },
    { key: "depart", delta: 0, label: "Départ", detail: "Le voyage commence.", role: "Transport" },
    { key: "arrivee", delta: 6, label: "Arrivée", detail: "Installation sur place.", role: "Hébergement" },
    { key: "premiere", delta: 10, label: "Première sortie", detail: "Repérage et premier repas.", role: "Restauration" },
    { key: "programme", delta: 30, label: "Activités du séjour", detail: "Le programme se déroule.", role: "Activités" },
    { key: "retour", delta: 120, label: "Retour", detail: "Trajet de retour.", role: "Transport" },
  ],
  retro: [
    { key: "destination", days: 150, label: "Choisir la destination", detail: "Envies, saison, budget." },
    { key: "budget", days: 140, label: "Fixer le budget", detail: "Transport, logement, sur place.", after: ["destination"] },
    { key: "transport", days: 120, label: "Réserver le transport", detail: "Billets et horaires.", role: "Transport", after: ["budget"] },
    { key: "hebergement", days: 100, label: "Réserver l'hébergement", detail: "Nuits et emplacements.", role: "Hébergement", after: ["transport"] },
    { key: "papiers", days: 60, label: "Papiers et santé", detail: "Passeport, visa, vaccins, assurance.", role: "Assurances", after: ["destination"] },
    { key: "activites", days: 30, label: "Réserver les activités", detail: "Visites, guides, restaurants.", role: "Activités", after: ["hebergement"] },
    { key: "itineraire", days: 14, label: "Écrire l'itinéraire", detail: "Jour par jour, marges comprises.", after: ["activites"] },
    { key: "valises", days: 2, label: "Préparer les bagages", detail: "Liste et derniers achats.", after: ["itineraire"] },
    { key: "souvenirs", days: -10, label: "Trier les souvenirs", detail: "Photos, carnet, partage." },
  ],
  questions: questions({
    quand: ["Départ", "La date du départ", "Nous partons le"],
    ou: ["Destination", "Où allez-vous ?"],
    qui: ["Voyageurs", "Nombre de voyageurs"],
    quiSentence: (v) => `Nous serons ${v} voyageurs.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date du départ se pose",
    "L'itinéraire prend forme",
    "Les réservations s'organisent",
    "Le rétroplanning se déroule",
  ],
};

const association: Blueprint = {
  id: "association",
  label: "Projet associatif",
  universe: "Association & Solidarité",
  kind: "solidarite",
  titleFallback: "Votre projet solidaire",
  pivotHour: 10,
  dayWord: "Jour de l'action",
  roles: ["Bénévoles", "Lieu", "Partenaires", "Logistique", "Communication", "Financements"],
  flow: [
    { key: "installation", delta: -3, label: "Installation", detail: "Stands, tables, signalétique.", role: "Logistique" },
    { key: "briefing", delta: -1, label: "Briefing des bénévoles", detail: "Rôles et consignes.", role: "Bénévoles" },
    { key: "ouverture", delta: 0, label: "Ouverture au public", detail: "L'action commence." },
    { key: "temps-fort", delta: 3, label: "Temps fort", detail: "Le moment central de la journée." },
    { key: "cloture", delta: 7, label: "Clôture", detail: "Remerciements et bilan à chaud." },
    { key: "rangement", delta: 8.5, label: "Rangement", detail: "Remise en état du lieu.", role: "Logistique" },
  ],
  retro: [
    { key: "intention", days: 180, label: "Poser le projet", detail: "But, public visé, impact attendu." },
    { key: "equipe", days: 150, label: "Réunir l'équipe", detail: "Bénévoles et référents.", role: "Bénévoles", after: ["intention"] },
    { key: "financements", days: 120, label: "Chercher les financements", detail: "Subventions, dons, partenaires.", role: "Financements", after: ["intention"] },
    { key: "lieu", days: 90, label: "Trouver le lieu", detail: "Autorisations et accès.", role: "Lieu", after: ["intention"] },
    { key: "partenaires", days: 60, label: "Confirmer les partenaires", detail: "Engagements écrits.", role: "Partenaires", after: ["financements"] },
    { key: "comm", days: 40, label: "Faire connaître l'action", detail: "Affiches, réseaux, presse locale.", role: "Communication", after: ["lieu"] },
    { key: "logistique", days: 20, label: "Logistique", detail: "Matériel, transport, repas.", role: "Logistique", after: ["lieu"] },
    { key: "planning", days: 7, label: "Planning des bénévoles", detail: "Créneaux et postes.", after: ["equipe", "logistique"] },
    { key: "remerciements", days: -3, label: "Remercier", detail: "Bénévoles, partenaires, participants." },
    { key: "bilan", days: -30, label: "Bilan et comptes", detail: "Impact, dépenses, suites." },
  ],
  questions: questions({
    quand: ["Date", "Le jour de l'action", "L'action est prévue le"],
    ou: ["Lieu", "Une ville, un quartier…"],
    qui: ["Personnes", "Personnes attendues"],
    quiSentence: (v) => `Nous attendons ${v} personnes.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date de l'action se pose",
    "Le déroulé de la journée se construit",
    "Bénévoles et partenaires s'organisent",
    "Le rétroplanning se déroule",
  ],
};

const artistique: Blueprint = {
  id: "artistique",
  label: "Projet artistique",
  universe: "Culture & Art",
  kind: "creation",
  titleFallback: "Votre projet artistique",
  pivotHour: 11,
  dayWord: "Sortie",
  roles: ["Direction artistique", "Studio / atelier", "Collaborateurs", "Technique", "Diffusion"],
  flow: [
    { key: "preparation", delta: -4, label: "Préparation", detail: "Dernière vérification des contenus." },
    { key: "sortie", delta: 0, label: "Sortie", detail: "Le projet est rendu public.", role: "Diffusion" },
    { key: "partage", delta: 3, label: "Partage", detail: "Réseaux, envois, retours." },
    { key: "rencontre", delta: 8, label: "Rencontre", detail: "Écoute, présentation ou vernissage." },
  ],
  retro: [
    { key: "intention", days: 210, label: "Écrire l'intention", detail: "Ce que le projet raconte." },
    { key: "maquettes", days: 180, label: "Maquettes / esquisses", detail: "Premières versions.", after: ["intention"] },
    { key: "collaborateurs", days: 150, label: "Réunir les collaborateurs", detail: "Qui fait quoi.", role: "Collaborateurs", after: ["intention"] },
    { key: "budget", days: 140, label: "Budget et financement", detail: "Autofinancement, aides, préventes.", after: ["maquettes"] },
    { key: "production", days: 90, label: "Production", detail: "Enregistrement, tournage, réalisation.", role: "Studio / atelier", after: ["collaborateurs", "budget"] },
    { key: "finition", days: 45, label: "Finitions", detail: "Mixage, montage, retouches.", role: "Technique", after: ["production"] },
    { key: "droits", days: 35, label: "Droits et dépôts", detail: "Déclarations et protections.", after: ["finition"] },
    { key: "diffusion", days: 21, label: "Plan de diffusion", detail: "Plateformes, galeries, dates.", role: "Diffusion", after: ["finition"] },
    { key: "annonce", days: 10, label: "Annonce publique", detail: "Teaser, visuels, presse.", after: ["diffusion"] },
    { key: "retours", days: -14, label: "Recueillir les retours", detail: "Public, pairs, presse." },
  ],
  questions: questions({
    quand: ["Sortie", "La date de sortie", "La sortie est prévue le"],
    ou: ["Où", "Studio, atelier, ville…"],
    qui: ["Équipe", "Nombre de personnes impliquées"],
    quiSentence: (v) => `Nous serons ${v} sur le projet.`,
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date de sortie se pose",
    "Les étapes de création s'enchaînent",
    "L'équipe trouve sa place",
    "Le rétroplanning se déroule",
  ],
};

const generique: Blueprint = {
  id: "generique",
  label: "Autre projet",
  universe: "Projet",
  kind: "projet",
  titleFallback: "Votre projet",
  pivotHour: 10,
  dayWord: "Date cible",
  roles: ["Lieu", "Intervenants", "Logistique", "Communication"],
  flow: [
    { key: "preparation", delta: -3, label: "Mise en place", detail: "Tout se prépare sur place." },
    { key: "ouverture", delta: 0, label: "Le moment prévu", detail: "Ce pour quoi le projet existe." },
    { key: "deroule", delta: 3, label: "Déroulé", detail: "Les temps qui suivent." },
    { key: "cloture", delta: 7, label: "Clôture", detail: "Fin et rangement." },
  ],
  retro: [
    { key: "intention", days: 120, label: "Poser l'intention", detail: "Ce que vous voulez obtenir." },
    { key: "budget", days: 100, label: "Fixer le budget", detail: "Ce que vous pouvez engager.", after: ["intention"] },
    { key: "lieu", days: 80, label: "Choisir le lieu", detail: "Disponibilité et conditions.", role: "Lieu", after: ["intention"] },
    { key: "equipe", days: 60, label: "Réunir les personnes", detail: "Qui participe et à quel titre.", role: "Intervenants", after: ["intention"] },
    { key: "preparation", days: 30, label: "Préparation", detail: "Matériel, contenus, logistique.", role: "Logistique", after: ["lieu", "equipe"] },
    { key: "annonce", days: 21, label: "Prévenir les participants", detail: "Invitation et informations pratiques.", role: "Communication", after: ["lieu"] },
    { key: "derniers", days: 5, label: "Derniers réglages", detail: "Déroulé et confirmations.", after: ["preparation"] },
    { key: "bilan", days: -14, label: "Bilan", detail: "Ce qui a marché, ce qui reste à faire." },
  ],
  questions: questions({
    quand: ["Date", "La date visée", "La date visée est le"],
    ou: ["Lieu", "Une ville, un lieu…"],
    qui: ["Personnes", "Nombre de personnes"],
  }),
  loadingSteps: [
    "Lecture de votre récit",
    "La date se pose sur la ligne de temps",
    "Les étapes du projet se construisent",
    "Les personnes trouvent leur place",
    "Le rétroplanning se déroule",
  ],
};

export const BLUEPRINTS: Blueprint[] = [
  mariage,
  celebration,
  concert,
  festival,
  spectacle,
  entreprise,
  voyage,
  association,
  artistique,
  generique,
];

/** Le type choisi (sous-univers) → le modèle de projet correspondant. */
const BY_SUB: Record<string, string> = {
  mariage: "mariage",
  anniversaire: "celebration",
  bapteme: "celebration",
  ceremonie: "celebration",
  naissance: "celebration",
  "fete-privee": "celebration",
  "evjf-evg": "celebration",
  concert: "concert",
  dj: "concert",
  "groupe-live": "concert",
  karaoke: "concert",
  festival: "festival",
  studio: "artistique",
  exposition: "spectacle",
  theatre: "spectacle",
  musee: "spectacle",
  artisanat: "artistique",
  cinema: "artistique",
  litterature: "artistique",
  voyage: "voyage",
  sejour: "voyage",
};

/** Modèle par défaut de chaque univers, quand le sous-univers n'a pas le sien. */
const BY_UNIVERSE: Record<string, string> = {
  evenement: "celebration",
  musique: "concert",
  culture: "spectacle",
  entreprise: "entreprise",
  lieux: "celebration",
  table: "celebration",
  image: "artistique",
  style: "generique",
  patrimoine: "generique",
  voyage: "voyage",
  lien: "generique",
  solidarite: "association",
};

export type ProjectType = {
  /** Identifiant stocké dans les réponses : « univers/sous-univers ». */
  id: string;
  label: string;
  universeSlug: string;
  universeLabel: string;
  blueprintId: string;
};

/** La liste proposée à l'accueil : tous les types réellement disponibles. */
export const PROJECT_TYPES: ProjectType[] = UNIVERSE_TREE.flatMap((u) =>
  u.subs.map((s) => ({
    id: `${u.slug}/${s.slug}`,
    label: s.label,
    universeSlug: u.slug,
    universeLabel: u.label,
    blueprintId: BY_SUB[s.slug] ?? BY_UNIVERSE[u.slug] ?? "generique",
  })),
);

export function projectTypeById(id?: string | null): ProjectType | null {
  if (!id) return null;
  return PROJECT_TYPES.find((t) => t.id === id) ?? null;
}

export function blueprintFor(typeId?: string | null): Blueprint {
  const type = projectTypeById(typeId);
  const bp = BLUEPRINTS.find((b) => b.id === (type?.blueprintId ?? "")) ?? generique;
  return bp;
}

/* ─────────────────────── Le moteur de construction ─────────────────────── */

export type BuildInput = {
  title?: string | null;
  /** Jour J à minuit (ms). */
  day: number;
  dayConfidence?: Confidence;
  city?: string | null;
  venue?: string | null;
  guests?: number | null;
  /** Heure du moment pivot, en heures décimales. */
  pivotH?: number | null;
  booked?: { role: string; name?: string; status?: WorldProvider["status"] }[];
  story?: string;
  now?: number;
  demo?: boolean;
  /**
   * Faits métier extensibles (registre de questions, clés snake_case).
   * Valeurs brutes ; `buildProject` les enveloppe en `Fact` (« confirme »,
   * source « récit ») — elles n'écrasent ni n'altèrent aucun slot canonique.
   */
  details?: Record<string, string | number | boolean>;
  /** Type choisi à l'accueil (« musique/concert »). */
  typeId?: string | null;
};

function slug(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/**
 * Place les étapes du rétroplanning en respectant le temps disponible et les
 * dépendances : rien avant aujourd'hui, rien après le jour J, et jamais une
 * étape avant celle dont elle dépend.
 */
export function scheduleRetro(
  steps: RetroStep[],
  day: number,
  now: number,
): Record<string, number> {
  const before = steps.filter((s) => s.days > 0);
  const maxDays = before.reduce((m, s) => Math.max(m, s.days), 1);
  const availableDays = Math.max(0, (day - now) / DAY);
  /* La date est proche : le rétroplanning se resserre au lieu de partir dans le passé. */
  const scale = availableDays > 0 && availableDays < maxDays ? availableDays / maxDays : 1;
  const minGap = Math.max(0.25, Math.min(1, (availableDays || 1) / Math.max(before.length, 1)));

  const at: Record<string, number> = {};
  const ordered = [...steps].sort((a, b) => b.days - a.days);

  for (const s of ordered) {
    if (s.days <= 0) {
      at[s.key] = day - s.days * DAY;
      continue;
    }
    let t = day - s.days * scale * DAY;
    if (scale < 1) t = Math.max(t, now + 0.2 * DAY);
    for (const dep of s.after ?? []) {
      const d = at[dep];
      if (d != null) t = Math.max(t, d + minGap * DAY);
    }
    at[s.key] = Math.min(t, day - 0.1 * DAY);
  }
  return at;
}

/** Un modèle + quelques informations → le monde complet du projet. */
export function buildProject(bp: Blueprint, input: BuildInput): WorldProject {
  const now = input.now ?? Date.now();
  const day = input.day;
  const pivot = input.pivotH ?? bp.pivotHour;
  const pivotKnown = input.pivotH != null;

  const cited = input.booked ?? [];
  const providers: WorldProvider[] = bp.roles.map((role) => {
    const hit = cited.find((c) => c.role === role);
    if (hit) {
      return {
        id: slug(role),
        role,
        ...(hit.name ? { name: hit.name } : {}),
        ...(input.city ? { city: input.city } : {}),
        status: hit.status ?? "reserve",
        confidence: "confirme" as Confidence,
        note: hit.name ? "Cité dans votre récit." : "Réservé, nom à préciser.",
      };
    }
    return {
      id: slug(role),
      role,
      ...(input.city ? { city: input.city } : {}),
      status: "a_rechercher" as const,
      confidence: "manquant" as Confidence,
      note: input.city
        ? `Personne n'est encore choisi — recherche possible autour de ${input.city}.`
        : "Personne n'est encore choisi.",
    };
  });

  const moments = bp.flow.map((f) => {
    const providerId = f.role ? slug(f.role) : undefined;
    const known = providers.find((p) => p.id === providerId);
    return {
      id: f.key,
      offsetH: pivot + f.delta,
      label: f.label,
      detail: f.detail,
      ...(known && known.status !== "a_rechercher" ? { providerId: known.id } : {}),
      ...(input.venue ? { location: input.venue } : {}),
      confidence:
        f.delta === 0 && pivotKnown ? ("confirme" as Confidence) : ("suggere" as Confidence),
    };
  });

  const planned = scheduleRetro(bp.retro, day, now);
  const tasks = bp.retro.map((r) => {
    const providerId = r.role ? slug(r.role) : undefined;
    const done = providerId
      ? providers.some((p) => p.id === providerId && p.status !== "a_rechercher")
      : false;
    return {
      id: r.key,
      label: r.label,
      detail: r.detail,
      at: planned[r.key] ?? day - r.days * DAY,
      ...(providerId ? { providerId } : {}),
      done,
      confidence: (done ? "confirme" : "suggere") as Confidence,
    };
  });

  const type = projectTypeById(input.typeId);

  const missing: string[] = [];
  if (!input.venue) missing.push("Le lieu n'est pas encore renseigné.");
  if (!input.guests) missing.push("Le nombre de personnes n'est pas encore connu.");
  if (!pivotKnown) missing.push(`L'heure du moment principal reste à confirmer.`);
  const open = providers.filter((p) => p.status === "a_rechercher");
  if (open.length) missing.push(`${open.length} places restent à pourvoir.`);
  /* Un budget déjà répondu n'est plus annoncé comme manquant. */
  if (input.details?.["budget"] == null)
    missing.push("Aucun budget n'a encore été posé sur les prestations.");

  return {
    id: bp.id,
    kind: type?.id.split("/")[1] ?? bp.kind,
    universe: type?.universeLabel ?? bp.universe,
    title: input.title?.trim() || (type ? `Votre ${type.label.toLowerCase()}` : bp.titleFallback),
    ...(input.city ? { subtitle: input.city } : {}),
    pivot: fact(day, input.dayConfidence ?? "confirme", "récit"),
    city: fact(input.city ?? null, input.city ? "confirme" : "manquant", "récit"),
    venue: fact(input.venue ?? null, input.venue ? "confirme" : "manquant", "récit"),
    guests: fact(input.guests ?? null, input.guests ? "confirme" : "manquant", "récit"),
    people: [],
    providers,
    moments,
    tasks,
    documents: [],
    payments: [],
    media: [],
    tracks: [],
    messages: [],
    reviews: [],
    intentions: input.story
      ? [{ id: "recit", text: input.story.trim(), at: Math.min(now, day - DAY) }]
      : [],
    /* Faits extensibles : joints au monde sans contredire aucun slot. */
    ...(input.details && Object.keys(input.details).length
      ? {
          details: Object.fromEntries(
            Object.entries(input.details).map(([k, v]) => [k, fact(v, "confirme", "récit")]),
          ),
        }
      : {}),
    missing,
    lifecycle: input.demo ? "demo" : "brouillon",
    demo: input.demo ?? false,
  };
}
