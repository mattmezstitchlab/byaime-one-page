/**
 * Le parcours d'accueil : une couche d'orchestration *pure* au-dessus du monde.
 *
 * Elle ne construit aucun modèle parallèle : chaque réponse devient du récit,
 * le récit est lu par `readStory` (ou par AIME), et la lecture alimente
 * `projectFromReading` → `buildWedding`. La ligne de temps reste dérivée du
 * `WorldProject` par `deriveTimeline`.
 */
import { readStory, projectFromReading, type DetailValue, type StoryReading } from "./parseStory";
import { PROJECT_TYPES, projectTypeById } from "./blueprints";
import { detailLabelFor, questionsFor } from "./questions";
import type { Confidence, WorldProject } from "./types";

/**
 * Réponses du parcours — registre ouvert (étape 4).
 *
 * Les clés sont celles du registre de questions (`QuestionSpec.key`, ex.
 * « quand », « immo-vente.role ») ; « type » porte le type de projet choisi
 * (« univers/domaine ») et « libre » le récit raconté d'un coup.
 * Les valeurs sont les réponses BRUTES, jamais des phrases reformatées :
 * une clé nouvelle (packs B/C, faits de domaine) traverse toute la chaîne
 * sans être écrasée ni transformée arbitrairement.
 */
export type JourneyAnswers = Partial<Record<string, string>>;

function clean(v?: string) {
  const t = (v ?? "").trim();
  return t.length ? t : null;
}

/** Les réponses deviennent un récit : une seule matière première pour AIME. */
export function storyFromAnswers(a: JourneyAnswers): string {
  const libre = clean(a["libre"]);
  const type = projectTypeById(a["type"] ?? null);
  if (libre) return type ? `${libre} (Projet : ${type.label}.)` : libre;
  const parts: string[] = [];
  if (type) parts.push(`C'est un projet de type ${type.label}.`);
  /* Chaque question renseignée parle avec ses propres mots — jamais ceux
     d'un mariage ou d'un événement supposé — dans l'ordre du registre. */
  const specs = questionsFor(a["type"] ?? null);
  for (const q of specs) {
    const v = clean(a[q.key]);
    if (!v) continue;
    const sentence = q.sentence(v).trim();
    if (sentence) parts.push(sentence);
  }
  /* Une réponse dont la clé n'est pas encore modélisée (pack futur, fait de
     domaine) n'est ni perdue ni reformattée : elle rejoint le récit telle
     quelle, après les phrases modélisées. */
  const known = new Set(["type", "libre", ...specs.map((q) => q.key)]);
  for (const key of Object.keys(a)) {
    if (known.has(key)) continue;
    const v = clean(a[key]);
    if (v) parts.push(v);
  }
  return parts.join(" ");
}

function titleCase(s: string) {
  return s
    .split(/\s+/)
    .map((w) => (w.length > 2 ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(" ")
    .trim();
}

const UNKNOWN = /^(je ne sais pas|aucune? id[ée]e|pas encore|on verra|\?)/i;

/** Une réponse « je ne sais pas encore » reste une donnée valide du monde. */
export function isUnknownAnswer(v?: string) {
  const t = clean(v);
  return !t || UNKNOWN.test(t);
}

/** Une valeur de fait : nombre si la question est numérique, sinon texte brut. */
function toDetail(raw: string, numeric: boolean): DetailValue {
  if (!numeric) return raw;
  const n = Number(raw);
  return Number.isFinite(n) && raw.trim() !== "" ? n : raw;
}

/**
 * Repérage local immédiat, complété par les réponses champ par champ.
 *
 * La distribution est déclarative : chaque question sait, via `mapsTo`, dans
 * quel slot du monde sa réponse atterrit (day/place/guests/budget/pivotH/
 * intention), et les faits de domaine (« detail:<clé> ») sont transportés
 * tels quels — clé stable, valeur brute, jamais d'écrasement.
 */
export function readingFromAnswers(a: JourneyAnswers, now = new Date()): StoryReading {
  const story = storyFromAnswers(a);
  const base = readStory(story, now);
  const details: Record<string, DetailValue> = {};

  const specs = questionsFor(a["type"] ?? null);
  const specKeys = new Set(specs.map((q) => q.key));

  for (const q of specs) {
    const raw = clean(a[q.key]);
    if (!raw || UNKNOWN.test(raw)) continue;
    switch (q.mapsTo) {
      case "day": {
        /* Date ISO (champ date) : plus fiable que le regex du récit. */
        if (base.day == null && /^\d{4}-\d{2}-\d{2}([T ].*)?$/.test(raw)) {
          const t = new Date(raw).getTime();
          if (!Number.isNaN(t)) base.day = t;
        }
        break;
      }
      case "place": {
        const isVenue = /(château|domaine|manoir|ferme|salle|grange|villa|mas)\b/i.test(raw);
        if (isVenue && !base.venue) base.venue = titleCase(raw);
        if (!isVenue && !base.city && raw.length < 40) base.city = titleCase(raw);
        break;
      }
      case "guests": {
        if (base.guests != null) break;
        const n = Number(raw);
        if (Number.isFinite(n) && raw.trim() !== "") {
          base.guests = n;
          break;
        }
        const m = raw.match(/(\d{1,4})/);
        if (m?.[1]) base.guests = Number(m[1]);
        break;
      }
      case "budget": {
        /* Le montant est conservé comme fait extensible, clé stable « budget ». */
        details["budget"] = toDetail(raw, true);
        break;
      }
      case "pivotH": {
        if (base.ceremonyH != null) break;
        const m = raw.match(/(\d{1,2})\s*(?:h|:)\s*(\d{2})?/i) ?? raw.match(/^(\d{1,2})$/);
        if (m?.[1]) {
          const h = Number(m[1]) + Number(m[2] ?? 0) / 60;
          if (h >= 0 && h <= 24) base.ceremonyH = h;
        }
        break;
      }
      case "intention": {
        /* L'intention voyage par le récit et les tons : rien de structurel ici. */
        break;
      }
      default: {
        /* detail:<clé> — fait métier transporté tel quel. */
        const key = q.mapsTo.slice("detail:".length);
        if (!(key in details)) details[key] = toDetail(raw, q.type === "number");
      }
    }
  }

  /* Une réponse préfixée « detail: » dont la clé n'est pas encore modélisée
     par le registre n'est ni perdue ni reformattée : elle rejoint les faits
     bruts, sans jamais écraser ce que le registre a déjà posé. */
  for (const key of Object.keys(a)) {
    if (key === "type" || key === "libre" || specKeys.has(key)) continue;
    if (!/^detail:[a-z][a-z0-9_]*$/.test(key)) continue;
    const raw = clean(a[key]);
    if (!raw || UNKNOWN.test(raw)) continue;
    const k = key.slice("detail:".length);
    if (!(k in details)) details[k] = raw;
  }

  if (Object.keys(details).length) base.details = details;
  return base;
}

/** Fusionne la lecture d'AIME (asynchrone) avec le repérage immédiat. */
export function mergeReading(base: StoryReading, ai: Partial<StoryReading> | null): StoryReading {
  if (!ai) return base;
  /* Faits extensibles : la réponse de l'utilisateur fait foi ; la lecture
     d'AIME ne peut que compléter les clés absentes, jamais réécrire. */
  const details = { ...(ai.details ?? {}), ...(base.details ?? {}) };
  return {
    day: ai.day ?? base.day,
    city: ai.city ?? base.city,
    venue: ai.venue ?? base.venue,
    guests: ai.guests ?? base.guests,
    ceremonyH: ai.ceremonyH ?? base.ceremonyH,
    couple: ai.couple ?? base.couple,
    booked: ai.booked?.length ? ai.booked : base.booked,
    ...(Object.keys(details).length ? { details } : {}),
  };
}

/** Les mots d'ambiance qu'AIME entend dans l'intention. */
const TONES: { re: RegExp; label: string }[] = [
  { re: /[ée]l[ée]gant|chic|raffin/i, label: "élégant" },
  { re: /champ[êe]tre|nature|ext[ée]rieur|plein air|jardin/i, label: "champêtre" },
  { re: /intim|petit comit[ée]|restreint/i, label: "intime" },
  { re: /festif|f[êe]te|dansant/i, label: "festif" },
  { re: /musique|musical|dj|groupe|live|playlist/i, label: "musical" },
  { re: /famil|enfants|parents/i, label: "familial" },
  { re: /boh[èe]me|folk/i, label: "bohème" },
  { re: /minimal|[ée]pur/i, label: "minimaliste" },
  { re: /gourmand|cuisine|repas|menu|traiteur/i, label: "gourmand" },
  { re: /la[ïi]que/i, label: "cérémonie laïque" },
];

export function toneTags(text?: string | null): string[] {
  const t = (text ?? "").trim();
  if (!t) return [];
  const out: string[] = [];
  for (const { re, label } of TONES) if (re.test(t) && !out.includes(label)) out.push(label);
  return out.slice(0, 6);
}

/** Moments qu'AIME peut proposer à partir de l'intention — jamais imposés. */
const EXTRA_MOMENTS: {
  re: RegExp;
  id: string;
  label: string;
  detail: string;
  offsetH: number;
}[] = [
  { re: /feu d'?artifice/i, id: "feu-artifice", label: "Feu d'artifice", detail: "À la nuit tombée, depuis la terrasse.", offsetH: 23 },
  { re: /brunch|lendemain/i, id: "brunch", label: "Brunch du lendemain", detail: "Des retrouvailles douces le matin suivant.", offsetH: 34 },
  { re: /photobooth|photomaton/i, id: "photobooth", label: "Photobooth", detail: "Un coin photo ouvert toute la soirée.", offsetH: 21 },
  { re: /vin d'?honneur/i, id: "vin-honneur", label: "Vin d'honneur", detail: "Entre la cérémonie et le dîner.", offsetH: 18 },
  { re: /surprise|discours des t[ée]moins/i, id: "surprise", label: "Surprise des témoins", detail: "Un moment préparé par vos proches.", offsetH: 22 },
];

export type JourneyProposal = { id: string; label: string; detail: string; offsetH: number };

export function proposedMoments(text?: string | null): JourneyProposal[] {
  const t = (text ?? "").trim();
  if (!t) return [];
  return EXTRA_MOMENTS.filter((m) => m.re.test(t)).map(({ id, label, detail, offsetH }) => ({
    id,
    label,
    detail,
    offsetH,
  }));
}

/**
 * Les réponses → le monde. Une seule source de vérité, construite par le
 * moteur existant (`buildWedding` via `projectFromReading`).
 */
export function projectFromJourney(
  a: JourneyAnswers,
  options: {
    ai?: Partial<StoryReading> | null;
    tones?: string[];
    moments?: JourneyProposal[];
    now?: number;
    /** Le parcours est commencé : le monde existe même sans aucune réponse. */
    force?: boolean;
  } = {},
): WorldProject | null {
  const story = storyFromAnswers(a);
  if (!story.trim() && !options.force) return null;
  const now = options.now ?? Date.now();
  const reading = mergeReading(readingFromAnswers(a, new Date(now)), options.ai ?? null);
  const project = projectFromReading(reading, story, now, a["type"] ?? null);

  const missing = [...project.missing];
  if (!reading.day) missing.unshift("La date n'est pas encore fixée — le déroulé reste indicatif.");
  if (!reading.city && !reading.venue) missing.unshift("La ville n'est pas encore connue.");

  const tones = options.tones ?? [];
  const intentions = [
    ...project.intentions,
    ...tones.map((label, i) => ({
      id: `ton-${i}-${label}`,
      text: `Ambiance ${label}`,
      at: Math.min(now, project.pivot.value - 2 * 86_400_000),
    })),
  ];

  const extra = (options.moments ?? []).map((m) => ({
    id: m.id,
    offsetH: m.offsetH,
    label: m.label,
    detail: m.detail,
    confidence: "suggere" as Confidence,
  }));

  return {
    ...project,
    intentions,
    moments: [...project.moments, ...extra],
    missing,
  };
}

/** La synthèse finale : ce qu'AIME a compris, en cinq regards + les
    précisions métier déclarées (details). Réponses métier C visibles
    (étape 12) : libellé humain du registre, jamais la clé technique. */
export function journeySummary(project: WorldProject) {
  const fmt = new Intl.DateTimeFormat("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Paris",
  });
  const pourvues = project.providers.filter((p) => p.status !== "a_rechercher").length;
  const typeId =
    PROJECT_TYPES.find((t) => t.id.endsWith("/" + project.kind))?.id ?? null;
  const details = Object.entries(project.details ?? {}).map(([key, f]) => ({
    label: detailLabelFor(key, typeId),
    value: String(f.value),
    confidence: f.confidence,
  }));
  return [
    {
      label: "Quand",
      value:
        project.pivot.confidence === "confirme"
          ? fmt.format(new Date(project.pivot.value))
          : "Date à définir",
      confidence: project.pivot.confidence,
    },
    {
      label: "Où",
      value: project.venue.value ?? project.city.value ?? "Lieu à définir",
      confidence: project.venue.value ? project.venue.confidence : project.city.confidence,
    },
    {
      label: "Qui",
      value: project.guests.value ? `${project.guests.value} personnes` : "Invités à estimer",
      confidence: project.guests.confidence,
    },
    /* Les précisions métier déclarées au parcours — une entrée par fait,
       au libellé humain du registre. Absens d'un domaine : rien n'apparaît. */
    ...details,
    {
      label: "Ce qui existe",
      value: pourvues
        ? `${pourvues} place${pourvues > 1 ? "s" : ""} pourvue${pourvues > 1 ? "s" : ""}`
        : "Tout reste à composer",
      confidence: (pourvues ? "confirme" : "manquant") as Confidence,
    },
    {
      label: "Ce qui est souhaité",
      value: project.intentions.length
        ? `${project.moments.length} moments, ${project.intentions.length} intentions`
        : "À raconter",
      confidence: (project.intentions.length ? "confirme" : "manquant") as Confidence,
    },
  ];
}
