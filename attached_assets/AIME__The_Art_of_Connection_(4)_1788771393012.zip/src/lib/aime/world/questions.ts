/**
 * Questions du parcours d'accueil — Vague 3.
 *
 * Ce module est la brique fondatrice du système de questions contextuelles :
 * le choix du Domaine (« univers/sous-univers ») décide des questions posées,
 * et chaque question déclare explicitement où sa réponse atterrit dans le
 * monde (`mapsTo`). Trois niveaux :
 *
 *   A — universelles : pertinentes pour presque tous les projets ;
 *   B — par Univers  : dépendant du grand domaine ;
 *   C — par Domaine  : spécifiques au choix final (1 à 3 maximum).
 *
 * ÉTAT (étape 9) : A + B + C sont actifs. Les packs C des 73 Domaines
 * privilégient la SUBSTITUTION (relibellage / replaces) ; tout ajout pur
 * dépassant le plafond 6 est en liste blanche documentée
 * (C_LONG_JOURNEY_DOMAINS). Chaque spéc métier C porte sa `phase` réfléchie
 * (avant = prépare / pendant = moment actif / apres = suivant) sauf les faits
 * honnêtement transversales (présentiel/visio…) — future donnée d'entrée des
 * capsules AVANT / PENDANT / APRÈS, sans moteur temporel construit ici.
 */

import { UNIVERSE_TREE } from "@/lib/aime/universeTree";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

/** Niveau de spécialisation d'une question. */
export type QuestionLevel = "A" | "B" | "C";

/**
 * Où la réponse atterrit dans le monde.
 *
 * Slots canoniques : « day » (jour pivot), « place » (ville/lieu), « guests »
 * (nombre de personnes), « budget » (montant €), « pivotH » (heure du moment
 * principal), « intention » (récit d'ambiance, alimente tons et moments
 * proposés).
 *
 * Slots étendus : « detail:<clé> » — faits métier de domaine. Les clés sont
 * stables, en snake_case, nommées explicitement et documentées : un même sens
 * = une même clé réutilisée entre Domaines (jamais de fourre-tout).
 */
export type QuestionMapsTo =
  | "day"
  | "place"
  | "guests"
  | "budget"
  | "pivotH"
  | "intention"
  | `detail:${string}`;

/** La forme d'une réponse dans la barre du héros. */
export type QuestionInputType = "date" | "text" | "number" | "choice";

/**
 * Phase temporelle du projet qu'une donnée nourrit en priorité.
 *
 * CONTRAINTE DE CONCEPTION (temporalité — héros, capsule AVANT/PENDANT/
 * APRÈS) : ce champ est documentaire à ce stade. Aucun moteur temporel ne le
 * consomme encore ; il garantit que les packs B/C (et les `detail:<clé>`
 * sémantiques et réutilisables) pensent chaque information en termes de
 * préparation / moment / suivi, pour que les mêmes réponses puissent plus
 * tard alimenter la Timeline, le Héros et les archives des 73 Domaines.
 */
export type QuestionPhase = "avant" | "pendant" | "apres";

export type QuestionSpec = {
  /** Clé stable, unique dans la séquence posée (ex. « quand », « immo-vente.role »). */
  key: string;
  /** Niveau de spécialisation : universelle, Univers, Domaine. */
  level: QuestionLevel;
  /** Le mot affiché sur le bouton, la pastille et le récap. */
  label: string;
  /** La formulation posée à l'utilisateur. */
  question: string;
  /** Aide affichée sous la question (optionnelle). */
  hint?: string;
  /** Exemple de saisie dans le champ. */
  placeholder: string;
  type: QuestionInputType;
  /** Propositions, obligatoires quand type = « choice ». */
  choices?: string[];
  mapsTo: QuestionMapsTo;
  /** Phase que la donnée alimente principalement (voir QuestionPhase). */
  phase?: QuestionPhase;
  /**
   * Cette question remplace une question plus générale dans la séquence
   * (ex. « couverts » remplace « personnes » pour un traiteur) : la question
   * remplacée n'est pas posée. Utilisé par les packs C.
   */
  replaces?: string;
  /** La réponse devient une phrase du récit lu par AIME. Jamais d'invention. */
  sentence: (value: string) => string;
};

/* ------------------------------------------------------------------ */
/* Validation (utilisée par les tests et les futurs packs B/C)         */
/* ------------------------------------------------------------------ */

const KEY_RE = /^[a-z][a-z0-9-]*(\.[a-z][a-z0-9-]*)?$/;
const DETAIL_RE = /^detail:[a-z][a-z0-9_]*$/;
const CANONICAL: readonly string[] = ["day", "place", "guests", "budget", "pivotH", "intention"];

/**
 * Les problèmes d'une question, sous forme de textes (vide = valide).
 * Reste pure : n'importe quel pack peut être validé avant d'entrer en service.
 */
export function validateQuestionSpec(q: QuestionSpec): string[] {
  const problems: string[] = [];
  if (!KEY_RE.test(q.key)) problems.push(`key invalide : « ${q.key} »`);
  if (!q.label.trim()) problems.push("label vide");
  if (!q.question.trim()) problems.push("question vide");
  if (!q.placeholder.trim()) problems.push("placeholder vide");
  if (!CANONICAL.includes(q.mapsTo) && !DETAIL_RE.test(q.mapsTo))
    problems.push(`mapsTo invalide : « ${q.mapsTo} »`);
  if (q.type === "choice" && !(q.choices && q.choices.length >= 2))
    problems.push("type « choice » sans au moins 2 choix");
  if (q.type !== "choice" && q.choices?.length) problems.push("choices présents sans type « choice »");
  if (q.replaces && !KEY_RE.test(q.replaces)) problems.push(`replaces invalide : « ${q.replaces} »`);
  if (q.phase && !["avant", "pendant", "apres"].includes(q.phase))
    problems.push(`phase invalide : « ${q.phase} »`);
  try {
    if (typeof q.sentence("exemple") !== "string") problems.push("sentence ne produit pas de texte");
  } catch {
    problems.push("sentence lève une erreur");
  }
  return problems;
}

/* ------------------------------------------------------------------ */
/* Le socle universel (niveau A)                                       */
/* ------------------------------------------------------------------ */

/**
 * Une date n'est mise en forme que si elle est réellement une date ISO
 * (champ `type="date"`) : `new Date` tolère presque tout
 * (« au printemps 2028 » → 1er janvier 2028), ce qui mentirait dans le récit.
 */
function formatDate(value: string): string {
  if (!/^\d{4}-\d{2}-\d{2}([T ].*)?$/.test(value.trim())) return value;
  const d = new Date(value);
  return Number.isNaN(d.getTime())
    ? value
    : d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

/**
 * Les cinq questions universelles, dans l'ordre posé par défaut.
 * Jamais toutes obligatoires : le parcours n'est bloquant pour aucune.
 */
export const A_PACK: readonly QuestionSpec[] = Object.freeze([
  {
    key: "quand",
    level: "A",
    label: "Quand",
    question: "Quand est-ce prévu ?",
    hint: "Une date, une saison, une échéance : ce que vous savez aujourd'hui suffit.",
    placeholder: "Le 14 août 2027, ou « au printemps 2028 »",
    type: "date",
    mapsTo: "day",
    /* Le pivot du projet : c'est lui qui fera basculer AVANT vers PENDANT. */
    phase: "pendant",
    sentence: (v) => {
      const f = formatDate(v);
      /* Date libre (« au printemps 2028 ») : pas de « le » maladroit devant. */
      return f === v ? `La date visée : ${v}.` : `La date visée est le ${f}.`;
    },
  },
  {
    key: "ou",
    level: "A",
    label: "Où",
    question: "Où se situe votre projet ?",
    hint: "Une ville, un quartier, une adresse, un lieu précis.",
    placeholder: "Lille, un quartier, une adresse…",
    type: "text",
    mapsTo: "place",
    /* Le lieu est un ancrage du moment (et des recherches en préparation). */
    phase: "pendant",
    /* La phrase du récit est rédigée (le repérage lit la réponse brute,
       stockée séparément — jamais cette phrase). */
    sentence: (v) => `Le projet se situe à ${v}.`,
  },
  {
    key: "qui",
    level: "A",
    label: "Personnes",
    question: "Combien de personnes sont concernées ?",
    hint: "Un ordre de grandeur suffit, pas une liste.",
    placeholder: "Nombre de personnes, même approximatif",
    type: "number",
    mapsTo: "guests",
    /* Dimensionne les préparatifs (jauge, capacités, priorisations). */
    phase: "avant",
    sentence: (v) => `Ce projet réunit environ ${v} personnes.`,
  },
  {
    key: "budget",
    level: "A",
    label: "Budget",
    question: "Quel budget envisagez-vous ?",
    hint: "Un ordre de grandeur suffit : tout reste ajustable.",
    placeholder: "Budget en euros",
    type: "number",
    mapsTo: "budget",
    /* Conditionne les décisions et les ressources à obtenir en amont. */
    phase: "avant",
    sentence: (v) => `Le budget est d'environ ${v} €.`,
  },
  {
    key: "intention",
    level: "A",
    label: "Envie",
    question: "Comment l'imaginez-vous ?",
    hint: "Une ambiance, une priorité, un souhait : en quelques mots.",
    placeholder: "Simple et chaleureux, en plein air, sans stress…",
    type: "text",
    mapsTo: "intention",
    /* Guide la préparation (et, plus tard, la façon de raconter l'APRÈS). */
    phase: "avant",
    /* L'envie est relue mot pour mot (tons, moments proposés) : brute aussi. */
    sentence: (v) => v,
  },
]);

export const A_PACK_BY_KEY: Readonly<Record<string, QuestionSpec>> = Object.freeze(
  Object.fromEntries(A_PACK.map((q) => [q.key, q])),
);

/* ------------------------------------------------------------------ */
/* Packs B — le contexte général de chacun des 12 univers              */
/* ------------------------------------------------------------------ */

/**
 * Relibellage d'une question du socle A : même `key`, mêmes `mapsTo` et
 * `sentence` — seules la formulation, le label ou l'aide sont adaptés à
 * l'univers. La compatibilité des réponses est donc structurelle (le chip,
 * le récit et le monde lisent la même valeur brute au même endroit), et le
 * remplacement se fait « en place » par `composeQuestions`, à la position
 * de la question d'origine.
 */
function relabel(
  key: string,
  patch: Pick<QuestionSpec, "question"> & Partial<QuestionSpec>,
): QuestionSpec {
  const base = A_PACK_BY_KEY[key];
  if (!base) throw new Error(`Question A inconnue : ${key}`);
  return { ...base, ...patch, key: base.key, level: "B" };
}

/**
 * Le contexte que chaque univers apporte au parcours. Règles :
 *
 *  - Un pack B reformule le socle (relibellage) et n'ajoute AU MAXIMUM
 *    qu'une question — plafond UX de 6 respecté pour les 12 univers
 *    (dépassement exceptionnel seulement, et documenté : aucun à ce jour).
 *  - Toute clé `detail:*` est stable, snake_case, sémantique et réutilisée
 *    dès que le sens est le même (« cadre », « occasion ») — jamais de
 *    fourre-tout : ces faits alimenteront le Héros, la Timeline et les
 *    archives AVANT / PENDANT / APRÈS de tous les Domaines.
 *  - Les spécificités d'un Domaine (« couverts » du traiteur, « duration »
 *    d'un séjour…) relèvent du pack C, pas d'ici.
 */
const B_PACKS = {
  evenement: Object.freeze([
    relabel("quand", {
      question: "Quand aura lieu l'événement ?",
      hint: "Une date, une saison : ce que vous savez aujourd'hui suffit.",
    }),
    relabel("qui", {
      question: "Combien de personnes seront invitées ?",
      hint: "Un ordre de grandeur suffit : convives, familles, amis.",
      placeholder: "Nombre d'invités, même approximatif",
    }),
    {
      key: "moment-journee",
      level: "B",
      label: "Moment",
      question: "À quel moment de la journée ?",
      hint: "Cela aide AIME à esquisser le déroulé.",
      placeholder: "Choisissez un moment",
      type: "choice",
      choices: ["le matin", "l'après-midi", "en soirée", "toute la journée"],
      mapsTo: "detail:partie_journee",
      /* Ce fait alimente le déroulé (PENDANT), pas les préparatifs. */
      phase: "pendant",
      sentence: (v) => `Le moment visé : ${v}.`,
    },
  ]),
  musique: Object.freeze([
    relabel("quand", {
      question: "Quand aura lieu le projet ?",
      hint: "Concert, date de sortie, session : ce que vous savez suffit.",
    }),
    relabel("qui", {
      question: "Combien de personnes au total ?",
      hint: "Public, artistes et équipe confondus : un ordre de grandeur.",
    }),
    {
      key: "cadre",
      level: "B",
      label: "Cadre",
      question: "Dans quel cadre ce projet se fera-t-il ?",
      placeholder: "Choisissez le cadre",
      type: "choice",
      /* Les deux choix du socle « privé/public » sont alignés sur la culture
         (même valeur = même chaîne) ; la variante métier est autorisée. */
      choices: [
        "en événement privé",
        "au public, en accès libre",
        "au public, en billetterie",
        "en studio ou en répétition",
      ],
      mapsTo: "detail:cadre",
      /* Cadre privé / public — même sens que la culture, même clé. */
      phase: "avant",
      sentence: (v) => `Le projet se fera ${v}.`,
    },
  ]),
  culture: Object.freeze([
    relabel("qui", {
      question: "Combien de personnes attendez-vous ?",
      hint: "Visiteurs, spectateurs, participants : un ordre de grandeur.",
    }),
    relabel("budget", {
      question: "Quel budget ou financement envisagez-vous ?",
      hint: "Subvention, billetterie, mécénat : un ordre de grandeur suffit.",
    }),
    {
      key: "cadre",
      level: "B",
      label: "Cadre",
      question: "Dans quel cadre ce projet se fera-t-il ?",
      placeholder: "Choisissez le cadre",
      type: "choice",
      choices: [
        "au public, en accès libre",
        "au public, en billetterie",
        "sur invitation seulement",
        "en création ou en résidence",
      ],
      mapsTo: "detail:cadre",
      phase: "avant",
      sentence: (v) => `Le projet se fera ${v}.`,
    },
  ]),
  entreprise: Object.freeze([
    relabel("quand", {
      question: "À quelle échéance cela doit-il aboutir ?",
      hint: "Une date butoir, un jalon : si approximatif, dites-le ainsi.",
      placeholder: "Le 14 août 2027, ou « avant fin 2027 »",
    }),
    relabel("qui", {
      question: "Combien de personnes y participent ?",
      hint: "Collaborateurs, invités, prestataires confondus.",
    }),
    {
      key: "audience",
      level: "B",
      label: "Audience",
      question: "Pour qui ce projet est-il organisé ?",
      placeholder: "Choisissez l'audience",
      type: "choice",
      choices: [
        "en interne, avec nos équipes",
        "avec des clients ou partenaires",
        "en mixte, interne et externe",
      ],
      mapsTo: "detail:audience",
      phase: "avant",
      sentence: (v) => `Ce projet est pensé ${v}.`,
    },
  ]),
  lieux: Object.freeze([
    relabel("ou", {
      question: "Où se situe ce lieu ?",
      hint: "Ville, adresse — ou secteur de recherche s'il n'est pas arrêté.",
    }),
    relabel("qui", {
      question: "Combien de personnes devrait-il accueillir ?",
      hint: "La jauge visée, même approximative.",
    }),
    {
      key: "usage",
      level: "B",
      label: "Usage",
      question: "Quel usage en attendez-vous ?",
      placeholder: "Choisissez l'usage",
      type: "choice",
      choices: [
        "pour une réception ou un événement",
        "pour un séjour ou de l'hébergement",
        "pour une production (tournage, shooting)",
        "pour une activité récurrente",
      ],
      mapsTo: "detail:usage",
      phase: "avant",
      sentence: (v) => `Le lieu sera utilisé ${v}.`,
    },
  ]),
  table: Object.freeze([
    relabel("qui", {
      label: "Couverts",
      question: "Combien de couverts faudra-t-il servir ?",
      hint: "Un ordre de grandeur suffit.",
      placeholder: "Nombre de couverts, même approximatif",
      sentence: (v) => `Il faudra servir environ ${v} couverts.`,
    }),
    {
      key: "service",
      level: "B",
      label: "Service",
      question: "Comment le service sera-t-il rendu ?",
      placeholder: "Choisissez le mode de service",
      type: "choice",
      choices: [
        "sur place, en production propre",
        "en prestation, chez le client ou sur un événement",
        "en vente à emporter",
        "en dégustation ou en boutique",
      ],
      mapsTo: "detail:service",
      phase: "avant",
      sentence: (v) => `Le service se fera ${v}.`,
    },
  ]),
  image: Object.freeze([
    relabel("quand", {
      question: "À quelle date la prestation ?",
      hint: "Date de prise de vue, tournage, livraison : ce que vous savez.",
    }),
    {
      key: "occasion",
      level: "B",
      label: "Occasion",
      question: "À quel occasion répond cette prestation ?",
      placeholder: "Choisissez l'occasion",
      type: "choice",
      choices: [
        "pour un événement (mariage, fête…)",
        "pour un projet professionnel",
        "pour une création ou une série",
        "en mission récurrente",
      ],
      mapsTo: "detail:occasion",
      /* Même sens que le style : même clé, mêmes choix, même phrase. */
      phase: "avant",
      sentence: (v) => `La prestation est prévue ${v}.`,
    },
  ]),
  style: Object.freeze([
    relabel("ou", {
      question: "Où souhaitez-vous la prestation ?",
      hint: "Un salon, un domicile, un lieu dédié : précisez la ville.",
    }),
    relabel("qui", {
      question: "Combien de personnes seront préparées ?",
      hint: "Une seule personne ou toute une tablée : un ordre de grandeur.",
    }),
    {
      key: "occasion",
      level: "B",
      label: "Occasion",
      question: "À quel occasion répond cette prestation ?",
      placeholder: "Choisissez l'occasion",
      type: "choice",
      choices: [
        "pour un événement (mariage, fête…)",
        "pour un projet professionnel",
        "pour une création ou une série",
        "en mission récurrente",
      ],
      mapsTo: "detail:occasion",
      phase: "avant",
      sentence: (v) => `La prestation est prévue ${v}.`,
    },
  ]),
  patrimoine: Object.freeze([
    relabel("quand", {
      question: "Quelle échéance visez-vous ?",
      hint: "Mise en vente, remise des clés, démarrage des travaux…",
    }),
    relabel("budget", {
      question: "Quelle enveloppe envisagez-vous ?",
      hint: "Achat, loyer, travaux : un ordre de grandeur, tout ajustable.",
    }),
    {
      key: "operation",
      level: "B",
      label: "Opération",
      question: "Quelle opération envisagez-vous ?",
      placeholder: "Choisissez l'opération",
      type: "choice",
      choices: [
        "une vente ou une acquisition",
        "une location longue durée",
        "une mise à disposition ou un prêt",
        "une mise en valeur ou un entretien",
      ],
      mapsTo: "detail:operation",
      phase: "avant",
      sentence: (v) => `L'opération envisagée : ${v}.`,
    },
  ]),
  voyage: Object.freeze([
    /* Cas d'école du mécanisme replaces : pour un voyage, « où se situe le
       projet » devient « où voulez-vous aller » — nouvelle clé, même slot
       canonique « place » (la réponse reste lue exactement comme avant),
       position de la question remplacée conservée. */
    {
      key: "destination",
      replaces: "ou",
      level: "B",
      label: "Destination",
      question: "Où voulez-vous aller ?",
      hint: "Une ville, un pays, une région — même vague.",
      placeholder: "Portugal, Vercors, Tokyo…",
      type: "text",
      mapsTo: "place",
      phase: "pendant",
      sentence: (v) => `La destination : ${v}.`,
    },
    relabel("qui", {
      label: "Voyageurs",
      question: "Combien de voyageurs ?",
      hint: "Tous comptés, même approximatif.",
      placeholder: "Nombre de voyageurs",
      sentence: (v) => `Le groupe compte environ ${v} voyageurs.`,
    }),
    {
      key: "mobilite",
      level: "B",
      label: "Déplacement",
      question: "Comment voyagerez-vous ?",
      placeholder: "Choisissez le mode de déplacement",
      type: "choice",
      choices: [
        "en voiture",
        "en train ou en transports en commun",
        "en avion",
        "en itinérance (à pied, à vélo)",
        "en combinant plusieurs moyens",
      ],
      mapsTo: "detail:mobilite",
      phase: "avant",
      sentence: (v) => `Le déplacement se fera ${v}.`,
    },
  ]),
  lien: Object.freeze([
    relabel("quand", {
      question: "Quand démarrer, et à quel rythme ?",
      hint: "Une date de début, un rythme visé : libre.",
      placeholder: "Une date, un mois, « chaque semaine »…",
      type: "text",
    }),
    relabel("qui", {
      question: "Combien de personnes sont visées ?",
      hint: "Personnes accompagnées, membres visés : un ordre de grandeur.",
    }),
    {
      key: "cadre-relation",
      level: "B",
      label: "Rencontres",
      question: "Quel cadre de lien recherchez-vous ?",
      placeholder: "Choisissez le cadre",
      type: "choice",
      choices: [
        "des rencontres individuelles",
        "un petit cercle",
        "une communauté plus large",
        "un réseau professionnel",
      ],
      mapsTo: "detail:cadre_relation",
      phase: "avant",
      sentence: (v) => `Le cadre visé : ${v}.`,
    },
  ]),
  solidarite: Object.freeze([
    relabel("qui", {
      question: "Combien de personnes seront mobilisées ou touchées ?",
      hint: "Bénévoles et bénéficiaires confondus : un ordre de grandeur.",
    }),
    relabel("budget", {
      question: "Quel budget ou quelles ressources ?",
      hint: "Fonds, matériel, subventions : tout reste ajustable.",
    }),
    {
      key: "beneficiaires",
      level: "B",
      label: "Bénéficiaires",
      question: "À qui s'adressera l'action ?",
      placeholder: "Choisissez les bénéficiaires",
      type: "choice",
      choices: [
        "des personnes (isolement, accès, précarité…)",
        "des animaux ou de la nature",
        "un quartier ou un territoire",
        "un public précis (jeunes, seniors, sportifs…)",
      ],
      mapsTo: "detail:beneficiaires",
      phase: "avant",
      sentence: (v) => `L'action s'adressera à ${v}.`,
    },
  ]),
} satisfies Record<string, readonly QuestionSpec[]>;

export const B_PACK_BY_UNIVERSE: Readonly<Record<string, readonly QuestionSpec[]>> =
  Object.freeze(B_PACKS);

/* ------------------------------------------------------------------ */
/* Packs C — le propre de chacun des 73 Domaines                       */
/* ------------------------------------------------------------------ */

/**
 * Spécification d'une question telle qu'elle serait posée avant le pack C
 * (socle A, le cas échéant relibellée par le pack B de l'univers).
 */
function currentSpec(universe: string, key: string): QuestionSpec {
  const b = (B_PACK_BY_UNIVERSE[universe] ?? []).find((q) => q.key === key);
  const base = b ?? A_PACK_BY_KEY[key];
  if (!base) throw new Error(`Question introuvable : ${universe}.${key}`);
  return base;
}

/**
 * Relibellage Domaine d'une question existante : même clé, même slot —
 * seuls la formulation, les choix ou la phrase sont spécialisés ; la
 * position est conservée (substitution en place par composeQuestions).
 */
function cRelabel(
  universe: string,
  key: string,
  patch: Partial<QuestionSpec>,
): QuestionSpec {
  return { ...currentSpec(universe, key), ...patch, key, level: "C" };
}

/**
 * DOMAINS À 7 QUESTIONS — liste blanche des dépassements du plafond 6,
 * chacun justifié par une information métier que la composition ne peut
 * pas remplacer sans renoncer à une donnée plus générale :
 *
 *  - detail:regimes (4 Domaines table) : allergies et régimes = obligation
 *    de préparation (sécurité, commandes, affichage) — phase `avant` ;
 *  - detail:livrables (photographe, vidéaste) : ce qui sera remis après la
 *    prestation — profil `apres` (premier fait APRÈS du registre) ;
 *  - detail:duree (hébergement, séjour de groupe) : la durée dimensionne
 *    toutes les réservations — phase `avant`.
 *
 * Toute nouvelle entrée doit être justifiée pareillement (faire jouer
 * `replaces` en priorité) : le test de cette liste échoue sinon.
 */
export const C_LONG_JOURNEY_DOMAINS: readonly string[] = Object.freeze([
  "table/traiteur",
  "table/chef",
  "table/food-truck",
  "table/patisserie",
  "image/photographe",
  "image/videaste",
  "voyage/hebergement",
  "voyage/sejour-groupe",
]);

export const C_PACK_BY_DOMAIN: Readonly<Record<string, readonly QuestionSpec[]>> = Object.freeze(
  Object.fromEntries([
    /* ---------------------- evenement (7) ---------------------- */
    /* Le « moment » se précise domaine par domaine : la chronologie (le
       moment-journee B) cède sa place au moment-cœur — même mécanisme
       replaces, clé stable `detail:moment_coeur`. Phase `pendant` :
       ce fait écrit le déroulé ; le cadrage préparatoire en découle. */
    ...(
      [
        ["evenement/mariage", ["la cérémonie", "le vin d'honneur", "le dîner", "la première danse"]],
        ["evenement/anniversaire", ["le gâteau et les bougies", "la surprise", "les retrouvailles", "la piste de danse"]],
        ["evenement/bapteme", ["la cérémonie", "le vin d'honneur", "le repas de famille"]],
        ["evenement/ceremonie", ["l'entrée solennelle", "l'échange ou le discours", "la réception ou le vin d'honneur"]],
        ["evenement/naissance", ["l'annonce aux proches", "le retour à la maison", "la journée d'accueil du nouveau-né"]],
        ["evenement/fete-privee", ["l'accueil des invités", "le repas", "la fin de soirée dansante"]],
        ["evenement/evjf-evg", ["les défis et activités", "la soirée finale", "le déplacement"]],
      ] as const
    ).map(
      ([domain, choices]): [string, readonly QuestionSpec[]] => [
        domain,
        [
          {
            key: "moment-coeur",
            replaces: "moment-journee",
            level: "C",
            label: "Moment",
            question: "Lequel de ces moments compte le plus ?",
            hint: "AIME le traitera comme le cœur du déroulé.",
            placeholder: "Choisissez le moment",
            type: "choice",
            choices: [...choices],
            mapsTo: "detail:moment_coeur",
            phase: "pendant",
            sentence: (v) => `Le moment qui compte le plus : ${v}.`,
          },
        ],
      ],
    ),

    /* ----------------------- musique (6) ----------------------- */
    /* Le « cadre » univers se précise par format réel du métier : même clé
       (même sens : contexte d'exercice), choix métier, phase héritée. */
    ...(
      [
        ["musique/concert", ["en salle dédiée", "en plein air ou en festival", "en soirée privée", "en itinérance (bars, rue)"]],
        ["musique/dj", ["en club ou en festival", "en soirée privée", "aux mariages et réceptions", "en direct (radio, stream)"]],
        ["musique/festival", ["en plein air", "sur plusieurs scènes", "en salle dédiée", "en format hybride"]],
        ["musique/groupe-live", ["sur scènes et en salles", "aux mariages et privés", "en bars et pubs", "en concerts et tournées"]],
        ["musique/karaoke", ["en soirées privées", "en bars et pubs", "aux événements d'entreprise"]],
        ["musique/studio", ["en enregistrement studio pro", "en home studio", "en captation de concert"]],
      ] as const
    ).map(
      ([domain, choices]): [string, readonly QuestionSpec[]] => [
        domain,
        [
          cRelabel("musique", "cadre", {
            question: "Dans quel format ce projet se fera-t-il ?",
            choices: [...choices],
          }),
        ],
      ],
    ),

    /* ----------------------- culture (6) ----------------------- */
    ["culture/exposition", [
      cRelabel("culture", "qui", {
        question: "Quelle fréquentation attendez-vous ?",
        hint: "Visiteurs cumulés sur la période : un ordre de grandeur.",
      }),
      cRelabel("culture", "cadre", {
        choices: ["au public, en billetterie", "au public, en accès libre", "sur invitation, vernissage privé"],
      }),
    ]],
    ["culture/theatre", [
      cRelabel("culture", "quand", {
        question: "Quand aura lieu la première ?",
        hint: "Date de la première représentation : les suivantes s'ajouteront.",
      }),
      cRelabel("culture", "cadre", {
        choices: ["des représentations en salle", "une tournée", "au public, en accès libre", "en troupe amateure"],
      }),
    ]],
    ["culture/musee", [
      cRelabel("culture", "quand", {
        question: "Quand ouvrira-t-il au public ?",
        hint: "L'ouverture fixe le reste de la programmation.",
      }),
      cRelabel("culture", "qui", {
        question: "Quelle fréquentation attendez-vous ?",
        hint: "Visiteurs annuels ou par période : un ordre de grandeur.",
      }),
    ]],
    ["culture/artisanat", [
      cRelabel("culture", "ou", {
        question: "Où se trouvera l'atelier ou la boutique ?",
        hint: "Ville, quartier : l'ancrage compte pour ce métier.",
      }),
    ]],
    ["culture/cinema", [
      cRelabel("culture", "quand", {
        question: "Quelle date visez-vous pour la sortie ?",
        hint: "Sortie salle, diffusion, festival : une échéance suffit.",
      }),
      cRelabel("culture", "budget", {
        question: "Quel financement envisagez-vous ?",
        hint: "Production, coproduction, subventions : un ordre de grandeur.",
      }),
    ]],
    ["culture/litterature", [
      cRelabel("culture", "quand", {
        question: "Quelle date visez-vous pour la parution ?",
        hint: "Un mois, une rentrée : cela suffit pour planifier.",
      }),
      cRelabel("culture", "budget", {
        question: "Quel financement envisagez-vous ?",
        hint: "Édition, autopublication, mécénat : un ordre de grandeur.",
      }),
    ]],

    /* ---------------------- entreprise (6) ---------------------- */
    ["entreprise/seminaire", [
      cRelabel("entreprise", "quand", { question: "Quand aura lieu le séminaire ?", hint: "Dates ou période visée." }),
      cRelabel("entreprise", "qui", {
        question: "Combien de collaborateurs sont concernés ?",
        hint: "Une équipe, un site, toute l'entreprise : un ordre de grandeur.",
      }),
    ]],
    ["entreprise/team-building", [
      cRelabel("entreprise", "qui", { question: "Combien de personnes, toute l'équipe ?", hint: "Un ordre de grandeur suffit." }),
      cRelabel("entreprise", "intention", {
        question: "Quel objectif visez-vous ?",
        hint: "Cohésion, célébration, souffle : en quelques mots.",
      }),
    ]],
    ["entreprise/lancement", [
      cRelabel("entreprise", "quand", { question: "Quand aura lieu le lancement ?", hint: "La date publique, telle que prévue aujourd'hui." }),
      cRelabel("entreprise", "budget", {
        question: "Quelle enveloppe pour le lancement ?",
        hint: "Communication, événement, production : un ordre de grandeur.",
      }),
    ]],
    ["entreprise/coworking", [
      cRelabel("entreprise", "quand", { question: "Quand visez-vous l'ouverture ?", hint: "Premier jour ou période d'accueil." }),
      cRelabel("entreprise", "qui", {
        question: "Combien de personnes y travailleront ?",
        hint: "Résidents et passage confondus : un ordre de grandeur.",
      }),
    ]],
    ["entreprise/formation", [
      cRelabel("entreprise", "quand", { question: "Quand aura lieu la première session ?", hint: "Session de lancement ; le cycle suivra." }),
      cRelabel("entreprise", "qui", {
        question: "Combien d'apprenants viserez-vous ?",
        hint: "Par session ou en cumulé : un ordre de grandeur.",
      }),
    ]],
    ["entreprise/salon", [
      cRelabel("entreprise", "quand", { question: "Quand se tiendra le salon ?", hint: "Dates du salon, même encore souples." }),
      cRelabel("entreprise", "qui", {
        question: "Combien de personnes viserez-vous ?",
        hint: "Visiteurs et exposants confondus.",
        sentence: (v) => `Le salon réunira environ ${v} personnes.`,
      }),
    ]],

    /* ------------------------ lieux (6) ------------------------ */
    ["lieux/salle", [
      cRelabel("lieux", "qui", {
        question: "Quelle capacité de salle visez-vous ?",
        hint: "Places assises ou jauge totale : un ordre de grandeur.",
      }),
    ]],
    ["lieux/chateau", [
      cRelabel("lieux", "qui", {
        question: "Combien de personnes le château pourra-t-il accueillir ?",
        hint: "Réceptions et couchages : un ordre de grandeur.",
      }),
    ]],
    ["lieux/domaine", [
      cRelabel("lieux", "qui", {
        question: "Combien de personnes le domaine pourra-t-il accueillir ?",
        hint: "Capacité sur le terrain et couchages confondus.",
      }),
    ]],
    ["lieux/rooftop", [
      cRelabel("lieux", "qui", {
        question: "Combien de personnes le rooftop pourra-t-il accueillir ?",
        hint: "Jauge utile, sécurité comprise.",
      }),
    ]],
    ["lieux/jardin", [
      cRelabel("lieux", "qui", {
        question: "Combien de personnes le jardin pourra-t-il accueillir ?",
        hint: "Réceptions de plein air : un ordre de grandeur.",
      }),
    ]],
    ["lieux/chapiteau", [
      cRelabel("lieux", "qui", {
        question: "Quelle jauge sous le chapiteau ?",
        hint: "Montage, chauffage et sécurité s'en déduisent.",
      }),
    ]],

    /* ------------------------ table (6) ------------------------ */
    /* detail:regimes — allergies et régimes : obligation de préparation
       (commandes, sécurité des invités, affichage). Aucun remplacement
       équitable ne l'évite : ajout assumé (C_LONG_JOURNEY_DOMAINS).
       Phase `avant` : briefs et marché, pas le service lui-même. */
    ...( ["table/traiteur", "table/chef", "table/food-truck", "table/patisserie"] as const ).map(
      (domain): [string, readonly QuestionSpec[]] => [
        domain,
        [
          {
            key: "regimes",
            level: "C",
            label: "Régimes",
            question: "Allergies ou régimes à prévoir ?",
            hint: "Sans gluten, végétarien, allergies connues : ce qui doit être garanti.",
            placeholder: "Aucun, ou détaillez…",
            type: "text",
            mapsTo: "detail:regimes",
            phase: "avant",
            sentence: (v) => `Allergies et régimes à prévoir : ${v}.`,
          },
        ],
      ],
    ),
    ["table/bar", [
      cRelabel("table", "service", {
        choices: ["bar mobile sur événement", "bar fixe ou éphémère", "dégustation ou masterclass", "ateliers de mixologie"],
      }),
    ]],
    ["table/cave", [
      cRelabel("table", "budget", {
        question: "Quel budget pour la cave ou la dégustation ?",
        hint: "Achat, abonnement, animation : un ordre de grandeur.",
      }),
    ]],

    /* ------------------------ image (6) ------------------------ */
    /* detail:livrables — phase `apres` : ce fait vit après le pivot
       (retouche, montage, livraison, archives) ; il pose AVANT le contrat.
       Pour album et retouche, c'est littéralement le métier : il remplace
       la question univers « occasion » à sa position. */
    ["image/photographe", [
      {
        key: "livrables",
        level: "C",
        label: "Livrables",
        question: "Qu'est-ce qui vous sera livré ?",
        hint: "Tirages, album, galerie HD : tout ce que le travail doit produire.",
        placeholder: "Une galerie en ligne, un album…",
        type: "text",
        mapsTo: "detail:livrables",
        phase: "apres",
        sentence: (v) => `Ce qui sera livré : ${v}.`,
      },
    ]],
    ["image/videaste", [
      {
        key: "livrables",
        level: "C",
        label: "Livrables",
        question: "Qu'est-ce qui vous sera livré ?",
        hint: "Film long, teaser, rushs, formats réseaux : tout ce qui compte.",
        placeholder: "Un film de 10 minutes, un teaser…",
        type: "text",
        mapsTo: "detail:livrables",
        phase: "apres",
        sentence: (v) => `Ce qui sera livré : ${v}.`,
      },
    ]],
    ["image/album", [
      {
        key: "livrables",
        replaces: "occasion",
        level: "C",
        label: "Contenu",
        question: "Que devra-t-il contenir ?",
        hint: "Mise en page, retouches, impression : précisez l'attendu.",
        placeholder: "Album 30 pages, impression fine art…",
        type: "text",
        mapsTo: "detail:livrables",
        phase: "apres",
        sentence: (v) => `Ce qui sera produit : ${v}.`,
      },
    ]],
    ["image/retouche", [
      {
        key: "livrables",
        replaces: "occasion",
        level: "C",
        label: "Travaux",
        question: "Quelles images, quel rendu attendu ?",
        hint: "Nombre de photos, nature du travail (restauration, lumière…).",
        placeholder: "50 photos de mariage, lumière douce…",
        type: "text",
        mapsTo: "detail:livrables",
        phase: "apres",
        sentence: (v) => `Travaux attendus : ${v}.`,
      },
    ]],
    ["image/drone", [
      cRelabel("image", "ou", {
        question: "Où se déroulera le vol ?",
        hint: "La zone décide des autorisations ; le lieu précis peut suivre.",
      }),
    ]],
    ["image/photobooth", [
      cRelabel("image", "quand", {
        question: "Quand installer le photobooth ?",
        hint: "Date et créneau d'installation ; la durée d'usage sera précisée.",
      }),
    ]],

    /* ------------------------ style (6) ------------------------ */
    ["style/coiffure", [
      cRelabel("style", "quand", { question: "Quand aura lieu le rendez-vous ?", hint: "Un essai peut se fixer avant : donnez la date du grand jour." }),
    ]],
    ["style/maquillage", [
      cRelabel("style", "quand", { question: "Quand aura lieu le rendez-vous ?", hint: "Un essai peut se fixer avant : donnez la date du grand jour." }),
    ]],
    ["style/tenue", [
      cRelabel("style", "quand", { question: "Quand la porterez-vous ?", hint: "L'essayage se donnera autour de cette date." }),
    ]],
    ["style/location-tenues", [
      cRelabel("style", "quand", { question: "Quand en aurez-vous besoin ?", hint: "Retrait et retour encadreront la date." }),
    ]],
    ["style/bijoux", [
      cRelabel("style", "budget", {
        question: "Quel budget bijoux ?",
        hint: "Création, location, ajustement : un ordre de grandeur.",
      }),
    ]],
    ["style/soins", [
      cRelabel("style", "ou", {
        question: "Où souhaitez-vous les soins ?",
        hint: "En institut, à domicile, sur un lieu : précisez la ville.",
      }),
    ]],

    /* ---------------------- patrimoine (6) --------------------- */
    /* « opération » est redondante avec le domaine choisi (Immo vente est
       déjà une vente) : C la remplace par l'avancement du dossier —
       phase `avant` (ce qui reste à franchir), clé stable
       `detail:statut_dossier`, lisible par la future Timeline. */
    ...(
      [
        ["patrimoine/immo-vente", ["juste estimé", "annonce en préparation", "annoncée, visites en cours", "compromis signé"]],
        ["patrimoine/immo-location", ["bien encore en recherche", "bail en préparation", "location en cours"]],
        ["patrimoine/materiel", ["besoin à préciser", "catalogue et tarifs à jour", "en cours de location"]],
        ["patrimoine/vehicules", ["juste estimé", "cession en préparation", "en circulation / usage quotidien"]],
        ["patrimoine/mobilier", ["à inventorier", "mis en vente", "en usage"]],
        ["patrimoine/objets", ["à expertiser", "estimé", "mis en vente ou en collection"]],
      ] as const
    ).map(
      ([domain, choices]): [string, readonly QuestionSpec[]] => [
        domain,
        [
          {
            key: "statut-dossier",
            replaces: "operation",
            level: "C",
            label: "Avancement",
            question: "Où en est le dossier ?",
            hint: "Ce qui est déjà fait guidera la suite.",
            placeholder: "Choisissez l'étape",
            type: "choice",
            choices: [...choices],
            mapsTo: "detail:statut_dossier",
            phase: "avant",
            sentence: (v) => `L'avancement du dossier : ${v}.`,
          },
        ],
      ],
    ),

    /* ------------------------ voyage (6) ----------------------- */
    /* detail:duree — nuits du séjour : dimensionne toutes les réservations
       (`avant`). Ajout assumé (C_LONG_JOURNEY_DOMAINS). */
    ["voyage/hebergement", [
      {
        key: "duree",
        level: "C",
        label: "Durée",
        question: "Combien de nuits ?",
        placeholder: "Choisissez la durée",
        type: "choice",
        choices: ["2-3 nuits", "une semaine", "deux semaines et plus"],
        mapsTo: "detail:duree",
        phase: "avant",
        sentence: (v) => `Durée prévue : ${v}.`,
      },
    ]],
    ["voyage/sejour-groupe", [
      cRelabel("voyage", "qui", {
        question: "Combien de voyageurs dans le groupe ?",
        hint: "Tous comptés, même approximatif.",
      }),
      {
        key: "duree",
        level: "C",
        label: "Durée",
        question: "Combien de nuits ?",
        placeholder: "Choisissez la durée",
        type: "choice",
        choices: ["2-3 nuits", "une semaine", "deux semaines et plus"],
        mapsTo: "detail:duree",
        phase: "avant",
        sentence: (v) => `Durée prévue : ${v}.`,
      },
    ]],
    ["voyage/guide", [
      cRelabel("voyage", "destination", {
        question: "Où se déroulera la visite guidée ?",
        hint: "Ville, quartier, sentier : le terrain de la visite.",
      }),
    ]],
    ["voyage/transport", [
      cRelabel("voyage", "mobilite", {
        choices: ["en voiture avec chauffeur", "en location longue durée", "en autocar privatisé", "en transport groupé"],
      }),
    ]],
    ["voyage/navette", [
      cRelabel("voyage", "mobilite", {
        choices: ["navette privatisée", "navette régulière", "transferts à la demande"],
      }),
    ]],
    ["voyage/experience", [
      cRelabel("voyage", "destination", {
        question: "Où se déroulera l'expérience ?",
        hint: "Ville, région, spot : liez-la au terrain de jeu.",
      }),
    ]],

    /* ------------------------- lien (6) ------------------------ */
    /* Mentorat, communauté, entraide : la ville importe moins que le mode
       d'échange — « ou » cède sa place. TRANSVERSAL par honnêteté :
       présentiel/visio structure les préparatifs (calendrier, canal) ET
       le vécu (chaque rencontre est l'actif). `phase` reste absente ;
       aucune phase n'a le monopole de ce fait. */
    ...( ["lien/mentorat", "lien/communaute", "lien/entraide"] as const ).map(
      (domain): [string, readonly QuestionSpec[]] => [
        domain,
        [
          {
            key: "cadre-echanges",
            replaces: "ou",
            level: "C",
            label: "Échanges",
            question: "Les échanges se feraient plutôt…",
            placeholder: "Choisissez le mode",
            type: "choice",
            choices: ["en présentiel, près de chez vous", "en visioconférence", "en mixte, présentiel et visio"],
            mapsTo: "detail:cadre_echanges",
            sentence: (v) => `Les échanges se feraient ${v}.`,
          },
        ],
      ],
    ),
    ["lien/rencontre", [
      cRelabel("lien", "qui", {
        question: "Combien de personnes viserez-vous ?",
        hint: "Personnes rencontrées, cercle visé : un ordre de grandeur.",
      }),
    ]],
    ["lien/amitie", [
      cRelabel("lien", "qui", {
        question: "Combien de personnes sont concernées ?",
        hint: "Le cercle visé : un ordre de grandeur.",
      }),
    ]],
    ["lien/reseau-pro", [
      cRelabel("lien", "budget", {
        question: "Quel investissement envisagez-vous ?",
        hint: "Adhésions, événements, accompagnement : un ordre de grandeur.",
      }),
    ]],

    /* ---------------------- solidarite (6) --------------------- */
    /* Bénévolat : la ressource première n'est pas l'argent mais le temps —
       detail:disponibilite remplace `budget` à sa position (`avant` :
       dimensionne un engagement qu'on puisse tenir). */
    ["solidarite/benevolat", [
      {
        key: "disponibilite",
        replaces: "budget",
        level: "C",
        label: "Temps",
        question: "Combien de temps donneriez-vous ?",
        hint: "L'engagement réaliste, celui qu'on peut tenir.",
        placeholder: "Choisissez votre temps",
        type: "choice",
        choices: ["quelques heures par semaine", "un jour par semaine", "des missions ponctuelles", "à temps plein"],
        mapsTo: "detail:disponibilite",
        phase: "avant",
        sentence: (v) => `Le temps disponible : ${v}.`,
      },
    ]],
    ["solidarite/collecte", [
      cRelabel("solidarite", "budget", {
        label: "Objectif",
        question: "Quel montant visez-vous ?",
        hint: "L'objectif de collecte, même provisoire.",
        sentence: (v) => `L'objectif de collecte : ${v} €.`,
      }),
    ]],
    ["solidarite/cause", [
      cRelabel("solidarite", "budget", {
        question: "Quelles ressources envisagez-vous ?",
        hint: "Fonds, matériel, partenariats : un ordre de grandeur.",
      }),
    ]],
    ["solidarite/sport", [
      cRelabel("solidarite", "qui", {
        question: "Combien de sportifs ou d'adhérents ?",
        hint: "Licenciés, participants : un ordre de grandeur.",
      }),
    ]],
    ["solidarite/animaux", [
      cRelabel("solidarite", "budget", {
        question: "Quelles ressources envisagez-vous ?",
        hint: "Soins, nourriture, refuge : un ordre de grandeur.",
      }),
    ]],
    ["solidarite/quartier", [
      cRelabel("solidarite", "budget", {
        question: "Quelles ressources envisagez-vous ?",
        hint: "Subventions, fonds propres, main-d'œuvre : un ordre de grandeur.",
      }),
    ]],
  ] as [string, readonly QuestionSpec[]][]),
);

/**
 * Compose le socle A avec les packs de spécialisation (B à ce jour, C à
 * l'étape 9), dans l'ordre donné. Règles, rendues structurelles ici :
 *
 *  - La proposition la plus spécialisée gagne toujours, EN PLACE : la
 *    question qu'elle remplace garde sa position et n'apparaît jamais deux
 *    fois (ni par key, ni par replaces, ni entre packs successifs) ;
 *  - `replaces` est prioritaire sur la clé elle-même : une question B/C peut
 *    reformuler une question existante sous une clé nouvelle (« destination »
 *    remplace « ou ») — si la cible est absente du socle actuel, la question
 *    s'ajoute sagement en fin (défensif : un replaces orphelin est d'ailleurs
 *    rejeté par les tests du registre) ;
 *  - Une question sans equivalant (ni replaces, ni clé existante) s'ajoute
 *    en fin, dans l'ordre déclaré de son pack → ordre déterministe total.
 *
 * Quand le pack C sera ajouté en troisième argument (étape 9), la même
 * garantie « aucun doublon » vaudra mécaniquement, sans nouvelle logique.
 */
export function composeQuestions(
  base: readonly QuestionSpec[],
  ...packs: readonly (readonly QuestionSpec[])[]
): QuestionSpec[] {
  const out = [...base];
  for (const pack of packs) {
    for (const spec of pack) {
      let target = spec.replaces
        ? out.findIndex((q) => q.key === spec.replaces)
        : -1;
      if (target < 0) target = out.findIndex((q) => q.key === spec.key);
      if (target >= 0) out[target] = spec;
      else out.push(spec);
    }
  }
  return out;
}

/** L'univers d'un typeId (« univers/domaine »), ou null s'il est inconnu. */
function universeForType(typeId: string): string | null {
  const hit = UNIVERSE_TREE.find((u) => {
    if (typeId === u.slug) return true;
    if (!typeId.startsWith(`${u.slug}/`)) return false;
    const sub = typeId.slice(u.slug.length + 1);
    return u.subs.some((s) => s.slug === sub);
  });
  return hit?.slug ?? null;
}

/**
 * Les questions posées pour un type de projet (« univers/domaine ») :
 * source UNIQUE de composition — A, plus le pack B de son univers, plus
 * le pack C de son domaine.
 *
 * Sans type (ou type inconnu) : le socle A historique s'applique, inchangé.
 * 6 questions par défaut ; 7 seulement pour les domaines en liste blanche
 * C_LONG_JOURNEY_DOMAINS (justification documentée avec le pack C).
 */
export function questionsFor(typeId?: string | null): readonly QuestionSpec[] {
  if (!typeId) return A_PACK;
  const universe = universeForType(typeId);
  if (!universe) return A_PACK;
  return Object.freeze(
    composeQuestions(
      A_PACK,
      B_PACK_BY_UNIVERSE[universe] ?? [],
      C_PACK_BY_DOMAIN[typeId] ?? [],
    ),
  );
}

/**
 * Nombre de questions du parcours guidé pour un type (hors champ « type »,
 * affiché par le héros). SEUIL UNIQUE DE VÉRITÉ de la progression : aucun
 * compteur codé ailleurs ne doit exister — quand les packs B/C rallongeront
 * les séquences (étapes 8/9), ce compteur suivra sans qu'aucune autre
 * ligne ne change.
 */
export function journeyQuestionCount(typeId?: string | null): number {
  return questionsFor(typeId).length;
}

/* ------------------------------------------------------------------ */
/* Présentation (étape 12)                                             */
/* ------------------------------------------------------------------ */

/**
 * Le libellé HUMAIN d'une clé `detail:<clé>` : celui que l'utilisateur a vu
 * sur le bouton de la question (« Livrables », « Avancement », « Temps »…).
 *
 * Ordre de spécialisation quand un typeId est fourni : C (Domaine) → B
 * (Univers) → A (socle). Sans typeId : parcours déterministe A → B → C —
 * les clés stables portant même sens, le label premier trouvé est cohérent.
 * Jamais de « detail:statut_dossier » à l'écran : en dernier recours, la
 * clé est humanisée (« statut_dossier » → « Statut dossier »).
 */
export function detailLabelFor(key: string, typeId?: string | null): string {
  const find = (seq: readonly QuestionSpec[]) =>
    seq.find((q) => q.mapsTo === `detail:${key}`)?.label;
  if (typeId) {
    const fromC = C_PACK_BY_DOMAIN[typeId] ? find(C_PACK_BY_DOMAIN[typeId]) : undefined;
    if (fromC) return fromC;
    const universe = universeForType(typeId);
    const fromB = universe ? find(B_PACK_BY_UNIVERSE[universe] ?? []) : undefined;
    if (fromB) return fromB;
  }
  const generic =
    find(A_PACK) ??
    Object.values(B_PACK_BY_UNIVERSE)
      .map((p) => find(p)!)
      .find(Boolean) ??
    Object.values(C_PACK_BY_DOMAIN)
      .map((p) => find(p)!)
      .find(Boolean);
  if (generic) return generic;
  const human = key.replaceAll("_", " ").trim();
  return human.charAt(0).toUpperCase() + human.slice(1);
}

/* ------------------------------------------------------------------ */
/* Glue du héros — fonctions pures testées unitairement                */
/* ------------------------------------------------------------------ */

/** Texte affiché dans la pastille d'une réponse saisie (valeur brute). */
export function chipText(
  q: Pick<QuestionSpec, "type" | "mapsTo" | "label">,
  value: string,
): string {
  if (q.type === "date") {
    const f = formatDate(value);
    return f;
  }
  if (q.type === "number" && q.mapsTo === "budget") return `${value} €`;
  if (q.type === "number") return `${value} ${q.label.toLowerCase()}`;
  return value;
}

/** Associe les anciennes clés de blueprint aux slots canoniques. */
const LEGACY_SLOT: Readonly<Record<string, QuestionMapsTo>> = Object.freeze({
  quand: "day",
  ou: "place",
  existant: "budget",
  qui: "guests",
});

/**
 * Filet de sécurité du héros : transforme les questions historiques d'un
 * blueprint en specs exploitables. Utilisé uniquement si `questionsFor`
 * renvoyait un jour une séquence vide (le socle A le rend aujourd'hui
 * impossible — le filet reste dormant et testé).
 */
export function blueprintQuestionsAsSpecs(bp: {
  questions: readonly {
    key: string;
    label: string;
    placeholder: string;
    type: QuestionInputType;
    sentence: (value: string) => string;
  }[];
}): QuestionSpec[] {
  return bp.questions.map((q) => ({
    key: q.key,
    level: "A",
    label: q.label,
    question: q.label,
    placeholder: q.placeholder,
    type: q.type,
    mapsTo: LEGACY_SLOT[q.key] ?? "intention",
    sentence: q.sentence,
  }));
}
