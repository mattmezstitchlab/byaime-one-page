/**
 * Le mariage : une déclinaison du modèle de projet.
 * À partir de quelques informations, AIME construit ce qui en découle —
 * le déroulé du jour, les places à pourvoir, le rétroplanning — en marquant
 * clairement ce qui est déduit ou seulement suggéré.
 */
import { DAY, fact, type Confidence, type WorldProject, type WorldProvider } from "./types";

export type WeddingInput = {
  couple?: string | null;
  /** Jour J à minuit (ms). */
  day: number;
  dayConfidence?: Confidence;
  city?: string | null;
  venue?: string | null;
  guests?: number | null;
  /** Heure de la cérémonie, en heures décimales. */
  ceremonyH?: number | null;
  ceremonyConfidence?: Confidence;
  /** Prestataires cités dans le récit. */
  booked?: { role: string; name?: string; status?: WorldProvider["status"] }[];
  story?: string;
  now?: number;
  /** Les fixtures de démonstration seules peuvent être marquées comme démo. */
  demo?: boolean;
};

/** Les places d'un mariage : la grille de référence. */
export const WEDDING_ROLES = [
  "Lieu de réception",
  "Traiteur",
  "Photographe",
  "Vidéaste",
  "Musique / DJ",
  "Fleuriste",
  "Décoration",
  "Coiffure & maquillage",
  "Pâtisserie",
  "Officiant / cérémonie",
  "Transport",
  "Hébergement",
];

/** Le déroulé type, calé sur l'heure de la cérémonie. */
const FLOW: { key: string; delta: number; label: string; detail: string; role?: string }[] = [
  { key: "preparation", delta: -7, label: "Préparatifs", detail: "Réveil, petit-déjeuner, mise en place calme.", role: "Coiffure & maquillage" },
  { key: "habillage", delta: -2.5, label: "Habillage", detail: "Tenues, derniers essayages, photos des préparatifs.", role: "Photographe" },
  { key: "deplacement", delta: -1.5, label: "Déplacement", detail: "Trajet vers le lieu de cérémonie.", role: "Transport" },
  { key: "installation", delta: -1, label: "Installation & décor", detail: "Arche, tables, signalétique, son.", role: "Décoration" },
  { key: "accueil", delta: -0.5, label: "Accueil des invités", detail: "Arrivée, placement, musique douce." },
  { key: "ceremonie", delta: 0, label: "Cérémonie", detail: "Échange des vœux et des consentements.", role: "Officiant / cérémonie" },
  { key: "sortie", delta: 0.75, label: "Sortie", detail: "Haie d'honneur, félicitations." },
  { key: "photos", delta: 1.25, label: "Photos de groupe", detail: "Familles, témoins, puis les mariés.", role: "Photographe" },
  { key: "cocktail", delta: 2.5, label: "Cocktail", detail: "Pièces salées et premières retrouvailles.", role: "Traiteur" },
  { key: "diner", delta: 4.5, label: "Dîner", detail: "Entrée en salle et service.", role: "Traiteur" },
  { key: "discours", delta: 6, label: "Discours", detail: "Prises de parole entre les plats." },
  { key: "gateau", delta: 7, label: "Pièce montée", detail: "Dessert et feux froids.", role: "Pâtisserie" },
  { key: "bal", delta: 7.5, label: "Ouverture de bal", detail: "Première danse.", role: "Musique / DJ" },
  { key: "soiree", delta: 8.5, label: "Soirée", detail: "La piste ne se vide plus.", role: "Musique / DJ" },
  { key: "fin", delta: 13, label: "Fin de soirée", detail: "Dernier morceau, retours.", role: "Transport" },
];

/** Le rétroplanning générique d'un mariage, en jours avant le jour J. */
const RETRO: { key: string; days: number; label: string; detail: string; role?: string }[] = [
  { key: "lieu", days: 540, label: "Réserver le lieu", detail: "Visiter, comparer, poser une option.", role: "Lieu de réception" },
  { key: "traiteur", days: 450, label: "Choisir le traiteur", detail: "Dégustation et devis.", role: "Traiteur" },
  { key: "photo", days: 450, label: "Choisir le photographe", detail: "Comparer les portfolios.", role: "Photographe" },
  { key: "musique", days: 330, label: "Choisir la musique", detail: "DJ ou groupe, style de soirée.", role: "Musique / DJ" },
  { key: "tenues", days: 300, label: "Tenues des mariés", detail: "Essayages et retouches." },
  { key: "faire-part", days: 240, label: "Envoyer les faire-part", detail: "Liste des invités et réponses." },
  { key: "fleurs", days: 180, label: "Fleurs et décoration", detail: "Arche, centres de table, bouquet.", role: "Fleuriste" },
  { key: "menu", days: 90, label: "Finaliser le menu", detail: "Allergies, régimes, nombre de couverts.", role: "Traiteur" },
  { key: "plan", days: 45, label: "Plan de table", detail: "Placement et signalétique." },
  { key: "repetition", days: 7, label: "Répétition", detail: "Déroulé, entrées, prises de parole." },
  { key: "solde", days: 15, label: "Dernier paiement du traiteur", detail: "Solde avant la réception.", role: "Traiteur" },
  { key: "materiel", days: -3, label: "Retour du matériel", detail: "Vaisselle, décor, location." },
  { key: "remerciements", days: -21, label: "Remerciements", detail: "Un mot aux invités et aux prestataires." },
  { key: "album", days: -30, label: "Album photo", detail: "Sélection et commande." },
];

function slug(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/**
 * Construit le modèle du mariage : ce qui est dit est confirmé,
 * ce qui en découle est déduit, le reste est proposé.
 */
export function buildWedding(input: WeddingInput): WorldProject {
  const now = input.now ?? Date.now();
  const day = input.day;
  const ceremony = input.ceremonyH ?? 15;
  const ceremonyKnown = input.ceremonyH != null;

  const cited = input.booked ?? [];
  const providers: WorldProvider[] = WEDDING_ROLES.map((role) => {
    const hit = cited.find((c) => c.role === role);
    if (hit) {
      return {
        id: slug(role),
        role,
        ...(hit.name ? { name: hit.name } : {}),
        ...(input.city ? { city: input.city } : {}),
        status: hit.status ?? "reserve",
        confidence: "confirme" as Confidence,
        note: hit.name ? "Cité dans votre récit." : "Réservé, nom à préciser.",
      };
    }
    return {
      id: slug(role),
      role,
      ...(input.city ? { city: input.city } : {}),
      status: "a_rechercher" as const,
      confidence: "manquant" as Confidence,
      note: input.city
        ? `Aucun prestataire choisi — recherche possible autour de ${input.city}.`
        : "Aucun prestataire choisi.",
    };
  });

  const momentConfidence: Confidence = "suggere";
  const moments = FLOW.map((f) => {
    const providerId = f.role ? slug(f.role) : undefined;
    const known = providers.find((p) => p.id === providerId);
    return {
      id: f.key,
      offsetH: ceremony + f.delta,
      label: f.label,
      detail: f.detail,
      ...(known && known.status !== "a_rechercher" ? { providerId: known.id } : {}),
      ...(input.venue ? { location: input.venue } : {}),
      confidence:
        f.key === "ceremonie" && ceremonyKnown ? ("confirme" as Confidence) : momentConfidence,
    };
  });

  const tasks = RETRO.map((r) => {
    const providerId = r.role ? slug(r.role) : undefined;
    const done = providerId
      ? providers.some((p) => p.id === providerId && p.status !== "a_rechercher")
      : false;
    return {
      id: r.key,
      label: r.label,
      detail: r.detail,
      at: day - r.days * DAY,
      ...(providerId ? { providerId } : {}),
      done,
      confidence: (done ? "confirme" : "suggere") as Confidence,
    };
  });

  const missing: string[] = [];
  if (!input.venue) missing.push("Le lieu de réception n'est pas encore renseigné.");
  if (!input.guests) missing.push("Le nombre d'invités n'est pas encore connu.");
  if (!ceremonyKnown) missing.push("L'heure de la cérémonie reste à confirmer.");
  const open = providers.filter((p) => p.status === "a_rechercher");
  if (open.length) missing.push(`${open.length} places restent à pourvoir.`);
  missing.push("Aucun budget n'a encore été posé sur les prestations.");

  return {
    id: "mariage",
    kind: "mariage",
    universe: "Mariage",
    title: input.couple?.trim() || "Votre mariage",
    ...(input.city ? { subtitle: input.city } : {}),
    pivot: fact(day, input.dayConfidence ?? "confirme", "récit"),
    city: fact(input.city ?? null, input.city ? "confirme" : "manquant", "récit"),
    venue: fact(input.venue ?? null, input.venue ? "confirme" : "manquant", "récit"),
    guests: fact(input.guests ?? null, input.guests ? "confirme" : "manquant", "récit"),
    people: [],
    providers,
    moments,
    tasks,
    documents: [],
    payments: [],
    media: [],
    tracks: [],
    messages: [],
    reviews: [],
    intentions: input.story
      ? [{ id: "recit", text: input.story.trim(), at: Math.min(now, day - DAY) }]
      : [],
    missing,
    lifecycle: input.demo ? "demo" : "brouillon",
    demo: input.demo ?? false,
  };
}
