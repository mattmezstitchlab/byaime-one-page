import { supabase } from "@/integrations/supabase/client";
import { flushPendingSources } from "@/lib/aime/sources/sources";
import type { WorldProject } from "./types";

/**
 * Persiste le projet confirmé dans l'événement opérationnel et dans le snapshot
 * canonique. Les écritures restent protégées par les politiques RLS du propriétaire.
 */
export async function persistValidatedProject(project: WorldProject, ownerId: string, story?: string) {
  const startsAt = new Date(project.pivot.value).toISOString();
  const { data: event, error: eventError } = await supabase
    .from("events")
    .insert({
      owner_id: ownerId,
      title: project.title,
      description: story?.trim() || project.intentions[0]?.text || null,
      starts_at: startsAt,
      location: project.venue.value,
      city: project.city.value,
      universe_slug: project.universe,
      status: "planifie",
    })
    .select("id")
    .single();
  if (eventError) throw eventError;

  const { error: snapshotError } = await supabase
    .from("project_snapshots")
    .insert({
      owner_id: ownerId,
      event_id: event.id,
      status: "actif",
      source_story: story?.trim() || null,
      payload: { ...project, id: event.id, lifecycle: "actif", demo: false },
    });
  if (snapshotError) {
    // Ne pas laisser un événement orphelin si le snapshot canonique ne peut pas être créé.
    await supabase.from("events").delete().eq("id", event.id);
    throw snapshotError;
  }

  // Les sources déposées avant la naissance du projet le rejoignent maintenant
  // qu'il a un identifiant. Une source manquée ne bloque jamais l'ouverture.
  await flushPendingSources(event.id, ownerId);

  return event.id;
}

export async function persistProjectEdits(project: WorldProject, ownerId: string) {
  const { error } = await supabase
    .from("project_snapshots")
    .update({ payload: project, updated_at: new Date().toISOString() })
    .eq("event_id", project.id)
    .eq("owner_id", ownerId);
  if (error) throw error;
}

export type ProjectFinanceLink = {
  event_id: string;
  quote_id?: string;
  document_id?: string;
  payment_id?: string;
  relation?: string;
  confidence?: number;
  confirmed?: boolean;
};

/** Enregistre une liaison vérifiée ou proposée sans dupliquer les objets métier. */
export async function linkProjectFinanceObject(link: ProjectFinanceLink, ownerId: string) {
  const { error } = await supabase.from("project_finance_links").upsert(
    { ...link, owner_id: ownerId },
    { onConflict: "event_id,quote_id,document_id,payment_id,relation" },
  );
  if (error) throw error;
}

export async function financeLinksForProject(eventId: string) {
  const { data, error } = await supabase
    .from("project_finance_links")
    .select("*")
    .eq("event_id", eventId)
    .order("created_at");
  if (error) throw error;
  return (data ?? []) as ProjectFinanceLink[];
}

/** Rattache les devis, paiements et documents déjà associés à l'événement. */
export async function syncProjectFinanceLinks(eventId: string, ownerId: string) {
  const [quotes, payments, folders] = await Promise.all([
    supabase.from("quotes").select("id").eq("event_id", eventId),
    supabase.from("event_payments").select("id").eq("event_id", eventId),
    supabase.from("bureau_folders").select("id").eq("event_id", eventId),
  ]);
  if (quotes.error) throw quotes.error;
  if (payments.error) throw payments.error;
  if (folders.error) throw folders.error;

  const folderIds = (folders.data ?? []).map((folder) => folder.id);
  const documents = folderIds.length
    ? await supabase.from("bureau_documents").select("id").in("folder_id", folderIds)
    : { data: [], error: null };
  if (documents.error) throw documents.error;

  await Promise.all([
    ...(quotes.data ?? []).map((quote) => linkProjectFinanceObject({ event_id: eventId, quote_id: quote.id, relation: "projet" }, ownerId)),
    ...(payments.data ?? []).map((payment) => linkProjectFinanceObject({ event_id: eventId, payment_id: payment.id, relation: "projet" }, ownerId)),
    ...((documents.data ?? []) as { id: string }[]).map((document) => linkProjectFinanceObject({ event_id: eventId, document_id: document.id, relation: "projet" }, ownerId)),
  ]);
}
