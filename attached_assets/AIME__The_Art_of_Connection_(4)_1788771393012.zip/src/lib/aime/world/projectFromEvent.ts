/**
 * Un projet enregistré dans la base devient un monde : même modèle que celui
 * issu d'un récit. La ligne de temps en est ensuite la projection (derive.ts).
 * Rien n'est inventé : ce qui manque reste absent ou « à confirmer ».
 */
import type { Database } from "@/integrations/supabase/types";
import { fact, type WorldPayment, type WorldProject, type WorldProvider } from "./types";

type EventRow = Database["public"]["Tables"]["events"]["Row"] & {
  event_participants?: Database["public"]["Tables"]["event_participants"]["Row"][] | null;
};
type QuoteRow = Database["public"]["Tables"]["quotes"]["Row"];
type PaymentRow = Database["public"]["Tables"]["event_payments"]["Row"];
type TrackRow = Database["public"]["Tables"]["musicbox_entries"]["Row"];

export type EventWorldSources = {
  participants?: { id: string; role_label: string; status: string; name?: string | null }[];
  quotes?: QuoteRow[];
  payments?: PaymentRow[];
  tracks?: TrackRow[];
};

const DAY = 86_400_000;

function midnight(iso: string) {
  const t = Date.parse(iso);
  const d = new Date(Number.isFinite(t) ? t : Date.now());
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

function hoursInto(dayStart: number, iso: string | null) {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return null;
  return (t - dayStart) / 3_600_000;
}

/** Compose le monde d'un projet à partir de ses données enregistrées. */
export function projectFromEvent(event: EventRow, sources: EventWorldSources = {}): WorldProject {
  const pivot = midnight(event.starts_at);
  const participants = sources.participants ?? event.event_participants ?? [];
  const quotes = sources.quotes ?? [];
  const payments = sources.payments ?? [];
  const tracks = sources.tracks ?? [];

  /** Chaque rôle tenu dans le projet est une place pourvue. */
  const providers: WorldProvider[] = participants.map((p) => ({
    id: `part-${p.id}`,
    role: p.role_label || "Participant",
    ...("name" in p && p.name ? { name: p.name } : {}),
    status: p.status === "accepte" || p.status === "confirme" ? "choisi" : "contacte",
    confidence: p.status === "accepte" || p.status === "confirme" ? "confirme" : "a_confirmer",
  }));

  const documents = quotes.map((q) => ({
    id: `quote-${q.id}`,
    title: q.title || "Devis",
    at: Date.parse(q.target_date ?? q.created_at) || pivot,
    kind: (q.status === "facture" || q.status === "paye" ? "facture" : "devis") as
      | "facture"
      | "devis",
    amountCents: Math.round(Number(q.total ?? 0) * 100),
    detail: `Statut : ${q.status}`,
    confidence: "confirme" as const,
  }));

  const worldPayments: WorldPayment[] = payments.map((p) => ({
    id: `pay-${p.id}`,
    label: p.label || "Paiement",
    at: Date.parse(p.paid_at ?? p.created_at) || pivot,
    amountCents: Math.round(Number(p.amount_paid || p.amount_due || 0) * 100),
    state: p.status === "paye" || Number(p.amount_paid) > 0 ? "paye" : "du",
    confidence: "confirme",
  }));

  const worldTracks = tracks.map((t, index) => {
    const day = Date.parse(`${t.day}T${t.start_time ?? "00:00:00"}`);
    const offsetH = Number.isFinite(day) ? (day - pivot) / 3_600_000 : 12 + index * 0.25;
    return {
      id: `track-${t.id}`,
      offsetH,
      title: t.title,
      artist: t.dedicated_name ?? t.source_type ?? "Programmation",
      moment: t.kind,
      ...(t.note ? { dedicace: t.note } : {}),
      confidence: "confirme" as const,
    };
  });

  const missing: string[] = [];
  if (!event.location && !event.city) missing.push("Le lieu du projet");
  if (participants.length === 0) missing.push("Les participants");
  if (quotes.length === 0) missing.push("Les devis");

  return {
    id: event.id,
    kind: event.universe_slug ?? "evenement",
    title: event.title,
    ...(event.description ? { subtitle: event.description } : {}),
    universe: event.universe_slug ?? "evenement",
    lifecycle: "actif",
    pivot: fact(pivot, "confirme", "projet"),
    city: fact(event.city ?? null, event.city ? "confirme" : "manquant", "projet"),
    venue: fact(event.location ?? null, event.location ? "confirme" : "manquant", "projet"),
    guests: fact(participants.length || null, participants.length ? "confirme" : "manquant"),
    people: [],
    providers,
    moments: [
      {
        id: "moment-ouverture",
        offsetH: hoursInto(pivot, event.starts_at) ?? 12,
        label: event.title,
        ...(event.location || event.city
          ? { location: [event.location, event.city].filter(Boolean).join(" · ") }
          : {}),
        confidence: "confirme" as const,
      },
      ...(event.ends_at
        ? [
            {
              id: "moment-fin",
              offsetH: hoursInto(pivot, event.ends_at) ?? 23,
              label: "Fin du rassemblement",
              confidence: "confirme" as const,
            },
          ]
        : []),
    ],
    tasks: [],
    documents,
    payments: worldPayments,
    media: [],
    tracks: worldTracks,
    messages: [],
    reviews: [],
    intentions: event.description
      ? [{ id: "intention-projet", text: event.description, at: pivot - 30 * DAY }]
      : [],
    missing,
  };
}
