/**
 * La lecture du récit par AIME : une phrase libre devient une lecture
 * structurée (date, lieu, ville, personnes, heure, rôles déjà trouvés,
 * faits extensibles). Rien n'est inventé : tout champ absent du récit
 * revient à null.
 *
 * La lecture est dynamique (Vague 3) : le type de projet choisi décide du
 * prompt, des rôles autorisés et des clés `details` — sans type, le
 * comportement historique (mariage) est conservé tel quel. Toute la
 * logique spécialisée vit dans `storyIntent.ts` (module pur, testé).
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  aiDetailsToRecord,
  intentContextFor,
  intentSchema,
  intentSystem,
  type IntentContext,
} from "./storyIntent";
import type { DetailValue } from "./parseStory";

const MODEL = "openai/gpt-5.6-sol";

const Input = z.object({
  recit: z.string().min(3).max(4000),
  /** Type choisi à l'accueil (« univers/domaine ») — optionnel (filet historique). */
  type: z.string().max(200).nullish(),
});

export type StoryAiReading = {
  couple: string | null;
  /** AAAA-MM-JJ */
  date: string | null;
  ville: string | null;
  lieu: string | null;
  invites: number | null;
  /** Heure décimale du moment principal, ex. 15.5 pour 15 h 30. */
  heure: number | null;
  prestatairesTrouves: string[];
  /** Faits extensibles explicitement présents dans le récit (clés autorisées). */
  details?: Record<string, DetailValue>;
  resume: string;
  /** Renseigné quand AIME n'a pas pu lire (crédits, limite, panne) : jamais bloquant. */
  indisponible?: string;
};

/** Lecture vide : le repérage local du récit prend le relais côté client. */
function lectureVide(raison: string): StoryAiReading {
  return {
    couple: null,
    date: null,
    ville: null,
    lieu: null,
    invites: null,
    heure: null,
    prestatairesTrouves: [],
    resume: "",
    indisponible: raison,
  };
}

async function readGateway(
  apiKey: string,
  recit: string,
  ctx: IntentContext,
): Promise<StoryAiReading> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      store: false,
      instructions: intentSystem(ctx),
      input: [{ role: "user", content: [{ type: "input_text", text: recit }] }],
      text: { format: { type: "json_schema", name: "recit", strict: true, schema: intentSchema(ctx) } },
    }),
  });

  if (!res.ok || !res.body) {
    if (res.status === 429) throw new Error("Trop de demandes, réessayez dans un instant.");
    if (res.status === 402) throw new Error("Crédits IA épuisés pour cet espace.");
    throw new Error(`AIME a répondu ${res.status}.`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const event = JSON.parse(payload) as {
          type?: string;
          delta?: string;
          response?: { output_text?: string };
        };
        if (event.type === "response.output_text.delta" && typeof event.delta === "string") {
          text += event.delta;
        } else if (event.type === "response.completed" && event.response?.output_text) {
          text = event.response.output_text;
        }
      } catch {
        /* fragment SSE incomplet */
      }
    }
  }

  const parsed = JSON.parse(text) as Omit<StoryAiReading, "details"> & { details?: unknown };
  const details = aiDetailsToRecord(parsed.details, ctx);
  return {
    couple: parsed.couple ?? null,
    date: parsed.date ?? null,
    ville: parsed.ville ?? null,
    lieu: parsed.lieu ?? null,
    invites: typeof parsed.invites === "number" ? parsed.invites : null,
    heure: typeof parsed.heure === "number" ? parsed.heure : null,
    prestatairesTrouves: Array.isArray(parsed.prestatairesTrouves)
      ? parsed.prestatairesTrouves.slice(0, 12)
      : [],
    ...(details ? { details } : {}),
    resume: parsed.resume ?? "",
  };
}

export const readStoryAI = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<StoryAiReading> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return lectureVide("Clé IA absente.");
    /* Le type choisi à l'accueil spécialise la lecture ; sans type, le
       contexte historique (mariage) demeure — jamais l'inverse. */
    try {
      return await readGateway(apiKey, data.recit, intentContextFor(data.type ?? null));
    } catch (e) {
      /* Crédits, limite, panne ou réponse illisible : jamais d'écran blanc. */
      console.error("[readStoryAI]", e);
      return lectureVide(e instanceof Error ? e.message : "Lecture IA indisponible.");
    }
  });
