/**
 * Faits extensibles (Vague 3, étape 5) : le tuyau
 *   QuestionSpec.mapsTo → readingFromAnswers → BuildInput.details
 *   → WorldProject.details
 * sans nouvelle table, sans migration, rétrocompatible avec les projets
 * historiques.
 *
 * Les detail:* utilisés ici sont ceux disponibles dans les tests — le
 * remplissage des 73 Domaines (packs B/C) vient aux étapes 8/9.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { mergeReading, projectFromJourney, readingFromAnswers } from "../journey";
import { projectFromReading, type StoryReading } from "../parseStory";
import { buildProject, blueprintFor } from "../blueprints";

const NOW = new Date(2026, 8, 6, 12, 0, 0).getTime();
const EMPTY: StoryReading = {
  day: null,
  city: null,
  venue: null,
  guests: null,
  ceremonyH: null,
  couple: null,
  booked: [],
};

/* ------------------------------------------------------------------ */
/* Une réponse detail:* arrive dans WorldProject.details               */
/* ------------------------------------------------------------------ */

describe("propagation d'un detail:* jusqu'au monde", () => {
  test("clé stable, valeur conservée, fait confirmé sourcé récit", () => {
    const p = projectFromJourney(
      {
        type: "lien/mentorat",
        quand: "2027-01-15",
        "detail:rythme_mentorat": "Mensuel, un jeudi sur deux",
      },
      { now: NOW, force: true },
    );
    assert.ok(p);
    assert.ok(p.details);
    /* « detail: » est un préfixe de routage : la clé du fait est la clé
       sémantique, snake_case, stable pour les futurs packs B/C. */
    assert.deepEqual(p.details["rythme_mentorat"], {
      value: "Mensuel, un jeudi sur deux",
      confidence: "confirme",
      source: "récit",
    });
  });

  test("plusieurs detail:* sont conservées, chacune à sa clé", () => {
    const p = projectFromJourney(
      {
        type: "patrimoine/immo-vente",
        "detail:nature_bien": "Maison",
        "detail:surface_m2": "128",
      },
      { now: NOW, force: true },
    );
    assert.ok(p?.details);
    assert.equal(p.details["nature_bien"]?.value, "Maison");
    assert.equal(p.details["surface_m2"]?.value, "128");
    assert.equal(Object.keys(p.details).length, 2);
  });

  test("la valeur d'une clé inconnue n'est ni perdue ni transformée", () => {
    const p = projectFromJourney(
      {
        type: "musique/dj",
        "detail:cle_future_x": "Valeur — 42 Ω & détails",
      },
      { now: NOW, force: true },
    );
    assert.ok(p);
    assert.equal(p.details?.["cle_future_x"]?.value, "Valeur — 42 Ω & détails");
    /* Et elle figure aussi verbatim dans le récit (étape 4). */
    assert.ok(p.intentions[0]?.text.includes("Valeur — 42 Ω & détails"));
  });

  test("une clé detail: blanche ou « je ne sais pas » ne produit aucun fait", () => {
    const p = projectFromJourney(
      {
        type: "musique/dj",
        "detail:cle_a": "   ",
        "detail:cle_b": "Je ne sais pas encore",
      },
      { now: NOW, force: true },
    );
    assert.ok(p);
    assert.equal(p.details, undefined);
  });
});

/* ------------------------------------------------------------------ */
/* Les slots historiques continuent de fonctionner                     */
/* ------------------------------------------------------------------ */

describe("slots canoniques inchangés", () => {
  test("day / place / guests arrivent aux faits historiques ; budget devient un fait extensible", () => {
    const p = projectFromJourney(
      { type: "evenement/mariage", quand: "2027-08-14", ou: "Lille", qui: "120", budget: "25000" },
      { now: NOW },
    );
    assert.ok(p);
    assert.equal(p.pivot.value, new Date(2027, 7, 14).getTime());
    assert.equal(p.city.value, "Lille");
    assert.equal(p.guests.value, 120);
    /* Budget : nombre (question numérique), jamais écrasé par un détail. */
    assert.deepEqual(p.details, {
      budget: { value: 25000, confidence: "confirme", source: "récit" },
    });
  });

  test("un lieu « domaine » reste un venue, nombre en texte est lu", () => {
    const r = readingFromAnswers(
      { type: "evenement/mariage", ou: "Domaine des Tilleuls", qui: "environ 80 personnes" },
      new Date(NOW),
    );
    assert.equal(r.venue, "Domaine Des Tilleuls");
    assert.equal(r.city, null);
    assert.equal(r.guests, 80);
  });
});

/* ------------------------------------------------------------------ */
/* Rétrocompatibilité                                                  */
/* ------------------------------------------------------------------ */

describe("rétrocompatibilité", () => {
  test("absence de details : valide partout", () => {
    const p = projectFromJourney({ type: "musique/concert", quand: "2027-06-03" }, { now: NOW });
    assert.ok(p);
    assert.equal(p.details, undefined);
    const r = readingFromAnswers({ type: "musique/concert", quand: "2027-06-03" }, new Date(NOW));
    assert.equal(r.details, undefined);
  });

  test("un projet historique sans details reste générable, tous champs intacts", () => {
    const p = projectFromReading(EMPTY, "Un concert.", NOW, "musique/concert");
    assert.equal(p.details, undefined);
    assert.equal(p.kind, "concert");
    assert.equal(p.providers.length, 9);
    assert.equal(p.moments.length, 9);
    assert.equal(p.tasks.length, 12);
    assert.ok(p.missing.includes("Aucun budget n'a encore été posé sur les prestations."));
  });

  test("buildProject accepte et enveloppe les faits bruts", () => {
    const p = buildProject(blueprintFor("musique/concert"), {
      day: NOW + 30 * 86_400_000,
      now: NOW,
      typeId: "musique/concert",
      details: { jauges_techniques: 2, note_libre: "Scène nord" },
    });
    assert.deepEqual(p.details?.["jauges_techniques"], {
      value: 2,
      confidence: "confirme",
      source: "récit",
    });
    assert.deepEqual(p.details?.["note_libre"], {
      value: "Scène nord",
      confidence: "confirme",
      source: "récit",
    });
  });
});

/* ------------------------------------------------------------------ */
/* Aucune donnée existante n'est écrasée par un détail                 */
/* ------------------------------------------------------------------ */

describe("aucun écrasement", () => {
  test("un budget répondu retire son message manquant, tout le reste demeure", () => {
    const sans = projectFromJourney(
      { type: "evenement/mariage", quand: "2027-08-14", ou: "Lille", qui: "120" },
      { now: NOW },
    );
    const avec = projectFromJourney(
      { type: "evenement/mariage", quand: "2027-08-14", ou: "Lille", qui: "120", budget: "25000" },
      { now: NOW },
    );
    assert.ok(sans && avec);
    assert.ok(sans.missing.includes("Aucun budget n'a encore été posé sur les prestations."));
    assert.ok(!avec.missing.includes("Aucun budget n'a encore été posé sur les prestations."));
    /* Tous les autres messages et faits sont strictement identiques. */
    const BUDGET_MSG = "Aucun budget n'a encore été posé sur les prestations.";
    assert.deepEqual(
      avec.missing,
      sans.missing.filter((m) => m !== BUDGET_MSG),
    );
    assert.equal(avec.pivot.value, sans.pivot.value);
    assert.equal(avec.city.value, sans.city.value);
    assert.deepEqual(avec.guests, sans.guests);
    assert.deepEqual(avec.providers, sans.providers);
    assert.deepEqual(avec.moments, sans.moments);
    assert.deepEqual(avec.tasks, sans.tasks);
  });

  test("mergeReading : la réponse utilisateur fait foi, AIME ne fait que compléter", () => {
    const base = readingFromAnswers(
      { type: "musique/dj", budget: "900" },
      new Date(NOW),
    );
    const merged = mergeReading(base, {
      details: { budget: 999999, duree_set: 4 },
    });
    assert.equal(merged.details?.["budget"], 900);
    assert.equal(merged.details?.["duree_set"], 4);
    /* Sans côté détails : le champ disparaît proprement (pas de details vide). */
    const sans = mergeReading(EMPTY, {});
    assert.equal(sans.details, undefined);
  });
});

/* ------------------------------------------------------------------ */
/* Mariage & concert : toujours compatibles                            */
/* ------------------------------------------------------------------ */

describe("compatibilité mariage et concert", () => {
  test("mariage : monde complet, budget en fait extensible", () => {
    const p = projectFromJourney(
      { type: "evenement/mariage", quand: "2027-08-14", ou: "Lille", qui: "120", budget: "25000" },
      { now: NOW },
    );
    assert.ok(p);
    assert.equal(p.kind, "mariage");
    assert.equal(p.providers.length, 12);
    assert.equal(p.moments.length, 15);
    assert.equal(p.tasks.length, 15);
    assert.equal(p.details?.["budget"]?.value, 25000);
  });

  test("concert : monde complet, aucun fait parasite", () => {
    const p = projectFromJourney(
      { type: "musique/concert", quand: "2027-06-03", ou: "Roubaix", qui: "300", budget: "8000" },
      { now: NOW },
    );
    assert.ok(p);
    assert.equal(p.kind, "concert");
    assert.equal(p.providers.length, 9);
    assert.equal(p.details?.["budget"]?.value, 8000);
    assert.equal(Object.keys(p.details ?? {}).length, 1);
  });
});
