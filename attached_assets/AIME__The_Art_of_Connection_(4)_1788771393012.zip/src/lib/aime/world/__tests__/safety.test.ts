/**
 * Filets de sécurité — Vague 3, étape 1.
 *
 * Ces tests figent le comportement ACTUEL de la chaîne
 *   réponses → récit → lecture → monde
 * avant toute évolution (questions par Domaine, réponses ouvertes, faits
 * extensibles, AIME INTENT dynamique). Toute divergence devra être voulue.
 *
 * Les sections marquées « REPLI ACTUEL » documentent le comportement de
 * secours (BY_SUB/BY_UNIVERSE) tel qu'il existe aujourd'hui pour les 54
 * Domaines sans entrée dédiée : elles seront *volontairement* remplacées
 * par les packs de questions (étapes 8/9) — chaque écart devra alors être
 * mis à jour explicitement dans ces tests.
 *
 * Exécution : bun run test (ou node --test --import ./tests/register-alias.mjs "src/**\/*.test.ts")
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import {
  BLUEPRINTS,
  PROJECT_TYPES,
  blueprintFor,
  buildProject,
  projectTypeById,
  scheduleRetro,
  type Blueprint,
} from "../blueprints";
import {
  journeySummary,
  projectFromJourney,
  readingFromAnswers,
  storyFromAnswers,
  type JourneyAnswers,
} from "../journey";
import { projectFromReading, readStory } from "../parseStory";
import { UNIVERSE_TREE } from "@/lib/aime/universeTree";

/* Référence temporelle fixe : aujourd'hui = 6 septembre 2026. */
const NOW = new Date(2026, 8, 6, 12, 0, 0).getTime();

/**
 * Compose des réponses exactement comme HeroBar le fait depuis l'étape 4 :
 * valeurs BRUTES sous les clés du registre de questions.
 */
function heroAnswers(
  typeId: string,
  raw: { quand: string; ou: string; budget: string; qui: string },
): JourneyAnswers {
  return { type: typeId, quand: raw.quand, ou: raw.ou, budget: raw.budget, qui: raw.qui };
}

/* ------------------------------------------------------------------ */
/* 1. L'arbre des types : 73 Domaines, tous reliés à un blueprint      */
/* ------------------------------------------------------------------ */

describe("PROJECT_TYPES — l'arbre des Domaines", () => {
  test("73 types de projet, un par Domaine de l'arbre", () => {
    const expected = UNIVERSE_TREE.flatMap((u) => u.subs.map((s) => `${u.slug}/${s.slug}`));
    assert.equal(PROJECT_TYPES.length, 73);
    assert.deepEqual(
      PROJECT_TYPES.map((t) => t.id),
      expected,
    );
  });

  test("chaque type pointe vers un blueprint existant", () => {
    const ids = new Set(BLUEPRINTS.map((b) => b.id));
    for (const t of PROJECT_TYPES) {
      assert.ok(ids.has(t.blueprintId), `${t.id} → blueprint inconnu ${t.blueprintId}`);
      assert.equal(t.id, `${t.universeSlug}/${t.id.split("/")[1]}`);
    }
  });

  test("10 moteurs de monde, pas un de plus", () => {
    assert.deepEqual(
      BLUEPRINTS.map((b) => b.id),
      [
        "mariage",
        "celebration",
        "concert",
        "festival",
        "spectacle",
        "entreprise",
        "voyage",
        "association",
        "artistique",
        "generique",
      ],
    );
  });
});

/* ------------------------------------------------------------------ */
/* 2. Structure des 10 blueprints actuels                              */
/* ------------------------------------------------------------------ */

describe("BLUEPRINTS — structure actuelle des moteurs", () => {
  const shape: Record<string, { roles: number; flow: number; retro: number }> = {
    mariage: { roles: 12, flow: 15, retro: 15 },
    celebration: { roles: 7, flow: 8, retro: 9 },
    concert: { roles: 9, flow: 9, retro: 12 },
    festival: { roles: 9, flow: 8, retro: 14 },
    spectacle: { roles: 7, flow: 7, retro: 11 },
    entreprise: { roles: 7, flow: 9, retro: 11 },
    voyage: { roles: 5, flow: 6, retro: 9 },
    association: { roles: 6, flow: 6, retro: 10 },
    artistique: { roles: 5, flow: 4, retro: 10 },
    generique: { roles: 4, flow: 4, retro: 8 },
  };

  for (const bp of BLUEPRINTS) {
    test(`${bp.id} : questions, rôles, déroulé, rétroplanning`, () => {
      /* Les 4 questions génériques actuelles, toujours dans cet ordre. */
      assert.deepEqual(
        bp.questions.map((q) => q.key),
        ["quand", "ou", "existant", "qui"],
      );
      const s = shape[bp.id];
      assert.ok(s, `forme attendue manquante pour ${bp.id}`);
      assert.equal(bp.roles.length, s.roles);
      assert.equal(bp.flow.length, s.flow);
      assert.equal(bp.retro.length, s.retro);
      /* Exactement un moment pivot dans le déroulé, identifiants uniques. */
      assert.equal(bp.flow.filter((f) => f.delta === 0).length, 1);
      assert.equal(new Set(bp.flow.map((f) => f.key)).size, bp.flow.length);
      assert.equal(new Set(bp.retro.map((r) => r.key)).size, bp.retro.length);
      assert.ok(bp.pivotHour >= 0 && bp.pivotHour <= 24);
      assert.ok(bp.loadingSteps.length >= 3);
      /* Les rôles cités dans le déroulé et le rétro existent dans places. */
      const roles = new Set(bp.roles);
      for (const f of bp.flow) if (f.role) assert.ok(roles.has(f.role), `${f.role} (flow)`);
      for (const r of bp.retro) if (r.role) assert.ok(roles.has(r.role), `${r.role} (retro)`);
      /* Les dépendances du rétroplanning pointent vers des étapes connues. */
      const keys = new Set(bp.retro.map((r) => r.key));
      for (const r of bp.retro)
        for (const dep of r.after ?? []) assert.ok(keys.has(dep), `${bp.id}.${r.key} → ${dep}`);
    });
  }
});

/* ------------------------------------------------------------------ */
/* 3. Résolution typeId → blueprint : cas direct et REPLI ACTUEL       */
/* ------------------------------------------------------------------ */

describe("blueprintFor — résolution actuelle", () => {
  test("les 19 Domaines couverts par BY_SUB", () => {
    const direct: Record<string, string> = {
      "evenement/mariage": "mariage",
      "evenement/anniversaire": "celebration",
      "evenement/bapteme": "celebration",
      "evenement/ceremonie": "celebration",
      "evenement/naissance": "celebration",
      "evenement/fete-privee": "celebration",
      "evenement/evjf-evg": "celebration",
      "musique/concert": "concert",
      "musique/dj": "concert",
      "musique/groupe-live": "concert",
      "musique/karaoke": "concert",
      "musique/festival": "festival",
      "musique/studio": "artistique",
      "culture/exposition": "spectacle",
      "culture/theatre": "spectacle",
      "culture/musee": "spectacle",
      "culture/artisanat": "artistique",
      "culture/cinema": "artistique",
      "culture/litterature": "artistique",
    };
    for (const [typeId, id] of Object.entries(direct)) {
      assert.equal(blueprintFor(typeId).id, id, typeId);
    }
  });

  test("REPLI ACTUEL : les Domaines sans entrée dédiée (documenté, appelé à changer)", () => {
    /* Ces repliages motivent la Vague 3 — ils sont volontairement figés ici. */
    const fallback: Record<string, string> = {
      "image/videaste": "artistique",
      "image/photographe": "artistique",
      "table/chef": "celebration",
      "table/traiteur": "celebration",
      "lieux/salle": "celebration",
      "lieux/chateau": "celebration",
      "patrimoine/immo-vente": "generique",
      "patrimoine/immo-location": "generique",
      "style/coiffure": "generique",
      "lien/mentorat": "generique",
      "lien/rencontre": "generique",
      "solidarite/benevolat": "association",
      "entreprise/seminaire": "entreprise",
      "voyage/transport": "voyage",
      "voyage/hebergement": "voyage",
    };
    for (const [typeId, id] of Object.entries(fallback)) {
      assert.equal(blueprintFor(typeId).id, id, typeId);
    }
  });

  test("sans type : jamais un mariage supposé", () => {
    assert.equal(blueprintFor(null).id, "generique");
    assert.equal(blueprintFor(undefined).id, "generique");
    assert.equal(blueprintFor("inconnu/slug").id, "generique");
  });
});

/* ------------------------------------------------------------------ */
/* 4. storyFromAnswers : le récit produit (formulations actuelles)     */
/* ------------------------------------------------------------------ */

/* Récit produit par le parcours. ÉVOLUTION DÉLIBÉRÉE (étapes 3/4) : les
   phrases proviennent désormais du registre de questions universelles (et
   plus des formulations propres à chaque blueprint). Les informations
   extraites — date, lieu, nombre, budget — restent strictement équivalentes :
   seule la formulation du récit change, sans vocabulaire mariage/événement. */
describe("storyFromAnswers — récit piloté par le registre", () => {
  test("mariage : phrase exacte produite par le parcours", () => {
    const a = heroAnswers("evenement/mariage", {
      quand: "2027-08-14",
      ou: "Lille",
      budget: "25000",
      qui: "120",
    });
    assert.equal(
      storyFromAnswers(a),
      "C'est un projet de type Mariage. " +
        "La date visée est le 14 août 2027. " +
        "Le projet se situe à Lille. " +
        "Ce projet réunit environ 120 personnes. " +
        "Le budget est d'environ 25000 €.",
    );
  });

  test("concert : préfixe de type + aucun vocabulaire mariage", () => {
    const a = heroAnswers("musique/concert", {
      quand: "2027-06-03",
      ou: "Roubaix",
      budget: "8000",
      qui: "300",
    });
    const story = storyFromAnswers(a);
    assert.equal(
      story,
      "C'est un projet de type Concert. " +
        "La date visée est le 3 juin 2027. " +
        "Le projet se situe à Roubaix. " +
        "Ce projet réunit environ 300 personnes. " +
        "Le budget est d'environ 8000 €.",
    );
    assert.ok(!/mari|invité|jour j|cérémonie/i.test(story), story);
  });

  test("le récit libre prime et porte le type en suffixe", () => {
    assert.equal(
      storyFromAnswers({ type: "evenement/mariage", libre: "On se marie à la mer." }),
      "On se marie à la mer. (Projet : Mariage.)",
    );
    assert.equal(storyFromAnswers({ libre: "Un concert au parc." }), "Un concert au parc.");
    assert.equal(storyFromAnswers({}), "");
  });

  test("les blancs sont ignorés proprement", () => {
    assert.equal(
      storyFromAnswers({ type: "musique/dj", quand: "   " }),
      "C'est un projet de type DJ.",
    );
  });
});

/* ------------------------------------------------------------------ */
/* 5. readStory : le repérage regex actuel                             */
/* ------------------------------------------------------------------ */

describe("readStory — repérage actuel", () => {
  test("date et invités extraits d'une phrase de mariage", () => {
    const r = readStory("On se marie le 14 août 2027 à Lille, 120 invités.", new Date(NOW));
    assert.equal(r.day, new Date(2027, 7, 14).getTime());
    assert.equal(r.guests, 120);
    /* QUIRK ACTUEL (documenté) : la regex « ville » exige `\b` (ASCII) devant
       « à » ; « …2027 à Lille » (espace + lettre accentuée) n'est donc pas
       reconnu — la ville n'arrive que via readingFromAnswers ou AIME INTENT.
       Ne pas corriger ici : traité par les étapes 5/6 de la Vague 3. */
    assert.equal(r.city, null);
    assert.equal(r.ceremonyH, null);
    assert.equal(r.couple, null);
    assert.deepEqual(r.booked, []);
  });

  test("lieu et heure de cérémonie", () => {
    const r = readStory(
      "Réception au Château des Lilas à Lille, cérémonie à 15h30.",
      new Date(NOW),
    );
    /* QUIRK ACTUEL (documenté) : titleCase capitalise chaque mot de plus de
       deux lettres (« Des »). */
    assert.equal(r.venue, "Château Des Lilas");
    assert.equal(r.ceremonyH, 15.5);
  });

  test("prestataires cités comme réservés, limités aux rôles mariage", () => {
    const r = readStory(
      "Le lieu est réservé et le photographe choisi, le menu avec notre traiteur signé.",
      new Date(NOW),
    );
    assert.deepEqual(
      r.booked.map((b) => b.role).sort(),
      ["Lieu de réception", "Photographe", "Traiteur"].sort(),
    );
  });

  test("couple détecté, date numérique supportée", () => {
    const r = readStory("Camille et Sofiane, mariage le 12/09/2027.", new Date(NOW));
    assert.equal(r.couple, "Camille & Sofiane");
    assert.equal(r.day, new Date(2027, 8, 12).getTime());
  });

  test("date sans année : bascule à l'année prochaine si passée", () => {
    const r = readStory("mariage le 14 février", new Date(NOW));
    assert.equal(r.day, new Date(2027, 1, 14).getTime());
  });
});

/* ------------------------------------------------------------------ */
/* 6. projectFromJourney : la chaîne complète actuelle                 */
/* ------------------------------------------------------------------ */

describe("projectFromJourney — monde actuel", () => {
  test("MARIAGE : typeId, kind, faits, places, déroulé, rétroplanning", () => {
    const a = heroAnswers("evenement/mariage", {
      quand: "2027-08-14",
      ou: "Lille",
      budget: "25000",
      qui: "120",
    });
    const p = projectFromJourney(a, { now: NOW });
    assert.ok(p);
    /* Le Domaine est la source de vérité du projet. */
    assert.equal(p.kind, "mariage");
    assert.equal(p.universe, "Événement");
    assert.equal(p.title, "Votre mariage");
    assert.equal(p.id, "mariage");
    /* Les faits extraits. */
    assert.equal(p.pivot.value, new Date(2027, 7, 14).getTime());
    assert.equal(p.pivot.confidence, "confirme");
    assert.equal(p.city.value, "Lille");
    assert.equal(p.guests.value, 120);
    assert.equal(p.guests.confidence, "confirme");
    assert.equal(p.venue.value, null);
    /* Le monde du blueprint mariage, inaltéré. */
    assert.equal(p.providers.length, 12);
    assert.equal(p.moments.length, 15);
    assert.equal(p.tasks.length, 15);
    assert.ok(p.providers.every((pr) => pr.status === "a_rechercher"));
    /* Le récit est conservé comme première intention. */
    assert.equal(p.intentions.length, 1);
    assert.ok(p.intentions[0]!.text.startsWith("C'est un projet de type Mariage."));
    assert.equal(p.lifecycle, "brouillon");
    assert.equal(p.demo, false);
  });

  test("CONCERT : le monde prend le moteur concert", () => {
    const a = heroAnswers("musique/concert", {
      quand: "2027-06-03",
      ou: "Roubaix",
      budget: "8000",
      qui: "300",
    });
    const p = projectFromJourney(a, { now: NOW });
    assert.ok(p);
    assert.equal(p.kind, "concert");
    assert.equal(p.universe, "Musique & Scène");
    assert.equal(p.title, "Votre concert");
    assert.equal(p.pivot.value, new Date(2027, 5, 3).getTime());
    assert.equal(p.guests.value, 300);
    assert.equal(p.providers.length, 9);
    assert.equal(p.moments.length, 9);
    assert.equal(p.tasks.length, 12);
    assert.ok(p.providers.some((pr) => pr.role === "Sonorisation"));
  });

  test("sans réponse mais parcours commencé : monde indicatif, jamais bloquant", () => {
    const p = projectFromJourney({ type: "evenement/mariage" }, { now: NOW, force: true });
    assert.ok(p);
    assert.equal(p.kind, "mariage");
    assert.equal(p.pivot.confidence, "a_confirmer");
    /* projectFromJourney ajoute en tête : d'abord la date, puis la ville
       (deux unshifts successifs — la ville passe devant la date). */
    assert.equal(p.missing[0], "La ville n'est pas encore connue.");
    assert.equal(p.missing[1], "La date n'est pas encore fixée — le déroulé reste indicatif.");
  });

  test("sans récit et sans force : rien n'est inventé", () => {
    assert.equal(projectFromJourney({}, { now: NOW }), null);
  });

  test("journeySummary : les regards actuels, budget décliné en ligne de détail", () => {
    /* Étape 12 : les détails rejoignent la synthèse (libellés humains).
       Le montant budgétaire — detail de fait par convention étape 5 —
       apparaît désormais entre le cercle et les ressources. */
    const a = heroAnswers("evenement/mariage", {
      quand: "2027-08-14",
      ou: "Lille",
      budget: "25000",
      qui: "120",
    });
    const p = projectFromJourney(a, { now: NOW });
    assert.ok(p);
    const s = journeySummary(p);
    assert.deepEqual(
      s.map((x) => x.label),
      ["Quand", "Où", "Qui", "Budget", "Ce qui existe", "Ce qui est souhaité"],
    );
    assert.equal(s[3]!.confidence, "confirme");
    assert.equal(s[0]!.value, "14 août 2027");
    assert.equal(s[1]!.value, "Lille");
    assert.equal(s[2]!.value, "120 personnes");
  });
});

/* ------------------------------------------------------------------ */
/* 7. projectFromReading : propagation du typeId (REPLI ACTUEL inclus) */
/* ------------------------------------------------------------------ */

describe("projectFromReading — typeId jusqu'au monde", () => {
  const empty = {
    day: null,
    city: null,
    venue: null,
    guests: null,
    ceremonyH: null,
    couple: null,
    booked: [],
  };

  test("VIDEASTE (repli artistique) : kind = domaine, monde = blueprint de repli", () => {
    const p = projectFromReading(empty, "Un film de famille.", NOW, "image/videaste");
    assert.equal(p.kind, "videaste");
    assert.equal(p.universe, "Image & Souvenirs");
    assert.equal(p.title, "Votre vidéaste");
    /* REPLI ACTUEL : rôles et rétroplanning du projet artistique. */
    assert.deepEqual(
      p.providers.map((pr) => pr.role),
      ["Direction artistique", "Studio / atelier", "Collaborateurs", "Technique", "Diffusion"],
    );
    /* Sans date : pivot indicatif à +400 jours, jamais bloquant. */
    assert.equal(p.pivot.confidence, "a_confirmer");
  });

  test("IMMO VENTE / CHEF / MENTORAT / BÉNÉVOLAT : le kind suit toujours le Domaine", () => {
    const cases: [string, string, string][] = [
      ["patrimoine/immo-vente", "immo-vente", "generique"],
      ["table/chef", "chef", "celebration"],
      ["lien/mentorat", "mentorat", "generique"],
      ["solidarite/benevolat", "benevolat", "association"],
    ];
    for (const [typeId, kind, bp] of cases) {
      const p = projectFromReading(empty, "Récit.", NOW, typeId);
      assert.equal(p.kind, kind, typeId);
      assert.equal(p.id, bp, typeId);
      assert.ok(p.guests.value === null, typeId);
    }
  });

  test("sans typeId : blueprint générique, kind hérité du blueprint", () => {
    const p = projectFromReading(empty, "Un projet à préciser.", NOW, null);
    assert.equal(p.id, "generique");
    assert.equal(p.kind, "projet");
    assert.equal(p.universe, "Projet");
  });

  test("un prestataire réservé hors rôles du blueprint est écarté (comportement actuel)", () => {
    const p = projectFromReading(
      { ...empty, booked: [{ role: "Photographe" }, { role: "Régie technique" }] },
      "Récit.",
      NOW,
      "musique/concert",
    );
    const reserved = p.providers.filter((pr) => pr.status !== "a_rechercher");
    assert.deepEqual(
      reserved.map((pr) => pr.role),
      ["Régie technique"],
    );
  });
});

/* ------------------------------------------------------------------ */
/* 8. buildProject / scheduleRetro : invariants du moteur              */
/* ------------------------------------------------------------------ */

describe("moteur de monde — invariants", () => {
  test("scheduleRetro : rien dans le passé, rien après J, dépendances respectées", () => {
    const bp = blueprintFor("evenement/mariage");
    const day = NOW + 90 * 86_400_000; /* date proche : le rétro se resserre */
    const at = scheduleRetro(bp.retro, day, NOW);
    for (const r of bp.retro) {
      const t = at[r.key];
      assert.ok(t != null, r.key);
      if (r.days > 0) {
        assert.ok(t! >= NOW, `${r.key} dans le passé`);
        assert.ok(t! < day, `${r.key} après le jour J`);
        for (const dep of r.after ?? []) assert.ok(t! >= at[dep]!, `${r.key} avant ${dep}`);
      }
    }
  });

  test("buildProject : moments calés sur l'heure pivot connue reste explicite", () => {
    const bp: Blueprint = blueprintFor("musique/concert");
    const day = new Date(2027, 5, 3).getTime();
    const p = buildProject(bp, { day, pivotH: 21, now: NOW, typeId: "musique/concert" });
    const pivot = p.moments.find((m) => m.id === "concert");
    assert.equal(pivot?.offsetH, 21);
    assert.equal(pivot?.confidence, "confirme");
    /* Les autres moments glissent avec l'heure, en suggestion. */
    const ouverture = p.moments.find((m) => m.id === "ouverture");
    assert.equal(ouverture?.offsetH, 20);
    assert.equal(ouverture?.confidence, "suggere");
  });

  test("buildProject : le kind et le titre viennent du ProjectType, pas du blueprint", () => {
    const bp = blueprintFor("image/videaste");
    const p = buildProject(bp, { day: NOW + 30 * 86_400_000, now: NOW, typeId: "image/videaste" });
    assert.equal(p.kind, "videaste");
    assert.equal(p.title, "Votre vidéaste");
    assert.equal(p.universe, "Image & Souvenirs");
    /* Mais l'id du monde reste celui du moteur employé. */
    assert.equal(p.id, "artistique");
  });

  test("projectTypeById : seuls les 73 ids réels sont reconnus", () => {
    assert.equal(projectTypeById("evenement/mariage")?.blueprintId, "mariage");
    assert.equal(projectTypeById("mariage"), null);
    assert.equal(projectTypeById("evenement/inconnu"), null);
    assert.equal(projectTypeById(""), null);
  });
});

/* ------------------------------------------------------------------ */
/* 9. readingFromAnswers : le repérage immédiat à partir des réponses  */
/* ------------------------------------------------------------------ */

describe("readingFromAnswers — fusion actuelle", () => {
  test("une ville courte reste une ville, un domaine devient un lieu", () => {
    const ville = readingFromAnswers({ ou: "Lille" }, new Date(NOW));
    assert.equal(ville.city, "Lille");
    assert.equal(ville.venue, null);
    const domaine = readingFromAnswers({ ou: "Domaine des Tilleuls" }, new Date(NOW));
    /* QUIRK ACTUEL (documenté) : même titleCase que readStory (« Des »). */
    assert.equal(domaine.venue, "Domaine Des Tilleuls");
    assert.equal(domaine.city, null);
  });

  test("« je ne sais pas » n'écrase jamais un fait", () => {
    const r = readingFromAnswers({ ou: "Je ne sais pas encore", qui: "aucune idée" }, new Date(NOW));
    assert.equal(r.city, null);
    assert.equal(r.guests, null);
  });
});
