/**
 * Packs B des 12 univers (Vague 3, étape 8) : registre déclaratif,
 * composition A + B dans questionsFor, remplacement / dédoublonnage,
 * et invariants sur les 73 Domaines. Aucun pack C n'existe encore : le
 * mécanisme qui les accueillera est cumulé et prouvé ici sur des fixtures.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { UNIVERSE_TREE } from "@/lib/aime/universeTree";
import { PROJECT_TYPES } from "../blueprints";
import {
  A_PACK,
  A_PACK_BY_KEY,
  B_PACK_BY_UNIVERSE,
  composeQuestions,
  journeyQuestionCount,
  questionsFor,
  validateQuestionSpec,
  type QuestionSpec,
} from "../questions";
import { intentContextFor } from "../storyIntent";

const keys = (seq: readonly QuestionSpec[]) => seq.map((q) => q.key);
const uniq = <T,>(xs: readonly T[]) => new Set(xs).size === xs.length;

/* ------------------------------------------------------------------ */
/* Registre                                                            */
/* ------------------------------------------------------------------ */

describe("B_PACK_BY_UNIVERSE — registre des 12 univers", () => {
  test("exactement les 12 univers existants, ni plus ni moins", () => {
    assert.deepEqual(
      Object.keys(B_PACK_BY_UNIVERSE).sort(),
      UNIVERSE_TREE.map((u) => u.slug).sort(),
    );
  });

  test("chaque question de chaque pack est une QuestionSpec valide, niveau B", () => {
    for (const [universe, pack] of Object.entries(B_PACK_BY_UNIVERSE)) {
      assert.ok(pack.length >= 1, `${universe} : pack non vide`);
      for (const q of pack) {
        assert.deepEqual(validateQuestionSpec(q), [], `${universe}.${q.key}`);
        assert.equal(q.level, "B", `${universe}.${q.key} : niveau B`);
      }
    }
  });

  test("aucune clé dupliquée au sein d'un même pack", () => {
    for (const [universe, pack] of Object.entries(B_PACK_BY_UNIVERSE)) {
      assert.ok(uniq(keys(pack)), `${universe}`);
    }
  });

  test("chaque replaces pointe vers une question du socle A", () => {
    for (const [universe, pack] of Object.entries(B_PACK_BY_UNIVERSE)) {
      for (const q of pack) {
        if (!q.replaces) continue;
        assert.ok(
          A_PACK_BY_KEY[q.replaces],
          `${universe}.${q.key} : replaces « ${q.replaces} » absent du socle`,
        );
      }
    }
  });

  test("un seul ajout métier par univers : le plafond 6 est tenu à la source", () => {
    for (const [universe, pack] of Object.entries(B_PACK_BY_UNIVERSE)) {
      const additions = pack.filter(
        (q) => !A_PACK_BY_KEY[q.key] && !q.replaces,
      );
      assert.ok(
        additions.length <= 1,
        `${universe} : ${additions.length} ajouts (> 1 dépasserait 6)`,
      );
    }
  });

  test("même sens = même clé : « cadre » (musique + culture) partage un vocabulaire commun", () => {
    const B = B_PACK_BY_UNIVERSE;
    const find = (u: string, k: string) => B[u]!.find((q) => q.key === k);
    /* Socle commun privé/public : une valeur identique = une chaîne
       identique dans les deux univers (les variantes métier — studio,
       création — restent autorisées en plus) ; même gabarit de phrase. */
    const CADRE_COMMUN = ["au public, en accès libre", "au public, en billetterie"];
    for (const c of CADRE_COMMUN) {
      assert.ok(find("musique", "cadre")?.choices?.includes(c), `musique : « ${c} »`);
      assert.ok(find("culture", "cadre")?.choices?.includes(c), `culture : « ${c} »`);
    }
    assert.equal(
      find("musique", "cadre")?.sentence("au public"),
      find("culture", "cadre")?.sentence("au public"),
    );
    assert.deepEqual(find("image", "occasion")?.choices, find("style", "occasion")?.choices);
    assert.equal(
      find("image", "occasion")?.sentence("pour une fête"),
      find("style", "occasion")?.sentence("pour une fête"),
    );
    /* Dix clés sémantiques stables pour douze univers (deux réutilisations). */
    const detailKeys = new Set(
      Object.values(B)
        .flat()
        .filter((q) => q.mapsTo.startsWith("detail:"))
        .map((q) => q.mapsTo),
    );
    assert.equal(detailKeys.size, 10);
  });
});

/* ------------------------------------------------------------------ */
/* Composition : les 7 Domaines obligatoires                           */
/* ------------------------------------------------------------------ */

const ADD_KEY: Record<string, string> = {
  "evenement/mariage": "moment-journee",
  "musique/concert": "cadre",
  "image/videaste": "occasion",
  "patrimoine/immo-vente": "operation",
  "table/chef": "service",
  "lien/mentorat": "cadre-relation",
  "solidarite/benevolat": "beneficiaires",
};

describe("questionsFor — composition A + B sur les Domaines de référence", () => {
  for (const [typeId, added] of Object.entries(ADD_KEY)) {
    test(`${typeId} : socle + B du bon univers bien posés (C peut spécialiser)`, () => {
      const seq = questionsFor(typeId);
      assert.deepEqual( // 6 par défaut, 7 seulement en liste blanche
        [seq.length >= 6 && seq.length <= 7, uniq(keys(seq))],
        [true, true],
      );
      assert.ok(seq.some((q) => q.level === "B"), "relibellages univers présents");
      /* L'ajout B est soit là (relibellage C possible, même clé), soit il a
         cédé sa place in-place via un replaces du pack C. */
      if (keys(seq).includes(added)) {
        assert.ok(["B", "C"].includes(seq.find((q) => q.key === added)!.level));
      } else {
        const replacer = seq.find((q) => q.replaces === added);
        assert.equal(replacer?.level, "C", `« ${added} » remplacé par un C`);
      }
      for (const q of seq) {
        assert.deepEqual(validateQuestionSpec(q), [], `${typeId}.${q.key}`);
        assert.equal(typeof q.sentence("exemple"), "string");
      }
    });
  }

  test("concert ne retombe pas sur l'événement/mariage", () => {
    const seq = questionsFor("musique/concert");
    assert.ok(!keys(seq).includes("moment-journee"), "pas le pack Événement");
    assert.equal(seq.find((q) => q.key === "ou")?.level, "A", "socle générique conservé où il faut");
  });
});

/* ------------------------------------------------------------------ */
/* Invariants sur les 73 Domaines                                      */
/* ------------------------------------------------------------------ */

describe("invariants sur les 73 Domaines", () => {
  test("séquence valide, 6 ou 7 questions, clés uniques", () => {
    for (const t of PROJECT_TYPES) {
      const seq = questionsFor(t.id);
      /* Étape 9 : 6 par défaut ; 7 uniquement pour les 8 domaines en liste
         blanche (voir C_LONG_JOURNEY_DOMAINS, test dédié dans cPacks). */
      assert.ok(seq.length >= 6 && seq.length <= 7, t.id);
      assert.ok(uniq(keys(seq)), t.id);
      for (const q of seq) assert.deepEqual(validateQuestionSpec(q), [], `${t.id}.${q.key}`);
    }
  });

  test("le compteur de l'étape 7 suit automatiquement, pour les 73 Domaines", () => {
    for (const t of PROJECT_TYPES) {
      assert.equal(journeyQuestionCount(t.id), questionsFor(t.id).length, t.id);
    }
    assert.equal(journeyQuestionCount("evenement/mariage"), 6);
  });

  test("aucun Domaine ne retombe sur le pack d'un autre univers", () => {
    /* Chaque question de niveau B posée pour un Domaine est une INSTANCE
       exacte du pack de SON univers (nulle part ailleurs) — la C du
       Domaine peut en remplacer certaines, jamais en réinjecter d'une
       autre univers. */
    for (const u of UNIVERSE_TREE) {
      for (const s of u.subs) {
        const seq = questionsFor(`${u.slug}/${s.slug}`);
        for (const q of seq.filter((x) => x.level === "B")) {
          assert.ok(
            B_PACK_BY_UNIVERSE[u.slug]!.some((b) => b === q),
            `${u.slug}/${s.slug} : « ${q.key} » n'est pas issu du pack « ${u.slug} »`,
          );
        }
      }
    }
  });

  test("ordre strictement déterministe : deux appels identiques", () => {
    for (const typeId of Object.keys(ADD_KEY)) {
      assert.deepEqual(keys(questionsFor(typeId)), keys(questionsFor(typeId)));
    }
  });
});

/* ------------------------------------------------------------------ */
/* Remplacement / dédoublonnage                                        */
/* ------------------------------------------------------------------ */

describe("remplacement et dédoublonnage", () => {
  test("relibellage « même key » : en place, mapsTo et sentence hérités du socle", () => {
    const seq = questionsFor("evenement/mariage");
    const quand = seq.find((q) => q.key === "quand");
    const base = A_PACK_BY_KEY["quand"]!;
    assert.equal(quand?.level, "B");
    assert.equal(seq.indexOf(quand!), 0, "position conservée");
    assert.equal(quand?.mapsTo, base!.mapsTo, "même slot canonique (compatibilité)");
    assert.equal(quand?.sentence("2027-08-14"), base!.sentence("2027-08-14"));
    assert.equal(seq.filter((q) => q.key === "quand").length, 1);
  });

  test("replaces : « destination » remplace « ou » pour le voyage (vrai cas registre)", () => {
    const seq = questionsFor("voyage/sejour-groupe");
    /* Le pack C y adjoint « duree » (liste blanche) — sauf cela, la place
       de « destination » est inchangée. */
    assert.deepEqual(keys(seq), ["quand", "destination", "qui", "budget", "intention", "mobilite", "duree"]);
    const destination = seq[1];
    assert.equal(destination!.mapsTo, "place", "même slot canonique : récit et monde inchangés");
    assert.ok(!keys(seq).includes("ou"), "la remplacée a disparu");
  });

  test("B sans replaces s'ajoute à la fin, dans l'ordre déclaré", () => {
    const extra: QuestionSpec[] = [
      { ...A_PACK_BY_KEY["budget"]!, key: "z-ajout", level: "B" },
      { ...A_PACK_BY_KEY["budget"]!, key: "a-ajout", level: "B" },
    ];
    assert.deepEqual(
      keys(composeQuestions(A_PACK, extra)).slice(-2),
      ["z-ajout", "a-ajout"],
    );
  });

  test("aucun doublon lorsqu'un futur pack C remplacera B (ou A)", () => {
    const fakeC: QuestionSpec[] = [
      /* C reformule une question B sous une nouvelle clé : */
      { ...A_PACK_BY_KEY["budget"]!, key: "budget-immo", level: "C", replaces: "budget" },
      /* C reprend la clé d'une question B existante : */
      { ...A_PACK_BY_KEY["quand"]!, key: "operation", level: "C" },
    ];
    const seq = composeQuestions(A_PACK, B_PACK_BY_UNIVERSE["patrimoine"]!, fakeC);
    assert.ok(uniq(keys(seq)), "clés uniques à travers trois packs");
    assert.ok(!keys(seq).includes("budget"), "« budget » remplacé");
    assert.equal(seq.find((q) => q.key === "operation")?.level, "C", "C prime sur B");
    assert.equal(keys(seq).indexOf("operation"), 5, "position du pack B conservée");
    assert.equal(seq.length, 6, "le remplacement ne rallonge pas la séquence");
  });

  test("deux specs de même key dans un pack : une seule survivante (la dernière)", () => {
    const dup: QuestionSpec[] = [
      { ...A_PACK_BY_KEY["quand"]!, key: "heure", level: "B" },
      { ...A_PACK_BY_KEY["quand"]!, key: "heure", level: "B", label: "Heure bis" },
    ];
    const seq = composeQuestions(A_PACK, dup);
    assert.equal(seq.filter((q) => q.key === "heure").length, 1);
    assert.equal(seq.find((q) => q.key === "heure")?.label, "Heure bis");
  });

  test("composeQuestions est strictement déterministe", () => {
    const a = keys(composeQuestions(A_PACK, B_PACK_BY_UNIVERSE["voyage"]!));
    const b = keys(composeQuestions(A_PACK, B_PACK_BY_UNIVERSE["voyage"]!));
    assert.deepEqual(a, b);
  });
});

/* ------------------------------------------------------------------ */
/* Descente dans le monde : les nouveaux details restent plombés       */
/* ------------------------------------------------------------------ */

describe("AIME INTENT hérité : le registre étendu borne toujours les faits", () => {
  test("les clés details lues par le modèle viennent toujours du registre", () => {
    const ctx = intentContextFor("musique/concert");
    assert.ok(ctx.detailKeys.includes("budget"));
    assert.ok(ctx.detailKeys.includes("cadre"), "le fait du pack musique est autorisé, rien d'autre");
    assert.ok(!ctx.detailKeys.includes("moment-journee"), "pas de faits d'un autre univers");
  });
});
