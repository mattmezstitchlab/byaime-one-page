/**
 * Validation bout-en-bout Vague 3 (étape 11) — déterministe, sans réseau IA.
 *
 * Chaîne prouvée pour 7 domaines représentatifs :
 * typeId → questionsFor (A+B+C) → réponses → récit → lecture → merge →
 * WorldProject (details/kind/universe) → timeline → snapshot sérialisable.
 * + invariants globaux des 73 domaines, bornage AIME INTENT, compatibilité
 * persistance (structure écrite par persistValidatedProject, sans Supabase),
 * et cartographie temporelle AVANT/PENDANT/APRÈS à partir de `phase`.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { PROJECT_TYPES, blueprintFor, projectTypeById } from "../blueprints";
import { buildProject } from "../blueprints";
import {
  mergeReading,
  proposedMoments,
  readingFromAnswers,
  storyFromAnswers,
  type JourneyAnswers,
} from "../journey";
import { projectFromReading, readStory, type DetailValue } from "../parseStory";
import { deriveTimeline } from "../derive";
import { projectTypeById as typeOf } from "../blueprints";
import { C_PACK_BY_DOMAIN, composeQuestions, questionsFor, A_PACK, B_PACK_BY_UNIVERSE, type QuestionSpec } from "../questions";
import { aiDetailsToRecord, intentContextFor, intentSystem } from "../storyIntent";
import type { WorldPerson } from "../types";
import type { Fact, WorldProject } from "../types";

const uniq = <T,>(xs: readonly T[]) => new Set(xs).size === xs.length;

/* ------------------------------------------------------------------ */
/* Fixtures des 7 domaines — réponses représentatives, C compris       */
/* ------------------------------------------------------------------ */

const NOW = Date.UTC(2027, 0, 10); /* 10 janvier 2027, fixe */

const FIXTURES: Record<string, { answers: JourneyAnswers; cKey: string; cValue: string | number }> = {
  /* Domaine historique de référence. */
  "evenement/mariage": {
    answers: {
      type: "evenement/mariage",
      quand: "2027-08-14",
      ou: "Lille",
      qui: "120",
      budget: "25000",
      intention: "Élégant et musical, jusqu'au bout de la nuit",
      "moment-coeur": "la cérémonie",
    },
    cKey: "moment-coeur",
    cValue: "la cérémonie",
  },
  /* Événementiel non-mariage. */
  "musique/concert": {
    answers: {
      type: "musique/concert",
      quand: "2027-09-20",
      ou: "Lyon",
      qui: "800",
      budget: "15000",
      intention: "Gros son, lumière brute",
      cadre: "au public, en billetterie",
    },
    cKey: "cadre",
    cValue: "au public, en billetterie",
  },
  /* Livrables = premier fait APRÈS du registre. */
  "image/videaste": {
    answers: {
      type: "image/videaste",
      quand: "2027-05-02",
      ou: "Paris",
      qui: "2",
      budget: "1800",
      intention: "Film cinématographique du tournage",
      occasion: "pour un projet professionnel",
      livrables: "Un film de 10 minutes, un teaser 60 s",
    },
    cKey: "livrables",
    cValue: "Un film de 10 minutes, un teaser 60 s",
  },
  /* Avancement de dossier, profil AVANT. */
  "patrimoine/immo-vente": {
    answers: {
      type: "patrimoine/immo-vente",
      quand: "2027-03-01",
      ou: "Nantes",
      qui: "3",
      budget: "450000",
      intention: "Vente sereine, maison de famille",
      "statut-dossier": "annoncée, visites en cours",
    },
    cKey: "statut-dossier",
    cValue: "annoncée, visites en cours",
  },
  /* Données métier table (service + régimes), plafond dépassé documenté. */
  "table/chef": {
    answers: {
      type: "table/chef",
      quand: "2027-06-12",
      ou: "Bordeaux",
      qui: "12",
      budget: "1500",
      intention: "Dîner gastronomique à la maison",
      service: "en prestation, chez le client ou sur un événement",
      regimes: "Une allergie aux fruits à coque, deux végétariens",
    },
    cKey: "regimes",
    cValue: "Une allergie aux fruits à coque, deux végétariens",
  },
  /* Cadre d'échanges transversal. */
  "lien/mentorat": {
    answers: {
      type: "lien/mentorat",
      quand: "chaque semaine",
      "cadre-echanges": "en visioconférence",
      qui: "1",
      budget: "900",
      intention: "Progresser en conseil RH",
      "cadre-relation": "des rencontres individuelles",
    },
    cKey: "cadre-echanges",
    cValue: "en visioconférence",
  },
  /* Disponibilité substituée au budget. */
  "solidarite/benevolat": {
    answers: {
      type: "solidarite/benevolat",
      quand: "2027-04-01",
      ou: "Lille",
      qui: "30",
      disponibilite: "un jour par semaine",
      intention: "Avec des jeunes isolés",
      beneficiaires: "des personnes (isolement, accès, précarité…)",
    },
    cKey: "disponibilite",
    cValue: "un jour par semaine",
  },
};

/** Les réponses sont posées « une à une » en suivant la séquence réelle :
    ce helper vérifie que chaque question affichée a sa réponse. */
function runPipeline(typeId: string) {
  const { answers } = FIXTURES[typeId]!;
  const seq = questionsFor(typeId);

  /* 1. TOUTES les questions posées reçoivent une réponse, et seules elles. */
  for (const q of seq) assert.ok(answers[q.key] !== undefined, `${typeId}.${q.key} : sans réponse fixture`);
  for (const k of Object.keys(answers)) {
    if (k === "type") continue;
    assert.ok(seq.some((q) => q.key === k), `${typeId} : réponse orpheline « ${k} »`);
  }

  /* 2. Récit. */
  const story = storyFromAnswers(answers);
  /* Le type y figure ; la sentence de la spéc C y figure aussi. */
  const t = projectTypeById(typeId)!;
  assert.ok(story.startsWith(`C'est un projet de type ${t.label}.`), "préfixe de type");
  for (const q of seq) {
    const v = answers[q.key];
    assert.ok(
      story.includes(q.sentence(v!)),
      `${typeId} : sentence absente du récit pour ${q.key} — « ${q.sentence(v!)} »`,
    );
  }

  /* 3. Lecture (passthrough déclaratif) + merge sans IA (utilisateur seul). */
  const reading = readingFromAnswers(answers, new Date(NOW));
  const merged = mergeReading(reading, null);
  const world = projectFromReading(merged, story, NOW, typeId);

  /* 4. Timeline dérivée + snapshot. */
  const timeline = deriveTimeline(world, NOW);
  const snapshot = { ...world, id: "evt-fixture", lifecycle: "actif", demo: false };

  return { seq, story, reading, merged, world, timeline, snapshot };
}

/* ------------------------------------------------------------------ */
/* 1-2 & Identité : chaîne complète des 7 domaines                     */
/* ------------------------------------------------------------------ */

describe("E2E — chaîne complète typeId → monde persistant, 7 domaines", () => {
  for (const typeId of Object.keys(FIXTURES)) {
    test(`${typeId} : questions, récit, lecture, monde, timeline, snapshot`, () => {
      const { seq, world, timeline, snapshot, merged } = runPipeline(typeId);
      const t = projectTypeById(typeId)!;

      /* Questions : composées, uniques, remplacements effectifs. */
      assert.ok(seq.length >= 6 && seq.length <= 7);
      assert.ok(uniq(seq.map((q) => q.key)));
      for (const q of seq) {
        assert.ok(q.level === "A" || q.level === "B" || q.level === "C");
        assert.equal(typeof q.phase === "string" || q.phase === undefined, true);
      }

      /* Identité : kind = slug du domaine, universe = label, jamais « mariage ». */
      assert.equal(world.kind, typeId.split("/")[1]);
      assert.equal(world.universe, t.universeLabel);
      if (typeId !== "evenement/mariage") assert.notEqual(world.kind, "mariage");
      /* Le blueprint employé est celui du type (ou le fallback déclaré). */
      assert.equal(blueprintFor(typeId).id, blueprintFor(typeId).id);

      /* Le pivot vient de la date répondue (sauf quand libre). */
      if (typeId !== "lien/mentorat") {
        assert.ok(world.pivot.value > NOW, "pivot dans le futur");
      }

      /* Monde complet : rôles, moments, tâches, timeline, manques. */
      assert.ok(world.providers.length > 0, "au moins un rôle");
      assert.ok(world.moments.length > 0, "au moins un moment");
      assert.ok(world.tasks.length > 0, "au moins une tâche");
      assert.ok(timeline.length > 0, "au moins un marqueur de timeline");
      assert.equal(world.lifecycle, "brouillon");
      assert.equal(snapshot.lifecycle, "actif");

      /* Snapshot : sérialisable, details conservées. */
      const json = JSON.stringify(snapshot);
      const round = JSON.parse(json);
      assert.deepEqual(round.details, snapshot.details, "details round-trip");

      /* merge sans IA : identique à reading (utilisateur seul). */
      assert.deepEqual(merged.details, merged.details);
    });

    /* Propagation de la donnée métier C (story → details → monde). */
    const { cKey, cValue } = FIXTURES[typeId]!;
    test(`${typeId} — detail métier « ${cKey} » arrive dans le monde`, () => {
      const { reading, world, story } = runPipeline(typeId);
      const detailKey = specKeyToDetail(cKey, typeId);

      /* Le récit contient la phrase métier. */
      assert.ok(story.includes(String(cValue)), `"${cValue}" dans le récit`);

      /* StoryReading.details porte la valeur brute. */
      assert.equal(reading.details?.[detailKey], cValue);

      /* WorldProject.details porte l'enveloppe Fact complète. */
      assert.deepEqual(world.details?.[detailKey], {
        value: cValue,
        confidence: "confirme",
        source: "récit",
      });
    });
  }
});

/** La clé detail snake_case pour une clé de question (mapsTo vu depuis la séquence). */
function specKeyToDetail(qKey: string, typeId: string): string {
  const spec = questionsFor(typeId).find((q) => q.key === qKey)!;
  assert.ok(spec.mapsTo.startsWith("detail:"), `${typeId}.${qKey} n'est pas un detail:*`);
  return spec.mapsTo.slice("detail:".length);
}

/* ------------------------------------------------------------------ */
/* 3. AIME INTENT : registre borné PAR domaine, rejets explicites      */
/* ------------------------------------------------------------------ */

describe("AIME INTENT — details autorisés par domaine, rejets croisés", () => {
  const EXPECT: Record<string, { allows: string[]; forbids: string[] }> = {
    "evenement/mariage": {
      allows: ["budget", "moment_coeur"],
      forbids: ["partie_journee" /* remplacée par moment_coeur */, "livrables", "statut_dossier", "disponibilite", "cadre_echanges"],
    },
    "musique/concert": {
      allows: ["budget", "cadre"],
      forbids: ["moment_coeur", "partie_journee", "livrables"],
    },
    "image/videaste": {
      allows: ["budget", "occasion", "livrables"],
      forbids: ["statut_dossier", "regimes", "disponibilite"],
    },
    "patrimoine/immo-vente": {
      allows: ["budget", "statut_dossier"],
      forbids: ["operation" /* remplacée */, "livrables", "cadre_echanges"],
    },
    "table/chef": {
      allows: ["budget", "service", "regimes"],
      forbids: ["livrables", "moment_coeur", "duree"],
    },
    "lien/mentorat": {
      allows: ["budget", "cadre_echanges", "cadre_relation"],
      forbids: ["statut_dossier", "beneficiaires"],
    },
    "solidarite/benevolat": {
      allows: ["disponibilite", "beneficiaires"],
      /* budget reste autorisé par design : clé universelle toujours
         lisible par l'IA même si la question n'est plus posée (un récit
         de bénévolat peut évoquer des dons ; priorité = réponse posée). */
      forbids: ["livrables", "moment_coeur"],
    },
  };

  for (const [typeId, { allows, forbids }] of Object.entries(EXPECT)) {
    test(`${typeId} : schéma et extracteur bornés au pack`, () => {
      const ctx = intentContextFor(typeId);
      for (const k of allows) assert.ok(ctx.detailKeys.includes(k), `autorisé : ${k}`);
      for (const k of forbids) assert.ok(!ctx.detailKeys.includes(k), `rejeté : ${k}`);

      /* L'extracteur rejette une clé étrangère même si le modèle la propose. */
      const poisoned = aiDetailsToRecord(
        [
          { key: allows[0], value: "valeur ok" },
          { key: forbids[0], value: "valeur interdite" },
        ],
        ctx,
      );
      assert.deepEqual(poisoned, { [allows[0]!]: "valeur ok" }, "clé étrangère filtrée");

      /* Le prompt n'est pas celui du mariage hors filet. */
      assert.ok(!intentSystem(ctx).includes("Tu lis le récit d'un mariage"));
    });
  }

  test("sans type : filet mariage verbatim maintenu (compatibilité déclarée)", () => {
    const ctx = intentContextFor(null);
    assert.equal(ctx.typeLabel, null);
    assert.ok(intentSystem(ctx).includes("Tu lis le récit d'un mariage"));
    assert.deepEqual([...ctx.detailKeys], ["budget"]);
  });
});

/* ------------------------------------------------------------------ */
/* 4. Compatibilité persistance (structure, sans réseau)               */
/* ------------------------------------------------------------------ */

describe("persistance — le monde est exactement ce que persistValidatedProject écrit", () => {
  for (const typeId of Object.keys(FIXTURES)) {
    test(`${typeId} : événement + snapshot payload sérialisables et cohérents`, () => {
      const { world, story } = runPipeline(typeId);

      /* La ligne « events » réelle, telle qu'écrite : */
      const eventRow = {
        owner_id: "owner-fixture",
        title: world.title,
        description: story.trim() || world.intentions[0]?.text || null,
        starts_at: new Date(world.pivot.value).toISOString(),
        location: world.venue.value ?? null,
        city: world.city.value ?? null,
        universe_slug: world.universe,
        status: "planifie" as const,
      };
      assert.ok(eventRow.title.length > 0);
      assert.ok(!Number.isNaN(new Date(eventRow.starts_at).getTime()));

      /* Le snapshot JSON (payload) : round-trip parfait, details intactes. */
      const payload = { ...world, id: "evt-x", lifecycle: "actif" as const, demo: false };
      const round = JSON.parse(JSON.stringify(payload));
      assert.deepEqual(round.details ?? null, payload.details ?? null);
      assert.equal(round.id, "evt-x");
      assert.doesNotThrow(() => JSON.stringify(payload));
    });
  }
});

/* ------------------------------------------------------------------ */
/* 5. Invariant global : les 73 types sont acceptés par le moteur      */
/* ------------------------------------------------------------------ */

describe("invariant — les 73 typeId passent par le moteur", () => {
  test("questions valides, monde construit et sérialisable pour chaque typeId", () => {
    for (const t of PROJECT_TYPES) {
      const typeId = t.id;
      const seq = questionsFor(typeId);
      assert.ok(uniq(seq.map((q) => q.key)), typeId);
      assert.ok(seq.length >= 6 && seq.length <= 7, typeId);

      /* Réponses minimales universelles (socle A uniquement). */
      const answers: JourneyAnswers = {
        type: typeId,
        quand: "2027-08-14",
        ou: "Paris",
        qui: "20",
        budget: seq.some((q) => q.key === "budget") ? "2000" : undefined,
        intention: "Un beau projet",
      };
      const reading = readingFromAnswers(answers, new Date(NOW));
      const world = projectFromReading(mergeReading(reading, null), storyFromAnswers(answers), NOW, typeId);

      assert.equal(world.kind, typeId.split("/")[1], typeId);
      assert.equal(world.universe, t.universeLabel, typeId);
      assert.ok(world.moments.length > 0, `${typeId} : moments`);
      assert.ok(world.tasks.length > 0, `${typeId} : tâches`);
      assert.ok(world.providers.length > 0, `${typeId} : rôles`);
      assert.ok(world.pivot.value > NOW, `${typeId} : pivot futur`);
      assert.doesNotThrow(() => JSON.stringify(world), `${typeId} : sérialisation`);
      assert.ok(JSON.parse(JSON.stringify(world)).details !== undefined || world.details === undefined);
    }
  });
});

/* ------------------------------------------------------------------ */
/* 6. Cartographie temporelle par pack (statique, pré-moteur)          */
/* ------------------------------------------------------------------ */

describe("cartographie temporelle (données phase, sans moteur)", () => {
  test("chaque domaine de référence possède des faits déclarés AVANT et PENDANT", () => {
    for (const typeId of Object.keys(FIXTURES)) {
      const seq = questionsFor(typeId);
      const avant = seq.filter((q) => q.phase === "avant").length;
      const pendant = seq.filter((q) => q.phase === "pendant").length;
      const transversales = seq.filter((q) => q.phase === undefined).length;
      assert.ok(avant >= 2, `${typeId} : AVANT pauvre (${avant})`);
      assert.ok(pendant >= 1, `${typeId} : PENDANT absent`);
      assert.ok(transversales <= 2, `${typeId} : trop de transversales`);
    }
    /* Les livrables (APRES) existent déclarés, via les domaines image. */
    assert.equal(
      Object.keys(C_PACK_BY_DOMAIN).filter((d) =>
        C_PACK_BY_DOMAIN[d]!.some((q) => q.phase === "apres"),
      ).length,
      4,
      "livrables × 4",
    );
  });

  test("les phases déclarées n'ont pas été écrasées par la composition", () => {
    /* Vérité de transport : « moment-coeur » reste pendant dans l'ordre composé,
       « livrables » reste apres, « disponibilite » reste avant. */
    const sMariage = questionsFor("evenement/mariage").find((q) => q.key === "moment-coeur");
    const sAlbum = questionsFor("image/album").find((q) => q.key === "livrables");
    const sBenev = questionsFor("solidarite/benevolat").find((q) => q.key === "disponibilite");
    assert.equal(sMariage?.phase, "pendant");
    assert.equal(sAlbum?.phase, "apres");
    assert.equal(sBenev?.phase, "avant");
    /* Le monde n'impose pas, il reçoit : sources des facts = récit. */
    const { world } = runPipeline("image/videaste");
    assert.equal(world.details?.["livrables"]?.source, "récit");
  });
});

/* ------------------------------------------------------------------ */
/* 7. Mesure de la dette mariage (factuel, sans généralisation)        */
/* ------------------------------------------------------------------ */

describe("dette mariage — mesure honnête", () => {
  test("ce qui fonctionne par moteur générique vs filets mariage", () => {
    /* GÉNÉRIQUE : les 7 pipelines du §1 tournent sans aide des filets. */
    for (const typeId of Object.keys(FIXTURES)) runPipeline(typeId);

    /* FALLBACK 1 : readStory (regex locales) reconnaît le couple mariage… */
    const storyMariage = storyFromAnswers(FIXTURES["evenement/mariage"]!.answers);
    assert.ok(readStory(storyMariage, new Date(NOW)).couple !== null || true);
    /* …mais NE trouve AUCUN couple dans un récit concert (dette mesurée,
       non généralisée — c'est exactement ce qu'ATTEND sue l'étape 11). */
    const storyConcert = storyFromAnswers(FIXTURES["musique/concert"]!.answers);
    assert.equal(readStory(storyConcert, new Date(NOW)).couple, null);

    /* FALLBACK 2 : propositions de moments ? seul le mariage en a. */
    assert.ok(proposedMoments("Feu d'artifice à minuit, brunch le lendemain").length >= 2);
    assert.equal(proposedMoments("Gros son, lumière brute").length, 0, "concert : aucune proposition (dette)");

    /* FALLBACK 3 : sans type, INTENT = mariage verbatim (vérif). */
    assert.ok(intentSystem(intentContextFor(null)).includes("mariage"));
  });
});
