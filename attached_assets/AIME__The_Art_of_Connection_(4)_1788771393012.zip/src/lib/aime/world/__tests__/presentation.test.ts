/**
 * Présentation des faits métier (étape 12) — les details du monde deviennent
 * visibles à leur libellé humain, la synthèse de validation affiche les
 * réponses C, et les phases de registre restent ludisponibles telles quelles.
 * Aucune architecture nouvelle n'existe ici : uniquement la démonstration
 * duditage entre registre déclaratif et données produites.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { PROJECT_TYPES, projectTypeById } from "../blueprints";
import { journeySummary, mergeReading, projectFromJourney } from "../journey";
import { readingFromAnswers } from "../journey";
import { storyFromAnswers } from "../journey";
import { C_PACK_BY_DOMAIN, detailLabelFor, questionsFor } from "../questions";
import type { WorldProject } from "../types";

/** Pipeline pure, sans IA ni réseau : réponses → monde. */
function worldOf(typeId: string, answers: Record<string, string>): WorldProject {
  const a = { type: typeId, ...answers };
  const p = projectFromJourney(a, { now: Date.UTC(2027, 0, 10), force: true })!;
  assert.ok(p, typeId);
  return p;
}

/* ------------------------------------------------------------------ */
/* 1. Un detail déclaré est visible dans la synthèse                   */
/* ------------------------------------------------------------------ */

describe("journeySummary — les réponses C deviennent visibles", () => {
  const CASES: [string, Record<string, string>, string, string, string][] = [
    /* [typeId, réponses C, clé métier, libellé humain, valeur attendue] */
    ["evenement/mariage", { quand: "2027-08-14", ou: "Lille", qui: "120", budget: "25000", intention: "élégant", "moment-coeur": "la cérémonie" }, "moment_coeur", "Moment", "la cérémonie"],
    ["musique/concert", { quand: "2027-09-20", ou: "Lyon", qui: "800", budget: "15000", intention: "gros son", cadre: "au public, en billetterie" }, "cadre", "Cadre", "au public, en billetterie"],
    ["image/videaste", { quand: "2027-05-02", ou: "Paris", qui: "2", budget: "1800", intention: "ciné", occasion: "pour un projet professionnel", livrables: "Un film de 10 minutes, un teaser 60 s" }, "livrables", "Livrables", "Un film de 10 minutes, un teaser 60 s"],
    ["patrimoine/immo-vente", { quand: "2027-03-01", ou: "Nantes", qui: "3", budget: "450000", intention: "serein", "statut-dossier": "annoncée, visites en cours" }, "statut_dossier", "Avancement", "annoncée, visites en cours"],
    ["table/chef", { quand: "2027-06-12", ou: "Bordeaux", qui: "12", budget: "1500", intention: "gastronomique", service: "en prestation, chez le client ou sur un événement", regimes: "Une allergie aux fruits à coque" }, "regimes", "Régimes", "Une allergie aux fruits à coque"],
    ["lien/mentorat", { quand: "chaque semaine", "cadre-echanges": "en visioconférence", qui: "1", budget: "900", intention: "conseil RH", "cadre-relation": "des rencontres individuelles" }, "cadre_echanges", "Échanges", "en visioconférence"],
    ["solidarite/benevolat", { quand: "2027-04-01", ou: "Lille", qui: "30", disponibilite: "un jour par semaine", intention: "jeunes isolés", beneficiaires: "des personnes (isolement, accès, précarité…)" }, "disponibilite", "Temps", "un jour par semaine"],
  ];

  for (const [typeId, answers, detailKey, humanLabel, value] of CASES) {
    test(`${typeId} — « ${humanLabel}: ${value} » dans la synthèse`, () => {
      const world = worldOf(typeId, answers);
      assert.deepEqual(world.details?.[detailKey]?.value, value);

      const summary = journeySummary(world);
      const line = summary.find((l) => l.label === humanLabel);
      assert.ok(line, `ligne « ${humanLabel} » présente`);
      assert.equal(line.value, value);
      assert.equal(line.confidence, "confirme");

      /* Interdit : la clé technique ne doit jamais s'afficher. */
      for (const l of summary) {
        assert.ok(!l.label.startsWith("detail:"), l.label);
        assert.ok(!/^[a-z]+(_[a-z]+)+$/.test(l.label), `snake_case exposé : « ${l.label} »`);
      }
    });
  }
});

/* ------------------------------------------------------------------ */
/* 2 & 3. Absence et multiplicité                                       */
/* ------------------------------------------------------------------ */

describe("journeySummary — absence et multiplicité", () => {
  test("aucun detail ⇒ aucune ligne factice, synthèse classique inchangée", () => {
    const minimal = {
      quand: "2027-08-14",
      ou: "Lille",
      qui: "120",
      intention: "réunir nos familles",
    };
    const world = worldOf("evenement/mariage", minimal);
    assert.equal(world.details, undefined);
    const labels = journeySummary(world).map((l) => l.label);
    assert.deepEqual(labels, ["Quand", "Où", "Qui", "Ce qui existe", "Ce qui est souhaité"]);
  });

  test("plusieurs details ⇒ toutes les lignes, dans l'ordre de la séquence", () => {
    const world = worldOf("table/chef", {
      quand: "2027-06-12",
      ou: "Bordeaux",
      qui: "12",
      budget: "1500",
      intention: "gastronomique",
      service: "en prestation, chez le client ou sur un événement",
      regimes: "Une allergie aux fruits à coque, deux végétariens",
    });
    const summary = journeySummary(world);
    const detailLines = summary.filter((l) => ["Service", "Régimes"].includes(l.label));
    assert.equal(detailLines.length, 2);
    assert.ok(summary.indexOf(detailLines[0]!) < summary.indexOf(detailLines[1]!));
  });
});

/* ------------------------------------------------------------------ */
/* 4 & 6. Libellé humain et séparation de domaines                      */
/* ------------------------------------------------------------------ */

describe("detailLabelFor — libellé humain, scopé par domaine quand utile", () => {
  test("libellés exacts des clés métier", () => {
    assert.equal(detailLabelFor("livrables", "image/videaste"), "Livrables");
    assert.equal(detailLabelFor("livrables", "image/album"), "Contenu");
    assert.equal(detailLabelFor("statut_dossier", "patrimoine/immo-vente"), "Avancement");
    assert.equal(detailLabelFor("cadre_echanges", "lien/mentorat"), "Échanges");
    assert.equal(detailLabelFor("disponibilite", "solidarite/benevolat"), "Temps");
  });

  test("même clé, libellé différent par domaine : le plus spécialisé gagne", () => {
    /* Les deux se lisent « humainement », mais l'album le spécifie. */
    assert.notEqual(
      detailLabelFor("livrables", "image/album"),
      detailLabelFor("livrables", "image/photographe"),
    );
    /* Sans typeId : le parcours déterministe A→B→C reste cohérent. */
    assert.equal(detailLabelFor("livrables"), "Livrables");
  });

  test("humanisation de dernier recours, jamais snake_case exposé", () => {
    assert.equal(detailLabelFor("cle_etrangere_inconnue"), "Cle etrangere inconnue");
    assert.equal(detailLabelFor("budget"), "Budget");
  });
});

/* ------------------------------------------------------------------ */
/* 5. Priorité utilisateur > IA sur les details                         */
/* ------------------------------------------------------------------ */

describe("mergeReading — priorité utilisateur sur l'IA pour les details", () => {
  test("l'IA ne remplace jamais une réponse posée ; elle complète l'absence", () => {
    /* L'IA propose l'autre valeur. */
    const mergedUser = mergeReading(
      readingFromAnswers(
        {
          type: "image/videaste",
          livrables: "Réponse utilisateur",
        },
        new Date(0),
      ),
      { details: { livrables: "Valeur lue par l'IA", occasion: "pour un mariage" } },
    );
    assert.equal(mergedUser.details?.["livrables"], "Réponse utilisateur");
    assert.equal(mergedUser.details?.["occasion"], "pour un mariage", "ajout IA conservé");

    const world = worldOf("image/videaste", {
      quand: "2027-05-02",
      ou: "Paris",
      qui: "2",
      budget: "1800",
      intention: "ciné",
      occasion: "pour un projet professionnel",
      livrables: "Réponse utilisateur",
    });
    const line = journeySummary(world).find((l) => l.label === "Livrables");
    assert.equal(line?.value, "Réponse utilisateur");
  });
});

/* ------------------------------------------------------------------ */
/* 7-8. Conservation snapshot + invariant 73                            */
/* ------------------------------------------------------------------ */

describe("sérialisation — details conservées dans le snapshot JSON", () => {
  for (const [typeId, expectedKey] of [
    ["image/videaste", "livrables"],
    ["solidarite/benevolat", "disponibilite"],
  ] as const) {
    test(`${typeId} : details intacts après JSON.stringify`, () => {
      const world = worldOf(typeId, {
        quand: "2027-04-01",
        ou: "Lille",
        qui: "30",
        budget: "900",
        intention: "beau projet",
        ...(typeId === "image/videaste"
          ? { occasion: "pour un projet professionnel", livrables: "correct" }
          : { disponibilite: "temps dispo", beneficiaires: "un quartier ou un territoire" }),
      });
      const round = JSON.parse(JSON.stringify(world));
      assert.deepEqual(round.details, world.details);
      assert.ok(round.details?.[expectedKey]);
    });
  }
});

describe("invariant 73 — la présentation est sûre pour tous les types", () => {
  test("journeySummary ne casse jamais ; aucun label technique exposé", () => {
    for (const t of PROJECT_TYPES) {
      const world = worldOf(t.id, {
        quand: "2027-08-14",
        ou: "Paris",
        qui: "20",
        budget: "2000",
        intention: "beau projet",
      });
      assert.ok(world.details === undefined || typeof world.details === "object", t.id);
      const summary = journeySummary(world);
      for (const l of summary) {
        assert.ok(!l.label.startsWith("detail:"), `${t.id} : clé exposée`);
        assert.ok(!/^[a-z-]+(_[a-z]+)+$/.test(l.label), `${t.id} : snake_case exposé`);
      }
    }
  });

  test("les phases du registre restent déclarées après composition (a venir du moteur)", () => {
    let avecPhase = 0;
    let total = 0;
    for (const t of PROJECT_TYPES) {
      for (const q of questionsFor(t.id)) {
        if (q.level !== "C") continue;
        total++;
        if (q.phase) avecPhase++;
      }
    }
    /* Les transversales (« cadre-echanges » ×3) restent volontairement
       sans phase : la différence est exactement 3. */
    assert.equal(total - avecPhase, 3, "transversales assumées");
    for (const pack of Object.values(C_PACK_BY_DOMAIN)) {
      for (const q of pack) {
        assert.ok(q.phase === undefined || ["avant", "pendant", "apres"].includes(q.phase));
      }
    }
    /* Point de branchement du futur moteur documenté (pas de temporal.ts
       à l'étape 12) : deriveTimeline(project).metadata / q.phase. */
  });
});
