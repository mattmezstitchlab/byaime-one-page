/**
 * Ouverture des réponses (Vague 3, étape 4) : registre de clés ouvert,
 * récit piloté par `questionsFor`, transport fidèle des informations que
 * le système ne connaissait pas auparavant.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { projectFromJourney, storyFromAnswers } from "../journey";
import { readStory } from "../parseStory";
import * as questionsModule from "../questions";

const NOW = new Date(2026, 8, 6, 12, 0, 0).getTime();

/* ------------------------------------------------------------------ */
/* Mariage : parité d'information avec le comportement précédent       */
/* ------------------------------------------------------------------ */

describe("parité mariage", () => {
  /* Le récit que produisait le parcours avant la Vague 3. */
  const ANCIEN_RECIT =
    "C'est un projet de type Mariage. " +
    "Le mariage est prévu le 14 août 2027. " +
    "Cela se passera à Lille. " +
    "Nous serons 120 invités. " +
    "Notre budget est d'environ 25000 €.";

  const answers = {
    type: "evenement/mariage",
    quand: "2027-08-14",
    ou: "Lille",
    qui: "120",
    budget: "25000",
  };

  test("toutes les informations de l'ancien récit survivent au nouveau", () => {
    const nouveau = storyFromAnswers(answers);
    const avant = readStory(ANCIEN_RECIT, new Date(NOW));
    const apres = readStory(nouveau, new Date(NOW));
    /* Informations identiques : jour et nombre de personnes. */
    assert.equal(apres.day, avant.day);
    assert.equal(apres.guests, avant.guests);
    /* La lecture regex de la ville est strictement à parité : le quirk «\b
       devant à » (documenté dans safety.test) la laisse à null dans les deux
       récits — et la ville atteint le monde via la réponse brute « ou »
       (readingFromAnswers), exactement comme avant. Le test monde ci-dessous
       le prouve (city.value === « Lille »). */
    assert.equal(avant.city, null);
    assert.equal(apres.city, null);
    /* Le budget reste présent dans le récit pour AIME INTENT. */
    assert.ok(nouveau.includes("Le budget est d'environ 25000 €."), nouveau);
    assert.ok(nouveau.startsWith("C'est un projet de type Mariage."), nouveau);
  });

  test("le monde généré garde kind, faits et moteur identiques", () => {
    const p = projectFromJourney(answers, { now: NOW });
    assert.ok(p);
    assert.equal(p.kind, "mariage");
    assert.equal(p.id, "mariage");
    assert.equal(p.pivot.value, new Date(2027, 7, 14).getTime());
    assert.equal(p.city.value, "Lille");
    assert.equal(p.guests.value, 120);
    assert.equal(p.providers.length, 12);
    assert.equal(p.moments.length, 15);
    assert.equal(p.tasks.length, 15);
  });
});

/* ------------------------------------------------------------------ */
/* Le récit n'est plus implicitement mariage/événement                 */
/* ------------------------------------------------------------------ */

describe("récit sans vocabulaire de famille imposée", () => {
  const BANNED = [/mari/i, /cérémonie/i, /invité/i, /jour j/i, /cela se passera/i, /fête/i];

  test("concert : rien de nuptial ni d'événementiel imposé", () => {
    const story = storyFromAnswers({
      type: "musique/concert",
      quand: "2027-06-03",
      ou: "Roubaix",
      qui: "300",
    });
    for (const re of BANNED) assert.ok(!re.test(story), `${re} dans « ${story} »`);
    assert.ok(story.includes("C'est un projet de type Concert."));
  });

  test("un type non événementiel produit un récit exploitable", () => {
    const story = storyFromAnswers({
      type: "patrimoine/immo-vente",
      quand: "2027-01-15",
      ou: "Lille",
      budget: "430000",
    });
    assert.equal(
      story,
      "C'est un projet de type Immobilier vente. " +
        "La date visée est le 15 janvier 2027. " +
        "Le projet se situe à Lille. " +
        "Le budget est d'environ 430000 €.",
    );
    for (const re of BANNED) assert.ok(!re.test(story), `${re} dans « ${story} »`);
  });
});

/* ------------------------------------------------------------------ */
/* Réponses partielles                                                 */
/* ------------------------------------------------------------------ */

describe("réponses partielles", () => {
  test("type + date seuls : deux phrases, rien d'inventé", () => {
    assert.equal(
      storyFromAnswers({ type: "musique/concert", quand: "2027-06-03" }),
      "C'est un projet de type Concert. La date visée est le 3 juin 2027.",
    );
  });

  test("absence de date : aucune phrase de date", () => {
    const story = storyFromAnswers({ type: "musique/concert", ou: "Roubaix" });
    assert.equal(story, "C'est un projet de type Concert. Le projet se situe à Roubaix.");
    const p = projectFromJourney(
      { type: "musique/concert", ou: "Roubaix" },
      { now: NOW, force: true },
    );
    assert.ok(p);
    assert.equal(p.pivot.confidence, "a_confirmer");
    assert.ok(p.missing.some((m) => m.startsWith("La date n'est pas encore fixée")));
  });

  test("absence de lieu : aucune phrase de lieu, ville inconnue", () => {
    const story = storyFromAnswers({ type: "musique/concert", qui: "300" });
    assert.ok(!story.includes("se situe"));
    const p = projectFromJourney({ type: "musique/concert", qui: "300" }, { now: NOW, force: true });
    assert.ok(p);
    assert.equal(p.city.value, null);
    assert.ok(p.missing.includes("La ville n'est pas encore connue."));
  });

  test("valeurs vides ou blanches ignorées", () => {
    assert.equal(
      storyFromAnswers({
        type: "musique/dj",
        quand: "   ",
        ou: "",
        budget: "  \t ",
        qui: "120",
      }),
      "C'est un projet de type DJ. Ce projet réunit environ 120 personnes.",
    );
  });
});

/* ------------------------------------------------------------------ */
/* Transport fidèle de l'inconnu (validation-clé de l'étape)           */
/* ------------------------------------------------------------------ */

describe("une information non modélisée traverse sans être écrasée", () => {
  test("une clé detail:* future est conservée telle quelle dans le récit", () => {
    const story = storyFromAnswers({
      type: "lien/mentorat",
      ou: "Lille",
      "detail:rythme_mentorat": "Mensuel, un jeudi sur deux",
    });
    assert.ok(
      story.endsWith("Mensuel, un jeudi sur deux"),
      `la valeur doit finir le récit, verbatim : « ${story} »`,
    );
    /* Aucune transformation : ni casse, ni ponctuation, ni traduction. */
    assert.ok(story.includes("Mensuel, un jeudi sur deux"));
  });

  test("une clé totalement inconnue du registre est conservée verbatim", () => {
    const story = storyFromAnswers({
      type: "musique/dj",
      "cle-future-x": "Valeur libre — 42 Ω & détails",
    });
    assert.ok(story.includes("Valeur libre — 42 Ω & détails"), story);
  });

  test("les clés inconnues blanches n'encombrent pas le récit", () => {
    assert.equal(
      storyFromAnswers({ type: "musique/dj", "cle-future-x": "   " }),
      "C'est un projet de type DJ.",
    );
  });
});

/* ------------------------------------------------------------------ */
/* Ordre des phrases = ordre du registre                               */
/* ------------------------------------------------------------------ */

describe("ordre des phrases conforme à l'ordre des QuestionSpec", () => {
  test("l'ordre de saisie n'influence pas l'ordre du récit", () => {
    /* Insertion volontairement inversée. */
    const a: Record<string, string> = {};
    a["budget"] = "8000";
    a["qui"] = "300";
    a["ou"] = "Roubaix";
    a["quand"] = "2027-06-03";
    a["type"] = "musique/concert";
    const story = storyFromAnswers(a);
    const ordre = ["type Concert", "date visée", "se situe", "réunit", "budget"];
    const positions = ordre.map((m) => story.indexOf(m));
    assert.ok(positions.every((p) => p >= 0), story);
    assert.deepEqual([...positions].sort((x, y) => x - y), positions, story);
  });
});

/* ------------------------------------------------------------------ */
/* answerKeyFor n'est plus nécessaire                                  */
/* ------------------------------------------------------------------ */

describe("plus aucun pont vers les clés héritées", () => {
  test("answerKeyFor et LEGACY_ANSWER_KEY n'existent plus dans le module", () => {
    assert.ok(!("answerKeyFor" in questionsModule));
    assert.ok(!("LEGACY_ANSWER_KEY" in questionsModule));
  });

  test("la clé « budget » atteint le récit en direct, sans repli sur « existant »", () => {
    const story = storyFromAnswers({ type: "musique/dj", budget: "900" });
    assert.ok(story.includes("Le budget est d'environ 900 €."), story);
    /* Et une ancienne clé « existant » serait traitée comme inconnue : brute. */
    const legacy = storyFromAnswers({ type: "musique/dj", existant: "900" });
    assert.ok(legacy.endsWith("900"), legacy);
  });
});
