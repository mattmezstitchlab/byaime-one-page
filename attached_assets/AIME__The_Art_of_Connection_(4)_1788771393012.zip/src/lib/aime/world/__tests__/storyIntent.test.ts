/**
 * AIME INTENT dynamique (Vague 3, étape 6) : le type choisi spécialise la
 * lecture ; sans type, le comportement historique est verbatim ; les
 * `details` retournés par le modèle sont strictement bornés.
 *
 * Le module testé est pur : l'appel réseau (passerelle IA) reste vérifié
 * manuellement (étape 11, clé LOVABLE_API_KEY absente du sandbox).
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import {
  aiDetailsToRecord,
  intentContextFor,
  intentSchema,
  intentSystem,
} from "../storyIntent";
import { WEDDING_ROLES } from "../wedding";
import { blueprintFor } from "../blueprints";

/* ------------------------------------------------------------------ */
/* Filet historique : sans type, tout est verbatim                     */
/* ------------------------------------------------------------------ */

describe("filet historique (type absent ou inconnu)", () => {
  const ctx = intentContextFor(null);

  test("rôles mariage historiques, clé detail budget seule", () => {
    assert.equal(ctx.typeLabel, null);
    assert.deepEqual([...ctx.roles], [...WEDDING_ROLES]);
    assert.deepEqual([...ctx.detailKeys], ["budget"]);
  });

  test("le prompt historique est conservé mot pour mot", () => {
    const s = intentSystem(ctx);
    assert.ok(s.startsWith("Tu es AIME. Tu lis le récit d'un mariage"));
    assert.ok(s.includes('"heure" : heure de cérémonie'));
    assert.equal(intentSystem(intentContextFor("inconnu/slug")), s);
  });

  test("le schéma du filet borne les rôles au mariage historique", () => {
    const schema = intentSchema(ctx);
    assert.deepEqual(
      schema.properties.prestatairesTrouves.items.enum,
      [...WEDDING_ROLES],
    );
  });
});

/* ------------------------------------------------------------------ */
/* Spécialisation par type                                             */
/* ------------------------------------------------------------------ */

describe("le type choisi spécialise la lecture", () => {
  test("concert : rôles du blueprint, prompt sans vocabulaire mariage", () => {
    const ctx = intentContextFor("musique/concert");
    assert.equal(ctx.typeLabel, "Concert");
    assert.deepEqual([...ctx.roles], [...blueprintFor("musique/concert").roles]);
    const s = intentSystem(ctx);
    assert.ok(s.includes('projet de type « Concert »'));
    assert.ok(!/mari|cérémonie|invité|jour j/i.test(s));
    const schema = intentSchema(ctx);
    assert.deepEqual(schema.properties.prestatairesTrouves.items.enum, [
      "Salle / lieu",
      "Plateau artistique",
      "Sonorisation",
      "Lumière",
      "Régie technique",
      "Billetterie",
      "Communication",
      "Sécurité",
      "Catering",
    ]);
  });

  test("mariage : rôles issus du blueprint (pas d'une liste codée en dur)", () => {
    const ctx = intentContextFor("evenement/mariage");
    assert.equal(ctx.typeLabel, "Mariage");
    assert.deepEqual([...ctx.roles], [...blueprintFor("evenement/mariage").roles]);
  });

  test("les 6 Domaines obligatoires reçoivent une lecture sans mariage", () => {
    for (const typeId of [
      "image/videaste",
      "patrimoine/immo-vente",
      "table/chef",
      "lien/mentorat",
      "solidarite/benevolat",
      "musique/concert",
    ]) {
      const ctx = intentContextFor(typeId);
      assert.ok(ctx.typeLabel, typeId);
      const s = intentSystem(ctx);
      assert.ok(s.includes(`« ${ctx.typeLabel} »`), typeId);
      assert.ok(!/mari|cérémonie/i.test(s), typeId);
      assert.deepEqual([...ctx.roles], [...blueprintFor(typeId).roles], typeId);
    }
  });

  test("les clés details viennent du registre (budget au minimum)", () => {
    for (const typeId of ["evenement/mariage", "musique/concert", "lien/mentorat"]) {
      const ctx = intentContextFor(typeId);
      assert.ok(ctx.detailKeys.includes("budget"), typeId);
    }
  });
});

/* ------------------------------------------------------------------ */
/* Schéma de sortie                                                    */
/* ------------------------------------------------------------------ */

describe("schéma étendu avec details", () => {
  const schema = intentSchema(intentContextFor("musique/concert"));

  test("shape stricte, details requis, clés bornées à l'enum", () => {
    assert.equal(schema.additionalProperties, false);
    assert.ok(schema.required.includes("details"));
    assert.ok(schema.required.includes("resume"));
    const item = schema.properties.details.items;
    assert.equal(item.additionalProperties, false);
    assert.deepEqual(item.required, ["key", "value"]);
    /* Les clés autorisées sont celles du registre — étape 6 : [\"budget\"]
       seul ; étape 8 : le registre s'est allongé (« cadre », pack musique),
       le schéma suit sans retouche de storyIntent.ts. */
    assert.deepEqual(item.properties.key.enum, [
      ...intentContextFor("musique/concert").detailKeys,
    ]);
    assert.deepEqual(item.properties.value.type, ["string", "number", "boolean"]);
  });
});

/* ------------------------------------------------------------------ */
/* Normalisation des details du modèle                                 */
/* ------------------------------------------------------------------ */

describe("aiDetailsToRecord — les faits sont bornés et verbatim", () => {
  const ctx = intentContextFor("musique/dj");

  test("valeurs conservées telles quelles, modèle ou texte", () => {
    assert.deepEqual(
      aiDetailsToRecord([{ key: "budget", value: 25000 }], ctx),
      { budget: 25000 },
    );
    assert.deepEqual(aiDetailsToRecord([{ key: "budget", value: "25 000 €" }], ctx), {
      budget: "25 000 €",
    });
    assert.deepEqual(aiDetailsToRecord([{ key: "budget", value: true }], ctx), { budget: true });
  });

  test("clés hors champ rejetées, valeurs non primitives rejetées", () => {
    assert.equal(
      aiDetailsToRecord(
        [
          { key: "couple", value: "X" } /* jamais un slot canonique */,
          { key: "cle_etrangere", value: "Y" },
          { key: "budget", value: { montant: 5 } },
          { key: "budget", value: [1] },
          { key: "budget", value: null },
        ],
        ctx,
      ),
      undefined,
    );
  });

  test("première occurrence gagnante, plafond de 12 faits, tableau court-circuité à 24", () => {
    const many = Array.from({ length: 30 }, (_, i) => ({ key: "budget", value: i }));
    assert.deepEqual(aiDetailsToRecord(many, ctx), { budget: 0 });
    const dozen = Array.from({ length: 15 }, (_, i) =>
      i === 0 ? { key: "budget", value: 1 } : { key: `budget`, value: i },
    );
    assert.deepEqual(aiDetailsToRecord(dozen, ctx), { budget: 1 });
  });

  test("entrée non tableau ou vide → undefined", () => {
    assert.equal(aiDetailsToRecord(null, ctx), undefined);
    assert.equal(aiDetailsToRecord({}, ctx), undefined);
    assert.equal(aiDetailsToRecord([], ctx), undefined);
  });

  test("les clés autorisées suivent le contexte", () => {
    const autre = { typeLabel: "DJ", roles: ["Sono"], detailKeys: ["budget", "duree_set"] } as const;
    assert.deepEqual(
      aiDetailsToRecord(
        [
          { key: "duree_set", value: 4 },
          { key: "budget", value: 800 },
        ],
        autre,
      ),
      { duree_set: 4, budget: 800 },
    );
  });
});
