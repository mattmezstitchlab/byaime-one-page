/**
 * Packs C des 73 Domaines (Vague 3, étape 9) : composition A + B + C,
 * substitution d'abord, liste blanche des dépassements, phases temporelles
 * réfléchies (AVANT / PENDANT / APRÈS ; transversales documentées sans
 * phase) — prérequis du futur moteur temporel universel, qui n'est pas
 * construit ici.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { UNIVERSE_TREE } from "@/lib/aime/universeTree";
import { PROJECT_TYPES } from "../blueprints";
import {
  A_PACK,
  B_PACK_BY_UNIVERSE,
  C_LONG_JOURNEY_DOMAINS,
  C_PACK_BY_DOMAIN,
  composeQuestions,
  questionsFor,
  validateQuestionSpec,
  type QuestionSpec,
} from "../questions";
import { readingFromAnswers } from "../journey";
import { storyFromAnswers } from "../journey";
import { intentContextFor } from "../storyIntent";

const keys = (seq: readonly QuestionSpec[]) => seq.map((q) => q.key);
const uniq = <T,>(xs: readonly T[]) => new Set(xs).size === xs.length;
const universeOf = (typeId: string) =>
  UNIVERSE_TREE.find((u) => typeId === u.slug || typeId.startsWith(`${u.slug}/`))?.slug ?? "";

/* ------------------------------------------------------------------ */
/* Registre                                                            */
/* ------------------------------------------------------------------ */

describe("C_PACK_BY_DOMAIN — registre des 73 Domaines", () => {
  test("une entrée par Domaine, exactement", () => {
    assert.deepEqual(
      Object.keys(C_PACK_BY_DOMAIN).sort(),
      PROJECT_TYPES.map((t) => t.id).sort(),
    );
  });

  test("chaque spéc est valide, niveau C, sans doublon intra-pack", () => {
    for (const [domain, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      assert.ok(pack.length >= 1, `${domain} : pack non vide`);
      for (const q of pack) {
        assert.deepEqual(validateQuestionSpec(q), [], `${domain}.${q.key}`);
        assert.equal(q.level, "C", `${domain}.${q.key} : niveau C`);
      }
      assert.ok(uniq(keys(pack)), `${domain} : clés doubles`);
    }
  });

  test("chaque replaces cible une question du socle ou de l'univers", () => {
    /* La cible doit exister : soit encore posée par A+B, soit héritée d'une
       clé lui ayant déjà cédé la place (ex. « destination » hérite de
       « ou » qu'elle a elle-même remplacée au niveau B). */
    for (const [domain, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      const universe = universeOf(domain);
      const legacy = new Set([
        ...keys(composeQuestions(A_PACK, B_PACK_BY_UNIVERSE[universe] ?? [])),
        ...A_PACK.map((q) => q.key),
        ...(B_PACK_BY_UNIVERSE[universe] ?? []).map((q) => q.key),
      ]);
      for (const q of pack) {
        if (!q.replaces) continue;
        assert.ok(legacy.has(q.replaces), `${domain}.${q.key} : replaces « ${q.replaces} » inconnu`);
      }
    }
  });
});

/* ------------------------------------------------------------------ */
/* Plafond 6 : liste blanche des dépassements                          */
/* ------------------------------------------------------------------ */

describe("plafond UX — substitution d'abord, dépassements en liste blanche", () => {
  test("73 Domaines : 65 à 6 questions, 8 à 7 (la liste blanche, à la clé près)", () => {
    const over = PROJECT_TYPES.filter((t) => questionsFor(t.id).length > 6).map((t) => t.id).sort();
    assert.deepEqual(over, [...C_LONG_JOURNEY_DOMAINS].sort());
    assert.equal(OVER_actualCount(), 8);
    function OVER_actualCount() {
      return over.length;
    }
    for (const t of PROJECT_TYPES) {
      if (!over.includes(t.id)) assert.equal(questionsFor(t.id).length, 6, `${t.id} visait 6`);
    }
  });

  test("question « ajoutée » (ni relibelle ni replaces) ⇔ liste blanche", () => {
    /* Tout ajout pur (clé nouvelle sans replaces) doit être l'une des
       SEULES justifications de dépassement : régimes/livrables/durée. */
    const added = new Map<string, string>();
    for (const [domain, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      const universe = universeOf(domain);
      const posed = keys(composeQuestions(A_PACK, B_PACK_BY_UNIVERSE[universe] ?? []));
      for (const q of pack) {
        if (!posed.includes(q.key) && !q.replaces) added.set(domain, q.key);
      }
    }
    const expect = new Map<string, string>([
      ["table/traiteur", "regimes"],
      ["table/chef", "regimes"],
      ["table/food-truck", "regimes"],
      ["table/patisserie", "regimes"],
      ["image/photographe", "livrables"],
      ["image/videaste", "livrables"],
      ["voyage/hebergement", "duree"],
      ["voyage/sejour-groupe", "duree"],
    ]);
    assert.deepEqual(new Map([...added].sort()), new Map([...expect].sort()));
  });
});

/* ------------------------------------------------------------------ */
/* Composition : les 7 Domaines de référence, en réel                  */
/* ------------------------------------------------------------------ */

const SNAPSHOTS: Record<string, string[]> = {
  "evenement/mariage": ["quand", "ou", "qui", "budget", "intention", "moment-coeur"],
  "musique/concert": ["quand", "ou", "qui", "budget", "intention", "cadre"],
  "image/videaste": ["quand", "ou", "qui", "budget", "intention", "occasion", "livrables"],
  "patrimoine/immo-vente": ["quand", "ou", "qui", "budget", "intention", "statut-dossier"],
  "table/chef": ["quand", "ou", "qui", "budget", "intention", "service", "regimes"],
  "lien/mentorat": ["quand", "cadre-echanges", "qui", "budget", "intention", "cadre-relation"],
  "solidarite/benevolat": ["quand", "ou", "qui", "disponibilite", "intention", "beneficiaires"],
};

describe("questionsFor — composition A + B + C sur les 7 Domaines de référence", () => {
  for (const [typeId, expected] of Object.entries(SNAPSHOTS)) {
    test(`${typeId} : séquence exacte`, () => {
      const seq = questionsFor(typeId);
      assert.deepEqual(keys(seq), expected);
      for (const q of seq) {
        assert.deepEqual(validateQuestionSpec(q), [], `${typeId}.${q.key}`);
        assert.equal(typeof q.sentence("exemple"), "string");
      }
      assert.ok(seq.some((q) => q.level === "C"), "au moins une spéc Domaine");
    });
  }

  test("les remplacées ont bien disparu (jamais additionnées)", () => {
    assert.ok(!keys(questionsFor("evenement/mariage")).includes("moment-journee"));
    assert.ok(!keys(questionsFor("patrimoine/immo-vente")).includes("operation"));
    assert.ok(!keys(questionsFor("solidarite/benevolat")).includes("budget"));
    assert.ok(!keys(questionsFor("lien/mentorat")).includes("ou"));
    assert.ok(!keys(questionsFor("image/album")).includes("occasion"));
  });

  test("« statut-dossier » conserve la position de « operation » (fin)", () => {
    assert.equal(keys(questionsFor("patrimoine/immo-vente")).at(-1), "statut-dossier");
    /* Bénévolat : « disponibilite » occupe la position de « budget » (index 3). */
    assert.equal(keys(questionsFor("solidarite/benevolat")).indexOf("disponibilite"), 3);
  });
});

/* ------------------------------------------------------------------ */
/* Temporalité : phases réfléchies                                     */
/* ------------------------------------------------------------------ */

describe("phases — données prêtes pour AVANT / PENDANT / APRÈS", () => {
  test("toute spéc C porte une phase valide, sauf les transversales documentées", () => {
    const TRANSVERSAL = new Set(["cadre-echanges"]);
    for (const [domain, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      for (const q of pack) {
        if (TRANSVERSAL.has(q.key)) {
          assert.equal(q.phase, undefined, `${domain}.${q.key} : transversale assumée`);
          continue;
        }
        assert.ok(q.phase, `${domain}.${q.key} : phase manquante`);
        assert.ok(["avant", "pendant", "apres"].includes(q.phase!), `${domain}.${q.key}`);
      }
    }
  });

  test("les rôles temporels sont honnêtes et cohérents", () => {
    const phasesOf = (key: string) =>
      Object.entries(C_PACK_BY_DOMAIN)
        .flatMap(([d, pack]) => pack.filter((q) => q.key === key).map(() => d));

    /* APRÈS : uniquement les livrables des 4 domaines Image. */
    assert.deepEqual(
      phasesOf("livrables").sort(),
      ["image/album", "image/photographe", "image/retouche", "image/videaste"],
    );
    for (const pack of Object.values(C_PACK_BY_DOMAIN)) {
      for (const q of pack) {
        if (q.phase === "apres") assert.equal(q.key, "livrables", "seul livrables concerne l'après");
      }
    }
    /* PENDANT porté par le moment-cœur des 7 domaines Événement :
       explicitement `pendant`, et présent sur les 7. */
    assert.deepEqual(
      phasesOf("moment-coeur").sort(),
      PROJECT_TYPES.filter((t) => t.id.startsWith("evenement/")).map((t) => t.id).sort(),
    );
    for (const [d, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      for (const q of pack) {
        if (q.key === "moment-coeur") assert.equal(q.phase, "pendant", d);
      }
    }
    /* Relibellages : la phase hérite de la question spécialisée. */
    for (const [domain, pack] of Object.entries(C_PACK_BY_DOMAIN)) {
      const universe = universeOf(domain);
      const posedAB = composeQuestions(A_PACK, B_PACK_BY_UNIVERSE[universe] ?? []);
      for (const q of pack) {
        if (q.key === "cadre-echanges") continue; /* transversale, testée ailleurs */
        const base = posedAB.find((x) => x.key === q.key);
        if (!base) continue; /* nouvelle clé : phase explicite vérifiée ci-dessus */
        if (!q.replaces) assert.equal(q.phase, base.phase, `${domain}.${q.key}`);
      }
    }
  });
});

/* ------------------------------------------------------------------ */
/* Invariants sur les 73 Domaines                                      */
/* ------------------------------------------------------------------ */

describe("invariants sur les 73 Domaines (A + B + C)", () => {
  test("clés uniques, 6 ou 7, compteur dérivé, déterminisme", () => {
    for (const t of PROJECT_TYPES) {
      const seq = questionsFor(t.id);
      assert.ok(uniq(keys(seq)), t.id);
      assert.ok(seq.length >= 6 && seq.length <= 7, t.id);
      assert.equal(questionsFor(t.id).length, seq.length);
      assert.deepEqual(keys(questionsFor(t.id)), keys(seq), t.id);
    }
  });

  test("chaque Domaine garde l'identité de SON univers (références B)", () => {
    for (const t of PROJECT_TYPES) {
      const universe = universeOf(t.id);
      for (const q of questionsFor(t.id).filter((x) => x.level === "B")) {
        assert.ok(B_PACK_BY_UNIVERSE[universe]!.some((b) => b === q), `${t.id}.${q.key}`);
      }
    }
  });
});

/* ------------------------------------------------------------------ */
/* Propagation jusque dans le monde (compatibilité §7)                 */
/* ------------------------------------------------------------------ */

describe("les nouveaux facts restent plombés jusqu'au monde", () => {
  test("bénévolat : disponibilité remplace budget — récit, details, monde", () => {
    const answers = {
      type: "solidarite/benevolat",
      quand: "2027-04-01",
      ou: "Lyon",
      qui: "30",
      disponibilite: "un jour par semaine",
      intention: "Avec des jeunes isolés",
      beneficiaires: "des personnes (isolement, accès, précarité…)",
    } as const;
    const story = storyFromAnswers(answers);
    assert.ok(story.includes("Le temps disponible : un jour par semaine."));
    assert.ok(story.includes("Le budget") === false, "budget substitué : absent du récit");
    const reading = readingFromAnswers(answers);
    assert.equal(reading.details?.["disponibilite"], "un jour par semaine");
    assert.equal(reading.details?.["beneficiaires"], "des personnes (isolement, accès, précarité…)");
  });

  test("AIME INTENT : les clés details d'un Domaine suivent son pack C", () => {
    assert.ok(intentContextFor("lien/mentorat").detailKeys.includes("cadre_echanges"));
    assert.ok(intentContextFor("image/videaste").detailKeys.includes("livrables"));
    assert.ok(intentContextFor("table/traiteur").detailKeys.includes("regimes"));
    /* …et rien d'étranger : pas de moment_coeur hors événements. */
    assert.ok(!intentContextFor("image/videaste").detailKeys.includes("moment_coeur"));
    assert.ok(!intentContextFor("solidarite/collecte").detailKeys.includes("statut_dossier"));
  });
});
