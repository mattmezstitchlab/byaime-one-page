/**
 * Tests de la brique questions (Vague 3, étape 2) : le socle universel A
 * et `questionsFor`, avant tout câblage dans HeroBar, le récit ou AIME.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import {
  A_PACK,
  A_PACK_BY_KEY,
  blueprintQuestionsAsSpecs,
  chipText,
  questionsFor,
  validateQuestionSpec,
  type QuestionSpec,
} from "../questions";
import { blueprintFor } from "../blueprints";

/* ------------------------------------------------------------------ */
/* Structure                                                           */
/* ------------------------------------------------------------------ */

describe("A_PACK — structure de chaque QuestionSpec", () => {
  for (const q of A_PACK) {
    test(`« ${q.key} » est une question valide et complète`, () => {
      assert.deepEqual(validateQuestionSpec(q), []);
      assert.equal(q.level, "A");
      assert.ok(q.label.trim().length > 0);
      assert.ok(q.question.trim().length > 0);
      assert.ok(q.placeholder.trim().length > 0);
      assert.ok(["date", "text", "number", "choice"].includes(q.type));
      assert.equal(typeof q.sentence, "function");
    });
  }

  test("le validateur rejette une spec défectueuse", () => {
    const broken: QuestionSpec = {
      key: "Mauvaise Clé!",
      level: "A",
      label: " ",
      question: "",
      placeholder: "",
      type: "choice",
      mapsTo: "fourre-tout" as QuestionSpec["mapsTo"],
      sentence: () => "ok",
    };
    const problems = validateQuestionSpec(broken);
    assert.ok(problems.length >= 4, JSON.stringify(problems));
    assert.ok(problems.some((p) => p.includes("key invalide")));
    assert.ok(problems.some((p) => p.includes("mapsTo invalide")));
    assert.ok(problems.some((p) => p.includes("« choice »")));
  });
});

/* ------------------------------------------------------------------ */
/* Clés                                                                */
/* ------------------------------------------------------------------ */

describe("A_PACK — clés stables et uniques", () => {
  test("l'ordre et l'identité des clés sont figés", () => {
    assert.deepEqual(
      A_PACK.map((q) => q.key),
      ["quand", "ou", "qui", "budget", "intention"],
    );
  });

  test("aucune clé en double, index cohérent", () => {
    const keys = A_PACK.map((q) => q.key);
    assert.equal(new Set(keys).size, keys.length);
    for (const [key, spec] of Object.entries(A_PACK_BY_KEY)) {
      assert.equal(spec.key, key);
    }
  });
});

/* ------------------------------------------------------------------ */
/* questionsFor                                                        */
/* ------------------------------------------------------------------ */

describe("questionsFor — composition A + B (étape 8) + C (étape 9)", () => {
  const safetyKeys = ["quand", "ou", "qui", "budget", "intention"];

  test("mariage : socle relibellé « Événement » + « moment-cœur » du pack C", () => {
    const seq = questionsFor("evenement/mariage");
    assert.deepEqual(
      seq.map((q) => q.key),
      ["quand", "ou", "qui", "budget", "intention", "moment-coeur"],
    );
    /* moment-journee (B) est remplacé par moment-coeur (C), non additionné. */
    assert.ok(!seq.some((q) => q.key === "moment-journee"));
    assert.ok(seq.some((q) => q.level === "C"));
  });

  test("concert : pack « musique », pas de retombe sur l'événement", () => {
    assert.deepEqual(
      questionsFor("musique/concert").map((q) => q.key),
      ["quand", "ou", "qui", "budget", "intention", "cadre"],
    );
  });

  test("sans type, le socle A reste le filet de sécurité, inchangé", () => {
    assert.deepEqual(
      questionsFor(null).map((q) => q.key),
      safetyKeys,
    );
    assert.deepEqual(
      questionsFor(undefined).map((q) => q.key),
      safetyKeys,
    );
  });
});

/* ------------------------------------------------------------------ */
/* Vocabulaire : rien de mariage ni d'événementiel dans le socle A     */
/* ------------------------------------------------------------------ */

describe("A_PACK — vocabulaire strictement universel", () => {
  const BANNED = [
    "mariage",
    "marié",
    "mariée",
    "événement",
    "evenement",
    "invité",
    "fête",
    "cérémonie",
    "ceremonie",
    "jour j",
    "noce",
    "réception",
    "anniversaire",
    "concert",
    "public",
  ];

  const samples: Record<string, string> = {
    quand: "2027-08-14",
    ou: "Lille",
    qui: "120",
    budget: "12000",
    intention: "Simple et chaleureux",
  };

  for (const q of A_PACK) {
    test(`« ${q.key} » ne contient aucun vocabulaire de famille de projet`, () => {
      const sample = samples[q.key] ?? "exemple";
      const visible = [q.label, q.question, q.hint ?? "", q.placeholder, q.sentence(sample)]
        .join(" ")
        .toLowerCase();
      for (const word of BANNED) {
        assert.ok(!visible.includes(word), `« ${word} » présent dans ${q.key}`);
      }
    });
  }
});

/* ------------------------------------------------------------------ */
/* mapsTo                                                              */
/* ------------------------------------------------------------------ */

describe("A_PACK — mapsTo valides et strictement canoniques à ce niveau", () => {
  test("chaque mapsTo pointe vers un slot canonique documenté", () => {
    const canonical = new Set(["day", "place", "guests", "budget", "pivotH", "intention"]);
    for (const q of A_PACK) {
      assert.ok(canonical.has(q.mapsTo), `${q.key} → ${q.mapsTo}`);
    }
  });

  test("aucun detail:* au niveau A : les faits de domaine relèvent des packs C", () => {
    assert.ok(A_PACK.every((q) => !q.mapsTo.startsWith("detail:")));
  });
});

/* ------------------------------------------------------------------ */
/* sentence(value) : des formulations directement exploitables          */
/* ------------------------------------------------------------------ */

describe("A_PACK — sentence produit une phrase du récit", () => {
  test("quand : date mise en forme, date inexploitable gardée brute", () => {
    const q = A_PACK_BY_KEY["quand"]!;
    assert.equal(q.sentence("2027-08-14"), "La date visée est le 14 août 2027.");
    assert.equal(q.sentence("au printemps 2028"), "La date visée : au printemps 2028.");
  });

  test("ou : phrase universelle ; intention : gardée mot pour mot", () => {
    assert.equal(A_PACK_BY_KEY["ou"]!.sentence("Lille"), "Le projet se situe à Lille.");
    assert.equal(A_PACK_BY_KEY["intention"]!.sentence("Simple et chaleureux"), "Simple et chaleureux");
  });

  test("qui et budget : phrases complètes dans le récit", () => {
    assert.equal(A_PACK_BY_KEY["qui"]!.sentence("120"), "Ce projet réunit environ 120 personnes.");
    assert.equal(A_PACK_BY_KEY["budget"]!.sentence("12000"), "Le budget est d'environ 12000 €.");
  });

  test("chaque phrase est non vide et propre", () => {
    for (const q of A_PACK) {
      const s = q.sentence("exemple").trim();
      assert.ok(s.length > 0, q.key);
      assert.ok(!s.endsWith("  "), q.key);
    }
  });
});

/* ------------------------------------------------------------------ */
/* Phase temporelle (contrainte AVANT / PENDANT / APRÈS)               */
/* ------------------------------------------------------------------ */

describe("A_PACK — phase temporelle documentée", () => {
  test("chaque question du socle déclare une phase valide", () => {
    for (const q of A_PACK) {
      assert.ok(q.phase, `${q.key} sans phase`);
      assert.ok(["avant", "pendant", "apres"].includes(q.phase!), `${q.key} → ${q.phase}`);
    }
  });

  test("les ancrages du moment sont « pendant », le dimensionnement « avant »", () => {
    assert.equal(A_PACK_BY_KEY["quand"]!.phase, "pendant");
    assert.equal(A_PACK_BY_KEY["ou"]!.phase, "pendant");
    assert.equal(A_PACK_BY_KEY["qui"]!.phase, "avant");
    assert.equal(A_PACK_BY_KEY["budget"]!.phase, "avant");
    assert.equal(A_PACK_BY_KEY["intention"]!.phase, "avant");
  });
});

/* ------------------------------------------------------------------ */
/* Glue du héros (étape 3)                                             */
/* ------------------------------------------------------------------ */

describe("chipText — pastilles du héros", () => {
  test("date ISO mise en forme, date libre gardée brute", () => {
    const q = A_PACK_BY_KEY["quand"]!;
    assert.equal(chipText(q, "2027-08-14"), "14 août 2027");
    assert.equal(chipText(q, "été 2027"), "été 2027");
  });

  test("budget en euros, personnes avec leur libellé, texte brut", () => {
    assert.equal(chipText(A_PACK_BY_KEY["budget"]!, "12000"), "12000 €");
    assert.equal(chipText(A_PACK_BY_KEY["qui"]!, "120"), "120 personnes");
    assert.equal(chipText(A_PACK_BY_KEY["ou"]!, "Lille"), "Lille");
    assert.equal(chipText(A_PACK_BY_KEY["intention"]!, "Simple"), "Simple");
  });

  test("un choix s'affiche tel quel", () => {
    const choice: QuestionSpec = {
      key: "x",
      level: "A",
      label: "Choix",
      question: "Choix ?",
      placeholder: "…",
      type: "choice",
      choices: ["Oui", "Non"],
      mapsTo: "intention",
      sentence: (v) => v,
    };
    assert.equal(chipText(choice, "Oui"), "Oui");
  });
});

describe("blueprintQuestionsAsSpecs — filet dormant du fallback", () => {
  const specs = blueprintQuestionsAsSpecs(blueprintFor("evenement/mariage"));

  test("les 4 questions historiques deviennent des specs valides", () => {
    assert.equal(specs.length, 4);
    assert.deepEqual(
      specs.map((q) => q.key),
      ["quand", "ou", "existant", "qui"],
    );
    for (const q of specs) assert.deepEqual(validateQuestionSpec(q), [], q.key);
  });

  test("les slots canoniques sont retrouvés", () => {
    assert.deepEqual(
      specs.map((q) => q.mapsTo),
      ["day", "place", "budget", "guests"],
    );
  });

  test("les formulations historiques sont préservées mot pour mot", () => {
    const bp = blueprintFor("evenement/mariage");
    const byKey = Object.fromEntries(bp.questions.map((q) => [q.key, q]));
    assert.equal(specs[0]!.sentence("2027-08-14"), byKey["quand"]!.sentence("2027-08-14"));
    assert.equal(specs[3]!.sentence("120"), "Nous serons 120 invités.");
  });
});
