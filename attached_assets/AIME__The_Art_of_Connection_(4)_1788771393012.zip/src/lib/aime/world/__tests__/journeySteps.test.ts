/**
 * Retrait de l'ancien parcours (Vague 3, étape 7) : le registre est la
 * seule source de vérité ; le seuil de progression dérive du nombre réel
 * de QuestionSpec ; plus aucun consommateur de l'ancien système.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { PROJECT_TYPES } from "../blueprints";
import { A_PACK, journeyQuestionCount, questionsFor } from "../questions";

/* ------------------------------------------------------------------ */
/* Le compteur = nombre réel de QuestionSpec, pour chacun des 73 types */
/* ------------------------------------------------------------------ */

describe("journeyQuestionCount — seuil unique de vérité", () => {
  test("le compteur correspond exactement au nombre de questions, pour les 73 Domaines", () => {
    for (const t of PROJECT_TYPES) {
      assert.equal(journeyQuestionCount(t.id), questionsFor(t.id).length, t.id);
    }
  });

  test("un type sans question spécifique reste fonctionnel (socle universel)", () => {
    for (const typeId of ["patrimoine/immo-vente", "lien/mentorat", null, undefined]) {
      const n = journeyQuestionCount(typeId);
      assert.ok(n >= 1, `${typeId} : au moins une question posable`);
    }
  });

  test("seuil « au-delà du parcours » = questions + 1, dérivé du registre", () => {
    /* Historiquement : 5 + 1 = 6 (socle A seul). Depuis l'étape 8, le pack B
       ajoute une question métier : le seuil est passé à 7 SANS qu'aucune
       ligne de HomeJourney ne change — preuve du compteur dérivé. */
    assert.equal(journeyQuestionCount("evenement/mariage"), A_PACK.length + 1);
    assert.equal(journeyQuestionCount("evenement/mariage") + 1, 7);
  });

  test("le compteur est dérivé, jamais un littéral : il suit la longueur réelle", () => {
    /* La définition est littéralement questionsFor(typeId).length — le test
       vérifie cette identité sur tout l'arbre : un futur allongement des
       packs ne pourra pas créer de décalage. */
    const ids = PROJECT_TYPES.map((t) => t.id);
    assert.deepEqual(
      ids.map((id) => journeyQuestionCount(id)),
      ids.map((id) => questionsFor(id).length),
    );
  });
});

/* ------------------------------------------------------------------ */
/* Garde : aucun consommateur de l'ancien système ne subsiste          */
/* ------------------------------------------------------------------ */

describe("l'ancien parcours a disparu des sources", () => {
  const read = (rel: string) => readFileSync(fileURLToPath(new URL(rel, import.meta.url)), "utf8");

  test("journey.ts ne définit ni JOURNEY_STEPS ni JourneyStepKey", () => {
    const journey = read("../journey.ts");
    assert.ok(!journey.includes("JOURNEY_STEPS"));
    assert.ok(!journey.includes("JourneyStepKey"));
  });

  test("HomeJourney n'importe rien de l'ancien système", () => {
    const home = read("../../../../components/aime/home/HomeJourney.tsx");
    assert.ok(!home.includes("JOURNEY_STEPS"));
    assert.ok(!home.includes("JourneyStep"));
    assert.ok(home.includes("journeyQuestionCount"));
  });

  test("HeroBar ne dépend que du registre", () => {
    const hero = read("../../../../components/aime/home/HeroBar.tsx");
    assert.ok(!hero.includes("JOURNEY_STEPS"));
    assert.ok(!hero.includes("JourneyStep"));
    assert.ok(hero.includes("questionsFor"));
  });
});
