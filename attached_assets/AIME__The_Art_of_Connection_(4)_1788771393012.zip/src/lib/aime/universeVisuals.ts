/**
 * Visuel immersif d'une carte : le métier d'abord, l'univers ensuite.
 * Utilisé par les pages Devis et tout bandeau immersif.
 */
import photo from "@/assets/visual-photo.jpg";
import video from "@/assets/visual-video.jpg";
import music from "@/assets/visual-music.jpg";
import food from "@/assets/visual-food.jpg";
import flower from "@/assets/visual-flower.jpg";
import venue from "@/assets/visual-venue.jpg";
import people from "@/assets/visual-people.jpg";
import light from "@/assets/visual-light.jpg";
import service from "@/assets/visual-service.jpg";
import resource from "@/assets/visual-resource.jpg";
import event from "@/assets/visual-event.jpg";
import patisserie from "@/assets/visual-patisserie.jpg";
import cave from "@/assets/visual-cave.jpg";
import beaute from "@/assets/visual-beaute.jpg";
import mode from "@/assets/visual-mode.jpg";
import deco from "@/assets/visual-deco.jpg";
import transport from "@/assets/visual-transport.jpg";
import patrimoine from "@/assets/visual-patrimoine.jpg";
import hotel from "@/assets/visual-hotel.jpg";
import scene from "@/assets/visual-scene.jpg";
import institution from "@/assets/visual-institution.jpg";

/** Visuel par métier (category_slug en base). */
const BY_CATEGORY: Record<string, string> = {
  traiteur: food,
  chef: food,
  "food-truck": food,
  restaurant: food,
  patisserie,
  patissier: patisserie,
  chocolatier: patisserie,
  boulanger: patisserie,
  cave,
  bar: cave,
  barman: cave,
  sommelier: cave,
  vigneron: cave,
  "lieu-reception": venue,
  lieu: venue,
  salle: venue,
  chateau: patrimoine,
  domaine: patrimoine,
  hotel,
  hebergement: hotel,
  gite: hotel,
  "salle-concert": scene,
  festival: light,
  musicien: music,
  dj: music,
  groupe: music,
  studio: music,
  sonorisation: music,
  eclairagiste: light,
  scenographe: light,
  photographe: photo,
  videaste: video,
  drone: video,
  photobooth: photo,
  fleuriste: flower,
  decorateur: deco,
  mobilier: deco,
  location: deco,
  materiel: deco,
  maquilleur: beaute,
  coiffeur: beaute,
  esthetique: beaute,
  soins: beaute,
  couturier: mode,
  tenue: mode,
  robe: mode,
  bijoutier: mode,
  transport,
  navette: transport,
  chauffeur: transport,
  vehicules: transport,
  immobilier: patrimoine,
  "immo-vente": patrimoine,
  "immo-location": patrimoine,
  institution,
  musee: institution,
  galerie: institution,
  theatre: scene,
  association: people,
  planner: service,
  agence: service,
  guide: service,
  formation: service,
  salon: event,
  coworking: service,
};

/** Repli par univers (slug en base). */
const BY_UNIVERSE: Record<string, string> = {
  mariage: flower,
  anniversaire: event,
  naissance: people,
  ceremonie: venue,
  concert: scene,
  culture: institution,
  entreprise: service,
  voyage: hotel,
  rencontre: people,
  association: people,
  evenement: event,
  patrimoine,
};

type VisualCard = {
  image_url?: string | null;
  visual_key?: string | null;
  category_slug?: string | null;
  universes?: string[] | null;
};

const NEUTRAL = resource;

/** Grand visuel immersif : photo de la carte → métier → univers → neutre. */
export function immersiveVisual(card: VisualCard | null | undefined): string {
  if (!card) return NEUTRAL;
  if (card.image_url) return card.image_url;
  const cat = card.category_slug ? BY_CATEGORY[card.category_slug] : undefined;
  if (cat) return cat;
  for (const u of card.universes ?? []) {
    const uni = BY_UNIVERSE[u];
    if (uni) return uni;
  }
  const legacy: Record<string, string> = {
    photo,
    video,
    music,
    food,
    flower,
    venue,
    people,
    light,
    service,
    resource,
    event,
  };
  return (card.visual_key && legacy[card.visual_key]) || NEUTRAL;
}
