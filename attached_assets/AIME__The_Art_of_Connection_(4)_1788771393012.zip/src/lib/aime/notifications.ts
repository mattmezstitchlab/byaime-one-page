import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Notification = Database["public"]["Tables"]["notifications"]["Row"];

/** Les notifications qui restent, du plus récent au plus ancien. */
export function notificationsQuery(userId: string | null | undefined) {
  return {
    queryKey: ["notifications", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async (): Promise<Notification[]> => {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", userId!)
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return data ?? [];
    },
  };
}

export function unreadCount(list: Notification[]): number {
  return list.filter((n) => !n.read_at).length;
}

/** Déposer une notification chez quelqu'un (jamais chez soi-même). */
export async function pushNotification(input: {
  userId: string | null | undefined;
  from?: string | null;
  kind?: string;
  title: string;
  body?: string | null;
  url?: string | null;
  targetType: "carte" | "media" | "moment" | "commentaire";
  targetId: string;
}) {
  if (!input.userId) return;
  if (input.from && input.from === input.userId) return;
  await supabase.from("notifications").insert({
    user_id: input.userId,
    kind: input.kind ?? "info",
    title: input.title,
    body: input.body ?? null,
    url: input.url ?? null,
    actor_id: input.from ?? null,
    target_type: input.targetType,
    target_id: input.targetId,
  });
}

/** Prévenir les abonnés d'un nouveau moment public, sans fabriquer de destinataire arbitraire. */
export async function notifyFollowersOfPost(input: {
  postId: string;
  cardId: string;
  authorId: string;
  cardName: string;
}) {
  const { data: follows, error: followsError } = await supabase
    .from("follows")
    .select("follower_id")
    .eq("card_id", input.cardId)
    .neq("follower_id", input.authorId);
  if (followsError) throw followsError;
  if (!follows?.length) return;
  const { error } = await supabase.from("notifications").insert(
    follows.map((follow) => ({
      user_id: follow.follower_id,
      actor_id: input.authorId,
      kind: "publication",
      title: "Nouveau moment",
      body: `${input.cardName} vient de publier.`,
      url: `/carte/${input.cardId}`,
      target_type: "moment",
      target_id: input.postId,
    })),
  );
  if (error) throw error;
}

export async function markRead(id: string) {
  await supabase
    .from("notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("id", id);
}

export async function markAllRead(userId: string) {
  await supabase
    .from("notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("user_id", userId)
    .is("read_at", null);
}

export async function removeNotification(id: string) {
  await supabase.from("notifications").delete().eq("id", id);
}
