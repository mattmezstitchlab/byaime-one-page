export type Rate = {
  id: string;
  card_id: string;
  label: string;
  month: number | null;
  day: string | null;
  price: number;
  unit: string;
  note: string | null;
};

export const MONTHS = [
  "Janvier",
  "Février",
  "Mars",
  "Avril",
  "Mai",
  "Juin",
  "Juillet",
  "Août",
  "Septembre",
  "Octobre",
  "Novembre",
  "Décembre",
];

export function formatPrice(cents: number) {
  return `${cents.toLocaleString("fr-FR")} €`;
}

/** Tarif applicable à une date : date précise > mois > tarif de base. */
export function rateForDate<T extends Rate>(rates: T[], date: Date | null): T | null {
  if (rates.length === 0) return null;
  if (date) {
    const key = `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, "0")}-${`${date.getDate()}`.padStart(2, "0")}`;
    const exact = rates.find((r) => r.day === key);
    if (exact) return exact;
    const monthly = rates.find((r) => r.month === date.getMonth() + 1 && !r.day);
    if (monthly) return monthly;
  }
  return rates.find((r) => !r.day && r.month === null) ?? rates[0] ?? null;
}
