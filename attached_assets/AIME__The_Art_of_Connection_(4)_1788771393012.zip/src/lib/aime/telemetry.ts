import { supabase } from "@/integrations/supabase/client";

/**
 * Journal vivant du site pendant la bêta.
 *
 * Tout le monde peut écrire (append-only). Seul un administrateur relit
 * l'ensemble ; un membre connecté ne voit que ce qui le concerne.
 */
export type EventKind = "visite" | "premiere" | "fonction" | "erreur" | "blocage" | "retour";
export type EventStatus = "nouveau" | "en_cours" | "resolu" | "ignore";

const ANON = "aime.visitor";
const SEEN = "aime.seen";

export function visitorId(): string {
  if (typeof window === "undefined") return "ssr";
  try {
    const found = window.localStorage.getItem(ANON);
    if (found) return found;
    const next = crypto.randomUUID();
    window.localStorage.setItem(ANON, next);
    return next;
  } catch {
    return "anonyme";
  }
}

/** Vrai la première fois seulement pour une clé donnée (par navigateur). */
export function firstTime(key: string): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.localStorage.getItem(SEEN);
    const seen: string[] = raw ? JSON.parse(raw) : [];
    if (seen.includes(key)) return false;
    window.localStorage.setItem(SEEN, JSON.stringify([...seen, key].slice(-200)));
    return true;
  } catch {
    return false;
  }
}

export async function recordEvent(input: {
  kind: EventKind;
  label: string;
  route?: string;
  node?: string | null;
  payload?: Record<string, unknown>;
  userId?: string | null;
}) {
  try {
    await supabase.from("site_events").insert({
      user_id: input.userId ?? null,
      anon_id: visitorId(),
      kind: input.kind,
      label: input.label.slice(0, 300),
      route: input.route ?? (typeof window !== "undefined" ? window.location.pathname : null),
      node: input.node ?? null,
      payload: JSON.parse(JSON.stringify(input.payload ?? {})),
      status: input.kind === "erreur" || input.kind === "blocage" ? "nouveau" : "resolu",
    });
  } catch {
    /* le journal ne doit jamais casser une page */
  }
}

/** Consigne une erreur réelle rencontrée par un utilisateur. */
export function recordError(
  error: unknown,
  context: { route?: string; node?: string | null; userId?: string | null; where?: string } = {},
) {
  const message =
    error instanceof Error ? error.message : typeof error === "string" ? error : "Erreur inconnue";
  void recordEvent({
    kind: "erreur",
    label: message,
    ...(context.route !== undefined && { route: context.route }),
    node: context.node ?? null,
    userId: context.userId ?? null,
    payload: {
      where: context.where ?? "inconnu",
      stack: error instanceof Error ? (error.stack ?? "").slice(0, 2000) : undefined,
    },
  });
}
