import type { TimelineMarker } from "@/components/aime/HeroTimeline";

/**
 * Rétroplanning générique : à partir d'une date cible, la ligne de temps
 * propose les étapes du projet. Les modèles sont des données, pas du code :
 * ajouter un type de projet ne demande aucune logique nouvelle.
 */

export type RetroStep = {
  /** Jours avant (négatif) ou après (positif) la date cible. */
  offsetDays: number;
  title: string;
  detail?: string;
  kind: TimelineMarker["kind"];
};

export type RetroTemplate = {
  slug: string;
  label: string;
  /** Mots reconnus dans une phrase d'intention. */
  hints: string[];
  steps: RetroStep[];
};

const common = (label: string): RetroStep[] => [
  { offsetDays: -540, title: `Définir l'intention : ${label}`, kind: "intention" },
  { offsetDays: -365, title: "Fixer le budget global", kind: "jalon" },
  { offsetDays: -180, title: "Choisir les prestataires", kind: "tache" },
  { offsetDays: -120, title: "Signer les devis", kind: "devis" },
  { offsetDays: -90, title: "Verser les acomptes", kind: "paiement" },
  { offsetDays: -60, title: "Vérifier les contrats", kind: "document" },
  { offsetDays: -30, title: "Confirmer les intervenants", kind: "message" },
  { offsetDays: -14, title: "Boucler le déroulé", kind: "jalon" },
  { offsetDays: -7, title: "Dernier point avec chacun", kind: "message" },
  { offsetDays: -1, title: "Préparer la journée", kind: "tache" },
  { offsetDays: 0, title: "Jour J", kind: "evenement" },
  { offsetDays: 1, title: "Remerciements", kind: "message" },
  { offsetDays: 7, title: "Régler les soldes", kind: "facture" },
  { offsetDays: 30, title: "Souvenirs et bilan", kind: "souvenir" },
];

export const RETRO_TEMPLATES: RetroTemplate[] = [
  {
    slug: "mariage",
    label: "Mariage",
    hints: ["mariage", "marier", "marie", "noces"],
    steps: [
      { offsetDays: -540, title: "Choisir la date et le lieu", kind: "intention" },
      { offsetDays: -365, title: "Établir la liste des invités", kind: "tache" },
      { offsetDays: -300, title: "Réserver le lieu", kind: "devis" },
      { offsetDays: -240, title: "Photographe et vidéaste", kind: "devis" },
      { offsetDays: -180, title: "Traiteur : dégustation", kind: "evenement" },
      { offsetDays: -150, title: "Musique et animation", kind: "devis" },
      { offsetDays: -120, title: "Envoyer les faire-part", kind: "tache" },
      { offsetDays: -90, title: "Acomptes prestataires", kind: "paiement" },
      { offsetDays: -60, title: "Tenues et essayages", kind: "evenement" },
      { offsetDays: -30, title: "Plan de table", kind: "tache" },
      { offsetDays: -14, title: "Déroulé de la journée", kind: "jalon" },
      { offsetDays: -7, title: "Confirmations finales", kind: "message" },
      { offsetDays: -1, title: "Répétition et installation", kind: "tache" },
      { offsetDays: 0, title: "Jour J", kind: "evenement" },
      { offsetDays: 1, title: "Remerciements aux invités", kind: "message" },
      { offsetDays: 15, title: "Photos et vidéos reçues", kind: "souvenir" },
      { offsetDays: 30, title: "Soldes et factures", kind: "facture" },
    ],
  },
  {
    slug: "evenement",
    label: "Événement / concert",
    hints: ["concert", "événement", "evenement", "spectacle", "festival", "soirée"],
    steps: [
      { offsetDays: -180, title: "Définir le projet artistique", kind: "intention" },
      { offsetDays: -120, title: "Réserver la salle", kind: "devis" },
      { offsetDays: -90, title: "Contrats des intervenants", kind: "document" },
      { offsetDays: -60, title: "Communication et billetterie", kind: "tache" },
      { offsetDays: -30, title: "Fiche technique", kind: "document" },
      { offsetDays: -14, title: "Répétitions", kind: "evenement" },
      { offsetDays: -1, title: "Montage", kind: "tache" },
      { offsetDays: 0, title: "Représentation", kind: "evenement" },
      { offsetDays: 7, title: "Facturation", kind: "facture" },
      { offsetDays: 30, title: "Bilan et archives", kind: "souvenir" },
    ],
  },
  {
    slug: "intermittence",
    label: "Objectif d'heures (intermittence)",
    hints: ["507", "intermittent", "heures", "cachets"],
    steps: [
      { offsetDays: -365, title: "Ouvrir la période de référence", kind: "intention" },
      { offsetDays: -270, title: "Point d'étape : heures déclarées", kind: "jalon" },
      { offsetDays: -180, title: "Rassembler contrats et bulletins", kind: "document" },
      { offsetDays: -120, title: "Vérifier les attestations employeurs", kind: "document" },
      { offsetDays: -60, title: "Relancer les justificatifs manquants", kind: "tache" },
      { offsetDays: -30, title: "Préparer la déclaration", kind: "document" },
      { offsetDays: 0, title: "Date anniversaire", kind: "jalon" },
      { offsetDays: 7, title: "Déposer le dossier", kind: "tache" },
    ],
  },
  {
    slug: "entreprise",
    label: "Création d'entreprise",
    hints: ["entreprise", "société", "societe", "auto-entrepreneur", "statut"],
    steps: [
      { offsetDays: -120, title: "Formaliser le projet", kind: "intention" },
      { offsetDays: -90, title: "Choisir le statut juridique", kind: "jalon" },
      { offsetDays: -60, title: "Rédiger les statuts", kind: "document" },
      { offsetDays: -45, title: "Ouvrir le compte professionnel", kind: "tache" },
      { offsetDays: -30, title: "Déposer le capital", kind: "paiement" },
      { offsetDays: -15, title: "Immatriculation", kind: "document" },
      { offsetDays: 0, title: "Démarrage de l'activité", kind: "evenement" },
      { offsetDays: 30, title: "Première facturation", kind: "facture" },
    ],
  },
  {
    slug: "voyage",
    label: "Voyage",
    hints: ["voyage", "vacances", "séjour", "sejour"],
    steps: [
      { offsetDays: -120, title: "Choisir la destination", kind: "intention" },
      { offsetDays: -90, title: "Réserver le transport", kind: "devis" },
      { offsetDays: -60, title: "Réserver l'hébergement", kind: "devis" },
      { offsetDays: -30, title: "Papiers et assurances", kind: "document" },
      { offsetDays: -7, title: "Préparer les bagages", kind: "tache" },
      { offsetDays: 0, title: "Départ", kind: "evenement" },
      { offsetDays: 14, title: "Souvenirs", kind: "souvenir" },
    ],
  },
  {
    slug: "projet",
    label: "Projet",
    hints: [],
    steps: common("le projet"),
  },
];

const DAY = 86_400_000;

export function templateFor(slug?: string | null): RetroTemplate {
  return RETRO_TEMPLATES.find((t) => t.slug === slug) ?? RETRO_TEMPLATES[RETRO_TEMPLATES.length - 1]!;
}

/** Reconnaît le type de projet dans une phrase d'intention. */
export function guessTemplate(text: string): RetroTemplate {
  const lower = text.toLowerCase();
  for (const t of RETRO_TEMPLATES) {
    if (t.hints.some((h) => lower.includes(h))) return t;
  }
  return templateFor("projet");
}

/** Reconnaît une date cible dans une phrase (jj/mm/aaaa, « 12 septembre 2027 », aaaa-mm-jj). */
export function guessTargetDate(text: string): number | null {
  const iso = text.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return new Date(`${iso[1]}-${iso[2]}-${iso[3]}T12:00:00`).getTime();
  const fr = text.match(/(\d{1,2})[/.](\d{1,2})[/.](\d{4})/);
  if (fr)
    return new Date(
      Number(fr[3]),
      Number(fr[2]) - 1,
      Number(fr[1]),
      12,
    ).getTime();
  const months = [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
  ];
  const lower = text.toLowerCase();
  const words = lower.match(/(\d{1,2})\s+([a-zéûôàè]+)\s+(\d{4})/);
  if (words) {
    const idx = months.findIndex((m) => m.startsWith(words[2]!.slice(0, 4)));
    if (idx >= 0) return new Date(Number(words[3]), idx, Number(words[1]), 12).getTime();
  }
  return null;
}

/**
 * Construit les repères proposés. Rien n'est enregistré : ce sont des
 * propositions marquées « à valider », affichées en pointillé sur la règle.
 */
export function buildRetroplanning(
  template: RetroTemplate,
  targetTime: number,
  opts: { projectId?: string; fromNow?: boolean } = {},
): TimelineMarker[] {
  const now = Date.now();
  return template.steps
    .map((s) => ({
      id: `retro-${template.slug}-${s.offsetDays}`,
      time: targetTime + s.offsetDays * DAY,
      kind: s.kind,
      title: s.title,
      detail:
        s.offsetDays === 0
          ? "Jour J"
          : s.offsetDays < 0
            ? `J${s.offsetDays}`
            : `J+${s.offsetDays}`,
      pending: true,
      status: "a_valider" as const,
      source: "retroplanning",
      ...(opts.projectId ? { projectId: opts.projectId } : {}),
    }))
    .filter((m) => (opts.fromNow === false ? true : m.time >= now - 30 * DAY));
}
