import { supabase } from "@/integrations/supabase/client";
import type { Domain } from "./domains";

const MARK = "Places à pourvoir :";

/** Les places à pourvoir vivent dans le brief tant qu'aucune carte ne s'y pose. */
export function readSlots(brief: string | null): string[] {
  if (!brief) return [];
  const line = brief.split("\n").find((l) => l.startsWith(MARK));
  if (!line) return [];
  return line
    .slice(MARK.length)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function writeSlots(brief: string | null, slots: string[]): string {
  const rest = (brief ?? "")
    .split("\n")
    .filter((l) => !l.startsWith(MARK))
    .join("\n")
    .trim();
  const line = slots.length ? `${MARK} ${slots.join(", ")}` : "";
  return [rest, line].filter(Boolean).join("\n\n");
}

export type AddResult = { slots: number; cards: number };

/**
 * L'exploration remplit le projet : les domaines cochés deviennent des places,
 * les cartes retenues viennent se poser sur la place correspondante.
 */
export async function addToComposition(params: {
  compositionId: string;
  domains: Domain[];
  cards: { id: string; slotLabel: string }[];
}): Promise<AddResult> {
  const { compositionId, domains, cards } = params;

  const { data: comp } = await supabase
    .from("compositions")
    .select("brief")
    .eq("id", compositionId)
    .maybeSingle();

  const existing = readSlots(comp?.brief ?? null);
  const filled = new Set(cards.map((c) => c.slotLabel));
  const merged = Array.from(new Set([...existing, ...domains.map((d) => d.label)])).filter(
    (s) => !filled.has(s),
  );

  await supabase
    .from("compositions")
    .update({ brief: writeSlots(comp?.brief ?? null, merged) })
    .eq("id", compositionId);

  if (cards.length) {
    const { count } = await supabase
      .from("composition_items")
      .select("id", { count: "exact", head: true })
      .eq("composition_id", compositionId);
    const base = count ?? 0;
    await supabase.from("composition_items").insert(
      cards.map((c, i) => ({
        composition_id: compositionId,
        card_id: c.id,
        slot_label: c.slotLabel,
        position: base + i,
      })),
    );
  }

  return { slots: merged.length, cards: cards.length };
}
