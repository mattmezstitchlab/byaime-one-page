import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type AiMemory = Database["public"]["Tables"]["ai_memory"]["Row"];
export type AiUsage = Database["public"]["Tables"]["ai_usage"]["Row"];
export type PayoutAccount = Database["public"]["Tables"]["payout_accounts"]["Row"];

/** Enveloppe mensuelle offerte à chaque membre. */
export const MONTHLY_AI_CREDITS = 120;

export function aiMemoryQuery(userId: string | null) {
  return {
    queryKey: ["ai_memory", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<AiMemory[]> => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("ai_memory")
        .select("*")
        .eq("user_id", userId)
        .order("pinned", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  };
}

export function aiUsageQuery(userId: string | null) {
  return {
    queryKey: ["ai_usage", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<AiUsage[]> => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("ai_usage")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return data ?? [];
    },
  };
}

export function payoutQuery(userId: string | null) {
  return {
    queryKey: ["payout_account", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<PayoutAccount | null> => {
      if (!userId) return null;
      const { data, error } = await supabase
        .from("payout_accounts")
        .select("*")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  };
}

/** Crédits consommés sur le mois en cours. */
export function creditsThisMonth(usage: AiUsage[]) {
  const start = new Date();
  start.setDate(1);
  start.setHours(0, 0, 0, 0);
  return usage
    .filter((u) => new Date(u.created_at) >= start)
    .reduce((sum, u) => sum + u.credits, 0);
}

export async function saveMemory(userId: string, label: string, content: string) {
  const { error } = await supabase
    .from("ai_memory")
    .insert({ user_id: userId, label, content, kind: "note" });
  if (error) throw error;
}

export async function deleteMemory(id: string) {
  const { error } = await supabase.from("ai_memory").delete().eq("id", id);
  if (error) throw error;
}

export async function savePayout(userId: string, values: Partial<PayoutAccount>) {
  const { error } = await supabase
    .from("payout_accounts")
    .upsert({ user_id: userId, ...values }, { onConflict: "user_id" });
  if (error) throw error;
}
