import { supabase } from "@/integrations/supabase/client";
import { ensureThread, sendMessage } from "@/lib/aime/messaging";
import { openDocuments, openMessages } from "@/components/aime/messagesSheet";
import { openEditPage } from "@/components/aime/page/pageSheet";
import { euros } from "@/lib/bureau/logic";
import { pageCompletion } from "@/components/aime/PageCompletion";
import type { Card } from "@/lib/aime/types";
import type { BureauDocument, BureauFolder } from "@/lib/bureau/types";

/**
 * Les « chemins d'un clic » de Mon espace.
 *
 * Rien n'est stocké : chaque chemin est déduit des données déjà là
 * (devis, documents, Aimes, conversations, page publique). Un chemin
 * porte sa propre exécution : un seul clic, et AIME enchaîne tout seul.
 */
export type ActionTone = "orange" | "bleu" | "vert";

export type SpaceAction = {
  id: string;
  tone: ActionTone;
  /** Ce qui appelle : « Devis Traiteur sans envoi ». */
  title: string;
  /** Pourquoi, en une ligne. */
  detail: string;
  /** Le bouton. */
  label: string;
  /** La phrase de confirmation, avant toute exécution. */
  confirm: string;
  /** Projet concerné, s'il y en a un. */
  eventId?: string | null;
  /** Exécute l'enchaînement et renvoie la phrase de résultat. */
  run: () => Promise<string>;
};

type Quote = {
  id: string;
  title: string;
  status: string;
  total: number;
  target_date: string | null;
  created_at: string;
};

type Aime = {
  id: string;
  status: string;
  intent: string;
  message: string | null;
  user_id: string;
  created_at: string;
  author?: string | null;
};

type Thread = { id: string; card_id: string | null; messages?: { sender_id: string; read_at: string | null }[] };

export type SpaceInput = {
  userId: string;
  myCard: Card | null | undefined;
  cards: Card[];
  quotes: Quote[];
  docs: BureauDocument[];
  folders: BureauFolder[];
  aimes: Aime[];
  threads: Thread[];
};

const day = (iso: string | null) =>
  iso
    ? new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long", timeZone: "Europe/Paris" })
    : "date à préciser";

/** Le fil de discussion lié à un dossier, sinon celui de la carte. */
async function threadForFolder(userId: string, folder: BureauFolder | undefined, cards: Card[]) {
  if (folder?.thread_id) return folder.thread_id;
  const card = folder?.card_id ? cards.find((c) => c.id === folder.card_id) : undefined;
  if (card?.owner_id && card.owner_id !== userId) {
    return ensureThread({ me: userId, other: card.owner_id, cardId: card.id });
  }
  return null;
}

export function buildSpaceActions(input: SpaceInput): SpaceAction[] {
  const { userId, myCard, cards, quotes, docs, folders, aimes } = input;
  const list: SpaceAction[] = [];

  // 1 — Un devis écrit mais jamais envoyé.
  for (const q of quotes.filter((x) => x.status === "brouillon")) {
    const folder = folders.find((f) => f.title === q.title);
    const card = folder?.card_id ? cards.find((c) => c.id === folder.card_id) : undefined;
    const who = card?.name ?? "la personne concernée";
    list.push({
      id: `devis:${q.id}`,
      tone: "vert",
      title: q.title,
      detail: `Devis prêt, jamais envoyé — ${euros(q.total)} pour le ${day(q.target_date)}.`,
      label: "Envoyer le devis",
      confirm: `Envoyer le devis de ${euros(q.total)} à ${who} ?`,
      run: async () => {
        const threadId = await threadForFolder(userId, folder, cards);
        if (threadId) {
          await sendMessage(
            threadId,
            userId,
            `Voici le devis « ${q.title} » : ${euros(q.total)}, pour le ${day(q.target_date)}.`,
          );
        }
        await supabase.from("quotes").update({ status: "envoye" }).eq("id", q.id);
        return threadId ? `Devis envoyé à ${who}.` : "Devis marqué comme envoyé.";
      },
    });
  }

  // 2 — Une facture échue et non payée.
  const today = new Date().toISOString().slice(0, 10);
  for (const d of docs.filter(
    (x) => x.doc_type === "facture" && !x.paid_on && x.due_on && x.due_on < today,
  )) {
    const folder = folders.find((f) => f.id === d.folder_id);
    const who = d.counterpart ?? folder?.counterpart ?? "votre contact";
    list.push({
      id: `relance:${d.id}`,
      tone: "orange",
      title: d.file_name,
      detail: `Facture de ${euros(d.amount_ttc)} échue le ${day(d.due_on)}, toujours pas payée.`,
      label: "Relancer",
      ...(folder?.event_id ? { eventId: folder.event_id } : {}),
      confirm: `Relancer ${who} pour la facture de ${euros(d.amount_ttc)} ?`,
      run: async () => {
        const threadId = await threadForFolder(userId, folder, cards);
        if (!threadId) {
          openDocuments(folder?.event_id ?? undefined);
          return "Aucune conversation liée : la facture est ouverte dans les Documents.";
        }
        await sendMessage(
          threadId,
          userId,
          `Petit rappel : la facture « ${d.file_name} » de ${euros(d.amount_ttc)} était due le ${day(d.due_on)}.`,
        );
        openMessages(threadId);
        return `Relance envoyée à ${who}.`;
      },
    });
  }

  // 3 — Un document arrivé sans montant ni date.
  for (const d of docs.filter(
    (x) => x.status !== "valide" && (x.amount_ttc == null || !x.issued_on || x.doc_type === "inconnu"),
  )) {
    const folder = folders.find((f) => f.id === d.folder_id);
    list.push({
      id: `doc:${d.id}`,
      tone: "orange",
      title: d.file_name,
      detail: "Ce document est incomplet : montant, date ou type à confirmer.",
      label: "Compléter",
      ...(folder?.event_id ? { eventId: folder.event_id } : {}),
      confirm: "Ouvrir la fiche de ce document ?",
      run: async () => {
        openDocuments(folder?.event_id ?? undefined);
        return "Fiche du document ouverte.";
      },
    });
  }

  // 4 — Une Aime reçue à laquelle je n'ai pas répondu.
  for (const a of aimes.filter((x) => x.status === "nouveau")) {
    const who = a.author ?? "Quelqu'un";
    list.push({
      id: `aime:${a.id}`,
      tone: "bleu",
      title: `${who} vous a fait signe`,
      detail: a.message?.trim() || `Intention : ${a.intent}.`,
      label: "Répondre",
      confirm: `Ouvrir une conversation avec ${who} ?`,
      run: async () => {
        const threadId = await ensureThread({
          me: userId,
          other: a.user_id,
          cardId: myCard?.id ?? null,
          aimeId: a.id,
        });
        await supabase.from("aimes").update({ status: "lu" }).eq("id", a.id);
        openMessages(threadId);
        return `Conversation ouverte avec ${who}.`;
      },
    });
  }

  // 5 — Ma page publique n'est pas finie.
  if (myCard && pageCompletion(myCard) < 100) {
    list.push({
      id: "page",
      tone: "bleu",
      title: "Ma page publique",
      detail: `Remplie à ${pageCompletion(myCard)} % — c'est elle qui vous rend trouvable.`,
      label: "Compléter ma page",
      confirm: "Ouvrir l'édition de votre page ?",
      run: async () => {
        openEditPage();
        return "Édition de votre page ouverte.";
      },
    });
  }

  return list;
}

/** Combien d'actions attendent sur un projet donné. */
export function actionsForEvent(actions: SpaceAction[], eventId: string) {
  return actions.filter((a) => a.eventId === eventId);
}
