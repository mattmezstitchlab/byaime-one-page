import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Follow = Database["public"]["Tables"]["follows"]["Row"];
export type Reaction = Database["public"]["Tables"]["reactions"]["Row"];
export type Comment = Database["public"]["Tables"]["comments"]["Row"];

/** Ce sur quoi on peut réagir ou écrire. */
export type Target = { type: "carte" | "media" | "moment"; id: string };
/** Les objets du LAB commentent avec la même table, leur étiquette en plus. */
export type LabObjectTarget = { type: "lab_object"; id: string };

/* ---------------------------------- Suivre --------------------------------- */

export function followersQuery(cardId: string | null | undefined) {
  return {
    queryKey: ["follows", cardId ?? "none"],
    enabled: !!cardId,
    queryFn: async (): Promise<Follow[]> => {
      const { data, error } = await supabase.from("follows").select("*").eq("card_id", cardId!);
      if (error) throw error;
      return data ?? [];
    },
  };
}

/** Les pages que je suis. */
export function myFollowsQuery(userId: string | null | undefined) {
  return {
    queryKey: ["mes-abonnements", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async (): Promise<Follow[]> => {
      const { data, error } = await supabase
        .from("follows")
        .select("*")
        .eq("follower_id", userId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function follow(userId: string, cardId: string) {
  const { error } = await supabase.from("follows").insert({ follower_id: userId, card_id: cardId });
  if (error && error.code !== "23505") throw error;
}

export async function unfollow(userId: string, cardId: string) {
  const { error } = await supabase
    .from("follows")
    .delete()
    .eq("follower_id", userId)
    .eq("card_id", cardId);
  if (error) throw error;
}

/* --------------------------------- Réactions -------------------------------- */

export const EMOJIS = ["coeur", "bravo", "rire", "waouh", "merci"] as const;
export type Emoji = (typeof EMOJIS)[number];

/** Le nom lisible d'une réaction (notifications, lecture d'écran). */
export const REACTION_LABEL: Record<string, string> = {
  coeur: "Cœur",
  bravo: "Bravo",
  rire: "Sourire",
  waouh: "Waouh",
  merci: "Merci",
};

export function reactionsQuery(target: Target) {
  return {
    queryKey: ["reactions", target.type, target.id],
    enabled: !!target.id,
    queryFn: async (): Promise<Reaction[]> => {
      const { data, error } = await supabase
        .from("reactions")
        .select("*")
        .eq("target_type", target.type)
        .eq("target_id", target.id);
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function toggleReaction(
  userId: string,
  target: Target,
  emoji: string,
  mine: Reaction | undefined,
) {
  if (mine) {
    const { error } = await supabase.from("reactions").delete().eq("id", mine.id);
    if (error) throw error;
    return;
  }
  const { error } = await supabase.from("reactions").insert({
    user_id: userId,
    target_type: target.type,
    target_id: target.id,
    emoji,
  });
  if (error && error.code !== "23505") throw error;
}

export function countByEmoji(list: Reaction[]): Record<string, number> {
  const out: Record<string, number> = {};
  for (const r of list) out[r.emoji] = (out[r.emoji] ?? 0) + 1;
  return out;
}

/* -------------------------------- Commentaires ------------------------------- */

export function commentsQuery(target: Target | LabObjectTarget) {
  return {
    queryKey: ["commentaires", target.type, target.id],
    enabled: !!target.id,
    queryFn: async (): Promise<Comment[]> => {
      const { data, error } = await supabase
        .from("comments")
        .select("*")
        .eq("target_type", target.type)
        .eq("target_id", target.id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function addComment(input: {
  userId: string;
  cardId: string | null;
  target: Target | LabObjectTarget;
  body: string;
  parentId?: string | null;
}) {
  const body = input.body.trim();
  if (!body || body.length > 1500) throw new Error("longueur");
  const { error } = await supabase.from("comments").insert({
    user_id: input.userId,
    card_id: input.cardId,
    target_type: input.target.type,
    target_id: input.target.id,
    body,
    parent_id: input.parentId ?? null,
  });
  if (error) throw error;
}

export async function removeComment(id: string) {
  const { error } = await supabase.from("comments").delete().eq("id", id);
  if (error) throw error;
}

/* --------------------------------- Personnes -------------------------------- */

export type Person = { id: string; name: string; avatar: string | null };

export function peopleQuery(ids: string[]) {
  const clean = Array.from(new Set(ids.filter(Boolean))).sort();
  return {
    queryKey: ["personnes", clean.join(",")],
    enabled: clean.length > 0,
    queryFn: async (): Promise<Record<string, Person>> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, display_name, avatar_url")
        .in("id", clean);
      if (error) throw error;
      const out: Record<string, Person> = {};
      for (const p of data ?? [])
        out[p.id] = { id: p.id, name: p.display_name, avatar: p.avatar_url };
      return out;
    },
  };
}
