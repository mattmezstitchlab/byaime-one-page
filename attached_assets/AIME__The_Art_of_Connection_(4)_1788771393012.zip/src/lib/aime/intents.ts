import type { AimeIntent } from "./types";

export type IntentDef = {
  value: AimeIntent;
  label: string;
  hint: string;
};

export const INTENTS: IntentDef[] = [
  { value: "aime", label: "J'aime", hint: "Garder cette carte en tête" },
  { value: "collaborer", label: "Collaborer", hint: "Créer quelque chose ensemble" },
  { value: "reserver", label: "Réserver", hint: "Bloquer une date" },
  { value: "recommander", label: "Recommander", hint: "La faire connaître" },
  { value: "associer", label: "Associer", hint: "La garder près de vous" },
  { value: "contacter", label: "Contacter", hint: "Ouvrir la conversation" },
  { value: "enregistrer", label: "Enregistrer", hint: "Mettre de côté" },
];

export const INTENT_LABEL = Object.fromEntries(INTENTS.map((i) => [i.value, i.label])) as Record<
  AimeIntent,
  string
>;
