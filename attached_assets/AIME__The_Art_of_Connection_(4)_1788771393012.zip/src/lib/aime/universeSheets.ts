/**
 * Les fiches d'univers d'une page : ce que le propriétaire raconte, univers par
 * univers. Stockées sur la carte, elles alimentent le carrousel de la vitrine.
 */
export type UniverseSheet = {
  slug: string;
  title?: string | undefined;
  subtitle?: string | undefined;
  /** Image ou vidéo choisie pour cet univers. */
  media?: string | undefined;
  /** Tarif d'entrée, en euros. */
  from?: number | undefined;
  description?: string | undefined;
};

type Holder = { universe_cards?: unknown } | null | undefined;

function toSheet(raw: unknown): UniverseSheet | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const slug = typeof o["slug"] === "string" ? o["slug"] : null;
  if (!slug) return null;
  const str = (k: string) => (typeof o[k] === "string" && o[k] ? (o[k] as string) : undefined);
  const num = (k: string) => (typeof o[k] === "number" ? (o[k] as number) : undefined);
  return {
    slug,
    title: str("title"),
    subtitle: str("subtitle"),
    media: str("media"),
    from: num("from"),
    description: str("description"),
  };
}

/** Les fiches d'une carte, indexées par univers. */
export function universeSheets(card: Holder): Record<string, UniverseSheet> {
  const raw = card?.universe_cards;
  if (!Array.isArray(raw)) return {};
  const out: Record<string, UniverseSheet> = {};
  for (const item of raw) {
    const sheet = toSheet(item);
    if (sheet) out[sheet.slug] = sheet;
  }
  return out;
}
