import {
  CalendarCheck,
  CheckCircle2,
  Eye,
  FileText,
  Receipt,
  Send,
  Share2,
  Trash2,
  Unlock,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";

/** Une action déclenchable directement depuis la bulle d'aperçu de la timeline. */
export type TimelineAction = {
  key: string;
  label: string;
  icon: LucideIcon;
  run: () => void;
};

export type TimelineActionHandlers = {
  reserve?: (m: TimelineMarker) => void;
  quote?: (m: TimelineMarker) => void;
  invoice?: (m: TimelineMarker) => void;
  open?: (m: TimelineMarker) => void;
  contact?: (m: TimelineMarker) => void;
  share?: (m: TimelineMarker) => void;
  confirm?: (m: TimelineMarker) => void;
  release?: (m: TimelineMarker) => void;
  remove?: (m: TimelineMarker) => void;
};

const ICONS = {
  reserve: CalendarCheck,
  quote: FileText,
  invoice: Receipt,
  open: Eye,
  contact: Send,
  share: Share2,
  confirm: CheckCircle2,
  release: Unlock,
  remove: Trash2,
  people: Users,
} satisfies Record<string, LucideIcon>;

const LABELS: Record<keyof TimelineActionHandlers, string> = {
  reserve: "Réserver",
  quote: "Devis",
  invoice: "Facture",
  open: "Ouvrir",
  contact: "Écrire",
  share: "Partager",
  confirm: "Confirmer",
  release: "Libérer",
  remove: "Supprimer",
};

/** Quelles clés d'action proposer selon la nature du repère. */
function keysFor(m: TimelineMarker, future: boolean): (keyof TimelineActionHandlers)[] {
  switch (m.kind) {
    case "disponible":
      return future ? ["reserve", "quote", "contact"] : ["contact"];
    case "option":
      return ["confirm", "release", "contact"];
    case "complet":
      return ["contact"];
    case "devis":
      return ["open", "invoice", "contact"];
    case "facture":
      return ["open", "confirm", "contact"];
    case "paiement":
      return ["open", "share"];
    case "document":
      return ["open", "share"];
    case "tache":
      return ["confirm", "contact"];
    case "message":
      return ["contact", "open"];
    case "evenement":
      return ["open", "reserve", "share"];

    case "intention":
      return ["contact", "quote"];
    default:
      return m.media ? ["open", "share"] : ["contact"];
  }
}

/** Construit la liste d'actions réellement disponibles (handler fourni). */
export function timelineActions(
  m: TimelineMarker,
  handlers: TimelineActionHandlers,
  opts: { canRemove?: boolean } = {},
): TimelineAction[] {
  const future = m.time > Date.now();
  const keys = keysFor(m, future);
  const out: TimelineAction[] = [];
  for (const k of keys) {
    const fn = handlers[k];
    if (!fn) continue;
    out.push({ key: k, label: LABELS[k], icon: ICONS[k], run: () => fn(m) });
    if (out.length === 3) break;
  }
  if (opts.canRemove && handlers.remove) {
    out.push({
      key: "remove",
      label: LABELS.remove,
      icon: ICONS.remove,
      run: () => handlers.remove!(m),
    });
  }
  return out;
}
