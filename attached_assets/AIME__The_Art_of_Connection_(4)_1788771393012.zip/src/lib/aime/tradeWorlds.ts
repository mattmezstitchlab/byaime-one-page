/**
 * Source unique de vérité : un métier (`cards.category_slug`) → un ou plusieurs
 * Mondes AIME (les 12 territoires de découverte).
 *
 * Règles :
 * - les Mondes ne classent plus une personne, ils servent à découvrir ;
 * - un métier peut appartenir à plusieurs Mondes ;
 * - rien n'est stocké en base : cette table vit uniquement ici.
 *
 * Aucune donnée n'est supprimée : la colonne historique `cards.universes`
 * reste lisible, mais elle n'est plus la source de classement.
 */
import { UNIVERSE_TREE } from "./universeTree";

export type WorldSlug =
  | "evenement"
  | "musique"
  | "culture"
  | "entreprise"
  | "lieux"
  | "table"
  | "image"
  | "style"
  | "patrimoine"
  | "voyage"
  | "lien"
  | "solidarite";

/** Les 21 métiers réellement présents en base, plus les slugs historiques. */
export const TRADE_WORLDS: Record<string, WorldSlug[]> = {
  agence: ["entreprise", "evenement"],
  artiste: ["culture", "musique"],
  association: ["solidarite", "lien"],
  dj: ["musique", "evenement"],
  eclairagiste: ["musique", "evenement"],
  festival: ["musique", "culture", "evenement"],
  fleuriste: ["evenement", "style"],
  guide: ["voyage", "culture"],
  hotel: ["voyage", "lieux"],
  institution: ["patrimoine", "culture"],
  "lieu-reception": ["lieux", "evenement", "table"],
  maquilleur: ["style", "image"],
  mobilier: ["lieux", "culture"],
  musicien: ["musique", "evenement"],
  personne: ["lien"],
  photographe: ["image", "evenement"],
  planner: ["evenement", "entreprise"],
  projet: ["evenement"],
  "salle-concert": ["musique", "lieux"],
  salon: ["entreprise", "lien"],
  sonorisation: ["musique", "evenement"],
  temoin: ["lien"],
  traiteur: ["table", "evenement"],
  transport: ["voyage", "evenement"],
  videaste: ["image", "culture"],
  // Slugs historiques conservés pour compatibilité (aucune donnée supprimée).
  sport: ["lien", "evenement"],
};

/**
 * Correspondances volontairement signalées comme incertaines : elles servent de
 * repli lisible, elles ne prétendent pas être la bonne classification.
 */
export const AMBIGUOUS_TRADES = new Set<string>(["sport", "personne", "projet"]);

/** Repli explicite quand un métier inconnu apparaît : on rattache au lien. */
export const FALLBACK_WORLDS: WorldSlug[] = ["lien"];

export function worldsForTrade(slug: string | null | undefined): WorldSlug[] {
  if (!slug) return [];
  return TRADE_WORLDS[slug] ?? FALLBACK_WORLDS;
}

export function tradesForWorld(world: string): string[] {
  return Object.keys(TRADE_WORLDS).filter((slug) =>
    (TRADE_WORLDS[slug] ?? []).includes(world as WorldSlug),
  );
}

const LABELS = new Map(UNIVERSE_TREE.map((u) => [u.slug, u.label]));

export function worldLabel(slug: string): string {
  return LABELS.get(slug) ?? slug;
}
