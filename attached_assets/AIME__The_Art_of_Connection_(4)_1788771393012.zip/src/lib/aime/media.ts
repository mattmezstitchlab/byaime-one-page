import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { MEDIA_KINDS, hostOfUrl, youtubeThumb } from "./mediaKind";
import type { MediaKind } from "./mediaKind";

/* Le cœur pur (YouTube, classification) vit dans `mediaKind.ts` — module
   feuille testable seul. Ré-exporté ici : aucun consommateur ne change. */
export {
  MEDIA_KINDS,
  youtubeId,
  youtubeThumb,
  youtubeEmbed,
  guessKind,
  hostOfUrl,
  isPdfUrl,
} from "./mediaKind";
export type { MediaKind } from "./mediaKind";

export type MediaItem = Database["public"]["Tables"]["media_items"]["Row"];

/** L'image à afficher dans la case, si le média en a une. */
export function mediaThumb(m: MediaItem): string | null {
  if (m.thumb_url) return m.thumb_url;
  if (m.kind === "photo") return m.url;
  if (m.kind === "youtube") return youtubeThumb(m.url);
  if (m.kind === "lien") {
    return `https://www.google.com/s2/favicons?sz=256&domain_url=${encodeURIComponent(m.url)}`;
  }
  return null;
}

export function mediaLabel(m: MediaItem): string {
  if (m.title) return m.title;
  if (m.kind === "lien") {
    return hostOfUrl(m.url) ?? "Lien";
  }
  if (m.kind === "doc") {
    return hostOfUrl(m.url) ?? "Document";
  }
  const k = MEDIA_KINDS.find((x) => x.key === m.kind);
  return k?.label ?? "Média";
}

export function mediaQuery(target: { cardId?: string | null; eventId?: string | null }) {
  const cardId = target.cardId ?? null;
  const eventId = target.eventId ?? null;
  return {
    queryKey: ["media-items", cardId, eventId] as const,
    enabled: !!(cardId || eventId),
    queryFn: async (): Promise<MediaItem[]> => {
      let q = supabase.from("media_items").select("*").order("position", { ascending: true });
      if (cardId) q = q.eq("card_id", cardId);
      else if (eventId) q = q.eq("event_id", eventId);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  };
}

/** Envoi d'un fichier : l'adresse signée reste valable très longtemps. */
export async function uploadMediaFile(userId: string, file: File): Promise<string> {
  const path = `${userId}/media/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
  const { error } = await supabase.storage.from("cartes").upload(path, file, { upsert: true });
  if (error) throw error;
  const { data, error: signErr } = await supabase.storage
    .from("cartes")
    .createSignedUrl(path, 60 * 60 * 24 * 365 * 5);
  if (signErr) throw signErr;
  return data.signedUrl;
}

export type NewMedia = {
  kind: MediaKind;
  url: string;
  title?: string | null;
  thumb_url?: string | null;
};

export async function addMedia(
  target: { cardId?: string | null; eventId?: string | null },
  media: NewMedia,
  userId: string | null,
  position: number,
) {
  const { error } = await supabase.from("media_items").insert({
    card_id: target.cardId ?? null,
    event_id: target.eventId ?? null,
    kind: media.kind,
    url: media.url,
    title: media.title ?? null,
    thumb_url: media.thumb_url ?? (media.kind === "youtube" ? youtubeThumb(media.url) : null),
    position,
    created_by: userId,
  } as never);
  if (error) throw error;
}

export async function updateMedia(id: string, patch: Partial<MediaItem>) {
  const { error } = await supabase
    .from("media_items")
    .update(patch as never)
    .eq("id", id);
  if (error) throw error;
}

export async function removeMedia(id: string) {
  const { error } = await supabase.from("media_items").delete().eq("id", id);
  if (error) throw error;
}

/** Échange la place de deux médias voisins. */
export async function swapMedia(a: MediaItem, b: MediaItem) {
  await updateMedia(a.id, { position: b.position });
  await updateMedia(b.id, { position: a.position });
}
