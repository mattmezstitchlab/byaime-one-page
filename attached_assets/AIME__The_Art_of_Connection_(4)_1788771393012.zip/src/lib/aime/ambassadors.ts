import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Ambassador = Database["public"]["Tables"]["ambassadors"]["Row"];
export type Mission = Database["public"]["Tables"]["ambassador_missions"]["Row"];
export type MissionIntent = Database["public"]["Tables"]["mission_intents"]["Row"];

/** Durée d'une présence déclarée : on se dit « en ligne » pour 30 minutes. */
const PRESENCE_MIN = 30;

export async function listMissions(): Promise<Mission[]> {
  const { data, error } = await supabase
    .from("ambassador_missions")
    .select("*")
    .order("sort_order");
  if (error) throw error;
  return data ?? [];
}

export async function myAmbassador(userId: string): Promise<Ambassador | null> {
  const { data, error } = await supabase
    .from("ambassadors")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function upsertAmbassador(
  userId: string,
  patch: Partial<Omit<Ambassador, "user_id" | "created_at" | "updated_at">>,
) {
  const { error } = await supabase
    .from("ambassadors")
    .upsert({ user_id: userId, ...patch }, { onConflict: "user_id" });
  if (error) throw error;
}

/** Se déclarer joignable pour la demi-heure qui vient. */
export async function goOnline(userId: string) {
  const until = new Date(Date.now() + PRESENCE_MIN * 60_000).toISOString();
  await upsertAmbassador(userId, { help_consent: true, accepted: true, online_until: until });
}

export async function goOffline(userId: string) {
  await upsertAmbassador(userId, { online_until: null });
}

/** Les personnes réellement joignables maintenant, qui ont accepté d'aider. */
export async function availableHelpers(limit = 6): Promise<Ambassador[]> {
  const { data, error } = await supabase
    .from("ambassadors")
    .select("*")
    .eq("help_consent", true)
    .gt("online_until", new Date().toISOString())
    .limit(limit);
  if (error) return [];
  return data ?? [];
}

export async function myIntents(userId: string): Promise<MissionIntent[]> {
  const { data, error } = await supabase.from("mission_intents").select("*").eq("user_id", userId);
  if (error) throw error;
  return data ?? [];
}

export async function declareIntent(userId: string, slug: string, message?: string) {
  const { error } = await supabase
    .from("mission_intents")
    .upsert(
      { user_id: userId, mission_slug: slug, message: message ?? null },
      { onConflict: "user_id,mission_slug" },
    );
  if (error) throw error;
}

export async function withdrawIntent(userId: string, slug: string) {
  const { error } = await supabase
    .from("mission_intents")
    .delete()
    .eq("user_id", userId)
    .eq("mission_slug", slug);
  if (error) throw error;
}

/**
 * Valeur d'une personne sur AIME : elle ne se décrète pas, elle se constate.
 * Chaque intention déclarée pèse selon la mission choisie.
 */
export function competenceProfile(missions: Mission[], intents: MissionIntent[]) {
  const bySlug = new Map(missions.map((m) => [m.slug, m]));
  const scores = new Map<string, number>();
  for (const intent of intents) {
    const m = bySlug.get(intent.mission_slug);
    if (!m) continue;
    const bonus = intent.status === "validee" ? 2 : intent.status === "en_cours" ? 1 : 0;
    scores.set(m.skill, (scores.get(m.skill) ?? 0) + m.value + bonus);
  }
  return [...scores.entries()]
    .map(([skill, score]) => ({ skill, score }))
    .sort((a, b) => b.score - a.score);
}
