/**
 * Le plan d'un mariage : une composition (les places à pourvoir) et un projet
 * (les invités, les paiements, les documents), tous deux rattachés à la carte.
 * Aucune table nouvelle : on réutilise ce qui existe déjà.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { addToComposition, readSlots } from "./compositionAdd";
import { WEDDING_ROLES, WEDDING_UNIVERSE } from "./presets/mariage";
import type { Card } from "./types";

export function weddingPlanQuery(cardId: string | null | undefined) {
  return queryOptions({
    queryKey: ["wedding-plan", cardId],
    enabled: !!cardId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("compositions")
        .select("*, composition_items(*)")
        .eq("card_id", cardId!)
        .order("created_at")
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function weddingProjectQuery(cardId: string | null | undefined) {
  return queryOptions({
    queryKey: ["wedding-project", cardId],
    enabled: !!cardId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("*, event_participants(*)")
        .eq("card_id", cardId!)
        .order("starts_at")
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

/** Ouvre le plan des places du mariage, avec les rôles habituels déjà posés. */
export async function ensureWeddingPlan(params: { userId: string; card: Card }) {
  const { userId, card } = params;
  const { data: existing } = await supabase
    .from("compositions")
    .select("id")
    .eq("card_id", card.id)
    .limit(1)
    .maybeSingle();
  if (existing) return existing.id;

  const brief = `Places à pourvoir : ${WEDDING_ROLES.map((r) => r.label).join(", ")}`;
  const { data, error } = await supabase
    .from("compositions")
    .insert({
      user_id: userId,
      card_id: card.id,
      title: card.name,
      universe_slug: WEDDING_UNIVERSE,
      brief,
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}

/** Ouvre le projet du mariage : invités, paiements et documents suivent. */
export async function ensureWeddingProject(params: {
  userId: string;
  card: Card;
  startsAt?: string | null;
}) {
  const { userId, card, startsAt } = params;
  const { data: existing } = await supabase
    .from("events")
    .select("id")
    .eq("card_id", card.id)
    .limit(1)
    .maybeSingle();
  if (existing) return existing.id;

  const { data, error } = await supabase
    .from("events")
    .insert({
      owner_id: userId,
      card_id: card.id,
      title: card.name,
      universe_slug: WEDDING_UNIVERSE,
      city: card.city,
      starts_at: startsAt ?? new Date().toISOString(),
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}

/** Pose une carte sur une place : la place devient pleine. */
export async function fillRole(params: {
  compositionId: string;
  slotLabel: string;
  cardId: string;
}) {
  await addToComposition({
    compositionId: params.compositionId,
    domains: [],
    cards: [{ id: params.cardId, slotLabel: params.slotLabel }],
  });
}

/** Retire la carte posée sur une place, qui redevient à pourvoir. */
export async function clearRole(params: {
  compositionId: string;
  itemId: string;
  slotLabel: string;
  brief: string | null;
}) {
  await supabase.from("composition_items").delete().eq("id", params.itemId);
  const slots = readSlots(params.brief);
  if (!slots.includes(params.slotLabel)) {
    const rest = (params.brief ?? "")
      .split("\n")
      .filter((l) => !l.startsWith("Places à pourvoir :"))
      .join("\n")
      .trim();
    const line = `Places à pourvoir : ${[...slots, params.slotLabel].join(", ")}`;
    await supabase
      .from("compositions")
      .update({ brief: [rest, line].filter(Boolean).join("\n\n") })
      .eq("id", params.compositionId);
  }
}
