import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({ code: z.string().trim().min(3).max(64) });

export type PublicInvite = {
  code: string;
  label: string;
  message: string | null;
  universe_slug: string | null;
};

/**
 * Vérifie un code d'invitation exact, côté serveur.
 * La table des invitations n'est plus lisible publiquement : seule cette
 * recherche par code renvoie les quelques champs affichables.
 */
export const lookupInvite = createServerFn({ method: "POST" })
  .validator((raw: unknown) => Input.parse(raw))
  .handler(async ({ data }): Promise<PublicInvite | null> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: invite, error } = await supabaseAdmin
      .from("invites")
      .select("code,label,message,universe_slug,expires_at")
      .eq("code", data.code)
      .maybeSingle();
    if (error) throw new Error("Vérification du lien impossible.");
    if (!invite) return null;
    if (invite.expires_at && new Date(invite.expires_at).getTime() <= Date.now()) return null;
    return {
      code: invite.code,
      label: invite.label,
      message: invite.message,
      universe_slug: invite.universe_slug,
    };
  });
