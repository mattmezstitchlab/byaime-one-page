import { supabase } from "@/integrations/supabase/client";

/**
 * Modèle de fournisseur musical : le morceau n'est jamais téléchargé ni stocké,
 * seule une prévisualisation légale et limitée est jouée quand la source l'autorise.
 */
export type MusicTrack = {
  provider: string;
  trackId: string;
  title: string;
  artist?: string | undefined;
  artwork?: string | undefined;
  previewUrl?: string | undefined;
  externalUrl?: string | undefined;
  /** Durée en secondes. */
  duration?: number | undefined;
  rights?: string | undefined;
  availability?: string | undefined;
};

export type MusicProvider = {
  id: string;
  label: string;
  /** Recherche de titres ; renvoie une liste normalisée. */
  search: (query: string) => Promise<MusicTrack[]>;
};

/** Fournisseur par défaut : catalogue iTunes, extraits de 30 secondes autorisés. */
export const itunesProvider: MusicProvider = {
  id: "itunes",
  label: "Catalogue public",
  search: async (query) => {
    const url = `https://itunes.apple.com/search?media=music&limit=12&term=${encodeURIComponent(query)}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const json = (await res.json()) as { results?: Record<string, unknown>[] };
    return (json.results ?? []).map((r) => ({
      provider: "itunes",
      trackId: String(r["trackId"] ?? ""),
      title: String(r["trackName"] ?? "Sans titre"),
      artist: r["artistName"] ? String(r["artistName"]) : undefined,
      artwork: r["artworkUrl100"] ? String(r["artworkUrl100"]) : undefined,
      previewUrl: r["previewUrl"] ? String(r["previewUrl"]) : undefined,
      externalUrl: r["trackViewUrl"] ? String(r["trackViewUrl"]) : undefined,
      duration: r["trackTimeMillis"] ? Math.round(Number(r["trackTimeMillis"]) / 1000) : undefined,
      rights: "preview-30s",
      availability: "public",
    }));
  },
};

export const MUSIC_PROVIDERS: MusicProvider[] = [itunesProvider];

/** Formats audio acceptés à l'import. */
export const AUDIO_TYPES = ".mp3,.wav,.m4a,.aac,.flac,audio/*";

/**
 * Dépôt d'un média dans l'espace privé de la carte. Le fichier d'origine
 * n'est jamais transformé : on conserve son nom et son type.
 */
export async function uploadTimelineMedia(cardId: string, file: File) {
  const clean = file.name.replace(/[^\w.\-]+/g, "_");
  const path = `${cardId}/${Date.now()}-${clean}`;
  const { error } = await supabase.storage
    .from("timeline-media")
    .upload(path, file, {
      ...(file.type ? { contentType: file.type } : {}),
      upsert: false,
    });

  if (error) throw error;
  const { data } = await supabase.storage.from("timeline-media").createSignedUrl(path, 60 * 60 * 24 * 7);
  return { path, url: data?.signedUrl ?? null };
}
