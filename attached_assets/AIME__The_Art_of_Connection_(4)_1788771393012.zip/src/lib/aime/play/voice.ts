import { speakNarration } from "@/lib/aime/play/speak.functions";

const cache = new Map<string, string>();
const KEY = "aime:voix";

export function voiceEnabled() {
  if (typeof localStorage === "undefined") return false;
  return localStorage.getItem(KEY) !== "off";
}

export function setVoiceEnabled(on: boolean) {
  localStorage.setItem(KEY, on ? "on" : "off");
}

/** Fabrique (une seule fois par phrase) la voix de l'animatrice. */
export async function narrationAudioUrl(text: string): Promise<string> {
  const key = text.trim();
  const known = cache.get(key);
  if (known) return known;
  const { audio } = await speakNarration({ data: { text: key } });
  const url = `data:audio/mpeg;base64,${audio}`;
  cache.set(key, url);
  return url;
}
