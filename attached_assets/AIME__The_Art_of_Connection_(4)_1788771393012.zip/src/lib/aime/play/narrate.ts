import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import { KIND_LABEL_TIMELINE } from "@/components/aime/HeroTimeline";

const HOUR = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" });
const DAY = new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long" });

function euros(cents?: number) {
  if (typeof cents !== "number") return null;
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);
}

/**
 * Narration dérivée uniquement de ce que porte le repère : aucune invention,
 * aucun fait ajouté. Si le repère ne dit rien, la narration reste vide.
 */
export function narrationFor(m: TimelineMarker): string {
  const parts: string[] = [];
  const d = new Date(m.time);
  const past = m.time < Date.now();
  const when = m.startTime ? `à ${HOUR.format(new Date(m.startTime))}` : "";
  parts.push(
    `${DAY.format(d)}${when ? ` ${when}` : ""}, ${past ? "il y a eu" : "il y aura"} ${
      KIND_LABEL_TIMELINE[m.kind].toLowerCase()
    } : ${m.title}.`,
  );
  if (m.detail) parts.push(m.detail);
  if (m.location) parts.push(`Lieu : ${m.location}.`);
  const money = euros(m.amountCents);
  if (money) parts.push(`Montant : ${money}.`);
  if (m.personIds?.length) parts.push(`${m.personIds.length} personne(s) concernée(s).`);
  return parts.join(" ");
}

/** Phrase d'ouverture d'une séquence, construite sur les seuls repères présents. */
export function openingLine(markers: TimelineMarker[]): string {
  if (markers.length === 0) return "Il n'y a rien à lire sur cette période.";
  const first = markers[0]!;
  const last = markers[markers.length - 1]!;
  const same = new Date(first.time).toDateString() === new Date(last.time).toDateString();
  return same
    ? `${markers.length} moment(s), ${DAY.format(new Date(first.time))}.`
    : `${markers.length} moment(s), de ${DAY.format(new Date(first.time))} à ${DAY.format(new Date(last.time))}.`;
}
