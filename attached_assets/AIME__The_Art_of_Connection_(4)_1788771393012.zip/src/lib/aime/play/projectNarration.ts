/**
 * Le récit d'un projet, à voix haute.
 *
 * L'animatrice lit ce que le projet dit déjà de lui-même : qui est réuni, ce
 * qui manque, où en est l'argent, ce que la météo annonce ce jour-là, et un
 * plan B quand le ciel l'exige. Rien n'est inventé : chaque phrase vient d'une
 * information déjà enregistrée.
 */
import { supabase } from "@/integrations/supabase/client";
import { lookupWeather } from "@/lib/aime/weather.functions";
import { readSelection } from "@/lib/aime/team/quintessence";
import type { Card } from "@/lib/aime/types";

export type ProjectStory = {
  title: string;
  /** Une phrase par respiration : chacune est lue séparément. */
  parts: string[];
};

function euros(cents: number) {
  return `${Math.round(cents / 100)} euros`;
}

function frDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

export async function buildProjectStory(eventId: string): Promise<ProjectStory> {
  const { data: event } = await supabase
    .from("events")
    .select("*, event_participants(card_id, role_label, status)")
    .eq("id", eventId)
    .maybeSingle();

  if (!event) return { title: "Projet", parts: ["Ce projet n'est plus accessible."] };

  const parts: string[] = [];
  const day = event.starts_at.slice(0, 10);
  const daysLeft = Math.round((new Date(event.starts_at).getTime() - Date.now()) / 86_400_000);

  parts.push(
    `${event.title}${event.city ? `, à ${event.city}` : ""}, le ${frDate(event.starts_at)}.` +
      (daysLeft > 0
        ? ` Il reste ${daysLeft} jour${daysLeft > 1 ? "s" : ""}.`
        : daysLeft === 0
          ? " C'est aujourd'hui."
          : " C'est passé."),
  );

  // QUI EST RÉUNI, ET CE QUI MANQUE
  const participants = (event.event_participants ?? []) as {
    card_id: string;
    role_label: string | null;
  }[];
  let cards: Card[] = [];
  if (participants.length > 0) {
    const { data } = await supabase
      .from("cards")
      .select("*")
      .in(
        "id",
        participants.map((p) => p.card_id),
      );
    cards = (data ?? []) as unknown as Card[];
  }

  if (cards.length === 0) {
    parts.push("Personne n'est encore réuni autour de ce projet.");
  } else {
    parts.push(
      `${cards.length} personne${cards.length > 1 ? "s sont réunies" : " est réunie"} : ${cards
        .map((c) => c.name)
        .slice(0, 6)
        .join(", ")}.`,
    );
    const reading = readSelection(cards)[0];
    if (reading) {
      if (reading.missing.length === 0) {
        parts.push(`Toutes les places de « ${reading.formula.title} » sont tenues.`);
      } else {
        parts.push(
          `Pour tenir « ${reading.formula.title} », il manque encore : ${reading.missing
            .map((m) => m.label)
            .slice(0, 4)
            .join(", ")}.`,
        );
      }
    }
  }

  // L'ARGENT
  const { data: payments } = await supabase
    .from("event_payments")
    .select("amount_due, amount_paid, status, label")
    .eq("event_id", eventId);
  if (payments && payments.length > 0) {
    const due = payments.reduce((s, p) => s + (p.amount_due ?? 0), 0);
    const paid = payments.reduce((s, p) => s + (p.amount_paid ?? 0), 0);
    parts.push(
      `Côté argent : ${euros(paid)} reçus sur ${euros(due)} attendus.` +
        (paid < due ? " Il reste des règlements à relancer." : " Tout est réglé."),
    );
  } else {
    parts.push("Aucune somme n'est encore inscrite pour ce projet.");
  }

  // LA PROGRAMMATION
  const { data: music } = await supabase
    .from("musicbox_entries")
    .select("title, kind")
    .eq("event_id", eventId)
    .limit(5);
  if (music && music.length > 0) {
    parts.push(`La programmation compte déjà ${music.length} moment${music.length > 1 ? "s" : ""}.`);
  } else {
    parts.push("Rien n'est encore programmé côté musique et prises de parole.");
  }

  // LA MÉTÉO ET LE PLAN B
  if (event.city) {
    try {
      const look = await lookupWeather({ data: { city: event.city, day } });
      if (look.kind !== "inconnu") {
        parts.push(
          `${look.kind === "prevision" ? "La météo annoncée" : "Les moyennes de saison"} à ${look.city} : ${look.summary}.`,
        );
        const pluie = (look.rainChance ?? 0) >= 40 || (look.rainMm ?? 0) >= 2;
        const vent = (look.windMax ?? 0) >= 45;
        const froid = (look.tempMax ?? 20) <= 8;
        if (pluie || vent || froid) {
          parts.push(
            "Plan B : prévoyez un repli couvert, décalez le temps fort d'une heure, et confirmez la veille avec le lieu.",
          );
        } else {
          parts.push("Rien dans le ciel ne demande de plan B pour l'instant.");
        }
      }
    } catch {
      /* la météo n'est jamais bloquante */
    }
  }

  // LA TEMPÉRATURE DU PROJET
  const manques = parts.filter((p) => p.includes("manque") || p.includes("Rien n'est encore")).length;
  parts.push(
    manques === 0
      ? "La température est bonne : ce projet tient debout tout seul."
      : manques === 1
        ? "Le projet avance bien, un seul point demande votre attention."
        : "Le projet est encore tiède : prenez les manques un par un, en commençant par les personnes.",
  );

  return { title: event.title, parts };
}
