import type { TimelineMarker } from "@/components/aime/HeroTimeline";

/** Nature d'un élément lisible : le moteur PLAY ne connaît que ces rendus. */
export type PlayableType = "photo" | "video" | "audio" | "musique" | "texte" | "narration";

/** Transition entre deux éléments de la file. */
export type Transition = "coupe" | "fondu" | "pause";

/** Un objet de la ligne de temps, préparé pour la lecture. */
export type PlayableItem = {
  id: string;
  type: PlayableType;
  /** Position temporelle d'origine (ms epoch). */
  timestamp: number;
  /** Durée de lecture en ms. */
  duration: number;
  mediaUrl?: string | undefined;
  thumbnail?: string | undefined;
  title: string;
  subtitle?: string | undefined;
  source?: string | undefined;
  narration?: string | undefined;
  transition: Transition;
  priority: number;
  metadata?: Record<string, unknown> | undefined;
  /** Repère d'origine : la file ne duplique jamais la donnée. */
  marker: TimelineMarker;
};

/** Ce qu'on veut lire : un scénario de lecture, jamais une timeline séparée. */
export type PlayMode =
  | "tout"
  | "photos"
  | "videos"
  | "audio"
  | "musique"
  | "messages"
  | "souvenirs"
  | "evenements"
  | "narration"
  | "film";

/** Sur quelle portion de la ligne de temps. */
export type PlayScope =
  | { kind: "tout" }
  | { kind: "jour"; at: number }
  | { kind: "semaine"; at: number }
  | { kind: "mois"; at: number }
  | { kind: "periode"; from: number; to: number }
  | { kind: "evenement"; projectId: string }
  | { kind: "personne"; personId: string }
  | { kind: "selection"; ids: string[] };

export type PlayRequest = {
  mode: PlayMode;
  scope: PlayScope;
  /** Durée d'une photo (ms). */
  photoMs?: number;
  /** Insère une phrase de contexte entre les éléments. */
  withNarration?: boolean;
};

export const MODE_LABEL: Record<PlayMode, string> = {
  tout: "Tout lire",
  photos: "Photos",
  videos: "Vidéos",
  audio: "Audio",
  musique: "Musique",
  messages: "Messages",
  souvenirs: "Souvenirs",
  evenements: "Événements",
  narration: "Récit",
  film: "Film du jour",
};
