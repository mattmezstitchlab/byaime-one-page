import { createServerFn } from "@tanstack/react-start";

/**
 * La voix du récit : une phrase de la ligne de temps devient de l'audio.
 * Les phrases sont courtes, donc un fichier complet suffit — pas de flux.
 */
export const speakNarration = createServerFn({ method: "POST" })
  .inputValidator((input: { text: string }) => {
    const text = (input?.text ?? "").trim().slice(0, 900);
    if (!text) throw new Error("Rien à lire.");
    return { text };
  })
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("La voix n'est pas configurée.");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-4o-mini-tts",
        input: data.text,
        voice: "alloy",
        response_format: "mp3",
        instructions:
          "Parle en français, d'une voix calme et chaleureuse d'animatrice, sans emphase excessive.",
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      if (res.status === 429) throw new Error("Trop de demandes de voix, réessayez dans un instant.");
      if (res.status === 402) throw new Error("Crédits épuisés : la voix est momentanément coupée.");
      if (res.status === 403) throw new Error("La voix est désactivée pour cet espace.");
      throw new Error(`Voix indisponible (${res.status}) ${detail.slice(0, 120)}`);
    }

    const audio = Buffer.from(await res.arrayBuffer()).toString("base64");
    return { audio };
  });
