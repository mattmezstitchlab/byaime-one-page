import event from "@/assets/visual-event.jpg";
import music from "@/assets/visual-music.jpg";
import scene from "@/assets/visual-scene.jpg";
import service from "@/assets/visual-service.jpg";
import venue from "@/assets/visual-venue.jpg";
import food from "@/assets/visual-food.jpg";
import photo from "@/assets/visual-photo.jpg";
import beaute from "@/assets/visual-beaute.jpg";
import patrimoine from "@/assets/visual-patrimoine.jpg";
import hotel from "@/assets/visual-hotel.jpg";
import people from "@/assets/visual-people.jpg";
import institution from "@/assets/visual-institution.jpg";

/** Image de repli affichée avant (et pendant) le chargement de la vidéo d'univers. */
const MAP: Record<string, string> = {
  evenement: event,
  musique: music,
  culture: scene,
  entreprise: service,
  lieux: venue,
  table: food,
  image: photo,
  style: beaute,
  patrimoine,
  voyage: hotel,
  lien: people,
  solidarite: institution,
};

export function universePoster(slug: string): string {
  return MAP[slug] ?? event;
}
