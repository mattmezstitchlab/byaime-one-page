import faceVideo from "@/assets/aime-face.mp4.asset.json";
import mariage from "@/assets/univers-mariage.mp4.asset.json";
import concert from "@/assets/univers-concert.mp4.asset.json";
import entreprise from "@/assets/univers-entreprise.mp4.asset.json";
import anniversaire from "@/assets/univers-anniversaire.mp4.asset.json";
import culture from "@/assets/univers-culture.mp4.asset.json";
import association from "@/assets/univers-association.mp4.asset.json";
import voyage from "@/assets/univers-voyage.mp4.asset.json";
import rencontre from "@/assets/univers-rencontre.mp4.asset.json";
import naissance from "@/assets/univers-naissance.mp4.asset.json";
import ceremonie from "@/assets/univers-ceremonie.mp4.asset.json";
import patrimoine from "@/assets/univers-patrimoine.mp4.asset.json";

const MAP: Record<string, string> = {
  mariage: mariage.url,
  concert: concert.url,
  entreprise: entreprise.url,
  anniversaire: anniversaire.url,
  evenement: faceVideo.url,
  culture: culture.url,
  association: association.url,
  voyage: voyage.url,
  rencontre: rencontre.url,
  naissance: naissance.url,
  ceremonie: ceremonie.url,
  patrimoine: patrimoine.url,
};

export function universeVideo(slug: string): string {
  return MAP[slug] ?? faceVideo.url;
}
