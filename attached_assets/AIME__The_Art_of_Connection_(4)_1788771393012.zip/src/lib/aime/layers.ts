/**
 * Échelle d'altitude unique du site.
 *
 * Un seul escalier, du contenu au plein écran : aucune page n'invente sa propre
 * valeur. Les classes sont écrites en toutes lettres pour rester compilables.
 *
 *   contenu            —      la page
 *   chrome    z-[20]   capsule latérale, bouton retour, bouton retour bêta
 *   panel     z-[30]   panneaux de page : liste, mosaïque, plateau, compteurs
 *   radio     z-[40]   barre radio
 *   header    z-[45]   en-tête collant
 *   dock      z-[50]   AI · + · ME
 *   menu      z-[60]   menus, bulles, coups d'œil
 *   modal     z-[70]   tiroirs, boîtes de dialogue, superpositions
 *   full      z-[80]   éphémères plein écran, intro du site
 */
export const Z = {
  chrome: "z-[20]",
  panel: "z-[30]",
  radio: "z-[40]",
  header: "z-[45]",
  dock: "z-[50]",
  menu: "z-[60]",
  modal: "z-[70]",
  full: "z-[80]",
} as const;
