/**
 * Le préréglage Mariage : la même page carte, habillée pour un futur marié.
 * Rien de nouveau côté données — seulement des libellés, des rôles et un ordre.
 */
import type { CardTab, CardTabKey } from "@/components/aime/CardTabs";
import type { Card } from "@/lib/aime/types";

export const WEDDING_UNIVERSE = "mariage";

/** Une carte Mariage : un événement posé dans le monde du mariage. */
export function isWeddingCard(card: Pick<Card, "kind" | "universes"> | null | undefined) {
  if (!card) return false;
  return card.kind === "evenement" && card.universes.includes(WEDDING_UNIVERSE);
}

export const WEDDING_TABS: CardTab[] = [
  { key: "jour-j", label: "Le jour J" },
  { key: "prestataires", label: "Les prestataires" },
  { key: "deroule", label: "Le déroulé" },
  { key: "invites", label: "Les invités" },
  { key: "budget", label: "Budget" },
  { key: "musique", label: "Musique" },
  { key: "documents", label: "Documents" },
  { key: "contact", label: "Messages" },
];

export const WEDDING_TAB_KEYS: CardTabKey[] = WEDDING_TABS.map((t) => t.key);

export type WeddingRole = {
  /** Libellé de la place à pourvoir. */
  label: string;
  /** Mots qui servent à reconnaître les cartes candidates. */
  match: string[];
  /** Une phrase pour dire à quoi sert ce rôle. */
  hint: string;
};

/** Les places d'un mariage, dans l'ordre où on les remplit habituellement. */
export const WEDDING_ROLES: WeddingRole[] = [
  {
    label: "Lieu de réception",
    match: ["lieu", "salle", "domaine", "chateau", "reception"],
    hint: "Ce qui fixe la date et le nombre d'invités.",
  },
  {
    label: "Traiteur",
    match: ["traiteur", "restauration", "cuisine", "food"],
    hint: "Le repas, le cocktail, le service.",
  },
  { label: "Photographe", match: ["photo", "photographe"], hint: "Les images qui resteront." },
  { label: "Vidéaste", match: ["video", "videaste", "film"], hint: "Le film du jour." },
  {
    label: "Musique / DJ",
    match: ["dj", "musique", "groupe", "orchestre", "musicien"],
    hint: "La soirée et l'ouverture de bal.",
  },
  {
    label: "Fleuriste",
    match: ["fleur", "fleuriste", "decoration florale"],
    hint: "Bouquet, décor, cérémonie.",
  },
  {
    label: "Décoration",
    match: ["decoration", "scenographie", "deco"],
    hint: "L'ambiance de la salle.",
  },
  {
    label: "Coiffure & maquillage",
    match: ["coiffure", "maquillage", "beaute", "makeup"],
    hint: "Les préparatifs du matin.",
  },
  {
    label: "Pâtisserie",
    match: ["patisserie", "gateau", "wedding cake", "dessert"],
    hint: "La pièce montée.",
  },
  {
    label: "Officiant / cérémonie",
    match: ["officiant", "ceremonie", "celebrant"],
    hint: "Le moment central.",
  },
  {
    label: "Transport",
    match: ["transport", "voiture", "navette", "limousine"],
    hint: "Les trajets des mariés et des invités.",
  },
  {
    label: "Hébergement",
    match: ["hotel", "hebergement", "gite", "chambre"],
    hint: "Pour les invités venus de loin.",
  },
];

export type WeddingStep = {
  label: string;
  /** Heure indicative du jour J, en heures depuis minuit. */
  hour: number;
};

/** Le déroulé type d'une journée : un point de départ, pas une règle. */
export const WEDDING_STEPS: WeddingStep[] = [
  { label: "Préparatifs", hour: 9 },
  { label: "Cérémonie civile", hour: 11 },
  { label: "Cérémonie", hour: 15 },
  { label: "Photos de groupe", hour: 16.5 },
  { label: "Cocktail", hour: 17.5 },
  { label: "Repas", hour: 20 },
  { label: "Ouverture de bal", hour: 23 },
  { label: "Soirée", hour: 23.5 },
];

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** Les cartes candidates pour une place : catégorie, mots-clés, savoir-faire. */
export function matchesRole(card: Card, role: WeddingRole) {
  const haystack = normalize(
    [card.category_slug, card.name, card.headline, ...card.tags, ...card.skills].join(" "),
  );
  return role.match.some((m) => haystack.includes(normalize(m)));
}

/** Date du jour J en texte court, quand elle est connue. */
export function formatWeddingDate(iso: string | null | undefined) {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** Jours restants avant le jour J (négatif si c'est passé). */
export function daysUntil(iso: string | null | undefined) {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return Math.ceil((d.getTime() - Date.now()) / 86_400_000);
}
