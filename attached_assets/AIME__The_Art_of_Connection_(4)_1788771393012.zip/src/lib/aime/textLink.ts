/**
 * Le premier lien d'un texte libre.
 *
 * Quand une adresse est collée dans la phrase d'une publication, le fil peut
 * la montrer (miniature vidéo, lecteur, carte de lien) au lieu de la laisser
 * en texte brut. Rien n'est inventé : seules les adresses http(s) valides sont
 * reconnues, la ponctuation de fin de phrase n'en fait jamais partie, et le
 * texte reste affiché tel quel — l'adresse d'origine est conservée.
 *
 * Ce module est volontairement feuille et pur (aucun import) : il est testé
 * seul, sans client ni réseau, comme les autres briques du monde AIME.
 */

/** Une adresse http(s) dans la phrase ; s'arrête aux espaces et aux guillemets. */
const LINK_RE = /https?:\/\/[^\s<>"«»]+/i;

/**
 * La ponctuation qui termine une phrase ne fait pas partie de l'adresse
 * (« regarde https://youtu.be/abc. » → l'adresse sans le point final).
 * Une parenthèse fermante orpheline — adresse placée entre parenthèses —
 * n'appartient pas à l'adresse non plus ; une parenthèse équilibrée
 * (chemins Wikipédia) est conservée.
 */
function trimLinkTail(raw: string): string {
  let out = raw.replace(/[.,;:!?…'’"\]]+$/, "");
  const opens = (s: string) => (s.match(/\(/g)?.length ?? 0);
  const closes = (s: string) => (s.match(/\)/g)?.length ?? 0);
  while (out.endsWith(")") && closes(out) > opens(out)) {
    out = out.slice(0, -1);
  }
  return out;
}

/**
 * La première adresse du texte, nettoyée de sa ponctuation de fin,
 * ou null quand il n'y en a pas (publication texte : rien ne change).
 */
export function firstLinkIn(text: string | null | undefined): string | null {
  if (!text) return null;
  const m = LINK_RE.exec(text);
  if (!m) return null;
  const found = trimLinkTail(m[0]);
  try {
    const u = new URL(found);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return found;
  } catch {
    return null;
  }
}
