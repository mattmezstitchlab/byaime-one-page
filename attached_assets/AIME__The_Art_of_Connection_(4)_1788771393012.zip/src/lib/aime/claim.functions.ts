import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Domaine « nu » d'une URL ou d'un e-mail (sans www). */
function domainOf(value: string | null | undefined): string | null {
  if (!value) return null;
  const raw = value.trim().toLowerCase();
  const host = raw.includes("@")
    ? raw.split("@")[1]
    : raw.replace(/^https?:\/\//, "").split("/")[0];
  if (!host) return null;
  return host.replace(/^www\./, "");
}

async function sha256(text: string) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export type ClaimRequestResult = {
  status: "code_sent" | "manual";
  claimId: string;
  message: string;
};

/** Étape 1 — demande de revendication : code par e-mail si le domaine correspond au site officiel. */
export const requestCardClaim = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: unknown) =>
    z
      .object({
        cardId: z.string().uuid(),
        email: z.string().email().max(160),
        note: z.string().max(600).optional(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }): Promise<ClaimRequestResult> => {
    const { supabase, userId } = context;

    const { data: card, error } = await supabase
      .from("cards")
      .select("id, name, owner_id, source_url")
      .eq("id", data.cardId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!card) throw new Error("Carte introuvable.");
    if (card.owner_id) throw new Error("Cette carte a déjà un propriétaire.");

    const { data: contact } = await supabase
      .from("card_contacts")
      .select("website")
      .eq("card_id", data.cardId)
      .maybeSingle();

    const official = domainOf(contact?.website ?? card.source_url);
    const claimed = domainOf(data.email);
    const matches = !!official && !!claimed && official === claimed;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (!matches) {
      const { data: row, error: insErr } = await supabaseAdmin
        .from("card_claims")
        .insert({
          card_id: data.cardId,
          user_id: userId,
          email: data.email,
          status: "manual",
          note: data.note ?? null,
        })
        .select("id")
        .single();
      if (insErr) throw new Error(insErr.message);
      return {
        status: "manual",
        claimId: row.id,
        message: official
          ? `Cette adresse n'appartient pas au domaine officiel (${official}). Votre demande part en vérification manuelle.`
          : "Cette fiche n'indique pas de site officiel : votre demande part en vérification manuelle.",
      };
    }

    const code = String(Math.floor(100000 + Math.random() * 900000));
    const codeHash = await sha256(`${data.cardId}:${code}`);

    const { data: row, error: insErr } = await supabaseAdmin
      .from("card_claims")
      .insert({
        card_id: data.cardId,
        user_id: userId,
        email: data.email,
        code_hash: codeHash,
        expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
        status: "pending",
        note: data.note ?? null,
      })
      .select("id")
      .single();
    if (insErr) throw new Error(insErr.message);

    const sent = await sendClaimCode(data.email, card.name, code);
    if (!sent) {
      await supabaseAdmin
        .from("card_claims")
        .update({ status: "manual", note: "Envoi d'e-mail indisponible" })
        .eq("id", row.id);
      return {
        status: "manual",
        claimId: row.id,
        message:
          "L'envoi d'e-mail n'est pas encore actif sur ce site : votre demande part en vérification manuelle.",
      };
    }

    return {
      status: "code_sent",
      claimId: row.id,
      message: `Un code à 6 chiffres vient d'être envoyé à ${data.email}. Il expire dans 15 minutes.`,
    };
  });

/** Étape 2 — vérification du code et attribution de la carte. */
export const verifyCardClaim = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: unknown) =>
    z.object({ claimId: z.string().uuid(), code: z.string().length(6) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: claim, error } = await supabaseAdmin
      .from("card_claims")
      .select("id, card_id, user_id, code_hash, expires_at, attempts, status")
      .eq("id", data.claimId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!claim || claim.user_id !== userId) throw new Error("Demande introuvable.");
    if (claim.status !== "pending") throw new Error("Cette demande n'est plus en attente.");
    if (claim.attempts >= 5) throw new Error("Trop de tentatives. Refaites une demande.");
    if (!claim.expires_at || new Date(claim.expires_at) < new Date())
      throw new Error("Le code a expiré. Refaites une demande.");

    const hash = await sha256(`${claim.card_id}:${data.code}`);
    if (hash !== claim.code_hash) {
      await supabaseAdmin
        .from("card_claims")
        .update({ attempts: claim.attempts + 1 })
        .eq("id", claim.id);
      throw new Error("Code incorrect.");
    }

    const { error: upErr } = await supabaseAdmin
      .from("cards")
      .update({ owner_id: userId, claim_status: "claimed" })
      .eq("id", claim.card_id)
      .is("owner_id", null);
    if (upErr) throw new Error(upErr.message);

    await supabaseAdmin
      .from("card_claims")
      .update({ status: "verified", code_hash: null })
      .eq("id", claim.id);

    return { ok: true, cardId: claim.card_id };
  });

/** Envoi du code de revendication via la messagerie du projet. */
async function sendClaimCode(to: string, cardName: string, code: string): Promise<boolean> {
  try {
    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    const result = await sendTemplateEmail("card-claim-code", to, {
      templateData: { cardName, code },
      idempotencyKey: `card-claim-code-${code}`,
    });
    return result.sent;
  } catch (err) {
    console.error("Claim email error", err);
    return false;
  }
}
