import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { RADIO_KINDS } from "@/lib/aime/musicbox";
import type { Database } from "@/integrations/supabase/types";


export type Track = Database["public"]["Tables"]["musicbox_entries"]["Row"];

/** Un morceau n'est écoutable que s'il porte un extrait ou un fichier. */
export function listenUrl(t: Track): string | null {
  return t.preview_url ?? t.source_url ?? null;
}

export function trackArtist(t: Track): string | null {
  if (t.artist) return t.artist;
  const dash = t.title.split(" — ")[1];
  return dash ?? null;
}

export function trackTitle(t: Track): string {
  return t.title.split(" — ")[0] ?? t.title;
}

/** Ma playlist : les morceaux placés sur ma ligne de temps. */
export function playlistQuery(cardId?: string | null, eventId?: string | null) {
  return queryOptions({
    queryKey: ["playlist", cardId ?? null, eventId ?? null],
    enabled: !!(cardId || eventId),
    queryFn: async (): Promise<Track[]> => {
      let q = supabase.from("musicbox_entries").select("*").eq("kind", "musique");
      if (eventId) q = q.eq("event_id", eventId);
      else q = q.eq("card_id", cardId!);
      const { data, error } = await q.order("day", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

/**
 * Tout ce qui passe à l'antenne : les morceaux, mais aussi les annonces et
 * les vocaux déposés depuis la capsule radio. Les vocaux vivent dans un
 * espace privé : on demande une adresse d'écoute temporaire avant de les
 * mettre au programme.
 */
export const publicTracksQuery = queryOptions({
  queryKey: ["public-tracks"],
  queryFn: async (): Promise<Track[]> => {
    const { data, error } = await supabase
      .from("musicbox_entries")
      .select("*")
      .in("kind", [...RADIO_KINDS])
      .eq("visibility", "public")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw error;
    const rows = data ?? [];

    const paths = rows
      .filter((t) => !listenUrl(t) && t.audio_path)
      .map((t) => t.audio_path as string);
    const signed = new Map<string, string>();
    if (paths.length > 0) {
      const { data: urls } = await supabase.storage
        .from("musicbox")
        .createSignedUrls(paths, 60 * 60);
      for (const u of urls ?? []) {
        if (u.path && u.signedUrl) signed.set(u.path, u.signedUrl);
      }
    }

    return rows
      .map((t) =>
        !listenUrl(t) && t.audio_path && signed.has(t.audio_path)
          ? { ...t, preview_url: signed.get(t.audio_path)! }
          : t,
      )
      .filter((t) => !!listenUrl(t));
  },
  staleTime: 5 * 60_000,
});


/** Mélange stable le temps d'une écoute. */
export function shuffle<T>(list: T[]): T[] {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}
