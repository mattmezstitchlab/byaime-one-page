import { describe, test } from "node:test";
import assert from "node:assert/strict";
import {
  guessKind,
  hostOfUrl,
  isPdfUrl,
  youtubeEmbed,
  youtubeId,
  youtubeThumb,
} from "../mediaKind";
import { firstLinkIn } from "../textLink";

/* ------------------------------------------------------------------ */
/* Aperçu d'une adresse — fil et Compositeur parlent le même moteur    */
/*  - classification : web, YouTube, image, vidéo, audio, inconnu      */
/*  - sans adresse : pas d'aperçu                                      */
/*  - le texte saisi n'est jamais modifié par la prévisualisation      */
/* ------------------------------------------------------------------ */

describe("guessKind — la classification unique (fil = compositeur)", () => {
  test("URL web classique → carte lien", () => {
    assert.equal(guessKind("https://www.lemonde.fr/article-du-jour"), "lien");
    assert.equal(guessKind("https://exemple.fr/guide?ref=aime"), "lien");
  });

  test("YouTube : watch, courte, shorts, embed → « youtube »", () => {
    assert.equal(guessKind("https://www.youtube.com/watch?v=AbCdEf12345"), "youtube");
    assert.equal(guessKind("https://youtu.be/AbCdEf12345"), "youtube");
    assert.equal(guessKind("https://www.youtube.com/shorts/AbCdEf12345"), "youtube");
    assert.equal(guessKind("https://www.youtube.com/embed/AbCdEf12345"), "youtube");
  });

  test("image directe → « photo » (params de requête tolérés)", () => {
    assert.equal(guessKind("https://images.exemple.fr/jardin.webp"), "photo");
    assert.equal(guessKind("https://images.exemple.fr/copie.JPG?w=800"), "photo");
  });

  test("vidéo directe → lecteur « video »", () => {
    assert.equal(guessKind("https://media.exemple.fr/film.mp4"), "video");
    assert.equal(guessKind("https://media.exemple.fr/clip.webm"), "video");
  });

  test("audio direct → lecteur « audio »", () => {
    assert.equal(guessKind("https://media.exemple.fr/chanson.mp3"), "audio");
    assert.equal(guessKind("https://media.exemple.fr/espiegle.flac"), "audio");
  });

  test("PDF direct → carte document", () => {
    assert.equal(guessKind("https://docs.exemple.fr/contrat.pdf"), "doc");
    assert.equal(guessKind("https://docs.exemple.fr/devis.PDF?download=1"), "doc");
  });

  test("URL inconnue ou invalide → repli « lien », jamais de casse", () => {
    assert.equal(guessKind("https://exemple.fr/ressource-bizarre"), "lien");
    assert.equal(guessKind("pas-une-url-du-tout"), "lien");
    assert.equal(guessKind(""), "lien");
  });
});

describe("YouTube — capacités existantes réutilisées", () => {
  test("identifiant, miniature et fenêtre dérivent de la même adresse", () => {
    const url = "https://youtu.be/AbCdEf12345";
    assert.equal(youtubeId(url), "AbCdEf12345");
    assert.equal(youtubeThumb(url), "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg");
    assert.equal(youtubeEmbed(url), "https://www.youtube.com/embed/AbCdEf12345");
  });

  test("pas de YouTube → pas de fenêtre (le fil montre alors la carte lien)", () => {
    assert.equal(youtubeEmbed("https://vimeo.com/12345"), null);
    assert.equal(youtubeThumb("https://exemple.fr/video"), null);
  });
});

describe("youtubeThumb — l'aperçu léger du Compositeur", () => {
  test("URL YouTube classique → miniature construite sans réseau", () => {
    assert.equal(
      youtubeThumb("https://www.youtube.com/watch?v=AbCdEf12345"),
      "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg",
    );
  });

  test("URL youtu.be → miniature", () => {
    assert.equal(
      youtubeThumb("https://youtu.be/AbCdEf12345"),
      "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg",
    );
  });

  test("URL YouTube avec paramètres en pagaille → même identifiant", () => {
    assert.equal(
      youtubeThumb("https://www.youtube.com/watch?v=AbCdEf12345&t=42&list=PLxyz"),
      "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg",
    );
  });

  test("shorts et embed donnent aussi leur miniature", () => {
    assert.equal(
      youtubeThumb("https://www.youtube.com/shorts/AbCdEf12345"),
      "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg",
    );
    assert.equal(
      youtubeThumb("https://www.youtube.com/embed/AbCdEf12345"),
      "https://img.youtube.com/vi/AbCdEf12345/hqdefault.jpg",
    );
  });

  test("URL non YouTube → null : le Compositeur garde les autres branches", () => {
    assert.equal(youtubeThumb("https://dailymotion.com/video/x8abc"), null);
    assert.equal(youtubeThumb("https://exemple.fr/clip.mp4"), null);
  });

  test("URL invalide → null, jamais de casse", () => {
    assert.equal(youtubeThumb("pas-une-adresse"), null);
    assert.equal(youtubeThumb(""), null);
  });

  test("URL YouTube atypique sans identifiant → null : repli vers l'existant", () => {
    /* Chaîne/accueil : aucune vidéo identifiable → pas de miniature, le
       composant retombe sur sa fenêtre habituelle, rien n'est cassé. */
    assert.equal(youtubeThumb("https://www.youtube.com/@unechaine"), null);
    assert.equal(youtubeThumb("https://www.youtube.com/feed"), null);
  });

  test("absence d'URL dans le texte → rien à miniaturer", () => {
    assert.equal(firstLinkIn("Publications texte : rien ne change."), null);
  });
});

describe("helpers de lien", () => {
  test("hostOfUrl renvoie le domaine sans www", () => {
    assert.equal(hostOfUrl("https://www.aime.fr/page"), "aime.fr");
    assert.equal(hostOfUrl("https://blog.exemple.com/article"), "blog.exemple.com");
  });

  test("isPdfUrl reconnaît un PDF même avec query/hash", () => {
    assert.equal(isPdfUrl("https://x.fr/file.pdf"), true);
    assert.equal(isPdfUrl("https://x.fr/file.pdf?dl=1#page=2"), true);
    assert.equal(isPdfUrl("https://x.fr/file.mp4"), false);
  });
});

describe("Aperçu dans le texte — la règle du compositeur = celle du fil", () => {
  test("publication sans URL : aucun aperçu (null)", () => {
    assert.equal(firstLinkIn("Ce samedi, tout est prêt pour le brunch."), null);
  });

  test("la règle complète : adresse YouTube dans la phrase → « youtube »", () => {
    const body = "Notre film est enfin là : https://youtu.be/AbCdEf12345 merci à tous !";
    const url = firstLinkIn(body);
    assert.ok(url);
    assert.equal(guessKind(url), "youtube");
  });

  test("le texte saisi n'est jamais modifié par la prévisualisation", () => {
    const body = "Regarde https://youtu.be/AbCdEf12345. C'est le grand jour !";
    const url = firstLinkIn(body);
    /* l'aperçu utilise une extraction ; le corps reste intact, caractère pour caractère */
    assert.equal(body, "Regarde https://youtu.be/AbCdEf12345. C'est le grand jour !");
    assert.ok(body.includes(url!));
    assert.equal(url, "https://youtu.be/AbCdEf12345");
  });
});
