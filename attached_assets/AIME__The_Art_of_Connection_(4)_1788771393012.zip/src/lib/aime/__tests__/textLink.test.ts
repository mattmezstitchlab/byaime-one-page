import { describe, test } from "node:test";
import assert from "node:assert/strict";
import { firstLinkIn } from "../textLink";

/* ------------------------------------------------------------------ */
/* Le premier lien d'un texte libre — finition du fil                  */
/*  - reconnaître les adresses collées dans la phrase                  */
/*  - ne jamais avaler la ponctuation qui suit                         */
/*  - texte sans adresse : rien ne change (null)                       */
/* ------------------------------------------------------------------ */

describe("firstLinkIn — adresses reconnues", () => {
  test("une adresse YouTube en pleine phrase est extraite", () => {
    assert.equal(
      firstLinkIn("Notre teaser est en ligne https://www.youtube.com/watch?v=AbCdEf12345 merci !"),
      "https://www.youtube.com/watch?v=AbCdEf12345",
    );
  });

  test("les formes courtes et shorts passent aussi", () => {
    assert.equal(firstLinkIn("https://youtu.be/AbCdEf12345"), "https://youtu.be/AbCdEf12345");
    assert.equal(
      firstLinkIn("vu ici : https://www.youtube.com/shorts/AbCdEf12345"),
      "https://www.youtube.com/shorts/AbCdEf12345",
    );
  });

  test("http simple est reconnu, en début comme en fin de phrase", () => {
    assert.equal(firstLinkIn("http://exemple.fr/article c'est parti"), "http://exemple.fr/article");
    assert.equal(firstLinkIn("le site : http://exemple.fr"), "http://exemple.fr");
  });

  test("la première adresse gagne quand il y en a plusieurs", () => {
    assert.equal(
      firstLinkIn("d'abord https://un.fr puis https://deux.fr/photo.jpg"),
      "https://un.fr",
    );
  });

  test("une image directe est reconnue comme telle", () => {
    assert.equal(
      firstLinkIn("la photo https://images.exemple.fr/jardin.webp !"),
      "https://images.exemple.fr/jardin.webp",
    );
  });
});

describe("firstLinkIn — ponctuation de fin jamais avalée", () => {
  test("point, virgule, point d'exclamation, point-virgule", () => {
    assert.equal(firstLinkIn("https://un.fr."), "https://un.fr");
    assert.equal(firstLinkIn("https://un.fr/page, ensuite"), "https://un.fr/page");
    assert.equal(firstLinkIn("https://un.fr!"), "https://un.fr");
    assert.equal(firstLinkIn("https://un.fr;"), "https://un.fr");
    assert.equal(firstLinkIn("https://un.fr…"), "https://un.fr");
  });

  test("guillemets et chevrons ne sont pas avalés", () => {
    assert.equal(firstLinkIn("\"https://un.fr\""), "https://un.fr");
    assert.equal(firstLinkIn("« https://un.fr »"), "https://un.fr");
  });

  test("parenthèse fermante orpheline retirée, parenthèse équilibrée gardée", () => {
    assert.equal(
      firstLinkIn("regarde (https://un.fr/clip) merci"),
      "https://un.fr/clip",
    );
    assert.equal(
      firstLinkIn("https://fr.wikipedia.org/wiki/Paon_(oiseau)"),
      "https://fr.wikipedia.org/wiki/Paon_(oiseau)",
    );
  });

  test("une adresse seule collée à « : » reste entière", () => {
    assert.equal(firstLinkIn("lien:https://un.fr/x"), "https://un.fr/x");
  });
});

describe("firstLinkIn — pas d'adresse : aucun changement", () => {
  test("texte vide, null, undefined", () => {
    assert.equal(firstLinkIn(""), null);
    assert.equal(firstLinkIn(null), null);
    assert.equal(firstLinkIn(undefined), null);
  });

  test("texte sans adresse http(s)", () => {
    assert.equal(firstLinkIn("Un beau mariage ce week-end !"), null);
    assert.equal(firstLinkIn("écris-moi sur contact@exemple.fr"), null);
    assert.equal(firstLinkIn("www.exemple.fr sans protocole ne compte pas"), null);
  });

  test("« https:// » tronqué ne produit rien", () => {
    assert.equal(firstLinkIn("collé trop vite : https://"), null);
  });
});
