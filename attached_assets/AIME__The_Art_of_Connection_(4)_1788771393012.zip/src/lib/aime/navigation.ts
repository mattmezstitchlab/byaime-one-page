import type { LucideIcon } from "lucide-react";

/** Une entrée de navigation : soit un lien, soit une action locale. */
export type NavItem = {
  to: string;
  label: string;
  /** Clé i18n éventuelle, sinon le libellé est utilisé tel quel. */
  key?: string;
  icon: LucideIcon;
  exact?: boolean;
};

/**
 * Une seule table de navigation pour tout le site.
 *
 * - HEADER_NAV : les deux portes du header.
 * - SYSTEM_MENU : le menu du logo AIME (système et aide).
 * - FOOTER_LEGAL : uniquement les mentions réglementaires.
 *
 * L'accueil se rejoint par le logo, le compte par « Mon espace ».
 * Aucune route ancienne n'apparaît ici.
 */

/** Le menu du logo : système, aide, démonstration. Jamais des fonctions métier. */
export type SystemMenuItem =
  { kind: "link"; to: string; label: string } | { kind: "feedback"; label: string };

export const SYSTEM_MENU: SystemMenuItem[] = [
  { kind: "link", to: "/demo/mariage", label: "Démo : un mariage" },
  { kind: "feedback", label: "Aide & retours" },
];

/**
 * Découvrir : les pages publiques qui existent réellement mais qu'aucune porte
 * n'ouvrait. Elles ne demandent pas de compte.
 */
export const DISCOVER_MENU: { to: string; label: string }[] = [
  { to: "/le-monde-aime", label: "Le Monde AIME — entraide" },
  { to: "/guides", label: "Guides par métier et par ville" },
  { to: "/organiser-un-mariage", label: "Organiser un mariage" },
];

/** Pied de page : mentions réglementaires seulement. */
export const FOOTER_LEGAL = [
  { doc: "mentions-legales", key: "footer.legal" },
  { doc: "confidentialite", key: "footer.privacy" },
  { doc: "conditions-utilisation", key: "footer.cgu" },
  { doc: "conditions-vente", key: "footer.cgv" },
  { doc: "cookies", key: "footer.cookies" },
  { doc: "accessibilite", key: "footer.a11y" },
  { doc: "mediation", key: "footer.mediation" },
  { doc: "contact", key: "footer.contact" },
] as const;
