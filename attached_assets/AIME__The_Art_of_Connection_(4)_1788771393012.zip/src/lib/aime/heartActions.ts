/**
 * Le cœur des champs de saisie n'est plus le même partout : son menu dépend
 * de la page où il est posé. Même grammaire, mais des entrées qui servent.
 */
import {
  CalendarRange,
  CalendarPlus,
  FileText,
  FolderPlus,
  Heart,
  History,
  Mic,
  Paperclip,
  Radio,
  Send,
  Compass,
} from "lucide-react";

export type HeartPage =
  | "accueil"
  | "monde"
  | "rencontres"
  | "messages"
  | "projets"
  | "carte"
  | "tableau"
  | "ma-page"
  | "reseau"
  | "saisons"
  | "bureau"
  | "autre";

export type HeartContext = {
  page: HeartPage;
  universeSlug?: string | null;
  city?: string | null;
  /** Carte affichée par la page (page carte). */
  cardId?: string | null;
  /** Projet affiché par la page. */
  eventId?: string | null;
};

export type HeartActionKey =
  | "import"
  | "voix"
  | "cadre"
  | "public"
  | "cartes"
  | "reprendre"
  | "date"
  | "devis"
  | "projet"
  | "destinataire";

export type HeartAction = {
  key: HeartActionKey;
  label: string;
  hint: string;
  icon: typeof Heart;
};

const A: Record<HeartActionKey, HeartAction> = {
  import: {
    key: "import",
    label: "Importer un document",
    hint: "Devis, brief, e-mail, inspiration",
    icon: Paperclip,
  },
  voix: { key: "voix", label: "Dicter à la voix", hint: "Racontez, on écrit", icon: Mic },
  cadre: {
    key: "cadre",
    label: "Préciser le cadre",
    hint: "Date, ville, budget, personnes",
    icon: CalendarRange,
  },
  public: {
    key: "public",
    label: "Déposer en public",
    hint: "Sur le Réseau, visible de tous",
    icon: Radio,
  },
  cartes: {
    key: "cartes",
    label: "Embarquer des cartes",
    hint: "Épingler des personnes ou lieux",
    icon: Compass,
  },
  reprendre: {
    key: "reprendre",
    label: "Reprendre une intention",
    hint: "Vos intentions et compositions",
    icon: History,
  },
  date: {
    key: "date",
    label: "Proposer une date",
    hint: "À cette carte, avec votre message",
    icon: CalendarPlus,
  },
  devis: {
    key: "devis",
    label: "Demander un devis",
    hint: "Ouvre la demande chiffrée",
    icon: FileText,
  },
  projet: {
    key: "projet",
    label: "Rattacher à un projet",
    hint: "Garder cette intention au bon endroit",
    icon: FolderPlus,
  },
  destinataire: {
    key: "destinataire",
    label: "Écrire à quelqu'un",
    hint: "Choisir la personne et envoyer",
    icon: Send,
  },
};

/** Toujours présentes : la base commune du cœur de saisie. */
const BASE: HeartActionKey[] = ["voix", "import", "cadre", "public"];

export function actionsForContext(ctx: HeartContext | undefined): HeartAction[] {
  const page = ctx?.page ?? "autre";
  const keys: HeartActionKey[] = [...BASE];

  // Sur l'accueil, le hero porte déjà les cartes suggérées et la feuille de route :
  // le cœur reste sur la base (dicter, importer, cadre, public).
  if (page === "monde" || page === "rencontres" || page === "tableau") {
    keys.push("cartes", "reprendre");
  }
  if (page === "carte" && ctx?.cardId) {
    keys.push("date", "devis");
  }
  if (page === "projets") {
    keys.push("projet", "reprendre");
  }
  if (page === "messages") {
    keys.push("destinataire");
  }
  if (page === "ma-page") {
    keys.push("reprendre");
  }
  if (page === "reseau" || page === "saisons") {
    keys.push("cartes", "date", "reprendre");
  }
  if (page === "bureau") {
    keys.push("devis", "projet", "reprendre");
  }
  if (page === "autre") {
    keys.push("cartes", "reprendre");
  }

  return keys.map((k) => A[k]);
}
