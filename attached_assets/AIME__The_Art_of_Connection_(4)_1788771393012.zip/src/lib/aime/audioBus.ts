/**
 * Bus audio unique d'AIME.
 * Un seul son à la fois : quand un lecteur prend l'antenne, les autres se taisent.
 */

type Owner = "radio" | "play" | "playlist" | "musicbox" | "preview" | "tv";

type Claimant = { owner: Owner; stop: () => void };

let current: Claimant | null = null;

/** Prend l'antenne pour ce lecteur : tous les autres sont coupés. */
export function claimAudio(owner: Owner, stop: () => void) {
  if (current && current.owner !== owner) current.stop();
  current = { owner, stop };
}

/** Rend l'antenne (fin de lecture ou démontage). */
export function releaseAudio(owner: Owner) {
  if (current?.owner === owner) current = null;
}

/** Coupe tout son en cours, quel que soit le lecteur. */
export function stopAllAudio() {
  current?.stop();
  current = null;
}

/**
 * Branche un élément <audio>/<video> sur le bus : il prend l'antenne
 * quand il démarre et la rend quand il s'arrête.
 */
export function bindAudioElement(
  owner: Owner,
  el: HTMLMediaElement | null,
): () => void {
  if (!el) return () => {};
  const onPlay = () => claimAudio(owner, () => el.pause());
  const onStop = () => releaseAudio(owner);
  el.addEventListener("play", onPlay);
  el.addEventListener("pause", onStop);
  el.addEventListener("ended", onStop);
  return () => {
    el.removeEventListener("play", onPlay);
    el.removeEventListener("pause", onStop);
    el.removeEventListener("ended", onStop);
    onStop();
  };
}
