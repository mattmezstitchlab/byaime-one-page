/**
 * Le noyau pur du moteur média : classer une adresse et reconnaître YouTube.
 *
 * Module feuille (aucun import) extrait de `media.ts`, qui le ré-exporte :
 * aucun consommateur ne change de chemin d'import. Il est testé seul, sans
 * client ni réseau — c'est la logique à laquelle le fil et le Compositeur se
 * réfèrent pour montrer la même représentation d'une adresse.
 */

export type MediaKind = "photo" | "video" | "youtube" | "audio" | "doc" | "lien";

export const MEDIA_KINDS: { key: MediaKind; label: string }[] = [
  { key: "photo", label: "Photo" },
  { key: "video", label: "Vidéo" },
  { key: "youtube", label: "YouTube" },
  { key: "audio", label: "Audio" },
  { key: "doc", label: "Document" },
  { key: "lien", label: "Lien" },
];

/** L'identifiant d'une vidéo YouTube dans une adresse collée. */
export function youtubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.slice(1) || null;
    if (!u.hostname.includes("youtube.com")) return null;
    if (u.pathname.startsWith("/embed/")) return u.pathname.slice(7) || null;
    if (u.pathname.startsWith("/shorts/")) return u.pathname.slice(8) || null;
    return u.searchParams.get("v");
  } catch {
    return null;
  }
}

export function youtubeThumb(url: string): string | null {
  const id = youtubeId(url);
  return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : null;
}

export function youtubeEmbed(url: string): string | null {
  const id = youtubeId(url);
  return id ? `https://www.youtube.com/embed/${id}` : null;
}

/** Le domaine lisible d'une adresse (sans www). */
export function hostOfUrl(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, "") || null;
  } catch {
    return null;
  }
}

/** Vrai si l'adresse ressemble à un PDF. */
export function isPdfUrl(url: string): boolean {
  const clean = (url.split("#")[0] ?? url).split("?")[0] ?? url;
  return /\.pdf$/i.test(clean);
}

/** Devine le type d'un média à partir de son adresse. */
export function guessKind(url: string): MediaKind {
  if (youtubeId(url)) return "youtube";
  const clean = url.split("?")[0] ?? url;
  if (/\.(png|jpe?g|gif|webp|avif|svg)$/i.test(clean)) return "photo";
  if (/\.(mp4|webm|mov|m4v)$/i.test(clean)) return "video";
  if (/\.(mp3|m4a|wav|ogg|flac)$/i.test(clean)) return "audio";
  if (isPdfUrl(clean)) return "doc";
  return "lien";
}
