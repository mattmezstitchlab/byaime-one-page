import { supabase } from "@/integrations/supabase/client";
import type { Card } from "@/lib/aime/types";
import type { FeedItem, Post } from "@/lib/aime/feed";

export type SearchResults = {
  cards: Card[];
  posts: FeedItem[];
  events: { id: string; title: string; city: string | null; starts_at: string }[];
};

export function resultCount(results: SearchResults | undefined | null) {
  if (!results) return 0;
  return results.cards.length + results.posts.length + results.events.length;
}

const empty: SearchResults = { cards: [], posts: [], events: [] };

function escape(term: string) {
  return term.replace(/[%,()]/g, " ").trim();
}

const RECENT_KEY = "aime:recherches";

/** Les dernières recherches, gardées seulement sur cet appareil. */
export function recentSearches(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(RECENT_KEY);
    const list: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list.filter((v): v is string => typeof v === "string") : [];
  } catch {
    return [];
  }
}

/** Se souvenir d'une recherche (huit au maximum, la plus récente en tête). */
export function rememberSearch(term: string) {
  if (typeof window === "undefined") return;
  const clean = term.trim();
  if (clean.length < 2) return;
  const next = [clean, ...recentSearches().filter((v) => v !== clean)].slice(0, 8);
  try {
    window.localStorage.setItem(RECENT_KEY, JSON.stringify(next));
  } catch {
    /* stockage indisponible : on n'insiste pas */
  }
}

/** Une seule recherche : personnes et lieux, moments, projets. */
export function searchQuery(raw: string) {
  const term = escape(raw);
  return {
    queryKey: ["recherche", term],
    enabled: term.length >= 2,
    queryFn: async (): Promise<SearchResults> => {
      const like = `%${term}%`;
      const [cardsRes, postsRes, eventsRes] = await Promise.all([
        supabase
          .from("cards")
          .select("*")
          .or(`name.ilike.${like},headline.ilike.${like},city.ilike.${like}`)
          .eq("published", true)
          .limit(12),
        supabase
          .from("posts")
          .select("*")
          .eq("visibility", "public")
          .ilike("body", like)
          .order("created_at", { ascending: false })
          .limit(12),
        supabase
          .from("events")
          .select("id,title,city,starts_at")
          .or(`title.ilike.${like},city.ilike.${like}`)
          .order("starts_at", { ascending: false })
          .limit(8),
      ]);

      const posts = (postsRes.data ?? []) as Post[];
      const ids = [...new Set(posts.map((p) => p.card_id))];
      let byId = new Map<string, Card>();
      if (ids.length) {
        const { data } = await supabase.from("cards").select("*").in("id", ids);
        byId = new Map((data ?? []).map((c) => [c.id, c as Card]));
      }

      return {
        ...empty,
        cards: (cardsRes.data ?? []) as Card[],
        posts: posts.map((p) => ({ ...p, card: byId.get(p.card_id) ?? null })),
        events: eventsRes.data ?? [],
      };
    },
  };
}
