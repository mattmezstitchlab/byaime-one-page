import { createServerFn } from "@tanstack/react-start";

/**
 * Météo d'une date et d'un lieu, sans clé : Open-Meteo (prévision à 16 jours,
 * puis moyennes saisonnières au-delà). Sert à préparer un plan B, jamais à décider seul.
 */
export type WeatherLook = {
  city: string;
  day: string;
  /** "prevision" quand la date est dans la fenêtre fiable, "saison" au-delà. */
  kind: "prevision" | "saison" | "inconnu";
  tempMin: number | null;
  tempMax: number | null;
  rainMm: number | null;
  windMax: number | null;
  /** Probabilité de pluie en %, quand elle existe. */
  rainChance: number | null;
  summary: string;
};

type GeoHit = { latitude: number; longitude: number; name: string };

async function geocode(city: string): Promise<GeoHit | null> {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
    city,
  )}&count=1&language=fr&format=json`;
  const res = await fetch(url);
  if (!res.ok) return null;
  const json = (await res.json()) as { results?: GeoHit[] };
  return json.results?.[0] ?? null;
}

function num(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

export const lookupWeather = createServerFn({ method: "POST" })
  .validator((input: { city: string; day: string }) => {
    if (!input.city?.trim()) throw new Error("Ville manquante.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(input.day)) throw new Error("Date invalide.");
    return { city: input.city.trim(), day: input.day };
  })
  .handler(async ({ data }): Promise<WeatherLook> => {
    const base: WeatherLook = {
      city: data.city,
      day: data.day,
      kind: "inconnu",
      tempMin: null,
      tempMax: null,
      rainMm: null,
      windMax: null,
      rainChance: null,
      summary: "Météo indisponible pour ce lieu.",
    };

    const hit = await geocode(data.city);
    if (!hit) return base;

    const daysAhead = Math.round(
      (new Date(`${data.day}T12:00:00Z`).getTime() - Date.now()) / 86_400_000,
    );
    const forecastable = daysAhead >= -1 && daysAhead <= 15;

    try {
      if (forecastable) {
        const url =
          `https://api.open-meteo.com/v1/forecast?latitude=${hit.latitude}&longitude=${hit.longitude}` +
          `&daily=temperature_2m_min,temperature_2m_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max` +
          `&timezone=auto&start_date=${data.day}&end_date=${data.day}`;
        const res = await fetch(url);
        if (!res.ok) return base;
        const json = (await res.json()) as { daily?: Record<string, unknown[]> };
        const d = json.daily ?? {};
        const look: WeatherLook = {
          ...base,
          city: hit.name,
          kind: "prevision",
          tempMin: num(d["temperature_2m_min"]?.[0]),
          tempMax: num(d["temperature_2m_max"]?.[0]),
          rainMm: num(d["precipitation_sum"]?.[0]),
          rainChance: num(d["precipitation_probability_max"]?.[0]),
          windMax: num(d["wind_speed_10m_max"]?.[0]),
          summary: "",
        };
        return { ...look, summary: describe(look) };
      }

      /* Au-delà de la fenêtre : moyennes des cinq dernières années, même jour. */
      const year = Number(data.day.slice(0, 4));
      const md = data.day.slice(5);
      const mins: number[] = [];
      const maxs: number[] = [];
      const rains: number[] = [];
      for (let y = year - 5; y < year; y++) {
        const url =
          `https://archive-api.open-meteo.com/v1/archive?latitude=${hit.latitude}&longitude=${hit.longitude}` +
          `&daily=temperature_2m_min,temperature_2m_max,precipitation_sum&timezone=auto` +
          `&start_date=${y}-${md}&end_date=${y}-${md}`;
        const res = await fetch(url);
        if (!res.ok) continue;
        const json = (await res.json()) as { daily?: Record<string, unknown[]> };
        const d = json.daily ?? {};
        const mn = num(d["temperature_2m_min"]?.[0]);
        const mx = num(d["temperature_2m_max"]?.[0]);
        const rn = num(d["precipitation_sum"]?.[0]);
        if (mn !== null) mins.push(mn);
        if (mx !== null) maxs.push(mx);
        if (rn !== null) rains.push(rn);
      }
      if (!maxs.length) return base;
      const avg = (a: number[]) => Math.round((a.reduce((s, v) => s + v, 0) / a.length) * 10) / 10;
      const look: WeatherLook = {
        ...base,
        city: hit.name,
        kind: "saison",
        tempMin: mins.length ? avg(mins) : null,
        tempMax: avg(maxs),
        rainMm: rains.length ? avg(rains) : null,
        rainChance: rains.length
          ? Math.round((rains.filter((r) => r >= 1).length / rains.length) * 100)
          : null,
        windMax: null,
        summary: "",
      };
      return { ...look, summary: describe(look) };
    } catch {
      return base;
    }
  });

function describe(w: WeatherLook): string {
  const parts: string[] = [];
  if (w.tempMax !== null) {
    parts.push(w.tempMin !== null ? `${w.tempMin}° à ${w.tempMax}°` : `${w.tempMax}°`);
  }
  if (w.rainChance !== null) parts.push(`${w.rainChance} % de risque de pluie`);
  else if (w.rainMm !== null) parts.push(`${w.rainMm} mm de pluie`);
  if (w.windMax !== null) parts.push(`vent jusqu'à ${Math.round(w.windMax)} km/h`);
  const head =
    w.kind === "saison"
      ? "Moyenne des cinq dernières années à cette date"
      : "Prévision pour cette date";
  return parts.length ? `${head} : ${parts.join(", ")}.` : `${head} : donnée incomplète.`;
}

/** Le plan B se déduit du risque, pas de l'humeur. */
export function planB(w: WeatherLook): string[] {
  const out: string[] = [];
  const wet = (w.rainChance ?? 0) >= 40 || (w.rainMm ?? 0) >= 3;
  const windy = (w.windMax ?? 0) >= 40;
  const cold = (w.tempMin ?? 99) <= 8;
  const hot = (w.tempMax ?? 0) >= 30;
  if (wet) {
    out.push(
      "Réserver une solution couverte (chapiteau, salle de repli) et la confirmer par écrit.",
    );
    out.push("Prévoir un sol praticable : tapis d'entrée, cheminement, parking boueux.");
  }
  if (windy) out.push("Arrimage et bâches : vérifier la tenue au vent des structures légères.");
  if (cold) out.push("Chauffage d'appoint et boissons chaudes pour l'extérieur en soirée.");
  if (hot) out.push("Ombre, eau et horaires décalés pour les moments en plein soleil.");
  if (!out.length) out.push("Conditions favorables : garder tout de même un repli identifié.");
  out.push("Fixer l'heure de décision du plan B avec le lieu et le traiteur.");
  return out;
}
