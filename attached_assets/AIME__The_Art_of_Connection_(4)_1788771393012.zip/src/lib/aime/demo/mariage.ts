/**
 * Le mariage de Camille & Sofiane : un seul modèle de projet, entièrement fictif.
 * Toutes les vues de la page de démonstration (Avant / Pendant / Après, ligne de
 * temps, documents, finance, prestataires, médias, musique, Play) lisent ce
 * modèle. Aucune information n'y est écrite deux fois.
 */
import visualVenue from "@/assets/visual-venue.jpg";
import visualFood from "@/assets/visual-food.jpg";
import visualPhoto from "@/assets/visual-photo.jpg";
import visualMusic from "@/assets/visual-music.jpg";
import visualFlower from "@/assets/visual-flower.jpg";
import visualPatisserie from "@/assets/visual-patisserie.jpg";
import visualBeaute from "@/assets/visual-beaute.jpg";
import visualVideo from "@/assets/visual-video.jpg";
import visualLight from "@/assets/visual-light.jpg";
import visualEvent from "@/assets/visual-event.jpg";
import visualScene from "@/assets/visual-scene.jpg";
import visualPeople from "@/assets/visual-people.jpg";
import weddingFilm from "@/assets/aime-wedding.mp4.asset.json";
import {
  DAY,
  fact,
  type WorldDocument,
  type WorldProject,
  type WorldProvider,
} from "@/lib/aime/world/types";
import { scheduleFrom, type PaymentCommitment } from "@/lib/aime/world/finance";

export { DAY, atHour as at, euros, formatHour, formatLongDate } from "@/lib/aime/world/types";

export const DEMO = {
  couple: "Camille & Sofiane",
  city: "Lille",
  guests: 148,
  filmUrl: weddingFilm.url,
};

/** Minuit du jour J : trois mois en arrière, toujours un samedi lisible. */
export function weddingDay(now = Date.now()) {
  const d = new Date(now - 92 * DAY);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - ((d.getDay() + 1) % 7)); // ramené au samedi
  return d.getTime();
}

type Seed = Omit<WorldProvider, "confidence" | "status" | "id"> & {
  id: string;
  daysBefore: number;
  paid: boolean;
};

const SEEDS: Seed[] = [
  { id: "lieu", role: "Lieu de réception", name: "Domaine de la Vigne Blanche", city: "Bondues", photo: visualVenue, daysBefore: 384, amountCents: 690000, depositCents: 207000, paid: true, note: "Grange rénovée, 160 couverts, nuit sur place pour les mariés." },
  { id: "traiteur", role: "Traiteur", name: "Maison Delcourt", city: "Lille", photo: visualFood, daysBefore: 297, amountCents: 1128000, depositCents: 340000, paid: true, note: "Cocktail 12 pièces, dîner 4 services, brunch du lendemain." },
  { id: "photo", role: "Photographe", name: "Anouk Ferrand", city: "Roubaix", photo: visualPhoto, daysBefore: 288, amountCents: 240000, depositCents: 72000, paid: true, note: "Préparatifs → ouverture de bal, 600 photos livrées." },
  { id: "video", role: "Vidéaste", name: "Studio Quatre Août", city: "Lille", photo: visualVideo, daysBefore: 240, amountCents: 195000, depositCents: 58000, paid: true, note: "Film de 8 minutes + teaser d'une minute." },
  { id: "dj", role: "Musique / DJ", name: "Collectif Nordiste — DJ Mel", city: "Lille", photo: visualMusic, daysBefore: 231, amountCents: 165000, depositCents: 50000, paid: true, note: "Trio live au cocktail, DJ set jusqu'à 4 h." },
  { id: "fleurs", role: "Fleuriste", name: "Atelier Pistil", city: "Lambersart", photo: visualFlower, daysBefore: 168, amountCents: 148000, depositCents: 44000, paid: true, note: "Arche de cérémonie, 16 centres de table, bouquet." },
  { id: "deco", role: "Décoration", name: "Les Bonnes Lumières", city: "Tourcoing", photo: visualLight, daysBefore: 150, amountCents: 96000, depositCents: 29000, paid: true, note: "Guirlandes, nappage, signalétique manuscrite." },
  { id: "beaute", role: "Coiffure & maquillage", name: "Salon Ondine", city: "Lille", photo: visualBeaute, daysBefore: 121, amountCents: 52000, depositCents: 15000, paid: true, note: "Deux mariés + quatre témoins, sur place dès 8 h." },
  { id: "patisserie", role: "Pâtisserie", name: "Sucre & Sel", city: "Lille", photo: visualPatisserie, daysBefore: 96, amountCents: 84000, depositCents: 25000, paid: true, note: "Pièce montée trois étages, vanille & fruits rouges." },
  { id: "officiant", role: "Officiant / cérémonie", name: "Hélène Vasseur", city: "Lille", photo: visualEvent, daysBefore: 88, amountCents: 45000, depositCents: 15000, paid: true, note: "Cérémonie laïque écrite avec les témoins." },
  { id: "transport", role: "Transport", name: "Navettes du Nord", city: "Marcq-en-Barœul", photo: visualScene, daysBefore: 62, amountCents: 78000, depositCents: 23000, paid: false, note: "Deux rotations gare → domaine, retour à 2 h et 4 h." },
  { id: "hebergement", role: "Hébergement", name: "Les Chambres du Clos", city: "Bondues", photo: visualPeople, daysBefore: 54, amountCents: 132000, depositCents: 40000, paid: false, note: "14 chambres bloquées pour les invités venus de loin." },
];

const MOMENTS: {
  id: string;
  offsetH: number;
  label: string;
  detail: string;
  providerId: string;
  photo: string;
}[] = [
  { id: "j1", offsetH: 8, label: "Préparatifs", detail: "Coiffure et maquillage dans la maison du domaine, café et musique douce.", providerId: "beaute", photo: visualBeaute },
  { id: "j2", offsetH: 10.5, label: "Mairie", detail: "Cérémonie civile à Lille, 30 proches, sortie sous les pétales.", providerId: "photo", photo: visualPhoto },
  { id: "j3", offsetH: 12.5, label: "Déjeuner des témoins", detail: "Repas léger au domaine pendant l'installation de la salle.", providerId: "traiteur", photo: visualFood },
  { id: "j4", offsetH: 14, label: "Installation & décor", detail: "Arche fleurie, 16 tables dressées, guirlandes tendues.", providerId: "fleurs", photo: visualFlower },
  { id: "j5", offsetH: 15.5, label: "Cérémonie laïque", detail: "Sous les tilleuls, six prises de parole, échange des vœux.", providerId: "officiant", photo: visualEvent },
  { id: "j6", offsetH: 17, label: "Photos de groupe", detail: "Familles, témoins, puis la série des mariés dans le verger.", providerId: "photo", photo: visualPhoto },
  { id: "j7", offsetH: 18, label: "Cocktail", detail: "12 pièces salées, trio jazz en live, jeu de la boîte à souvenirs.", providerId: "dj", photo: visualMusic },
  { id: "j8", offsetH: 20, label: "Entrée en salle & dîner", detail: "Quatre services, discours entre les plats, 148 couverts.", providerId: "traiteur", photo: visualFood },
  { id: "j9", offsetH: 22.5, label: "Pièce montée", detail: "Trois étages vanille & fruits rouges, feux froids.", providerId: "patisserie", photo: visualPatisserie },
  { id: "j10", offsetH: 23, label: "Ouverture de bal", detail: "Première danse, puis la piste ne se vide plus.", providerId: "dj", photo: visualScene },
  { id: "j11", offsetH: 25.5, label: "Soirée", detail: "Set nordiste, karaoké improvisé, dernier morceau à 4 h.", providerId: "dj", photo: visualLight },
  { id: "j12", offsetH: 28, label: "Navette de fin", detail: "Retour vers Lille, dernières photos sur le parvis.", providerId: "transport", photo: visualVenue },
];

const TRACKS: { id: string; offsetH: number; title: string; artist: string; moment: string; dedicace?: string }[] = [
  { id: "t1", offsetH: 18, title: "Blue in Green", artist: "Trio Nordiste", moment: "Cocktail" },
  { id: "t2", offsetH: 18.6, title: "Fly Me to the Moon", artist: "Trio Nordiste", moment: "Cocktail" },
  { id: "t3", offsetH: 19.3, title: "La Javanaise", artist: "Trio Nordiste", moment: "Cocktail" },
  { id: "t4", offsetH: 20, title: "Entrée des mariés — Home", artist: "Edward Sharpe", moment: "Entrée en salle", dedicace: "Choisi par les témoins" },
  { id: "t5", offsetH: 21, title: "Sunday Kind of Love", artist: "Etta James", moment: "Dîner" },
  { id: "t6", offsetH: 22, title: "Ne me quitte pas", artist: "Jacques Brel", moment: "Dîner" },
  { id: "t7", offsetH: 23, title: "Ouverture de bal — At Last", artist: "Etta James", moment: "Ouverture de bal", dedicace: "Camille & Sofiane, première danse" },
  { id: "t8", offsetH: 23.4, title: "Septembre", artist: "Earth, Wind & Fire", moment: "Piste ouverte", dedicace: "Demandé par la table 4" },
  { id: "t9", offsetH: 24.2, title: "Voyage voyage", artist: "Desireless", moment: "Soirée" },
  { id: "t10", offsetH: 25, title: "Alors on danse", artist: "Stromae", moment: "Soirée", dedicace: "Pour la bande de Bruxelles" },
  { id: "t11", offsetH: 26, title: "Bella Ciao", artist: "Reprise live", moment: "Karaoké" },
  { id: "t12", offsetH: 27, title: "P'tit bonheur", artist: "Félix Leclerc", moment: "Fin de nuit", dedicace: "Pour les grands-parents" },
  { id: "t13", offsetH: 28, title: "Dernier morceau — La Bohème", artist: "Charles Aznavour", moment: "Fin de nuit", dedicace: "Les mariés remercient tout le monde" },
];

const MESSAGES: {
  id: string;
  providerId?: string;
  thread?: string;
  from: string;
  mine?: boolean;
  days: number;
  text: string;
}[] = [
  { id: "m1", providerId: "lieu", thread: "Domaine de la Vigne Blanche", from: "Camille", mine: true, days: -384, text: "Bonjour ! La date du samedi est-elle encore libre pour 150 personnes ?" },
  { id: "m2", providerId: "lieu", thread: "Domaine de la Vigne Blanche", from: "Le Domaine", days: -383, text: "Elle l'est. Je vous envoie le devis avec la nuit sur place incluse." },
  { id: "m3", providerId: "lieu", thread: "Domaine de la Vigne Blanche", from: "Camille", mine: true, days: -381, text: "Devis signé, acompte parti. On a hâte." },
  { id: "m4", providerId: "traiteur", thread: "Maison Delcourt", from: "Sofiane", mine: true, days: -60, text: "On monte à 148 convives, dont 9 sans gluten et 12 végétariens." },
  { id: "m5", providerId: "traiteur", thread: "Maison Delcourt", from: "Maison Delcourt", days: -59, text: "Noté. Devis rectificatif envoyé, le brunch reste au même prix." },
  { id: "m6", providerId: "traiteur", thread: "Maison Delcourt", from: "Sofiane", mine: true, days: -7, text: "Tout est validé, à samedi !" },
  { id: "m7", providerId: "dj", thread: "DJ Mel", from: "DJ Mel", days: -21, text: "Envoyez-moi la playlist d'ouverture de bal et vos interdits." },
  { id: "m8", providerId: "dj", thread: "DJ Mel", from: "Camille", mine: true, days: -20, text: "At Last pour la première danse. Interdit : la Macarena, sous aucun prétexte." },
  { id: "m9", providerId: "dj", thread: "DJ Mel", from: "DJ Mel", days: 1, text: "Quelle soirée. La piste n'a pas désempli, merci pour la confiance." },
  { id: "m10", from: "Camille & Sofiane", mine: true, days: 3, text: "Merci à toutes et tous. Vous avez fait de cette journée exactement ce qu'on espérait : simple, bruyante et pleine de gens qu'on aime." },
  { id: "m11", providerId: "photo", from: "Anouk Ferrand", days: 12, text: "Les 600 photos sont en ligne, la galerie reste ouverte un an." },
  { id: "m12", from: "Tante Yamina", days: 5, text: "Le dessert. Je pense encore au dessert." },
  { id: "m13", providerId: "video", from: "Studio Quatre Août", days: 34, text: "Le film de 8 minutes est livré, le teaser arrive demain." },
];

const THREAD_PHOTO: Record<string, string> = {
  lieu: visualVenue,
  traiteur: visualFood,
  dj: visualMusic,
  photo: visualPhoto,
  video: visualVideo,
};

/** Le projet complet : une seule source pour toutes les représentations. */
export function demoWedding(now = Date.now()): WorldProject {
  const day = weddingDay(now);

  const providers: WorldProvider[] = SEEDS.map((s) => ({
    id: s.id,
    role: s.role,
    ...(s.name ? { name: s.name } : {}),
    ...(s.city ? { city: s.city } : {}),
    ...(s.photo ? { photo: s.photo } : {}),
    ...(s.note ? { note: s.note } : {}),
    status: "reserve",
    ...(s.amountCents !== undefined ? { amountCents: s.amountCents } : {}),
    ...(s.depositCents !== undefined ? { depositCents: s.depositCents } : {}),
    signedAt: day - s.daysBefore * DAY,
    confidence: "confirme",
  }));

  // Les montants de la démo sont des devis fictifs : ils restent rattachés à
  // leur prestataire et produisent le même échéancier que la couche finance.
  const commitments: PaymentCommitment[] = SEEDS.map((s) => {
    const documentId = `devis-${s.id}`;
    const createdAt = day - s.daysBefore * DAY;
    return {
      id: `engagement-${s.id}`,
      projectId: "demo-mariage",
      providerId: s.id,
      beneficiary: s.name ?? s.role,
      documentId,
      category: "prestation",
      description: `Prestation ${s.role}`,
      totalAmountCents: s.amountCents ?? 0,
      currency: "EUR",
      serviceDate: day,
      paymentMethod: "virement",
      beneficiaryVerification: "verifie",
      validation: "valide",
      schedule: scheduleFrom({
        id: `engagement-${s.id}`,
        totalCents: s.amountCents ?? 0,
        ...(s.depositCents !== undefined ? { depositCents: s.depositCents } : {}),
        signedAt: createdAt,
        serviceDate: day,
        paidUntil: s.paid ? day : -Infinity,
        role: s.role,
      }),
      source: "document",
      confidence: "confirme",
      createdAt,
      updatedAt: createdAt,
    };
  });

  return {
    id: "demo-mariage",
    kind: "mariage",
    universe: "Mariage",
    lifecycle: "demo",
    title: DEMO.couple,
    subtitle: DEMO.city,
    pivot: fact(day, "confirme", "projet"),
    city: fact(DEMO.city, "confirme", "projet"),
    venue: fact("Domaine de la Vigne Blanche", "confirme", "devis"),
    guests: fact(DEMO.guests, "confirme", "projet"),
    people: [
      { id: "camille", name: "Camille", role: "Mariée", confidence: "confirme" },
      { id: "sofiane", name: "Sofiane", role: "Marié", confidence: "confirme" },
    ],
    providers,
    moments: MOMENTS.map((m) => ({
      id: m.id,
      offsetH: m.offsetH,
      label: m.label,
      detail: m.detail,
      providerId: m.providerId,
      photo: m.photo,
      confidence: "confirme" as const,
    })),
    tasks: [
      { id: "faire-part", label: "Faire-part envoyés", detail: "148 invitations, 132 réponses en trois semaines.", at: day - 210 * DAY, done: true, confidence: "confirme" },
      { id: "playlist", label: "Playlist bouclée", detail: "13 moments programmés avec le DJ.", at: day - 30 * DAY, providerId: "dj", done: true, confidence: "confirme" },
      { id: "plan-table", label: "Plan de table arrêté", detail: "16 tables, placement validé avec les témoins.", at: day - 21 * DAY, done: true, confidence: "confirme" },
      { id: "retour-materiel", label: "Retour du matériel", detail: "Vaisselle et décor rendus au domaine.", at: day + 3 * DAY, done: true, confidence: "confirme" },
      { id: "album", label: "Album photo à commander", detail: "Sélection de 80 photos parmi les 600 livrées.", at: day + 60 * DAY, done: false, confidence: "suggere" },
    ],
    documents: [
      ...SEEDS.map<WorldDocument>((s) => ({
        id: `devis-${s.id}`,
        title: `Devis ${s.role} — ${s.name}`,
        at: day - s.daysBefore * DAY,
        kind: "devis",
        providerId: s.id,
        ...(s.amountCents !== undefined ? { amountCents: s.amountCents } : {}),
        ...(s.photo ? { photo: s.photo } : {}),
        ...(s.note ? { detail: s.note } : {}),
        confidence: "confirme",
      })),
      {
        id: "dossier",
        title: "Dossier clôturé",
        at: day + 45 * DAY,
        kind: "document",
        detail: "Contrats, factures et attestations rangés.",
        confidence: "confirme",
      },
    ],

    payments: SEEDS.flatMap((s) => [
      {
        id: `acompte-${s.id}`,
        label: `Acompte ${s.role}`,
        at: day - (s.daysBefore - 2) * DAY,
        amountCents: s.depositCents ?? 0,
        providerId: s.id,
        state: "paye" as const,
        confidence: "confirme" as const,
      },
      {
        id: `solde-${s.id}`,
        label: `Solde ${s.role}`,
        at: day + (s.paid ? -7 : 20) * DAY,
        amountCents: (s.amountCents ?? 0) - (s.depositCents ?? 0),
        providerId: s.id,
        state: s.paid ? ("paye" as const) : ("du" as const),
        confidence: "confirme" as const,
      },
    ]),
    media: [
      {
        id: "galerie",
        kind: "photo",
        at: day + 12 * DAY,
        title: "600 photos livrées",
        detail: "La galerie rejoint la page du mariage.",
        thumb: visualPhoto,
        confidence: "confirme",
      },
      {
        id: "film",
        kind: "video",
        at: day + 34 * DAY,
        title: "Le film du mariage",
        detail: "Huit minutes, du matin jusqu'au dernier morceau.",
        url: weddingFilm.url,
        thumb: visualVideo,
        confidence: "confirme",
      },
    ],
    tracks: TRACKS.map((t) => ({
      id: t.id,
      offsetH: t.offsetH,
      title: t.title,
      artist: t.artist,
      moment: t.moment,
      ...(t.dedicace ? { dedicace: t.dedicace } : {}),
      confidence: "confirme" as const,
    })),
    messages: MESSAGES.map((m) => ({
      id: m.id,
      from: m.from,
      text: m.text,
      at: day + m.days * DAY,
      ...(m.mine ? { mine: true } : {}),
      ...(m.providerId ? { providerId: m.providerId } : {}),
      ...(m.thread ? { thread: m.thread } : {}),
      ...(m.providerId && THREAD_PHOTO[m.providerId]
        ? { photo: THREAD_PHOTO[m.providerId] as string }
        : {}),
    })),
    reviews: [
      { providerId: "traiteur", vendor: "Maison Delcourt", stars: 5, text: "Service impeccable, aucun temps mort." },
      { providerId: "photo", vendor: "Anouk Ferrand", stars: 5, text: "On ne l'a jamais vue, on la retrouve partout." },
      { providerId: "transport", vendor: "Navettes du Nord", stars: 4, text: "Un quart d'heure de retard à 2 h, sans gravité." },
    ],
    intentions: [
      {
        id: "depart",
        text: "Nous nous marions près de Lille, en septembre, avec environ 150 invités.",
        at: day - 400 * DAY,
      },
    ],
    commitments,
    missing: [],
    demo: true,
  };
}
