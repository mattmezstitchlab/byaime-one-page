import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AiMode = "off" | "conseil" | "auto";

export function threadMembersQuery(threadId: string | null) {
  return queryOptions({
    queryKey: ["thread-members", threadId],
    enabled: !!threadId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("thread_members")
        .select("*")
        .eq("thread_id", threadId!)
        .order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export const directoryQuery = queryOptions({
  queryKey: ["directory"],
  staleTime: 60_000,
  queryFn: async () => {
    const { data, error } = await supabase
      .from("profiles")
      .select("id, display_name, headline, city, avatar_url")
      .order("display_name")
      .limit(200);
    if (error) throw error;
    return data ?? [];
  },
});

export function threadSettingsQuery(threadId: string | null, userId: string | null) {
  return queryOptions({
    queryKey: ["thread-settings", threadId, userId],
    enabled: !!threadId && !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("thread_settings")
        .select("*")
        .eq("thread_id", threadId!)
        .eq("user_id", userId!)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export async function saveThreadSettings(
  threadId: string,
  userId: string,
  patch: {
    ai_mode?: AiMode;
    translate_to?: string | null;
    tone?: string;
    auto_translate?: boolean;
    my_lang?: string | null;
  },
) {
  const { error } = await supabase
    .from("thread_settings")
    .upsert(
      { thread_id: threadId, user_id: userId, ...patch },
      { onConflict: "thread_id,user_id" },
    );
  if (error) throw error;
}

export async function createGroupThread(params: {
  me: string;
  title: string;
  kind: "groupe" | "equipe";
  memberIds: string[];
}) {
  const { data, error } = await supabase
    .from("threads")
    .insert({
      user_a: params.me,
      user_b: null,
      created_by: params.me,
      kind: params.kind,
      title: params.title,
      subject: params.title,
    })
    .select("id")
    .single();
  if (error) throw error;
  const rows = [params.me, ...params.memberIds]
    .filter((v, i, a) => a.indexOf(v) === i)
    .map((user_id) => ({ thread_id: data.id, user_id }));
  const { error: mErr } = await supabase.from("thread_members").upsert(rows, {
    onConflict: "thread_id,user_id",
  });
  if (mErr) throw mErr;
  return data.id;
}

export async function addThreadMember(threadId: string, userId: string, roleLabel = "membre") {
  const { error } = await supabase.from("thread_members").upsert(
    { thread_id: threadId, user_id: userId, role_label: roleLabel },
    {
      onConflict: "thread_id,user_id",
    },
  );
  if (error) throw error;
}

export async function removeThreadMember(threadId: string, userId: string) {
  const { error } = await supabase
    .from("thread_members")
    .delete()
    .eq("thread_id", threadId)
    .eq("user_id", userId);
  if (error) throw error;
}

export async function postMessage(params: {
  threadId: string;
  senderId: string;
  body: string;
  byAi?: boolean;
  kind?: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  sourceLang?: string | null;
  originalBody?: string | null;
}) {
  const { error } = await supabase.from("messages").insert({
    thread_id: params.threadId,
    sender_id: params.senderId,
    body: params.body,
    by_ai: params.byAi ?? false,
    kind: params.kind ?? "texte",
    attachment_url: params.attachmentUrl ?? null,
    attachment_name: params.attachmentName ?? null,
    source_lang: params.sourceLang ?? null,
    original_body: params.originalBody ?? null,
  });
  if (error) throw error;
  await supabase
    .from("threads")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", params.threadId);
}

/** Dépose un document dans l'espace privé et renvoie un lien signé longue durée. */
export async function uploadAttachment(threadId: string, file: File) {
  const path = `${threadId}/${Date.now()}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
  const { error } = await supabase.storage.from("pieces-jointes").upload(path, file);
  if (error) throw error;
  const { data, error: sErr } = await supabase.storage
    .from("pieces-jointes")
    .createSignedUrl(path, 60 * 60 * 24 * 365);
  if (sErr) throw sErr;
  return { url: data.signedUrl, name: file.name };
}

export async function setVisio(threadId: string, url: string | null) {
  const { error } = await supabase.from("threads").update({ visio_url: url }).eq("id", threadId);
  if (error) throw error;
}

export function visioUrlFor(threadId: string) {
  return `https://meet.jit.si/aime-${threadId.slice(0, 8)}-${threadId.slice(-4)}`;
}
