import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { FEATURES, type FeatureKey } from "@/lib/aime/features";

export type CreditEntry = Database["public"]["Tables"]["credit_ledger"]["Row"];

/** Barème AIME : 1 € versé = 10 crédits d'Aime. */
export const CREDITS_PER_EURO = 10;

export const TOPUP_PACKS = [
  { euros: 5, label: "Un coup de main" },
  { euros: 15, label: "Un projet" },
  { euros: 40, label: "Une saison" },
] as const;

export const PAY_METHODS = [
  { value: "carte", label: "Carte bancaire" },
  { value: "iban", label: "Virement (IBAN)" },
  { value: "revolut", label: "Revolut" },
] as const;

export const LEDGER_STATUS_LABEL: Record<string, string> = {
  en_attente: "En attente",
  valide: "Validé",
  refuse: "Refusé",
  paye: "Payé",
};

export function creditLedgerQuery(userId: string | null) {
  return {
    queryKey: ["credit_ledger", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<CreditEntry[]> => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("credit_ledger")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  };
}

/**
 * La contribution comme valeur : une heure donnée vaut autant qu'un euro
 * versé, au barème déclaré ci-dessous. Rien n'est converti en argent : la
 * contribution ouvre des crédits d'usage, pas un retrait.
 */
export const CREDITS_PER_HOUR = 10;

export const CONTRIBUTION_KINDS = [
  { value: "temps", label: "Du temps donné" },
  { value: "materiel", label: "Du matériel prêté" },
  { value: "lieu", label: "Un lieu ouvert" },
  { value: "savoir", label: "Un savoir transmis" },
] as const;

export async function addContribution(
  userId: string,
  hours: number,
  method: string,
  note?: string,
  cardId?: string | null,
) {
  if (!Number.isFinite(hours) || hours <= 0) throw new Error("Indiquez un nombre d'heures.");
  const { error } = await supabase.from("credit_ledger").insert({
    user_id: userId,
    kind: "contribution",
    amount_cents: 0,
    credits: Math.round(hours * CREDITS_PER_HOUR),
    method,
    status: "en_attente",
    note: note?.trim() || null,
  });
  if (error) throw error;

  // Une contribution rattachée à une carte devient un repère daté sur sa timeline.
  if (cardId) {
    const { error: tlError } = await supabase.from("card_timeline_entries").insert({
      card_id: cardId,
      kind: "contribution",
      title: `${hours} h données${note?.trim() ? ` — ${note.trim()}` : ""}`,
      description: `Contribution déclarée (${method}). ${Math.round(
        hours * CREDITS_PER_HOUR,
      )} crédits reconnus.`,
      starts_at: new Date().toISOString(),
      is_public: true,
      secrecy: "public",
    });
    if (tlError) throw tlError;
  }
}

export function contributionCredits(ledger: CreditEntry[]) {
  return ledger
    .filter((e) => e.kind === "contribution" && e.status !== "refuse")
    .reduce((s, e) => s + e.credits, 0);
}

export function creditsPurchased(ledger: CreditEntry[]) {
  return ledger
    .filter((e) => e.kind === "versement" && e.status !== "refuse")
    .reduce((s, e) => s + e.credits, 0);
}

export function euros(cents: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);
}

/**
 * Journalise une action IA réussie.
 *
 * Pendant la bêta rien n'est bloqué : on écrit seulement dans le journal
 * pour que le compteur dise la vérité et que personne n'ait de surprise.
 */
export async function logUsage(
  userId: string | null,
  feature: FeatureKey,
  detail?: string,
): Promise<void> {
  if (!userId) return;
  const f = FEATURES[feature];
  if (!f.credits) return;
  try {
    await supabase.from("ai_usage").insert({
      user_id: userId,
      feature: f.key,
      credits: f.credits,
      detail: (detail ?? f.label).slice(0, 200),
    });
  } catch {
    /* le journal ne doit jamais empêcher une action d'aboutir */
  }
}

export async function addTopup(userId: string, amountEuros: number, method: string, note?: string) {
  if (!Number.isFinite(amountEuros) || amountEuros <= 0)
    throw new Error("Indiquez un montant en euros.");
  const { error } = await supabase.from("credit_ledger").insert({
    user_id: userId,
    kind: "versement",
    amount_cents: Math.round(amountEuros * 100),
    credits: Math.round(amountEuros * CREDITS_PER_EURO),
    method,
    status: "valide",
    note: note?.trim() || null,
  });
  if (error) throw error;
}

export async function addWithdrawal(
  userId: string,
  amountEuros: number,
  method: string,
  note?: string,
) {
  if (!Number.isFinite(amountEuros) || amountEuros <= 0)
    throw new Error("Indiquez un montant à retirer.");
  const { error } = await supabase.from("credit_ledger").insert({
    user_id: userId,
    kind: "retrait",
    amount_cents: Math.round(amountEuros * 100),
    credits: 0,
    method,
    status: "en_attente",
    note: note?.trim() || null,
  });
  if (error) throw error;
}
