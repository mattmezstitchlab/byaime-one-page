/**
 * Lire la quintessence d'une sélection de personnes.
 *
 * Rien n'est enregistré ici : on regarde seulement ce que les personnes
 * choisies réunissent déjà (métiers, univers, villes), ce que cela rend
 * possible (les formules), et qui manque encore pour tenir chaque formule.
 */
import type { Card } from "@/lib/aime/types";
import { WEDDING_ROLES } from "@/lib/aime/presets/mariage";

export type Role = {
  label: string;
  /** Mots qui servent à reconnaître une carte candidate. */
  match: string[];
  hint: string;
};

export type Formula = {
  id: string;
  title: string;
  /** Une phrase qui dit pourquoi cette réunion tient debout. */
  why: string;
  roles: Role[];
};

const r = (label: string, match: string[], hint: string): Role => ({ label, match, hint });

/** Les lectures possibles d'un groupe. La première qui colle est proposée. */
export const FORMULAS: Formula[] = [
  {
    id: "mariage",
    title: "Mariage complet",
    why: "Un lieu, un repas, des images et de la musique : la journée tient toute seule.",
    roles: WEDDING_ROLES.map((w) => r(w.label, w.match, w.hint)),
  },
  {
    id: "concert",
    title: "Concert en salle",
    why: "Une scène, du son, des musiciens et de quoi faire venir du monde.",
    roles: [
      r("Lieu / salle", ["lieu", "salle", "scene", "club", "theatre"], "Où ça se passe."),
      r("Musicien / groupe", ["musicien", "groupe", "artiste", "chanteur", "dj"], "Ce qu'on vient écouter."),
      r("Son & lumière", ["son", "sono", "technique", "lumiere", "regie"], "Pour que ça s'entende et se voie."),
      r("Photo / vidéo", ["photo", "video", "captation"], "Les traces du soir."),
      r("Communication", ["communication", "presse", "affiche", "graphiste", "reseaux"], "Pour remplir la salle."),
    ],
  },
  {
    id: "tournage",
    title: "Tournage / film",
    why: "Une image, un son, un décor : de quoi tourner une histoire.",
    roles: [
      r("Réalisation", ["realisateur", "realisation", "film", "video", "videaste"], "Celui qui raconte."),
      r("Image", ["photo", "camera", "chef operateur", "image"], "Ce qu'on voit."),
      r("Son", ["son", "ingenieur du son", "perche", "audio"], "Ce qu'on entend."),
      r("Décor / lieu", ["lieu", "decor", "studio", "salle", "domaine"], "Où l'on tourne."),
      r("Montage", ["montage", "monteur", "post-production"], "Ce qui reste au bout."),
    ],
  },
  {
    id: "reception",
    title: "Réception / soirée",
    why: "Un lieu, à manger, de la musique : la soirée se tient.",
    roles: [
      r("Lieu de réception", ["lieu", "salle", "domaine", "chateau", "reception"], "Le cadre."),
      r("Traiteur", ["traiteur", "restauration", "cuisine", "food", "chef"], "Ce qu'on mange."),
      r("Musique / DJ", ["dj", "musique", "groupe", "orchestre", "musicien"], "L'ambiance."),
      r("Décoration", ["decoration", "fleur", "fleuriste", "scenographie"], "Ce qu'on regarde."),
    ],
  },
  {
    id: "exposition",
    title: "Exposition / événement culturel",
    why: "Des œuvres, un lieu, un regard extérieur : l'exposition existe.",
    roles: [
      r("Artiste / auteur", ["artiste", "peintre", "photographe", "auteur", "plasticien"], "Ce qu'on montre."),
      r("Lieu d'exposition", ["lieu", "galerie", "musee", "salle", "espace"], "Où l'on montre."),
      r("Scénographie", ["scenographie", "decoration", "eclairage", "lumiere"], "Comment on montre."),
      r("Médiation / presse", ["presse", "communication", "mediation", "association"], "À qui l'on montre."),
    ],
  },
];

function hay(card: Card): string {
  return [card.category_slug, card.name, card.headline, ...(card.tags ?? []), ...(card.skills ?? [])]
    .join(" ")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** Cette carte peut-elle tenir ce rôle ? */
export function cardFitsRole(card: Card, role: Pick<Role, "match">): boolean {
  const text = hay(card);
  return role.match.some((m) => text.includes(m));
}

export type Reading = {
  formula: Formula;
  covered: { role: Role; cards: Card[] }[];
  missing: Role[];
  /** Part des rôles déjà réunis, de 0 à 1. */
  score: number;
};

/** Les lectures possibles d'une sélection, la plus complète d'abord. */
export function readSelection(cards: Card[]): Reading[] {
  if (cards.length === 0) return [];
  return FORMULAS.map((formula) => {
    const covered: { role: Role; cards: Card[] }[] = [];
    const missing: Role[] = [];
    for (const role of formula.roles) {
      const hits = cards.filter((c) => cardFitsRole(c, role));
      if (hits.length > 0) covered.push({ role, cards: hits });
      else missing.push(role);
    }
    return { formula, covered, missing, score: covered.length / formula.roles.length };
  })
    .filter((reading) => reading.covered.length > 0)
    .sort((a, b) => b.score - a.score || b.covered.length - a.covered.length)
    .slice(0, 3);
}

/** Ce que les personnes choisies réunissent déjà, en petites pastilles. */
export function selectionChips(
  cards: Card[],
  catLabel: Map<string, string>,
): { metiers: string[]; univers: string[]; villes: string[] } {
  const metiers = new Set<string>();
  const univers = new Set<string>();
  const villes = new Set<string>();
  for (const c of cards) {
    metiers.add(catLabel.get(c.category_slug) ?? c.category_slug);
    for (const u of c.universes ?? []) univers.add(u);
    if (c.city) villes.add(c.city);
  }
  return { metiers: [...metiers], univers: [...univers], villes: [...villes] };
}

/** Une phrase d'objectif pré-remplie pour la page équipe. */
export function objectiveFor(reading: Reading | undefined, cards: Card[]): string {
  if (!reading) return `Réunir ${cards.length} personnes autour d'un projet commun.`;
  const villes = [...new Set(cards.map((c) => c.city).filter(Boolean))];
  const ou = villes.length === 1 ? ` à ${villes[0]}` : "";
  return `${reading.formula.title}${ou} : ${reading.formula.why}`;
}
