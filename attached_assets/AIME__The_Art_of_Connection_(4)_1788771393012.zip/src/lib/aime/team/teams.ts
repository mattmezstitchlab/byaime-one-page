/**
 * Une équipe, c'est un regroupement de personnes déjà connu de l'application
 * (une « composition ») avec un objectif écrit en une phrase. Aucune notion
 * nouvelle : la même table, une page dédiée, et une notification par personne.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Card } from "@/lib/aime/types";

export type Team = {
  id: string;
  title: string;
  objective: string | null;
  universe_slug: string | null;
  user_id: string;
  created_at: string;
  cards: Card[];
  slots: Record<string, string>;
};

export function teamQuery(id: string) {
  return queryOptions({
    queryKey: ["equipe", id],
    queryFn: async (): Promise<Team | null> => {
      const { data, error } = await supabase
        .from("compositions")
        .select("*, composition_items(card_id, slot_label, position)")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const items = (data.composition_items ?? []) as {
        card_id: string;
        slot_label: string;
        position: number;
      }[];
      const ids = items.map((i) => i.card_id);
      let cards: Card[] = [];
      if (ids.length > 0) {
        const { data: rows, error: e2 } = await supabase.from("cards").select("*").in("id", ids);
        if (e2) throw e2;
        cards = (rows ?? []) as unknown as Card[];
      }
      const order = new Map(items.map((i) => [i.card_id, i.position]));
      cards.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
      return {
        id: data.id,
        title: data.title,
        objective: data.brief,
        universe_slug: data.universe_slug,
        user_id: data.user_id,
        created_at: data.created_at,
        cards,
        slots: Object.fromEntries(items.map((i) => [i.card_id, i.slot_label])),
      };
    },
  });
}

/** Crée l'équipe, range chaque personne à sa place, prévient tout le monde. */
export async function createTeam(input: {
  userId: string;
  title: string;
  objective: string;
  universeSlug?: string | null;
  members: { card: Card; slot: string }[];
}): Promise<string> {
  const { data, error } = await supabase
    .from("compositions")
    .insert({
      user_id: input.userId,
      title: input.title.trim() || "Équipe",
      brief: input.objective.trim() || null,
      universe_slug: input.universeSlug ?? null,
    })
    .select("id")
    .single();
  if (error) throw error;
  const teamId = data.id;

  const { error: e2 } = await supabase.from("composition_items").insert(
    input.members.map((m, i) => ({
      composition_id: teamId,
      card_id: m.card.id,
      slot_label: m.slot,
      position: i,
    })),
  );
  if (e2) throw e2;

  const owners = [
    ...new Set(
      input.members
        .map((m) => m.card.owner_id)
        .filter((o): o is string => !!o && o !== input.userId),
    ),
  ];
  if (owners.length > 0) {
    await supabase.from("notifications").insert(
      owners.map((owner) => ({
        user_id: owner,
        actor_id: input.userId,
        kind: "equipe",
        target_type: "equipe",
        target_id: teamId,
        title: `Vous faites partie de « ${input.title.trim() || "Équipe"} »`,
        body: input.objective.trim() || null,
        url: `/equipe/${teamId}`,
      })),
    );
  }
  return teamId;
}
