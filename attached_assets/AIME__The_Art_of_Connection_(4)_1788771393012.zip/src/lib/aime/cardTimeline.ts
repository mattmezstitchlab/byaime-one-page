import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import { entryStart } from "@/lib/aime/musicbox";


/**
 * Tout ce qui est daté autour d'une carte, ramené sur une seule ligne de temps :
 * documents, devis, factures, paiements, événements et messages.
 * Les sources privées ne sont lues que par le propriétaire de la carte.
 */
export function useCardTimelineSources(cardId: string, opts: { isOwner: boolean }) {
  const { isOwner } = opts;

  const documents = useQuery({
    queryKey: ["timeline-documents", cardId, isOwner],
    enabled: isOwner,
    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data, error } = await supabase
        .from("bureau_documents")
        .select("id,file_name,doc_type,doc_number,issued_on,created_at,amount_ttc,counterpart")
        .order("created_at", { ascending: false })
        .limit(120);
      if (error) throw error;
      return (data ?? []).map((d) => ({
        id: `doc-${d.id}`,
        time: new Date(d.issued_on ?? d.created_at).getTime(),
        kind: d.doc_type === "facture" ? "facture" : "document",
        title: d.doc_number ? `${d.file_name} · ${d.doc_number}` : d.file_name,
        detail: d.counterpart ?? undefined,
        media: "doc",
        ...(typeof d.amount_ttc === "number"
          ? { amountCents: Math.round(d.amount_ttc * 100) }
          : {}),
      }));
    },
  });

  const quotes = useQuery({
    queryKey: ["timeline-quotes", cardId],
    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data, error } = await supabase
        .from("quotes")
        .select("id,title,status,total,target_date,created_at")
        .eq("card_id", cardId)
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return (data ?? []).map((q) => ({
        id: `quote-${q.id}`,
        time: new Date(q.target_date ?? q.created_at).getTime(),
        kind: q.status === "facture" || q.status === "paye" ? "facture" : "devis",
        title: q.title || "Devis",
        detail: `Statut : ${q.status}`,
        amountCents: Math.round(Number(q.total ?? 0) * 100),
      }));
    },
  });

  const payments = useQuery({
    queryKey: ["timeline-payments", cardId],
    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data, error } = await supabase
        .from("event_payments")
        .select("id,label,amount_due,amount_paid,paid_at,created_at,payer_name,status")
        .eq("card_id", cardId)
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return (data ?? []).map((p) => ({
        id: `pay-${p.id}`,
        time: new Date(p.paid_at ?? p.created_at).getTime(),
        kind: "paiement",
        title: p.label || "Paiement",
        detail: `${p.payer_name} · ${p.status}`,
        amountCents: Math.round(Number(p.amount_paid || p.amount_due || 0) * 100),
      }));
    },
  });

  const events = useQuery({
    queryKey: ["timeline-events", cardId],
    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data, error } = await supabase
        .from("events")
        .select("id,title,starts_at,city,location,universe_slug,status")
        .eq("card_id", cardId)
        .order("starts_at", { ascending: true })
        .limit(60);
      if (error) throw error;
      return (data ?? []).map((e) => ({
        id: `event-${e.id}`,
        time: new Date(e.starts_at).getTime(),
        kind: "evenement",
        title: e.title,
        detail: [e.city, e.location].filter(Boolean).join(" · ") || undefined,
        universe: e.universe_slug ?? undefined,
      }));
    },
  });

  /** Messages du fil rattaché à la carte, regroupés par jour. */
  const messages = useQuery({
    queryKey: ["timeline-messages", cardId, isOwner],
    enabled: isOwner,
    // La ligne de temps est vivante : un message reçu allume sa pastille.
    refetchInterval: 20_000,

    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data: threads, error: tErr } = await supabase
        .from("threads")
        .select("id,subject")
        .eq("card_id", cardId)
        .limit(20);
      if (tErr) throw tErr;
      const ids = (threads ?? []).map((t) => t.id);
      if (ids.length === 0) return [];
      const { data: me } = await supabase.auth.getUser();
      const myId = me.user?.id ?? null;
      const { data, error } = await supabase
        .from("messages")
        .select("id,thread_id,body,created_at,sender_id,read_at")
        .in("thread_id", ids)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      const byDay = new Map<
        string,
        { time: number; thread: string; bodies: string[]; unread: boolean }
      >();
      for (const m of data ?? []) {
        const d = new Date(m.created_at);
        const key = `${m.thread_id}-${d.toISOString().slice(0, 10)}`;
        const unread = !m.read_at && !!myId && m.sender_id !== myId;
        const bucket = byDay.get(key);
        if (bucket) {
          bucket.bodies.push(m.body);
          bucket.unread ||= unread;
        } else
          byDay.set(key, {
            time: d.getTime(),
            thread: m.thread_id,
            bodies: [m.body],
            unread,
          });
      }
      return [...byDay.entries()].map(([key, v]) => ({
        id: `msg-${key}`,
        time: v.time,
        kind: "message" as const,
        title:
          v.bodies.length > 1 ? `${v.bodies.length} messages` : (v.bodies[0]?.slice(0, 60) ?? ""),
        detail: v.bodies.slice(0, 3).join(" — ").slice(0, 160),
        threadId: v.thread,
        unread: v.unread,
      }));

    },
  });

  /** Musique et voix : la playlist est une partition posée sur la même ligne. */
  const music = useQuery({
    queryKey: ["timeline-music", cardId],
    queryFn: async (): Promise<TimelineMarker[]> => {
      const { data, error } = await supabase
        .from("musicbox_entries")
        .select(
          "id,title,kind,day,start_time,duration_min,note,source_type,source_url,audio_path,event_id,status,dedicated_name",
        )
        .eq("card_id", cardId)
        .order("day", { ascending: true })
        .limit(200);
      if (error) throw error;
      return (data ?? []).map((e) => {
        const time = entryStart(e).getTime();
        return {
          id: `music-${e.id}`,
          time,
          startTime: time,
          endTime: time + Math.max(1, e.duration_min ?? 4) * 60_000,
          kind: "souvenir" as const,
          title: e.title,
          detail: e.note ?? e.dedicated_name ?? undefined,
          media: "audio" as const,
          ...(e.source_url ? { mediaUrl: e.source_url } : {}),
          ...(e.event_id ? { projectId: e.event_id } : {}),
          source: e.source_type ?? "musicbox",
          metadata: {
            track: true,
            musicKind: e.kind,
            durationMs: Math.max(1, e.duration_min ?? 4) * 60_000,
            ...(e.audio_path ? { audioPath: e.audio_path } : {}),
          },
        };
      });
    },
  });

  const markers: TimelineMarker[] = [
    ...(documents.data ?? []),
    ...(quotes.data ?? []),
    ...(payments.data ?? []),
    ...(events.data ?? []),
    ...(messages.data ?? []),
    ...(music.data ?? []),
  ];

  return { markers };
}

