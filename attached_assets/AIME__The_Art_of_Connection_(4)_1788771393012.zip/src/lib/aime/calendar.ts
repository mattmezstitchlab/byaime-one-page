export const AVAILABILITY_STATUSES = ["disponible", "option", "complet"] as const;
export type AvailabilityStatus = (typeof AVAILABILITY_STATUSES)[number];

export const AVAILABILITY_LABEL: Record<string, string> = {
  disponible: "Disponible",
  option: "Option posée",
  complet: "Complet",
};

export const AVAILABILITY_DOT: Record<string, string> = {
  disponible: "bg-emerald-500",
  option: "bg-amber-500",
  complet: "bg-rose-500",
};

export const AIME_STATUSES = ["nouveau", "discussion", "accepte", "decline"] as const;
export type AimeStatus = (typeof AIME_STATUSES)[number];

export const AIME_STATUS_LABEL: Record<string, string> = {
  nouveau: "Nouveau",
  discussion: "En discussion",
  accepte: "Accepté",
  decline: "Décliné",
};

export const PARTICIPANT_STATUS_LABEL: Record<string, string> = {
  invite: "Invité",
  confirme: "Confirmé",
  decline: "Décliné",
};

export function toDayKey(d: Date) {
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function monthLabel(d: Date) {
  return d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
}

export function addMonths(d: Date, n: number) {
  return new Date(d.getFullYear(), d.getMonth() + n, 1);
}

/** Grille du mois alignée sur lundi (42 cases), null pour les cases vides. */
export function monthGrid(month: Date): (Date | null)[] {
  const first = new Date(month.getFullYear(), month.getMonth(), 1);
  const offset = (first.getDay() + 6) % 7;
  const total = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells: (Date | null)[] = Array.from({ length: offset }, () => null);
  for (let i = 1; i <= total; i += 1) {
    cells.push(new Date(month.getFullYear(), month.getMonth(), i));
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export const WEEKDAYS = ["L", "M", "M", "J", "V", "S", "D"];

export function formatDateTime(iso: string) {
  return new Date(iso).toLocaleString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatDay(day: string) {
  return new Date(`${day}T12:00:00`).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}
