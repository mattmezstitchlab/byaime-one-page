import { supabase } from "@/integrations/supabase/client";

/** Retourne (ou crée) le fil de discussion entre deux membres pour une carte / intention. */
export async function ensureThread(params: {
  me: string;
  other: string;
  cardId?: string | null;
  aimeId?: string | null;
  subject?: string | null;
}) {
  const { me, other } = params;
  const { data: existing, error: readErr } = await supabase
    .from("threads")
    .select("id")
    .or(`and(user_a.eq.${me},user_b.eq.${other}),and(user_a.eq.${other},user_b.eq.${me})`)
    .limit(1)
    .maybeSingle();
  if (readErr) throw readErr;
  if (existing) return existing.id;

  const { data, error } = await supabase
    .from("threads")
    .insert({
      user_a: me,
      user_b: other,
      card_id: params.cardId ?? null,
      aime_id: params.aimeId ?? null,
      subject: params.subject ?? null,
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}

export async function sendMessage(threadId: string, senderId: string, body: string) {
  const { error } = await supabase
    .from("messages")
    .insert({ thread_id: threadId, sender_id: senderId, body });
  if (error) throw error;
  await supabase
    .from("threads")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", threadId);
}
