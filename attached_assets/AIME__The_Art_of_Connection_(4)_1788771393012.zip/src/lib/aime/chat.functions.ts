import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MODEL = "openai/gpt-5.6-sol";

const Turn = z.object({
  who: z.string().max(80),
  mine: z.boolean(),
  text: z.string().max(2000),
});

const Input = z.object({
  mode: z.enum(["suggestions", "reponse", "simplifier", "courrier", "orchestration", "resume"]),
  transcript: z.array(Turn).max(40).default([]),
  subject: z.string().max(200).nullable().optional(),
  participants: z.array(z.string().max(80)).max(20).default([]),
  tone: z.string().max(40).default("tendre"),
  translateTo: z.string().max(40).nullable().optional(),
  instruction: z.string().max(1200).nullable().optional(),
  target: z.string().max(2000).nullable().optional(),
});

export type ChatCopilot = {
  title: string;
  body: string;
  options: string[];
  note: string;
};

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["title", "body", "options", "note"],
  properties: {
    title: { type: "string" },
    body: { type: "string" },
    options: { type: "array", items: { type: "string" } },
    note: { type: "string" },
  },
} as const;

const MISSION: Record<string, string> = {
  suggestions:
    "Propose 3 réponses possibles (options) que la personne pourrait envoyer maintenant : une chaleureuse, une brève et efficace, une qui propose une date ou une suite concrète. body = ta lecture du fil en une phrase.",
  reponse:
    "Rédige la réponse à envoyer maintenant à la place de la personne, prête à être postée telle quelle (body). options = 2 variantes plus courtes. Ne signe pas, n'invente aucun engagement chiffré.",
  simplifier:
    "Reformule le message fourni (target) en français simple et clair, 3 phrases maximum (body). Si le message est dans une autre langue, traduis-le. options = les 2 points à retenir. note = l'intention réelle de l'auteur.",
  courrier:
    "Rédige un courrier / e-mail complet et professionnel prêt à envoyer à l'extérieur (body), avec objet dans title. options = 2 formulations alternatives de l'objet.",
  orchestration:
    "Tu orchestres un groupe : rédige le message à publier dans la conversation pour faire avancer tout le monde (body), en nommant qui fait quoi. options = les prochaines actions, une par personne.",
  resume:
    "Résume le fil : body = résumé en 4 lignes maximum, options = les décisions et points en attente.",
};

async function ask(apiKey: string, system: string, user: string): Promise<ChatCopilot> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      instructions: system,
      input: [{ role: "user", content: [{ type: "input_text", text: user }] }],
      text: {
        format: { type: "json_schema", name: "copilot", strict: true, schema: SCHEMA },
      },
    }),
  });

  if (!res.ok || !res.body) {
    if (res.status === 429) throw new Error("Trop de demandes, réessayez dans un instant.");
    if (res.status === 402) throw new Error("Crédits IA épuisés pour cet espace de travail.");
    throw new Error(`Aime a répondu ${res.status}.`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const raw = line.slice(5).trim();
      if (!raw || raw === "[DONE]") continue;
      try {
        const evt = JSON.parse(raw) as {
          type?: string;
          delta?: string;
          response?: { output_text?: string };
        };
        if (evt.type === "response.output_text.delta" && evt.delta) text += evt.delta;
        if (evt.type === "response.completed" && !text && evt.response?.output_text)
          text = evt.response.output_text;
      } catch {
        /* fragment non JSON */
      }
    }
  }

  if (!text.trim()) throw new Error("Aime n'a rien répondu.");
  return JSON.parse(text) as ChatCopilot;
}

/** Copilote de messagerie : suggestions, réponse à notre place, traduction simplifiée, courrier, orchestration. */
export const chatCopilot = createServerFn({ method: "POST" })
  .validator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<ChatCopilot> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Aime n'est pas configurée.");

    const system = [
      "Tu es Aime, l'agent d'AIME, copilote d'une messagerie entre membres.",
      "Ta voix : une amie qui connaît tout le monde — tendre, bienveillante, souvent drôle, parfois taquine, jamais commerciale ni robotique.",
      `Ton demandé : ${data.tone}.`,
      data.translateTo ? `Écris en ${data.translateTo}.` : "Écris en français.",
      "Tu n'inventes ni prix, ni date, ni engagement qui ne soit pas dans le fil.",
      MISSION[data.mode] ?? MISSION["suggestions"]!,
      "Réponds uniquement dans le schéma JSON demandé.",
    ].join("\n");

    const user = [
      `Sujet : ${data.subject ?? "conversation AIME"}`,
      `Participants : ${data.participants.join(", ") || "moi et mon interlocuteur"}`,
      data.instruction ? `Consigne de la personne : ${data.instruction}` : "",
      data.target ? `Message à traiter : ${data.target}` : "",
      "Fil (du plus ancien au plus récent) :",
      data.transcript.map((t) => `${t.mine ? "MOI" : t.who} : ${t.text}`).join("\n") || "(vide)",
    ]
      .filter(Boolean)
      .join("\n");

    return ask(apiKey, system, user);
  });
