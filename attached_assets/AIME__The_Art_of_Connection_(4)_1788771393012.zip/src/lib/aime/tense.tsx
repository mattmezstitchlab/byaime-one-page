import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { AimeIntent } from "./types";

/** Les trois temps d'AIME. Le cœur, lui, ne change jamais : il est hors du temps. */
export type Tense = "passe" | "present" | "futur";

export const TENSES: Tense[] = ["passe", "present", "futur"];

export type TenseDef = {
  id: Tense;
  /** Enseigne du jeu de cartes. */
  suit: "pique" | "carreau" | "trefle";
  label: string;
  verb: string;
  hint: string;
  /** Couleur du bouton « + » dans ce temps. */
  bg: string;
  ring: string;
  text: string;
};

export const TENSE: Record<Tense, TenseDef> = {
  passe: {
    id: "passe",
    suit: "pique",
    label: "Passé",
    verb: "Constater",
    hint: "Ce qui est gravé",
    bg: "bg-neutral-900",
    ring: "ring-neutral-900",
    text: "text-neutral-900",
  },
  present: {
    id: "present",
    suit: "carreau",
    label: "Présent",
    verb: "Agir",
    hint: "Ce qui s'échange",
    bg: "bg-rose-600",
    ring: "ring-rose-600",
    text: "text-rose-600",
  },
  futur: {
    id: "futur",
    suit: "trefle",
    label: "Futur",
    verb: "Prévenir",
    hint: "Ce qui peut pousser",
    bg: "bg-emerald-700",
    ring: "ring-emerald-700",
    text: "text-emerald-700",
  },
};

/** Quelles intentions ont un sens dans quel temps. */
const INTENTS_BY_TENSE: Record<Tense, AimeIntent[]> = {
  passe: ["aime", "recommander", "enregistrer"],
  present: ["aime", "contacter", "collaborer", "associer", "enregistrer"],
  futur: ["aime", "reserver", "collaborer", "associer"],
};

export function intentInTense(intent: AimeIntent | undefined, tense: Tense): boolean {
  if (!intent) return true;
  return INTENTS_BY_TENSE[tense].includes(intent);
}

/** Créations rangées par temps : une même entrée peut vivre dans deux temps. */
export const CREATE_TENSE: Record<string, Tense[]> = {
  "Une carte": ["passe", "present", "futur"],
  "Un projet": ["present", "futur"],
  "Une équipe": ["present", "futur"],
  "Une intention publique": ["present"],
  "Un moment sur ma timeline": ["passe", "present", "futur"],
  "Un document": ["passe", "present"],
  "Un devis (depuis une carte)": ["present", "futur"],
  "Une contribution": ["passe", "present", "futur"],
  "Une annonce radio": ["present", "futur"],
  "Une invitation": ["present", "futur"],
  "Un retour bêta": ["passe", "present", "futur"],
};

/* ------------------------------------------------------------------ */
/* Contexte                                                            */
/* ------------------------------------------------------------------ */

const KEY = "aime.tense";

type Ctx = { tense: Tense; setTense: (t: Tense) => void; cycle: () => void };

const TenseContext = createContext<Ctx>({
  tense: "present",
  setTense: () => {},
  cycle: () => {},
});

export function TenseProvider({ children }: { children: ReactNode }) {
  const [tense, setTenseState] = useState<Tense>("present");

  /** Lecture après hydratation : jamais dans l'initialiseur d'état. */
  useEffect(() => {
    const stored = window.localStorage.getItem(KEY);
    if (stored === "passe" || stored === "present" || stored === "futur") setTenseState(stored);
  }, []);

  const setTense = useCallback((t: Tense) => {
    setTenseState(t);
    window.localStorage.setItem(KEY, t);
  }, []);

  const cycle = useCallback(() => {
    setTenseState((prev) => {
      const next = TENSES[(TENSES.indexOf(prev) + 1) % TENSES.length]!;
      window.localStorage.setItem(KEY, next);
      return next;
    });
  }, []);

  const value = useMemo(() => ({ tense, setTense, cycle }), [tense, setTense, cycle]);
  return <TenseContext.Provider value={value}>{children}</TenseContext.Provider>;
}

export function useTense() {
  return useContext(TenseContext);
}

/* ------------------------------------------------------------------ */
/* Enseignes                                                           */
/* ------------------------------------------------------------------ */

/** Les enseignes du jeu de cartes, dessinées à la main (absentes de lucide). */
export function Suit({
  suit,
  className,
}: {
  suit: TenseDef["suit"] | "coeur";
  className?: string;
}) {
  const paths: Record<string, string> = {
    pique:
      "M12 2c2.6 3.6 8 6.7 8 11a4.6 4.6 0 0 1-7.3 3.7c.2 1.7.8 3.1 1.8 4.3H9.5c1-1.2 1.6-2.6 1.8-4.3A4.6 4.6 0 0 1 4 13c0-4.3 5.4-7.4 8-11Z",
    carreau: "M12 1.8 20.5 12 12 22.2 3.5 12 12 1.8Z",
    trefle:
      "M12 2a3.6 3.6 0 0 1 3 5.6A3.7 3.7 0 1 1 16.6 15c-.9 0-1.7-.3-2.4-.8.1 2.2.7 4.1 1.8 5.8H8c1.1-1.7 1.7-3.6 1.8-5.8-.7.5-1.5.8-2.4.8A3.7 3.7 0 1 1 9 7.6 3.6 3.6 0 0 1 12 2Z",
    coeur: "M12 21s-8-4.9-8-10.4A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8 3.6C20 16.1 12 21 12 21Z",
  };
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={className} fill="currentColor">
      <path d={paths[suit]} />
    </svg>
  );
}
