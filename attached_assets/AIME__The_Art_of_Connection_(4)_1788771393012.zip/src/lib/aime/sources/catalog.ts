/**
 * La porte universelle : la liste des sources qu'un projet peut accueillir.
 * Toutes les sources sont actives : chacune se rattache aujourd'hui par son
 * lien (agenda partagé, dossier public, profil, événement…) ou par un
 * document importé — la pièce rejoint le projet et reste lisible par la
 * Timeline, les personnes, les lieux et le Document Intelligence, sans
 * système parallèle. Le branchement direct des API viendra par-dessus.
 */
import {
  CalendarDays,
  FileText,
  Folder,
  Instagram,
  Link2,
  Linkedin,
  Mail,
  type LucideIcon,
  Facebook,
} from "lucide-react";

export type SourceKey =
  | "google-calendar"
  | "gmail"
  | "google-drive"
  | "instagram"
  | "linkedin"
  | "facebook"
  | "document"
  | "lien";

export type SourceDef = {
  key: SourceKey;
  label: string;
  icon: LucideIcon;
  /** Ce que la source apportera au projet, dit simplement. */
  hint: string;
  /** Ce qui manque pour une vraie connexion API. */
  missing?: string;
};

export const SOURCES: SourceDef[] = [
  {
    key: "google-calendar",
    label: "Google Agenda",
    icon: CalendarDays,
    hint: "Collez le lien de votre agenda partagé : la pièce rejoint le projet.",
    missing:
      "Connexion API non branchée : il faut un projet Google Cloud, OAuth Calendar, vérification d'application et stockage de jetons.",
  },
  {
    key: "gmail",
    label: "Gmail",
    icon: Mail,
    hint: "Collez le lien d'un échange : il restera une trace à valider.",
    missing:
      "Connexion API non branchée : il faut un projet Google Cloud, OAuth Gmail, consentement lecture e-mails et gestion sécurisée des jetons.",
  },
  {
    key: "google-drive",
    label: "Google Drive",
    icon: Folder,
    hint: "Collez le lien du dossier : les pièces rejoignent le projet.",
    missing:
      "Connexion API non branchée : il faut un projet Google Cloud, OAuth Drive, accès fichiers et synchronisation des permissions.",
  },
  {
    key: "instagram",
    label: "Instagram",
    icon: Instagram,
    hint: "Collez le lien d'un profil ou d'une publication : il rejoint les souvenirs.",
    missing:
      "Connexion API non branchée : il faut une app Meta développeur, permissions Instagram Graph API et revue d'application.",
  },
  {
    key: "linkedin",
    label: "LinkedIn",
    icon: Linkedin,
    hint: "Collez le lien d'un profil : la personne rejoint le réseau du projet.",
    missing:
      "Connexion API non branchée : il faut une app LinkedIn Developer, permissions profils et validation des usages API.",
  },
  {
    key: "facebook",
    label: "Facebook",
    icon: Facebook,
    hint: "Collez le lien d'un événement ou d'une page : il rejoint le projet.",
    missing:
      "Connexion API non branchée : il faut une app Meta développeur, permissions Pages/Events et revue d'application.",
  },
  {
    key: "document",
    label: "Importer un document",
    icon: FileText,
    hint: "PDF, devis, contrat, photo : la pièce reste attachée au projet.",
  },
  {
    key: "lien",
    label: "Ajouter un lien",
    icon: Link2,
    hint: "Une adresse web : page, vidéo, article, annonce.",
  },
];

export function sourceByKey(key: SourceKey): SourceDef | undefined {
  return SOURCES.find((s) => s.key === key);
}
