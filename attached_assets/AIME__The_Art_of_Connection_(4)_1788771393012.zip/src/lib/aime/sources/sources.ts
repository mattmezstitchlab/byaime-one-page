/**
 * Rattacher une source à un projet.
 * On réutilise les pièces existantes (`media_items`) : une source est une
 * pièce du projet, donc elle est déjà lisible par les médias, les documents
 * et la ligne de temps. Aucune donnée n'est inventée ni ajoutée d'office.
 */
import { supabase } from "@/integrations/supabase/client";
import { addMedia, mediaQuery, uploadMediaFile, type MediaItem } from "@/lib/aime/media";
import type { SourceKey } from "./catalog";

export type NewSource = {
  key: Extract<SourceKey, "document" | "lien">;
  url: string;
  title?: string | null;
};

const PENDING_KEY = "aime.project.sources.pending.v1";

/** Une source posée avant que le projet n'existe (accueil). */
export function pendingSources(): NewSource[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(PENDING_KEY);
    return raw ? (JSON.parse(raw) as NewSource[]) : [];
  } catch {
    return [];
  }
}

export function addPendingSource(source: NewSource) {
  if (typeof window === "undefined") return;
  const next = [...pendingSources(), source];
  window.localStorage.setItem(PENDING_KEY, JSON.stringify(next));
}

export function removePendingSource(index: number) {
  if (typeof window === "undefined") return;
  const next = pendingSources().filter((_, i) => i !== index);
  window.localStorage.setItem(PENDING_KEY, JSON.stringify(next));
}

export function clearPendingSources() {
  if (typeof window !== "undefined") window.localStorage.removeItem(PENDING_KEY);
}

/** Les sources d'un projet : les pièces rattachées sous forme de lien. */
export function projectSourcesQuery(eventId: string) {
  const base = mediaQuery({ eventId });
  return {
    queryKey: ["project-sources", eventId] as const,
    enabled: !!eventId,
    queryFn: async (): Promise<MediaItem[]> => {
      const items = await base.queryFn();
      return items.filter((m) => m.kind === "lien");
    },
  };
}

export async function attachSource(eventId: string, source: NewSource, userId: string | null) {
  const { count } = await supabase
    .from("media_items")
    .select("id", { count: "exact", head: true })
    .eq("event_id", eventId);
  await addMedia({ eventId }, { kind: "lien", url: source.url, title: source.title ?? null }, userId, count ?? 0);
}

/** Au moment où le projet naît, les sources posées à l'accueil le rejoignent. */
export async function flushPendingSources(eventId: string, userId: string | null) {
  const list = pendingSources();
  if (!list.length) return;
  for (const source of list) {
    try {
      await attachSource(eventId, source, userId);
    } catch {
      /* une source manquée ne doit jamais empêcher l'ouverture du projet */
    }
  }
  clearPendingSources();
}

export async function uploadSourceFile(userId: string, file: File) {
  const url = await uploadMediaFile(userId, file);
  return { key: "document" as const, url, title: file.name };
}
