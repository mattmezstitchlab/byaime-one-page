/** Coordonnées approximatives des villes du réseau AIME (Hauts-de-France et alentours). */
export const CITY_COORDS: Record<string, [number, number]> = {
  lille: [50.6292, 3.0573],
  roubaix: [50.6942, 3.1746],
  tourcoing: [50.7236, 3.1611],
  villeneuvedascq: [50.6221, 3.1301],
  lambersart: [50.65, 3.0244],
  marcqenbaroeul: [50.6739, 3.0937],
  seclin: [50.5486, 3.0289],
  armentieres: [50.6889, 2.8811],
  lens: [50.4292, 2.8318],
  arras: [50.291, 2.7778],
  bethune: [50.5303, 2.6407],
  douai: [50.3714, 3.08],
  valenciennes: [50.3579, 3.5234],
  cambrai: [50.1768, 3.2359],
  dunkerque: [51.0344, 2.3768],
  calais: [50.9513, 1.8587],
  boulognesurmer: [50.7264, 1.6136],
  saintomer: [50.7478, 2.2523],
  amiens: [49.8941, 2.2958],
  compiegne: [49.4179, 2.8261],
  beauvais: [49.43, 2.0809],
  soissons: [49.3817, 3.3236],
  laon: [49.5641, 3.6216],
  saintquentin: [49.8486, 3.2864],
  paris: [48.8566, 2.3522],
  bruxelles: [50.8503, 4.3517],
  croix: [50.6786, 3.1503],
  bondues: [50.7047, 3.0958],
  hem: [50.6567, 3.1878],
  avelin: [50.5219, 3.0961],
  cappelleenpevele: [50.5069, 3.1836],
  boeschepe: [50.7908, 2.6664],
  cassel: [50.8006, 2.4869],
  busnes: [50.5731, 2.5261],
  lamadelainesousmontreuil: [50.4636, 1.7461],
  montreuilsurmer: [50.4642, 1.7628],
  hazebrouck: [50.7239, 2.5389],
  maubeuge: [50.2789, 3.9725],
  wambrechies: [50.6828, 3.0489],
  lesquin: [50.5867, 3.1122],
  // Monde

  london: [51.5074, -0.1278],
  londres: [51.5074, -0.1278],
  newyork: [40.7128, -74.006],
  losangeles: [34.0522, -118.2437],
  seattle: [47.6062, -122.3321],
  sanmateo: [37.563, -122.3255],
  chicago: [41.8781, -87.6298],
  boulder: [40.015, -105.2705],
  englewood: [39.6478, -104.9878],
  herndon: [38.9696, -77.3861],
  portland: [45.5152, -122.6784],
  atlanta: [33.749, -84.388],
  washington: [38.9072, -77.0369],
  lasvegas: [36.1699, -115.1398],
  quebec: [46.8139, -71.208],
  montreal: [45.5019, -73.5674],
  berlin: [52.52, 13.405],
  wetzlar: [50.5548, 8.5008],
  vienne: [48.2082, 16.3738],
  geneve: [46.2044, 6.1432],
  gland: [46.4206, 6.2694],
  montreux: [46.4312, 6.9107],
  zurich: [47.3769, 8.5417],
  madrid: [40.4168, -3.7038],
  barcelone: [41.3874, 2.1686],
  pampelune: [42.8125, -1.6458],
  gerone: [41.9794, 2.8214],
  lisbonne: [38.7223, -9.1393],
  rome: [41.9028, 12.4964],
  florence: [43.7696, 11.2558],
  milan: [45.4642, 9.19],
  cernobbio: [45.8419, 9.0764],
  amsterdam: [52.3676, 4.9041],
  sittard: [51.0016, 5.8697],
  copenhague: [55.6761, 12.5683],
  stockholm: [59.3293, 18.0686],
  helsinki: [60.1699, 24.9384],
  boom: [51.0894, 4.3714],
  chantilly: [49.1936, 2.4707],
  nice: [43.7102, 7.262],
  lyon: [45.764, 4.8357],
  marseille: [43.2965, 5.3698],
  bordeaux: [44.8378, -0.5792],
  tokyo: [35.6762, 139.6503],
  singapour: [1.3521, 103.8198],
  bangkok: [13.7563, 100.5018],
  sydney: [-33.8688, 151.2093],
  melbourne: [-37.8136, 144.9631],
  dubai: [25.2048, 55.2708],
  casablanca: [33.5731, -7.5898],
  marrakech: [31.6295, -7.9811],
  dakar: [14.7167, -17.4677],
  saopaulo: [-23.5505, -46.6333],
  mexico: [19.4326, -99.1332],
};

export const DEFAULT_CENTER: [number, number] = [50.6292, 3.0573];

function normalize(city: string) {
  return city
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z]/g, "");
}

/** Position stable (léger décalage déterministe pour éviter les marqueurs superposés). */
export function coordsFor(city: string | null | undefined, seed = ""): [number, number] | null {
  if (!city) return null;
  const base = CITY_COORDS[normalize(city)];
  if (!base) return null;
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) % 1000;
  const jitter = ((h % 100) / 100 - 0.5) * 0.02;
  const jitter2 = ((Math.floor(h / 100) % 10) / 10 - 0.5) * 0.03;
  return [base[0] + jitter, base[1] + jitter2];
}

/** Position d'une carte : coordonnées réelles si connues, sinon repli sur la ville. */
export function cardCoords(card: {
  id: string;
  city?: string | null;
  lat?: number | null;
  lon?: number | null;
}): [number, number] | null {
  if (typeof card.lat === "number" && typeof card.lon === "number") return [card.lat, card.lon];
  return coordsFor(card.city, card.id);
}

/** Distance approximative en km entre deux points. */
export function distanceKm(a: [number, number], b: [number, number]) {
  const R = 6371;
  const dLat = ((b[0] - a[0]) * Math.PI) / 180;
  const dLon = ((b[1] - a[1]) * Math.PI) / 180;
  const lat1 = (a[0] * Math.PI) / 180;
  const lat2 = (b[0] * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.sin(dLon / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(h));
}
