/**
 * L'agent de la ligne de temps : il lit le projet réel (le même modèle que
 * l'affichage, aucune donnée recopiée), répond en français, puis commande
 * l'interface — calques à activer, période à cadrer, repères à mettre en avant.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MODEL = "openai/gpt-5.6-sol";

const Item = z.object({
  id: z.string().max(120),
  quoi: z.string().max(120),
  titre: z.string().max(200),
  quand: z.string().max(40),
  etat: z.string().max(40),
  montant: z.string().max(40).nullable().optional(),
});

const Input = z.object({
  question: z.string().min(1).max(600),
  projet: z.object({
    titre: z.string().max(200),
    jourJ: z.string().max(40),
    lieu: z.string().max(200),
    invites: z.number().nullable().optional(),
    engage: z.string().max(40),
    paye: z.string().max(40),
    reste: z.string().max(40),
    aPourvoir: z.array(z.string().max(120)).max(30).default([]),
  }),
  items: z.array(Item).max(220).default([]),
  fenetre: z.object({ de: z.string().max(40), a: z.string().max(40) }).nullable().optional(),
});

export type TimelineAnswer = {
  reponse: string;
  calques: string[];
  focusDe: string | null;
  focusA: string | null;
  cibles: string[];
};

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["reponse", "calques", "focusDe", "focusA", "cibles"],
  properties: {
    reponse: { type: "string" },
    calques: {
      type: "array",
      items: {
        type: "string",
        enum: [
          "rdv",
          "tache",
          "document",
          "finance",
          "personne",
          "musique",
          "photo",
          "video",
          "souvenir",
          "message",
          "narration",
        ],
      },
    },
    focusDe: { type: ["string", "null"] },
    focusA: { type: ["string", "null"] },
    cibles: { type: "array", items: { type: "string" } },
  },
} as const;

const SYSTEM = `Tu es AIME, l'agent d'un projet représenté par une seule ligne de temps.
Tu reçois le projet et la liste de ses repères (identifiant, nature, titre, date, état, montant).
Réponds en français, en 3 phrases maximum, avec des chiffres exacts tirés des repères fournis.
N'invente jamais un repère, un montant ou une date.
"calques" : les familles à activer pour illustrer la réponse (vide = tout montrer).
"focusDe"/"focusA" : la période à cadrer, au format AAAA-MM-JJ (null si toute la ligne convient).
"cibles" : les identifiants exacts des repères à mettre en avant (5 maximum).
Si l'utilisateur demande ce qui manque, appuie-toi sur les places à pourvoir et les repères "À valider" ou "En attente".`;

async function askGateway(apiKey: string, user: string): Promise<TimelineAnswer> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      store: false,
      instructions: SYSTEM,
      input: [{ role: "user", content: [{ type: "input_text", text: user }] }],
      text: { format: { type: "json_schema", name: "timeline", strict: true, schema: SCHEMA } },
    }),
  });

  if (!res.ok || !res.body) {
    if (res.status === 429) throw new Error("Trop de demandes, réessayez dans un instant.");
    if (res.status === 402) throw new Error("Crédits IA épuisés pour cet espace.");
    throw new Error(`AIME a répondu ${res.status}.`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const event = JSON.parse(payload) as {
          type?: string;
          delta?: string;
          response?: { output_text?: string };
        };
        if (event.type === "response.output_text.delta" && typeof event.delta === "string") {
          text += event.delta;
        } else if (event.type === "response.completed" && event.response?.output_text) {
          text = event.response.output_text;
        }
      } catch {
        /* fragment SSE incomplet */
      }
    }
  }

  try {
    const parsed = JSON.parse(text) as TimelineAnswer;
    return {
      reponse: parsed.reponse ?? "",
      calques: Array.isArray(parsed.calques) ? parsed.calques : [],
      focusDe: parsed.focusDe ?? null,
      focusA: parsed.focusA ?? null,
      cibles: Array.isArray(parsed.cibles) ? parsed.cibles.slice(0, 5) : [],
    };
  } catch {
    throw new Error("AIME n'a pas pu formuler de réponse.");
  }
}

export const askTimeline = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<TimelineAnswer> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Clé IA absente.");

    const user = [
      `Question : ${data.question}`,
      data.fenetre ? `Période regardée : du ${data.fenetre.de} au ${data.fenetre.a}` : "",
      `Projet : ${data.projet.titre} · jour J ${data.projet.jourJ} · ${data.projet.lieu}` +
        (data.projet.invites ? ` · ${data.projet.invites} invités` : ""),
      `Argent : ${data.projet.engage} engagés, ${data.projet.paye} payés, ${data.projet.reste} restants.`,
      data.projet.aPourvoir.length
        ? `Places à pourvoir : ${data.projet.aPourvoir.join(", ")}`
        : "Toutes les places sont pourvues.",
      "Repères :",
      ...data.items.map(
        (i) =>
          `- ${i.id} | ${i.quoi} | ${i.titre} | ${i.quand} | ${i.etat}${i.montant ? ` | ${i.montant}` : ""}`,
      ),
    ]
      .filter(Boolean)
      .join("\n");

    return askGateway(apiKey, user);
  });
