import type { TimelineMarker } from "@/components/aime/HeroTimeline";

/**
 * Les deux boussoles de la ligne de temps :
 * « Que dois-je faire ? » et « Que manque-t-il ? ».
 * Calcul purement local sur les objets déjà chargés : aucune requête en plus.
 */

const DAY = 86_400_000;

export type AuditItem = {
  id: string;
  label: string;
  detail?: string | undefined;
  time?: number;
  /** 2 = urgent, 1 = à surveiller, 0 = information. */
  severity: 0 | 1 | 2;
  marker?: TimelineMarker;
};

export type TimelineAudit = {
  todo: AuditItem[];
  missing: AuditItem[];
  anomalies: AuditItem[];
  money: {
    prevu: number;
    engage: number;
    facture: number;
    paye: number;
    restant: number;
    retard: number;
  };
};

const amount = (m: TimelineMarker) => (m.amountCents ?? 0) / 100;

export function auditTimeline(markers: TimelineMarker[], now = Date.now()): TimelineAudit {
  const todo: AuditItem[] = [];
  const missing: AuditItem[] = [];
  const anomalies: AuditItem[] = [];

  let prevu = 0;
  let engage = 0;
  let facture = 0;
  let paye = 0;
  let retard = 0;

  for (const m of markers) {
    // Argent
    if (m.kind === "devis") {
      prevu += amount(m);
      if (m.status === "execute") engage += amount(m);
    }
    if (m.kind === "facture") facture += amount(m);
    if (m.kind === "paiement") paye += amount(m);

    // À faire
    if (m.kind === "tache" && !m.done) {
      const due = m.dueAt ?? m.time;
      const late = due < now;
      todo.push({
        id: m.id,
        label: m.title,
        detail: late ? "En retard" : undefined,
        time: due,
        severity: late ? 2 : due - now < 7 * DAY ? 1 : 0,
        marker: m,
      });
    }
    if (m.status === "a_valider") {
      todo.push({
        id: `valider-${m.id}`,
        label: `À valider : ${m.title}`,
        time: m.time,
        severity: 1,
        marker: m,
      });
    }
    if (m.status === "bloque" || m.status === "echoue") {
      anomalies.push({
        id: `bloque-${m.id}`,
        label: `${m.status === "bloque" ? "Bloqué" : "Échoué"} : ${m.title}`,
        time: m.time,
        severity: 2,
        marker: m,
      });
    }

    // Échéances d'argent dépassées
    if (m.kind === "facture" && m.dueAt && m.dueAt < now && m.status !== "execute") {
      retard += amount(m);
      anomalies.push({
        id: `retard-${m.id}`,
        label: `Facture en retard : ${m.title}`,
        time: m.dueAt,
        severity: 2,
        marker: m,
      });
    }
  }

  // Chaînes incomplètes : devis sans facture, facture sans paiement.
  const invoices = markers.filter((m) => m.kind === "facture");
  const payments = markers.filter((m) => m.kind === "paiement");
  for (const q of markers.filter((m) => m.kind === "devis" && m.status === "execute")) {
    const linked = invoices.some((f) => f.relatedIds?.includes(q.id) || q.relatedIds?.includes(f.id));
    if (!linked)
      missing.push({
        id: `sansfacture-${q.id}`,
        label: `Devis accepté sans facture : ${q.title}`,
        time: q.time,
        severity: 1,
        marker: q,
      });
  }
  for (const f of invoices) {
    const paid = payments.some((p) => p.relatedIds?.includes(f.id) || f.relatedIds?.includes(p.id));
    if (!paid && f.status !== "execute")
      missing.push({
        id: `sanspaiement-${f.id}`,
        label: `Facture sans paiement : ${f.title}`,
        time: f.time,
        severity: f.time < now - 30 * DAY ? 2 : 1,
        marker: f,
      });
  }

  // Écarts de montants entre devis et facture reliés.
  for (const f of invoices) {
    const q = markers.find(
      (m) => m.kind === "devis" && (f.relatedIds?.includes(m.id) || m.relatedIds?.includes(f.id)),
    );
    if (q && Math.abs(amount(q) - amount(f)) > 1)
      anomalies.push({
        id: `ecart-${f.id}`,
        label: `Écart devis / facture : ${f.title}`,
        detail: `${amount(q).toFixed(2)} € prévus, ${amount(f).toFixed(2)} € facturés`,
        time: f.time,
        severity: 2,
        marker: f,
      });
  }

  // Événement proche sans prestataire ni document.
  for (const e of markers.filter((m) => m.kind === "evenement")) {
    if (e.time < now || e.time - now > 60 * DAY) continue;
    const around = markers.filter(
      (m) => m.id !== e.id && Math.abs(m.time - e.time) < 30 * DAY && m.kind !== "evenement",
    );
    if (around.length === 0)
      missing.push({
        id: `nu-${e.id}`,
        label: `Rien de préparé autour de : ${e.title}`,
        time: e.time,
        severity: 1,
        marker: e,
      });
  }

  const byTime = (a: AuditItem, b: AuditItem) =>
    b.severity - a.severity || (a.time ?? 0) - (b.time ?? 0);

  return {
    todo: todo.sort(byTime).slice(0, 12),
    missing: missing.sort(byTime).slice(0, 12),
    anomalies: anomalies.sort(byTime).slice(0, 12),
    money: {
      prevu,
      engage,
      facture,
      paye,
      restant: Math.max(0, facture - paye),
      retard,
    },
  };
}
