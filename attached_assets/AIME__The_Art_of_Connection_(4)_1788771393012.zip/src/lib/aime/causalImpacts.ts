import { supabase } from "@/integrations/supabase/client";
import type { CausalLink } from "@/lib/aime/causal";

/**
 * Accepter une onde : l'humain décide, puis l'impact devient un repère de timeline
 * et un effet lisible dans la Fréquence. Rien n'est écrit sans cette validation.
 */
export async function acceptWave(params: {
  cardId: string;
  eventId?: string | null;
  variable: string;
  wave: CausalLink;
  startsAt: string;
}) {
  const { data: entry, error } = await supabase
    .from("card_timeline_entries")
    .insert({
      card_id: params.cardId,
      kind: "onde",
      title: `${params.variable} → ${params.wave.to}`,
      description: params.wave.effect,
      starts_at: params.startsAt,
      is_public: false,
      link_event_id: params.eventId ?? null,
    })
    .select("id")
    .single();
  if (error) throw error;

  const { error: effectError } = await supabase.from("timeline_effects").insert({
    entry_id: entry.id,
    card_id: params.cardId,
    nature: "Étape",
    direction: "neutre",
    source: "estime",
    confidence: "moyenne",
    note: `Onde ${params.wave.wave} depuis « ${params.variable} ».`,
  });
  if (effectError) throw effectError;

  return entry.id;
}
