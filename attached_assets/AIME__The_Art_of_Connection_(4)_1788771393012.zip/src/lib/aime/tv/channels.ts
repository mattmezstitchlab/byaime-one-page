import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { youtubeEmbed, youtubeThumb } from "@/lib/aime/media";

/** Les trois chaînes d'AIME TV : avant, pendant, après. */
export type TvChannel = "preparatifs" | "jour-j" | "memory";

export const TV_CHANNELS: { key: TvChannel; label: string; hint: string }[] = [
  { key: "preparatifs", label: "Les préparatifs", hint: "Tout ce qui précède le jour J" },
  { key: "jour-j", label: "Jour J", hint: "Ce qui se passe pendant, en direct des invités" },
  { key: "memory", label: "Memory", hint: "L'après : souvenirs et film du projet" },
];

export const CHANNEL_LABEL: Record<TvChannel, string> = Object.fromEntries(
  TV_CHANNELS.map((c) => [c.key, c.label]),
) as Record<TvChannel, string>;

/** Un passage à l'antenne : une photo ou une vidéo, jamais autre chose. */
export type TvItem = {
  id: string;
  kind: "photo" | "video" | "youtube";
  url: string;
  /** Adresse à mettre dans une fenêtre YouTube, le cas échéant. */
  embed?: string | null;
  thumb?: string | null;
  title: string;
  /** Moment du dépôt (ms epoch). */
  at: number;
};

const DAY = 86_400_000;

function startOfDay(ms: number) {
  const d = new Date(ms);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/** À quelle chaîne appartient un média, selon la date du projet. */
export function channelOf(at: number, eventStart: number): TvChannel {
  const day = startOfDay(eventStart);
  if (at < day) return "preparatifs";
  if (at < day + DAY) return "jour-j";
  return "memory";
}

const FR = new Intl.DateTimeFormat("fr-FR", {
  day: "numeric",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
});

export function tvCaption(item: TvItem) {
  return `${FR.format(new Date(item.at))} · ${item.title}`;
}

/** Mélange : la TV n'annonce jamais deux fois le même ordre. */
export function shuffled<T>(list: T[]): T[] {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}

/**
 * La matière d'une chaîne : les photos et vidéos du projet, rangées
 * avant / pendant / après selon la date du projet. Rien n'est ajouté :
 * on ne montre que ce qui a déjà été déposé.
 */
export function tvChannelQuery(eventId: string | null, channel: TvChannel) {
  return queryOptions({
    queryKey: ["aime-tv", eventId, channel] as const,
    enabled: !!eventId,
    staleTime: 30_000,
    queryFn: async (): Promise<TvItem[]> => {
      const { data: event, error: evErr } = await supabase
        .from("events")
        .select("id, starts_at")
        .eq("id", eventId!)
        .maybeSingle();
      if (evErr) throw evErr;
      const eventStart = event?.starts_at ? new Date(event.starts_at).getTime() : Date.now();

      const { data, error } = await supabase
        .from("media_items")
        .select("*")
        .eq("event_id", eventId!)
        .order("created_at", { ascending: true });
      if (error) throw error;

      return (data ?? [])
        .filter((m) => m.kind === "photo" || m.kind === "video" || m.kind === "youtube")
        .map((m): TvItem => {
          const at = new Date(m.created_at).getTime();
          return {
            id: m.id,
            kind: m.kind as TvItem["kind"],
            url: m.url,
            embed: m.kind === "youtube" ? youtubeEmbed(m.url) : null,
            thumb: m.thumb_url ?? (m.kind === "youtube" ? youtubeThumb(m.url) : m.url),
            title: m.title ?? (m.kind === "video" ? "Vidéo" : "Photo"),
            at,
          };
        })
        .filter((item) => channelOf(item.at, eventStart) === channel);
    },
  });
}
