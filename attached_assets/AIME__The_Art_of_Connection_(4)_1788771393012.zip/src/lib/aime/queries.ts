import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Card, Category, Universe } from "./types";

export const cardsQuery = queryOptions({
  queryKey: ["cards"],
  queryFn: async (): Promise<Card[]> => {
    const { data, error } = await supabase
      .from("cards")
      .select("*")
      .eq("published", true)
      .order("rating", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
  staleTime: 60_000,
});

export const categoriesQuery = queryOptions({
  queryKey: ["categories"],
  queryFn: async (): Promise<Category[]> => {
    const { data, error } = await supabase.from("categories").select("*").order("sort_order");
    if (error) throw error;
    return data ?? [];
  },
  staleTime: 5 * 60_000,
});

export const universesQuery = queryOptions({
  queryKey: ["universes"],
  queryFn: async (): Promise<Universe[]> => {
    const { data, error } = await supabase.from("universes").select("*").order("sort_order");
    if (error) throw error;
    return data ?? [];
  },
  staleTime: 5 * 60_000,
});

export function aimesQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["aimes", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("aimes")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function encountersQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["encounters", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("encounters")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function compositionsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["compositions", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("compositions")
        .select("*, composition_items(*)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function profileQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["profile", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select(
          "id, display_name, city, headline, avatar_url, created_at, updated_at, radio_radius_km, geo_consent, locale, a11y",
        )
        .eq("id", userId!)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const { data: geo } = await supabase
        .from("profile_geo")
        .select("lat, lon")
        .eq("id", userId!)
        .maybeSingle();
      return { ...data, lat: geo?.lat ?? null, lon: geo?.lon ?? null };
    },
  });
}

export function myCardQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["my-card", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Card | null> => {
      const { data, error } = await supabase
        .from("cards")
        .select("*")
        .eq("owner_id", userId!)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function myCardsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["my-cards", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Card[]> => {
      const { data, error } = await supabase
        .from("cards")
        .select("*")
        .eq("owner_id", userId!)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function availabilityQuery(cardIds: string[]) {
  const key = [...cardIds].sort();
  return queryOptions({
    queryKey: ["availability", key],
    enabled: key.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("card_availability")
        .select("*")
        .in("card_id", key)
        .order("day");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

export function receivedAimesQuery(cardId: string | null | undefined) {
  return queryOptions({
    queryKey: ["card-aimes", cardId],
    enabled: !!cardId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("aimes")
        .select("*")
        .eq("card_id", cardId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const rows = data ?? [];
      const ids = [...new Set(rows.map((r) => r.user_id))];
      if (ids.length === 0) return rows.map((r) => ({ ...r, author: null as string | null }));
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, display_name")
        .in("id", ids);
      const byId = new Map((profs ?? []).map((p) => [p.id, p.display_name]));
      return rows.map((r) => ({ ...r, author: byId.get(r.user_id) ?? null }));
    },
  });
}

export function eventsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["events", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("*, event_participants(*)")
        .order("starts_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function cardQuery(id: string) {
  return queryOptions({
    queryKey: ["card", id],
    queryFn: async (): Promise<Card | null> => {
      const { data, error } = await supabase.from("cards").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
    staleTime: 60_000,
  });
}

export function cardReviewsQuery(id: string) {
  return queryOptions({
    queryKey: ["card-reviews", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reviews")
        .select("*")
        .eq("card_id", id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

export function timelineQuery(cardId: string) {
  return queryOptions({
    queryKey: ["card-timeline", cardId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("card_timeline_entries")
        .select("*")
        .eq("card_id", cardId)
        .order("starts_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function cardContactQuery(cardId: string | null | undefined) {
  return queryOptions({
    queryKey: ["card-contact", cardId],
    enabled: !!cardId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("card_contacts")
        .select("*")
        .eq("card_id", cardId!)
        .maybeSingle();
      if (error) return null;
      return data;
    },
  });
}

export function serviceRatesQuery(cardId: string | null | undefined) {
  return queryOptions({
    queryKey: ["service-rates", cardId],
    enabled: !!cardId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_rates")
        .select("*")
        .eq("card_id", cardId!)
        .order("month", { nullsFirst: false });
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

export function allRatesQuery(cardIds: string[]) {
  const key = [...cardIds].sort();
  return queryOptions({
    queryKey: ["service-rates-many", key],
    enabled: key.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.from("service_rates").select("*").in("card_id", key);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });
}

export function eventQuery(id: string) {
  return queryOptions({
    queryKey: ["event", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("*, event_participants(*)")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function paymentsQuery(eventId: string) {
  return queryOptions({
    queryKey: ["event-payments", eventId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("event_payments")
        .select("*")
        .eq("event_id", eventId)
        .order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function invitationsQuery(eventId: string) {
  return queryOptions({
    queryKey: ["event-invitations", eventId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("event_invitations")
        .select("*")
        .eq("event_id", eventId)
        .order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function threadsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["threads", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("threads")
        .select("*, messages(id, body, sender_id, created_at, read_at)")
        .order("last_message_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function threadQuery(threadId: string | null) {
  return queryOptions({
    queryKey: ["thread", threadId],
    enabled: !!threadId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("thread_id", threadId!)
        .order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export const intentionsQuery = queryOptions({
  queryKey: ["intentions"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("intentions")
      .select("*")
      .eq("published", true)
      .order("created_at", { ascending: false })
      .limit(40);
    if (error) throw error;
    return data ?? [];
  },
  staleTime: 30_000,
});

export function musicboxQuery(scope: { cardId?: string | null; eventId?: string | null }) {
  const cardId = scope.cardId ?? null;
  const eventId = scope.eventId ?? null;
  return queryOptions({
    queryKey: ["musicbox", cardId, eventId],
    enabled: !!(cardId || eventId),
    queryFn: async () => {
      let q = supabase.from("musicbox_entries").select("*");
      if (eventId) q = q.eq("event_id", eventId);
      else q = q.eq("card_id", cardId!);
      const { data, error } = await q.order("day").order("start_time");
      if (error) throw error;
      return data ?? [];
    },
  });
}


export function allPaymentsQuery(eventIds: string[]) {
  return queryOptions({
    queryKey: ["event-payments-many", [...eventIds].sort().join(",")],
    enabled: eventIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("event_payments")
        .select("*")
        .in("event_id", eventIds);
      if (error) throw error;
      return data ?? [];
    },
  });
}

/** Mes devis, tous statuts confondus (panneaux AI et ME). */
export function myQuotesQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["my-quotes", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quotes")
        .select("id,title,status,total,target_date,created_at")
        .eq("user_id", userId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}
