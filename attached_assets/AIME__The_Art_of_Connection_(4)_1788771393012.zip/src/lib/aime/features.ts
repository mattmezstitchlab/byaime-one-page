/**
 * Catalogue unique des fonctions qui consomment de l'IA ou une contrepartie.
 *
 * Règle : une étiquette ne s'affiche que là où le mécanisme existe vraiment.
 *  - « up »  : la fonction appelle l'IA. Gratuite pendant la bêta, mais journalisée.
 *  - « pro » : la fonction demande d'avoir créé sa page.
 */
export type FeatureTag = "up" | "pro";

export type Feature = {
  key: string;
  label: string;
  tag: FeatureTag;
  credits: number;
  /** Nœud du système nerveux concerné, pour rattacher les incidents. */
  node?: string;
};

export const FEATURES = {
  composer: {
    key: "composer",
    label: "Composer une rencontre",
    tag: "up",
    credits: 4,
    node: "rencontres",
  },
  roadmap: { key: "roadmap", label: "Feuille de route", tag: "up", credits: 3, node: "accueil" },
  document: {
    key: "document",
    label: "Lecture d'un document",
    tag: "up",
    credits: 3,
    node: "bureau",
  },
  translate: {
    key: "translate",
    label: "Traduction d'un message",
    tag: "up",
    credits: 1,
    node: "messages",
  },
  chat: { key: "chat", label: "Réponse déléguée à Aime", tag: "up", credits: 2, node: "messages" },
  radio: { key: "radio", label: "Annonce de fréquence", tag: "up", credits: 2, node: "radio" },
  enrich: {
    key: "enrich",
    label: "Qualification d'une carte",
    tag: "up",
    credits: 3,
    node: "registre",
  },
  cardReport: {
    key: "cardReport",
    label: "Rapport IA de ma carte",
    tag: "up",
    credits: 2,
    node: "ma-carte",
  },
  weather: { key: "weather", label: "Météo du projet", tag: "up", credits: 2, node: "projets" },
  intermittent: {
    key: "intermittent",
    label: "Cockpit intermittent",
    tag: "up",
    credits: 2,
    node: "intermittent",
  },
  cardImage: {
    key: "cardImage",
    label: "Image de profil générée",
    tag: "pro",
    credits: 0,
    node: "ma-carte",
  },
  cardVideo: {
    key: "cardVideo",
    label: "Portrait animé",
    tag: "pro",
    credits: 0,
    node: "ma-carte",
  },
} as const satisfies Record<string, Feature>;

export type FeatureKey = keyof typeof FEATURES;

export const TAG_HELP: Record<FeatureTag, string> = {
  up: "Cette action fait travailler Aime. Gratuite pendant la bêta, elle est simplement comptée dans votre journal.",
  pro: "Cette action est réservée aux membres qui ont créé leur page.",
};
