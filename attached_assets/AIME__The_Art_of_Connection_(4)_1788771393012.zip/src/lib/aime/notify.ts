/**
 * Les alertes du navigateur : un message ou un document arrive, on le sait
 * même quand l'onglet est ailleurs. Rien n'est envoyé sans accord explicite.
 */
const KEY = "aime:notifications";

export type NotifyState = "prete" | "refusee" | "a-demander" | "onglet" | "impossible";

export function notifyState(): NotifyState {
  if (typeof window === "undefined" || !("Notification" in window)) return "impossible";
  if (window.top !== window.self) return "onglet";
  if (Notification.permission === "granted") return "prete";
  if (Notification.permission === "denied") return "refusee";
  return "a-demander";
}

export function notifyEnabled() {
  if (typeof localStorage === "undefined") return false;
  return localStorage.getItem(KEY) === "on" && notifyState() === "prete";
}

/** Demande l'autorisation depuis un clic ; renvoie l'état obtenu. */
export async function enableNotifications(): Promise<NotifyState> {
  const state = notifyState();
  if (state === "impossible" || state === "onglet" || state === "refusee") return state;
  const permission =
    Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
  if (permission !== "granted") return "refusee";
  localStorage.setItem(KEY, "on");
  return "prete";
}

export function disableNotifications() {
  localStorage.setItem(KEY, "off");
}

/** Une alerte discrète, doublée d'un petit son. */
export function notify(title: string, body: string) {
  if (!notifyEnabled()) return;
  try {
    const n = new Notification(title, { body, icon: "/favicon.ico", tag: title });
    n.onclick = () => {
      window.focus();
      n.close();
    };
    ping();
  } catch {
    /* le navigateur peut refuser en silence */
  }
}

/** Petit son de notification, sans fichier à charger. */
export function ping() {
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    const ctx = new Ctor();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.3);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.32);
    setTimeout(() => void ctx.close(), 500);
  } catch {
    /* son indisponible */
  }
}
