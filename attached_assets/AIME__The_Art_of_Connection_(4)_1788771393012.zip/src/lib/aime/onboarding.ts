import { supabase } from "@/integrations/supabase/client";
import type { Card } from "@/lib/aime/types";

/**
 * La page personnelle existe dès la création du compte.
 * Si elle manque (compte créé avant, ou inscription par Google), on la crée ici.
 */
export async function ensureMyCard(userId: string, fallbackName?: string): Promise<Card> {
  const { data: existing, error: readError } = await supabase
    .from("cards")
    .select("*")
    .eq("owner_id", userId)
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle();
  if (readError) throw readError;
  if (existing) return existing as Card;

  const name = (fallbackName ?? "").trim() || "Ma page";
  const { data, error } = await supabase
    .from("cards")
    .insert({
      owner_id: userId,
      name,
      category_slug: "personne",
      kind: "personne",
      headline: "",
      published: true,
    } as never)
    .select("*")
    .single();
  if (error) throw error;
  return data as Card;
}

/** Le nom lisible d'un compte, tel qu'il a été saisi à l'inscription. */
export function displayNameOf(user: { email?: string | null; user_metadata?: Record<string, unknown> } | null) {
  if (!user) return "";
  const meta = user.user_metadata ?? {};
  const name = (meta["display_name"] ?? meta["full_name"] ?? meta["name"]) as string | undefined;
  if (name && name.trim()) return name.trim();
  return (user.email ?? "").split("@")[0] ?? "";
}
