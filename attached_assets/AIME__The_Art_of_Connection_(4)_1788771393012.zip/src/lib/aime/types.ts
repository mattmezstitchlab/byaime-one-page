import type { Database } from "@/integrations/supabase/types";

export type Card = Database["public"]["Tables"]["cards"]["Row"];
export type Category = Database["public"]["Tables"]["categories"]["Row"];
export type Universe = Database["public"]["Tables"]["universes"]["Row"];
export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type Composition = Database["public"]["Tables"]["compositions"]["Row"];
export type CompositionItem = Database["public"]["Tables"]["composition_items"]["Row"];
export type Encounter = Database["public"]["Tables"]["encounters"]["Row"];
export type AimeIntent = Database["public"]["Enums"]["aime_intent"];
export type CardStatus = Database["public"]["Enums"]["card_status"];
export type CardKind = Database["public"]["Enums"]["card_kind"];

export const STATUS_LABEL: Record<CardStatus, string> = {
  disponible: "Disponible",
  indisponible: "Indisponible",
  nouveau: "Nouveau",
  populaire: "Populaire",
  recommande: "Recommandé",
};

export const KIND_LABEL: Record<CardKind, string> = {
  personne: "Personne",
  professionnel: "Professionnel",
  entreprise: "Entreprise",
  organisme: "Organisme",
  lieu: "Lieu",
  service: "Service",
  ressource: "Ressource",
  evenement: "Événement",
};

export const REGISTRY_GROUPS = [
  "PERSONNES",
  "PROFESSIONNELS",
  "ORGANISMES",
  "LIEUX",
  "SERVICES",
  "RESSOURCES",
  "ÉVÉNEMENTS",
] as const;
