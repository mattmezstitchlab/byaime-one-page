import { supabase } from "@/integrations/supabase/client";

/** Format YYYY-MM-DD attendu par `quotes.target_date`. */
export function toTargetDate(d: Date | string): string {
  const day = typeof d === "string" ? new Date(d) : d;
  return `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, "0")}-${String(
    day.getDate(),
  ).padStart(2, "0")}`;
}

type DraftQuote = {
  userId: string;
  cardId: string;
  cardName?: string | null;
  title?: string;
  /** Date visée : Date, chaîne ISO ou déjà au format YYYY-MM-DD. */
  targetDate: Date | string;
};

/**
 * Source unique de création d'un devis brouillon.
 * Utilisée par la page carte (timeline) et par le cœur d'intention.
 */
export async function createDraftQuote({
  userId,
  cardId,
  cardName,
  title,
  targetDate,
}: DraftQuote) {
  const label = title?.trim() || `Devis — ${cardName ?? "prestation"}`;
  const { error } = await supabase.from("quotes").insert({
    user_id: userId,
    card_id: cardId,
    title: label,
    target_date: toTargetDate(targetDate),
    status: "brouillon",
    total: 0,
  });
  if (error) throw error;
  // Le devis ouvre aussitôt son dossier vivant dans le Bureau : la pièce
  // (devis → facture → paiement) arrive plus tard au même endroit.
  await ensureQuoteFolder({ userId, cardId, cardName: cardName ?? null, title: label });
}

/**
 * Dossier du Bureau associé à une carte : créé une seule fois, réutilisé ensuite.
 * Silencieux en cas d'échec : un devis ne doit jamais être bloqué par le Bureau.
 */
export async function ensureQuoteFolder({
  userId,
  cardId,
  cardName,
  title,
}: {
  userId: string;
  cardId: string;
  cardName: string | null;
  title: string;
}) {
  try {
    const { data } = await supabase
      .from("bureau_folders")
      .select("id")
      .eq("owner_id", userId)
      .eq("card_id", cardId)
      .limit(1)
      .maybeSingle();
    if (data) return data.id;
    const { data: created } = await supabase
      .from("bureau_folders")
      .insert({
        owner_id: userId,
        card_id: cardId,
        title,
        kind: "tiers",
        counterpart: cardName,
        note: "Ouvert automatiquement par un devis",
      })
      .select("id")
      .maybeSingle();
    return created?.id ?? null;
  } catch {
    return null;
  }
}
