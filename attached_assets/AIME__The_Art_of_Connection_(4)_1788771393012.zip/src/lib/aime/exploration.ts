/**
 * La mémoire d'exploration : ce que la personne regarde en parcourant les
 * 12 mondes. Anonyme tant qu'elle n'est pas connectée, effaçable à tout moment.
 */
import { supabase } from "@/integrations/supabase/client";

export type SignalKind = "clic" | "choix" | "curseur" | "surprise";

export type LocalSignal = {
  universe: string;
  sub: string | null;
  kind: SignalKind;
  value: Record<string, unknown>;
  at: string;
};

const ANON_KEY = "aime.explorer";
const LOCAL_KEY = "aime.exploration";
const MAX_LOCAL = 120;

export const EXPLORATION_EVENT = "aime-exploration";

export function explorerId(): string {
  if (typeof window === "undefined") return "";
  let id = window.localStorage.getItem(ANON_KEY);
  if (!id) {
    id = crypto.randomUUID();
    window.localStorage.setItem(ANON_KEY, id);
  }
  return id;
}

export function readSignals(): LocalSignal[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(LOCAL_KEY);
    const parsed = raw ? (JSON.parse(raw) as LocalSignal[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function clearSignals(userId?: string | null) {
  if (typeof window !== "undefined") {
    window.localStorage.removeItem(LOCAL_KEY);
    window.dispatchEvent(new Event(EXPLORATION_EVENT));
  }
  if (userId) {
    void supabase.from("exploration_signals").delete().eq("user_id", userId);
  }
}

/** Enregistre un geste d'exploration. Jamais bloquant : l'échec est silencieux. */
export function recordSignal(
  input: {
    universe: string;
    sub?: string | null;
    kind: SignalKind;
    value?: Record<string, unknown>;
  },
  userId?: string | null,
) {
  const entry: LocalSignal = {
    universe: input.universe,
    sub: input.sub ?? null,
    kind: input.kind,
    value: input.value ?? {},
    at: new Date().toISOString(),
  };
  if (typeof window !== "undefined") {
    const next = [entry, ...readSignals()].slice(0, MAX_LOCAL);
    try {
      window.localStorage.setItem(LOCAL_KEY, JSON.stringify(next));
    } catch {
      /* stockage plein : la mémoire locale n'est pas critique */
    }
    window.dispatchEvent(new Event(EXPLORATION_EVENT));
  }
  void supabase
    .from("exploration_signals")
    .insert({
      user_id: userId ?? null,
      anon_id: explorerId(),
      universe: entry.universe,
      sub: entry.sub,
      kind: entry.kind,
      value: JSON.parse(JSON.stringify(entry.value)),
    })
    .then(() => undefined);
}

/** Poids d'affinité par monde puis par entrée : sert à reclasser ce qu'on propose. */
export function affinity(signals = readSignals()) {
  const universes = new Map<string, number>();
  const subs = new Map<string, number>();
  for (const s of signals) {
    const w = s.kind === "clic" ? 1 : s.kind === "surprise" ? 0.5 : 2;
    universes.set(s.universe, (universes.get(s.universe) ?? 0) + w);
    if (s.sub) subs.set(`${s.universe}:${s.sub}`, (subs.get(`${s.universe}:${s.sub}`) ?? 0) + w);
  }
  return { universes, subs };
}

/** Les entrées les plus regardées, du plus au moins fréquent. */
export function topSubs(limit = 6, signals = readSignals()) {
  const { subs } = affinity(signals);
  return [...subs.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([key, score]) => {
      const [universe, sub] = key.split(":");
      return { universe: universe ?? "", sub: sub ?? "", score };
    });
}
