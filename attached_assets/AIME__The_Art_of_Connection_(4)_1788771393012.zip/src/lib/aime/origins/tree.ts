import type { Certainty } from "@/lib/aime/memory/certainty";
import { type FamilyLink, orientedLinks, otherCardId } from "@/lib/aime/origins/origins";

/**
 * L'arbre des origines : les places attendues existent même sans nom.
 * Une place vide n'est pas rien — c'est une information manquante.
 */
export type TreeNode = {
  /** Emplacement structurel : moi, p1 (parent 1), p1p2 (grand-parent)… */
  slot: string;
  /** Le rôle lu par la personne : « Parent », « Grand-parent ». */
  role: string;
  generation: number;
  cardId: string | null;
  name: string | null;
  city: string | null;
  certainty: Certainty;
  linkId: string | null;
  /** Chemin du parent dans l'arbre, pour tracer les traits. */
  parentSlot: string | null;
};

const ROLE_BY_GEN = ["Personne", "Parent", "Grand-parent"];

/**
 * Deux parents, quatre grands-parents : la structure est certaine,
 * les identités ne le sont pas. On les montre donc « inférées ».
 */
export function buildOriginsTree(
  cardId: string,
  cardName: string,
  cardCity: string | null,
  links: FamilyLink[],
  depth = 2,
): TreeNode[] {
  const byCard = new Map<string, FamilyLink[]>();
  for (const l of links) {
    for (const side of [l.from_card_id, l.to_card_id]) {
      const list = byCard.get(side) ?? [];
      list.push(l);
      byCard.set(side, list);
    }
  }

  const parentsOf = (id: string) => {
    const own = byCard.get(id) ?? [];
    return orientedLinks(own, id).parents;
  };

  const nodes: TreeNode[] = [
    {
      slot: "moi",
      role: ROLE_BY_GEN[0] as string,
      generation: 0,
      cardId,
      name: cardName,
      city: cardCity,
      certainty: "confirme",
      linkId: null,
      parentSlot: null,
    },
  ];

  const expand = (node: TreeNode) => {
    if (node.generation >= depth) return;
    const gen = node.generation + 1;
    const role = ROLE_BY_GEN[gen] ?? `Génération −${gen}`;
    const known = node.cardId ? parentsOf(node.cardId) : [];
    for (let i = 0; i < 2; i++) {
      const link = known[i];
      const otherId = link && node.cardId ? otherCardId(link, node.cardId) : null;
      const child: TreeNode = {
        slot: `${node.slot}-${i + 1}`,
        role,
        generation: gen,
        cardId: otherId,
        name: link?.otherName ?? null,
        city: link?.otherCity ?? null,
        certainty: link?.certainty ?? "infere",
        linkId: link?.id ?? null,
        parentSlot: node.slot,
      };
      nodes.push(child);
      expand(child);
    }
  };

  expand(nodes[0] as TreeNode);
  return nodes;
}

/** Ce qui reste à découvrir : les trous, dits simplement. */
export type OpenQuestion = { slot: string; label: string; detail: string };

export function openQuestions(
  nodes: TreeNode[],
  opts: { hasBirth: boolean; hasBirthPlace: boolean; momentsCount: number },
): OpenQuestion[] {
  const out: OpenQuestion[] = [];
  if (!opts.hasBirth) {
    out.push({
      slot: "moi",
      label: "Votre date de naissance n'est pas renseignée",
      detail: "C'est le point d'ancrage de toute votre histoire.",
    });
  }
  if (!opts.hasBirthPlace) {
    out.push({
      slot: "moi",
      label: "Votre lieu de naissance n'est pas renseigné",
      detail: "Un lieu ouvre la recherche d'archives.",
    });
  }
  const unknownParents = nodes.filter((n) => n.generation === 1 && !n.cardId);
  if (unknownParents.length > 0) {
    out.push({
      slot: unknownParents[0]!.slot,
      label:
        unknownParents.length === 2
          ? "Aucun de vos deux parents n'est encore relié"
          : "Un de vos parents n'est pas encore relié",
      detail: "La place existe, l'identité reste à documenter.",
    });
  }
  const unknownGrand = nodes.filter((n) => n.generation === 2 && !n.cardId);
  if (unknownGrand.length > 0 && unknownParents.length < 2) {
    out.push({
      slot: unknownGrand[0]!.slot,
      label: `${unknownGrand.length} grands-parents non documentés`,
      detail: "Une branche entière reste à explorer.",
    });
  }
  const hypotheses = nodes.filter((n) => n.certainty === "hypothese");
  if (hypotheses.length > 0) {
    out.push({
      slot: hypotheses[0]!.slot,
      label: `${hypotheses.length} hypothèse${hypotheses.length > 1 ? "s" : ""} à trancher`,
      detail: "Une correspondance possible, pas encore confirmée.",
    });
  }
  if (opts.momentsCount === 0) {
    out.push({
      slot: "moi",
      label: "Aucune trace ne documente encore votre passé",
      detail: "Une photo, une lettre, un document suffisent pour commencer.",
    });
  }
  return out;
}
