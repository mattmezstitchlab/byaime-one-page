import { supabase } from "@/integrations/supabase/client";
import {
  type Certainty,
  type EvidenceItem,
  evidenceList,
} from "@/lib/aime/memory/certainty";

/** Une place dans la structure familiale. Vide ne veut pas dire rien. */
export type Relation = "parent" | "enfant" | "fratrie" | "conjoint";

export const RELATION_LABEL: Record<Relation, string> = {
  parent: "Parent",
  enfant: "Enfant",
  fratrie: "Frère ou sœur",
  conjoint: "Conjoint",
};

export type Visibility = "private" | "shared" | "public";

export const VISIBILITY_LABEL: Record<Visibility, string> = {
  private: "Privé — vous seul",
  shared: "Partagé — les personnes liées",
  public: "Public — sur la page",
};

export type FamilyLink = {
  id: string;
  from_card_id: string;
  to_card_id: string;
  relation: Relation;
  certainty: Certainty;
  visibility: Visibility;
  note: string | null;
  source_ref_id: string | null;
  evidence: EvidenceItem[];
  created_by: string;
  /** Nom de la personne à l'autre bout, quand la carte est lisible. */
  otherName?: string | null;
  otherCity?: string | null;
};

export type CardIdentity = {
  card_id: string;
  born_on: string | null;
  born_precision: "jour" | "mois" | "annee";
  birth_city: string | null;
  birth_country: string | null;
  died_on: string | null;
  death_city: string | null;
  certainty: Record<string, Certainty>;
  visibility: Visibility;
  note: string | null;
};

export function identityQuery(cardId: string | null | undefined) {
  return {
    queryKey: ["card-identity", cardId ?? "none"],
    enabled: !!cardId,
    queryFn: async (): Promise<CardIdentity | null> => {
      const { data, error } = await supabase
        .from("card_identity")
        .select("*")
        .eq("card_id", cardId!)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return {
        ...(data as unknown as CardIdentity),
        certainty: (data.certainty ?? {}) as Record<string, Certainty>,
      };
    },
  };
}

export async function saveIdentity(cardId: string, patch: Partial<CardIdentity>) {
  const { error } = await supabase
    .from("card_identity")
    .upsert({ card_id: cardId, ...patch } as never, { onConflict: "card_id" });
  if (error) throw error;
}

/** Tous les liens qui touchent cette personne, dans un sens ou dans l'autre. */
export function familyLinksQuery(cardId: string | null | undefined) {
  return {
    queryKey: ["family-links", cardId ?? "none"],
    enabled: !!cardId,
    queryFn: async (): Promise<FamilyLink[]> => {
      const { data, error } = await supabase
        .from("family_links")
        .select("*")
        .or(`from_card_id.eq.${cardId},to_card_id.eq.${cardId}`);
      if (error) throw error;
      const rows = (data ?? []) as unknown as FamilyLink[];
      const ids = Array.from(
        new Set(rows.flatMap((r) => [r.from_card_id, r.to_card_id])),
      ).filter((x) => x !== cardId);
      const names = new Map<string, { name: string; city: string | null }>();
      if (ids.length > 0) {
        const { data: cards } = await supabase
          .from("cards")
          .select("id,name,city")
          .in("id", ids);
        for (const c of cards ?? []) names.set(c.id, { name: c.name, city: c.city });
      }
      return rows.map((r) => {
        const otherId = r.from_card_id === cardId ? r.to_card_id : r.from_card_id;
        const other = names.get(otherId);
        return {
          ...r,
          evidence: evidenceList(r.evidence),
          otherName: other?.name ?? null,
          otherCity: other?.city ?? null,
        };
      });
    },
  };
}

/** Le point de vue de la personne : qui est parent, enfant, fratrie, conjoint. */
export function orientedLinks(links: FamilyLink[], cardId: string) {
  const parents: FamilyLink[] = [];
  const children: FamilyLink[] = [];
  const siblings: FamilyLink[] = [];
  const partners: FamilyLink[] = [];
  for (const l of links) {
    const outgoing = l.from_card_id === cardId;
    if (l.relation === "parent") (outgoing ? parents : children).push(l);
    else if (l.relation === "enfant") (outgoing ? children : parents).push(l);
    else if (l.relation === "fratrie") siblings.push(l);
    else partners.push(l);
  }
  return { parents, children, siblings, partners };
}

/** Le lien qui mène de cette personne à l'autre bout du lien. */
export function otherCardId(link: FamilyLink, cardId: string) {
  return link.from_card_id === cardId ? link.to_card_id : link.from_card_id;
}

export type CreateLinkInput = {
  fromCardId: string;
  toCardId: string;
  relation: Relation;
  certainty: Certainty;
  visibility?: Visibility;
  note?: string | null;
  evidence?: EvidenceItem[];
};

export async function createFamilyLink(input: CreateLinkInput) {
  const { data, error } = await supabase
    .from("family_links")
    .insert({
      from_card_id: input.fromCardId,
      to_card_id: input.toCardId,
      relation: input.relation,
      certainty: input.certainty,
      visibility: input.visibility ?? "private",
      note: input.note ?? null,
      evidence: (input.evidence ?? []) as never,
    } as never)
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}

export async function updateFamilyLink(id: string, patch: Partial<FamilyLink>) {
  const { error } = await supabase.from("family_links").update(patch as never).eq("id", id);
  if (error) throw error;
}

export async function removeFamilyLink(id: string) {
  const { error } = await supabase.from("family_links").delete().eq("id", id);
  if (error) throw error;
}

/**
 * Une personne d'un arbre est une carte : pas de duplication de données.
 * Un aïeul devient une carte « personne » non publiée, propriété de celui qui la crée.
 */
export async function ensurePersonCard(name: string, city?: string | null) {
  const { data: auth } = await supabase.auth.getUser();
  const ownerId = auth.user?.id ?? null;
  const { data, error } = await supabase
    .from("cards")
    .insert({
      name: name.trim(),
      kind: "personne",
      category_slug: "personne",
      published: false,
      owner_id: ownerId,
      ...(city ? { city } : {}),
    } as never)
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}
