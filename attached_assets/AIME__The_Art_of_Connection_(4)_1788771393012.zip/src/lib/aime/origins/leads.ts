import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import {
  certaintyFromConfidence,
  type Certainty,
  type EvidenceItem,
} from "@/lib/aime/memory/certainty";
import { createFamilyLink, ensurePersonCard, type Relation } from "@/lib/aime/origins/origins";

export type Lead = Database["public"]["Tables"]["web_memory_finds"]["Row"];

/** Les pistes d'origines : rangées à part des traces de la ligne de temps. */
export function leadsQuery(cardId: string | null | undefined, slot?: string) {
  return {
    queryKey: ["origins-leads", cardId ?? "none", slot ?? "all"],
    enabled: !!cardId,
    queryFn: async (): Promise<Lead[]> => {
      let q = supabase
        .from("web_memory_finds")
        .select("*")
        .eq("card_id", cardId!)
        .eq("kind", "genealogie")
        .neq("status", "refusee")
        .order("created_at", { ascending: false });
      if (slot) q = q.like("query", `%:${slot}`);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  };
}

export function relationOfLead(lead: Lead): Relation {
  const part = (lead.query ?? "").split(":")[1];
  if (part === "enfant" || part === "fratrie" || part === "conjoint") return part;
  return "parent";
}

/** Ce qui appuie une piste, dit élément par élément — jamais une note unique. */
export function leadEvidence(lead: Lead): EvidenceItem[] {
  const items: EvidenceItem[] = [];
  if (lead.source_title || lead.source_url) {
    items.push({
      label: "Source identifiable",
      detail: lead.source_title ?? lead.source_url ?? "",
      ok: true,
    });
  }
  if (lead.date_text) items.push({ label: "Période cohérente", detail: lead.date_text, ok: true });
  if (lead.place) items.push({ label: "Lieu cohérent", detail: lead.place, ok: true });
  if (lead.reason) items.push({ label: "Pourquoi cette piste", detail: lead.reason });
  items.push({ label: "Identité non confirmée", ok: false });
  return items;
}

export async function refuseLead(id: string) {
  const { error } = await supabase.from("web_memory_finds").update({ status: "refusee" }).eq("id", id);
  if (error) throw error;
}

/**
 * Le seul chemin d'une piste vers l'arbre : la personne a lu, choisi le niveau, accepté.
 * La piste devient une carte « personne » non publiée, et un lien expliqué.
 */
export async function acceptLead(
  lead: Lead,
  input: { cardId: string; relation: Relation; certainty: Certainty; name?: string },
) {
  const name = (input.name ?? lead.title).trim();
  if (!name) throw new Error("Donnez un nom à cette personne.");
  const personId = await ensurePersonCard(name, lead.place);
  const linkId = await createFamilyLink({
    fromCardId: input.cardId,
    toCardId: personId,
    relation: input.relation,
    certainty: input.certainty,
    visibility: "private",
    note: lead.summary,
    evidence: leadEvidence(lead),
  });
  const { error } = await supabase
    .from("web_memory_finds")
    .update({ status: "validee" })
    .eq("id", lead.id);
  if (error) throw error;
  return { personId, linkId };
}

export function suggestedCertainty(lead: Lead): Certainty {
  return certaintyFromConfidence(lead.confidence);
}
