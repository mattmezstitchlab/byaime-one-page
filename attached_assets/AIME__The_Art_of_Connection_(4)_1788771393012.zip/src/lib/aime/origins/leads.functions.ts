import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Pistes d'origines — recherche de traces publiques sur une branche familiale.
 * Règle absolue : aucune relation n'est jamais enregistrée ici.
 * On ne fait qu'écrire des pistes, à examiner puis à valider par la personne.
 */

const MODEL = "google/gemini-3-flash";

const Input = z.object({
  cardId: z.string().uuid(),
  name: z.string().min(2).max(120),
  relation: z.enum(["parent", "enfant", "fratrie", "conjoint"]),
  slot: z.string().max(40),
  bornYear: z.string().max(4).optional(),
  birthPlace: z.string().max(160).optional(),
  hint: z.string().max(240).optional(),
});

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["pistes"],
  properties: {
    pistes: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["nom", "resume", "annee", "lieu", "confiance", "pourquoi", "source"],
        properties: {
          nom: { type: "string" },
          resume: { type: "string" },
          annee: { type: "string", description: "AAAA ou vide" },
          lieu: { type: "string" },
          confiance: { type: "string", enum: ["faible", "moyenne", "forte"] },
          pourquoi: { type: "string" },
          source: { type: "string" },
        },
      },
    },
  },
} as const;

type RawLead = {
  nom: string;
  resume: string;
  annee: string;
  lieu: string;
  confiance: string;
  pourquoi: string;
  source: string;
};

type Page = { url: string; title: string; text: string };

async function searchWeb(query: string, apiKey: string): Promise<Page[]> {
  const res = await fetch("https://api.firecrawl.dev/v1/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      query,
      limit: 8,
      scrapeOptions: { formats: ["markdown"], onlyMainContent: true },
    }),
  });
  if (!res.ok) throw new Error("La recherche de traces n'a pas abouti.");
  const json = (await res.json()) as {
    data?: { url?: string; title?: string; markdown?: string; description?: string }[];
  };
  return (json.data ?? [])
    .filter((r) => !!r.url)
    .map((r) => ({
      url: r.url!,
      title: r.title ?? r.url!,
      text: (r.markdown ?? r.description ?? "").slice(0, 6000),
    }))
    .filter((p) => p.text.length > 80);
}

function typeOfSource(url: string): string {
  const host = (() => {
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch {
      return "";
    }
  })();
  if (/geneanet|filae|ancestry|geneal/.test(host)) return "base généalogique";
  if (/archives|archive|bnf|gallica|memoire/.test(host)) return "archive publique";
  if (/insee|service-public|gouv/.test(host)) return "source institutionnelle";
  if (/wikipedia|wikitree/.test(host)) return "encyclopédie";
  if (/presse|journal|news|actu|ouest-france|lemonde|figaro/.test(host)) return "presse";
  return host || "web";
}

export type LeadsRunResult = { found: number; kept: number; message: string };

export const runOriginsLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }): Promise<LeadsRunResult> => {
    const firecrawl = process.env["FIRECRAWL_API_KEY"];
    const lovable = process.env["LOVABLE_API_KEY"];
    if (!firecrawl) throw new Error("La recherche de traces n'est pas disponible pour l'instant.");
    if (!lovable) throw new Error("Aime n'est pas joignable pour l'instant.");

    const supabase = context.supabase;
    const { data: card, error: cardErr } = await supabase
      .from("cards")
      .select("id, name, owner_id")
      .eq("id", data.cardId)
      .maybeSingle();
    if (cardErr) throw new Error(cardErr.message);
    if (!card || card.owner_id !== context.userId) {
      throw new Error("Cette page n'est pas la vôtre.");
    }

    const query = [
      `"${data.name}"`,
      data.relation === "parent" ? "père mère famille" : "famille",
      data.birthPlace,
      data.bornYear,
      data.hint,
      "archive généalogie état civil",
    ]
      .filter(Boolean)
      .join(" ");

    const pages = await searchWeb(query, firecrawl);
    if (!pages.length) {
      return { found: 0, kept: 0, message: "Aucune trace publique trouvée avec ce contexte." };
    }

    const corpus = pages
      .map((p, i) => `--- SOURCE ${i + 1} : ${p.title}\nURL : ${p.url}\n${p.text}`)
      .join("\n\n");

    const system = `Tu aides une personne à retrouver une branche de sa famille à partir de traces publiques.
Tu ne déclares JAMAIS une filiation vraie. Tu proposes seulement des PISTES à examiner.
Règles :
- N'invente aucun nom, aucune date, aucun lieu : tout doit venir des pages fournies.
- "source" doit être exactement l'une des URL fournies.
- "pourquoi" explique en une phrase simple pourquoi cette piste pourrait correspondre (période, lieu, nom).
- "confiance" est faible dès qu'un homonyme est possible.
- Ignore les pages sans rapport. Maximum 6 pistes.
- Français simple, aucune formule technique.`;

    const user = `Personne connue : ${data.name}
Lien recherché : ${data.relation}
Année de naissance connue : ${data.bornYear || "inconnue"}
Lieu de naissance connu : ${data.birthPlace || "inconnu"}
Indice donné : ${data.hint || "aucun"}

${corpus}`;

    const ai = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${lovable}` },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
        response_format: {
          type: "json_schema",
          json_schema: { name: "pistes", strict: true, schema: SCHEMA },
        },
      }),
    });
    if (!ai.ok) throw new Error("L'analyse des pages trouvées n'a pas abouti.");
    const payload = (await ai.json()) as { choices?: { message?: { content?: string } }[] };
    let leads: RawLead[] = [];
    try {
      leads = (JSON.parse(payload.choices?.[0]?.message?.content ?? "{}").pistes ?? []) as RawLead[];
    } catch {
      leads = [];
    }

    const urls = new Set(pages.map((p) => p.url));
    const rows = leads
      .filter((l) => urls.has(l.source) && l.nom?.trim())
      .map((l) => ({
        card_id: data.cardId,
        created_by: context.userId,
        kind: "genealogie",
        title: l.nom.slice(0, 200),
        summary: l.resume?.slice(0, 1200) || null,
        occurred_on: null,
        date_text: l.annee?.slice(0, 20) || null,
        place: l.lieu?.slice(0, 160) || null,
        people: [l.nom.slice(0, 120)],
        source_url: l.source,
        source_title: pages.find((p) => p.url === l.source)?.title?.slice(0, 200) ?? null,
        source_type: typeOfSource(l.source),
        confidence: ["faible", "moyenne", "forte"].includes(l.confiance) ? l.confiance : "faible",
        reason: l.pourquoi?.slice(0, 400) || null,
        status: "trouvee",
        query: `origines:${data.relation}:${data.slot}`,
      }));

    if (!rows.length) {
      return { found: pages.length, kept: 0, message: "Rien de solide à vous proposer." };
    }

    const { error: insErr, count } = await supabase
      .from("web_memory_finds")
      .upsert(rows as never, {
        onConflict: "card_id,source_url,title",
        ignoreDuplicates: true,
        count: "exact",
      });
    if (insErr) throw new Error(insErr.message);

    return {
      found: pages.length,
      kept: count ?? rows.length,
      message: `${rows.length} piste(s) à examiner, tirées de ${pages.length} page(s).`,
    };
  });
