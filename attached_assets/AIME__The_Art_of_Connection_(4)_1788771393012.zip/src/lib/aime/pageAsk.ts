/**
 * Ce qu'on peut demander à l'agent depuis la page d'une personne.
 * Ces entrées remplacent l'ancienne navigation horizontale : elles vivent
 * désormais dans le cœur, au début du champ de saisie posé dans le hero.
 */
import {
  CalendarRange,
  CreditCard,
  FileText,
  Heart,
  Images,
  MessageCircle,
  Phone,
  Radio,
  Sparkle,
  Star,
  Clock,
  FolderOpen,
  Layers,
  Pencil,
  Send,
  Share2,
  FolderPlus,
  Trees,
} from "lucide-react";
import type { CardTabKey } from "@/components/aime/CardTabs";

export type AskKey =
  | CardTabKey
  | "payer"
  | "galerie"
  | "message"
  | "modifier"
  | "aime"
  | "associer"
  | "recommander"
  | "document";

/** Les familles du menu du cœur. */
export type AskGroup = "decouvrir" | "ensemble" | "lien" | "ma-page";

export type AskEntry = {
  key: AskKey;
  label: string;
  hint: string;
  /** Phrase déposée dans le champ quand on choisit l'entrée. */
  prompt: string;
  icon: typeof Sparkle;
  group: AskGroup;
  /** "tous" | "visiteur" (pas sur sa propre page) | "proprietaire". */
  scope: "tous" | "visiteur" | "proprietaire";
};

export const PAGE_ASKS: AskEntry[] = [
  {
    key: "aime",
    group: "lien",
    label: "J'aime cette page",
    hint: "La garder en tête",
    prompt: "",
    icon: Heart,
    scope: "visiteur",
  },
  {
    key: "calendrier",
    group: "ensemble",
    label: "Disponibilités",
    hint: "Voir les dates libres, réserver",
    prompt: "Es-tu disponible ",
    icon: CalendarRange,
    scope: "tous",
  },
  {
    key: "devis",
    group: "ensemble",
    label: "Tarifs et devis",
    hint: "Connaître les prix, demander un devis",
    prompt: "Quels sont tes tarifs ? J'aimerais un devis",
    icon: FileText,
    scope: "tous",
  },
  {
    key: "payer",
    group: "ensemble",
    label: "Payer",
    hint: "Régler une prestation",
    prompt: "Je souhaite payer ",
    icon: CreditCard,
    scope: "visiteur",
  },
  {
    key: "galerie",
    group: "decouvrir",
    label: "Photos et vidéos",
    hint: "La vitrine, en images",
    prompt: "Montre-moi ses photos et vidéos",
    icon: Images,
    scope: "tous",
  },
  {
    key: "avis",
    group: "decouvrir",
    label: "Avis",
    hint: "Ce qu'on dit d'elle ou de lui",
    prompt: "Quels sont les avis ?",
    icon: Star,
    scope: "tous",
  },
  {
    key: "savoir-faire",
    group: "decouvrir",
    label: "Savoir-faire",
    hint: "Ce qu'elle ou il sait faire",
    prompt: "Quels sont ses savoir-faire ?",
    icon: Sparkle,
    scope: "tous",
  },
  {
    key: "experiences",
    group: "decouvrir",
    label: "Expériences",
    hint: "Son parcours, ses références",
    prompt: "Quelles sont ses expériences ?",
    icon: Layers,
    scope: "tous",
  },
  {
    key: "message",
    group: "lien",
    label: "Écrire un message",
    hint: "Ouvrir la conversation",
    prompt: "Écris-lui : ",
    icon: MessageCircle,
    scope: "visiteur",
  },
  {
    key: "contact",
    group: "lien",
    label: "Coordonnées",
    hint: "Téléphone, site, adresse",
    prompt: "Comment la contacter ?",
    icon: Phone,
    scope: "tous",
  },
  {
    key: "radio",
    group: "decouvrir",
    label: "Radio",
    hint: "Sa fréquence, ses annonces",
    prompt: "Fais écouter sa radio",
    icon: Radio,
    scope: "tous",
  },
  {
    key: "timeline",
    group: "decouvrir",
    label: "Sa ligne de temps",
    hint: "Souvenirs, projets, jalons",
    prompt: "Montre-moi sa ligne de temps",
    icon: Clock,
    scope: "tous",
  },
  {
    key: "origines",
    group: "decouvrir",
    label: "Origines",
    hint: "D'où vient cette personne, ce qui reste à découvrir",
    prompt: "Montre-moi ses origines",
    icon: Trees,
    scope: "tous",
  },
  {
    key: "projets",
    group: "ma-page",
    label: "Mes projets",
    hint: "Tout ce que j'organise",
    prompt: "Montre-moi mes projets",
    icon: FolderOpen,
    scope: "proprietaire",
  },
  {
    key: "bureau",
    group: "ma-page",
    label: "Mon Bureau",
    hint: "Mes dossiers et pièces",
    prompt: "Montre-moi mon Bureau",
    icon: FolderOpen,
    scope: "proprietaire",
  },
  {
    key: "associer",
    label: "L'ajouter à un projet",
    hint: "Le rattacher à ce que j'organise",
    prompt: "Ajoute-la à mon projet ",
    icon: FolderPlus,
    group: "ensemble",
    scope: "visiteur",
  },
  {
    key: "recommander",
    label: "Recommander",
    hint: "Envoyer cette page à quelqu'un",
    prompt: "Je recommande cette page à ",
    icon: Share2,
    group: "lien",
    scope: "visiteur",
  },
  {
    key: "document",
    label: "Envoyer un document",
    hint: "Devis, plan, photo — rangé tout seul",
    prompt: "Je lui envoie un document",
    icon: Send,
    group: "lien",
    scope: "visiteur",
  },
  {
    key: "modifier",
    group: "ma-page",
    label: "Modifier ma page",
    hint: "Compléter, enrichir",
    prompt: "Je veux modifier ma page",
    icon: Pencil,
    scope: "proprietaire",
  },
];

export function asksForPage(isMine: boolean): AskEntry[] {
  return PAGE_ASKS.filter((a) =>
    a.scope === "tous" ? true : a.scope === "proprietaire" ? isMine : !isMine,
  );
}

export function askLabel(key: AskKey): string {
  return PAGE_ASKS.find((a) => a.key === key)?.label ?? "Réponse";
}

const RULES: { key: AskKey; words: string[] }[] = [
  { key: "calendrier", words: ["disponib", "libre", "reserv", "agenda", "calendrier", "date"] },
  { key: "devis", words: ["tarif", "prix", "devis", "cout", "budget", "combien"] },
  { key: "payer", words: ["payer", "paiement", "regler", "acompte", "facture"] },
  { key: "galerie", words: ["photo", "video", "galerie", "image", "portfolio", "vitrine"] },
  { key: "avis", words: ["avis", "temoignage", "recommand", "note", "retour"] },
  { key: "savoir-faire", words: ["savoir", "competence", "sait faire", "specialite"] },
  { key: "experiences", words: ["experience", "parcours", "reference", "cv"] },
  { key: "message", words: ["ecris", "ecrire", "message", "envoie", "dis-lui", "discuter"] },
  { key: "contact", words: ["contact", "telephone", "adresse", "coordonnees", "joindre"] },
  { key: "radio", words: ["radio", "frequence", "ecouter", "annonce"] },
  { key: "origines", words: ["origine", "genealog", "famille", "parent", "ancetre", "arbre", "heritage", "memoire"] },
  { key: "timeline", words: ["timeline", "ligne de temps", "souvenir", "passe", "histoire"] },
  { key: "projets", words: ["projet", "evenement", "organisation"] },
  { key: "bureau", words: ["bureau", "dossier", "document", "piece"] },
  { key: "associer", words: ["ajoute-la", "ajouter au projet", "associer", "rattacher"] },
  { key: "recommander", words: ["recommand", "partager la page", "envoyer la page"] },
  { key: "document", words: ["envoyer un document", "joindre", "piece jointe"] },
  { key: "modifier", words: ["modifier ma page", "completer ma page", "enrichir ma page"] },
];

function strip(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** L'intention comprise dans une phrase libre, sinon rien. */
export function detectAsk(text: string): AskKey | null {
  const t = strip(text);
  for (const r of RULES) {
    if (r.words.some((w) => t.includes(w))) return r.key;
  }
  return null;
}
