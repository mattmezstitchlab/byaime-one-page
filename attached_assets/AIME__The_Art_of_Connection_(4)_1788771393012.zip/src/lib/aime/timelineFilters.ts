import type { TimelineKind, TimelineMarker } from "@/components/aime/HeroTimeline";

/** Familles de repères : ce sont les calques activables au-dessus de la règle. */
export type TimelineFamily =
  | "intention"
  | "rdv"
  | "personne"
  | "tache"
  | "document"
  | "photo"
  | "video"
  | "musique"
  | "narration"
  | "message"
  | "finance"
  | "admin"
  | "validation"
  | "souvenir"
  | "dispo";

export const FAMILY_LABEL: Record<TimelineFamily, string> = {
  intention: "Intentions",
  rdv: "Événements",
  personne: "Personnes",
  tache: "Tâches",
  document: "Documents",
  photo: "Photos",
  video: "Vidéos",
  musique: "Musique",
  narration: "Narration",
  message: "Messages",
  finance: "Finance",
  admin: "Administratif",
  validation: "Validations",
  souvenir: "Souvenirs",
  dispo: "Disponibilités",
};

export const FAMILY_ORDER: TimelineFamily[] = [
  "intention",
  "rdv",
  "personne",
  "tache",
  "document",
  "photo",
  "video",
  "musique",
  "narration",
  "message",
  "finance",
  "admin",
  "validation",
  "souvenir",
  "dispo",
];


const BY_KIND: Record<TimelineKind, TimelineFamily> = {
  souvenir: "souvenir",
  intention: "intention",
  evenement: "rdv",
  jalon: "rdv",
  tache: "tache",
  document: "document",
  devis: "finance",
  facture: "finance",
  paiement: "finance",
  message: "message",
  disponible: "dispo",
  option: "dispo",
  complet: "dispo",
  dossier: "rdv",
};

export function familyOf(kind: TimelineKind): TimelineFamily {
  return BY_KIND[kind] ?? "souvenir";
}

/** Un même objet peut appartenir à plusieurs calques : c'est le principe de superposition. */
export function familiesOf(m: TimelineMarker): TimelineFamily[] {
  const out = new Set<TimelineFamily>([familyOf(m.kind)]);
  if (m.media === "video") out.add("video");
  if (m.media === "rencontre") out.add("personne");
  if (m.media === "doc") out.add("document");
  if (m.thumbUrl && m.media !== "video") out.add("photo");
  if (m.personIds?.length) out.add("personne");
  if (m.status === "a_valider" || m.status === "bloque") out.add("validation");
  if (m.metadata?.["track"]) out.add("musique");
  if (m.metadata?.["musicKind"] === "recit" || m.metadata?.["narration"]) out.add("narration");
  const admin = String(m.metadata?.["admin"] ?? "");
  if (admin) out.add("admin");

  return [...out];
}

/** Filtre d'affichage : aucun calque actif = tout est visible. */
export function makeLayerFilter(active: TimelineFamily[]) {
  if (active.length === 0) return undefined;
  const set = new Set(active);
  return (m: TimelineMarker) => familiesOf(m).some((f) => set.has(f));
}
