/** Helpers pour les pages SEO « métier × ville ». */

export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** Retrouve le libellé d'une ville à partir de son slug, dans une liste de villes. */
export function cityFromSlug(cities: string[], slug: string): string | undefined {
  return cities.find((c) => slugify(c) === slug);
}

export const SITE_URL = "https://byaime.fr";

export function guideTitle(categoryLabel: string, city: string): string {
  return `${categoryLabel} à ${city} — AIME`;
}

export function guideDescription(categoryLabel: string, city: string, count: number): string {
  const n = count > 0 ? `${count} carte${count > 1 ? "s" : ""}` : "Les cartes";
  return `${n} de ${categoryLabel.toLowerCase()} à ${city} sur AIME : disponibilités, tarifs indicatifs, avis et mise en relation directe.`;
}
