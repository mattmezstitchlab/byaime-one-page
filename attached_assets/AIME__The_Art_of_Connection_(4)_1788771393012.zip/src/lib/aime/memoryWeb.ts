import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

/** Une trace retrouvée sur le Web, en attente du regard de la personne. */
export type WebFind = Database["public"]["Tables"]["web_memory_finds"]["Row"];

export type FindStatus = "trouvee" | "a_revoir" | "validee" | "refusee";

export const FIND_KINDS = [
  { key: "evenement", label: "Événement" },
  { key: "souvenir", label: "Souvenir" },
  { key: "jalon", label: "Jalon" },
  { key: "document", label: "Document" },
  { key: "message", label: "Anecdote" },
] as const;

export const CONFIDENCE_LABEL: Record<string, string> = {
  faible: "Peu sûr",
  moyenne: "Plausible",
  forte: "Très probable",
};

export function webMemoryQuery(cardId: string | null | undefined) {
  return {
    queryKey: ["memoire-web", cardId ?? "none"],
    enabled: !!cardId,
    queryFn: async (): Promise<WebFind[]> => {
      const { data, error } = await supabase
        .from("web_memory_finds")
        .select("*")
        .eq("card_id", cardId!)
        .neq("status", "refusee")
        .order("occurred_on", { ascending: false, nullsFirst: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function setFindStatus(id: string, status: FindStatus) {
  const { error } = await supabase.from("web_memory_finds").update({ status }).eq("id", id);
  if (error) throw error;
}

export async function removeFind(id: string) {
  const { error } = await supabase.from("web_memory_finds").delete().eq("id", id);
  if (error) throw error;
}

export type FindEdit = {
  title: string;
  summary: string;
  kind: string;
  date: string;
  place: string;
  isPublic: boolean;
};

/**
 * Le seul chemin vers la ligne de temps : la personne a lu, corrigé, et accepté.
 * La source d'origine reste attachée au moment créé.
 */
export async function acceptFind(find: WebFind, edit: FindEdit) {
  if (!edit.title.trim()) throw new Error("Donnez un titre à ce moment.");
  if (!edit.date) throw new Error("Choisissez une date : sans date, rien ne peut être placé.");

  const { data: entry, error } = await supabase
    .from("card_timeline_entries")
    .insert({
      card_id: find.card_id,
      kind: edit.kind,
      title: edit.title.trim(),
      description: edit.summary.trim() || null,
      starts_at: new Date(edit.date).toISOString(),
      is_public: edit.isPublic,
      status: "execute",
      metadata: {
        source: find.source_url,
        sourceTitre: find.source_title,
        sourceType: find.source_type,
        lieu: edit.place.trim() || null,
        origine: "memoire-web",
        trouveLe: find.created_at,
      },
    })
    .select("id")
    .single();
  if (error) throw error;

  const { error: upErr } = await supabase
    .from("web_memory_finds")
    .update({ status: "validee", added_entry_id: entry.id })
    .eq("id", find.id);
  if (upErr) throw upErr;
  return entry.id;
}
