import type { TimelineKind } from "@/components/aime/HeroTimeline";

const DAY = 86_400_000;

const MONTHS = [
  "janvier",
  "février",
  "mars",
  "avril",
  "mai",
  "juin",
  "juillet",
  "août",
  "septembre",
  "octobre",
  "novembre",
  "décembre",
];

const WEEKDAYS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];

/** Ce que l'agent a compris d'une phrase écrite sous le hero. */
export type AgentIntent = {
  /** Période à mettre au centre de la ligne de temps. */
  focus: { from: number; to: number };
  /** Repère préparé, en attente de validation de l'utilisateur. */
  draft: {
    kind: TimelineKind;
    title: string;
    time: number;
    startTime?: number;
    endTime?: number;
  } | null;
  /** Recherche libre : mots gardés pour filtrer/expliquer. */
  query: string;
};

function strip(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** Date évoquée dans la phrase, sinon aujourd'hui. */
function parseDate(text: string, now: Date): { date: Date; explicit: boolean } {
  const t = strip(text);

  const dmy = t.match(/\b(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2,4}))?\b/);
  if (dmy) {
    const d = Number(dmy[1]);
    const m = Number(dmy[2]) - 1;
    const yRaw = dmy[3] ? Number(dmy[3]) : now.getFullYear();
    const y = yRaw < 100 ? 2000 + yRaw : yRaw;
    return { date: new Date(y, m, d), explicit: true };
  }

  const dm = t.match(/\b(\d{1,2})\s+([a-z]+)\b(?:\s+(\d{4}))?/);
  if (dm) {
    const idx = MONTHS.findIndex((m) => strip(m) === dm[2]);
    if (idx >= 0) {
      const y = dm[3] ? Number(dm[3]) : now.getFullYear();
      const d = new Date(y, idx, Number(dm[1]));
      if (!dm[3] && d.getTime() < now.getTime() - 7 * DAY) d.setFullYear(y + 1);
      return { date: d, explicit: true };
    }
  }

  if (/\bapres-demain\b/.test(t))
    return { date: new Date(now.getTime() + 2 * DAY), explicit: true };
  if (/\bdemain\b/.test(t)) return { date: new Date(now.getTime() + DAY), explicit: true };
  if (/\bhier\b/.test(t)) return { date: new Date(now.getTime() - DAY), explicit: true };
  if (/\baujourd'?hui\b/.test(t)) return { date: new Date(now), explicit: true };

  const wd = WEEKDAYS.findIndex((d) => new RegExp(`\\b${strip(d)}\\b`).test(t));
  if (wd >= 0) {
    const d = new Date(now);
    let delta = (wd - now.getDay() + 7) % 7;
    if (delta === 0 || /prochain/.test(t)) delta = delta === 0 ? 7 : delta;
    d.setDate(d.getDate() + delta);
    return { date: d, explicit: true };
  }

  return { date: new Date(now), explicit: false };
}

/** Créneau horaire : « de 14h à 18h », « à 15h30 ». */
function parseHours(text: string): { start?: number; end?: number } {
  const t = strip(text);
  const range = t.match(/\b(\d{1,2})\s*h\s*(\d{2})?\s*(?:a|-|jusqu'a)\s*(\d{1,2})\s*h\s*(\d{2})?/);
  if (range) {
    return {
      start: Number(range[1]) * 60 + Number(range[2] ?? 0),
      end: Number(range[3]) * 60 + Number(range[4] ?? 0),
    };
  }
  const one = t.match(/\b(?:a\s+)?(\d{1,2})\s*h\s*(\d{2})?\b/);
  if (one) return { start: Number(one[1]) * 60 + Number(one[2] ?? 0) };
  return {};
}

/** Nature du repère déduite des mots employés. */
function parseKind(text: string): TimelineKind | null {
  const t = strip(text);
  if (/\bdevis\b/.test(t)) return "devis";
  if (/\bfacture\b/.test(t)) return "facture";
  if (/\bpaiement|acompte|regl/.test(t)) return "paiement";
  if (/\bdocument|contrat|piece\b/.test(t)) return "document";
  if (/\btache|penser a|rappel|todo|a faire\b/.test(t)) return "tache";
  if (/\bmessage|ecrire|repondre\b/.test(t)) return "message";
  if (/\bmariage|concert|evenement|fete|ceremonie|soiree\b/.test(t)) return "evenement";
  if (/\brdv|rendez-?vous|reunion|essayage|repetition|reserve/.test(t)) return "jalon";
  if (/\bdispo|disponible|libre\b/.test(t)) return "disponible";
  return null;
}

/** Nettoie le titre : on retire les marqueurs de date et d'heure. */
function cleanTitle(text: string): string {
  const out = text
    .replace(/\b\d{1,2}\s*h\s*\d{0,2}\b/gi, " ")
    .replace(/\b\d{1,2}[/.]\d{1,2}(?:[/.]\d{2,4})?\b/g, " ")
    .replace(new RegExp(`\\b\\d{1,2}\\s+(${MONTHS.join("|")})\\b`, "gi"), " ")
    .replace(/\b(le|de|à|a|du|au|vers|pour|demain|hier|aujourd'hui|après-demain)\b/gi, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
  return out.length > 2 ? out.charAt(0).toUpperCase() + out.slice(1) : text.trim();
}

/**
 * Lit une phrase simple et en tire une période à montrer
 * et, si la phrase demande d'inscrire quelque chose, un repère à valider.
 */
export function parseAgentIntent(text: string, now = new Date()): AgentIntent {
  const { date, explicit } = parseDate(text, now);
  const hours = parseHours(text);
  const kind = parseKind(text);

  const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const focus = explicit
    ? { from: dayStart - 3 * DAY, to: dayStart + 4 * DAY }
    : { from: now.getTime() - 30 * DAY, to: now.getTime() + 60 * DAY };

  const wantsWrite =
    /\b(ajoute|note|inscris|cree|crée|bloque|réserve|reserve|planifie|prévois|prevois|rappelle)\b/i.test(
      text,
    );

  const draft =
    (explicit && kind) || (explicit && wantsWrite) || (kind && wantsWrite)
      ? {
          kind: kind ?? "jalon",
          title: cleanTitle(text),
          time: dayStart + (hours.start ?? 12 * 60) * 60_000,
          ...(hours.start !== undefined ? { startTime: dayStart + hours.start * 60_000 } : {}),
          ...(hours.end !== undefined ? { endTime: dayStart + hours.end * 60_000 } : {}),
        }
      : null;

  return { focus, draft, query: text.trim() };
}
