import {
  Bookmark,
  Building2,
  Cake,
  Baby,
  Compass,
  Feather,
  Globe2,
  Handshake,
  Heart,
  HeartHandshake,
  type LucideIcon,
  MessageCircle,
  Music4,
  Palette,
  Puzzle,
  CalendarCheck,
  Star,
  Ticket,
} from "lucide-react";
import type { AimeIntent } from "./types";

/** Pictos modernes (lucide) par univers — remplace les emojis. */
const UNIVERSE_ICONS: Record<string, LucideIcon> = {
  mariage: HeartHandshake,
  concert: Music4,
  entreprise: Building2,
  anniversaire: Cake,
  evenement: Ticket,
  culture: Palette,
  association: Handshake,
  voyage: Globe2,
  rencontre: Heart,
  naissance: Baby,
  ceremonie: Feather,
};

export function universeIcon(slug?: string | null): LucideIcon {
  return (slug && UNIVERSE_ICONS[slug]) || Compass;
}

/** Pictos modernes par intention du bouton AIME. */
export const INTENT_ICONS: Record<AimeIntent, LucideIcon> = {
  aime: Heart,
  collaborer: Handshake,
  reserver: CalendarCheck,
  recommander: Star,
  associer: Puzzle,
  contacter: MessageCircle,
  enregistrer: Bookmark,
};

export function intentIcon(intent: AimeIntent): LucideIcon {
  return INTENT_ICONS[intent] ?? Compass;
}

/** Univers mis en avant dans le registre. */
export const FEATURED_UNIVERSES = ["mariage", "anniversaire", "concert", "voyage"] as const;
