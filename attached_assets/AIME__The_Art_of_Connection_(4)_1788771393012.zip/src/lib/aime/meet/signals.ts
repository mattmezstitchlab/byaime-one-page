/**
 * Les signaux de rencontre : dire bonjour, garder pour plus tard, suivre,
 * proposer une rencontre. Rien n'est binaire, rien n'est automatique.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { pushNotification } from "@/lib/aime/notifications";
import { ensureThread, sendMessage } from "@/lib/aime/messaging";
import type { Reason } from "./convergences";

export type MeetSignal = Database["public"]["Tables"]["meet_signals"]["Row"];
export type MeetProposal = Database["public"]["Tables"]["meet_proposals"]["Row"];

export type SignalKind = "bonjour" | "garde" | "suivi" | "proposition";

export const SIGNAL_LABEL: Record<SignalKind, string> = {
  bonjour: "Bonjour envoyé",
  garde: "Gardé pour plus tard",
  suivi: "Suivi",
  proposition: "Rencontre proposée",
};

export const PROPOSAL_PURPOSES = [
  { key: "cafe", label: "Un café" },
  { key: "evenement", label: "Se croiser à un événement" },
  { key: "projet", label: "Parler d'un projet" },
  { key: "collaboration", label: "Une collaboration" },
  { key: "faire-connaissance", label: "Faire connaissance" },
  { key: "autre", label: "Autre" },
] as const;

export function purposeLabel(key: string) {
  return PROPOSAL_PURPOSES.find((p) => p.key === key)?.label ?? key;
}

export function mySignalsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["meet-signals", userId],
    enabled: !!userId,
    queryFn: async (): Promise<MeetSignal[]> => {
      const { data, error } = await supabase
        .from("meet_signals")
        .select("*")
        .or(`from_user.eq.${userId},to_user.eq.${userId}`)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function myProposalsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["meet-proposals", userId],
    enabled: !!userId,
    queryFn: async (): Promise<MeetProposal[]> => {
      const { data, error } = await supabase
        .from("meet_proposals")
        .select("*")
        .or(`from_user.eq.${userId},to_user.eq.${userId}`)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });
}

/** Envoie un signal. Les raisons sont figées telles qu'elles étaient au moment de l'envoi. */
export async function sendSignal(input: {
  me: string;
  myCardId?: string | null;
  toUser: string;
  toCardId?: string | null;
  toName: string;
  kind: SignalKind;
  message?: string | null;
  reasons: Reason[];
}): Promise<MeetSignal> {
  const { data, error } = await supabase
    .from("meet_signals")
    .upsert(
      {
        from_user: input.me,
        to_user: input.toUser,
        from_card: input.myCardId ?? null,
        to_card: input.toCardId ?? null,
        kind: input.kind,
        message: input.message?.trim() || null,
        reasons: JSON.parse(JSON.stringify(input.reasons)) as Database["public"]["Tables"]["meet_signals"]["Row"]["reasons"],
        status: "envoye",
      },
      { onConflict: "from_user,to_user,kind" },
    )
    .select("*")
    .single();
  if (error) throw error;

  // « Garder pour plus tard » reste privé : personne n'est prévenu.
  if (input.kind !== "garde" && input.toCardId) {
    await pushNotification({
      userId: input.toUser,
      from: input.me,
      kind: "rencontre",
      title: input.kind === "bonjour" ? "Quelqu'un vous dit bonjour" : "Un nouveau signal de rencontre",
      body: input.message?.trim() || null,
      url: "/rencontres",
      targetType: "carte",
      targetId: input.toCardId,
    });
  }
  return data;
}

export async function withdrawSignal(id: string) {
  const { error } = await supabase.from("meet_signals").delete().eq("id", id);
  if (error) throw error;
}

/** Le destinataire répond : accepter ouvre l'échange, refuser ferme la porte. */
export async function respondToSignal(input: {
  signal: MeetSignal;
  me: string;
  status: "accepte" | "refuse" | "ignore";
}): Promise<string | null> {
  let threadId: string | null = input.signal.thread_id;
  if (input.status === "accepte" && !threadId) {
    threadId = await ensureThread({
      me: input.me,
      other: input.signal.from_user,
      cardId: input.signal.from_card,
      subject: "Rencontre",
    });
    if (input.signal.message) await sendMessage(threadId, input.signal.from_user, input.signal.message);
  }
  const { error } = await supabase
    .from("meet_signals")
    .update({ status: input.status, thread_id: threadId })
    .eq("id", input.signal.id);
  if (error) throw error;

  if (input.status === "accepte" && input.signal.to_card) {
    await pushNotification({
      userId: input.signal.from_user,
      from: input.me,
      kind: "rencontre",
      title: "Votre bonjour a été accepté",
      body: "Vous pouvez commencer à échanger.",
      url: "/rencontres",
      targetType: "carte",
      targetId: input.signal.to_card,
    });
  }
  return threadId;
}

export async function proposeMeeting(input: {
  me: string;
  toUser: string;
  toCardId?: string | null;
  signalId?: string | null;
  purpose: string;
  place?: string | null;
  moment?: string | null;
  message?: string | null;
}) {
  const { error } = await supabase.from("meet_proposals").insert({
    signal_id: input.signalId ?? null,
    from_user: input.me,
    to_user: input.toUser,
    purpose: input.purpose,
    place: input.place?.trim() || null,
    moment: input.moment || null,
    message: input.message?.trim() || null,
  });
  if (error) throw error;
  if (input.toCardId) {
    await pushNotification({
      userId: input.toUser,
      from: input.me,
      kind: "rencontre",
      title: "Une rencontre vous est proposée",
      body: `${purposeLabel(input.purpose)}${input.place ? ` — ${input.place}` : ""}`,
      url: "/rencontres",
      targetType: "carte",
      targetId: input.toCardId,
    });
  }
}

/** Une rencontre acceptée peut devenir un moment — seulement si les deux le veulent. */
export async function answerProposal(input: {
  proposal: MeetProposal;
  status: "accepte" | "refuse";
}) {
  const { error } = await supabase
    .from("meet_proposals")
    .update({ status: input.status })
    .eq("id", input.proposal.id);
  if (error) throw error;
}
