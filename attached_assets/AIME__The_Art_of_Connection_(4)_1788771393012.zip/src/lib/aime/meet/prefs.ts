/**
 * Les préférences de rencontre : ce que je cherche, jusqu'où, qui peut me parler.
 * Rien n'est visible tant que la personne ne l'a pas décidé.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type MeetPrefs = Database["public"]["Tables"]["meet_prefs"]["Row"];

export const MEET_INTENTS = [
  { key: "amitie", label: "Faire des connaissances" },
  { key: "collaboration", label: "Collaborer" },
  { key: "projet", label: "Monter un projet" },
  { key: "artistes", label: "Rencontrer des artistes" },
  { key: "professionnels", label: "Rencontrer des professionnels" },
  { key: "amoureux", label: "Rencontre amoureuse" },
  { key: "ouvert", label: "Je ne précise pas" },
] as const;

export type MeetIntent = (typeof MEET_INTENTS)[number]["key"];

export const PRO_INTENTS: string[] = ["collaboration", "projet", "artistes", "professionnels"];

export function intentLabel(key: string): string {
  return MEET_INTENTS.find((i) => i.key === key)?.label ?? key;
}

export const CONTACT_POLICIES = [
  { key: "tous", label: "Tout le monde" },
  { key: "convergents", label: "Seulement si nos chemins se croisent" },
  { key: "personne", label: "Personne pour l'instant" },
] as const;

export const MEET_RANGES = [
  { key: "ville", label: "Ma ville", km: 5 },
  { key: "40", label: "40 km", km: 40 },
  { key: "100", label: "100 km", km: 100 },
  { key: "region", label: "Ma région", km: 200 },
  { key: "all", label: "Partout", km: Infinity },
] as const;

export function rangeKm(key: string | null | undefined): number {
  return MEET_RANGES.find((r) => r.key === key)?.km ?? 100;
}

export function myMeetPrefsQuery(userId: string | null) {
  return queryOptions({
    queryKey: ["meet-prefs", userId],
    enabled: !!userId,
    queryFn: async (): Promise<MeetPrefs | null> => {
      const { data, error } = await supabase
        .from("meet_prefs")
        .select("*")
        .eq("user_id", userId!)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

/** Les personnes qui ont choisi d'être visibles dans Rencontres. */
export const visibleMeetPrefsQuery = queryOptions({
  queryKey: ["meet-prefs-visibles"],
  staleTime: 60_000,
  queryFn: async (): Promise<MeetPrefs[]> => {
    const { data, error } = await supabase
      .from("meet_prefs")
      .select("*")
      .eq("visible", true)
      .limit(300);
    if (error) throw error;
    return data ?? [];
  },
});

export async function saveMeetPrefs(input: {
  userId: string;
  cardId?: string | null;
  visible: boolean;
  intents: string[];
  rangeKey: string;
  contactPolicy: string;
  sharePosition: boolean;
  note?: string | null;
}) {
  const { error } = await supabase.from("meet_prefs").upsert(
    {
      user_id: input.userId,
      card_id: input.cardId ?? null,
      visible: input.visible,
      intents: input.intents,
      range_key: input.rangeKey,
      contact_policy: input.contactPolicy,
      share_position: input.sharePosition,
      note: input.note ?? null,
    },
    { onConflict: "user_id" },
  );
  if (error) throw error;
}
