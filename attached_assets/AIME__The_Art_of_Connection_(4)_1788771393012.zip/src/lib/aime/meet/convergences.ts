/**
 * Les convergences : pourquoi deux histoires pourraient se croiser.
 * Tout est calculé à partir de données déjà publiques (fiches publiées,
 * moments publics, disponibilités, participations d'événements) et chaque
 * rapprochement est accompagné de sa raison, en clair.
 */
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Card } from "@/lib/aime/types";
import { cardCoords, distanceKm } from "@/lib/aime/geo";
import { findUniverse } from "@/lib/aime/universeTree";
import { worldsForTrade, worldLabel } from "@/lib/aime/tradeWorlds";
import { intentLabel, rangeKm, type MeetPrefs } from "./prefs";

export type Axis = "passe" | "present" | "futur";

export const AXIS_LABEL: Record<Axis, string> = {
  passe: "Passé",
  present: "Présent",
  futur: "Futur",
};

export type Reason = { axis: Axis; label: string; weight: number };

export type Convergence = {
  userId: string;
  card: Card;
  prefs: MeetPrefs;
  reasons: Reason[];
  score: number;
  km: number | null;
  intents: string[];
};

type TimelineEntry = {
  card_id: string;
  title: string;
  starts_at: string;
  universe_slug: string | null;
};

type AvailabilityDay = { card_id: string; day: string; status: string };

type Participation = { card_id: string; event_id: string };

export type MeetPool = {
  prefs: MeetPrefs[];
  cards: Card[];
  timeline: TimelineEntry[];
  availability: AvailabilityDay[];
  participations: Participation[];
  events: { id: string; title: string; starts_at: string }[];
};

/** Toutes les données publiques nécessaires au calcul, en une seule passe. */
export const meetPoolQuery = queryOptions({
  queryKey: ["meet-pool"],
  staleTime: 60_000,
  queryFn: async (): Promise<MeetPool> => {
    const { data: prefs, error: prefsError } = await supabase
      .from("meet_prefs")
      .select("*")
      .eq("visible", true)
      .limit(300);
    if (prefsError) throw prefsError;
    const owners = (prefs ?? []).map((p) => p.user_id);
    if (!owners.length)
      return { prefs: [], cards: [], timeline: [], availability: [], participations: [], events: [] };

    const { data: cards, error: cardsError } = await supabase
      .from("cards")
      .select("*")
      .eq("published", true)
      .in("owner_id", owners);
    if (cardsError) throw cardsError;
    const cardIds = (cards ?? []).map((c) => c.id);
    if (!cardIds.length)
      return { prefs: prefs ?? [], cards: [], timeline: [], availability: [], participations: [], events: [] };

    const [tl, av, pa] = await Promise.all([
      supabase
        .from("card_timeline_entries")
        .select("card_id,title,starts_at,universe_slug")
        .eq("is_public", true)
        .in("card_id", cardIds)
        .limit(600),
      supabase
        .from("card_availability")
        .select("card_id,day,status")
        .in("card_id", cardIds)
        .gte("day", new Date().toISOString().slice(0, 10))
        .limit(600),
      supabase.from("event_participants").select("card_id,event_id").in("card_id", cardIds).limit(600),
    ]);
    if (tl.error) throw tl.error;
    if (av.error) throw av.error;
    if (pa.error) throw pa.error;

    const eventIds = Array.from(new Set((pa.data ?? []).map((p) => p.event_id)));
    let events: { id: string; title: string; starts_at: string }[] = [];
    if (eventIds.length) {
      const { data, error } = await supabase.from("events").select("id,title,starts_at").in("id", eventIds);
      if (error) throw error;
      events = data ?? [];
    }

    return {
      prefs: prefs ?? [],
      cards: cards ?? [],
      timeline: (tl.data ?? []) as TimelineEntry[],
      availability: (av.data ?? []) as AvailabilityDay[],
      participations: (pa.data ?? []) as Participation[],
      events,
    };
  },
});

function sharedList(a: string[] | null | undefined, b: string[] | null | undefined): string[] {
  const other = new Set((b ?? []).map((v) => v.toLowerCase()));
  return (a ?? []).filter((v) => other.has(v.toLowerCase()));
}

function dayFr(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
}

/** Construit les convergences entre moi et chaque personne visible. */
export function buildConvergences(input: {
  pool: MeetPool;
  myCard: Card | null;
  myPrefs: MeetPrefs | null;
  myUserId: string | null;
  blocked?: string[];
}): Convergence[] {
  const { pool, myCard, myPrefs, myUserId } = input;
  const blocked = new Set(input.blocked ?? []);
  const byOwner = new Map<string, Card>();
  for (const card of pool.cards) if (card.owner_id) byOwner.set(card.owner_id, card);

  const myPoint = myCard ? cardCoords(myCard) : null;
  const myWorlds = new Set(worldsForTrade(myCard?.category_slug));
  const myEvents = new Set(
    myCard ? pool.participations.filter((p) => p.card_id === myCard.id).map((p) => p.event_id) : [],
  );
  const myDays = new Set(
    myCard
      ? pool.availability.filter((a) => a.card_id === myCard.id && a.status !== "indisponible").map((a) => a.day)
      : [],
  );
  const myMoments = myCard ? pool.timeline.filter((t) => t.card_id === myCard.id) : [];
  const limit = rangeKm(myPrefs?.range_key);
  const out: Convergence[] = [];

  for (const prefs of pool.prefs) {
    if (prefs.user_id === myUserId || blocked.has(prefs.user_id)) continue;
    if (prefs.contact_policy === "personne") continue;
    const card = byOwner.get(prefs.user_id);
    if (!card) continue;

    const reasons: Reason[] = [];

    // Présent — le territoire
    const point = cardCoords(card);
    const km = myPoint && point ? Math.round(distanceKm(myPoint, point)) : null;
    if (km != null) {
      if (km <= 5 && card.city)
        reasons.push({ axis: "present", label: `Vous êtes dans la même ville : ${card.city}`, weight: 3 });
      else if (km <= limit)
        reasons.push({ axis: "present", label: `À environ ${km} km de vous`, weight: 2 });
    } else if (card.region && myCard?.region && card.region === myCard.region) {
      reasons.push({ axis: "present", label: `La même région : ${card.region}`, weight: 2 });
    }

    // Présent — les mondes et le métier
    const worlds = sharedList(card.universes, myCard?.universes);
    for (const slug of worlds.slice(0, 2)) {
      const uni = findUniverse(slug);
      reasons.push({ axis: "present", label: `Le même monde : ${uni?.label ?? slug}`, weight: 3 });
    }
    const tradeWorlds = worldsForTrade(card.category_slug).filter((w) => myWorlds.has(w));
    if (!worlds.length && tradeWorlds[0])
      reasons.push({
        axis: "present",
        label: `Des métiers voisins autour de ${worldLabel(tradeWorlds[0])}`,
        weight: 2,
      });
    const skills = sharedList(card.skills, myCard?.skills);
    if (skills.length)
      reasons.push({
        axis: "present",
        label: `Compétences croisées : ${skills.slice(0, 3).join(", ")}`,
        weight: 2,
      });

    // Passé — les chemins déjà croisés
    const theirEvents = pool.participations.filter((p) => p.card_id === card.id).map((p) => p.event_id);
    const common = theirEvents.filter((id) => myEvents.has(id));
    for (const id of common.slice(0, 2)) {
      const ev = pool.events.find((e) => e.id === id);
      const year = ev ? new Date(ev.starts_at).getFullYear() : null;
      reasons.push({
        axis: "passe",
        label: ev ? `${year} — vous étiez tous les deux à « ${ev.title} »` : "Un événement en commun",
        weight: 4,
      });
    }
    const now = Date.now();
    const theirMoments = pool.timeline.filter((t) => t.card_id === card.id);
    for (const mine of myMoments) {
      const mineTime = new Date(mine.starts_at).getTime();
      if (mineTime > now) continue;
      const near = theirMoments.find((t) => {
        const time = new Date(t.starts_at).getTime();
        return time <= now && Math.abs(time - mineTime) < 3 * 86400000;
      });
      if (near) {
        reasons.push({
          axis: "passe",
          label: `${new Date(mine.starts_at).getFullYear()} — vous avez peut-être été au même endroit (${near.title})`,
          weight: 3,
        });
        break;
      }
    }

    // Futur — ce qui vient
    const theirDays = pool.availability.filter((a) => a.card_id === card.id && a.status !== "indisponible");
    const sameDay = theirDays.find((d) => myDays.has(d.day));
    if (sameDay)
      reasons.push({ axis: "futur", label: `Vous êtes libres le ${dayFr(sameDay.day)}`, weight: 3 });
    const nextMoment = theirMoments
      .filter((t) => new Date(t.starts_at).getTime() > now)
      .sort((a, b) => a.starts_at.localeCompare(b.starts_at))[0];
    if (nextMoment) {
      const days = Math.max(1, Math.round((new Date(nextMoment.starts_at).getTime() - now) / 86400000));
      reasons.push({
        axis: "futur",
        label: `Dans ${days} j — « ${nextMoment.title} »`,
        weight: 2,
      });
    }

    // Les intentions déclarées
    const intents = sharedList(prefs.intents, myPrefs?.intents ?? []);
    for (const key of intents.slice(0, 2))
      reasons.push({ axis: "futur", label: `Une intention commune : ${intentLabel(key)}`, weight: 3 });

    if (!reasons.length) continue;
    out.push({
      userId: prefs.user_id,
      card,
      prefs,
      reasons,
      km,
      intents: prefs.intents ?? [],
      score: reasons.reduce((sum, r) => sum + r.weight, 0),
    });
  }

  return out.sort((a, b) => b.score - a.score);
}

export type MeetMode = "autour" | "convergences" | "exploration";

export function sortForMode(list: Convergence[], mode: MeetMode): Convergence[] {
  if (mode === "autour")
    return [...list].sort((a, b) => (a.km ?? 99999) - (b.km ?? 99999) || b.score - a.score);
  if (mode === "exploration")
    return [...list].sort((a, b) => (b.km ?? 0) - (a.km ?? 0) || a.score - b.score);
  return [...list].sort((a, b) => b.score - a.score);
}

export function reasonsByAxis(reasons: Reason[]): Record<Axis, Reason[]> {
  return {
    passe: reasons.filter((r) => r.axis === "passe"),
    present: reasons.filter((r) => r.axis === "present"),
    futur: reasons.filter((r) => r.axis === "futur"),
  };
}
