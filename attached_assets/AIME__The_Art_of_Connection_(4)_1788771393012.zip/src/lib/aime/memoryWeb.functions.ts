import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Mémoire Web — recherche de traces publiques.
 * Règle absolue : rien n'est jamais posé sur la ligne de temps ici.
 * On ne fait qu'écrire des propositions à valider par la personne.
 */

const MODEL = "google/gemini-3-flash";

const Input = z.object({
  cardId: z.string().uuid(),
  name: z.string().min(2).max(120),
  aliases: z.string().max(240).optional(),
  activity: z.string().max(160).optional(),
  places: z.string().max(160).optional(),
  keywords: z.string().max(240).optional(),
  from: z.string().max(4).optional(),
  to: z.string().max(4).optional(),
});

const KINDS = [
  "evenement",
  "souvenir",
  "jalon",
  "document",
  "message",
] as const;

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["moments"],
  properties: {
    moments: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: [
          "titre",
          "resume",
          "type",
          "date",
          "dateTexte",
          "lieu",
          "personnes",
          "confiance",
          "pourquoi",
          "source",
        ],
        properties: {
          titre: { type: "string" },
          resume: { type: "string" },
          type: { type: "string", enum: [...KINDS] },
          date: { type: "string", description: "AAAA-MM-JJ ou vide si inconnue" },
          dateTexte: { type: "string" },
          lieu: { type: "string" },
          personnes: { type: "array", items: { type: "string" } },
          confiance: { type: "string", enum: ["faible", "moyenne", "forte"] },
          pourquoi: { type: "string" },
          source: { type: "string" },
        },
      },
    },
  },
} as const;

type RawMoment = {
  titre: string;
  resume: string;
  type: string;
  date: string;
  dateTexte: string;
  lieu: string;
  personnes: string[];
  confiance: string;
  pourquoi: string;
  source: string;
};

type Page = { url: string; title: string; text: string };

/** Traces publiques trouvées sur le Web pour ce contexte. */
async function searchWeb(query: string, apiKey: string): Promise<Page[]> {
  const res = await fetch("https://api.firecrawl.dev/v1/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      query,
      limit: 8,
      scrapeOptions: { formats: ["markdown"], onlyMainContent: true },
    }),
  });
  if (!res.ok) throw new Error("La recherche sur le Web n'a pas abouti.");
  const json = (await res.json()) as {
    data?: { url?: string; title?: string; markdown?: string; description?: string }[];
  };
  return (json.data ?? [])
    .filter((r) => !!r.url)
    .map((r) => ({
      url: r.url!,
      title: r.title ?? r.url!,
      text: (r.markdown ?? r.description ?? "").slice(0, 6000),
    }))
    .filter((p) => p.text.length > 80);
}

function typeOfSource(url: string): string {
  const host = (() => {
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch {
      return "";
    }
  })();
  if (/youtube|vimeo|dailymotion/.test(host)) return "vidéo";
  if (/facebook|instagram|x\.com|twitter|linkedin/.test(host)) return "réseau social";
  if (/wikipedia|archive/.test(host)) return "archive";
  if (/bandcamp|soundcloud|discogs|songkick|bandsintown/.test(host)) return "musique";
  if (/presse|journal|news|actu|ouest-france|lemonde|figaro/.test(host)) return "presse";
  return host || "web";
}

export type WebMemoryRunResult = {
  found: number;
  kept: number;
  message: string;
};

/** Étape unique : chercher, analyser, et enregistrer des propositions « à valider ». */
export const runWebMemorySearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }): Promise<WebMemoryRunResult> => {
    const firecrawl = process.env["FIRECRAWL_API_KEY"];
    const lovable = process.env["LOVABLE_API_KEY"];
    if (!firecrawl) throw new Error("La recherche sur le Web n'est pas disponible pour l'instant.");
    if (!lovable) throw new Error("Aime n'est pas joignable pour l'instant.");

    const supabase = context.supabase;

    // La règle d'accès de la base vérifie déjà que la page appartient à la personne.
    const { data: card, error: cardErr } = await supabase
      .from("cards")
      .select("id, name, owner_id")
      .eq("id", data.cardId)
      .maybeSingle();
    if (cardErr) throw new Error(cardErr.message);
    if (!card || card.owner_id !== context.userId) {
      throw new Error("Cette page n'est pas la vôtre.");
    }

    const period =
      data.from || data.to ? `${data.from ?? ""}${data.to ? `-${data.to}` : ""}` : "";
    const query = [
      `"${data.name}"`,
      data.aliases,
      data.activity,
      data.places,
      data.keywords,
      period,
    ]
      .filter(Boolean)
      .join(" ");

    const pages = await searchWeb(query, firecrawl);
    if (!pages.length) {
      return { found: 0, kept: 0, message: "Aucune trace publique trouvée avec ce contexte." };
    }

    const corpus = pages
      .map((p, i) => `--- SOURCE ${i + 1} : ${p.title}\nURL : ${p.url}\n${p.text}`)
      .join("\n\n");

    const system = `Tu aides une personne à retrouver des traces publiques de son passé, pour compléter sa ligne de temps.
Tu reçois des extraits de pages publiques. Tu en tires des MOMENTS POSSIBLES, jamais des certitudes.
Règles :
- N'invente jamais une date : si la page ne donne pas de date claire, laisse "date" vide et écris ce que la page dit dans "dateTexte".
- "source" doit être exactement l'une des URL fournies.
- "pourquoi" explique en une phrase simple pourquoi ce moment semble concerner cette personne.
- "confiance" est faible si le nom peut désigner quelqu'un d'autre (homonyme) ou si la page est vague.
- Ignore les pages qui ne concernent visiblement pas cette personne.
- Français simple, pas de jargon. Maximum 12 moments.`;

    const user = `Personne : ${data.name}${data.aliases ? ` (aussi connue comme : ${data.aliases})` : ""}
Activité : ${data.activity || "non précisée"}
Lieux : ${data.places || "non précisés"}
Période visée : ${data.from || "?"} → ${data.to || "?"}
Mots-clés : ${data.keywords || "aucun"}

${corpus}`;

    const ai = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${lovable}` },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
        response_format: {
          type: "json_schema",
          json_schema: { name: "moments", strict: true, schema: SCHEMA },
        },
      }),
    });
    if (!ai.ok) throw new Error("L'analyse des pages trouvées n'a pas abouti.");
    const payload = (await ai.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = payload.choices?.[0]?.message?.content ?? "{}";
    let moments: RawMoment[] = [];
    try {
      moments = (JSON.parse(content).moments ?? []) as RawMoment[];
    } catch {
      moments = [];
    }
    if (!moments.length) {
      return {
        found: pages.length,
        kept: 0,
        message: "Des pages ont été lues, mais aucun moment clair n'en ressort.",
      };
    }

    // Doublons : on compare aux moments déjà présents sur la ligne de temps.
    const { data: existing } = await supabase
      .from("card_timeline_entries")
      .select("id, title, starts_at")
      .eq("card_id", data.cardId);

    const norm = (s: string) =>
      s
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9 ]/g, "")
        .trim();

    const findDuplicate = (m: RawMoment): string | null => {
      const t = norm(m.titre);
      const day = m.date ? new Date(m.date).getTime() : null;
      for (const e of existing ?? []) {
        const et = norm(e.title ?? "");
        const sameTitle = et && (et === t || et.includes(t) || t.includes(et));
        const close =
          day !== null && Math.abs(new Date(e.starts_at).getTime() - day) < 3 * 86400000;
        if (sameTitle && (day === null || close)) return e.id;
        if (close && sameTitle) return e.id;
      }
      return null;
    };

    const urls = new Set(pages.map((p) => p.url));
    const rows = moments
      .filter((m) => urls.has(m.source))
      .map((m) => ({
        card_id: data.cardId,
        created_by: context.userId,
        kind: (KINDS as readonly string[]).includes(m.type) ? m.type : "evenement",
        title: m.titre.slice(0, 200),
        summary: m.resume?.slice(0, 1200) || null,
        occurred_on: /^\d{4}-\d{2}-\d{2}$/.test(m.date) ? m.date : null,
        date_text: m.dateTexte?.slice(0, 200) || null,
        place: m.lieu?.slice(0, 160) || null,
        people: (m.personnes ?? []).slice(0, 12),
        source_url: m.source,
        source_title: pages.find((p) => p.url === m.source)?.title?.slice(0, 200) ?? null,
        source_type: typeOfSource(m.source),
        confidence: ["faible", "moyenne", "forte"].includes(m.confiance) ? m.confiance : "moyenne",
        reason: m.pourquoi?.slice(0, 400) || null,
        status: "trouvee",
        duplicate_of: findDuplicate(m),
        query,
      }));

    if (!rows.length) {
      return { found: pages.length, kept: 0, message: "Rien de solide à vous proposer." };
    }

    const { error: insErr, count } = await supabase
      .from("web_memory_finds")
      .upsert(rows as never, {
        onConflict: "card_id,source_url,title",
        ignoreDuplicates: true,
        count: "exact",
      });
    if (insErr) throw new Error(insErr.message);

    return {
      found: pages.length,
      kept: count ?? rows.length,
      message: `${rows.length} moment(s) possible(s) à examiner, tirés de ${pages.length} page(s).`,
    };
  });
