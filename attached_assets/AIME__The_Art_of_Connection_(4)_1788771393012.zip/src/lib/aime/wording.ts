/**
 * Les phrases du contrat produit, écrites une seule fois et répétées à l'identique
 * partout où elles doivent être lues (accueil, démonstration, projet).
 */

/** La chaîne récit → ligne de temps → projet → action, en une ligne. */
export const CHAIN_LINE =
  "Votre récit devient une seule ligne de temps. Le projet, c'est cette même ligne, avec ses actions.";

/** Le rôle d'AIME face à l'argent : orchestrer, jamais encaisser. */
export const NO_CASH_LINE =
  "AIME prépare et suit les paiements, mais ne les encaisse pas.";
