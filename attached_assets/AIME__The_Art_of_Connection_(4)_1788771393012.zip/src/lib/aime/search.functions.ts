import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  query: z.string().min(2).max(140),
});

export type PublicWebResult = {
  url: string;
  title: string;
  snippet: string;
  host: string;
};

export type PublicWebSearchResponse = {
  results: PublicWebResult[];
  message?: string;
};

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "web";
  }
}

function cleanSnippet(text: string) {
  return text
    .replace(/[#>*_`~[\]]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 240);
}

export const runPublicWebSearch = createServerFn({ method: "POST" })
  .validator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<PublicWebSearchResponse> => {
    const firecrawl = process.env["FIRECRAWL_API_KEY"];
    if (!firecrawl) {
      return {
        results: [],
        message: "La recherche Web n'est pas disponible pour l'instant.",
      };
    }

    const res = await fetch("https://api.firecrawl.dev/v1/search", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + firecrawl },
      body: JSON.stringify({
        query: data.query,
        limit: 6,
        scrapeOptions: { formats: ["markdown"], onlyMainContent: true },
      }),
    });

    if (!res.ok) {
      return {
        results: [],
        message: "Le Web ne répond pas pour l'instant.",
      };
    }

    const json = (await res.json()) as {
      data?: { url?: string; title?: string; markdown?: string; description?: string }[];
    };

    const results = (json.data ?? [])
      .filter(
        (item): item is { url: string; title?: string; markdown?: string; description?: string } =>
          typeof item.url === "string" && item.url.length > 0,
      )
      .map((item) => {
        const snippet = cleanSnippet(item.markdown ?? item.description ?? "");
        return {
          url: item.url,
          title: (item.title?.trim() || hostOf(item.url)).slice(0, 120),
          snippet,
          host: hostOf(item.url),
        };
      })
      .filter((item) => item.snippet.length > 40);

    return {
      results,
      ...(results.length === 0 ? { message: "Aucun résultat Web utile trouvé." } : {}),
    };
  });
