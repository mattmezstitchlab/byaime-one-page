import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MODEL = "google/gemini-3-flash";

const Turn = z.object({ mine: z.boolean(), text: z.string().max(2000) });

const Input = z.object({
  transcript: z.array(Turn).max(30).default([]),
  route: z.string().max(200).default("/"),
});

export type SupportReply = {
  reply: string;
  solved: boolean;
  needsHuman: boolean;
  summary: string;
  options: string[];
};

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["reply", "solved", "needsHuman", "summary", "options"],
  properties: {
    reply: { type: "string" },
    solved: { type: "boolean" },
    needsHuman: { type: "boolean" },
    summary: { type: "string" },
    options: { type: "array", items: { type: "string" } },
  },
} as const;

const SYSTEM = `Tu es Aime, l'agent d'accueil du site AIME, pendant sa phase bêta.
Ton rôle : accueillir un retour d'utilisateur, comprendre ce qui coince, et si une solution
existe, la donner tout de suite, simplement, en français clair.

Ton : tendre, direct, parfois un brin d'humour, jamais condescendant. Deux ou trois phrases
maximum par réponse. Tu ne promets aucun délai. Tu n'inventes aucune fonctionnalité.

Ce que tu sais du site : cartes universelles (recto/verso), Le Monde AIME (grille de cases),
Réseau (carte, liste, mosaïque), Projets, Bureau (documents, devis, factures, export),
Radio / Fréquence, Messages, Ma carte. Les fonctions marquées « up » font travailler l'IA :
elles sont gratuites pendant la bêta. Celles marquées « pro » demandent une case du Monde AIME.

- solved = true quand tu as donné une marche à suivre concrète qui devrait débloquer.
- needsHuman = true quand la personne bute encore après ton conseil, ou décrit un vrai bug :
  on lui proposera alors un membre qui a déjà franchi le même obstacle.
- summary = une ligne, factuelle, pour l'équipe (ce sera enregistré).
- options = 2 ou 3 suites possibles, très courtes, à proposer en boutons.`;

export const askSupport = createServerFn({ method: "POST" })
  .validator((d: unknown) => Input.parse(d))
  .handler(async ({ data }): Promise<SupportReply> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Aime n'est pas joignable pour l'instant.");

    const conversation = data.transcript
      .map((t) => `${t.mine ? "Personne" : "Aime"} : ${t.text}`)
      .join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: MODEL,
        instructions: SYSTEM,
        input: [
          {
            role: "user",
            content: [
              {
                type: "input_text",
                text: `Page où se trouve la personne : ${data.route}\n\nConversation :\n${conversation}`,
              },
            ],
          },
        ],
        text: { format: { type: "json_schema", name: "support", strict: true, schema: SCHEMA } },
      }),
    });

    if (!res.ok) {
      if (res.status === 429) throw new Error("Trop de demandes, réessayez dans un instant.");
      if (res.status === 402) throw new Error("Crédits IA épuisés pour cet espace.");
      throw new Error(`Aime a répondu ${res.status}.`);
    }

    const json = (await res.json()) as {
      output?: Array<{ content?: Array<{ text?: string }> }>;
      output_text?: string;
    };
    const raw =
      json.output_text ??
      json.output
        ?.flatMap((o) => o.content ?? [])
        .map((c) => c.text ?? "")
        .join("") ??
      "";

    try {
      return JSON.parse(raw) as SupportReply;
    } catch {
      return {
        reply: raw.slice(0, 600) || "Je n'ai pas bien saisi — pouvez-vous redire autrement ?",
        solved: false,
        needsHuman: false,
        summary: "Réponse non structurée",
        options: [],
      };
    }
  });
