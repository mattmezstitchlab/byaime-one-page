import { supabase } from "@/integrations/supabase/client";

/**
 * Rémunération des ayants droit.
 *
 * Le journal de diffusion existe déjà (`airplay_logs`). Ici on le transforme en
 * ce qui est dû : un barème déclaré par diffusion, réparti selon les parts
 * connues (`work_rights`). Rien n'est inventé : quand aucune part n'est
 * déclarée, la ligne le dit et reste « à documenter ».
 */

/** Barème déclaré d'AIME : ce qu'une diffusion doit à l'œuvre, en centimes. */
export const RATE_PER_PLAY_CENTS = 6;

export type RoyaltyRow = {
  key: string;
  title: string;
  artist: string | null;
  plays: number;
  seconds: number;
  dueCents: number;
  workId: string | null;
  holders: { name: string; role: string | null; share: number; dueCents: number }[];
  documented: boolean;
};

export function royaltiesQuery(userId: string | null) {
  return {
    queryKey: ["royalties", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<RoyaltyRow[]> => {
      if (!userId) return [];
      const { data: logs, error } = await supabase
        .from("airplay_logs")
        .select("id, work_id, title, artist, duration_sec")
        .eq("owner_id", userId)
        .order("started_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      const rows = logs ?? [];
      if (rows.length === 0) return [];

      const workIds = [...new Set(rows.map((r) => r.work_id).filter(Boolean) as string[])];
      let rights: { work_id: string; holder_name: string; role: string | null; share: number }[] =
        [];
      if (workIds.length > 0) {
        const { data } = await supabase
          .from("work_rights")
          .select("work_id, holder_name, role, share")
          .in("work_id", workIds);
        rights = (data ?? []).map((r) => ({ ...r, share: Number(r.share ?? 0) }));
      }

      const grouped = new Map<string, RoyaltyRow>();
      for (const r of rows) {
        const key = r.work_id ?? `${r.title ?? "Sans titre"}·${r.artist ?? ""}`;
        const cur =
          grouped.get(key) ??
          ({
            key,
            title: r.title ?? "Sans titre",
            artist: r.artist ?? null,
            plays: 0,
            seconds: 0,
            dueCents: 0,
            workId: r.work_id ?? null,
            holders: [],
            documented: false,
          } satisfies RoyaltyRow);
        cur.plays += 1;
        cur.seconds += r.duration_sec ?? 0;
        cur.dueCents = cur.plays * RATE_PER_PLAY_CENTS;
        grouped.set(key, cur);
      }

      for (const row of grouped.values()) {
        const list = row.workId ? rights.filter((x) => x.work_id === row.workId) : [];
        const total = list.reduce((s, x) => s + (x.share || 0), 0);
        row.documented = list.length > 0 && total > 0;
        row.holders = list.map((x) => ({
          name: x.holder_name,
          role: x.role,
          share: x.share,
          dueCents: row.documented ? Math.round((row.dueCents * x.share) / total) : 0,
        }));
      }

      return [...grouped.values()].sort((a, b) => b.dueCents - a.dueCents);
    },
  };
}

export function royaltiesTotals(rows: RoyaltyRow[]) {
  const dueCents = rows.reduce((s, r) => s + r.dueCents, 0);
  const documentedCents = rows.filter((r) => r.documented).reduce((s, r) => s + r.dueCents, 0);
  const plays = rows.reduce((s, r) => s + r.plays, 0);
  return { dueCents, documentedCents, toDocumentCents: dueCents - documentedCents, plays };
}

/**
 * Engager le reversement d'une œuvre : la somme due passe du relevé au grand
 * livre en tant que « reversement » à honorer. Ce n'est pas un paiement
 * automatique — c'est une dette reconnue, datée et traçable, réglée ensuite
 * par le circuit de versement du Bureau.
 */
export async function declareSettlement(userId: string, row: RoyaltyRow) {
  if (!row.documented) throw new Error("Déclarez d'abord les parts des ayants droit.");
  if (row.dueCents <= 0) throw new Error("Rien à reverser sur cette œuvre.");
  const holders = row.holders.map((h) => `${h.name} (${Math.round(h.share)}%)`).join(", ");
  const { error } = await supabase.from("credit_ledger").insert({
    user_id: userId,
    kind: "reversement",
    amount_cents: row.dueCents,
    credits: 0,
    method: "virement",
    status: "en_attente",
    note: `${row.title} — ${row.plays} diffusion(s) · ${holders}`,
  });
  if (error) throw error;
}
