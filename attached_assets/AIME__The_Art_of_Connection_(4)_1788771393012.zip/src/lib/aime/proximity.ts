/**
 * La proximité : d'abord ce qu'on sait déjà (table des villes AIME),
 * puis un géocodage public mis en cache pour les villes inconnues.
 * Rien n'est demandé au navigateur, aucune position n'est envoyée.
 */
import { useEffect, useMemo, useState } from "react";
import { coordsFor } from "./geo";

export type Point = { lat?: number | null; lon?: number | null };

const KEY = "aime:geo-cache:v1";

function normalize(city: string) {
  return city
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z]/g, "");
}

function readCache(): Record<string, Point | null> {
  try {
    return JSON.parse(window.localStorage.getItem(KEY) ?? "{}") as Record<string, Point | null>;
  } catch {
    return {};
  }
}

function writeCache(cache: Record<string, Point | null>) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(cache));
  } catch {
    /* mémoire pleine : on continue sans cache */
  }
}

/** Géocodage public d'une ville, utilisé seulement si la table locale ne sait pas. */
export async function resolveCity(city: string): Promise<Point | null> {
  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
        city,
      )}&count=1&language=fr&format=json`,
    );
    if (!res.ok) return null;
    const json = (await res.json()) as { results?: { latitude: number; longitude: number }[] };
    const hit = json.results?.[0];
    return hit ? { lat: hit.latitude, lon: hit.longitude } : null;
  } catch {
    return null;
  }
}

/**
 * Donne une fonction ville → point. Les villes connues d'AIME répondent
 * immédiatement ; les autres sont résolues une fois puis gardées en cache.
 */
export function useCityPoints(cities: (string | null | undefined)[]) {
  const key = useMemo(() => {
    const set = new Set<string>();
    for (const c of cities) if (c && c.trim() && !coordsFor(c)) set.add(normalize(c));
    return [...set].sort().join("|");
  }, [cities]);

  const [points, setPoints] = useState<Record<string, Point | null>>({});

  useEffect(() => {
    if (typeof window === "undefined") return;
    let alive = true;
    const cache = readCache();
    const wanted = key ? key.split("|") : [];
    const missing = wanted.filter((c) => c && !(c in cache));
    setPoints((cur) => ({ ...cache, ...cur }));
    if (missing.length === 0) return;

    void (async () => {
      const next = { ...cache };
      for (const c of missing) {
        next[c] = await resolveCity(c);
        if (!alive) return;
      }
      writeCache(next);
      if (alive) setPoints((cur) => ({ ...next, ...cur }));
    })();

    return () => {
      alive = false;
    };
  }, [key]);

  return useMemo(
    () =>
      (city: string | null | undefined): Point => {
        if (!city) return {};
        const known = coordsFor(city);
        if (known) return { lat: known[0], lon: known[1] };
        return points[normalize(city)] ?? {};
      },
    [points],
  );
}

export function sameCity(a: string | null | undefined, b: string | null | undefined) {
  return !!a && !!b && normalize(a) === normalize(b);
}

/** Les portées proposées, de la plus serrée à la plus large. */
export const RANGES = [
  { key: "ville", label: "Ma ville", km: 0 },
  { key: "40", label: "40 km", km: 40 },
  { key: "100", label: "100 km", km: 100 },
  { key: "region", label: "Ma région", km: 200 },
  { key: "all", label: "Partout", km: Infinity },
] as const;

export type RangeKey = (typeof RANGES)[number]["key"];

export function rangeKm(key: RangeKey) {
  return RANGES.find((r) => r.key === key)?.km ?? Infinity;
}

/** Portée de départ déduite du rayon déjà choisi pour la radio. */
export function rangeFromRadius(radiusKm: number | null | undefined): RangeKey {
  if (radiusKm == null) return "100";
  if (radiusKm <= 5) return "ville";
  if (radiusKm <= 40) return "40";
  if (radiusKm <= 100) return "100";
  if (radiusKm <= 250) return "region";
  return "all";
}

/**
 * Garde une place si elle entre dans la portée choisie.
 * Une distance inconnue n'est jamais masquée : elle est simplement reléguée.
 */
export function inRange(
  slot: { distanceKm: number | null; city: string | null },
  home: { city?: string | null },
  range: RangeKey,
) {
  if (range === "all") return true;
  if (slot.distanceKm == null) return true;
  if (range === "ville") return slot.distanceKm <= 5 || sameCity(slot.city, home.city);
  return slot.distanceKm <= rangeKm(range);
}
