/**
 * Les cinq niveaux de certitude de la mémoire AIME.
 * Jamais une note unique : on dit ce qu'on sait, et pourquoi on le sait.
 */
export type Certainty = "confirme" | "documente" | "hypothese" | "a_clarifier" | "infere";

export const CERTAINTIES: Certainty[] = [
  "confirme",
  "documente",
  "hypothese",
  "a_clarifier",
  "infere",
];

export const CERTAINTY_LABEL: Record<Certainty, string> = {
  confirme: "Confirmé",
  documente: "Documenté",
  hypothese: "Hypothèse",
  a_clarifier: "À clarifier",
  infere: "Inféré",
};

export const CERTAINTY_HINT: Record<Certainty, string> = {
  confirme: "Validé par la personne, ou appuyé par une preuve suffisante.",
  documente: "Vient d'une source identifiable, pas encore validée personnellement.",
  hypothese: "Correspondance possible, à examiner.",
  a_clarifier: "Il manque une vérification pour trancher.",
  infere: "Déduit logiquement de ce qui est connu, sans preuve directe.",
};

/** Trois formes visuelles, comprises sans manuel : plein, demi, vide. */
export type CertaintyShape = "plein" | "demi" | "vide";

export const CERTAINTY_SHAPE: Record<Certainty, CertaintyShape> = {
  confirme: "plein",
  documente: "plein",
  hypothese: "demi",
  a_clarifier: "vide",
  infere: "vide",
};

/** Les anciens niveaux des références restent lisibles dans le nouveau langage. */
export function certaintyFromSourceLevel(level: string): Certainty {
  if (level === "declare") return "confirme";
  if (level === "documente") return "documente";
  return "hypothese";
}

/** La confiance d'une trouvaille web n'est jamais une vérité : au mieux une hypothèse. */
export function certaintyFromConfidence(confidence: string | null | undefined): Certainty {
  if (confidence === "forte") return "documente";
  if (confidence === "moyenne") return "hypothese";
  return "a_clarifier";
}

/** Un élément d'explication : « période cohérente », « lieu cohérent »… */
export type EvidenceItem = { label: string; detail?: string; ok?: boolean };

export function evidenceList(raw: unknown): EvidenceItem[] {
  if (!Array.isArray(raw)) return [];
  return raw.flatMap((r) => {
    if (typeof r === "string") return [{ label: r }];
    if (r && typeof r === "object" && typeof (r as EvidenceItem).label === "string") {
      return [r as EvidenceItem];
    }
    return [];
  });
}
