import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import type { Card } from "@/lib/aime/types";

export type Post = Database["public"]["Tables"]["posts"]["Row"];

/** Une publication accompagnée de la page qui l'a écrite. */
export type FeedItem = Post & { card: Card | null };

export const PAGE_SIZE = 20;

async function withCards(rows: Post[]): Promise<FeedItem[]> {
  const ids = [...new Set(rows.map((r) => r.card_id))];
  if (!ids.length) return [];
  const { data: cards } = await supabase.from("cards").select("*").in("id", ids);
  const byId = new Map((cards ?? []).map((c) => [c.id, c as Card]));
  return rows.map((r) => ({ ...r, card: byId.get(r.card_id) ?? null }));
}

/** Le fil des pages suivies (et des miennes). */
export function feedQuery(cardIds: string[], page = 0) {
  const key = [...cardIds].sort();
  return {
    queryKey: ["fil", key, page],
    enabled: key.length > 0,
    queryFn: async (): Promise<FeedItem[]> => {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .in("card_id", key)
        .order("created_at", { ascending: false })
        .range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      if (error) throw error;
      return withCards(data ?? []);
    },
  };
}

/** Les publications récentes de tout le monde, pour découvrir. */
export function discoverFeedQuery(page = 0) {
  return {
    queryKey: ["fil-decouverte", page],
    queryFn: async (): Promise<FeedItem[]> => {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .eq("visibility", "public")
        .order("created_at", { ascending: false })
        .range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      if (error) throw error;
      return withCards(data ?? []);
    },
  };
}

/** Les publications d'une page précise. */
export function cardPostsQuery(cardId: string | null | undefined) {
  return {
    queryKey: ["publications", cardId ?? "none"],
    enabled: !!cardId,
    queryFn: async (): Promise<Post[]> => {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .eq("card_id", cardId!)
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return data ?? [];
    },
  };
}

export type NewPost = {
  cardId: string;
  authorId: string;
  body?: string | null;
  mediaUrl?: string | null;
  mediaKind?: string;
  visibility?: "public" | "prive";
};

export async function addPost(p: NewPost) {
  const body = p.body?.trim() || null;
  if (body && body.length > 3000) throw new Error("longueur");
  const { data, error } = await supabase
    .from("posts")
    .insert({
      card_id: p.cardId,
      author_id: p.authorId,
      body,
      media_url: p.mediaUrl ?? null,
      media_kind: p.mediaKind ?? "photo",
      visibility: p.visibility ?? "public",
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as Post;
}

export async function removePost(id: string) {
  const { error } = await supabase.from("posts").delete().eq("id", id);
  if (error) throw error;
}

/** Un temps lisible : « il y a 3 h ». */
export function ago(iso: string): string {
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "à l'instant";
  const m = Math.round(s / 60);
  if (m < 60) return `il y a ${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `il y a ${h} h`;
  const j = Math.round(h / 24);
  if (j < 7) return `il y a ${j} j`;
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
}
