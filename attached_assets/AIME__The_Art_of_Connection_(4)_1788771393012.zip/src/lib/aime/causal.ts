/**
 * Le moteur causal AIME, en quatre notions : point zéro, lien causal, onde, zone secrète.
 * Le moteur est unique ; chaque univers ne fournit que son dictionnaire (jargon, variables,
 * points de rupture). Aucun calcul n'est appliqué automatiquement : tout est proposé.
 */

export type CausalRole = {
  slug: string;
  label: string;
  /** Ce que ce rôle voit du projet. */
  sees: string[];
  /** Ce qui l'impacte sans qu'il le décide. */
  impacted: string[];
  /** Ce qui lui est masqué par conception. */
  hidden: string[];
  subtypes?: string[];
};

export type CausalLink = {
  /** Variable qui bouge. */
  from: string;
  /** Ce qui bouge en conséquence. */
  to: string;
  /** Direct : immédiat. Indirect : en second rideau. Différé : se voit plus tard. */
  wave: "direct" | "indirect" | "differe";
  effect: string;
};

export type UniverseCausality = {
  /** Slug d'univers (voir universeTree). */
  universe: string;
  label: string;
  /** Le paramètre irréversible qui amorce tout. */
  zeroPoint: string;
  /** La variable qui fait tout basculer. */
  criticalVariable: string;
  /** Le point de rupture le plus fréquent, en clair. */
  rupture: string;
  /** Ce qui doit rester masqué, même quand le créneau est visible. */
  secret: string | null;
  roles: CausalRole[];
  links: CausalLink[];
};

const COMMON_ORGANIZER: CausalRole = {
  slug: "organisateur",
  label: "Organisateur",
  sees: ["Le budget global", "Tous les participants", "Le calendrier complet"],
  impacted: ["Les confirmations tardives", "Les changements de date", "Les dépassements"],
  hidden: ["Ce que les porteurs d'un secret préparent"],
};

const COMMON_GUEST: CausalRole = {
  slug: "participant",
  label: "Participant",
  sees: ["La date, le lieu, le déroulé public"],
  impacted: ["Un changement d'horaire", "Un changement de lieu"],
  hidden: ["Le budget", "Les contrats", "Les créneaux réservés"],
};

export const CAUSALITY: UniverseCausality[] = [
  {
    universe: "evenement",
    label: "Événement",
    zeroPoint: "La date et la capacité du lieu",
    criticalVariable: "Le nombre de convives",
    rupture:
      "+10 convives, et le traiteur, la salle, le plan de table et le budget bougent ensemble",
    secret: "Les surprises et les discours préparés",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "couple",
        label: "Couple",
        sees: ["Lieu", "Prestataires", "Invités", "Budget"],
        impacted: ["Nombre d'invités", "Date", "Budget global"],
        hidden: ["Surprises des témoins", "Discours", "Cadeaux"],
        subtypes: ["Autonome", "Avec organisateur"],
      },
      {
        slug: "temoin",
        label: "Témoin",
        sees: ["Le déroulé", "Le créneau qui lui est réservé"],
        impacted: ["Décalage de la cérémonie", "Durée du dîner"],
        hidden: ["Le budget global", "Les contrats"],
      },
      {
        slug: "prestataire",
        label: "Prestataire",
        sees: ["Sa mission", "Son créneau", "Le lieu"],
        impacted: ["Retard du créneau précédent", "Nombre final de convives"],
        hidden: ["Les tarifs des autres prestataires"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Nombre de convives",
        to: "Traiteur",
        wave: "direct",
        effect: "Couverts et coût par personne recalculés",
      },
      { from: "Nombre de convives", to: "Lieu", wave: "direct", effect: "Capacité à revérifier" },
      {
        from: "Nombre de convives",
        to: "Budget",
        wave: "indirect",
        effect: "Rééquilibrage des postes",
      },
      {
        from: "Nombre de convives",
        to: "Plan de table",
        wave: "differe",
        effect: "À refaire avant le Jour J",
      },
      { from: "Date", to: "Prestataires", wave: "direct", effect: "Disponibilités à reconfirmer" },
      {
        from: "Horaire de cérémonie",
        to: "Photographe",
        wave: "indirect",
        effect: "Séquences décalées",
      },
    ],
  },
  {
    universe: "musique",
    label: "Musique & Scène",
    zeroPoint: "L'heure de balance",
    criticalVariable: "La durée du set",
    rupture: "Balance décalée, et l'ouverture des portes puis le couvre-feu suivent",
    secret: "L'invité surprise, le morceau caché",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "artiste",
        label: "Artiste",
        sees: ["Sa loge", "Sa balance", "Son passage"],
        impacted: ["Retard de la balance", "Changement de plateau"],
        hidden: ["Les cachets des autres artistes"],
      },
      {
        slug: "regie",
        label: "Régie",
        sees: ["Le conducteur complet", "Le plan de scène"],
        impacted: ["Changement de durée de set", "Couvre-feu"],
        hidden: ["Les négociations de cachet"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Heure de balance",
        to: "Ouverture des portes",
        wave: "direct",
        effect: "Décalage du public",
      },
      {
        from: "Durée du set",
        to: "Couvre-feu",
        wave: "direct",
        effect: "Risque de dépassement réglementaire",
      },
      {
        from: "Durée du set",
        to: "Plateau suivant",
        wave: "indirect",
        effect: "Changement de plateau raccourci",
      },
      {
        from: "Couvre-feu",
        to: "Démontage",
        wave: "differe",
        effect: "Heures d'équipe supplémentaires",
      },
    ],
  },
  {
    universe: "culture",
    label: "Culture & Art",
    zeroPoint: "La date de vernissage",
    criticalVariable: "Le nombre d'œuvres et la surface disponible",
    rupture: "Une œuvre en retard, et l'accrochage, l'assurance et le catalogue bougent",
    secret: "La pièce dévoilée le soir même",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "artiste",
        label: "Artiste",
        sees: ["Son espace", "Le calendrier d'accrochage"],
        impacted: ["Retard de transport", "Surface réattribuée"],
        hidden: ["Les valeurs d'assurance des autres œuvres"],
      },
      {
        slug: "commissaire",
        label: "Commissaire",
        sees: ["Le parcours complet", "Les prêts"],
        impacted: ["Œuvre indisponible", "Contraintes de conservation"],
        hidden: ["Les prix de vente confidentiels"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Livraison d'une œuvre",
        to: "Accrochage",
        wave: "direct",
        effect: "Planning d'accrochage décalé",
      },
      { from: "Nombre d'œuvres", to: "Surface", wave: "direct", effect: "Parcours à redessiner" },
      {
        from: "Nombre d'œuvres",
        to: "Assurance",
        wave: "indirect",
        effect: "Valeur assurée à réviser",
      },
      { from: "Parcours", to: "Catalogue", wave: "differe", effect: "Impression à relancer" },
    ],
  },
  {
    universe: "entreprise",
    label: "Entreprise & Pro",
    zeroPoint: "La date et le nombre d'inscrits",
    criticalVariable: "Les inscrits confirmés",
    rupture: "Salle sous-dimensionnée, et le traiteur, les badges et la régie suivent",
    secret: "L'annonce sous embargo",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "intervenant",
        label: "Intervenant",
        sees: ["Son créneau", "La salle", "Le matériel"],
        impacted: ["Décalage du programme", "Changement de format"],
        hidden: ["Les honoraires des autres intervenants"],
      },
      COMMON_GUEST,
    ],
    links: [
      { from: "Inscrits confirmés", to: "Salle", wave: "direct", effect: "Capacité à revérifier" },
      {
        from: "Inscrits confirmés",
        to: "Traiteur",
        wave: "direct",
        effect: "Pauses et déjeuners recalculés",
      },
      {
        from: "Inscrits confirmés",
        to: "Badges",
        wave: "indirect",
        effect: "Impression à relancer",
      },
      { from: "Programme", to: "Régie", wave: "differe", effect: "Conducteur technique à refaire" },
    ],
  },
  {
    universe: "lieux",
    label: "Lieux & Réception",
    zeroPoint: "La capacité homologuée",
    criticalVariable: "Le créneau de montage",
    rupture: "Montage raccourci, et le décor, la sécurité et les horaires se compriment",
    secret: "Un autre client sur le même week-end",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "lieu",
        label: "Lieu",
        sees: ["Tous les prestataires qui entrent", "Les horaires"],
        impacted: ["Changement de jauge", "Retard de montage"],
        hidden: ["Le budget du client"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Créneau de montage",
        to: "Décor",
        wave: "direct",
        effect: "Installation à réduire ou décaler",
      },
      { from: "Jauge", to: "Sécurité", wave: "direct", effect: "Effectif de sécurité à réviser" },
      {
        from: "Retard de montage",
        to: "Ouverture",
        wave: "indirect",
        effect: "Accueil du public décalé",
      },
      {
        from: "Horaire de fin",
        to: "État des lieux",
        wave: "differe",
        effect: "Nettoyage repoussé",
      },
    ],
  },
  {
    universe: "table",
    label: "Table & Saveurs",
    zeroPoint: "Le nombre de couverts",
    criticalVariable: "Les régimes et allergènes",
    rupture: "Régimes annoncés tard, et les commandes, le coût et le service bougent",
    secret: "Le gâteau ou le menu surprise",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "traiteur",
        label: "Traiteur",
        sees: ["Couverts", "Régimes", "Horaires de service"],
        impacted: ["Changement de nombre", "Retard du déroulé"],
        hidden: ["Les tarifs des autres prestataires"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Nombre de couverts",
        to: "Commandes",
        wave: "direct",
        effect: "Volumes à recalculer",
      },
      { from: "Régimes", to: "Menu", wave: "direct", effect: "Alternatives à prévoir" },
      {
        from: "Nombre de couverts",
        to: "Service",
        wave: "indirect",
        effect: "Effectif en salle à ajuster",
      },
      {
        from: "Horaire du dîner",
        to: "Cuisson",
        wave: "differe",
        effect: "Production à replanifier",
      },
    ],
  },
  {
    universe: "image",
    label: "Image & Souvenirs",
    zeroPoint: "L'heure de la lumière",
    criticalVariable: "L'ordre des séquences",
    rupture: "Cérémonie en retard, et les photos de groupe se perdent avec le jour",
    secret: "Le cadeau filmé à l'avance",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "photographe",
        label: "Photographe",
        sees: ["Le déroulé", "Les moments clés", "La lumière"],
        impacted: ["Retard de cérémonie", "Changement de lieu"],
        hidden: ["Le budget global"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Horaire de cérémonie",
        to: "Photos de groupe",
        wave: "direct",
        effect: "Créneau de lumière réduit",
      },
      { from: "Lieu", to: "Repérage", wave: "direct", effect: "Repérage à refaire" },
      { from: "Déroulé", to: "Vidéaste", wave: "indirect", effect: "Placement caméra à revoir" },
      {
        from: "Volume d'images",
        to: "Livraison",
        wave: "differe",
        effect: "Délai de retouche allongé",
      },
    ],
  },
  {
    universe: "style",
    label: "Beauté & Style",
    zeroPoint: "L'heure de départ",
    criticalVariable: "Le nombre de mises en beauté",
    rupture: "+2 personnes, et le réveil avance de 90 minutes",
    secret: null,
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "beaute",
        label: "Coiffure & maquillage",
        sees: ["Le nombre de personnes", "L'heure de départ"],
        impacted: ["Ajout de dernière minute", "Changement d'horaire"],
        hidden: ["Le budget global"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Nombre de mises en beauté",
        to: "Heure de réveil",
        wave: "direct",
        effect: "Départ des préparatifs avancé",
      },
      {
        from: "Heure de départ",
        to: "Photographe",
        wave: "indirect",
        effect: "Préparatifs à couvrir plus tôt",
      },
      {
        from: "Retard des préparatifs",
        to: "Cérémonie",
        wave: "differe",
        effect: "Tout le déroulé glisse",
      },
    ],
  },
  {
    universe: "patrimoine",
    label: "Patrimoine & Biens",
    zeroPoint: "La date de disponibilité",
    criticalVariable: "L'état des lieux",
    rupture: "Livraison décalée, et le montage, la caution et l'assurance suivent",
    secret: "Le prix négocié",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "loueur",
        label: "Loueur",
        sees: ["Le matériel réservé", "Les créneaux"],
        impacted: ["Retour tardif", "Casse constatée"],
        hidden: ["Les autres devis du client"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Date de livraison",
        to: "Montage",
        wave: "direct",
        effect: "Créneau d'installation décalé",
      },
      { from: "État des lieux", to: "Caution", wave: "direct", effect: "Retenue possible" },
      {
        from: "Retard de retour",
        to: "Location suivante",
        wave: "indirect",
        effect: "Client suivant impacté",
      },
      { from: "Casse", to: "Assurance", wave: "differe", effect: "Déclaration à ouvrir" },
    ],
  },
  {
    universe: "voyage",
    label: "Voyage & Séjour",
    zeroPoint: "La date de réservation",
    criticalVariable: "Le nombre de chambres",
    rupture: "Groupe réduit, et le tarif de groupe tombe pendant que les navettes tournent vides",
    secret: "Le voyage offert",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "hebergeur",
        label: "Hébergeur",
        sees: ["Les nuitées", "Les arrivées"],
        impacted: ["Annulations tardives", "Changement de dates"],
        hidden: ["Le budget global du groupe"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Nombre de chambres",
        to: "Tarif de groupe",
        wave: "direct",
        effect: "Seuil de remise à revérifier",
      },
      {
        from: "Nombre de voyageurs",
        to: "Navettes",
        wave: "direct",
        effect: "Rotations à réajuster",
      },
      { from: "Dates", to: "Annulation", wave: "indirect", effect: "Conditions et frais modifiés" },
      { from: "Arrivées", to: "Accueil", wave: "differe", effect: "Planning d'accueil à refaire" },
    ],
  },
  {
    universe: "lien",
    label: "Lien & Rencontre",
    zeroPoint: "La première proposition",
    criticalVariable: "La disponibilité réelle",
    rupture: "Un créneau annulé, et toute la chaîne d'intentions se décale",
    secret: "Le message pas encore envoyé",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "invite",
        label: "Personne invitée",
        sees: ["La proposition", "Le lieu"],
        impacted: ["Annulation", "Changement d'horaire"],
        hidden: ["Les autres propositions en cours"],
      },
    ],
    links: [
      {
        from: "Créneau proposé",
        to: "Réponse",
        wave: "direct",
        effect: "Délai de réponse relancé",
      },
      {
        from: "Annulation",
        to: "Chaîne d'intentions",
        wave: "indirect",
        effect: "Propositions suivantes à replanifier",
      },
      {
        from: "Silence prolongé",
        to: "Intention",
        wave: "differe",
        effect: "Intention à clore ou relancer",
      },
    ],
  },
  {
    universe: "solidarite",
    label: "Association & Solidarité",
    zeroPoint: "La date de collecte",
    criticalVariable: "Les bénévoles confirmés",
    rupture: "Bénévoles manquants, et le périmètre, la sécurité et l'autorisation sont en jeu",
    secret: "Le montant d'un don anonyme",
    roles: [
      COMMON_ORGANIZER,
      {
        slug: "benevole",
        label: "Bénévole",
        sees: ["Son créneau", "Son poste"],
        impacted: ["Désistement d'un autre bénévole", "Changement de lieu"],
        hidden: ["L'identité des donateurs anonymes"],
      },
      COMMON_GUEST,
    ],
    links: [
      {
        from: "Bénévoles confirmés",
        to: "Périmètre",
        wave: "direct",
        effect: "Zones à réduire ou fermer",
      },
      {
        from: "Bénévoles confirmés",
        to: "Sécurité",
        wave: "direct",
        effect: "Effectif minimum à respecter",
      },
      {
        from: "Périmètre",
        to: "Autorisation",
        wave: "indirect",
        effect: "Déclaration à mettre à jour",
      },
      {
        from: "Collecte",
        to: "Reçus fiscaux",
        wave: "differe",
        effect: "Édition des reçus à préparer",
      },
    ],
  },
];

export const CAUSALITY_BY_UNIVERSE = new Map(CAUSALITY.map((c) => [c.universe, c]));

/** Repli sur Événement : c'est le monde le plus dense, donc le plus sûr par défaut. */
export function causalityFor(universeSlug?: string | null): UniverseCausality {
  return (
    (universeSlug ? CAUSALITY_BY_UNIVERSE.get(universeSlug) : undefined) ??
    (CAUSALITY[0] as UniverseCausality)
  );
}

export const WAVE_LABEL: Record<CausalLink["wave"], string> = {
  direct: "Impact direct",
  indirect: "Impact indirect",
  differe: "Impact différé",
};

export const WAVE_HINT: Record<CausalLink["wave"], string> = {
  direct: "Se produit tout de suite.",
  indirect: "Arrive en second rideau, via un autre acteur.",
  differe: "Ne se voit que plus tard, souvent trop tard.",
};

/** Les ondes déclenchées par une variable, triées de l'immédiat au différé. */
export function wavesFrom(universeSlug: string | null | undefined, variable: string): CausalLink[] {
  const order: CausalLink["wave"][] = ["direct", "indirect", "differe"];
  return causalityFor(universeSlug)
    .links.filter((l) => l.from.toLowerCase() === variable.toLowerCase())
    .sort((a, b) => order.indexOf(a.wave) - order.indexOf(b.wave));
}

/** Les variables sources de l'univers, sans doublon. */
export function causalVariables(universeSlug?: string | null): string[] {
  return [...new Set(causalityFor(universeSlug).links.map((l) => l.from))];
}

export function roleFor(
  universeSlug: string | null | undefined,
  roleSlug: string,
): CausalRole | undefined {
  return causalityFor(universeSlug).roles.find((r) => r.slug === roleSlug);
}
