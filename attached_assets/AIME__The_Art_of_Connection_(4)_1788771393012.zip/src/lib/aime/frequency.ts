import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type TimelineEffect = Database["public"]["Tables"]["timeline_effects"]["Row"];
export type TimelineEntry = Database["public"]["Tables"]["card_timeline_entries"]["Row"];
export type CardKind = Database["public"]["Enums"]["card_kind"];

export type EffectSource = "declare" | "documente" | "estime";
export type EffectConfidence = "faible" | "moyenne" | "haute";

/** Une Fréquence n'est jamais un score : c'est une lecture de ce qui a bougé. */
export const SOURCE_LABEL: Record<EffectSource, string> = {
  declare: "Déclaré",
  documente: "Documenté",
  estime: "Estimé",
};

export const SOURCE_HINT: Record<EffectSource, string> = {
  declare: "Affirmé par le propriétaire, sans pièce jointe.",
  documente: "Adossé à une pièce du Bureau (facture, diagnostic, contrat).",
  estime: "Issu d'une source externe (barème, indice) — jamais inventé.",
};

export const CONFIDENCE_LABEL: Record<EffectConfidence, string> = {
  faible: "Confiance faible",
  moyenne: "Confiance moyenne",
  haute: "Confiance haute",
};

export const DIRECTION_SIGN: Record<string, string> = {
  hausse: "▲",
  baisse: "▼",
  neutre: "—",
};

/**
 * Le type de Monde décide de ce qui est autorisé.
 * Une personne n'a JAMAIS d'indicateur chiffré : sa fréquence est narrative.
 */
export function allowsIndicators(kind?: CardKind | null): boolean {
  if (!kind) return false;
  return kind !== "personne" && kind !== "evenement";
}

/** Confiance dérivée mécaniquement de la preuve, jamais saisie à la main. */
export function deriveConfidence(source: EffectSource, hasDocument: boolean): EffectConfidence {
  if (source === "documente" && hasDocument) return "haute";
  if (source === "documente" || source === "estime") return "moyenne";
  return "faible";
}

/** Natures proposées, communes à tous les types de Mondes. */
export const NATURES = [
  "Travaux",
  "Énergie",
  "Équipement",
  "Entretien",
  "Contribution",
  "Formation",
  "Accompagnement",
  "Réalisation",
  "Étape",
] as const;

/** Effets d'évolution d'une carte (jointure faite côté client sur les repères). */
export function effectsQuery(cardId?: string | null) {
  return queryOptions({
    queryKey: ["timeline-effects", cardId],
    enabled: !!cardId,
    queryFn: async (): Promise<TimelineEffect[]> => {
      const { data, error } = await supabase
        .from("timeline_effects")
        .select("*")
        .eq("card_id", cardId!)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export type EffectWithEntry = TimelineEffect & { entry: TimelineEntry | null };

/** Lecture de la Fréquence : passé récent, présent, à venir — calculée, jamais stockée. */
export type FrequencyReading = {
  recent: EffectWithEntry[];
  upcoming: TimelineEntry[];
  ongoing: TimelineEntry[];
  /** Cumuls par nature, séparés par source. Aucun total unique. */
  indicators: {
    nature: string;
    unit: string | null;
    source: EffectSource;
    total: number;
    count: number;
    confidence: EffectConfidence;
  }[];
};

export function readFrequency(
  entries: TimelineEntry[],
  effects: TimelineEffect[],
  kind: CardKind | null | undefined,
  now = new Date(),
): FrequencyReading {
  const byId = new Map(entries.map((e) => [e.id, e]));
  const enriched: EffectWithEntry[] = effects.map((f) => ({
    ...f,
    entry: byId.get(f.entry_id) ?? null,
  }));

  const at = (e: EffectWithEntry) => new Date(e.entry?.starts_at ?? e.created_at).getTime();

  const recent = enriched
    .filter((e) => at(e) <= now.getTime())
    .sort((a, b) => at(b) - at(a))
    .slice(0, 8);

  const ongoing = entries.filter((e) => {
    const s = new Date(e.starts_at).getTime();
    const end = e.ends_at ? new Date(e.ends_at).getTime() : null;
    return s <= now.getTime() && end !== null && end >= now.getTime();
  });

  const upcoming = entries
    .filter((e) => new Date(e.starts_at).getTime() > now.getTime())
    .sort((a, b) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime())
    .slice(0, 5);

  const indicators: FrequencyReading["indicators"] = [];
  if (allowsIndicators(kind)) {
    const buckets = new Map<string, FrequencyReading["indicators"][number]>();
    for (const f of effects) {
      if (f.value === null || f.value === undefined) continue;
      const source = f.source as EffectSource;
      const key = `${f.nature}|${f.unit ?? ""}|${source}`;
      const signed = f.direction === "baisse" ? -Number(f.value) : Number(f.value);
      const cur = buckets.get(key);
      if (cur) {
        cur.total += signed;
        cur.count += 1;
        if (cur.confidence !== (f.confidence as EffectConfidence)) {
          // La confiance affichée est toujours la plus basse du lot.
          const rank: Record<EffectConfidence, number> = { faible: 0, moyenne: 1, haute: 2 };
          if (rank[f.confidence as EffectConfidence] < rank[cur.confidence]) {
            cur.confidence = f.confidence as EffectConfidence;
          }
        }
      } else {
        buckets.set(key, {
          nature: f.nature,
          unit: f.unit,
          source,
          total: signed,
          count: 1,
          confidence: f.confidence as EffectConfidence,
        });
      }
    }
    indicators.push(...buckets.values());
  }

  return { recent, ongoing, upcoming, indicators };
}

export function formatIndicator(total: number, unit: string | null) {
  const value = Number.isInteger(total) ? total : Math.round(total * 100) / 100;
  return `${value.toLocaleString("fr-FR")}${unit ? ` ${unit}` : ""}`;
}
