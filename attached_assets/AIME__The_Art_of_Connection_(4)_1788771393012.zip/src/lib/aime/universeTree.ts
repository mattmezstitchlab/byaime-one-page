/** Les 12 univers AIME et leurs sous-univers (structure front, aucune migration). */

export type SubUniverse = {
  slug: string;
  label: string;
  /** Slug d'univers existant en base, si le sous-univers y correspond. */
  db?: string;
  /** Mots-clés de repli pour filtrer les cartes. */
  keywords?: string[];
};

export type UniverseNode = {
  slug: string;
  label: string;
  /** Clé de la vidéo (voir universeMedia). */
  video: string;
  /** Slugs d'univers en base rattachés à ce parent. */
  db: string[];
  keywords: string[];
  subs: SubUniverse[];
};

export const UNIVERSE_TREE: UniverseNode[] = [
  {
    slug: "evenement",
    label: "Événement",
    video: "evenement",
    db: ["evenement", "mariage", "anniversaire", "naissance", "ceremonie"],
    keywords: ["événement", "fête", "célébration"],
    subs: [
      { slug: "mariage", label: "Mariage", db: "mariage" },
      { slug: "anniversaire", label: "Anniversaire", db: "anniversaire" },
      { slug: "bapteme", label: "Baptême", keywords: ["baptême", "bapteme"] },
      { slug: "ceremonie", label: "Cérémonie", db: "ceremonie" },
      { slug: "naissance", label: "Naissance", db: "naissance" },
      { slug: "fete-privee", label: "Fête privée", keywords: ["fête", "privée", "soirée"] },
      { slug: "evjf-evg", label: "EVJF / EVG", keywords: ["evjf", "evg", "enterrement de vie"] },
    ],
  },
  {
    slug: "musique",
    label: "Musique & Scène",
    video: "concert",
    db: ["concert"],
    keywords: ["musique", "musicien", "scène", "concert"],
    subs: [
      { slug: "concert", label: "Concert", db: "concert" },
      { slug: "dj", label: "DJ", keywords: ["dj", "mix"] },
      { slug: "festival", label: "Festival", keywords: ["festival"] },
      { slug: "groupe-live", label: "Groupe live", keywords: ["groupe", "live", "orchestre"] },
      { slug: "karaoke", label: "Karaoké", keywords: ["karaoké", "karaoke"] },
      { slug: "studio", label: "Studio", keywords: ["studio", "enregistrement"] },
    ],
  },
  {
    slug: "culture",
    label: "Culture & Art",
    video: "culture",
    db: ["culture"],
    keywords: ["culture", "art", "artiste"],
    subs: [
      { slug: "exposition", label: "Exposition", keywords: ["exposition", "expo", "galerie"] },
      { slug: "theatre", label: "Théâtre", keywords: ["théâtre", "theatre", "comédien"] },
      { slug: "musee", label: "Musée", keywords: ["musée", "musee", "patrimoine"] },
      {
        slug: "artisanat",
        label: "Artisanat d'art",
        keywords: ["artisan", "artisanat", "atelier"],
      },
      { slug: "cinema", label: "Cinéma", keywords: ["cinéma", "cinema", "film"] },
      { slug: "litterature", label: "Littérature", keywords: ["littérature", "livre", "auteur"] },
    ],
  },
  {
    slug: "entreprise",
    label: "Entreprise & Pro",
    video: "entreprise",
    db: ["entreprise"],
    keywords: ["entreprise", "professionnel", "business"],
    subs: [
      { slug: "seminaire", label: "Séminaire", keywords: ["séminaire", "seminaire"] },
      { slug: "team-building", label: "Team building", keywords: ["team building", "cohésion"] },
      { slug: "lancement", label: "Lancement produit", keywords: ["lancement", "inauguration"] },
      { slug: "coworking", label: "Coworking", keywords: ["coworking", "bureau"] },
      { slug: "formation", label: "Formation", keywords: ["formation", "coach", "atelier"] },
      { slug: "salon", label: "Salon", keywords: ["salon", "stand", "congrès"] },
    ],
  },
  {
    slug: "lieux",
    label: "Lieux & Réception",
    video: "mariage",
    db: [],
    keywords: ["lieu", "salle", "réception", "domaine", "château"],
    subs: [
      { slug: "salle", label: "Salle", keywords: ["salle", "réception"] },
      { slug: "chateau", label: "Château", keywords: ["château", "chateau"] },
      { slug: "domaine", label: "Domaine", keywords: ["domaine", "ferme", "grange"] },
      { slug: "rooftop", label: "Rooftop", keywords: ["rooftop", "toit", "terrasse"] },
      { slug: "jardin", label: "Jardin", keywords: ["jardin", "parc", "extérieur"] },
      { slug: "chapiteau", label: "Chapiteau", keywords: ["chapiteau", "tente"] },
    ],
  },
  {
    slug: "table",
    label: "Table & Saveurs",
    video: "anniversaire",
    db: [],
    keywords: ["traiteur", "cuisine", "gastronomie", "food"],
    subs: [
      { slug: "traiteur", label: "Traiteur", keywords: ["traiteur"] },
      { slug: "chef", label: "Chef à domicile", keywords: ["chef", "domicile", "cuisinier"] },
      { slug: "food-truck", label: "Food truck", keywords: ["food truck", "camion"] },
      {
        slug: "patisserie",
        label: "Pâtisserie",
        keywords: ["pâtisserie", "gâteau", "wedding cake"],
      },
      {
        slug: "bar",
        label: "Bar & mixologie",
        keywords: ["bar", "cocktail", "mixologie", "barman"],
      },
      { slug: "cave", label: "Cave", keywords: ["cave", "vin", "champagne"] },
    ],
  },
  {
    slug: "image",
    label: "Image & Souvenirs",
    video: "ceremonie",
    db: [],
    keywords: ["photo", "vidéo", "image", "souvenir"],
    subs: [
      { slug: "photographe", label: "Photographe", keywords: ["photographe", "photo"] },
      { slug: "videaste", label: "Vidéaste", keywords: ["vidéaste", "videaste", "vidéo"] },
      { slug: "drone", label: "Drone", keywords: ["drone", "aérien"] },
      { slug: "photobooth", label: "Photobooth", keywords: ["photobooth", "borne photo"] },
      { slug: "retouche", label: "Retouche", keywords: ["retouche", "montage"] },
      { slug: "album", label: "Album", keywords: ["album", "tirage", "impression"] },
    ],
  },
  {
    slug: "style",
    label: "Beauté & Style",
    video: "naissance",
    db: [],
    keywords: ["beauté", "style", "mode"],
    subs: [
      { slug: "coiffure", label: "Coiffure", keywords: ["coiffure", "coiffeur"] },
      { slug: "maquillage", label: "Maquillage", keywords: ["maquillage", "make-up", "mua"] },
      { slug: "tenue", label: "Robe & costume", keywords: ["robe", "costume", "couturier"] },
      {
        slug: "location-tenues",
        label: "Location de tenues",
        keywords: ["location", "tenue", "robe"],
      },
      { slug: "bijoux", label: "Bijoux", keywords: ["bijou", "joaillier", "alliance"] },
      { slug: "soins", label: "Soins", keywords: ["soin", "spa", "esthétique"] },
    ],
  },
  {
    slug: "patrimoine",
    label: "Patrimoine & Biens",
    video: "patrimoine",
    db: [],
    keywords: ["immobilier", "location", "bien", "matériel"],
    subs: [
      {
        slug: "immo-vente",
        label: "Immobilier vente",
        keywords: ["vente", "immobilier", "maison"],
      },
      {
        slug: "immo-location",
        label: "Immobilier location",
        keywords: ["location", "appartement", "logement"],
      },
      {
        slug: "materiel",
        label: "Location de matériel",
        keywords: ["matériel", "sono", "mobilier", "location"],
      },
      {
        slug: "vehicules",
        label: "Véhicules",
        keywords: ["voiture", "van", "véhicule", "navette"],
      },
      { slug: "mobilier", label: "Mobilier & déco", keywords: ["mobilier", "déco", "décoration"] },
      {
        slug: "objets",
        label: "Objets rares",
        keywords: ["objet", "vintage", "collection", "brocante"],
      },
    ],
  },
  {
    slug: "voyage",
    label: "Voyage & Séjour",
    video: "voyage",
    db: ["voyage"],
    keywords: ["voyage", "séjour", "hébergement"],
    subs: [
      {
        slug: "hebergement",
        label: "Hébergement",
        keywords: ["hébergement", "gîte", "hôtel", "chambre"],
      },
      {
        slug: "sejour-groupe",
        label: "Séjour de groupe",
        keywords: ["séjour", "groupe", "week-end"],
      },
      { slug: "guide", label: "Guide local", keywords: ["guide", "visite"] },
      { slug: "transport", label: "Transport", keywords: ["transport", "bus", "train"] },
      { slug: "navette", label: "Navette", keywords: ["navette", "chauffeur"] },
      { slug: "experience", label: "Expérience", keywords: ["expérience", "activité", "escapade"] },
    ],
  },
  {
    slug: "lien",
    label: "Lien & Rencontre",
    video: "rencontre",
    db: ["rencontre"],
    keywords: ["rencontre", "lien", "affinité"],
    subs: [
      { slug: "rencontre", label: "Rencontre", db: "rencontre" },
      { slug: "amitie", label: "Amitié", keywords: ["amitié", "ami"] },
      { slug: "reseau-pro", label: "Réseau pro", keywords: ["réseau", "networking"] },
      { slug: "mentorat", label: "Mentorat", keywords: ["mentor", "mentorat", "accompagnement"] },
      { slug: "communaute", label: "Communauté", keywords: ["communauté", "collectif"] },
      { slug: "entraide", label: "Entraide", keywords: ["entraide", "soutien"] },
    ],
  },
  {
    slug: "solidarite",
    label: "Association & Solidarité",
    video: "association",
    db: ["association"],
    keywords: ["association", "solidarité", "bénévole"],
    subs: [
      { slug: "benevolat", label: "Bénévolat", keywords: ["bénévole", "bénévolat"] },
      { slug: "collecte", label: "Collecte", keywords: ["collecte", "don", "cagnotte"] },
      { slug: "cause", label: "Cause", keywords: ["cause", "engagement"] },
      { slug: "sport", label: "Sport & loisirs", keywords: ["sport", "loisir", "club"] },
      { slug: "animaux", label: "Cause animale", keywords: ["animal", "animaux", "refuge"] },
      { slug: "quartier", label: "Quartier", keywords: ["quartier", "voisin", "local"] },
    ],
  },
];

export const UNIVERSE_BY_SLUG = new Map(UNIVERSE_TREE.map((u) => [u.slug, u]));

export function findUniverse(slug?: string | null): UniverseNode | undefined {
  return slug ? UNIVERSE_BY_SLUG.get(slug) : undefined;
}

export function findSub(parentSlug?: string | null, subSlug?: string | null) {
  const parent = findUniverse(parentSlug);
  if (!parent || !subSlug) return undefined;
  return parent.subs.find((s) => s.slug === subSlug);
}

type MatchableCard = {
  name: string;
  headline: string;
  city: string | null;
  tags: string[];
  skills: string[];
  universes: string[];
  category_slug: string;
};

function haystack(card: MatchableCard): string {
  return [card.name, card.headline, card.category_slug, ...card.tags, ...card.skills]
    .join(" ")
    .toLowerCase();
}

function hasKeyword(card: MatchableCard, keywords?: string[]): boolean {
  if (!keywords?.length) return false;
  const h = haystack(card);
  return keywords.some((k) => h.includes(k.toLowerCase()));
}

/** La carte appartient-elle à cet univers parent ? */
export function cardMatchesUniverse(card: MatchableCard, parentSlug: string): boolean {
  const parent = findUniverse(parentSlug);
  if (card.universes.includes(parentSlug)) return true;
  if (!parent) return false;
  if (parent.db.some((s) => card.universes.includes(s))) return true;
  if (hasKeyword(card, parent.keywords)) return true;
  return parent.subs.some((s) => cardMatchesSubNode(card, s));
}

function cardMatchesSubNode(card: MatchableCard, sub: SubUniverse): boolean {
  if (sub.db && card.universes.includes(sub.db)) return true;
  return hasKeyword(card, sub.keywords ?? [sub.label]);
}

/** La carte correspond-elle à ce sous-univers ? */
export function cardMatchesSub(card: MatchableCard, parentSlug: string, subSlug: string): boolean {
  const sub = findSub(parentSlug, subSlug);
  if (!sub) return true;
  return cardMatchesSubNode(card, sub);
}

/* ------------------------------------------------------------------ */
/* Qualification d'une carte : catégories, tags, univers en base       */
/* ------------------------------------------------------------------ */

/** Catégories (slugs en base) pertinentes par univers parent. */
export const CATEGORIES_BY_UNIVERSE: Record<string, string[]> = {
  evenement: [
    "planner",
    "lieu-reception",
    "traiteur",
    "photographe",
    "videaste",
    "musicien",
    "dj",
    "fleuriste",
    "maquilleur",
    "mobilier",
    "transport",
    "temoin",
    "agence",
  ],
  musique: [
    "musicien",
    "dj",
    "artiste",
    "salle-concert",
    "sonorisation",
    "eclairagiste",
    "festival",
    "agence",
  ],
  culture: ["artiste", "association", "institution", "guide", "salon", "festival", "agence"],
  entreprise: [
    "agence",
    "institution",
    "salle-concert",
    "lieu-reception",
    "traiteur",
    "salon",
    "guide",
    "photographe",
    "videaste",
  ],
  lieux: ["lieu-reception", "salle-concert", "hotel", "mobilier", "agence"],
  table: ["traiteur", "lieu-reception", "artiste", "agence"],
  image: ["photographe", "videaste", "artiste", "agence"],
  style: ["maquilleur", "artiste", "agence", "mobilier"],
  patrimoine: ["agence", "mobilier", "transport", "hotel", "lieu-reception", "institution"],
  voyage: ["hotel", "guide", "transport", "agence", "traiteur"],
  lien: ["artiste", "temoin", "association", "guide", "agence"],
  solidarite: ["association", "institution", "guide", "artiste", "festival"],
};

/** Catégories proposées pour la sélection d'univers en cours. */
export function categoriesForUniverses(parentSlugs: string[]): string[] {
  const out = new Set<string>();
  for (const p of parentSlugs) for (const c of CATEGORIES_BY_UNIVERSE[p] ?? []) out.add(c);
  return [...out];
}

/** Normalise un libellé en tag propre et filtrable. */
export function normalizeTag(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/** Slugs d'univers réellement présents en base pour une sélection parent + sous-univers. */
export function dbUniversesFor(parentSlugs: string[], subSlugs: string[]): string[] {
  const out = new Set<string>();
  for (const p of parentSlugs) {
    const node = findUniverse(p);
    if (!node) continue;
    for (const db of node.db) out.add(db);
    for (const sub of node.subs) {
      if (sub.db && subSlugs.includes(`${p}:${sub.slug}`)) out.add(sub.db);
    }
  }
  return [...out];
}

/** Tags dérivés des sous-univers choisis (clé "parent:sub"). */
export function tagsForSubs(subKeys: string[]): string[] {
  const out = new Set<string>();
  for (const key of subKeys) {
    const [parent, sub] = key.split(":");
    const node = findSub(parent, sub);
    if (node) out.add(normalizeTag(node.slug));
  }
  return [...out];
}

/** Suggestions de tags : sous-univers, mots-clés d'univers et catégorie. */
export function suggestedTags(
  parentSlugs: string[],
  subKeys: string[],
  categorySlug?: string | null,
): string[] {
  const out = new Set<string>(tagsForSubs(subKeys));
  for (const key of subKeys) {
    const [parent, sub] = key.split(":");
    const node = findSub(parent, sub);
    for (const k of node?.keywords ?? []) out.add(normalizeTag(k));
  }
  for (const p of parentSlugs) {
    const node = findUniverse(p);
    for (const k of node?.keywords ?? []) out.add(normalizeTag(k));
  }
  if (categorySlug) out.add(normalizeTag(categorySlug));
  return [...out].filter(Boolean).slice(0, 24);
}

/** Régions françaises déduites de la ville (repli : Hauts-de-France). */
const REGION_BY_CITY: Record<string, string> = {
  lille: "Hauts-de-France",
  roubaix: "Hauts-de-France",
  tourcoing: "Hauts-de-France",
  arras: "Hauts-de-France",
  amiens: "Hauts-de-France",
  lens: "Hauts-de-France",
  valenciennes: "Hauts-de-France",
  douai: "Hauts-de-France",
  dunkerque: "Hauts-de-France",
  calais: "Hauts-de-France",
  beauvais: "Hauts-de-France",
  compiegne: "Hauts-de-France",
  paris: "Île-de-France",
  versailles: "Île-de-France",
  "boulogne-billancourt": "Île-de-France",
  lyon: "Auvergne-Rhône-Alpes",
  grenoble: "Auvergne-Rhône-Alpes",
  "saint-etienne": "Auvergne-Rhône-Alpes",
  annecy: "Auvergne-Rhône-Alpes",
  chambery: "Auvergne-Rhône-Alpes",
  clermont: "Auvergne-Rhône-Alpes",
  marseille: "Provence-Alpes-Côte d'Azur",
  nice: "Provence-Alpes-Côte d'Azur",
  toulon: "Provence-Alpes-Côte d'Azur",
  cannes: "Provence-Alpes-Côte d'Azur",
  "aix-en-provence": "Provence-Alpes-Côte d'Azur",
  avignon: "Provence-Alpes-Côte d'Azur",
  bordeaux: "Nouvelle-Aquitaine",
  biarritz: "Nouvelle-Aquitaine",
  "la-rochelle": "Nouvelle-Aquitaine",
  poitiers: "Nouvelle-Aquitaine",
  limoges: "Nouvelle-Aquitaine",
  pau: "Nouvelle-Aquitaine",
  toulouse: "Occitanie",
  montpellier: "Occitanie",
  nimes: "Occitanie",
  perpignan: "Occitanie",
  albi: "Occitanie",
  carcassonne: "Occitanie",
  nantes: "Pays de la Loire",
  angers: "Pays de la Loire",
  "le-mans": "Pays de la Loire",
  "la-roche-sur-yon": "Pays de la Loire",
  laval: "Pays de la Loire",
  rennes: "Bretagne",
  brest: "Bretagne",
  quimper: "Bretagne",
  vannes: "Bretagne",
  lorient: "Bretagne",
  "saint-malo": "Bretagne",
  strasbourg: "Grand Est",
  metz: "Grand Est",
  nancy: "Grand Est",
  reims: "Grand Est",
  colmar: "Grand Est",
  mulhouse: "Grand Est",
  troyes: "Grand Est",
  rouen: "Normandie",
  caen: "Normandie",
  "le-havre": "Normandie",
  deauville: "Normandie",
  cherbourg: "Normandie",
  evreux: "Normandie",
  dijon: "Bourgogne-Franche-Comté",
  besancon: "Bourgogne-Franche-Comté",
  auxerre: "Bourgogne-Franche-Comté",
  chalon: "Bourgogne-Franche-Comté",
  tours: "Centre-Val de Loire",
  orleans: "Centre-Val de Loire",
  bourges: "Centre-Val de Loire",
  chartres: "Centre-Val de Loire",
  blois: "Centre-Val de Loire",
  ajaccio: "Corse",
  bastia: "Corse",
  bruxelles: "Bruxelles-Capitale",
  geneve: "Genève",
  luxembourg: "Luxembourg",
};

export function regionForCity(city?: string | null): string {
  const key = normalizeTag(city ?? "");
  if (!key) return "Hauts-de-France";
  if (REGION_BY_CITY[key]) return REGION_BY_CITY[key] as string;
  const partial = Object.keys(REGION_BY_CITY).find((k) => key.startsWith(k) || k.startsWith(key));
  return partial ? (REGION_BY_CITY[partial] as string) : "Hauts-de-France";
}

export const KNOWN_CITIES = Object.keys(REGION_BY_CITY);

/** Catégories de type organisateur / lieu / structure : elles seules affichent les coordonnées. */
export const ORGANIZER_CATEGORIES = [
  "planner",
  "agence",
  "lieu-reception",
  "salle-concert",
  "hotel",
  "institution",
  "association",
  "festival",
  "salon",
];

export function isOrganizerCategory(slug?: string | null): boolean {
  return !!slug && ORGANIZER_CATEGORIES.includes(slug);
}
