/**
 * Visuel d'une carte : sa photo d'abord, puis son métier, puis son univers.
 * Objectif : ne plus voir deux fois la même image dans une grille de cartes.
 */
import photo from "@/assets/visual-photo.jpg";
import video from "@/assets/visual-video.jpg";
import music from "@/assets/visual-music.jpg";
import food from "@/assets/visual-food.jpg";
import flower from "@/assets/visual-flower.jpg";
import venue from "@/assets/visual-venue.jpg";
import people from "@/assets/visual-people.jpg";
import light from "@/assets/visual-light.jpg";
import service from "@/assets/visual-service.jpg";
import resource from "@/assets/visual-resource.jpg";
import event from "@/assets/visual-event.jpg";
import patisserie from "@/assets/visual-patisserie.jpg";
import cave from "@/assets/visual-cave.jpg";
import beaute from "@/assets/visual-beaute.jpg";
import mode from "@/assets/visual-mode.jpg";
import deco from "@/assets/visual-deco.jpg";
import transport from "@/assets/visual-transport.jpg";
import patrimoine from "@/assets/visual-patrimoine.jpg";
import hotel from "@/assets/visual-hotel.jpg";
import scene from "@/assets/visual-scene.jpg";
import institution from "@/assets/visual-institution.jpg";

/** Une ou plusieurs images possibles par métier : la variante dépend de la carte. */
const BY_CATEGORY: Record<string, string[]> = {
  traiteur: [food, service],
  chef: [food, patisserie],
  "food-truck": [food, event],
  restaurant: [food, cave],
  patisserie: [patisserie],
  patissier: [patisserie],
  chocolatier: [patisserie],
  boulanger: [patisserie, food],
  cave: [cave],
  bar: [cave, event],
  barman: [cave],
  sommelier: [cave],
  vigneron: [cave, patrimoine],
  "lieu-reception": [venue, patrimoine],
  lieu: [venue, hotel],
  salle: [venue, scene],
  chateau: [patrimoine, venue],
  domaine: [patrimoine, flower],
  hotel: [hotel],
  hebergement: [hotel, venue],
  gite: [hotel, patrimoine],
  "salle-concert": [scene, light],
  festival: [light, event],
  musicien: [music, scene],
  dj: [music, light],
  groupe: [music, scene],
  studio: [music],
  sonorisation: [music, light],
  eclairagiste: [light, scene],
  scenographe: [light, deco],
  photographe: [photo],
  videaste: [video],
  drone: [video, light],
  photobooth: [photo, event],
  fleuriste: [flower],
  decorateur: [deco, flower],
  mobilier: [deco, venue],
  location: [deco, resource],
  materiel: [resource, deco],
  maquilleur: [beaute],
  coiffeur: [beaute],
  esthetique: [beaute],
  soins: [beaute],
  couturier: [mode],
  tenue: [mode],
  robe: [mode, flower],
  bijoutier: [mode, beaute],
  transport: [transport],
  navette: [transport],
  chauffeur: [transport],
  vehicules: [transport],
  immobilier: [patrimoine],
  "immo-vente": [patrimoine],
  "immo-location": [patrimoine, hotel],
  institution: [institution],
  musee: [institution, patrimoine],
  galerie: [institution, deco],
  theatre: [scene, institution],
  association: [people, service],
  planner: [service, event],
  agence: [service],
  guide: [service, patrimoine],
  formation: [service, people],
  salon: [event, service],
  coworking: [service, resource],
};

/** Repli par univers. */
const BY_UNIVERSE: Record<string, string[]> = {
  mariage: [flower, venue, patisserie],
  anniversaire: [event, patisserie],
  naissance: [people, flower],
  ceremonie: [venue, patrimoine],
  concert: [scene, music, light],
  culture: [institution, patrimoine],
  entreprise: [service, event],
  voyage: [hotel, transport],
  rencontre: [people],
  association: [people, service],
  evenement: [event, light],
  patrimoine: [patrimoine, institution],
};

/** Anciennes clés simples encore présentes en base. */
const LEGACY: Record<string, string> = {
  photo,
  video,
  music,
  food,
  flower,
  venue,
  people,
  light,
  service,
  resource,
  event,
  patisserie,
  cave,
  beaute,
  mode,
  deco,
  transport,
  patrimoine,
  hotel,
  scene,
  institution,
};

const NEUTRAL = [resource, people, service, event];

export type VisualCard = {
  id?: string | null;
  name?: string | null;
  image_url?: string | null;
  visual_key?: string | null;
  category_slug?: string | null;
  universes?: string[] | null;
};

/** Hash stable : la même carte garde toujours la même variante. */
function hash(seed: string) {
  let h = 0;
  for (let i = 0; i < seed.length; i += 1) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h;
}

function pick(pool: string[], seed: string) {
  return pool[hash(seed) % pool.length]!;
}

/** Visuel d'une carte : photo → métier → univers → neutre. */
export function cardVisual(card: VisualCard | null | undefined): string {
  if (!card) return NEUTRAL[0]!;
  if (card.image_url) return card.image_url;
  const seed = `${card.id ?? ""}${card.name ?? ""}`;

  const cat = card.category_slug ? BY_CATEGORY[card.category_slug] : undefined;
  if (cat) return pick(cat, seed);

  for (const u of card.universes ?? []) {
    const uni = BY_UNIVERSE[u];
    if (uni) return pick(uni, seed);
  }

  if (card.visual_key && LEGACY[card.visual_key]) return LEGACY[card.visual_key]!;
  return pick(NEUTRAL, seed);
}

/** Visuel d'un univers précis, avec repli sur celui de la carte. */
export function universeVisual(slug: string, card?: VisualCard | null): string {
  const pool = BY_UNIVERSE[slug];
  if (pool) return pick(pool, `${slug}${card?.id ?? ""}`);
  return cardVisual(card);
}

/** Bibliothèque brute de visuels internes, sans doublons. */
export function allVisualLibrary(): string[] {
  return [
    ...new Set([
      ...Object.values(BY_CATEGORY).flat(),
      ...Object.values(BY_UNIVERSE).flat(),
      ...NEUTRAL,
    ]),
  ];
}

/** Visuels adaptés à un domaine (category_slug), avec repli universel. */
export function visualLibraryForDomain(domain: string | null | undefined): string[] {
  if (!domain) return [];
  return [...new Set(BY_CATEGORY[domain] ?? [])];
}

/** Visuels adaptés à un univers (slug base). */
export function visualLibraryForUniverse(universe: string | null | undefined): string[] {
  if (!universe) return [];
  return [...new Set(BY_UNIVERSE[universe] ?? [])];
}

/** Clé stable d'un visuel interne, pour persister sans URL hashée. */
export function visualKeyFromUrl(url: string): string | null {
  const found = Object.entries(LEGACY).find(([, value]) => value === url);
  return found?.[0] ?? null;
}

/** Compat : ancienne signature (clé + photo). */
export function visualFor(key: string | null | undefined, imageUrl?: string | null) {
  if (imageUrl) return imageUrl;
  return (key && LEGACY[key]) || NEUTRAL[0]!;
}
