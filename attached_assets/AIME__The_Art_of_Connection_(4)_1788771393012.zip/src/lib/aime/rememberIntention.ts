import { supabase } from "@/integrations/supabase/client";

/**
 * Garde en mémoire ce qui a été demandé depuis un champ d'intention.
 * Non publié : c'est une trace privée, retrouvable via « Reprendre une intention ».
 */
export async function rememberIntention(
  userId: string | null | undefined,
  body: string,
  extra?: { city?: string | null; universeSlug?: string | null },
) {
  const text = body.trim();
  if (!userId || text.length < 4) return;
  await supabase.from("intentions").insert({
    user_id: userId,
    body: text.slice(0, 400),
    kind: "cherche",
    city: extra?.city ?? null,
    universe_slug: extra?.universeSlug ?? null,
    published: false,
  });
}
