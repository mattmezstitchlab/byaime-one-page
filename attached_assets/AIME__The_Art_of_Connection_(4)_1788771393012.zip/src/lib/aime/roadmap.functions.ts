import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { CAPABILITIES } from "@/lib/aime/capabilities";

const Input = z.object({
  brief: z.string().min(6).max(1200),
});

const StepSchema = z.object({
  capability_id: z.string(),
  title: z.string(),
  why: z.string(),
});

const PlanSchema = z.object({
  zero: z.object({ objective: z.string(), context: z.string() }),
  steps: z.array(StepSchema),
  after: z.array(StepSchema),
});

export type RoadmapStep = z.infer<typeof StepSchema>;
export type Roadmap = z.infer<typeof PlanSchema>;

const SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["zero", "steps", "after"],
  properties: {
    zero: {
      type: "object",
      additionalProperties: false,
      required: ["objective", "context"],
      properties: { objective: { type: "string" }, context: { type: "string" } },
    },
    steps: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["capability_id", "title", "why"],
        properties: {
          capability_id: { type: "string" },
          title: { type: "string" },
          why: { type: "string" },
        },
      },
    },
    after: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["capability_id", "title", "why"],
        properties: {
          capability_id: { type: "string" },
          title: { type: "string" },
          why: { type: "string" },
        },
      },
    },
  },
} as const;

export const buildRoadmap = createServerFn({ method: "POST" })
  .validator((data: unknown) => Input.parse(data))
  .handler(async ({ data }): Promise<Roadmap> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Aime n'est pas configurée pour l'instant.");

    const catalogue = CAPABILITIES.map(
      (c) => `${c.id} | ${c.label} | ${c.what} | état: ${c.status}`,
    ).join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          {
            role: "system",
            content: [
              "Tu es Aime, l'agent du réseau AIME. À partir d'une intention exprimée librement, tu écris une feuille de route claire, humaine et sans jargon.",
              "zero.objective : reformule l'objectif en une phrase, à la deuxième personne. zero.context : ville, période, budget ou ambiance si la personne les a exprimés, sinon une phrase douce qui invite à préciser.",
              "steps : 5 à 8 étapes ORDONNÉES, du point de départ jusqu'à la réalisation. after : 2 à 4 suites possibles une fois l'objectif atteint.",
              "Chaque étape référence OBLIGATOIREMENT une capability_id copiée exactement depuis le catalogue fourni. N'invente jamais d'identifiant ni de fonctionnalité absente du catalogue.",
              "title : 2 à 5 mots. why : une phrase concrète qui dit ce que la personne y gagne, liée à SON projet (pas une description générique du site).",
              "N'utilise pas deux fois la même capability_id dans steps.",
              "Ton : tendre, direct, parfois taquin, jamais commercial.",
            ].join("\n"),
          },
          {
            role: "user",
            content: `Intention : ${data.brief}\n\nCatalogue des capacités (id | libellé | ce que ça fait | état) :\n${catalogue}`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: { name: "roadmap", strict: true, schema: SCHEMA },
        },
      }),
    });

    if (!res.ok) {
      if (res.status === 429) throw new Error("Trop de demandes, réessayez dans un instant.");
      if (res.status === 402) throw new Error("Crédits IA épuisés pour cet espace de travail.");
      throw new Error(`Aime a répondu ${res.status}.`);
    }

    const payload = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw new Error("Réponse vide d'Aime.");

    const parsed = PlanSchema.parse(JSON.parse(content));
    const known = new Set(CAPABILITIES.map((c) => c.id));

    const clean = (list: RoadmapStep[], max: number) => {
      const seen = new Set<string>();
      return list
        .filter((s) => known.has(s.capability_id) && !seen.has(s.capability_id))
        .map((s) => {
          seen.add(s.capability_id);
          return s;
        })
        .slice(0, max);
    };

    return {
      zero: parsed.zero,
      steps: clean(parsed.steps, 8),
      after: clean(parsed.after, 4),
    };
  });
