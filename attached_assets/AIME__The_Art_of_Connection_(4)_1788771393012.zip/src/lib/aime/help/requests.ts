import { supabase } from "@/integrations/supabase/client";

/**
 * « Le Monde AIME » : un projet peut demander de l'aide.
 * Rien ne devient public tant qu'une personne ne l'a pas relu et validé.
 */

export const NEED_KINDS = [
  { key: "coup_de_main", label: "Un coup de main", hint: "du temps, des bras" },
  { key: "pret", label: "Un prêt", hint: "un objet, un lieu, du matériel" },
  { key: "promesse", label: "Une promesse", hint: "un engagement pour plus tard" },
  { key: "don", label: "Un don", hint: "une somme, une fourniture" },
  { key: "relation", label: "Une mise en relation", hint: "une personne à rencontrer" },
] as const;

export type NeedKind = (typeof NEED_KINDS)[number]["key"];

export const REVIEW_LABEL: Record<string, string> = {
  brouillon: "Brouillon",
  a_valider: "En attente de relecture",
  a_revoir: "À revoir",
  valide: "Validée",
  refuse: "Non retenue",
};

export type HelpNeedDraft = {
  kind: NeedKind;
  label: string;
  detail: string;
  quantity: number;
  amountEuros: number | null;
};

export type HelpRequestDraft = {
  title: string;
  reason: string;
  detail: string;
  city: string;
  deadline: string;
  eventId: string | null;
  universeSlug: string | null;
  declaredAccurate: boolean;
  needs: HelpNeedDraft[];
};

/** Envoie la demande en relecture : jamais publiée directement. */
export async function submitHelpRequest(userId: string, draft: HelpRequestDraft) {
  const { data: request, error } = await supabase
    .from("help_requests")
    .insert({
      user_id: userId,
      kind: "demande",
      title: draft.title.trim(),
      detail: draft.detail.trim() || null,
      reason: draft.reason.trim() || null,
      city: draft.city.trim() || null,
      deadline: draft.deadline || null,
      event_id: draft.eventId,
      universe_slug: draft.universeSlug,
      declared_accurate: draft.declaredAccurate,
      review_status: "a_valider",
      status: "ouvert",
    })
    .select("id")
    .single();
  if (error) throw error;

  const needs = draft.needs.filter((n) => n.label.trim());
  if (needs.length) {
    const { error: needError } = await supabase.from("help_needs").insert(
      needs.map((need) => ({
        request_id: request.id,
        kind: need.kind,
        label: need.label.trim(),
        detail: need.detail.trim() || null,
        quantity_needed: Math.max(1, need.quantity),
        amount_cents: need.amountEuros ? Math.round(need.amountEuros * 100) : null,
      })),
    );
    if (needError) throw needError;
  }
  return request.id as string;
}

/** Les demandes validées : lisibles par tout le monde, même sans compte. */
export function publishedRequestsQuery() {
  return {
    queryKey: ["help-requests", "publiees"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("help_requests")
        .select("*, help_needs(*)")
        .eq("review_status", "valide")
        .order("created_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return data ?? [];
    },
  };
}

/** Mes demandes, quel que soit leur état de relecture. */
export function myRequestsQuery(userId: string | null) {
  return {
    queryKey: ["help-requests", "miennes", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("help_requests")
        .select("*, help_needs(*)")
        .eq("user_id", userId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  };
}
