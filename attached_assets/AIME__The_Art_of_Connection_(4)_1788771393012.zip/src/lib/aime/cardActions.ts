import {
  CalendarCheck,
  CalendarPlus,
  CreditCard,
  Eye,
  FileText,
  Handshake,
  Heart,
  MessageCircle,
  Pencil,
  Puzzle,
  Share2,
  Star,
  Ticket,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { AimeIntent, CardKind } from "./types";

export type ActionPanel =
  "contact" | "reserve" | "associate" | "quote" | "pay" | "recommend" | "invite" | "own" | null;

export type CardAction = {
  key: string;
  label: string;
  hint: string;
  icon: LucideIcon;
  /** Intention enregistrée en base (si applicable). */
  intent?: AimeIntent;
  /** Panneau déplié au clic ; sans panneau, l'action est instantanée. */
  panel?: Exclude<ActionPanel, null>;
};

const A = {
  aime: {
    key: "aime",
    label: "J'aime",
    hint: "Garder cette carte en tête",
    icon: Heart,
    intent: "aime" as const,
  },
  contacter: {
    key: "contacter",
    label: "Contacter",
    hint: "Écrire un premier message",
    icon: MessageCircle,
    intent: "contacter" as const,
    panel: "contact" as const,
  },
  reserver: {
    key: "reserver",
    label: "Réserver",
    hint: "Demander une date",
    icon: CalendarCheck,
    intent: "reserver" as const,
    panel: "reserve" as const,
  },
  visiter: {
    key: "visiter",
    label: "Visiter",
    hint: "Proposer une date de visite",
    icon: Eye,
    intent: "reserver" as const,
    panel: "reserve" as const,
  },
  louer: {
    key: "louer",
    label: "Louer / Emprunter",
    hint: "Réserver la ressource",
    icon: CalendarCheck,
    intent: "reserver" as const,
    panel: "reserve" as const,
  },
  participer: {
    key: "participer",
    label: "Participer",
    hint: "Rejoindre cet événement",
    icon: Ticket,
    intent: "reserver" as const,
    panel: "reserve" as const,
  },
  devis: {
    key: "devis",
    label: "Devis",
    hint: "Demander une estimation",
    icon: FileText,
    panel: "quote" as const,
  },
  payer: {
    key: "payer",
    label: "Payer",
    hint: "Régler ma part",
    icon: CreditCard,
    panel: "pay" as const,
  },
  associer: {
    key: "associer",
    label: "Associer",
    hint: "La garder près de vous",
    icon: Puzzle,
    intent: "associer" as const,
    panel: "associate" as const,
  },
  collaborer: {
    key: "collaborer",
    label: "Collaborer",
    hint: "Créer quelque chose ensemble",
    icon: Handshake,
    intent: "collaborer" as const,
    panel: "contact" as const,
  },
  partenariat: {
    key: "partenariat",
    label: "Partenariat",
    hint: "Proposer un partenariat",
    icon: Handshake,
    intent: "collaborer" as const,
    panel: "contact" as const,
  },
  recommander: {
    key: "recommander",
    label: "Recommander",
    hint: "La faire connaître",
    icon: Star,
    intent: "recommander" as const,
    panel: "recommend" as const,
  },
  inviter: {
    key: "inviter",
    label: "Inviter à un événement",
    hint: "L'ajouter à un de mes événements",
    icon: CalendarPlus,
    panel: "invite" as const,
  },
  proposerService: {
    key: "proposer-service",
    label: "Proposer un service",
    hint: "Se positionner sur cet événement",
    icon: Handshake,
    intent: "collaborer" as const,
    panel: "contact" as const,
  },
} satisfies Record<string, CardAction>;

const OWN: CardAction[] = [
  {
    key: "own-edit",
    label: "Modifier ma carte",
    hint: "Identité, univers, tags",
    icon: Pencil,
    panel: "own",
  },
  {
    key: "own-timeline",
    label: "Timeline",
    hint: "Gérer mes repères",
    icon: CalendarCheck,
    panel: "own",
  },
  { key: "own-rates", label: "Tarifs", hint: "Grille et devis", icon: FileText, panel: "own" },
  {
    key: "own-share",
    label: "Partager",
    hint: "Copier le lien de ma carte",
    icon: Share2,
    panel: "own",
  },
];

const BY_KIND: Record<CardKind, CardAction[]> = {
  professionnel: [A.reserver, A.devis, A.payer, A.contacter, A.associer, A.recommander, A.aime],
  service: [A.reserver, A.devis, A.payer, A.contacter, A.associer, A.recommander, A.aime],
  lieu: [A.reserver, A.devis, A.visiter, A.contacter, A.associer, A.recommander, A.aime],
  personne: [A.contacter, A.collaborer, A.inviter, A.recommander, A.aime],
  entreprise: [A.contacter, A.collaborer, A.devis, A.partenariat, A.recommander, A.aime],
  organisme: [A.contacter, A.collaborer, A.devis, A.partenariat, A.recommander, A.aime],
  evenement: [A.participer, A.inviter, A.proposerService, A.payer, A.aime],
  ressource: [A.reserver, A.louer, A.devis, A.contacter, A.associer, A.aime],
};

/** Actions du cœur selon la nature de la carte (et si elle m'appartient). */
export function actionsForCard(kind: CardKind | undefined, isOwn: boolean): CardAction[] {
  if (isOwn) return OWN;
  return BY_KIND[kind ?? "professionnel"] ?? BY_KIND.professionnel;
}

/** Actions génériques quand aucune carte n'est fournie (repli historique). */
export const DEFAULT_ACTIONS: CardAction[] = BY_KIND.professionnel;

export const OWN_ACTIONS = OWN;
