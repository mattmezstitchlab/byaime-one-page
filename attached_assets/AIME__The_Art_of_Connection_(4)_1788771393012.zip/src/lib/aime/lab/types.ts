/**
 * LAB : les types de la toile. Une seule règle — un objet LAB ne porte que
 * de la géométrie et des RÉFÉRENCES (card_id, media, module) : jamais une
 * copie d'une donnée métier. Le World Model reste l'unique source.
 */

export type LabObjectType =
  "mot" | "note" | "texte" | "forme" | "media" | "carte" | "etape" | "module" | "proposition";

export const LAB_OBJECT_TYPES: LabObjectType[] = [
  "mot",
  "note",
  "texte",
  "forme",
  "media",
  "carte",
  "etape",
  "module",
  "proposition",
];

export type LabBoard = {
  id: string;
  owner_id: string;
  event_id: string | null;
  title: string;
  universe_slug: string | null;
  domain_slug: string | null;
  created_at: string;
  updated_at: string;
};

/** data : texte brut, catégorie proposée, références par identifiant. */
export type LabObjectData = {
  text?: string;
  /** Étiquette proposée par AIME, validable par l'humain. */
  cat?: string;
  /** forme : rect | cercle | ligne. */
  shape?: "rect" | "cercle" | "ligne";
  /** media : l'URL de la pièce media_items + son titre. */
  url?: string;
  mediaKind?: string;
  /** carte : la personne référencée. */
  cardId?: string;
  name?: string;
  headline?: string | null;
  photo?: string | null;
  city?: string | null;
  /** module : timeline | personnes | documents. */
  module?: "timeline" | "personnes" | "documents";
  /** proposition : la facette d'AIME qui la pose (voir agents.ts). */
  agent?: string;
  /** proposition : pourquoi elle est faite — toujours lisible. */
  why?: string;
  /** proposition : les éléments du contexte utilisés (libellés). */
  uses?: string[];
  /** proposition : l'objet de la toile concerné, s'il y en a un. */
  target?: string;
  /** proposition : son statut, la frontière entre suggéré et validé. */
  propositionStatus?: "propose" | "valide" | "ecarte";
  [key: string]: unknown;
};

export type LabObject = {
  id: string;
  board_id: string;
  type: LabObjectType;
  x: number;
  y: number;
  w: number | null;
  h: number | null;
  z: number;
  data: LabObjectData;
  created_by: string;
  created_at: string;
  updated_at: string;
};

export type LabMember = {
  id: string;
  board_id: string;
  card_id: string;
  role_label: string;
  created_at: string;
  card?: {
    id: string;
    name: string;
    headline: string | null;
    image_url: string | null;
    city: string | null;
  } | null;
};
