/** Ce que les facettes partagent : la normalisation de texte et la mémoire
 *  des propositions déjà posées (jamais reposées, jamais dupliquées). */
import type { LabObject } from "../types";

export function norm(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Les textes déjà proposés par une facette (ni écartés). */
export function existingTexts(objects: LabObject[], agent: string): Set<string> {
  return new Set(
    objects
      .filter(
        (o) =>
          o.type === "proposition" &&
          o.data.agent === agent &&
          o.data.propositionStatus !== "ecarte" &&
          o.data.text,
      )
      .map((o) => norm(o.data.text ?? "")),
  );
}
