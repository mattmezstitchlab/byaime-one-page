/**
 * LAB — la facette Temps d'AIME.
 *
 * Elle ne calcule rien elle-même : elle lit le rétroplanning générique du
 * dépôt (`retroplanning.ts` — les modèles sont des données) et la date lue
 * par AIME, puis rend des PROPOSITIONS (objets de la toile, étape 1).
 * AIME propose ; l'équipe déplace, modifie, valide ou écarte.
 */
import {
  buildRetroplanning,
  guessTemplate,
  RETRO_TEMPLATES,
  templateFor,
  type RetroTemplate,
} from "@/lib/aime/retroplanning";
import type { LabObject } from "../types";
import { existingTexts, norm } from "./shared";

const DAY = 86_400_000;

export type TempsProposal = {
  text: string;
  why: string;
  uses: string[];
  /** L'objet de la toile concerné (une étape posée), s'il y en a un. */
  target?: string;
};

function fmtDay(t: number) {
  return new Date(t).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** Le libellé humain d'un écart en jours : « ≈ 10 mois avant », « 3 semaines avant »… */
function fmtOffset(days: number) {
  const before = days < 0;
  const d = Math.abs(days);
  const label =
    d >= 300
      ? `≈ ${Math.round(d / 30)} mois`
      : d >= 60
        ? `≈ ${Math.round(d / 30)} mois`
        : d >= 21
          ? `≈ ${Math.round(d / 7)} semaines`
          : `≈ ${d} jour${d > 1 ? "s" : ""}`;
  return `${label} ${before ? "avant" : "après"}`;
}

/**
 * La lecture temporelle du board. Pure et déterministe : la date vient de
 * la lecture d'AIME (ou du bref en repli), le modèle du rétroplanning du
 * type reconnu (ou des mots posés). Rien d'enregistré — des propositions.
 */
export function runTemps(input: {
  brief: string;
  /** La date lue par AIME (ms), null si inconnue. */
  day: number | null;
  /** L'univers choisi sur le board, pour mieux choisir le modèle. */
  universeSlug?: string | null;
  objects: LabObject[];
  now?: number;
}): TempsProposal[] {
  const now = input.now ?? Date.now();
  const seen = existingTexts(input.objects, "temps");
  const out: TempsProposal[] = [];
  const push = (p: TempsProposal) => {
    if (seen.has(norm(p.text))) return;
    seen.add(norm(p.text));
    out.push(p);
  };

  const day = input.day ?? null;
  if (!day) {
    push({
      text: "Fixer la date du projet",
      why: "Sans date, aucun délai ne peut être calculé : tout le rétroplanning en dépend.",
      uses: ["la toile aujourd'hui"],
    });
    return out;
  }

  /* Le modèle vient du type reconnu, sinon des mots du bref — jamais codé ici. */
  const template: RetroTemplate = RETRO_TEMPLATES.some((t) => t.slug === input.universeSlug)
    ? templateFor(input.universeSlug)
    : guessTemplate(input.brief);
  const markers = buildRetroplanning(template, day, { fromNow: true })
    .filter((m) => m.time >= now - DAY)
    .sort((a, b) => a.time - b.time);

  const jourJ = fmtDay(day);
  for (const m of markers.slice(0, 4)) {
    const days = Math.round((m.time - day) / DAY);
    push({
      text: `Étape : ${m.title}`,
      why: `Posée ${days === 0 ? "le jour même" : fmtOffset(days)} du ${jourJ}, d'après le modèle « ${template.label} » du rétroplanning AIME.`,
      uses: [`date lue : ${jourJ}`, `modèle : ${template.label}`],
    });
  }

  /* Les étapes déjà posées par l'équipe : leur proposer une place dans le temps. */
  const etapes = input.objects.filter((o) => o.type === "etape" && o.data.text?.trim());
  for (const e of etapes.slice(0, 3)) {
    const text = norm(e.data.text ?? "");
    const step = template.steps.find((s) => {
      const n = norm(s.title);
      return n.includes(text) || text.includes(n.split(" ").slice(0, 3).join(" "));
    });
    if (step && step.offsetDays !== 0) {
      push({
        text: `Placer « ${e.data.text?.trim()} » ${fmtOffset(step.offsetDays)} du jour J`,
        why: `Le modèle « ${template.label} » place cette étape à J${step.offsetDays} du ${jourJ}.`,
        uses: [`votre étape : ${e.data.text?.trim()}`, `modèle : ${template.label}`],
        target: e.id,
      });
    }
  }

  if (out.length === 0) {
    push({
      text: "Le rétroplanning est déjà posé jusqu'au jour J",
      why: `Toutes les étapes à venir du modèle « ${template.label} » sont déjà sur la toile (ou écartées).`,
      uses: [`date lue : ${jourJ}`],
    });
  }
  return out;
}
