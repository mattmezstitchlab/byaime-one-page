/**
 * LAB — la facette Critique d'AIME.
 *
 * Celle qui n'est jamais simplement d'accord : elle relit le projet projeté
 * (le même World Model que l'affichage), sa confiance fact par fact, ses
 * manques déclarés, le moteur causal de l'univers et les contradictions de
 * la ligne de temps. Elle ne décide rien : elle pose des propositions —
 * des objets de la toile, explicables et écartables.
 */
import { CONFIDENCE_LABEL, type Fact, type WorldProject } from "@/lib/aime/world/types";
import { causalVariables, wavesFrom, WAVE_LABEL } from "@/lib/aime/causal";
import { analyzeTimeline } from "@/lib/aime/world/timelineAutomation";
import type { LabObject } from "../types";
import { existingTexts, norm } from "./shared";

export type CritiqueProposal = {
  text: string;
  why: string;
  uses: string[];
  target?: string;
};

/** Une confiance fragile, au sens du World Model. */
const FRAGILE = new Set(["a_confirmer", "deduit", "suggere", "manquant"]);

function lowerFirst(s: string) {
  return s.charAt(0).toLowerCase() + s.slice(1);
}

export function runCritique(input: {
  brief: string;
  objects: LabObject[];
  /** Le projet projeté depuis le bref (même moteur que l'accueil). */
  project: WorldProject | null;
  universeSlug?: string | null;
}): CritiqueProposal[] {
  const seen = existingTexts(input.objects, "critique");
  const out: CritiqueProposal[] = [];
  const push = (p: CritiqueProposal) => {
    if (seen.has(norm(p.text))) return;
    seen.add(norm(p.text));
    out.push(p);
  };

  if (!input.project) {
    push({
      text: "Trop peu de matière pour une lecture critique",
      why: "Posez une date, un lieu, quelques mots : la critique lit le projet que la toile projette.",
      uses: ["la toile aujourd'hui"],
    });
    return out;
  }
  const project = input.project;

  /* 1. Les faits fragiles : la confiance du World Model, dite simplement. */
  const facts: [string, Fact<unknown>][] = [
    ["la date", project.pivot],
    ["la ville", project.city],
    ["le lieu", project.venue],
    ["le nombre de personnes", project.guests],
  ];
  for (const [label, fact] of facts) {
    if (!FRAGILE.has(fact.confidence)) continue;
    const conf = CONFIDENCE_LABEL[fact.confidence].toLowerCase();
    push({
      text:
        fact.confidence === "manquant"
          ? `Ce qui manque : ${label}`
          : `À confirmer : ${label} (${conf})`,
      why: `AIME s'appuie sur ce fait sans qu'un humain l'ait confirmé — ${conf} au sens du World Model.`,
      uses: [`confiance : ${CONFIDENCE_LABEL[fact.confidence]}`],
    });
  }

  /* 2. Ce qu'AIME sait ne pas savoir : les manques déclarés du projet. */
  for (const m of project.missing.slice(0, 2)) {
    push({
      text: `Manque : ${lowerFirst(m)}`,
      why: "Le World Model porte explicitement ce manque : la structure reste fragile tant qu'il n'est pas comblé.",
      uses: ["les manques déclarés du projet"],
    });
  }

  /* 3. Les ondes de vigilance : variables sensibles de l'univers jamais évoquées. */
  const evoked = norm(
    `${input.brief} ${input.objects
      .filter((o) => o.type === "mot" || o.type === "note")
      .map((o) => o.data.text ?? "")
      .join(" ")}`,
  );
  const vars = causalVariables(input.universeSlug).filter((v) => !evoked.includes(norm(v)));
  for (const v of vars.slice(0, 2)) {
    const waves = wavesFrom(input.universeSlug, v);
    if (waves.length === 0) continue;
    const touches = [...new Set(waves.map((w) => w.to))].slice(0, 4).join(", ");
    push({
      text: `Vigilance : « ${v} » n'est pas encore posé`,
      why: `Dans cet univers, faire bouger « ${v} » propage une onde ${WAVE_LABEL[waves[0]!.wave]!.toLowerCase()} vers : ${touches}.`,
      uses: [`univers : ${input.universeSlug ?? "général"}`, "moteur causal AIME"],
    });
  }

  /* 4. Les contradictions détectées par l'analyse de la ligne de temps. */
  for (const c of analyzeTimeline(project)
    .filter((a) => a.kind === "contradiction")
    .slice(0, 2)) {
    push({
      text: `Contradiction : ${lowerFirst(c.title)}`,
      why: c.detail,
      uses: ["l'analyse de la ligne de temps"],
    });
  }

  if (out.length === 0) {
    push({
      text: "Rien à signaler pour l'instant",
      why: "Les faits posés sont confirmés et les lectures cohérentes entre elles.",
      uses: ["le projet projeté"],
    });
  }
  return out;
}
