/**
 * LAB — la facette Relations d'AIME.
 *
 * Elle regarde les personnes : celles posées sur la toile, celles de
 * l'équipe, et ce que le projet réclame. Elle ne recrute pas : elle réutilise
 * les domaines de la taxonomie (73 entrées, des données) et la lecture de
 * quintessence d'une sélection (les formules et leurs rôles manquants),
 * puis rend des propositions — à pourvoir, à inviter, à réunir.
 */
import type { Card } from "@/lib/aime/types";
import { domainsFor, cardMatchesDomain } from "@/lib/aime/domains";
import { readSelection } from "@/lib/aime/team/quintessence";
import type { LabMember, LabObject } from "../types";
import { existingTexts, norm } from "./shared";

export type RelationsProposal = {
  text: string;
  why: string;
  uses: string[];
  target?: string;
};

/** Ce que la toile dit, en un seul texte normalisé. */
function corpus(brief: string, objects: LabObject[]) {
  return norm(
    `${brief} ${objects
      .filter((o) => o.type === "mot" || o.type === "note" || o.type === "etape")
      .map((o) => o.data.text ?? "")
      .join(" ")}`,
  );
}

/** Les seuls champs lus par les matchers du dépôt (hay, cardMatchesDomain). */
type Matchable = {
  name: string;
  headline: string;
  tags: string[];
  skills: string[];
  category_slug: string;
};

/** Une carte enough-pour-matcher : seuls ces champs sont lus. */
function matchable(name: string, headline?: string | null): Matchable {
  return { name, headline: headline ?? "", tags: [], skills: [], category_slug: "" };
}

function asCard(m: Matchable): Card {
  /* Lecture pure : hay() ne lit que ces cinq champs. */
  return {
    name: m.name,
    headline: m.headline,
    tags: m.tags,
    skills: m.skills,
    category_slug: m.category_slug,
  } as unknown as Card;
}

export function runRelations(input: {
  brief: string;
  objects: LabObject[];
  members: LabMember[];
  universeSlug?: string | null;
  domainSlug?: string | null;
}): RelationsProposal[] {
  const seen = existingTexts(input.objects, "relations");
  const out: RelationsProposal[] = [];
  const push = (p: RelationsProposal) => {
    if (seen.has(norm(p.text))) return;
    seen.add(norm(p.text));
    out.push(p);
  };

  const cartes = input.objects.filter((o) => o.type === "carte" && o.data.name);
  const memberCardIds = new Set(input.members.map((m) => m.card_id));
  const people: Matchable[] = [
    ...cartes.map((o) => matchable(o.data.name ?? "", o.data.headline)),
    ...input.members.map((m) => matchable(m.card?.name ?? "Membre", m.card?.headline)),
  ];
  const text = corpus(input.brief, input.objects);

  /* 1. Les compétences évoquées sans personne : la taxonomie des domaines. */
  /* domainsFor retombe sur les domaines de l'univers quand l'entrée est vide. */
  const domains = input.universeSlug ? domainsFor(input.universeSlug, input.domainSlug ?? "") : [];
  for (const domain of domains) {
    const keyword = domain.keywords.find((k) => text.includes(norm(k)));
    if (!keyword) continue;
    const covered = people.some((p) => cardMatchesDomain(p, domain));
    if (covered) continue;
    push({
      text: `À pourvoir : ${domain.label}`,
      why: `« ${keyword} » est présent sur la toile, et personne ne porte encore ce rôle.`,
      uses: [`mot présent : ${keyword}`, `domaine : ${domain.label}`],
    });
  }

  /* 2. La formule qui se dessine : quintessence de la sélection réelle. */
  if (people.length > 0) {
    const reading = readSelection(people.map(asCard))[0];
    if (reading) {
      for (const role of reading.missing.slice(0, 2)) {
        push({
          text: `Pour la formule « ${reading.formula.title} » : ${role.label}`,
          why: `${reading.formula.why} Il manque encore : ${role.hint}`,
          uses: [`formule : ${reading.formula.title}`, `rôle : ${role.label}`],
        });
      }
    }
  }

  /* 3. Posés sur la toile mais pas dans l'équipe : le geste qui manque. */
  for (const o of cartes.slice(0, 3)) {
    if (o.data.cardId && memberCardIds.has(o.data.cardId)) continue;
    push({
      text: `Inviter ${o.data.name} dans le LAB`,
      why: "Sa carte est posée sur la toile ; l'inviter lui donnera la même vue, la même matière.",
      uses: [`carte posée : ${o.data.name}`],
      target: o.id,
    });
  }

  if (out.length === 0) {
    push({
      text: people.length
        ? "L'équipe répond déjà à ce qui est posé"
        : "Poser une première personne",
      why: people.length
        ? "Aucun rôle évoqué ne reste sans personne, et personne n'attend d'invitation."
        : "La facette Relations lit les personnes : posez une carte ou évoquez un métier, elle proposera.",
      uses: [people.length ? "les personnes réunies" : "la toile aujourd'hui"],
    });
  }
  return out;
}
