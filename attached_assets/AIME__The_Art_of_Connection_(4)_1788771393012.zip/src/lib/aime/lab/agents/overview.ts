import { analyzeTimeline } from "@/lib/aime/world/timelineAutomation";
import { type Fact, type WorldProject } from "@/lib/aime/world/types";

export type LabOverview = {
  solide: string[];
  fragile: string[];
  manquant: string[];
  contradictoire: string[];
  renforcer: string[];
};

const LABEL: [string, (p: WorldProject) => Fact<unknown>][] = [
  ["Date", (p) => p.pivot],
  ["Ville", (p) => p.city],
  ["Lieu", (p) => p.venue],
  ["Invités", (p) => p.guests],
];

export function buildOverview(project: WorldProject | null): LabOverview {
  if (!project) {
    return {
      solide: [],
      fragile: [],
      manquant: ["Le projet n'a pas encore assez de matière pour une lecture d'ensemble."],
      contradictoire: [],
      renforcer: ["Ajoutez une date, un lieu et une estimation d'invités."],
    };
  }

  const solide: string[] = [];
  const fragile: string[] = [];
  const manquant: string[] = [];

  for (const [label, pick] of LABEL) {
    const fact = pick(project);
    if (fact.confidence === "confirme" && fact.value != null && `${fact.value}`.trim()) {
      solide.push(`${label} : ${String(fact.value)}`);
      continue;
    }
    if (fact.confidence === "manquant") manquant.push(label);
    else fragile.push(`${label} (${fact.confidence})`);
  }

  const contradictoire = analyzeTimeline(project)
    .filter((a) => a.kind === "contradiction")
    .map((a) => a.title);

  const renforcer = [
    ...manquant.map((m) => `Renseigner ${m.toLowerCase()}.`),
    ...fragile.map((f) => `Confirmer ${f.toLowerCase()}.`),
    ...project.missing.slice(0, 3).map((m) => m.charAt(0).toUpperCase() + m.slice(1)),
  ];

  if (contradictoire.length > 0) {
    renforcer.push("Arbitrer les contradictions signalées dans la timeline.");
  }
  if (renforcer.length === 0) renforcer.push("Continuer à valider les propositions des facettes.");

  return { solide, fragile, manquant, contradictoire, renforcer };
}
