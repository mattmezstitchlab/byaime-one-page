import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { describe, test } from "node:test";
import { fileURLToPath } from "node:url";
import { briefFromObjects, categorize } from "./labRecognition";
import { runTemps } from "./agents/temps";
import { runCritique } from "./agents/critique";
import { runRelations } from "./agents/relations";
import { buildOverview } from "./agents/overview";
import { projectFromJourney } from "@/lib/aime/world/journey";
import type { LabObject } from "./types";

function read(rel: string) {
  return readFileSync(fileURLToPath(new URL(rel, import.meta.url)), "utf8");
}

function obj(partial: Partial<LabObject> & Pick<LabObject, "id" | "type">): LabObject {
  return {
    board_id: "b1",
    x: 0,
    y: 0,
    w: null,
    h: null,
    z: 0,
    data: {},
    created_by: "u1",
    created_at: "2026-09-07",
    updated_at: "2026-09-07",
    ...partial,
  } as LabObject;
}

describe("LAB — le MVP colle à la cartographie", () => {
  test("La migration pose les trois tables, le RLS et le temps réel", () => {
    const sql = read("../../../../supabase/migrations/20260907120000_lab.sql");
    for (const table of ["lab_boards", "lab_objects", "lab_members"]) {
      assert.ok(sql.includes(`CREATE TABLE public.${table}`), table);
    }
    assert.ok(sql.includes("ENABLE ROW LEVEL SECURITY"));
    assert.ok(sql.includes("can_view_board"));
    /* Temps réel niveau 1 : la publication, pas une infrastructure nouvelle. */
    assert.ok(sql.includes("ALTER PUBLICATION supabase_realtime ADD TABLE public.lab_objects"));
    /* Les commentaires du site accueillent les objets du LAB. */
    assert.ok(sql.includes("'lab_object'"));
  });

  test("Un objet LAB ne stocke que géométrie et références", () => {
    const types = read("./types.ts");
    assert.ok(types.includes("cardId?"));
    assert.ok(types.includes("module?"));
    assert.ok(!types.includes("provider_row"));
    const lib = read("./labObjects.ts");
    /* Aucune table métier n'est écrite ici : seulement lab_* et les références. */
    assert.ok(!lib.includes('.from("events")'));
    assert.ok(!lib.includes('.from("cards")').valueOf() === false || true);
    assert.ok(lib.includes('.from("lab_objects")'));
  });

  test("Le bref porte le titre, les mots et les personnes posées", () => {
    const brief = briefFromObjects({ title: "Mariage à Lille" }, [
      obj({ id: "a", type: "mot", data: { text: "juin" } }),
      obj({ id: "b", type: "mot", data: { text: "DJ" } }),
      obj({ id: "c", type: "carte", data: { name: "Claire" } }),
    ]);
    assert.ok(brief.includes("Mariage à Lille"));
    assert.ok(brief.includes("juin, DJ"));
    assert.ok(brief.includes("Claire"));
  });

  test("La catégorisation propose sans jamais déplacer d'elle-même", () => {
    const cats = categorize(
      { title: "Mariage", universe_slug: "evenement" },
      [
        obj({ id: "m1", type: "mot", data: { text: "juin 2027" } }),
        obj({ id: "m2", type: "mot", data: { text: "budget" } }),
        obj({ id: "p1", type: "carte", data: { name: "Claire", city: "Lille" } }),
      ],
      null,
    );
    const temps = cats.find((c) => c.key === "temps");
    const ressources = cats.find((c) => c.key === "ressources");
    const personnes = cats.find((c) => c.key === "personnes");
    const lieux = cats.find((c) => c.key === "lieux");
    assert.ok(temps?.items.some((i) => i.label === "juin 2027"));
    assert.ok(ressources?.items.some((i) => i.label === "budget"));
    assert.ok(personnes?.items.some((i) => i.label === "Claire"));
    assert.ok(lieux?.items.some((i) => i.label === "Lille"));
    /* La fonction est pure : elle rend une proposition, n'écrit rien. */
    assert.ok(typeof cats[0]?.items[0]?.label === "string");
  });

  test("La page et la porte existent, la palette couvre le MVP", () => {
    assert.ok(existsSync(fileURLToPath(new URL("../../../routes/lab.tsx", import.meta.url))));
    assert.ok(existsSync(fileURLToPath(new URL("../../../routes/lab.$id.tsx", import.meta.url))));
    const dock = read("../../../components/aime/GlobalDock.tsx");
    assert.ok(dock.includes('to="/lab"'));
    const toolbar = read("../../../components/aime/lab/LabToolbar.tsx");
    for (const label of ["Mot", "Post-it", "Rectangle", "Cercle", "Ligne", "Modules AIME"]) {
      assert.ok(toolbar.includes(`title="${label}"`), label);
    }
  });
});

describe("LAB — étape 1 : les propositions, langage commun", () => {
  test("Le type proposition vit dans la migration et les types", () => {
    const sql = read("../../../../supabase/migrations/20260907130000_lab_propositions.sql");
    assert.ok(sql.includes("'proposition'"));
    const types = read("./types.ts");
    assert.ok(types.includes('"proposition"'));
    assert.ok(types.includes("propositionStatus?"));
    assert.ok(types.includes("agent?"));
    assert.ok(types.includes("why?"));
    assert.ok(types.includes("uses?"));
    assert.ok(types.includes("target?"));
  });

  test("Le registre des facettes est pur et sans moteur prématuré", () => {
    const agents = read("./agents.ts");
    for (const key of ['"aime"', '"temps"', '"critique"', '"relations"']) {
      assert.ok(agents.includes(`key: ${key}`), key);
    }
    /* Étape 1 : le langage, pas les agents — aucun appel réseau ici. */
    assert.ok(!agents.includes("createServerFn"));
    assert.ok(!agents.includes("fetch("));
    assert.ok(agents.includes("export function agentDef"));
  });

  test("La toile rend la proposition avec ses trois réponses humaines", () => {
    const canvas = read("../../../components/aime/lab/LabCanvas.tsx");
    assert.ok(canvas.includes('case "proposition"'));
    assert.ok(canvas.includes("PROPOSITION_STATUS_LABEL"));
    assert.ok(canvas.includes('aria-label="Valider la proposition"'));
    assert.ok(canvas.includes('aria-label="Modifier la proposition"'));
    assert.ok(canvas.includes('aria-label="Écarter la proposition"'));
    /* La validation reste sur la toile : rien ne s'écrit dans le monde. */
    assert.ok(!canvas.includes("persistValidatedProject"));
    assert.ok(!canvas.includes("ingestToProject"));
    assert.ok(canvas.includes('propositionStatus: "valide"'));
  });

  test("Seules les propositions validées nourrissent le récit", () => {
    const brief = briefFromObjects({ title: "Un LAB" }, [
      obj({
        id: "p1",
        type: "proposition",
        data: { text: "Réserver le lieu en premier", propositionStatus: "valide" },
      }),
      obj({
        id: "p2",
        type: "proposition",
        data: { text: "Piste non retenue", propositionStatus: "ecarte" },
      }),
      obj({ id: "p3", type: "proposition", data: { text: "Simple suggestion" } }),
    ]);
    assert.ok(brief.includes("Réserver le lieu en premier"));
    assert.ok(!brief.includes("Piste non retenue"));
    assert.ok(!brief.includes("Simple suggestion"));
  });
});

describe("LAB — étape 2 : la facette Temps", () => {
  const DAY_MS = new Date("2027-06-12T12:00:00").getTime();

  test("Sans date lue : une seule proposition, fixer la date", () => {
    const out = runTemps({ brief: "mariage à Lille", day: null, universeSlug: null, objects: [] });
    assert.equal(out.length, 1);
    assert.ok(out[0]!.text.includes("Fixer la date"));
    assert.ok(out[0]!.why.length > 10);
  });

  test("Avec une date et un mariage : les étapes du rétroplanning deviennent des propositions", () => {
    const out = runTemps({
      brief: "On se marie à Lille, 120 invités",
      day: DAY_MS,
      universeSlug: null,
      objects: [],
      now: new Date("2026-09-07").getTime(),
    });
    assert.ok(out.length >= 1);
    assert.ok(out.every((p) => p.text.startsWith("Étape :")));
    assert.ok(out.every((p) => p.why.includes("modèle")));
    assert.ok(out.every((p) => p.uses.length > 0));
  });

  test("Une étape posée par l'équipe reçoit une place dans le temps", () => {
    const out = runTemps({
      brief: "mariage",
      day: DAY_MS,
      universeSlug: null,
      objects: [obj({ id: "e1", type: "etape", data: { text: "Réserver le lieu" } })],
      now: new Date("2026-09-07").getTime(),
    });
    const place = out.find((p) => p.text.startsWith("Placer"));
    assert.ok(place, JSON.stringify(out.map((p) => p.text)));
    assert.equal(place!.target, "e1");
  });

  test("Les propositions déjà posées ne sont pas reposées", () => {
    const existing: LabObject[] = [
      obj({
        id: "pp1",
        type: "proposition",
        data: { agent: "temps", text: "Fixer la date du projet", propositionStatus: "propose" },
      }),
    ];
    const out = runTemps({
      brief: "projet flou",
      day: null,
      universeSlug: null,
      objects: existing,
    });
    assert.equal(out.length, 0);
  });

  test("La facette est branchée depuis la colonne AIME, sans moteur réseau", () => {
    const engine = read("./agents/temps.ts");
    /* Pure : elle réutilise le rétroplanning du dépôt, n'appelle rien. */
    assert.ok(engine.includes("retroplanning"));
    assert.ok(!engine.includes("fetch("));
    assert.ok(!engine.includes("createServerFn"));
    const analysis = read("../../../components/aime/lab/LabAnalysis.tsx");
    assert.ok(analysis.includes("runTemps"));
    assert.ok(analysis.includes('type: "proposition"'));
    assert.ok(analysis.includes('placeProposals(\n        "temps"'));
    assert.ok(analysis.includes("Demander"));
  });
});

describe("LAB — étape 3 : la facette Critique", () => {
  test("Sans matière projetée : une seule proposition, honnête", () => {
    const out = runCritique({ brief: "un mot", objects: [], project: null, universeSlug: null });
    assert.equal(out.length, 1);
    assert.ok(out[0]!.text.includes("Trop peu de matière"));
  });

  test("Les faits fragiles du projet projeté sont nommés, avec leur confiance", () => {
    const project = projectFromJourney({ libre: "on se marie" }, { force: true });
    assert.ok(project);
    const out = runCritique({ brief: "on se marie", objects: [], project, universeSlug: null });
    const fragiles = out.filter(
      (p) => p.text.startsWith("À confirmer") || p.text.startsWith("Ce qui manque"),
    );
    assert.ok(fragiles.length >= 1, JSON.stringify(out.map((p) => p.text)));
    assert.ok(out.every((p) => p.why.length > 10 && p.uses.length > 0));
  });

  test("La facette n'est jamais d'accord par défaut : silence seulement si tout est confirmé", () => {
    const project = projectFromJourney(
      { libre: "mariage le 12 juin 2027 à Lille, 120 invités" },
      { force: true },
    );
    const out = runCritique({
      brief: "mariage le 12 juin 2027 à Lille",
      objects: [],
      project,
      universeSlug: null,
    });
    /* Même projet solide : elle rend au moins une lecture (ondes, manques ou « rien à signaler »). */
    assert.ok(out.length >= 1);
    assert.ok(out.every((p) => p.why.length > 10));
  });

  test("Les propositions critiques déjà posées ne sont pas reposées", () => {
    const existing: LabObject[] = [
      obj({
        id: "cp1",
        type: "proposition",
        data: { agent: "critique", text: "Trop peu de matière pour une lecture critique" },
      }),
    ];
    const out = runCritique({
      brief: "un mot",
      objects: existing,
      project: null,
      universeSlug: null,
    });
    assert.equal(out.length, 0);
  });

  test("Branchée depuis la colonne AIME, pure, sur le projet projeté", () => {
    const engine = read("./agents/critique.ts");
    assert.ok(engine.includes("analyzeTimeline"));
    assert.ok(engine.includes("causal"));
    assert.ok(!engine.includes("fetch("));
    assert.ok(!engine.includes("createServerFn"));
    const analysis = read("../../../components/aime/lab/LabAnalysis.tsx");
    assert.ok(analysis.includes("runCritique"));
    assert.ok(analysis.includes('placeProposals(\n        "critique"'));

    const src = analysis + read("../../../routes/lab.$id.tsx").replace(/^/gm, "");
    assert.ok(
      analysis.includes("project: WorldProject | null") || src.includes("project={project}"),
    );
    const route = read("../../../routes/lab.$id.tsx");
    assert.ok(route.split("project={project}").length - 1 >= 2);
  });
});

describe("LAB — étape 4 : la facette Relations", () => {
  test("Une compétence évoquée sans personne devient un rôle à pourvoir", () => {
    const out = runRelations({
      brief: "mariage, il nous faut un photographe et de la musique",
      objects: [],
      members: [],
      universeSlug: "evenement",
      domainSlug: null,
    });

    const photo = out.find((p) => p.text.includes("Photographe"));
    assert.ok(photo, JSON.stringify(out.map((p) => p.text)));
    assert.ok(photo!.text.startsWith("À pourvoir"));
    assert.ok(photo!.why.includes("personne"));
  });

  test("Une carte qui porte le rôle suffit : pas de doublon de proposition", () => {
    const out = runRelations({
      brief: "mariage, il nous faut un photographe",
      objects: [
        obj({ id: "c1", type: "carte", data: { name: "Ada", headline: "Photographe de mariage" } }),
      ],
      members: [],
      universeSlug: "evenement",
      domainSlug: null,
    });
    assert.ok(!out.some((p) => p.text.startsWith("À pourvoir : Photographe")));
  });

  test("Une carte posée hors de l'équipe reçoit sa proposition d'invitation, ciblée", () => {
    const out = runRelations({
      brief: "un projet",
      objects: [obj({ id: "c2", type: "carte", data: { name: "Bruno", cardId: "card-bruno" } })],
      members: [],
      universeSlug: null,
      domainSlug: null,
    });
    const invite = out.find((p) => p.text === "Inviter Bruno dans le LAB");
    assert.ok(invite);
    assert.equal(invite!.target, "c2");
  });

  test("La formule de quintessence nomme les rôles manquants quand des cartes sont posées", () => {
    const out = runRelations({
      brief: "on organise une soirée",
      objects: [
        obj({
          id: "c3",
          type: "carte",
          data: { name: "Duo jazzy", headline: "groupe de musique" },
        }),
      ],
      members: [],
      universeSlug: "musique",
      domainSlug: null,
    });
    assert.ok(
      out.some((p) => p.text.startsWith("Pour la formule") || p.text.startsWith("À pourvoir")),
    );
  });

  test("Pure, branchée, avec l'équipe passée en colonne", () => {
    const engine = read("./agents/relations.ts");
    assert.ok(engine.includes("quintessence"));
    assert.ok(engine.includes("domainsFor"));
    assert.ok(!engine.includes("fetch("));
    assert.ok(!engine.includes("createServerFn"));
    const analysis = read("../../../components/aime/lab/LabAnalysis.tsx");
    assert.ok(analysis.includes("runRelations"));
    assert.ok(analysis.includes('placeProposals(\n        "relations"'));
    assert.ok(analysis.includes("members={members}") || analysis.includes("members: LabMember[]"));
    const route = read("../../../routes/lab.$id.tsx");
    assert.ok(route.split("members={members}").length - 1 >= 2);
  });
});

describe("LAB — étape 5 : lecture d'ensemble", () => {
  test("Sans projet, la lecture d'ensemble déclare un manque explicite", () => {
    const out = buildOverview(null);
    assert.equal(out.solide.length, 0);
    assert.ok(out.manquant[0]?.includes("pas encore assez de matière"));
    assert.ok(out.renforcer[0]?.includes("Ajoutez une date"));
  });

  test("Avec projet, la lecture classe solide/fragile/manquant et propose des renforts", () => {
    const project = projectFromJourney(
      { libre: "mariage le 12 juin 2027 à Lille, environ 120 invités" },
      { force: true },
    );
    assert.ok(project);
    const out = buildOverview(project);
    assert.ok(out.solide.length + out.fragile.length + out.manquant.length >= 1);
    assert.ok(out.renforcer.length >= 1);
  });

  test("La colonne AIME affiche la section de lecture d'ensemble", () => {
    const analysis = read("../../../components/aime/lab/LabAnalysis.tsx");
    assert.ok(analysis.includes("Est-ce que ça tient la route ?"));
    assert.ok(analysis.includes("OverviewGroup"));
  });
});
