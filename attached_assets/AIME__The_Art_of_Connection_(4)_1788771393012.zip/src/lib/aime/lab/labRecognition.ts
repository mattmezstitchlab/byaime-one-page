/**
 * LAB : la matière première devient récit lisible par AIME.
 * Ce module est PUR (aucun import de client) : la même fonction tourne dans
 * les tests et dans le navigateur. La lecture elle-même revient aux briques
 * existantes — readStoryAI côté serveur, catégorisation déterministe ici.
 * AIME propose des étiquettes ; l'humain les valide (jamais l'inverse).
 */
import type { LabBoard, LabObject } from "./types";

/** Ce qu'AIME sait lire d'un projet, après readStoryAI. */
export type LabReading = {
  day: number | null;
  city: string | null;
  venue: string | null;
  guests: number | null;
  couple: string | null;
  booked: { role: string }[];
  details: Record<string, string>;
};

export const LAB_CATEGORIES = [
  { key: "objectifs", label: "Objectifs" },
  { key: "personnes", label: "Personnes" },
  { key: "lieux", label: "Lieux" },
  { key: "temps", label: "Temps" },
  { key: "ressources", label: "Ressources" },
  { key: "idees", label: "Idées" },
] as const;

export type LabCategoryKey = (typeof LAB_CATEGORIES)[number]["key"];

export type LabCategory = {
  key: LabCategoryKey;
  label: string;
  /** {id : l'objet LAB, label : ce qui se lit} — un mot, une référence… */
  items: { id: string; label: string }[];
};

const MONTHS =
  /janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre/i;
const TIME_HINT =
  /\b\d{1,2}\s?(h|heures?)\b|\b\d{4}\b|\b\d{1,2}\s?(janv|févr|avr|juil|sept|oct|nov|déc)/i;
const RESOURCE_HINT =
  /budget|prix|coût|cout|devis|euros?|€|argent|financement|matériel|materiel|logistique|transport|hébergement|hebergement|musique|son|lumière|lumiere/i;
const PLACE_HINT = /ville|près|pres de|à paris|à lyon|à lille|restaurant|salle|lieu|domicile/i;

function isTimeWord(s: string) {
  return MONTHS.test(s) || TIME_HINT.test(s);
}
function isResourceWord(s: string) {
  return RESOURCE_HINT.test(s);
}
function isPlaceWord(s: string) {
  return PLACE_HINT.test(s);
}

/** Le bref : ce que la toile dit d'elle-même, en quelques lignes. */
export function briefFromObjects(board: Pick<LabBoard, "title">, objects: LabObject[]): string {
  const mots = objects.filter((o) => o.type === "mot").map((o) => o.data.text?.trim() ?? "");
  const notes = objects
    .filter((o) => o.type === "note" && o.data.text?.trim())
    .map((o) => `— ${o.data.text?.trim()}`);
  const etapes = objects
    .filter((o) => o.type === "etape" && o.data.text?.trim())
    .map((o) => o.data.text?.trim());
  const gens = objects.filter((o) => o.type === "carte").map((o) => o.data.name ?? "une personne");
  const pieces = objects
    .filter((o) => o.type === "media")
    .map((o) => o.data.text || o.data.url || "une pièce");
  /* Seules les propositions validées par un humain nourrissent le récit :
     la frontière entre « suggéré » et « retenu » reste visible. */
  const retenues = objects
    .filter((o) => o.type === "proposition" && o.data.propositionStatus === "valide")
    .map((o) => o.data.text?.trim())
    .filter(Boolean);

  const lines = [
    `Projet : ${board.title}.`,
    mots.length ? `Mots posés : ${mots.filter(Boolean).join(", ")}.` : "",
    gens.length ? `Personnes réunies : ${gens.join(", ")}.` : "",
    etapes.length ? `Étapes évoquées : ${etapes.join(", ")}.` : "",
    pieces.length ? `Pièces apportées : ${pieces.join(", ")}.` : "",
    retenues.length ? `Propositions retenues : ${retenues.join(" ; ")}.` : "",
    notes.length ? `Notes :\n${notes.join("\n")}` : "",
  ].filter(Boolean);

  return lines.join("\n").slice(0, 1200);
}

/**
 * La catégorisation proposée : les catégories stables d'AIME (personnes,
 * lieux, temps, ressources…), remplies par ce que la toile contient et par
 * ce que readStoryAI a lu. Proposition seulement — l'humain valide.
 */
export function categorize(
  board: Pick<LabBoard, "title" | "universe_slug">,
  objects: LabObject[],
  reading: LabReading | null,
): LabCategory[] {
  const byKey: Record<LabCategoryKey, { id: string; label: string }[]> = {
    objectifs: [],
    personnes: [],
    lieux: [],
    temps: [],
    ressources: [],
    idees: [],
  };

  byKey.objectifs.push({ id: "board", label: board.title });
  if (board.universe_slug) byKey.objectifs.push({ id: "universe", label: board.universe_slug });

  if (reading?.couple) byKey.personnes.push({ id: "reading:couple", label: reading.couple });
  for (const p of reading?.booked ?? [])
    byKey.personnes.push({ id: `role:${p.role}`, label: p.role });
  if (reading?.guests)
    byKey.personnes.push({ id: "reading:guests", label: `${reading.guests} invités` });

  if (reading?.city) byKey.lieux.push({ id: "reading:city", label: reading.city });
  if (reading?.venue && reading.venue !== reading.city)
    byKey.lieux.push({ id: "reading:venue", label: reading.venue });

  if (reading?.day)
    byKey.temps.push({
      id: "reading:day",
      label: new Date(reading.day).toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
    });

  for (const o of objects) {
    const text = o.data.text?.trim();
    switch (o.type) {
      case "mot":
        if (!text) break;
        if (isTimeWord(text)) byKey.temps.push({ id: o.id, label: text });
        else if (isResourceWord(text)) byKey.ressources.push({ id: o.id, label: text });
        else if (isPlaceWord(text)) byKey.lieux.push({ id: o.id, label: text });
        else byKey.idees.push({ id: o.id, label: text });
        break;
      case "note":
        if (text) byKey.idees.push({ id: o.id, label: text.slice(0, 60) });
        break;
      case "carte":
        byKey.personnes.push({ id: o.id, label: o.data.name ?? "Une personne" });
        if (o.data.city) byKey.lieux.push({ id: `${o.id}:city`, label: o.data.city });
        break;
      case "media":
        byKey.ressources.push({ id: o.id, label: o.data.text || "Une pièce" });
        break;
      case "etape":
        if (text) byKey.objectifs.push({ id: o.id, label: text });
        break;
      default:
        break;
    }
  }

  for (const detail of Object.entries(reading?.details ?? {})) {
    byKey.ressources.push({ id: `detail:${detail[0]}`, label: `${detail[0]} : ${detail[1]}` });
  }

  return LAB_CATEGORIES.map((c) => ({ ...c, items: byKey[c.key] })).filter(
    (c) => c.items.length > 0,
  );
}

/** La catégorie lisible d'un objet, une fois validée. */
export function catLabel(key: string | undefined): string | null {
  return LAB_CATEGORIES.find((c) => c.key === key)?.label ?? null;
}
