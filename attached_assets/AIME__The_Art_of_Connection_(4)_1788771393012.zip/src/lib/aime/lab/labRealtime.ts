/**
 * LAB : le temps réel, niveau 1 — chacun voit les modifications des autres.
 * Même API Supabase que le badge de réparation (postgres_changes) : aucune
 * infrastructure nouvelle, une publication et un canal.
 */
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { BOARD_QK, MEMBERS_QK, OBJECTS_QK } from "./labObjects";

export function useLabRealtime(boardId: string) {
  const qc = useQueryClient();

  useEffect(() => {
    if (!boardId) return;
    const refresh = () => {
      void qc.invalidateQueries({ queryKey: BOARD_QK(boardId) });
      void qc.invalidateQueries({ queryKey: OBJECTS_QK(boardId) });
      void qc.invalidateQueries({ queryKey: MEMBERS_QK(boardId) });
    };

    const channel = supabase
      .channel(`lab:${boardId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "lab_objects", filter: `board_id=eq.${boardId}` },
        refresh,
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "lab_members", filter: `board_id=eq.${boardId}` },
        refresh,
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "lab_boards", filter: `id=eq.${boardId}` },
        refresh,
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [boardId, qc]);
}
