/**
 * LAB : la persistance de la toile. Tout passe par les tables lab_* et les
 * briques existantes (cards, media_items) — références, jamais de copies.
 */
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import type { LabBoard, LabMember, LabObject, LabObjectType } from "./types";

export const BOARD_QK = (id: string) => ["lab-board", id] as const;
export const OBJECTS_QK = (id: string) => ["lab-objects", id] as const;
export const MEMBERS_QK = (id: string) => ["lab-members", id] as const;

export function myBoardsQuery(userId: string | null) {
  return {
    queryKey: ["lab-boards", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async (): Promise<LabBoard[]> => {
      const { data, error } = await supabase
        .from("lab_boards")
        .select("*")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as LabBoard[];
    },
  };
}

export function boardQuery(id: string) {
  return {
    queryKey: BOARD_QK(id),
    enabled: !!id,
    queryFn: async (): Promise<LabBoard | null> => {
      const { data, error } = await supabase
        .from("lab_boards")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return (data as LabBoard) ?? null;
    },
  };
}

export function objectsQuery(boardId: string) {
  return {
    queryKey: OBJECTS_QK(boardId),
    enabled: !!boardId,
    queryFn: async (): Promise<LabObject[]> => {
      const { data, error } = await supabase
        .from("lab_objects")
        .select("*")
        .eq("board_id", boardId)
        .order("z", { ascending: true });
      if (error) throw error;
      return (data ?? []) as LabObject[];
    },
  };
}

export function membersQuery(boardId: string) {
  return {
    queryKey: MEMBERS_QK(boardId),
    enabled: !!boardId,
    queryFn: async (): Promise<LabMember[]> => {
      const { data, error } = await supabase
        .from("lab_members")
        .select("*, card:cards(id,name,headline,image_url,city)")
        .eq("board_id", boardId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as LabMember[];
    },
  };
}

export async function createBoard(userId: string, title: string) {
  const { data, error } = await supabase
    .from("lab_boards")
    .insert({ owner_id: userId, title: title.trim() || "Un nouveau LAB" })
    .select("id")
    .single();
  if (error) throw new Error("Le LAB ne s'ouvre pas. Réessayez.");
  return data.id as string;
}

export async function addObject(input: {
  boardId: string;
  userId: string;
  type: LabObjectType;
  x: number;
  y: number;
  data: LabObject["data"];
  w?: number | null;
  h?: number | null;
  z?: number;
}) {
  const { data, error } = await supabase
    .from("lab_objects")
    .insert({
      board_id: input.boardId,
      type: input.type,
      x: Math.round(input.x),
      y: Math.round(input.y),
      w: input.w ?? null,
      h: input.h ?? null,
      z: input.z ?? 0,
      data: input.data as Json,
      created_by: input.userId,
    })
    .select("id")
    .single();
  if (error) throw new Error("L'objet ne se pose pas. Réessayez.");
  return data.id as string;
}

export async function updateObject(
  id: string,
  patch: Partial<Pick<LabObject, "x" | "y" | "w" | "h" | "z" | "data">>,
) {
  const { data, ...rest } = patch;
  const { error } = await supabase
    .from("lab_objects")
    .update({ ...rest, ...(data !== undefined ? { data: data as Json } : {}) })
    .eq("id", id);
  if (error) throw new Error("L'objet ne bouge pas. Réessayez.");
}

export async function deleteObject(id: string) {
  const { error } = await supabase.from("lab_objects").delete().eq("id", id);
  if (error) throw new Error("L'objet ne s'efface pas. Réessayez.");
}

export async function addMember(boardId: string, cardId: string, roleLabel: string) {
  const { error } = await supabase
    .from("lab_members")
    .insert({ board_id: boardId, card_id: cardId, role_label: roleLabel });
  if (error) throw new Error("La personne ne rejoint pas. Réessayez.");
}

export async function removeMember(id: string) {
  const { error } = await supabase.from("lab_members").delete().eq("id", id);
  if (error) throw new Error("Le départ ne s'enregistre pas. Réessayez.");
}

export async function updateBoard(
  id: string,
  patch: Partial<Pick<LabBoard, "title" | "universe_slug" | "domain_slug" | "event_id">>,
) {
  const { error } = await supabase.from("lab_boards").update(patch).eq("id", id);
  if (error) throw new Error("Le LAB ne s'actualise pas. Réessayez.");
}
