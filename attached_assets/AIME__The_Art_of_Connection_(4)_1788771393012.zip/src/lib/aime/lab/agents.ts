/**
 * LAB — le registre des facettes d'AIME.
 *
 * Une même intelligence distribuée, pas neuf chats indépendants : chaque
 * facette lit UNE partie du même contexte (le board + le World Model
 * projeté) et rend des propositions — des objets visibles sur la toile,
 * jamais des décisions. Ce registre est PUR : les moteurs viendront s'y
 * brancher (Temps, Critique, Relations…), en réutilisant les briques
 * existantes du dépôt (retroplanning, causal, domains, readStoryAI…).
 */

export type LabAgentKey = "aime" | "temps" | "critique" | "relations";

export type LabAgentDef = {
  key: LabAgentKey;
  label: string;
  /** Ce qu'elle lit — dit simplement, affiché sur la proposition. */
  facet: string;
  /** La couleur de son point, sur la toile comme dans les listes. */
  dot: string;
};

export const LAB_AGENTS: LabAgentDef[] = [
  {
    key: "aime",
    label: "AIME",
    facet: "L'intention globale et l'orchestration",
    dot: "bg-foreground",
  },
  {
    key: "temps",
    label: "Temps",
    facet: "Les étapes, l'ordre, les échéances et leurs conflits",
    dot: "bg-amber-500",
  },
  {
    key: "critique",
    label: "Critique",
    facet: "Les incohérences, les hypothèses fragiles, ce qui manque",
    dot: "bg-rose-500",
  },
  {
    key: "relations",
    label: "Relations",
    facet: "Les personnes, les compétences et les connexions possibles",
    dot: "bg-sky-500",
  },
];

export function agentDef(key: string | undefined): LabAgentDef | null {
  return LAB_AGENTS.find((a) => a.key === key) ?? null;
}

/** Le statut d'une proposition : proposée, validée par un humain, écartée. */
export type PropositionStatus = "propose" | "valide" | "ecarte";

export const PROPOSITION_STATUS_LABEL: Record<PropositionStatus, string> = {
  propose: "Proposé",
  valide: "Validé",
  ecarte: "Écarté",
};
