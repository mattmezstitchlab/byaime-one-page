import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type ReportTarget = "carte" | "moment" | "commentaire" | "conversation";
export type ReportReason = "harcelement" | "haine" | "nudite" | "spam" | "usurpation" | "danger" | "autre";
export type Report = Database["public"]["Tables"]["reports"]["Row"];

export function myRolesQuery(userId: string | null | undefined) {
  return {
    queryKey: ["mes-roles", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId ?? "");
      if (error) throw error;
      return (data ?? []).map((item) => item.role);
    },
  };
}

export async function reportContent(input: {
  reporterId: string;
  targetType: ReportTarget;
  targetId: string;
  reason: ReportReason;
  details?: string;
}) {
  const { error } = await supabase.from("reports").upsert(
    {
      reporter_id: input.reporterId,
      target_type: input.targetType,
      target_id: input.targetId,
      reason: input.reason,
      details: input.details?.trim() || null,
      status: "pending",
    },
    { onConflict: "reporter_id,target_type,target_id", ignoreDuplicates: true },
  );
  if (error) throw error;
}

export function myBlocksQuery(userId: string | null | undefined) {
  return {
    queryKey: ["blocages", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("blocks")
        .select("*")
        .eq("blocker_id", userId ?? "");
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function blockPerson(blockerId: string, blockedId: string) {
  const { error } = await supabase.from("blocks").insert({ blocker_id: blockerId, blocked_id: blockedId });
  if (error && error.code !== "23505") throw error;
}

export async function unblockPerson(blockerId: string, blockedId: string) {
  const { error } = await supabase
    .from("blocks")
    .delete()
    .eq("blocker_id", blockerId)
    .eq("blocked_id", blockedId);
  if (error) throw error;
}

export function moderationReportsQuery(enabled: boolean) {
  return {
    queryKey: ["signalements-moderation"],
    enabled,
    queryFn: async (): Promise<Report[]> => {
      const { data, error } = await supabase
        .from("reports")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  };
}

export async function reviewReport(input: {
  id: string;
  reviewerId: string;
  status: "reviewing" | "dismissed" | "actioned";
  decision?: string;
}) {
  const { error } = await supabase
    .from("reports")
    .update({
      status: input.status,
      decision: input.decision?.trim() || null,
      reviewed_by: input.reviewerId,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", input.id);
  if (error) throw error;
}