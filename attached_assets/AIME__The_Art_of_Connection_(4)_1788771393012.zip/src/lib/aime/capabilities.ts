/**
 * Catalogue des capacités réelles d'AIME.
 * Source unique de vérité pour la feuille de route : les badges et les liens
 * viennent d'ici, jamais du texte généré par l'IA.
 */

export type CapabilityStatus = "disponible" | "partiel" | "bientot";

export type Capability = {
  id: string;
  /** Libellé court, langage d'usage. */
  label: string;
  /** Ce que ça permet de faire, en une phrase. */
  what: string;
  /** Route réelle du site. */
  to: string;
  /** Libellé du bouton. */
  action: string;
  status: CapabilityStatus;
  /** Détour praticable quand ce n'est pas complet. Obligatoire hors "disponible". */
  workaround?: string;
};

export const CAPABILITY_STATUS_LABEL: Record<CapabilityStatus, string> = {
  disponible: "Disponible",
  partiel: "Partiel",
  bientot: "Bientôt",
};

export const CAPABILITIES: Capability[] = [
  {
    id: "carte",
    label: "Créer ma page",
    what: "Se présenter, dire ce qu'on sait faire et quand on est libre.",
    to: "/mon-espace",
    action: "Créer ma page",
    status: "disponible",
  },
  {
    id: "registre",
    label: "Ouvrir Le Monde AIME",
    what: "Trouver des personnes, des lieux et des savoir-faire par univers et par ville.",
    to: "/reseau",
    action: "Ouvrir Le Monde AIME",
    status: "disponible",
  },
  {
    id: "annuaire-carte",
    label: "Explorer la carte du réseau",
    what: "Voir qui est où, autour de vous, en géolocalisation.",
    to: "/reseau",
    action: "Ouvrir la carte",
    status: "disponible",
  },
  {
    id: "equipe",
    label: "Composer l'équipe",
    what: "Aime assemble les cartes qui vont bien ensemble et explique pourquoi.",
    to: "/reseau",
    action: "Composer",
    status: "disponible",
  },
  {
    id: "intention",
    label: "Envoyer une intention",
    what: "Le bouton cœur : travailler ensemble, réserver, conseiller, discuter.",
    to: "/reseau",
    action: "Choisir une carte",
    status: "disponible",
  },
  {
    id: "messages",
    label: "En parler",
    what: "Échanger avec les personnes dont l'intention a été acceptée.",
    to: "/mon-espace",
    action: "Ouvrir les messages",
    status: "disponible",
  },
  {
    id: "projet",
    label: "Ouvrir le projet",
    what: "Date, lieu, participants, budget : le moment existe au même endroit.",
    to: "/mon-espace",
    action: "Ouvrir mes projets",
    status: "disponible",
  },
  {
    id: "date",
    label: "Réserver une date",
    what: "Poser la date sur le calendrier et croiser les disponibilités.",
    to: "/mon-espace",
    action: "Ouvrir le calendrier",
    status: "disponible",
  },
  {
    id: "devis",
    label: "Demander un devis",
    what: "Créer un devis brouillon lié à une carte et à une date.",
    to: "/reseau",
    action: "Choisir un prestataire",
    status: "disponible",
  },
  {
    id: "budget",
    label: "Suivre le budget",
    what: "Budget et trésorerie du projet, alimentés par les devis et les paiements.",
    to: "/mon-espace",
    action: "Voir le budget",
    status: "disponible",
  },
  {
    id: "documents",
    label: "Ranger un document",
    what: "Déposer devis, factures et justificatifs : Aime lit, classe et dit ce qui manque.",
    to: "/mon-espace",
    action: "Ouvrir mes documents",
    status: "disponible",
  },
  {
    id: "participants",
    label: "Inviter les participants",
    what: "Envoyer les invitations et suivre les réponses.",
    to: "/mon-espace",
    action: "Ouvrir le projet",
    status: "disponible",
  },
  {
    id: "paiement",
    label: "Encaisser et payer",
    what: "Paiements par carte reliés au projet et aux participants.",
    to: "/credits",
    action: "Voir les paiements",
    status: "partiel",
    workaround:
      "Le paiement en ligne existe pour les crédits et certains projets. Autrement : ajoutez le règlement aux documents du projet, il se rapproche du devis.",
  },
  {
    id: "musique",
    label: "Préparer la musique",
    what: "MusicBox et Radio Aime : demandes musicales et ambiance du moment.",
    to: "/mon-espace",
    action: "Ouvrir la MusicBox",
    status: "partiel",
    workaround:
      "La MusicBox vit dans le projet. Autrement : notez les titres dans la timeline du projet.",
  },
  {
    id: "export-compta",
    label: "Exporter la comptabilité",
    what: "Synthèse comptable prête à importer chez le comptable.",
    to: "/mon-espace",
    action: "Ouvrir mes documents",
    status: "partiel",
    workaround: "L'export autonome a été retiré ; les pièces restent classées dans Documents.",
  },
  {
    id: "membres",
    label: "Partager le dossier",
    what: "Inviter quelqu'un à voir ou gérer les documents avec vous.",
    to: "/mon-espace",
    action: "Ouvrir mes documents",
    status: "partiel",
    workaround: "Les accès se gèrent désormais dans le contexte de chaque projet.",
  },
  {
    id: "avis",
    label: "Laisser un avis",
    what: "Raconter la rencontre après coup sur la carte concernée.",
    to: "/reseau",
    action: "Retrouver la carte",
    status: "partiel",
    workaround: "L'avis s'écrit depuis la page de la carte, une fois la rencontre passée.",
  },
  {
    id: "timeline",
    label: "Noter dans la timeline",
    what: "Poser un repère, une note ou un moment sur la ligne de temps.",
    to: "/mon-espace",
    action: "Ouvrir la timeline",
    status: "disponible",
  },
  {
    id: "guides",
    label: "Lire un guide local",
    what: "Repères métier par ville pour savoir quoi demander et à quel prix.",
    to: "/guides",
    action: "Lire les guides",
    status: "disponible",
  },
  {
    id: "aime",
    label: "En parler à Aime",
    what: "Reformuler, affiner, demander une autre piste.",
    to: "/reseau",
    action: "Parler à Aime",
    status: "disponible",
  },
];

export const CAPABILITY_BY_ID = new Map(CAPABILITIES.map((c) => [c.id, c]));

/** Étape de secours : rien ne bloque jamais. */
export const FALLBACK_CAPABILITY_ID = "timeline";
