import type { Database } from "@/integrations/supabase/types";
import { supabase } from "@/integrations/supabase/client";

export type MusicboxEntry = Database["public"]["Tables"]["musicbox_entries"]["Row"];

export const MUSICBOX_KINDS = [
  { value: "musique", label: "Morceau", dot: "bg-violet-500" },
  { value: "message", label: "Message vocal", dot: "bg-sky-500" },
  { value: "annonce", label: "Annonce", dot: "bg-amber-500" },
  { value: "recit", label: "Récit / conte / lecture", dot: "bg-emerald-500" },
  { value: "biographie", label: "Biographie", dot: "bg-teal-500" },
  { value: "tache", label: "Tâche", dot: "bg-slate-500" },
  { value: "rdv", label: "Rendez-vous", dot: "bg-rose-500" },
] as const;

export type MusicboxKind = (typeof MUSICBOX_KINDS)[number]["value"];

export const KIND_LABEL: Record<string, string> = Object.fromEntries(
  MUSICBOX_KINDS.map((k) => [k.value, k.label]),
);

export const KIND_DOT: Record<string, string> = Object.fromEntries(
  MUSICBOX_KINDS.map((k) => [k.value, k.dot]),
);

export const VISIBILITY = [
  { value: "prive", label: "Privé" },
  { value: "invites", label: "Invités" },
  { value: "public", label: "Public (radio)" },
] as const;

export const RADIO_KINDS = new Set(["musique", "message", "annonce", "recit", "biographie"]);

/** Début absolu d'une entrée. */
export function entryStart(e: Pick<MusicboxEntry, "day" | "start_time">) {
  const time = (e.start_time ?? "20:00:00").slice(0, 8);
  return new Date(`${e.day}T${time.length === 5 ? `${time}:00` : time}`);
}

export function entryEnd(e: Pick<MusicboxEntry, "day" | "start_time" | "duration_min">) {
  return new Date(entryStart(e).getTime() + Math.max(1, e.duration_min ?? 4) * 60_000);
}

export function isLive(e: MusicboxEntry, now: Date) {
  const t = now.getTime();
  return t >= entryStart(e).getTime() && t < entryEnd(e).getTime();
}

export function formatSlot(e: Pick<MusicboxEntry, "day" | "start_time" | "duration_min">) {
  const s = entryStart(e);
  return `${s.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })} · ${e.duration_min ?? 4} min`;
}

export function countdown(ms: number) {
  const total = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${`${s}`.padStart(2, "0")}`;
}

export { distanceKm } from "./geo";

export async function signedAudioUrl(path: string | null) {
  if (!path) return null;
  const { data } = await supabase.storage.from("musicbox").createSignedUrl(path, 3600);
  return data?.signedUrl ?? null;
}

/** Identifie un lecteur externe embarquable. */
export function embedInfo(
  url: string | null,
): { kind: "youtube" | "spotify" | "soundcloud" | "audio" | "link"; src: string } | null {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtube.com") || u.hostname === "youtu.be") {
      const id = u.hostname === "youtu.be" ? u.pathname.slice(1) : u.searchParams.get("v");
      if (id) return { kind: "youtube", src: `https://www.youtube.com/embed/${id}` };
    }
    if (u.hostname.includes("spotify.com")) {
      return { kind: "spotify", src: url.replace("open.spotify.com/", "open.spotify.com/embed/") };
    }
    if (u.hostname.includes("soundcloud.com")) {
      return {
        kind: "soundcloud",
        src: `https://w.soundcloud.com/player/?url=${encodeURIComponent(url)}&color=%23111111`,
      };
    }
    if (/\.(mp3|m4a|wav|ogg)$/i.test(u.pathname)) return { kind: "audio", src: url };
    return { kind: "link", src: url };
  } catch {
    return null;
  }
}
