# Brief pour Manus — analyse externe d'AIME

> Message prêt à copier-coller. À envoyer tel quel à Manus.

---

## 0. Ta mission

Tu es un analyste externe. Je te demande un **rapport d'analyse en trois volets** sur mon produit AIME :
parcours utilisateur, positionnement/marché, qualité technique et référencement.

Tu peux faire de la recherche web. Tu **ne dois pas** produire de code, ni proposer une refonte
totale du produit. Je cherche un regard lucide et hiérarchisé sur l'existant.

Site à analyser : **https://byaime.fr** (page d'accueil, démonstration `/demo/mariage`,
`/reseau`, `/mon-espace`, `/projets`, `/guides`).

---

## 1. Ce qu'est AIME

AIME transforme une **intention racontée en langage libre** en un **monde/projet** structuré.

Exemple : quelqu'un écrit « on se marie en juin près de Bordeaux, environ 80 personnes, on a
déjà le lieu ». AIME lit ce récit, en déduit une date, un lieu, un nombre d'invités, ce qui est
déjà réservé, et **fait apparaître une ligne de temps** — les points se posent un à un pendant
la lecture. C'est le geste différenciant du produit.

Le projet ainsi créé contient tout : préparatifs, prestataires, devis, paiements, participants,
musique, photos, souvenirs, messages. Le premier cas d'usage travaillé est le **mariage**, mais
le modèle est volontairement générique (tout projet daté et collectif).

### Principes non négociables

1. **Une seule ligne de temps universelle.** Pas de second calendrier, pas de vue concurrente.
   Les « phases » (Tout / Avant / Pendant / Après) ne sont que des fenêtres sur cette même ligne.
2. **Une information n'est jamais dupliquée, elle se propage.** Une seule source de vérité par
   donnée ; tout le reste en est une projection.
3. **Un seul moteur de lecture (« PLAY »).** Le bouton de lecture orchestre la journée sur la
   ligne de temps ; il n'existe pas de lecteur séparé.
4. **AIME n'encaisse pas.** AIME prépare, sécurise et orchestre les paiements ; le prestataire de
   paiement exécute, l'utilisateur autorise, la ligne de temps trace.

---

## 2. Architecture actuelle (résumé écrit)

### Les espaces

| Espace | Rôle |
| --- | --- |
| **Accueil** (`/`) | Porte d'entrée unique de création : on raconte son projet, la ligne de temps se dessine, on entre dans le projet. |
| **Mon espace** (`/mon-espace`) | Seuil personnel : mes mondes, mes « Aimes » reçues, mes messages, mes crédits, ma page publique, mes réglages. |
| **Projet / Monde** (`/projets/$id`) | Le monde d'un projet : film d'en-tête, ligne de temps universelle, participants, paiements, facture, musique. |
| **Réseau** (`/reseau`) | Découverte de personnes et de prestataires. |
| **Bureau** (`/bureau/*`) | Espace d'administration interne — **périmètre gelé, hors analyse**. |
| **Démo** (`/demo/mariage`) | Mariage fictif déjà passé, consultable sans compte : préparatifs, devis, jour J lu heure par heure, souvenirs, remerciements. |

Autres pages publiques : `/guides` et `/guides/{métier}/{ville}` (contenu de référencement local),
`/carte/$id` (fiche publique d'une personne), `/evenements`, `/legal/{doc}`, `/messages`,
`/credits`, `/auth`.

### Chaîne source → transformation → affichage

```text
récit libre de l'utilisateur
      │  lecture (règles + IA)
      ▼
  PROJET (modèle unique : dates, lieu, invités, prestataires, engagements financiers)
      │  dérivation
      ▼
  LIGNE DE TEMPS (points, calques, relations, états)
      │  fenêtres
      ▼
  Tout / Avant / Pendant / Après  •  lecture PLAY  •  fiches au survol
```

Correspondances dans le code (pour information, pas à auditer ligne à ligne) :
`src/lib/aime/world/` (modèle de projet, lecture du récit, dérivation, finance, persistance),
`src/lib/aime/play/` (moteur de lecture unique), `src/components/aime/world/ProjectStage.tsx`
(la scène unique partagée par la démo et les projets réels), `HeroTimeline.tsx` (la ligne de temps).

### État du chantier

Une phase de nettoyage est en cours : une vingtaine d'anciennes pages ont été retirées, la
navigation a été ramenée à un en-tête unique, et les doubles portes de création ont été
supprimées. Le produit est donc en transition — signale-le si tu vois des restes.

---

## 3. Volet 1 — Clarté du parcours

Parcours cible : **accueil → récit → apparition de la ligne de temps → projet → Avant/Pendant/Après
→ modification → action**.

Réponds précisément à :

1. En arrivant sur l'accueil, un visiteur comprend-il en moins de 30 secondes ce que fait AIME ?
   Qu'est-ce qui manque, qu'est-ce qui parasite ?
2. Le champ de récit libre donne-t-il envie d'écrire ? La consigne est-elle assez explicite ?
3. Le moment où la ligne de temps se dessine est-il perçu comme la promesse tenue, ou passe-t-il
   inaperçu ?
4. Où sont les points de décrochage probables (avant l'inscription, à l'inscription, dans le projet) ?
5. La démonstration `/demo/mariage` convainc-elle ? Que faudrait-il y montrer en premier ?
6. Le vocabulaire (« monde », « Aime », « ligne de temps », « studio ») est-il compris ou faut-il
   des mots plus ordinaires ?

---

## 4. Volet 2 — Positionnement et marché

Fais de la recherche web et cite tes sources.

1. Qui sont les concurrents réels en France sur l'organisation de mariage et d'événements
   (outils de planification, places de marché de prestataires, applications d'invités) ?
   Positionnement, prix, promesse, points forts et faiblesses.
2. Sur quel axe AIME est-il réellement différenciant ? La ligne de temps vivante est-elle un
   argument compréhensible pour un couple, ou seulement pour un professionnel ?
3. Notre message public est-il aligné avec ce que les gens cherchent ? Propose 3 formulations
   alternatives de la promesse d'accueil.
4. Quelles requêtes de recherche (français) devrions-nous viser en priorité ? Volume approximatif,
   difficulté, et intention derrière chaque requête.
5. Le modèle générique « tout projet daté et collectif » est-il un atout ou une dilution du message
   au stade actuel ?

---

## 5. Volet 3 — Qualité technique et référencement

1. Cohérence de l'ensemble : y a-t-il des pages orphelines, des liens morts, des doublons de
   fonction, des restes de l'ancienne structure encore visibles ?
2. Titres, descriptions, structure des titres, données structurées, plan du site, images :
   qu'est-ce qui est correct, qu'est-ce qui manque ?
3. Performance perçue et affichage sur mobile (largeur 390 px) : où ça coince ?
4. Accessibilité : contrastes, cibles tactiles, navigation au clavier, textes alternatifs.
5. Les pages de guides locaux (`/guides/{métier}/{ville}`) apportent-elles une vraie valeur ou
   ressemblent-elles à du contenu généré en série ?

---

## 6. Règles de cadrage (importantes)

- **Ne propose pas de refonte totale.** Le socle — une intention, un monde, une ligne de temps —
  est acquis et ne se rediscute pas. Travaille dedans.
- **Ne touche pas au périmètre gelé** : l'espace `/bureau/*` et les règles de sécurité de la base
  ne font pas partie de l'analyse.
- **Sépare clairement les faits observés des hypothèses.** Si tu n'as pas pu vérifier, dis-le.
- **N'invente rien** : pas de chiffres de trafic, de témoignages ou de parts de marché sans source.
- **Classe chaque recommandation** par impact (fort / moyen / faible) et par effort
  (rapide / moyen / lourd).
- **Sois franc.** Si une décision est mauvaise, dis-le et explique pourquoi. Je ne cherche pas
  à être rassuré.

---

## 7. Format de réponse attendu

1. **Synthèse en dix lignes** — ce que tu retiens, en langage simple.
2. **Volet 1 — Parcours** (constats, puis recommandations).
3. **Volet 2 — Positionnement et marché** (avec sources).
4. **Volet 3 — Technique et référencement**.
5. **Liste d'actions priorisées** — tableau : action | volet | impact | effort | pourquoi.
6. **Les trois choses à ne surtout pas faire.**
