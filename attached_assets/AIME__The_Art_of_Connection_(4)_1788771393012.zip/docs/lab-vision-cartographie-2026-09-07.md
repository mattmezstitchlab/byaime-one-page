# LAB — Cartographie de la vision étendue (7 septembre 2026)

> Statut : le MVP décrit en §J est implémenté (7 septembre 2026).
> La cartographie reste valable pour les vagues suivantes.

> Deuxième étape d'audit, avant tout code. Répond aux questions A→J du brief
> « vision étendue ». La première audit (`lab-audit-2026-09-07.md`) reste
> valable pour le volet tables/structure ; celui-ci élargit au rôle de LAB
> comme surface universelle où tout AIME se réunit.
>
> Contraintes respectées : aucun code écrit, aucune migration, aucune
> suppression, aucune nouvelle architecture prématurée.

## Le principe directeur (validé par le code existant)

Le dépôt prouve déjà la règle « une source, plusieurs représentations » :
`WorldProject` est l'unique modèle, et la timeline, les capsules Avant/
Pendant/Après, PLAY, la radio… en sont des **projections** (`derive.ts`).
LAB n'est donc pas à inventer : c'est **une projection de plus**, éditable,
dont les objets ne stockent que de la géométrie et des **références**.
Le schéma central (§6 du brief) suit la même loi que la timeline :
`deriveStructure(project)` — jamais un deuxième monde.

---

## A. Les fonctionnalités existantes candidates à devenir modules LAB

| Candidat | Brique existante | Niveau | Note |
| --- | --- | --- | --- |
| Personne | `cards` + `CardPreview`/`CardIdentity` | **réutilisable tel quel** | un module personne = une référence `card_id` |
| Timeline | `HeroTimeline` (mode preview) + `deriveTimeline` | **tel quel** | posable sur la toile dès qu'un projet est compris |
| Documents | `media_items`, `bureau_documents` | **tel quel** | le module liste et ouvre, la logique métier ne bouge pas |
| Commentaire / post-it | table `comments` (target_type/target_id) | **tel quel** | `target_type = "lab_object"` |
| Calendrier | `MonthCalendar`, `calendar.ts` | **tel quel** | |
| Carte géographique | `CardsMap` (maplibre, chargé à la demande) | **à adapter** | un mode compact « mini-carte » posable |
| Playlist / musique | `musicbox_entries`, `MusicBox` | **à adapter** | scoper à une carte avant que le projet existe |
| Budget / argent | `ProjectMoneyStrip`, panneaux Argent, `quotes` | **à adapter** | dépend d'un `event` : lecture seule tant que le LAB n'est pas converti |
| Tâche / checklist | `TimelineKind "tache"`, `retroplanning.ts` | **à adapter** | les tâches vivent dans le WorldProject, le module les projette |
| Lieu | pages guides, `profile_geo`, `geo.ts` | **référence** | un lieu = un objet-lien vers la page existante |
| Objectif | table `objectives` (title, why, obstacles, due_on) | **à adapter** | existe déjà comme donnée première ! |
| Événement / rencontre | `events`, `rencontres` | **référence** | |
| Formulaire | `demande-profil`, `AimeButton` | **plus tard** | |
| Radio / PLAY | `RadioProvider`, play | **plus tard** | endergin d'expérience, pas brique de construction |

Verdict : **5 modules « tel quel » dès le MVP** (personne, timeline,
documents, commentaires, calendrier), 4 par adaptation simple, le reste en
seconde vague. Aucun module ne recrée de logique métier : chaque module lit
sa table et rend son composant existant.

## B. Briques réutilisables directement (sans adaptation)

- **Reconnaissance** : `readStoryAI` (server fn) + `readStory`/`agentParse`
  (récit → date, lieu, invités, budget, faits extensibles `details`).
- **Questions par Univers/Domaine** : `questionsFor`, packs A/B/C
  (`world/questions.ts`) — l'identification progressive du LAB.
- **Univers & Domaines** : `universeTree.ts`, `domains.ts` (12/73).
- **Étapes dérivées** : `blueprints.ts` + `derive.ts` (jamais hardcodées).
- **Persistance projet** : `persistValidatedProject` (« créer l'espace »).
- **L'agent architecte** : `buildRoadmap` (`roadmap.functions.ts`) produit
  déjà un plan `{objectif, contexte, étapes[], suite[]}` **ancré sur le
  catalogue réel des capacités** (`capabilities.ts`) — pas de texte libre.
- **Alertes & contradictions** : `timelineAutomation` connaît déjà
  `contradiction`, `retard`, `impact`, `prochaine_action` ; le moteur
  `causal.ts` (point zéro, ondes) **propose sans jamais décider**.
- **Conversation agent** : `chat.functions.ts` (modes suggestions, résumé,
  orchestration…), crédités via `ai_usage`.
- **Équipe** : `event_participants`, `event_invitations` (jeton e-mail),
  `search.ts` pour chercher une carte, helpers RLS `has_role`,
  `is_event_owner`, `can_view_event`.
- **Présentation** : panneaux `Sheet` + conventions `xxxSheet.ts`,
  animations `motion`, patterns pointeurs de `HeroTimeline` (drag).

## C. Briques à adapter (petits chantiers, pas des réécritures)

1. **La toile + palette** : le seul vrai code neuf — volontairement minimal
   (pointer events, aucun ajout de dépendance).
2. **Le sérialiseur toile → récit** (`labRecognition`) : ~100 lignes qui
   listent mots/tags/références d'un board en bref lisible par `readStoryAI`.
3. **Mini-carte** (`CardsMap` compact) et **modules avant-projet**
   (playlist scopée à une carte, argent en lecture anticipée).
4. **Le canal presence** : même API Supabase que postgres_changes, jamais
   encore utilisée — hook dédié `labRealtime`.
5. **`deriveStructure`** : la projection du schéma central (voir G).

## D. Structure minimale d'un objet LAB

```
lab_boards  : id, owner_id, event_id (nullable), title,
              universe_slug (nullable), created_at
lab_objects : id, board_id, type, x, y, w, h, z,
              data (jsonb), created_by, updated_at
lab_members : board_id, card_id, role_label
```

`type` au MVP : `mot` (tag libre) · `note` (post-it) · `texte` · `forme`
(rect/cercle/ligne) · `media` · `carte` (personne) · `etape` · `module`.
Le `data` ne contient **que** du texte brut, une catégorie proposée
(étiquette, réorganisable) et des **références par identifiant**
(`card_id`, `media_item_id`, `module: "timeline"`). La géométrie (x, y,
z…) est la seule vérité propre du LAB — tout le reste est référencé.
Les commentaires existent déjà (`comments` ciblant `lab_object`), les
relations entre objets réutilisent `timeline_relations`
(from_id/from_kind/to_id/to_kind/relation/note).

## E. Lien au World Model sans deuxième monde

Trois lois, déjà appliquées partout ailleurs dans AIME :

1. **Référence, jamais copie.** Un objet LAB pointe vers l'entité réelle
   (carte, média, moment). Supprimer l'objet n'efface rien ; l'entité
   affichée est toujours la donnée fraîche de sa table.
2. **La géométrie n'est pas une donnée métier.** x/y/z/la taille n'ont de
   sens que dans LAB ; elles ne quittent jamais `lab_objects`.
3. **L'ingestion reste validée.** Les mots/tags libres deviennent des
   `Fact`s du `WorldProject` (avec leur `Confidence`) uniquement via la
   validation humaine — mécanisme existant (`ingestToProject`,
   `mergeReading`). LAB est l'antichambre du projet, pas sa source.
   À la conversion, `persistValidatedProject` crée l'`event`, et le board
   passe `event_id` de null à l'identifiant créé : le LAB devient alors une
   vue de plus du projet, au même titre que sa timeline.

## F. Comment AIME analyse la toile et propose une structure

Pipeline entièrement composé de briques existantes — le seul code neuf est
le sérialiseur (C.2) :

```
lab_objects → labRecognition (sérialisation : mots, tags, références)
           → readStoryAI          → thèmes, dates, lieux, personnes, faits
           → questionsFor         → ce qui manque encore
           → catégorisation       → PERSONNES / LIEUX / TEMPS / RESSOURCES /
                                    OBJECTIFS / IDÉES… (étiquettes proposées,
                                    réorganisables par drag — AIME propose,
                                    l'humain valide)
           → buildRoadmap         → plan ancré sur les capacités réelles
           → causal + timelineAutomation → cohérence, contradictions, alertes
```

Chaque brique est un « proposeur » : la sortie atterrit dans un panneau de
lecture à côté de la toile, avec des boutons *Valider / Modifier / Écarter*.
Rien n'écrit dans le World Model sans validation (loi E.3), et le plan ne
cite que des capacités réelles du catalogue — l'agent architecte, jamais chef.

## G. Le schéma central

Même loi que la timeline : **une projection, pas un modèle**.
`deriveStructure(project)` déduit du `WorldProject` (et des relations
validées) des nœuds — objectif, personnes, lieux, ressources, étapes — et
des liens, puis un rendu SVG calme et déplaçable :

- déplacer un nœud = écrire une **préférence de disposition** (géométrie,
  loi E.2) ;
- relier deux nœuds = écrire une `timeline_relation` (brique existante) ;
- le même moteur sert le schéma du LAB et, demain, toute « vue structure »
   d'un projet — il n'existe pas « un schéma LAB » à part.

Aucune timeline imposée : la structure est l'arbre vivant du projet reconnu,
du plus flou (des mots) au plus ferme (des étapes validées).

## H. Capacités temps réel déjà là

- **Côté serveur** : la publication `supabase_realtime` existe et diffuse
  déjà (`musicbox_entries`, `site_events` — migrations datées).
- **Côté client** : le pattern est en production dans `RepairBadge` :
  `supabase.channel(...).on("postgres_changes", ...)` → rechargement.
  Aucune infrastructure à créer : ajouter `lab_objects`/`lab_boards` à la
  publication est une ligne de migration.
- **Phasage** : ① modifications visibles par tous (postgres_changes) ;
  ② présence de la colonne Équipe (même API channel, mode presence) ;
  ③ sélections et curseurs partagés — plus tard.

## I. Systèmes réutilisables (utilisateurs, invitations, documents, commentaires)

| Besoin | Brique | État |
| --- | --- | --- |
| Comptes / identités | Supabase Auth + `profiles` + `cards` | tel quel |
| Inviter par e-mail | `event_invitations` (jeton, rôle, statut) + UI existante | tel quel |
| Membres / rôles | `lab_members` (miroir minimal d'`event_participants`) + RLS `has_role` | à créer (minimal) |
| Documents / fichiers | `media_items` + storage (`uploadMediaFile`) | tel quel |
| Documents bureau | `bureau_documents` | lecture |
| Commentaires | `comments` (générique) | tel quel |
| Notifications | `notifications` (actor, target, url) | tel quel |
| Permissions | politiques RLS existantes + `can_view_event` à la conversion | à étendre légèrement |

## J. Le plus petit MVP qui donne la sensation

« Nous construisons ensemble une application autour de notre projet »
s'obtient avec ceci (ordre de construction) :

1. **Toile** blanche pleine, calme, pan/zoom — page `/lab`.
2. **Palette discrète** : mot, note, texte, forme, image, document, personne.
3. **Drag & drop** des objets (pointeurs, sauvegarde `lab_objects`).
4. **Nuage de mots** : chacun pose ses mots libres.
5. **Colonne Équipe** : membres + « + Inviter » (briques I).
6. **Lecture d'AIME** : `labRecognition → readStoryAI → catégorisation
   proposée` — les mots se rangent en catégories **validables**, le
   projet est identifié (Univers + Domaine).
7. **Schéma central** : `deriveStructure` sur ce qui est validé.
8. **Plan proposé** : `buildRoadmap` ancré sur les capacités réelles.
9. **3 modules réels posables** : timeline du projet reconnu, personnes
   (cartes), documents.
10. **« Créer l'espace »** : conversion via `persistValidatedProject` →
    l'équipe atterrit dans le projet AIME existant, le board y reste
    rattaché comme surface de travail.
11. **Temps réel niveau ①** : une ligne de publication + le pattern
    `RepairBadge`.

Rien de plus : pas de curseurs, pas de mini-app paramétrable, pas de
règles — la boucle *humains → matière → compréhension → proposition →
validation → projet* est déjà, à elle seule, la démonstration.

## Risques surveillés

- La toile est le seul code neuf : la garder sous ~600 lignes, pointer
  events purs, zéro dépendance ajoutée.
- Ne jamais laisser un module copier une donnée (loi E.1) — revue systématique.
- La catégorisation automatique doit rester une **étiquette réorganisable**,
  jamais un déplacement automatique des objets d'autrui (§5 : l'agent
  n'est pas le chef).
- `lab_members` doit disparaître conceptuellement à la conversion
  (rôles repris par `event_participants`) pour éviter un double système.
