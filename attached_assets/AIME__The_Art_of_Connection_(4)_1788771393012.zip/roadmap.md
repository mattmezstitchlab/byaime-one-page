# Feuille de route AIME

## Étape A — Nettoyage (fait)
- [x] Plan du système retiré de l'accueil (et son générateur)
- [x] Réglages : blocs morts retirés, liens « Corriger » ouvrent le panneau Mon espace
- [x] Fichiers jamais utilisés supprimés (exploration, boussole, bande de fréquence, écrans bureau résiduels, outils orphelins)
- [x] Lien d'invitation documents obsolète supprimé
- [ ] Décider du sort des 5 anciennes adresses redirigées (projets musicbox/paiements/participants/facture, evenement)

## Étape B — Socle social (fait)
- [x] Suivre / relations
- [x] Réactions et commentaires (page, média, moment)
- [x] Notifications persistantes + centre de notifications dans Mon espace
- [ ] Réactions/commentaires aussi sous chaque média et chaque moment de la ligne de temps

## Étape C — Fil d'actualité (fait)
- [x] Publier un moment court (texte + photo) depuis mes pages
- [x] Fil des personnes suivies + onglet Découvrir
- [ ] Chargement progressif au défilement

## Étape C bis — Première inscription sur téléphone (fait)
- [x] Page créée dès l'inscription (`ensureMyCard`) + écran `/bienvenue`
- [x] Message clair si la confirmation par e-mail est demandée
- [x] En-tête adapté au téléphone (radio, profil, carte du réseau rangés dans le menu AIME, boutons 44 px)
- [ ] Vérifier la connexion Google depuis l'adresse publique
- [ ] Essai réel de bout en bout depuis un téléphone

## Étape D — Découverte
- [x] Recherche globale
- [ ] Groupes / pages collectives
- [ ] Événements publics avec participation

## Étape E — Confiance
- [ ] Encaissement réel
- [x] Confidentialité héritée pour les interactions sociales
- [x] Signalement et blocage minimal
- [x] File complète de traitement modérateur
- [x] Blocage propagé immédiatement au fil, aux publications et aux notifications visibles

## Étape F — Réseau social public
- [x] Notifications sociales vérifiées et liens internes sûrs
- [x] Notification des abonnés lors d'un nouveau moment
- [x] Publication indépendante de la livraison des notifications secondaires
- [x] Abonnés / abonnements visibles
- [x] Suggestions de pages à suivre dans le fil
- [ ] Édition et réponses aux commentaires
- [ ] Temps réel social et tests pilote multi-comptes

## Étape C ter — Retouches mobile & carte
- [x] Google Search Console : site vérifié, propriété ajoutée, sitemap soumis
- [x] Page « Organiser un mariage » (/organiser-un-mariage)
- [x] Hero page publique : cœur central plus discret sur téléphone
- [x] Capsule temporelle moins encombrante sur téléphone
- [x] Grille des médias visible sous la ligne de temps
- [x] Carte du réseau : clic sur un cercle chiffré → zoom sur les pins
- [x] Page publique : commandes regroupées sous la ligne de temps, visuel libéré

## Étape C quater — Commandes mobiles compactes
- [x] Carte : toucher/clic d’un cercle chiffré zoome sans ouvrir la liste
- [x] Carte : recherche, actions, filtres actifs et sélection occupent moins d’espace
- [x] Échanges/Documents : commandes compactes et stables
- [x] Mon espace : confirmations et actions de page allégées
- [x] Invitations et entrées publiques : séries de boutons simplifiées
- [x] Vérification des pages, du débordement horizontal et des libellés accessibles

## Étape C quinquies — Unification des commandes
- [x] Démo Mariage : panneaux compacts communs, en lecture seule
- [x] Projets : même barre de panneaux compacte et défilable sur téléphone
- [x] En-tête mobile : Documents et Mon espace réunis dans une commande personnelle
- [x] Carte : localisation intégrée à la recherche et sélection adaptée aux titres longs
- [x] Crédits : formulaires de retrait et contribution empilés sur téléphone

## Étape D — Finalisation mobile
- [x] Toutes les commandes tactiles ≥ 44 px (menu, retour, footer, crédits, guides, mariage, carte, cookies, calques)
- [x] Zoom de la carte au doigt
- [x] Application installable sur l'écran d'accueil (manifeste, icônes, couleur de thème)
- [x] Icône AIME et pages d'erreur/404 en français
- [ ] Listes abonnés / abonnements
- [ ] Réponses aux commentaires et modification des moments
- [ ] Défilement infini du fil et temps réel
- [x] Recherche globale (personnes, lieux, projets, moments) — /recherche
- [ ] Encaissement réel de bout en bout

## Rencontres — se rencontrer parce que des chemins se croisent
- [x] Choix personnels : visibilité, intentions, rayon, qui peut me contacter, position facultative
- [x] Convergences expliquées (passé / présent / futur), sans tri opaque
- [x] Carte des convergences avec « moi » au centre
- [x] Signaux non binaires : dire bonjour, garder, suivre, proposer une rencontre
- [x] Découvrir avant de contacter (/rencontres/$id), bloquer et signaler
- [ ] Événements et projets comme lieux de rencontre (encarts dédiés)
- [ ] Phrase hebdomadaire à la Radio, jamais intrusive
- [ ] Rencontre acceptée → moment inscrit sur la ligne de temps après double accord

## Mémoire & Héritage
- [x] Onglet Origines sur la page personne (arbre, naissance, pistes, questions ouvertes)
- [ ] Héritage : ce qui se transmet (média, lettre, voix, œuvre, lieu)
- [ ] Croiser les origines avec la ligne de temps et Rencontres
- [ ] Fusion de doublons de personnes
