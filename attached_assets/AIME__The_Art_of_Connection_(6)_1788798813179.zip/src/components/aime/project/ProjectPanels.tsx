import { useMemo, useState } from "react";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  CalendarClock,
  CheckCircle2,
  Copy,
  FolderOpen,
  Mail,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Printer,
  Radar,
  Trash2,
  Users,
  WalletCards,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  allRatesQuery,
  cardsQuery,
  eventQuery,
  invitationsQuery,
  paymentsQuery,
  profileQuery,
  threadsQuery,
} from "@/lib/aime/queries";
import { openDocuments, openMessages } from "@/components/aime/messagesSheet";
import { PARTICIPANT_STATUS_LABEL, formatDateTime } from "@/lib/aime/calendar";

import { formatPrice, rateForDate, type Rate } from "@/lib/aime/pricing";
import { causalityFor, type CausalLink } from "@/lib/aime/causal";
import { acceptWave } from "@/lib/aime/causalImpacts";
import { auditTimeline, type AuditItem } from "@/lib/aime/timelineAudit";
import { deriveTimeline } from "@/lib/aime/world/derive";
import { projectFromEvent } from "@/lib/aime/world/projectFromEvent";
import { loadProjectWorld } from "@/lib/aime/world/projectPersistence";
import type { WorldProject } from "@/lib/aime/world/types";
import CausalPanel from "@/components/aime/CausalPanel";
import WeatherPanel from "@/components/aime/WeatherPanel";
import FolderTemplates from "@/components/bureau/FolderTemplates";
import { MusicBox } from "@/components/aime/MusicBox";
import { BureauPanel } from "@/components/bureau/BureauPanel";
import { ProjectSources } from "@/components/aime/sources/ProjectSources";
import { RadioPanel } from "@/components/aime/panels/RadioPanel";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Z } from "@/lib/aime/layers";
import { useDockHostPresent, useRegisterDockMenu } from "@/components/aime/dockPresence";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/**
 * Cinq portes, pas neuf boutons. Chaque porte réunit ce qui appartenait
 * autrefois à plusieurs sous-pages : même source, même page, un seul tiroir.
 */
export type ProjectPanelKey = "personnes" | "argent" | "documents" | "jourj" | "veille";

export const PROJECT_PANEL_KEYS: ProjectPanelKey[] = [
  "personnes",
  "argent",
  "documents",
  "jourj",
  "veille",
];

/** Les tuiles qui ouvrent le panneau commun des Échanges plutôt qu'un tiroir à part. */
export type TileKey = ProjectPanelKey | "echanges";

export const PROJECT_PANEL_LABEL: Record<TileKey, string> = {
  personnes: "Personnes",
  argent: "Argent",
  documents: "Documents",
  echanges: "Échanges",
  jourj: "Le jour J",
  veille: "Veille",
};

export const PROJECT_PANEL_HINT: Record<TileKey, string> = {
  personnes: "Invités, prestataires, rôles",
  argent: "Devis, paiements, factures",
  documents: "Pièces et dossiers du projet",
  echanges: "La discussion du projet",
  jourj: "Déroulé, musique, météo",
  veille: "Ce qui bouge et ce qui suivra",
};

const PROJECT_PANEL_ICON = {
  personnes: Users,
  argent: WalletCards,
  documents: FolderOpen,
  echanges: MessageCircle,
  jourj: CalendarClock,
  veille: Radar,
} satisfies Record<TileKey, typeof Users>;

/** La barre de panneaux et le tiroir, pilotés par l'URL du projet. */
export function ProjectPanelDock({ id }: { id: string }) {
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { data: threads = [] } = useQuery(threadsQuery(userId));
  const search = useSearch({ from: "/projets/$id/" }) as { panneau?: ProjectPanelKey };
  const open = search.panneau === "documents" ? undefined : search.panneau;
  const setPanel = (panneau: ProjectPanelKey | undefined) =>
    void navigate({ to: "/projets/$id", params: { id }, search: panneau ? { panneau } : {} });

  /** Documents et Échanges vivent dans le panneau commun : une seule porte. */
  const pick = (key: TileKey) => {
    if (key === "documents") {
      openDocuments(id);
      return;
    }
    if (key === "echanges") {
      const thread = threads.find((t) => t.event_id === id);
      if (thread) openMessages(thread.id, "discussions");
      else openMessages(undefined, "discussions");
      return;
    }
    setPanel(key);
  };

  return (
    <>
      <PanelBar current={open} onPick={pick} keys={[...PROJECT_PANEL_KEYS, "echanges"]} />
      <Sheet open={!!open} onOpenChange={(v) => !v && setPanel(undefined)}>
        <SheetContent side="right" className="w-full overflow-y-auto p-0 sm:max-w-2xl">
          <SheetHeader className="sticky top-0 z-10 border-b border-hairline bg-background px-5 py-4 text-left">
            <SheetTitle className="pr-8 text-[18px]">
              {open ? PROJECT_PANEL_LABEL[open] : ""}
            </SheetTitle>
          </SheetHeader>
          <div className="px-5 py-6">{open && <ProjectPanel id={id} panel={open} />}</div>
        </SheetContent>
      </Sheet>
    </>
  );
}

/**
 * La même barre partout — projet réel, démo, page personne — et au même
 * endroit : posée en bas de l'écran, sur téléphone comme sur ordinateur.
 * Une seule ligne, jamais de défilement horizontal : le mot s'efface avant
 * la porte.
 */
export function PanelBar({
  current,
  onPick,
  keys = PROJECT_PANEL_KEYS,
}: {
  current: TileKey | undefined;
  onPick: (key: never) => void;
  keys?: TileKey[];
}) {
  const choose = onPick as (key: TileKey) => void;
  const host = useDockHostPresent();

  useRegisterDockMenu({
    label: "Projet",
    items: keys.map((key) => ({
      key,
      label: PROJECT_PANEL_LABEL[key],
      hint: PROJECT_PANEL_HINT[key],
      icon: PROJECT_PANEL_ICON[key],
      active: current === key,
    })),
    onPick: (key) => choose(key as TileKey),
  });

  /** Dans la démo (téléphone de l'accueil) il n'y a pas de barre commune : on pose la nôtre. */
  if (host) return null;

  return (
    <div
      className={`fixed inset-x-0 bottom-0 ${Z.dock} border-t border-hairline bg-background/95 backdrop-blur-xl`}
    >
      <div
        className="mx-auto flex w-full max-w-3xl items-center gap-1 px-2 py-1.5"
        style={{ paddingBottom: "max(0.375rem, env(safe-area-inset-bottom))" }}
      >
        {keys.map((key) => {
          const Icon = PROJECT_PANEL_ICON[key];
          return (
            <Button
              key={key}
              type="button"
              variant={current === key ? "default" : "ghost"}
              onClick={() => choose(key)}
              aria-label={`${PROJECT_PANEL_LABEL[key]} — ${PROJECT_PANEL_HINT[key]}`}
              title={PROJECT_PANEL_HINT[key]}
              className="h-11 min-w-0 flex-1 px-0"
            >
              <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
              <span className="sr-only">{PROJECT_PANEL_LABEL[key]}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}

function Divider({ title }: { title: string }) {
  return (
    <p className="mb-3 mt-10 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
      {title}
    </p>
  );
}

export function ProjectPanel({ id, panel }: { id: string; panel: ProjectPanelKey }) {
  if (panel === "personnes") return <ParticipantsPanel id={id} />;
  if (panel === "argent")
    return (
      <div>
        <PaymentsPanel id={id} />
        <Divider title="Facture" />
        <InvoicePanel id={id} />
      </div>
    );
  if (panel === "documents")
    return (
      <div>
        <BureauPanel eventId={id} />
        <Divider title="Sources" />
        <SourcesPanel id={id} />
        <Divider title="Ouvrir un dossier" />
        <DossiersPanel id={id} />
      </div>
    );
  if (panel === "veille") return <VeillePanel id={id} />;
  return (
    <div>
      <MeteoPanel id={id} />
      <Divider title="Programmation" />
      <MusicPanel id={id} />
    </div>
  );
}

/** Les sources du projet : documents et liens rattachés, sans stockage parallèle. */
function SourcesPanel({ id }: { id: string }) {
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const isOwner = !!userId && event?.owner_id === userId;
  return <ProjectSources eventId={id} userId={userId} canEdit={isOwner} />;
}

/**
 * La veille : d'abord l'état réel de la ligne de temps (moteur `auditTimeline`),
 * puis ce qui pourrait la déplacer (causalité). Les données viennent du cache
 * déjà chargé par la page projet : aucune requête supplémentaire.
 */
function VeillePanel({ id }: { id: string }) {
  return (
    <div>
      <TimelineAuditPanel id={id} />
      <Divider title="Ce qui pourrait bouger" />
      <CausalitePanel id={id} />
    </div>
  );
}

const AUDIT_DOT: Record<0 | 1 | 2, string> = {
  2: "bg-red-500",
  1: "bg-amber-500",
  0: "bg-muted-foreground/40",
};

function AuditList({
  title,
  empty,
  items,
  onPick,
}: {
  title: string;
  empty: string;
  items: AuditItem[];
  /** Revenir à la ligne de temps, seule vue qui porte ces moments. */
  onPick: () => void;
}) {
  return (
    <section className="mt-6">
      <div className="flex items-baseline justify-between gap-3">
        <h3 className="text-[15px] font-semibold">{title}</h3>
        <span className="rounded-full bg-muted px-2.5 py-1 text-[11px]">{items.length}</span>
      </div>
      {items.length === 0 ? (
        <p className="mt-2 text-[13.5px] text-muted-foreground">{empty}</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={onPick}
                className="flex w-full items-start gap-2.5 rounded-2xl hairline bg-card p-3 text-left transition-colors hover:bg-muted"
              >
                <span
                  aria-hidden
                  className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", AUDIT_DOT[item.severity])}
                />
                <span className="min-w-0 flex-1">
                  <span className="block text-[14px] font-medium">{item.label}</span>
                  {(item.detail || item.time) && (
                    <span className="mt-0.5 block text-[12.5px] text-muted-foreground">
                      {[
                        item.detail,
                        item.time
                          ? new Date(item.time).toLocaleDateString("fr-FR", {
                              day: "numeric",
                              month: "long",
                              year: "numeric",
                              timeZone: "Europe/Paris",
                            })
                          : null,
                      ]
                        .filter(Boolean)
                        .join(" · ")}
                    </span>
                  )}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

/** « Que dois-je faire ? Qu'est-ce qui manque ? Qu'est-ce qui est en retard ? » */
function TimelineAuditPanel({ id }: { id: string }) {
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const { data: payments = [] } = useQuery(paymentsQuery(id));
  const { data: quotes = [] } = useQuery({
    queryKey: ["project-quotes", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("quotes").select("*").eq("event_id", id);
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: tracks = [] } = useQuery({
    queryKey: ["project-tracks", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("musicbox_entries")
        .select("*")
        .eq("event_id", id)
        .order("day");
      if (error) throw error;
      return data ?? [];
    },
  });

  /* Mêmes clés que la page projet :la réponse vient du cache, pas du réseau. */
  const { data: remoteProject } = useQuery({
    queryKey: ["project-world", id, userId],
    queryFn: async () => loadProjectWorld(event ?? null, { payments, quotes, tracks }),
    enabled: !!event,
  });

  const project: WorldProject | null =
    remoteProject ?? (event ? projectFromEvent(event, { payments, quotes, tracks }) : null);

  const audit = useMemo(() => (project ? auditTimeline(deriveTimeline(project)) : null), [project]);

  /**
   * Il n'existe pas encore d'ancre par moment sur la ligne de temps : plutôt
   * qu'un lien qui ne résoudrait rien, on referme la veille et on rend la main
   * à la ligne de temps du projet, seule vue qui porte ces moments.
   */
  const backToTimeline = () => {
    void navigate({ to: "/projets/$id", params: { id }, search: {} });
  };

  if (!audit)
    return <p className="text-[14px] text-muted-foreground">Chargement de la ligne de temps…</p>;

  const money = audit.money;
  const euro = (v: number) =>
    v.toLocaleString("fr-FR", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });

  return (
    <div>
      <p className="text-[15px] leading-relaxed">
        Ce que dit votre ligne de temps aujourd'hui : ce qui vous attend, ce qui manque, ce qui
        cloche. Rien n'est calculé ailleurs que sur vos propres moments.
      </p>

      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {[
          { label: "Prévu", value: money.prevu },
          { label: "Engagé", value: money.engage },
          { label: "Facturé", value: money.facture },
          { label: "Payé", value: money.paye },
          { label: "Reste à payer", value: money.restant },
          { label: "En retard", value: money.retard },
        ].map((cell) => (
          <div key={cell.label} className="rounded-2xl hairline bg-card p-3">
            <p className="text-[11px] tracking-[0.14em] text-muted-foreground uppercase">
              {cell.label}
            </p>
            <p
              className={cn(
                "mt-1 text-[16px] font-semibold",
                cell.label === "En retard" && cell.value > 0 && "text-red-600",
              )}
            >
              {euro(cell.value)}
            </p>
          </div>
        ))}
      </div>

      <AuditList
        title="Que dois-je faire ?"
        empty="Rien ne vous attend pour l'instant."
        items={audit.todo}
        onPick={backToTimeline}
      />
      <AuditList
        title="Qu'est-ce qui manque ?"
        empty="Aucune chaîne incomplète repérée."
        items={audit.missing}
        onPick={backToTimeline}
      />
      <AuditList
        title="Qu'est-ce qui cloche ?"
        empty="Aucune anomalie repérée."
        items={audit.anomalies}
        onPick={backToTimeline}
      />
    </div>
  );
}

/** Ce qui bouge, et ce qui bougera ensuite. */
function CausalitePanel({ id }: { id: string }) {
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const { data: cards = [] } = useQuery(cardsQuery);
  const isOwner = !!userId && event?.owner_id === userId;
  const myCard = cards.find((c) => c.owner_id === userId);

  const accept = useMutation({
    mutationFn: async ({ variable, wave }: { variable: string; wave: CausalLink }) => {
      if (!myCard) throw new Error("Créez d'abord votre carte pour inscrire une onde.");
      await acceptWave({
        cardId: myCard.id,
        eventId: event?.id ?? null,
        variable,
        wave,
        startsAt: event?.starts_at ?? new Date().toISOString(),
      });
    },
    onSuccess: () => toast("Impact inscrit dans votre ligne de temps"),
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div>
      <p className="text-[15px] leading-relaxed">
        La veille surveille ce qui peut déplacer votre projet, avant que ça n'arrive.
      </p>
      <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">
        Exemple : la salle repousse une visite, et la veille vous montre tout de suite ce que cela
        décale ensuite — le devis du traiteur, l'envoi des invitations, le paiement d'acompte.
        Chaque conséquence peut être inscrite dans votre ligne de temps d'un seul geste ; rien ne
        s'ajoute tout seul.
      </p>

      <div className="mt-6">
        <CausalPanel
          universeSlug={event?.universe_slug}
          roleSlug={isOwner ? "organisateur" : "participant"}
          onAccept={isOwner ? (variable, wave) => accept.mutate({ variable, wave }) : undefined}
        />
      </div>
    </div>
  );
}

function MeteoPanel({ id }: { id: string }) {
  const { data: event } = useQuery(eventQuery(id));
  return (
    <div>
      <p className="text-[15px] leading-relaxed text-muted-foreground">
        Ce que dit le ciel à cette date et à cet endroit, et ce qu'on prépare au cas où.
      </p>
      <div className="mt-6">
        <WeatherPanel city={event?.city ?? event?.location} startsAt={event?.starts_at} />
      </div>
    </div>
  );
}

function DossiersPanel({ id }: { id: string }) {
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  return (
    <div>
      <p className="text-[15px] leading-relaxed text-muted-foreground">
        Ouvrez un dossier vivant déjà structuré selon le rôle et le métier.
      </p>
      <div className="mt-6">
        <FolderTemplates
          ownerId={userId ?? null}
          universeSlug={event?.universe_slug}
          eventId={event?.id ?? null}
          defaultTitle={event?.title}
        />
      </div>
    </div>
  );
}

function ParticipantsPanel({ id }: { id: string }) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const { data: invitations = [] } = useQuery(invitationsQuery(id));
  const { data: cards = [] } = useQuery(cardsQuery);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("Invité");

  const isOwner = !!userId && event?.owner_id === userId;
  const cardById = new Map(cards.map((c) => [c.id, c]));
  const roleOptions: string[] = [
    ...causalityFor(event?.universe_slug).roles.map((r) => r.label),
    "Invité",
  ].filter((v, i, a) => a.indexOf(v) === i);

  const invite = useMutation({
    mutationFn: async () => {
      if (!email.includes("@")) throw new Error("Adresse e-mail invalide.");
      const { error } = await supabase.from("event_invitations").insert({
        event_id: id,
        email: email.trim().toLowerCase(),
        name: name.trim() || null,
        role_label: role.trim() || "Invité",
        sent_at: new Date().toISOString(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setEmail("");
      setName("");
      qc.invalidateQueries({ queryKey: ["event-invitations", id] });
      toast("Invitation créée — partagez le lien");
    },
    onError: (e: Error) => toast(e.message),
  });

  const setInvitationStatus = useMutation({
    mutationFn: async ({ inviteId, status }: { inviteId: string; status: string }) => {
      const { error } = await supabase
        .from("event_invitations")
        .update({ status, responded_at: new Date().toISOString() })
        .eq("id", inviteId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["event-invitations", id] }),
    onError: (e: Error) => toast(e.message),
  });

  const removeInvitation = useMutation({
    mutationFn: async (inviteId: string) => {
      const { error } = await supabase.from("event_invitations").delete().eq("id", inviteId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["event-invitations", id] }),
    onError: (e: Error) => toast(e.message),
  });

  const setParticipantStatus = useMutation({
    mutationFn: async ({ pid, status }: { pid: string; status: string }) => {
      const { error } = await supabase.from("event_participants").update({ status }).eq("id", pid);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["event", id] });
      qc.invalidateQueries({ queryKey: ["events"] });
    },
    onError: (e: Error) => toast(e.message),
  });

  const participants = event?.event_participants ?? [];

  return (
    <div>
      <section>
        <p className="eyebrow mb-3">Cartes engagées</p>
        <ul className="space-y-2">
          {participants.map((p) => (
            <li
              key={p.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
            >
              <span>
                {cardById.get(p.card_id)?.name ?? "Carte"}
                <span className="text-muted-foreground"> · {p.role_label}</span>
              </span>
              <span className="flex gap-1.5">
                {(["invite", "confirme", "decline"] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    disabled={!isOwner}
                    onClick={() => setParticipantStatus.mutate({ pid: p.id, status: s })}
                    className={cn(
                      "rounded-full px-3 py-1 text-[12px] transition-colors",
                      p.status === s
                        ? "bg-primary text-primary-foreground"
                        : "hairline bg-background text-muted-foreground",
                    )}
                  >
                    {PARTICIPANT_STATUS_LABEL[s]}
                  </button>
                ))}
              </span>
            </li>
          ))}
          {participants.length === 0 && (
            <p className="text-[15px] text-muted-foreground">Aucune carte engagée.</p>
          )}
        </ul>
      </section>

      {isOwner && (
        <section className="mt-8 rounded-3xl hairline bg-card p-5 shadow-soft">
          <p className="eyebrow mb-3">Inviter par e-mail</p>
          <div className="grid gap-3 sm:grid-cols-3">
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@exemple.fr"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nom"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            >
              {roleOptions.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <button
            type="button"
            disabled={invite.isPending}
            onClick={() => invite.mutate()}
            className="mt-3 inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-50"
          >
            <Mail className="h-4 w-4" strokeWidth={1.75} />
            Créer l'invitation
          </button>
        </section>
      )}

      <section className="mt-8">
        <p className="eyebrow mb-3">Invitations</p>
        {invitations.length === 0 ? (
          <p className="text-[15px] text-muted-foreground">Aucune invitation envoyée.</p>
        ) : (
          <ul className="space-y-2">
            {invitations.map((iv) => (
              <li
                key={iv.id}
                className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-2 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
              >
                <span className="min-w-0 truncate">
                  {iv.name ?? iv.email}
                  <span className="text-muted-foreground"> · {iv.role_label}</span>
                </span>
                <select
                  value={iv.status}
                  onChange={(e) =>
                    setInvitationStatus.mutate({
                      inviteId: iv.id,
                      status: e.target.value as "envoyee" | "confirmee" | "declinee",
                    })
                  }
                  aria-label={`État de l’invitation de ${iv.name ?? iv.email}`}
                  className="max-w-28 rounded-full hairline bg-background px-2.5 py-1 text-[12px]"
                >
                  <option value="envoyee">Envoyée</option>
                  <option value="confirmee">Confirmée</option>
                  <option value="declinee">Déclinée</option>
                </select>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      type="button"
                      aria-label={`Actions pour ${iv.name ?? iv.email}`}
                      title="Plus d’actions"
                      className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Invitation</DropdownMenuLabel>
                    <DropdownMenuItem
                      onSelect={() => {
                        const url = `${window.location.origin}/invitation?token=${iv.token}`;
                        void navigator.clipboard.writeText(url);
                        toast("Lien copié");
                      }}
                    >
                      <Copy /> Copier le lien
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onSelect={() => removeInvitation.mutate(iv.id)}
                      className="text-destructive focus:text-destructive"
                    >
                      <Trash2 /> Supprimer
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function PaymentsPanel({ id }: { id: string }) {
  const qc = useQueryClient();
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const { data: payments = [] } = useQuery(paymentsQuery(id));
  const { data: cards = [] } = useQuery(cardsQuery);

  const participants = useMemo(() => event?.event_participants ?? [], [event]);
  const cardIds = participants.map((p) => p.card_id);
  const { data: rates = [] } = useQuery(allRatesQuery(cardIds));

  const isOwner = !!userId && event?.owner_id === userId;
  const cardById = new Map(cards.map((c) => [c.id, c]));
  const eventDate = event ? new Date(event.starts_at) : null;

  const [payer, setPayer] = useState("");
  const [share, setShare] = useState("");

  const services = participants.map((p) => {
    const rate = rateForDate(
      (rates as Rate[]).filter((r) => r.card_id === p.card_id),
      eventDate,
    );
    return {
      participantId: p.id,
      cardId: p.card_id,
      name: cardById.get(p.card_id)?.name ?? "Carte",
      role: p.role_label,
      price: rate?.price ?? 0,
      label: rate?.label ?? "Sur devis",
      confirmed: p.status === "confirme",
    };
  });

  const total = services.reduce((s, x) => s + x.price, 0);
  const collected = payments.reduce((s, p) => s + p.amount_paid, 0);
  const due = payments.reduce((s, p) => s + p.amount_due, 0);

  const addPayer = useMutation({
    mutationFn: async () => {
      const amount = Number.parseInt(share, 10);
      if (!payer.trim()) throw new Error("Indiquez un nom.");
      const { error } = await supabase.from("event_payments").insert({
        event_id: id,
        payer_name: payer.trim(),
        label: "Part participant",
        amount_due: Number.isFinite(amount) ? amount : 0,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setPayer("");
      setShare("");
      qc.invalidateQueries({ queryKey: ["event-payments", id] });
      toast("Part ajoutée");
    },
    onError: (e: Error) => toast(e.message),
  });

  const splitEvenly = useMutation({
    mutationFn: async () => {
      if (payments.length === 0) throw new Error("Ajoutez d'abord des participants payeurs.");
      const part = Math.round(total / payments.length);
      for (const p of payments) {
        const { error } = await supabase
          .from("event_payments")
          .update({ amount_due: part })
          .eq("id", p.id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["event-payments", id] });
      toast("Total réparti à parts égales");
    },
    onError: (e: Error) => toast(e.message),
  });

  const markPaid = useMutation({
    mutationFn: async (paymentId: string) => {
      const p = payments.find((x) => x.id === paymentId);
      if (!p) return;
      const { error } = await supabase
        .from("event_payments")
        .update({
          amount_paid: p.amount_due,
          status: "paye",
          paid_at: new Date().toISOString(),
        })
        .eq("id", paymentId);
      if (error) throw error;

      const rest = payments.filter((x) => x.id !== paymentId);
      const allPaid = rest.every((x) => x.amount_paid >= x.amount_due);
      if (allPaid) {
        await supabase.from("event_participants").update({ status: "confirme" }).eq("event_id", id);
        await supabase.from("events").update({ status: "confirme" }).eq("id", id);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["event-payments", id] });
      qc.invalidateQueries({ queryKey: ["event", id] });
      qc.invalidateQueries({ queryKey: ["events"] });
      toast("Paiement enregistré");
    },
    onError: (e: Error) => toast(e.message),
  });

  const removePayment = useMutation({
    mutationFn: async (paymentId: string) => {
      const { error } = await supabase.from("event_payments").delete().eq("id", paymentId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["event-payments", id] }),
    onError: (e: Error) => toast(e.message),
  });

  return (
    <div>
      <section>
        <p className="eyebrow mb-3">Total par service</p>
        <ul className="space-y-2">
          {services.map((s) => (
            <li
              key={s.participantId}
              className="flex flex-wrap items-center justify-between gap-2 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
            >
              <span>
                {s.name}
                <span className="text-muted-foreground">
                  {" · "}
                  {s.role} · {s.label}
                </span>
              </span>
              <span className="flex items-center gap-3">
                {s.confirmed && (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" strokeWidth={1.75} />
                )}
                <Link
                  to="/carte/$id"
                  params={{ id: s.cardId }}
                  search={{ onglet: "devis" as const }}
                  className="text-[12px] underline underline-offset-4"
                >
                  Devis
                </Link>
                <span className="font-medium">
                  {s.price > 0 ? formatPrice(s.price) : "Sur devis"}
                </span>
              </span>
            </li>
          ))}
          {services.length === 0 && (
            <p className="text-[15px] text-muted-foreground">Aucun service engagé.</p>
          )}
        </ul>
        <p className="mt-4 text-[22px] font-semibold tracking-[-0.03em]">
          Total {formatPrice(total)}
          <span className="ml-2 text-[13px] font-normal text-muted-foreground">
            · {formatPrice(collected)} réglés sur {formatPrice(due)} répartis
          </span>
        </p>
      </section>

      {isOwner && (
        <section className="mt-8 rounded-3xl hairline bg-card p-5 shadow-soft">
          <p className="eyebrow mb-3">Ajouter un participant payeur</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <input
              value={payer}
              onChange={(e) => setPayer(e.target.value)}
              placeholder="Nom du participant"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
            <input
              value={share}
              onChange={(e) => setShare(e.target.value)}
              inputMode="numeric"
              placeholder="Part due en €"
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px] outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              disabled={addPayer.isPending}
              onClick={() => addPayer.mutate()}
              className="inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-2.5 text-[14px] font-medium text-primary-foreground disabled:opacity-50"
            >
              <Plus className="h-4 w-4" strokeWidth={1.75} />
              Ajouter
            </button>
            <button
              type="button"
              disabled={splitEvenly.isPending}
              onClick={() => splitEvenly.mutate()}
              className="rounded-2xl hairline bg-background px-4 py-2.5 text-[14px]"
            >
              Répartir le total à parts égales
            </button>
          </div>
        </section>
      )}

      <section className="mt-8">
        <p className="eyebrow mb-3">Parts des participants</p>
        {payments.length === 0 ? (
          <p className="text-[15px] text-muted-foreground">Aucune part définie.</p>
        ) : (
          <ul className="space-y-2">
            {payments.map((p) => (
              <li
                key={p.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-2xl hairline bg-card px-4 py-3 text-[14px]"
              >
                <span>
                  {p.payer_name}
                  <span className="text-muted-foreground"> · {p.label}</span>
                </span>
                <span className="flex items-center gap-3">
                  <span
                    className={cn(
                      "font-medium",
                      p.amount_paid >= p.amount_due && p.amount_due > 0 && "text-emerald-600",
                    )}
                  >
                    {formatPrice(p.amount_paid)} / {formatPrice(p.amount_due)}
                  </span>
                  {isOwner && (
                    <>
                      <button
                        type="button"
                        onClick={() => markPaid.mutate(p.id)}
                        className="rounded-full bg-primary px-3 py-1 text-[12px] text-primary-foreground"
                      >
                        Marquer payé
                      </button>
                      <button
                        type="button"
                        aria-label="Supprimer"
                        onClick={() => removePayment.mutate(p.id)}
                        className="text-muted-foreground transition-colors hover:text-foreground"
                      >
                        <Trash2 className="h-4 w-4" strokeWidth={1.75} />
                      </button>
                    </>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function InvoicePanel({ id }: { id: string }) {
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const { data: payments = [] } = useQuery(paymentsQuery(id));
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: profile } = useQuery(profileQuery(userId));

  const participants = useMemo(() => event?.event_participants ?? [], [event]);
  const { data: rates = [] } = useQuery(allRatesQuery(participants.map((p) => p.card_id)));

  const cardById = new Map(cards.map((c) => [c.id, c]));
  const eventDate = event ? new Date(event.starts_at) : null;

  const lines = participants.map((p) => {
    const rate = rateForDate(
      (rates as Rate[]).filter((r) => r.card_id === p.card_id),
      eventDate,
    );
    return {
      id: p.id,
      name: cardById.get(p.card_id)?.name ?? "Prestation",
      role: p.role_label,
      price: rate?.price ?? 0,
      unit: rate?.unit ?? "forfait",
    };
  });

  const total = lines.reduce((s, l) => s + l.price, 0);
  const collected = payments.reduce((s, p) => s + p.amount_paid, 0);

  return (
    <div>
      <div className="flex justify-end print:hidden">
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-[13px] font-medium text-primary-foreground"
        >
          <Printer className="h-4 w-4" strokeWidth={1.75} />
          Imprimer
        </button>
      </div>

      <article className="mt-4 rounded-3xl hairline bg-card p-7 shadow-soft print:border-0 print:shadow-none">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-[20px] font-semibold tracking-[-0.03em]">AIME</p>
            <p className="text-[13px] text-muted-foreground">Le réseau des bonnes rencontres</p>
          </div>
          <div className="text-right text-[13px] text-muted-foreground">
            <p className="font-medium text-foreground">{event?.title}</p>
            {event && <p className="first-letter:uppercase">{formatDateTime(event.starts_at)}</p>}
            {(event?.location || event?.city) && (
              <p>{[event?.location, event?.city].filter(Boolean).join(" · ")}</p>
            )}
            {profile?.display_name && <p className="mt-1">Émise pour {profile.display_name}</p>}
          </div>
        </header>

        <table className="mt-8 w-full text-[14px]">
          <thead>
            <tr className="border-b border-border text-left text-[12px] tracking-[0.12em] text-muted-foreground uppercase">
              <th className="pb-2 font-normal">Prestation</th>
              <th className="pb-2 font-normal">Rôle</th>
              <th className="pb-2 text-right font-normal">Montant</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => (
              <tr key={l.id} className="border-b border-border/60">
                <td className="py-2.5">{l.name}</td>
                <td className="py-2.5 text-muted-foreground">{l.role}</td>
                <td className="py-2.5 text-right">
                  {l.price ? `${formatPrice(l.price)} / ${l.unit}` : "Sur devis"}
                </td>
              </tr>
            ))}
            {lines.length === 0 && (
              <tr>
                <td colSpan={3} className="py-4 text-muted-foreground">
                  Aucune prestation associée à ce projet.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="mt-6 ml-auto max-w-xs space-y-1.5 text-[14px]">
          <p className="flex justify-between">
            <span className="text-muted-foreground">Total</span>
            <span className="font-medium">{formatPrice(total)}</span>
          </p>
          <p className="flex justify-between">
            <span className="text-muted-foreground">Déjà réglé</span>
            <span>{formatPrice(collected)}</span>
          </p>
          <p className="flex justify-between border-t border-border pt-1.5 text-[17px] font-semibold tracking-[-0.02em]">
            <span>Reste à régler</span>
            <span>{formatPrice(Math.max(0, total - collected))}</span>
          </p>
        </div>

        {payments.length > 0 && (
          <div className="mt-8">
            <p className="eyebrow mb-2">Règlements par participant</p>
            <ul className="space-y-1.5 text-[14px]">
              {payments.map((p) => (
                <li key={p.id} className="flex justify-between border-b border-border/50 py-1.5">
                  <span>{p.payer_name}</span>
                  <span className="text-muted-foreground">
                    {formatPrice(p.amount_paid)} / {formatPrice(p.amount_due)}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="mt-8 text-[12px] text-muted-foreground">
          Document généré par AIME. Les prestations sont contractées directement entre les
          participants et les prestataires.
        </p>
      </article>
    </div>
  );
}

function MusicPanel({ id }: { id: string }) {
  const { userId } = useAuth();
  const { data: event } = useQuery(eventQuery(id));
  const isHost = !!event && event.owner_id === userId;

  return (
    <div>
      <p className="max-w-xl text-[15px] leading-relaxed text-muted-foreground">
        {isHost
          ? "Vos invités proposent des morceaux et des mots ; vous validez et la journée se lit comme un conducteur."
          : "Proposez un morceau, un message pour les mariés, une lecture. L'organisateur valide."}
      </p>
      <div className="mt-6">
        <RadioPanel
          eventId={id}
          cardName={event?.title ?? "l'événement"}
          city={event?.city ?? null}
          canManage={isHost}
        />
      </div>
      <div className="mt-8">
        <MusicBox
          eventId={id}
          canManage={isHost}
          collaborative
          city={event?.city ?? null}
          title="MusicBox de l'événement"
          intro="Chaque date, chaque créneau : cérémonie, repas, soirée. Musique, dédicaces, récits, tâches et rendez-vous au même endroit."
        />
      </div>
    </div>
  );
}
