import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  ClearVisualButton,
  VisualLibraryButton,
  VisualLibraryDialog,
} from "@/components/aime/media/VisualLibraryDialog";
import type { WorldMedia, WorldProject } from "@/lib/aime/world/types";

const HERO_INTRO_LIMIT = 300;

function toLocalDateTime(ms: number) {
  const d = new Date(ms);
  const pad = (n: number) => `${n}`.padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function heroMediaOf(project: WorldProject) {
  return project.media.find((item) => item.id === "hero-media") ?? null;
}

function normalizeMediaUrl(value: string) {
  const raw = value.trim();
  if (!raw) return "";
  try {
    const url = new URL(raw);
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
  } catch {
    return "";
  }
}

function clampHeroIntro(value: string) {
  return value.slice(0, HERO_INTRO_LIMIT);
}

function nextHeroMedia(
  project: WorldProject,
  kind: "photo" | "video",
  url: string,
): WorldProject["media"] {
  const hero: WorldMedia = {
    id: "hero-media",
    kind,
    at: project.pivot.value,
    title: "Hero du projet",
    ...(url ? { url, ...(kind === "photo" ? { thumb: url } : {}) } : {}),
    confidence: "confirme",
  };
  return [hero, ...project.media.filter((item) => item.id !== "hero-media")];
}

export function EditProjectSheet({
  open,
  onOpenChange,
  project,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: WorldProject;
  onSave: (next: WorldProject) => Promise<void>;
}) {
  const hero = heroMediaOf(project);
  const [title, setTitle] = useState(project.title);
  const [subtitle, setSubtitle] = useState(clampHeroIntro(project.subtitle ?? ""));
  const [city, setCity] = useState(project.city.value ?? "");
  const [venue, setVenue] = useState(project.venue.value ?? "");
  const [date, setDate] = useState(toLocalDateTime(project.pivot.value));
  const [heroKind, setHeroKind] = useState<"photo" | "video">(hero?.kind ?? "photo");
  const [heroUrl, setHeroUrl] = useState(hero?.url ?? hero?.thumb ?? "");
  const [visualLibraryOpen, setVisualLibraryOpen] = useState(false);
  const previewUrl = normalizeMediaUrl(heroUrl);

  useEffect(() => {
    if (!open) return;
    const currentHero = heroMediaOf(project);
    setTitle(project.title);
    setSubtitle(clampHeroIntro(project.subtitle ?? ""));
    setCity(project.city.value ?? "");
    setVenue(project.venue.value ?? "");
    setDate(toLocalDateTime(project.pivot.value));
    setHeroKind(currentHero?.kind ?? "photo");
    setHeroUrl(currentHero?.url ?? currentHero?.thumb ?? "");
  }, [open, project]);

  const save = useMutation({
    mutationFn: async () => {
      const when = Date.parse(date);
      const normalizedHeroUrl = normalizeMediaUrl(heroUrl);
      if (heroUrl.trim() && !normalizedHeroUrl) {
        throw new Error("Le visuel du hero doit être une URL http(s) valide.");
      }
      const next: WorldProject = {
        ...project,
        title: title.trim() || project.title,
        ...(clampHeroIntro(subtitle).trim() ? { subtitle: clampHeroIntro(subtitle).trim() } : {}),
        pivot: { ...project.pivot, value: Number.isNaN(when) ? project.pivot.value : when },
        city: {
          ...project.city,
          value: city.trim() || null,
          confidence: city.trim() ? "confirme" : "manquant",
        },
        venue: {
          ...project.venue,
          value: venue.trim() || null,
          confidence: venue.trim() ? "confirme" : "manquant",
        },
        media: normalizedHeroUrl
          ? nextHeroMedia(
              {
                ...project,
                pivot: { ...project.pivot, value: Number.isNaN(when) ? project.pivot.value : when },
              },
              heroKind,
              normalizedHeroUrl,
            )
          : project.media.filter((item) => item.id !== "hero-media"),
      };
      await onSave(next);
    },
    onError: (error: Error) => toast.error(error.message),
    onSuccess: () => onOpenChange(false),
  });

  const field = "w-full rounded-2xl hairline bg-background px-4 py-3 text-[15px] outline-none";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-xl">
        <SheetHeader className="border-b border-hairline px-5 py-4 text-left">
          <SheetTitle className="text-[20px] font-semibold">Modifier le projet</SheetTitle>
        </SheetHeader>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
          <div className="space-y-6">
            <label className="block space-y-2 text-[13px] font-medium">
              Titre
              <input value={title} onChange={(e) => setTitle(e.target.value)} className={field} />
            </label>
            <label className="block space-y-2 text-[13px] font-medium">
              Accroche du héros
              <p className="text-[12px] font-normal text-muted-foreground">
                Phrase courte uniquement, pas de biographie.
              </p>
              <textarea
                value={subtitle}
                onChange={(e) => setSubtitle(clampHeroIntro(e.target.value))}
                maxLength={HERO_INTRO_LIMIT}
                rows={4}
                className={field}
              />
              <span className="block text-right text-[12px] text-muted-foreground">
                {subtitle.length}/{HERO_INTRO_LIMIT}
              </span>
            </label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block space-y-2 text-[13px] font-medium">
                Ville
                <input value={city} onChange={(e) => setCity(e.target.value)} className={field} />
              </label>
              <label className="block space-y-2 text-[13px] font-medium">
                Lieu
                <input value={venue} onChange={(e) => setVenue(e.target.value)} className={field} />
              </label>
            </div>
            <label className="block space-y-2 text-[13px] font-medium">
              Date
              <input
                type="datetime-local"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={field}
              />
            </label>
            <div className="space-y-3 rounded-3xl hairline bg-card p-4 shadow-soft">
              <div>
                <p className="text-[13px] font-medium">Visuel du héros</p>
                <p className="mt-1 text-[13px] text-muted-foreground">
                  Même logique que la page publique, mais appliquée au projet.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <VisualLibraryButton onClick={() => setVisualLibraryOpen(true)} />
                {heroUrl && <ClearVisualButton onClick={() => setHeroUrl("")} />}
              </div>
              <div className="grid gap-3 sm:grid-cols-[140px_minmax(0,1fr)]">
                <select
                  value={heroKind}
                  onChange={(e) => setHeroKind(e.target.value as "photo" | "video")}
                  className={field}
                >
                  <option value="photo">Photo</option>
                  <option value="video">Vidéo</option>
                </select>
                <input
                  value={heroUrl}
                  onChange={(e) => setHeroUrl(e.target.value)}
                  placeholder="https://…"
                  className={field}
                />
              </div>
              {previewUrl && (
                <div className="overflow-hidden rounded-2xl border border-hairline bg-background">
                  {heroKind === "video" ? (
                    <video
                      src={previewUrl}
                      muted
                      loop
                      playsInline
                      autoPlay
                      className="aspect-video w-full object-cover"
                    />
                  ) : (
                    <img
                      src={previewUrl}
                      alt="Aperçu du héros"
                      className="aspect-video w-full object-cover"
                    />
                  )}
                </div>
              )}
              <VisualLibraryDialog
                open={visualLibraryOpen}
                onOpenChange={setVisualLibraryOpen}
                selectedUniverse={project.universe}
                selectedDomain={null}
                onPick={({ url }) => {
                  setHeroKind("photo");
                  setHeroUrl(url);
                }}
              />
            </div>
            <button
              type="button"
              disabled={save.isPending}
              onClick={() => save.mutate()}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-primary px-5 text-[14px] font-medium text-primary-foreground disabled:opacity-50"
            >
              {save.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Enregistrer
            </button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
