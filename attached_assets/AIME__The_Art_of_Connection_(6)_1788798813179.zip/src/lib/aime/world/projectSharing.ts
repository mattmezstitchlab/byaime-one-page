/**
 * Partage de projet : derive le role de chaque participant depuis les
 * tables existantes(events, event_participants, cards)。Aucune copie :
 * l'annuaire des personnes impliquees est deja dans le projet。

 * Un editeur partage peut preparer des modifications(etat local, demo,
 * validation agent), mais la persistance reste verrouillee au proprietaire
 * tant que la migration project_members(avec RLS) n'est pas appliquee。
 */

export type ProjectMemberRole = "owner" | "editor" | "viewer";

export type ProjectMember = {
  userId: string;
  name: string;
  role: ProjectMemberRole;
  cardId: string | null;
  slot: string | null;
};

export type SharingInput = {
  ownerId: string;
  participants?: {
    card_id: string;
    role_label: string | null;
  }[];
  cards?: {
    id: string;
    name: string;
    owner_id: string | null;
  }[];
};

/** Le role d'un utilisateur sur ce projet, derive depuis son event_owner et ses cards。 */
export function roleForUser(
  userId: string | null,
  ownerId: string,
  input: SharingInput,
): ProjectMemberRole {
  if (!userId) return "viewer";
  if (userId === ownerId) return "owner";
  const card = input.cards?.find(
    (c) => c.owner_id === userId && input.participants?.some((p) => p.card_id === c.id),
  );
  if (card) return "editor";
  return "viewer";
}

/** La liste des membres du projet(proprietaire + participants editeurs。 */
export function projectMembers(input: SharingInput): ProjectMember[] {
  const members: ProjectMember[] = [];
  const seen = new Set<string>();
  const push = (m: ProjectMember) => {
    if (seen.has(m.userId)) return;
    seen.add(m.userId);
    members.push(m);
  };
  push({ userId: input.ownerId, name: "Proprietaire", role: "owner", cardId: null, slot: null });
  for (const p of input.participants ?? []) {
    const card = input.cards?.find((c) => c.id === p.card_id);
    const userId = card?.owner_id;
    if (!userId) continue;
    push({
      userId,
      name: card?.name ?? "Participant",
      role: "editor",
      cardId: p.card_id,
      slot: p.role_label,
    });
  }
  return members;
}
