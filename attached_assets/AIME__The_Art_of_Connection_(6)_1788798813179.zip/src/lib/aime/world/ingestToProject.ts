/**
 * Un document lu par le Bureau devient UN SEUL ensemble relié dans le projet :
 * le document, le prestataire, l'engagement financier, et rien d'autre.
 *
 * Les vues (Documents, Finance, Prestataires, Avant) ne stockent rien : elles
 * lisent ce modèle. La ligne de temps en est la projection (voir derive.ts).
 */
import type { DocumentExtraction } from "@/lib/bureau/documents.functions";
import type {
  WorldDocument,
  WorldDocumentKind,
  WorldPayment,
  WorldProject,
  WorldProvider,
  WorldRelation,
} from "./types";

/** Ce qu'AIME propose d'ajouter, avant toute écriture. Rien n'est enregistré ici. */
export type IngestProposal = {
  /** Une phrase lisible : « Devis — Coiffure & maquillage ». */
  headline: string;
  document: WorldDocument;
  /** Le prestataire reconnu, existant ou à créer. */
  provider: WorldProvider | null;
  providerIsNew: boolean;
  payments: WorldPayment[];
  /** Les vues qui verront l'information apparaître. */
  targets: string[];
  /** Les champs que l'agent n'a pas pu lire avec certitude. */
  uncertain: string[];
  recap: { label: string; value: string }[];
};

const KIND: Record<string, WorldDocumentKind> = {
  devis: "devis",
  facture: "facture",
  contrat: "contrat",
  acompte: "facture",
  recu: "facture",
};

function slug(text: string) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function dateOf(value: string | null, fallback: number) {
  if (!value) return fallback;
  const t = Date.parse(value);
  return Number.isFinite(t) ? t : fallback;
}

const euro = (cents: number) =>
  (cents / 100).toLocaleString("fr-FR", { style: "currency", currency: "EUR" });

const day = (t: number) =>
  new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });

/**
 * Transforme une fiche lue en proposition. Aucun champ n'est inventé : ce qui
 * manque reste absent et apparaît dans `uncertain`.
 */
export function proposalFromExtraction(
  ext: DocumentExtraction,
  fileName: string,
  project: WorldProject,
  now = Date.now(),
): IngestProposal {
  const kind = KIND[ext.doc_type] ?? "document";
  const issuedAt = dateOf(ext.issued_on, now);
  const dueAt = dateOf(ext.due_on, issuedAt);
  const vendor = ext.issuer?.trim() || null;

  const needle = vendor?.toLowerCase() ?? null;
  const existing =
    (needle
      ? project.providers.find((p) => {
          const name = p.name?.toLowerCase();
          if (!name) return false;
          return name === needle || name.includes(needle) || needle.includes(name);
        })
      : undefined) ?? null;

  const providerId = existing?.id ?? (vendor ? `pro-${slug(vendor)}` : undefined);
  const totalCents = ext.amount_ttc != null ? Math.round(ext.amount_ttc) : undefined;

  const provider: WorldProvider | null = existing
    ? {
        ...existing,
        ...(totalCents != null && existing.amountCents == null ? { amountCents: totalCents } : {}),
      }
    : vendor
      ? {
          id: providerId as string,
          role: ext.purpose?.trim() || "Prestataire",
          name: vendor,
          status: kind === "devis" ? "contacte" : "reserve",
          ...(totalCents != null ? { amountCents: totalCents } : {}),
          confidence: ext.confidence >= 0.7 ? "confirme" : "a_confirmer",
        }
      : null;

  const document: WorldDocument = {
    id: `doc-${slug(fileName)}-${issuedAt}`,
    title: ext.summary?.trim() || fileName,
    at: issuedAt,
    kind,
    ...(providerId ? { providerId } : {}),
    ...(totalCents != null ? { amountCents: totalCents } : {}),
    ...(ext.doc_number ? { detail: `Réf. ${ext.doc_number}` } : {}),
    confidence: ext.confidence >= 0.7 ? "confirme" : "a_confirmer",
  };

  const payments: WorldPayment[] = [];
  if (totalCents != null && totalCents > 0) {
    const paid = !!ext.paid_on;
    payments.push({
      id: `pay-${document.id}`,
      label: `${vendor ?? "Prestataire"} — ${paid ? "réglé" : kind === "devis" ? "solde" : "à régler"}`,
      at: paid ? dateOf(ext.paid_on, dueAt) : dueAt,
      amountCents: totalCents,
      ...(providerId ? { providerId } : {}),
      state: paid ? "paye" : "du",
      confidence: document.confidence,
    });
  }

  const recap: { label: string; value: string }[] = [
    { label: "Type", value: kind === "document" ? "Document" : kind },
    ...(vendor ? [{ label: "Prestataire", value: vendor }] : []),
    ...(totalCents != null ? [{ label: "Montant", value: euro(totalCents) }] : []),
    ...(ext.amount_vat != null ? [{ label: "TVA", value: euro(Math.round(ext.amount_vat)) }] : []),
    { label: "Date", value: day(issuedAt) },
    ...(ext.due_on ? [{ label: "Échéance", value: day(dueAt) }] : []),
    ...(ext.doc_number ? [{ label: "Référence", value: ext.doc_number }] : []),
  ];

  const targets = [
    "Documents",
    ...(provider ? ["Prestataires"] : []),
    ...(payments.length ? ["Finance"] : []),
    "Ligne de temps",
  ];

  return {
    headline: `${kind === "document" ? "Document" : kind[0]!.toUpperCase() + kind.slice(1)}${
      ext.purpose ? ` — ${ext.purpose}` : vendor ? ` — ${vendor}` : ""
    }`,
    document,
    provider,
    providerIsNew: !existing && !!provider,
    payments,
    targets,
    uncertain: ext.uncertain_fields ?? [],
    recap,
  };
}

/** Applique la proposition au projet : une seule écriture, tout est relié. */
export function applyProposal(project: WorldProject, p: IngestProposal): WorldProject {
  const providers = p.provider
    ? p.providerIsNew
      ? [...project.providers, p.provider]
      : project.providers.map((v) => (v.id === p.provider!.id ? p.provider! : v))
    : project.providers;

  // IDS complets des repères de la timeline (voir derive.ts).
  const docMarker = `doc-${p.document.id}`;
  const relations: WorldRelation[] = [
    ...(p.provider
      ? [
          {
            id: `rel-${p.document.id}-prestataire`,
            from_kind: "document",
            from_id: docMarker,
            to_kind: "provider",
            to_id: `prestataire-${p.provider.id}`,
            relation: "lie",
          },
        ]
      : []),
    ...p.payments.map((payment): WorldRelation => ({
      id: `rel-${p.document.id}-payment-${payment.id}`,
      from_kind: "document",
      from_id: docMarker,
      to_kind: "payment",
      to_id: `paiement-${payment.id}`,
      relation: "paye",
    })),
  ];

  return {
    ...project,
    providers,
    documents: [...project.documents.filter((d) => d.id !== p.document.id), p.document],
    payments: [
      ...project.payments.filter((v) => !p.payments.some((n) => n.id === v.id)),
      ...p.payments,
    ],
    // Le graphe projet s'enrichit sans dupliquer les liens existants (même paire.)
    relations: [
      ...(project.relations ?? []).filter(
        (r) => !relations.some((n) => n.from_id === r.from_id && n.to_id === r.to_id),
      ),
      ...relations,
    ],
  };
}
