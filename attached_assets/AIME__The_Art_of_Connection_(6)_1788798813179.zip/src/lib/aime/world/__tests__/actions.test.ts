/**
 * Registre d'actions autorisees (phase 4) — fonctions pures sur le
 * WorldProject, testees sans base ni reseau.

 * Execution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import {
  actionCreateTask,
  actionEditMarkerTitle,
  actionMoveMarker,
  createTask,
  editMarkerTitle,
  worldActionByKey,
  WORLD_ACTION_KEYS,
} from "../actions";
import type { WorldProject } from "../types";

function baseProject(over: Partial<WorldProject> = {}): WorldProject {
  return {
    id: "projet-1",
    kind: "mariage",
    title: "Mariage",
    universe: "mariage",
    pivot: { value: Date.UTC(2027, 7, 14), confidence: "confirme" },
    city: { value: "Lille", confidence: "confirme" },
    venue: { value: null, confidence: "manquant" },
    guests: { value: null, confidence: "manquant" },
    people: [],
    providers: [],
    moments: [],
    tasks: [],
    documents: [],
    payments: [],
    media: [],
    tracks: [],
    messages: [],
    reviews: [],
    intentions: [],
    missing: [],
    ...over,
  };
}

describe("editMarkerTitle", () => {
  test("ecrit le titre dans timelineEdits sans toucher au modele", () => {
    const project = baseProject({
      tasks: [{ id: "t1", label: "Salle", at: 0, confidence: "confirme" }],
    });
    const next = editMarkerTitle(project, "tache-t1", "Salle des fetes");
    assert.equal(next.timelineEdits?.["tache-t1"]?.title, "Salle des fetes");
    const e0 = next.tasks[0];
    assert.ok(e0);
    assert.equal(e0.label, "Salle");
  });
});

describe("createTask", () => {
  test("ajoute une tache avec un id stable et une confiance suggere", () => {
    const project = baseProject();
    const next = createTask(project, { label: "Appeler la mairie", at: Date.UTC(2027, 5, 1) });
    assert.equal(next.tasks.length, 1);
    const t0 = next.tasks[0];
    assert.ok(t0);
    assert.equal(t0.label, "Appeler la mairie");
    assert.equal(t0.confidence, "suggere");
    assert.ok(/^task-/.test(t0.id));
  });

  test("l'id est stable: deux creations du meme label donnent le meme id", () => {
    const project = baseProject();
    const a = createTask(project, { label: "Traiteur", at: 0 });
    const b = createTask(project, { label: "Traiteur", at: 0 });
    const a0 = a.tasks[0];
    const b0 = b.tasks[0];
    assert.ok(a0 && b0);
    assert.equal(a0.id, b0.id);
  });
});

describe("registre d'actions (factories)", () => {
  test("les factories produisent des actions reelles", () => {
    const project = baseProject({
      tasks: [{ id: "t1", label: "Salle", at: 0, confidence: "confirme" }],
    });
    const moved = actionMoveMarker("tache-t1", Date.UTC(2027, 5, 1)).apply(project);
    assert.equal(moved.timelineEdits?.["tache-t1"]?.time, Date.UTC(2027, 5, 1));
    const created = actionCreateTask({ label: "Traiteur", at: Date.UTC(2027, 6, 1) }).apply(
      project,
    );
    assert.equal(created.tasks.length, 2);
    assert.equal(created.tasks[1]?.label, "Traiteur");
    const renamed = actionEditMarkerTitle("tache-t1", "Salle des fetes").apply(project);
    assert.equal(renamed.timelineEdits?.["tache-t1"]?.title, "Salle des fetes");
  });

  test("worldActionByKey resout les cles connues et refuse les entrées incompletes", () => {
    assert.ok(WORLD_ACTION_KEYS.includes("creer_tache"));
    const c0 = worldActionByKey("creer_tache", { label: "Mairie", at: 0 });
    assert.ok(c0);
    assert.equal(c0.key, "creer_tache");
    const d1 = worldActionByKey("deplacer_repere", { id: "tache-t1", time: 0 });
    assert.ok(d1);
    assert.equal(d1.key, "deplacer_repere");
    const e2 = worldActionByKey("editer_titre_repere", { id: "tache-t1", title: "X" });
    assert.ok(e2);
    assert.equal(e2.key, "editer_titre_repere");
    assert.equal(worldActionByKey("creer_tache", {}), null);
    assert.equal(worldActionByKey("deplacer_repere", {}), null);
  });
});
