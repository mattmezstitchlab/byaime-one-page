/**
 * Partage de projet (phase 5) — derivation pure des roles depuis les
 * tables existantes, testee sans base ni reseau。
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { projectMembers, roleForUser } from "../projectSharing";

const OWNER = "u-owner";
const EDITOR = "u-editor";
const OUTSIDER = "u-badaud";

const PARTICIPANTS = [
  { card_id: "card-marie", role_label: "La mariee" },
  { card_id: "card-photo", role_label: "Photographe" },
];
const CARDS = [
  { id: "card-marie", name: "Camille", owner_id: OWNER },
  { id: "card-photo", name: "Marco", owner_id: EDITOR },
  { id: "card-invitee", name: "Julie", owner_id: null },
];
const INPUT = { ownerId: OWNER, participants: PARTICIPANTS, cards: CARDS };

describe("roleForUser", () => {
  test("le proprietaire est owner", () => {
    assert.equal(roleForUser(OWNER, OWNER, INPUT), "owner");
  });

  test("un participant dont la card appartient a un autre compte est editor", () => {
    assert.equal(roleForUser(EDITOR, OWNER, INPUT), "editor");
  });

  test("un utilisateur sans lien est viewer; personne anonyme aussi", () => {
    assert.equal(roleForUser(OUTSIDER, OWNER, INPUT), "viewer");
    assert.equal(roleForUser(null, OWNER, INPUT), "viewer");
  });
});

describe("projectMembers", () => {
  test("liste le proprietaire et les editeurs, sans doublon", () => {
    const members = projectMembers(INPUT);
    assert.equal(members.length, 2);
    const m0 = members[0];
    const m1 = members[1];
    assert.ok(m0 && m1);
    assert.equal(m0.role, "owner");
    assert.equal(m1.userId, EDITOR);
    assert.equal(m1.slot, "Photographe");
  });
});
