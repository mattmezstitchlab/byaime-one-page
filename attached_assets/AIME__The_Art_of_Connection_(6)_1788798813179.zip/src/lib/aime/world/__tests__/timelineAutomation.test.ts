/**
 * Mutations generiques de timeline (phase 3) - simulateDateChange
 * previsualise un deplacement de repere en ecrivant timelineEdits dans le
 * projet canonique, et analyzeTimeline produit les alertes depuis le derive.
 *
 * Execution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { deriveTimeline } from "../derive";
import { analyzeTimeline, simulateDateChange } from "../timelineAutomation";
import type { WorldProject } from "../types";

function baseProject(over: Partial<WorldProject> = {}): WorldProject {
  return {
    id: "projet-1",
    kind: "mariage",
    title: "Mariage",
    universe: "mariage",
    pivot: { value: Date.UTC(2027, 7, 14), confidence: "confirme" },
    city: { value: "Lille", confidence: "confirme" },
    venue: { value: null, confidence: "manquant" },
    guests: { value: null, confidence: "manquant" },
    people: [],
    providers: [],
    moments: [],
    tasks: [
      { id: "t1", label: "Reserver la salle", at: Date.UTC(2027, 4, 1), confidence: "confirme" },
    ],
    documents: [],
    payments: [],
    media: [],
    tracks: [],
    messages: [],
    reviews: [],
    intentions: [],
    missing: [],
    ...over,
  };
}

describe("simulateDateChange - deplacer un repere ecrit timelineEdits", () => {
  test("le repere se deplace et le projet est enrichi sans ecraser le reste", () => {
    const project = baseProject();
    const markerId = "tache-t1";
    const nextTime = Date.UTC(2027, 5, 1);
    const { project: next, changed } = simulateDateChange(project, markerId, nextTime);
    assert.deepEqual(changed, ["Reserver la salle"]);
    assert.equal(next.timelineEdits?.[markerId]?.time, nextTime);
    assert.equal(next.tasks.length, 1);
    assert.equal(next.providers.length, 0);
  });

  test("un second deplacement ecrase le premier sans entree dupliquee", () => {
    const project = baseProject();
    const markerId = "tache-t1";
    const first = simulateDateChange(project, markerId, Date.UTC(2027, 4, 10));
    const second = simulateDateChange(first.project, markerId, Date.UTC(2027, 5, 20));
    assert.equal(second.project.timelineEdits?.[markerId]?.time, Date.UTC(2027, 5, 20));
    assert.equal(Object.keys(second.project.timelineEdits ?? {}).length, 1);
  });

  test("deplacer rend le repere au bon endroit dans les reperes derives", () => {
    const project = baseProject();
    const markerId = "tache-t1";
    const { project: next } = simulateDateChange(project, markerId, Date.UTC(2027, 6, 1));
    const markers = deriveTimeline(next);
    assert.equal(markers.find((m) => m.id === markerId)?.time, Date.UTC(2027, 6, 1));
  });
});

describe("analyzeTimeline - les alertes derivent du projet", () => {
  test("un retard est signale quand une tache non terminee passe la date", () => {
    const project = baseProject({
      tasks: [
        { id: "t1", label: "Reserver la salle", at: Date.UTC(2027, 4, 1), confidence: "suggere" },
      ],
    });
    const result = analyzeTimeline(project, Date.UTC(2027, 9, 1));
    assert.ok(result.some((a) => a.kind === "retard" && a.markerIds.includes("tache-t1")));
  });

  test("les elements non termines, plus proches dans le temps, sont proposes en prochaine action", () => {
    const project = baseProject({
      tasks: [
        { id: "t1", label: "Reserver la salle", at: Date.UTC(2027, 4, 1), confidence: "suggere" },
      ],
    });
    const result = analyzeTimeline(project, Date.UTC(2026, 9, 1));
    assert.ok(
      result.some((a) => a.kind === "prochaine_action" && a.markerIds.includes("tache-t1")),
    );
  });
});
