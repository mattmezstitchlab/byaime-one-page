/**
 * Graphe de relations projet (phase 2) — le graphe vit dans le projet
 * canonique (`WorldProject.relations`) et se projette sur les repères de la
 * timeline (`relatedIds`), sans dupliquer les liens lors d'une ré-ingestion.
 *
 * Exécution : npm test
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";

import { deriveTimeline } from "../derive";
import { applyProposal, type IngestProposal } from "../ingestToProject";
import { neighborsOf, withProjectRelations, type TimelineRelation } from "../../timelineRelations";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import type { WorldProject, WorldRelation } from "../types";

function baseProject(over: Partial<WorldProject> = {}): WorldProject {
  return {
    id: "projet-1",
    kind: "mariage",
    title: "Mariage",
    universe: "mariage",
    pivot: { value: Date.UTC(2027, 7, 14), confidence: "confirme" },
    city: { value: "Lille", confidence: "confirme" },
    venue: { value: null, confidence: "manquant" },
    guests: { value: null, confidence: "manquant" },
    people: [],
    providers: [],
    moments: [],
    tasks: [],
    documents: [],
    payments: [],
    media: [],
    tracks: [],
    messages: [],
    reviews: [],
    intentions: [],
    missing: [],
    ...over,
  };
}

describe("projectRelations — le graphe vit dans le projet", () => {
  test("sans relations, les repères restent sans relatedIds", () => {
    const project = baseProject({
      documents: [
        { id: "doc-1", title: "Devis coiffure", at: 0, kind: "devis", confidence: "confirme" },
      ],
      providers: [{ id: "prov-1", role: "Coiffure", status: "choisi", confidence: "confirme" }],
    });
    const markers = deriveTimeline(project);
    assert.ok(markers.length > 0);
    assert.equal(
      markers.every((m) => !m.relatedIds?.length),
      true,
    );
  });

  test("withProjectRelations projette les liens sur les repères concernés", () => {
    const project = baseProject({
      documents: [
        { id: "doc-1", title: "Devis coiffure", at: 0, kind: "devis", confidence: "confirme" },
      ],
      providers: [{ id: "prov-1", role: "Coiffure", status: "choisi", confidence: "confirme" }],
      payments: [
        {
          id: "pay-1",
          label: "Acompte",
          at: 0,
          amountCents: 50_00,
          state: "paye",
          confidence: "confirme",
        },
      ],
      relations: [
        {
          id: "rel-1",
          from_kind: "document",
          from_id: "doc-doc-1",
          to_kind: "provider",
          to_id: "prestataire-prov-1",
          relation: "lie",
        },
        {
          id: "rel-2",
          from_kind: "document",
          from_id: "doc-doc-1",
          to_kind: "payment",
          to_id: "paiement-pay-1",
          relation: "paye",
        },
      ],
    });
    const markers = deriveTimeline(project);
    const doc = markers.find((m) => m.id === "doc-doc-1");
    assert.ok(doc);
    assert.ok(doc.relatedIds?.includes("prestataire-prov-1"));
    assert.ok(doc.relatedIds?.includes("paiement-pay-1"));
    const provider = markers.find((m) => m.id === "prestataire-prov-1");
    assert.ok(provider);
    assert.ok(provider.relatedIds?.includes("doc-doc-1"));
    assert.deepEqual(
      neighborsOf(doc!, markers)
        .map((m) => m.id)
        .sort(),
      ["paiement-pay-1", "prestataire-prov-1"].sort(),
    );
  });

  test("applyProposal crée les liens document→prestataire et document→paiement", () => {
    const project = baseProject();
    const p: IngestProposal = {
      headline: "Devis — Coiffure",
      document: {
        id: "doc-2",
        title: "Devis coiffure",
        at: 0,
        kind: "devis",
        confidence: "confirme",
      },
      provider: { id: "prov-2", role: "Coiffure", status: "choisi", confidence: "confirme" },
      providerIsNew: true,
      payments: [
        {
          id: "pay-2",
          label: "Acompte",
          at: 0,
          amountCents: 100_00,
          state: "du",
          confidence: "confirme",
        },
      ],
      targets: ["documents"],
      uncertain: [],
      recap: [{ label: "Prestataire", value: "Coiffure" }],
    };
    const next = applyProposal(project, p);
    assert.equal(next.relations?.length, 2);
    assert.ok(
      next.relations?.some(
        (r) =>
          r.from_id === "doc-doc-2" && r.to_id === "prestataire-prov-2" && r.relation === "lie",
      ),
    );
    assert.ok(
      next.relations?.some(
        (r) => r.from_id === "doc-doc-2" && r.to_id === "paiement-pay-2" && r.relation === "paye",
      ),
    );
    // Ré-ingestion sans changement : pas de doublon.
    const again = applyProposal(next, p);
    assert.equal(again.relations?.length, 2);
  });

  test("withRelations (table historique) reste compatible", () => {
    const marker = (id: string, time: number): TimelineMarker => ({
      id,
      kind: "jalon",
      media: "doc",
      title: id.toUpperCase(),
      time,
      status: "execute",
      projectId: "p",
    });
    const markers = [marker("a", 0), marker("b", 1)];
    const rels = [
      {
        id: "r1",
        from_kind: "x",
        from_id: "a",
        to_kind: "y",
        to_id: "b",
        relation: "lie",
      },
    ] satisfies WorldRelation[];
    const linked = withProjectRelations(markers, baseProject({ relations: rels }));
  });
});
