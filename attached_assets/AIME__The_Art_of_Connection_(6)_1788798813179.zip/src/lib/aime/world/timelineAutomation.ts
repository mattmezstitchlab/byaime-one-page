import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import type { WorldProject } from "./types";
import { deriveTimeline } from "./derive";

export type TimelineAutomation = {
  id: string;
  kind: "retard" | "impact" | "contradiction" | "prochaine_action" | "relance";
  title: string;
  detail: string;
  severity: "info" | "attention" | "critique";
  markerIds: string[];
};

export function analyzeTimeline(project: WorldProject, now = Date.now()): TimelineAutomation[] {
  const markers = deriveTimeline(project, now);
  const result: TimelineAutomation[] = [];
  const overdue = markers.filter(
    (m) => m.time < now && m.status !== "execute" && m.status !== "annule",
  );
  overdue.slice(0, 5).forEach((m) =>
    result.push({
      id: `retard-${m.id}`,
      kind: "retard",
      title: `${m.title} est en retard`,
      detail: "Cette action peut décaler les éléments qui en dépendent.",
      severity: "critique",
      markerIds: [m.id],
    }),
  );

  const pending = markers.filter((m) => m.status === "a_valider" || m.status === "en_attente");
  pending.slice(0, 3).forEach((m) =>
    result.push({
      id: `action-${m.id}`,
      kind: "prochaine_action",
      title: `À confirmer : ${m.title}`,
      detail: "La confirmation de cet élément débloque la suite du projet.",
      severity: "attention",
      markerIds: [m.id],
    }),
  );

  const providerIds = new Map<string, string[]>();
  markers.forEach((m) => {
    const providerId =
      typeof m.metadata?.["providerId"] === "string" ? m.metadata["providerId"] : undefined;
    if (providerId) providerIds.set(providerId, [...(providerIds.get(providerId) ?? []), m.id]);
  });
  providerIds.forEach((ids, providerId) => {
    if (ids.length > 1)
      result.push({
        id: `impact-${providerId}`,
        kind: "impact",
        title: "Plusieurs éléments dépendent du même prestataire",
        detail: "Une modification de ce prestataire peut se propager à toute la chaîne concernée.",
        severity: "attention",
        markerIds: ids,
      });
  });

  const guests = project.guests.value;
  const documents = project.documents.filter((d) => d.kind === "devis" || d.kind === "facture");
  if (
    guests &&
    guests > 0 &&
    documents.some((d) => d.amountCents !== undefined && d.amountCents < guests * 1000)
  )
    result.push({
      id: "contradiction-guests-budget",
      kind: "contradiction",
      title: "Jauge et document à vérifier",
      detail: "Un document financier semble inférieur à la jauge d’invités du projet.",
      severity: "attention",
      markerIds: documents.map((d) => `doc-${d.id}`),
    });

  const next = markers
    .filter((m) => m.status !== "execute" && m.status !== "annule")
    .sort((a, b) => a.time - b.time)[0];
  if (next)
    result.push({
      id: "next-action",
      kind: "prochaine_action",
      title: `Prochaine action : ${next.title}`,
      detail: "C’est l’élément non terminé le plus proche dans le temps.",
      severity: "info",
      markerIds: [next.id],
    });

  project.providers
    .filter((p) => p.status === "contacte" && p.name)
    .slice(0, 2)
    .forEach((p) =>
      result.push({
        id: `relance-${p.id}`,
        kind: "relance",
        title: `Préparer une relance pour ${p.name}`,
        detail: `Bonjour ${p.name}, pouvez-vous nous confirmer votre disponibilité et les prochaines étapes pour le projet « ${project.title} » ?`,
        severity: "info",
        markerIds: [`prestataire-${p.id}`],
      }),
    );
  return result;
}

export function simulateDateChange(project: WorldProject, markerId: string, nextTime: number) {
  const next: WorldProject = {
    ...project,
    timelineEdits: {
      ...project.timelineEdits,
      [markerId]: { ...project.timelineEdits?.[markerId], time: nextTime },
    },
  };
  const before = deriveTimeline(project);
  const after = deriveTimeline(next);
  const changed = after
    .filter((item) => item.time !== before.find((b) => b.id === item.id)?.time)
    .map((item) => item.title);
  return { project: next, changed };
}
