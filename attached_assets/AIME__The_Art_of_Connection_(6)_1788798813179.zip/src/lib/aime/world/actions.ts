/**
 * Registre d'actions autorisees sur le WorldProject.
 *
 * Chaque action est une fonction pure(projet) -> projet suivant :
 * elle ne touche jamais la base, elle est previsualisable(et testable.
 * L'ecriture passe ensuite par le chemin unique valide(persistProjectEdits,
 * jamais par l'agent lui-meme。


 */
import { simulateDateChange } from "./timelineAutomation";
import type { WorldProject } from "./types";

function slug(text: string) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}

/** Editer le titre d'un repere derive via timelineEdits(sans toucher au modele. */
export function editMarkerTitle(project: WorldProject, id: string, title: string): WorldProject {
  return {
    ...project,
    timelineEdits: {
      ...project.timelineEdits,
      [id]: { ...project.timelineEdits?.[id], title },
    },
  };
}

export type CreateTaskInput = {
  label: string;
  at: number;
  providerId?: string;
};

/** Ajouter une tache au projet(jamais d'id invente : un id stable derivable. */
export function createTask(project: WorldProject, input: CreateTaskInput): WorldProject {
  const id = `task-${slug(input.label)}`;
  return {
    ...project,
    tasks: [
      ...project.tasks,
      {
        id,
        label: input.label,
        at: input.at,
        ...(input.providerId ? { providerId: input.providerId } : {}),
        confidence: "suggere",
      },
    ],
  };
}

/** Action authentiquee par l'utilisateur avant ecriture, ou proposee par l'agent. */
export type WorldAction = {
  key: string;
  label: string;
  /** Construit le projet suivant (effet pur, previsualisable. */
  apply: (project: WorldProject) => WorldProject;
};

/** Registre nomme des actions a proposer a l'humain pour validation. */
export function actionMoveMarker(id: string, time: number, title?: string): WorldAction {
  return {
    key: "deplacer_repere",
    label: title ? "Deplacer « " + title + " » dans le temps" : "Deplacer un repere dans le temps",
    apply: (project) => simulateDateChange(project, id, time).project,
  };
}

export function actionCreateTask(input: CreateTaskInput): WorldAction {
  return {
    key: "creer_tache",
    label: "Ajouter la tache « " + input.label + " »",
    apply: (project) => createTask(project, input),
  };
}

export function actionEditMarkerTitle(id: string, title: string): WorldAction {
  return {
    key: "editer_titre_repere",
    label: "Renommer le repere en « " + title + " »",
    apply: (project) => editMarkerTitle(project, id, title),
  };
}

/** Les actions connues : pour l'UI et les confirmations humaines. */
export const WORLD_ACTION_KEYS = ["creer_tache", "deplacer_repere", "editer_titre_repere"] as const;

export type WorldActionKey = (typeof WORLD_ACTION_KEYS)[number];

/** Construit l'action demandee par cle, ou null si inconnue. */
export function worldActionByKey(
  key: WorldActionKey,
  inputs: {
    id?: string;
    time?: number;
    title?: string;
    label?: string;
    at?: number;
    providerId?: string;
  },
): WorldAction | null {
  switch (key) {
    case "creer_tache":
      if (!inputs.label || inputs.at === undefined) return null;
      return actionCreateTask({
        label: inputs.label,
        at: inputs.at,
        ...(inputs.providerId ? { providerId: inputs.providerId } : {}),
      });
    case "deplacer_repere":
      if (!inputs.id || inputs.time === undefined) return null;
      return actionMoveMarker(inputs.id, inputs.time, inputs.title);
    case "editer_titre_repere":
      if (!inputs.id || !inputs.title) return null;
      return actionEditMarkerTitle(inputs.id, inputs.title);
    default:
      return null;
  }
}
