import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { TimelineMarker } from "@/components/aime/HeroTimeline";
import type { WorldProject, WorldRelation } from "@/lib/aime/world/types";

/**
 * Relations entre objets de la ligne de temps :
 * devis → contrat → facture → paiement, prestation → heures → bulletin,
 * mariage → jour J → photos. Un seul graphe, une seule timeline.

 * Depuis la phase 2, le graphe vit dans le projet canonique
 * (`WorldProject.relations`, scope projet) ; la table `timeline_relations`
 * (scope carte) reste prise en charge pour l'historique.
 */

export type RelationKind =
  "lie" | "decoule" | "facture" | "paye" | "illustre" | "prepare" | "remplace";

export const RELATION_LABEL: Record<RelationKind, string> = {
  lie: "Lié à",
  decoule: "Découle de",
  facture: "Facturé par",
  paye: "Payé par",
  illustre: "Illustré par",
  prepare: "Préparé par",
  remplace: "Remplacé par",
};

export type TimelineRelation = {
  id: string;
  /** Scope carte (table historique) ; absent dans le graphe projet embarqué. */
  card_id?: string;
  from_kind: string;
  from_id: string;
  to_kind: string;
  to_id: string;
  relation: string;
  note?: string | null;
};

export function relationsQuery(cardId: string) {
  return {
    queryKey: ["timeline-relations", cardId],
    queryFn: async (): Promise<TimelineRelation[]> => {
      const { data, error } = await supabase
        .from("timeline_relations")
        .select("id,card_id,from_kind,from_id,to_kind,to_id,relation,note")
        .eq("card_id", cardId)
        .limit(500);
      if (error) throw error;
      return data ?? [];
    },
  };
}

/** Relations du graphe projet, prêtes à projeter sur les repères de la timeline. */
export function projectRelations(project: WorldProject): WorldRelation[] {
  return project.relations ?? [];
}

/** Ajoute `relatedIds` à chaque repère à partir des relations enregistrées. */
export function withRelations(
  markers: TimelineMarker[],
  relations: TimelineRelation[],
): TimelineMarker[] {
  if (relations.length === 0) return markers;
  const map = new Map<string, Set<string>>();
  const add = (a: string, b: string) => {
    const s = map.get(a) ?? new Set<string>();
    s.add(b);
    map.set(a, s);
  };
  for (const r of relations) {
    add(r.from_id, r.to_id);
    add(r.to_id, r.from_id);
  }
  return markers.map((m) => {
    const linked = map.get(m.id);
    return linked ? { ...m, relatedIds: [...linked] } : m;
  });
}

/** Objets directement reliés à un repère donné. */
export function neighborsOf(marker: TimelineMarker, markers: TimelineMarker[]): TimelineMarker[] {
  const ids = new Set(marker.relatedIds ?? []);
  return markers.filter((m) => ids.has(m.id) || m.relatedIds?.includes(marker.id));
}

/** Applique le graphe projet aux repères dérivés (IDs complets de markers). */
export function withProjectRelations(
  markers: TimelineMarker[],
  project: WorldProject,
): TimelineMarker[] {
  const relations = projectRelations(project);
  if (relations.length === 0) return markers;
  return withRelations(markers, relations);
}

export function useTimelineRelations(cardId: string, enabled = true) {
  const qc = useQueryClient();
  const query = useQuery({ ...relationsQuery(cardId), enabled });

  const link = useMutation({
    mutationFn: async (input: {
      from: TimelineMarker;
      to: TimelineMarker;
      relation?: RelationKind;
      note?: string;
    }) => {
      const { error } = await supabase.from("timeline_relations").insert({
        card_id: cardId,
        from_kind: input.from.kind,
        from_id: input.from.id,
        to_kind: input.to.kind,
        to_id: input.to.id,
        relation: input.relation ?? "lie",
        note: input.note ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["timeline-relations", cardId] }),
  });

  const unlink = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("timeline_relations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["timeline-relations", cardId] }),
  });

  return { relations: query.data ?? [], link, unlink };
}
